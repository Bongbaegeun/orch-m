#!/usr/bin/python
#-*- coding: utf-8 -*-
'''
Created on 2019. 1. 3.

@author: ythan
'''

from optparse import OptionParser
import os, ssl, shutil
from time import sleep
import ruamel.yaml
from tornado.web import Application
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop

from onebox_agent.data.ob_info import OBA_CONF
from onebox_agent.data import ob_constant as obc
from onebox_agent.func.report_ob_info import ReportObinfo
from onebox_agent.func.watch_axgate_info import WatchAxgateInfo
from onebox_agent.func.update_zbxa_znmsc import ZBXA_CONF
from onebox_agent.func.update_zbxa_znmsc import ZNMSC_CONF
from onebox_agent.pnf.axgate_plugin import AxgatePlugin
from onebox_agent.handler import orchf2oba, orchm2oba

from util.logger import logger
logger = logger(tag=obc.OBA_NAME, logdir="/mnt/flash/data/onebox/onebox-agent/log/", loglevel="debug", logConsole=False).get_instance()
logger.propagate = False


def setKey(oba_base_path):
    try:
        logger.info('Set Key File')
        if not os.path.isdir('%s/key' % oba_base_path):
            os.makedirs('%s/key' % oba_base_path)
            logger.info(' - Make Key Dir')

        rootKeyFile = '%s/key/id_rsa' % oba_base_path
        zbKeyFile = '%s/key/zb_rsa' % oba_base_path
        hasRootKey = hasZbKey = setZbKeyOwn = False
        if os.path.isfile(rootKeyFile):
            hasRootKey = True
        if os.path.isfile(zbKeyFile):
            hasZbKey = True

        import commands as cmd
        status, ret = cmd.getstatusoutput("ls -g %s" % str(zbKeyFile))
        if status == 0 and ret.find('zabbix') >= 0:
            setZbKeyOwn = True

        if hasRootKey and hasZbKey and setZbKeyOwn:
            logger.info('SUCC: Set Key, Already Exist')
            return True

        return False
        # skip keygen if not exist in aos

    except Exception, e:
        logger.error("Fail to Set Key, Unknown Error, exc=%s" % str(e))
        logger.exception(e)
        return False


def makeApp(_oba_data):
    app = Application(
        orchf2oba.url(_oba_data) +
        orchm2oba.url(_oba_data)
    )

    return app


class httpSvrThread:
    
    def __init__(self, applictions, port, oba_base_path):

        self.svr = HTTPServer(applictions, ssl_options={
                "certfile": "%s/key/svr_crt.pem" % oba_base_path,
                "keyfile": "%s/key/svr_key.pem" % oba_base_path,
                "ca_certs": "%s/key/svr_ca.pem" % oba_base_path,
                "cert_reqs": ssl.CERT_REQUIRED
        })
        self.svr.bind(port)
        try:
            self.svr.start()
        except KeyboardInterrupt:
            logger.info('Keyboard Interrupt')
            self.shutdown()
    
    def shutdown(self):
        logger.info('shutdown - ioloop.stop')        
        IOLoop().current().stop()
        logger.info('shutdown - svr.stop')
        self.svr.stop()
        
    def run(self):
        logger.info('Run Http Server')
        IOLoop().current().start()

def startAPI(app, _port, _oba_base_path):
    logger.info('Start API : port=%s' % str(_port))
    svr = httpSvrThread(app, _port, _oba_base_path)
    svr.run()

'''
loop till all config's are ready
'''
def initConfig(obaCfgFile):
    logger.info("Start oba init configuration -------------------- ")
    while True:
        try:
            with open(obaCfgFile, "r") as f:
                init_oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)

            axgate_info_path = init_oba_cfg.get('axgate_info_path', None)

            if axgate_info_path is None:
                raise Exception("Input axgate_info_path into onebox-agent.conf ")
            elif os.path.exists(axgate_info_path) is False:
                raise Exception("Check axgate_info_path= %s is invalid. " % axgate_info_path)

            # load onebox-agent.conf, axgate-info
            # basic oba_cfg  + mgmt_ip, oba_base_url, etc
            oba_conf = OBA_CONF().load(init_oba_cfg, logger)

            # todo: don't exit, and loop till oba, axgate conf ready
            if oba_conf is None:
                raise Exception("Failed to load oba_conf")

            # update onebox-agent.conf file
            _ret = oba_conf.write(obaCfgFile, logger)
            if _ret is False:
                raise Exception('Failed to update onebox-agent.conf')

            # ckeck n update zbxa, znmsc conf
            plugin = AxgatePlugin()
            conf_zbxa = ZBXA_CONF(oba_conf.m_onebox_id, plugin)
            _ret_zbxa = conf_zbxa.update()
            if _ret_zbxa is not None:
                raise Exception('Failed to update zabbix agent conf. %s' % _ret_zbxa)

            # todo: skip till aos, znms ready
            conf_znms = ZNMSC_CONF(oba_conf.m_onebox_id, plugin)
            _ret_znms = conf_znms.update()
            if _ret_znms is not None:
                raise Exception('Failed to update znmsc agent conf. %s' % _ret_zbxa)

            _ret, _msg = plugin.set_zbxa_znmsc(always_on=True)
            if not _ret:
                    raise Exception("Failed to Start zbxa, znmsc. %s" % _msg)

            logger.info("Complete oba init  -------------------- ")
            return oba_conf
        except Exception, e:
            logger.exception(e)
            logger.info("Retry oba init  -------------------- ")
            sleep(10)

def main():
    
    parser = OptionParser( 
        usage="usage: %prog [options]", 
        version="One-Box Agent version %s" % obc.OBA_VERSION
        )
    parser.add_option( 
        "-c", 
        "--config-file",
        dest="config", 
        type="string",
        help="configuration file"
        )
    (options, args) = parser.parse_args()
    
    if options.config == None:
        # parser.print_help()
        # sys.exit(0)
        cfgFile = obc.FILE_OBA_CONF
    else:
        cfgFile = options.config

    logger.info("---------------[[[ OneBox-Agent Start ]]]---------------")

    try:
        oba_conf = initConfig(cfgFile)

        # start report ob-info periodically
        reportObinfo = ReportObinfo(oba_conf)
        reportObinfo.start()

        # start watch axgate-info and report immediately
        watchAxgateInfo = WatchAxgateInfo(oba_conf)
        watchAxgateInfo.start()

        setKey(oba_conf.m_oba_base_path)
        # todo
        # initStatus(_ob_info, obLib)

        app = makeApp(oba_conf)
        startAPI(app, oba_conf.m_oba_port, oba_conf.m_oba_base_path)
        
        logger.info("---------------[[[ OneBox-Agent started all tasks ]]]----------------")
    except Exception, e:
        logger.exception(e)
        raise e


if __name__ == '__main__':
    main()

