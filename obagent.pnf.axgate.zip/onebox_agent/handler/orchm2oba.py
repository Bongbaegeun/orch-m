#!/usr/bin/python
#-*- coding: utf-8 -*-

import os, json, shutil, dircache
from onebox_agent.handler.msg2orchm import OrchmRespMsg
from onebox_agent.data import ob_constant as obc
from onebox_agent.util.ob_lib import OB_LIB as obl
from onebox_agent.pnf.axgate_plugin import AxgatePlugin
import logging
logger = logging.getLogger(obc.OBA_NAME)


class Orchm2ObaRequest(OrchmRespMsg):

    def initialize(self, opCode, oba_cfg):
        self.opCode = opCode
        self.cfg = oba_cfg
        self.obl = obl(logger)

    def post(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req : %s, body=%s" % (str(self.opCode), str(reqdata)[:200]))

        if reqdata: reqdata = json.loads(reqdata)

        if self.opCode == obc.OP_FILE_PUT:
            resp = self._file_put(reqdata)
        elif self.opCode == obc.OP_FILE_DEL:
            resp = self._file_del(reqdata)
        elif self.opCode == obc.OP_FILE_DEL_EXCLUDE:
            resp = self._file_del_exclude(reqdata)
        elif self.opCode == obc.OP_ZBA_STATUS_MON_FILE:
            resp = self._zba_status_mon_file(reqdata)
        elif self.opCode == obc.OP_ZBA_RESTART:
            resp = self._zba_restart()
        else:
            resp = self.retError(obc.HTTP_BAD_REQUEST, "Unknown Post URL or Operation, opcode=%s" % str(self.opCode))

        self.write(resp)
        self.flush()

    def get(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req : %s, body=%s" % (str(self.opCode), str(reqdata)))
        resp = self.retError(obc.HTTP_BAD_REQUEST, "Unknown URL or Operation, opcode=%s" % str(self.opCode))
        self.write(resp)
        self.flush()

    def _file_put(self, reqData):
        _backupDir = reqData.get('backup_dir', None)

        # if str.isdigit(reqData['chmod']):
        #     _chmod = int(reqData['chmod'])
        _chmod = reqData.get('chmod', 0755)

        try:
            _file_name = reqData['name']
            _data = reqData['data']
            _dir = os.path.dirname(_file_name)
            if not os.path.exists(_dir):
                _backupDir = None
                os.makedirs(_dir)

            if not os.path.exists(_file_name):
                _backupDir = None

            self.obl.backupFile(_file_name, _dir, _backupDir)

            f = open(str(_file_name), 'w+')
            f.write(_data)
            f.close()

            os.chmod(_file_name, _chmod)
            logger.info('SUCC: Put File, file=%s' % _file_name)
            return self.retOK(_file_name)

        except Exception, e:
            logger.exception(e)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, str(e))

    def _file_del(self, reqData):
        try:
            _type = reqData.get('type', None)
            _targets = reqData.get('targets', None)
            _backupDir = reqData.get('backup_dir', None)
            delList = []
            if str(_type).upper() == 'FILE':
                for target in _targets:
                    if os.path.isfile(target) and os.path.isabs(target):
                        self.obl.backupFile(target, os.path.dirname(target), _backupDir)
                        os.remove(target)
                        delList.append(target)
                    else:
                        logger.warning(' - Del File is not File or Abstract Path, file=%s' % target)
                        continue
            elif str(_type).upper() == 'DIR':
                for target in _targets:
                    if os.path.isdir(target) and os.path.isabs(target):
                        self.obl.backupFile(target, target, _backupDir)
                        shutil.rmtree(target)
                        delList.append(target)
                    else:
                        logger.warning(' - Del File is not Directory or Abstract Path, file=%s' % target)
                        continue
            else:
                return self.retError(obc.HTTP_BAD_REQUEST, 'Unknown Delete TargetType=%s' % (_type))

            logger.info('SUCC: Del Target, file=%s' % (delList))
            return self.retOK(delList)
        except Exception, e:
            logger.exception(e)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, e)

    def _file_del_exclude(self, reqData):
        try:
            _targetDir = reqData.get('target_dir', None)
            _excludeFile = reqData.get('exclude_file', None)
            _backupDir = reqData.get('backup_dir', None)

            if not os.path.isabs(_targetDir):
                logger.error('Fail to Delete File, TargetDir is not Abstract Dir, dir=%s' % (_targetDir))
                return self.retError(obc.HTTP_BAD_REQUEST, 'TargetDir is not Abstract Dir, dir=%s' % (_targetDir))

            fList = dircache.listdir(_targetDir)

            for exclude in _excludeFile:
                try:
                    fList.remove(os.path.basename(exclude))
                except ValueError, ve:
                    logger.warning(ve)

            delFileList = []
            for delFile in fList:
                if not delFile: continue

                backupFileName = os.path.join(_targetDir, delFile)
                if os.path.isfile(backupFileName):
                    self.obl.backupFile(backupFileName, _targetDir, _backupDir)
                    os.remove(backupFileName)
                    delFileList.append(backupFileName)

                logger.info('SUCC: Del Files, file=%s' % (delFileList))
            return self.retOK(delFileList)
        except Exception, e:
            logger.exception(e)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, e)

    def _zba_status_mon_file(self, reqData):
        ''' return : { zba_key_list: [1,2,3], template_list:[1,2,3] }    '''
        try:
            _plug_root_dir = obc.DIR_ZBXA_PLUGIN
            _zbac_root_dir = obc.DIR_ZBXA_KEY

            if type(reqData) == dict and reqData.has_key('plug_root_dir'):
                if reqData['plug_root_dir'] is None or str(reqData['plug_root_dir']).strip() == "":
                    logger.error(
                        "Fail to MON-FILE Status API, No PlugIn-Root Param, dir=%s" % str(reqData['plug_root_dir']))
                    return self.retError(obc.HTTP_BAD_REQUEST, "No PlugIn-Root Param, dir=%s" % str(reqData['plug_root_dir']))
                else:
                    _plug_root_dir = str(reqData['plug_root_dir']).strip()
            if type(reqData) == dict and reqData.has_key('zba_key_root_dir'):
                if reqData['zba_key_root_dir'] is None or str(reqData['zba_key_root_dir']).strip() == "":
                    logger.error(
                        "Fail to MON-FILE Status API, No ZBA-KEY-Root Param, dir=%s" % str(reqData['zba_key_root_dir']))
                    return self.retError(obc.HTTP_BAD_REQUEST, "No ZBA-KEY-Root Param, dir=%s" % str(reqData['zba_key_root_dir']))
                else:
                    _zbac_root_dir = str(reqData['zba_key_root_dir']).strip()

            _p_dir_list = []
            _z_file_list = []
            if os.path.isdir(_plug_root_dir):
                _p_dir_list = os.listdir(_plug_root_dir)
            else:
                logger.error("Fail to MON-FILE Status API, No Plugin-Directory, dir=%s" % str(_plug_root_dir))
                return self.retError(obc.HTTP_BAD_REQUEST, "No Plugin-Directory, dir=%s" % str(_plug_root_dir))
            if os.path.isdir(_zbac_root_dir):
                for (path, _dir, files) in os.walk(_zbac_root_dir):
                    if path == _zbac_root_dir:
                        _z_file_list += files
            else:
                logger.error("Fail to MON-FILE Status API, No ZB-Key-Directory, dir=%s" % str(_zbac_root_dir))
                return self.retError(obc.HTTP_BAD_REQUEST, "No ZB-Key-Directory, dir=%s" % str(_zbac_root_dir))

            _p_temp_list = []
            _z_temp_list = []
            for _p_dir in _p_dir_list:
                _path_plugin = os.path.join(_plug_root_dir, _p_dir)
                for (_path, _dir, files) in os.walk(_path_plugin):
                    if _path == _path_plugin:
                        for filename in files:
                            if str(filename).find(".pyc") < 1 or (
                                    str(filename).find(".py") > -1 or str(filename).find(".yaml") > -1 or str(
                                    filename).find(".sh") > -1):
                                _p_comp = str(_p_dir).split('-')
                                try:
                                    if not int(_p_comp[0]) in _p_temp_list:
                                        _p_temp_list.append(int(_p_comp[0]))
                                except Exception, e:
                                    logger.warning(
                                        " - SKIP to Get Plugin-Template Number, Plugin-Dir=%s" % str(_p_comp))
                                break
            for _z_file in _z_file_list:
                _z_comp = str(_z_file).split('-')
                try:
                    _z_temp_list.append(int(_z_comp[0]))
                except Exception, e:
                    logger.warning(" - SKIP to Get ZBA-Key-Template Number, ZBKEY-File=%s" % str(_z_file))

            _ret = {'zba_key_list': _z_temp_list, 'template_list': _p_temp_list}
            return _ret
        except Exception, e:
            logger.error("Fail to Get MonA-File Status, exc=%s" % str(e))
            logger.exception(e)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR , e)


    def _zba_restart(self):
        try:
            plugin = AxgatePlugin()
            _ret, _err = plugin.restart_service(obc.SVC_NAME_ZBXA)
            if not _ret:
                self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, _err)
            return self.retOK("zba restart")
        except Exception, e:
            logger.exception(e)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, e)


'''
'file_put': '/file/put',
'file_del' : '/file/del',
'file_del_exclude' : '/file/del/exclude',
'plugin_check' : '/zba/status/mon_file',
'zba_restart': '/zba/restart'
'''

def url( _oba_cfg ):
    url = [
        ('/file/put', Orchm2ObaRequest, dict(opCode=obc.OP_FILE_PUT, oba_cfg=_oba_cfg)),
        ('/file/del', Orchm2ObaRequest, dict(opCode=obc.OP_FILE_DEL, oba_cfg=_oba_cfg)),
        ('/file/del/exclude', Orchm2ObaRequest, dict(opCode=obc.OP_FILE_DEL_EXCLUDE, oba_cfg=_oba_cfg)),
        ('/zba/status/mon_file', Orchm2ObaRequest, dict(opCode=obc.OP_ZBA_STATUS_MON_FILE, oba_cfg=_oba_cfg)),
        ('/zba/restart', Orchm2ObaRequest, dict(opCode=obc.OP_ZBA_RESTART, oba_cfg=_oba_cfg))
    ]
    return url

