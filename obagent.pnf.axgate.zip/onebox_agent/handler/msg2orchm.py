# -*- coding: utf-8 -*-
from tornado.web import RequestHandler


class OrchmRespMsg(RequestHandler):
    def retOK(self, msg):
        return {'result': 'SC', 'response': msg}

    def retError(self, code, msg, req=None):
        if req == None:
            return {'result': 'FA', 'error': {'name': code, 'message': str(msg)}}
        else:
            return {'result': 'FA', 'error': {'name': code, 'message': str(msg), 'req': req}}


# NAME
# INVALID_DATA = 'Invalid Data'
# NO_DATA = 'No Data'
# EXCP = 'Exception'
# DB_FAIL = 'DB Operation Fail'
# HTTP_RES_ERR = 'HTTP Response Error'
# ZBAPI_ERR = 'Zabbix Server Manager API Error'
# UNKNOWN_REQ = 'Unknown Request'
# SHELL_FAIL = 'Shell EXEC FAIL'
# DUPLICATE_DATA = 'Duplicated Data'
# NO_IMPL = 'Not Implement'
# NMS_OP_FAIL = "NMS Operation Fail"

