#!/usr/bin/python
#-*- coding: utf-8 -*-

import os, json, shutil, datetime
from time import sleep
from onebox_agent.pnf.axgate_plugin import AxgatePlugin
from onebox_agent.handler.msg2orchf import OrchfRespMsg
from onebox_agent.data import ob_constant as obc
from onebox_agent.util.ob_lib import OB_LIB as obl
from onebox_agent.util.onebox_manager import BackupRestoreStateManager
from onebox_agent.util import onebox_manager
from onebox_agent.data.ob_info import ONEBOX_INFO
from onebox_agent.func.ob_backup import BackupWorker, RestoreWoker

import logging
logger = logging.getLogger(obc.OBA_NAME)


class Orchf2ObaRequest(OrchfRespMsg):

    def initialize(self, opCode, oba_cfg):
        self._opCode = opCode
        self._oba_cfg = oba_cfg
        self._obl = obl(logger)
        self._plugin = AxgatePlugin()
        # self._ol = _data[oc.OTAG_LIB_OB]
        # self._ob_info = _data[oc.OTAG_OBA_INFO]

    # todo complte get, post mothods
    def post(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req : %s, body=%s" % (str(self._opCode), str(reqdata)[:200]))

        if reqdata:
            reqdata = json.loads(reqdata)

        if self._opCode == obc.OP_BACKUP:
            resp = self._backup()
        elif self._opCode == obc.OP_RESTORE:
            resp = self._restore(reqdata)
        elif self._opCode == obc.OP_REBOOT:
            resp = self._reboot_pnf()
        else:
            resp = self.retError(obc.BAD_REQUEST, "Unknown Post URL or Operation, opcode=%s" % str(self._opCode))

        self.write(resp)
        self.flush()

    def get(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req : %s, body=%s" % (str(self._opCode), str(reqdata)[:200]))

        if self._opCode == obc.OP_NOTI_OBINFO:
            resp = self._noti_obinfo()
        elif self._opCode == obc.OP_VERSION:
            resp = self._show_pnf_version()
        elif self._opCode == obc.OP_WAN_MONITOR:
            resp = self._wan_monitor()
        elif self._opCode == obc.OP_RESTORE_PROGRESS:
            resp = self._get_restore_progress()
        else:
            resp = self.retError(obc.BAD_REQUEST, "Unknown GET URL or Operation, opcode=%s" % str(self._opCode))

        self.write(resp)
        self.flush()

    def _noti_obinfo(self):
        '''
        return :
            OK= retOK
            error= error:description
        '''
        try:
            _ob_noti_info = ONEBOX_INFO(self._oba_cfg.m_axgate_info_path, logger).load()
            if _ob_noti_info is not None:
                return self.retOK(_ob_noti_info)
            else:
                raise Exception('Failed to load onebox-info. Invalid /tmp/axgate-info')
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s" % (self._opCode, str(e)))
            logger.exception(e)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, str(e))

    def _show_pnf_version(self):
        '''
        return :
            OK, PNF(OS) version
            FAIL, error_code, error_desc
        '''
        try:
            _version = self._plugin.show_version()
            if _version is not None:
                return self.retOK({'version':_version})
            else:
                raise Exception("pulgin.show_version is None")
        except Exception, e:
            logger.error("Fail to get axgate version. %s" % str(e))
            logger.exception(e)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, str(e))

    def _show_oba_version(self):
        '''
        return :
            OK, OBA version
            FAIL, error_code, error_desc
        '''
        try:
            return self.retOK({'version': obc.OBA_VERSION})

        except Exception, e:
            logger.error("Fail to get axgate version. %s" % str(e))
            logger.exception(e)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, str(e))

    def _wan_monitor(self):
        '''
        return :
            "result”: “OK”,“mode”: “host”
           “result”: “FAIL”, “error_code”: “4XX”, “error_desc”: <string>
        '''
        return self.retOK({'mode': 'host'})

    def _get_restore_progress(self, retries=3, retry_delay=1):
        '''
        return :
            "result”: “OK”,“status”: “DONE | DOING | ERROR", "message": ""
           “result”: “FAIL”, “error_code”: “4XX”, “error_desc”: <string>
        '''
        _err = None
        tid = self.get_argument('transaction_id', '')
        if tid != "":
            for retry in range(1, retries + 1):
                if retry > 1:
                    sleep(retry_delay)
                try:
                    stateMgr = BackupRestoreStateManager()
                    state = stateMgr.get_state()
                    if state is not None:
                        return self.retOK(state)
                    else:
                        raise Exception("Error occurs in stateMgr.get_state()")
                except Exception, e:
                    _err = "Failed to get restore progress [%d/%d]" % (retry, retries)
                    logger.exception(obc.HTTP_INTERNAL_SERVER_ERROR, e)

            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, _err)

    def _reboot_pnf(self):
        '''
        return :
            OK,
            FAIL, error_code, error_desc
        '''
        try:
            _ret, _err = self._plugin.reboot()
            if not _ret:
                raise Exception(_err)
            return self.retOK()
        except Exception, e:
            logger.error("Failed to reboot force. %s" % str(e))
            logger.exception(e)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, str(e))

    def _backup(self):
        _op = obc.OP_BACKUP
        try:
            trans_id = onebox_manager.new_tid()
            backupState = BackupRestoreStateManager(_op, trans_id)

            _chk = backupState.chk_inprogress()
            if _chk != None:
                _res = "Other Request IN-Progress, status=%s" % str(_chk)
                logger.info("Fail to %s, %s" % (self._opCode, _res))
                backupState.set_state(obc.STATE_DONE)
                return self.retError(obc.HTTP_BAD_REQUEST, _res)

            backupState.set_state(obc.STATE_DOING)

            # archive files and copy them to backup location (local + remote)
            _ob_id = self._oba_cfg.m_onebox_id
            # _pnf_plugin = AxgatePlugin()
            today = datetime.datetime.now()
            _date = today.strftime('%y%m%d-%H%M')
            local_location = os.path.join(obc.DIR_BACKUP_ROOT % str(_date), obc.FILE_BACKUP_LOCAL % str(_date))
            remote_location = obc.FILE_BACKUP_REMOTE % (_ob_id, _date)

            _work = BackupWorker(_ob_id, self._plugin, _date, local_location, remote_location)
            # _work.start()
            _ret, _info, _backkup_file = _work.backup()

            if _ret is not True:
                raise Exception(_info)

            remote_file = os.path.join(remote_location, os.path.basename(local_location))
            _res = {
                'local_location': local_location,
                'remote_location': remote_file,
                'backup_file': _backkup_file,
                'backup_data': _info
                }
            logger.info("SUCC: %s , resp=%s...." % (self._opCode, json.dumps(_res)[:50]))
            logger.debug("response= %s" % json.dumps(_res)[:300])
            backupState.set_state(obc.STATE_DONE)
            return self.retOK(_res)
        except KeyError, e:
            logger.error("Fail to %s, No Key, exc=%s" % (self._opCode, str(e)))
            logger.exception(e)
            backupState.set_state(obc.STATE_ERROR)
            return self.retError(obc.HTTP_BAD_REQUEST, "KeyError: %s" % str(e))
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s" % (self._opCode, str(e)))
            logger.exception(e)
            backupState.set_state(obc.STATE_ERROR)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, e)

    def _restore(self, reqData):
        _op = obc.OP_RESTORE

        try:
            trans_id = onebox_manager.new_tid()
            restoreState = BackupRestoreStateManager(_op, trans_id)

            _chk = restoreState.chk_inprogress()
            if _chk != None:
                _res = "Other Request IN-Progress, status=%s" % str(_chk)
                logger.info("Fail to %s, %s" % (self._opCode, _res))
                restoreState.set_state(obc.STATE_DONE)
                return self.retError(obc.HTTP_BAD_REQUEST, _res)

            restoreState.set_state(obc.STATE_DOING, curStep=1, totalStep=8)

            local_location = reqData['local_location']
            backup_data = reqData['backup_file']

            _worker = RestoreWoker(trans_id, restoreState, self._plugin, local_location, backup_data)
            _worker.start()

            _res = {'transaction_id': trans_id, 'status': obc.STATE_DOING, 'message': "Restore requested",
                    'current_step': 1, 'total_step': 8}

            logger.info("SUCC: %s, tid=%s" % (self._opCode, trans_id))
            return self.retOK(_res)

        except KeyError, e:
            logger.error("Fail to %s, No Key, exc=%s" % (self._opCode, str(e)))
            logger.exception(e)
            restoreState.set_state(obc.STATE_ERROR)
            return self.retError(obc.HTTP_BAD_REQUEST, "KeyError: %s" % str(e))
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s" % (self._opCode, str(e)))
            logger.exception(e)
            restoreState.set_state(obc.STATE_ERROR)
            return self.retError(obc.HTTP_INTERNAL_SERVER_ERROR, e)

url_base = '/v1'

def url( _oba_cfg ):
    url = [
        ('%s/onebox_info' % url_base,   Orchf2ObaRequest, dict(opCode=obc.OP_NOTI_OBINFO, oba_cfg=_oba_cfg)),
        ('%s/backup' % url_base,        Orchf2ObaRequest, dict(opCode=obc.OP_BACKUP, oba_cfg=_oba_cfg)),
        ('%s/restore' % url_base,       Orchf2ObaRequest, dict(opCode=obc.OP_RESTORE, oba_cfg=_oba_cfg)),
        ('%s/restore/progress' % url_base, Orchf2ObaRequest, dict(opCode=obc.OP_RESTORE_PROGRESS, oba_cfg=_oba_cfg)),
        ('%s/reboot' % url_base, Orchf2ObaRequest, dict(opCode=obc.OP_REBOOT, oba_cfg=_oba_cfg)),
        ('%s/version' % url_base, Orchf2ObaRequest, dict(opCode=obc.OP_VERSION, oba_cfg=_oba_cfg)),
        ('%s/wanmonitor' % url_base,    Orchf2ObaRequest, dict(opCode=obc.OP_WAN_MONITOR, oba_cfg=_oba_cfg))
    ]
    return url

