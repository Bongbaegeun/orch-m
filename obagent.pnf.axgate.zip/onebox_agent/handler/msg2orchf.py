# -*- coding: utf-8 -*-

import datetime
from tornado.web import RequestHandler
import onebox_agent.data.ob_constant as obc

def new_tid():
    today = datetime.datetime.now()
    return today.strftime('%y%m%d%H%M')


class OrchfRespMsg(RequestHandler):

    def retOK(self, jsonMsg=None):
        retok = {'result': 'OK'}
        if jsonMsg is not None and type(jsonMsg) is dict:
            retok = {key: value for (key, value) in (jsonMsg.items() + retok.items())}
        return retok

    def retError(self, err_code = obc.HTTP_INTERNAL_SERVER_ERROR, error_desc = ""):
        self.set_status(err_code)
        return {'result': 'FAIL', 'error_code': err_code, 'error_desc': str(error_desc)}


