#-*- coding: utf-8 -*-

import threading
from time import sleep
import inotify.adapters
import onebox_agent.data.ob_constant as obc
import onebox_agent.util.rest_api as rest
from onebox_agent.data.ob_info import ONEBOX_INFO
from onebox_agent.pnf.axgate_plugin import AxgatePlugin
from onebox_agent.func.update_zbxa_znmsc import ZBXA_CONF
from onebox_agent.func.update_zbxa_znmsc import ZNMSC_CONF

import logging
logger = logging.getLogger(obc.OBA_NAME)
_TITLE = "Report to orch-f ob-info changed immediately"

class WatchAxgateInfo(threading.Thread):
    def __init__(self, oba_conf):
        threading.Thread.__init__(self)
        self.oba_conf = oba_conf
        self.axgate_info_current = None
        self.axgate_info_path = oba_conf.m_axgate_info_path
        self.report_url = oba_conf.m_orchf_url_ob_info
        self.report_ip = oba_conf.m_orchf_ip
        self.report_port = oba_conf.m_orchf_port
        self.plugin = AxgatePlugin()

    def _update_zbxa_znmsc(self, onebox_id):
        # todo: update zbx, znms conf if onebox_id changed
        try:
            if onebox_id == obc.DEF_OB_ID:
                logger.info(' stop process zabbix, znmsc. ')
                self.plugin.set_zbxa_znmsc(always_on=False)
                return None

            conf_zbxa = ZBXA_CONF(onebox_id, self.plugin)
            _ret_zbxa = conf_zbxa.update()
            if _ret_zbxa is not None:
                raise Exception('Failed to update zabbix agent conf. %s' % _ret_zbxa)

            conf_znms = ZNMSC_CONF(onebox_id, self.plugin)
            _ret_znms = conf_znms.update(only_id=True)
            if _ret_znms is not None:
                raise Exception('Failed to update znmsc conf. %s' % _ret_zbxa)

            logger.info(' restart process zabbix, znmsc. ')
            self.plugin.set_zbxa_znmsc(always_on=True)

            return None
        except Exception, e:
            return str(e)

    def _send_ob_info(self, ob_info, url, retries=3, retry_delay=3):
        _header = obc.HTTP_HEADER
        for retry in range(1, retries + 1):
            try:
                _ret, _ecode, _resp = rest.sendReq(_header, url, 'POST', ob_info)
                logger.debug("send body= %s" % str(ob_info))
                logger.debug("return={}, {}, {}".format(_ret, _ecode, _resp))
                if _ret is False or _ecode is not 200 and _resp is None:
                    raise Exception(_resp)
                return
            except Exception, e:
                logger.error(str(e))
                sleep(retry_delay)

    def run(self):
        logger.info("-------[[ START- \"%s\" ]]--------" % _TITLE)
        try:
            self.axgate_info_current = ONEBOX_INFO(self.axgate_info_path, logger).load()

            i = inotify.adapters.Inotify()
            i.add_watch(self.axgate_info_path)

            for event in i.event_gen(yield_nones=False):
                (_, type_names, path, filename) = event
                # event_msg = "PATH=[{}] FILENAME=[{}] EVENT_TYPES={}".format(path, filename, type_names)
                # print(event_msg)
                # logger.info(event_msg)

                if str(type_names).find('IN_CLOSE_WRITE') > -1:
                    try:
                        axgate_info_new = ONEBOX_INFO(self.axgate_info_path, logger).load()

                        if axgate_info_new is None:
                            logger.error("Failed to load modified ob_info!!! ")
                        else:
                            if self.axgate_info_current == axgate_info_new:
                                # skip update, send to orchf
                                logger.info("ob_info Not modified!!! skip send to orchf")
                            else:
                                # 1. update current ob info
                                self.oba_conf.update_from_axgate_info(self.axgate_info_path, logger)

                                # 2. update zbxa, znmsc conf
                                ob_id_cur = self.axgate_info_current['onebox_id']
                                ob_id_new = axgate_info_new['onebox_id']
                                if not ob_id_new:
                                    ob_id_new = obc.DEF_OB_ID

                                if ob_id_cur != ob_id_new:
                                    logger.info('onebox_id is changed. %s > %s' % (ob_id_cur, ob_id_new))
                                    _upd_ret = self._update_zbxa_znmsc(ob_id_new)
                                    if _upd_ret:
                                        raise Exception(_upd_ret)

                                # 3. send to orchf
                                if ob_id_new is not obc.DEF_OB_ID:
                                    logger.info("Start to send new obinfo to orch-f ")
                                    _url = self.report_url % (self.report_ip, self.report_port, ob_id_new)
                                    self._send_ob_info(axgate_info_new, _url)

                                # 4. save new ob info as cur
                                self.axgate_info_current = axgate_info_new
                    except Exception, loop_exc:
                        logger.exception(loop_exc)
        except Exception, e:
            logger.exception(e)

