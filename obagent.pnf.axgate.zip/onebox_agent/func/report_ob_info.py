#!/usr/bin/python
#-*- coding: utf-8 -*-

import threading
from time import sleep

from onebox_agent.data import ob_constant as obc
from onebox_agent.data.ob_info import ONEBOX_INFO
from onebox_agent.util import rest_api as api

import logging
logger = logging.getLogger(obc.OBA_NAME)
_TITLE = "Report ob-info to orch-f periodically"


class ReportObinfo(threading.Thread):
    def __init__(self, oba_conf):
        threading.Thread.__init__(self)
        self._oba_cfg = oba_conf

    def run(self):
        logger.info("-------[[ START- \"%s\" ]]--------" % _TITLE)

        _header = obc.HTTP_HEADER
        _interval = self._oba_cfg.m_report_interval
        _first_noti = True

        while True:
            try:
                _body = ONEBOX_INFO(self._oba_cfg.m_axgate_info_path, logger).load(first_noti=_first_noti)
                if _body is None:
                    raise Exception('Failed to load onebox-info. Invalid /tmp/axgate-info')

                _ob_id = _body['onebox_id']

                _url = self._oba_cfg.m_orchf_url_ob_info % (self._oba_cfg.m_orchf_ip, self._oba_cfg.m_orchf_port, _ob_id)

                if _body is not None:
                    _retries = 3
                    _retry_delay = 3
                    for retry in range(1, _retries + 1):
                        if retry > 1:
                            sleep(_retry_delay)
                        _ret, _ecode, _res = api.sendReq(_header, _url, 'POST', _body)
                        logger.debug("send body= %s" % str(_body))
                        logger.debug("return={}, {}, {}".format(_ret, _ecode, _res))
                        if _ret is True and _ecode is 200:
                            if _first_noti: _first_noti = False
                            break
                else:
                    logger.error("Failed to load ob_info for send to orchf")
            except Exception, e:
                logger.exception(e)

            sleep(_interval)

