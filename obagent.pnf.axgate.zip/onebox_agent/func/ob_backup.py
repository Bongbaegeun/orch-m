#-*- coding: utf-8 -*-

import os, shutil, threading
import base64
# from onebox_agent.util.onebox_manager import BackupRestoreStateManager
import onebox_agent.data.ob_constant as obc
from onebox_agent.util.ob_lib import OB_LIB

import logging
logger = logging.getLogger(obc.OBA_NAME)


class BackupWorker:
    def __init__(self, ob_id, plugin, date, local_path, remote_path):
        self._ob_id = ob_id
        self._date = date
        self._local_path = local_path
        self._remote_path = remote_path
        self._ol = OB_LIB(logger)
        self._plugin = plugin
        return

    def _del_tmp_backup(self):
        try:
            self._ol.delDir(obc.DIR_OBA_TMP + "/backup")
        except Exception, e:
            logger.Error(e)

    def _tar_backup_files(self, pnf_bak_file):
        _pnf_bak_file = pnf_bak_file
        _oba_bak_files = obc.BACKUP_FILE_OBA
        _zbxa_bak_files = obc.BACKUP_FILE_ZBXA
        _zbxa_bak_dirs = obc.BACKUP_DIR_ZBXA
        _znmsc_bak_files = obc.BACKUP_FILE_ZNMSC

        try:
            backup_root = obc.DIR_BACKUP_ROOT % str(self._date)

            dst = "%s%s" % (backup_root, _pnf_bak_file)
            self._ol.copyFile(_pnf_bak_file, dst)
            logger.info("copy file : %s to %s" % (_pnf_bak_file, dst))

            for src in _oba_bak_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)
                logger.info("copy file : %s to %s" % (src, dst))

            for src in _zbxa_bak_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)
                logger.info("copy file : %s to %s" % (src, dst))

            for src in _zbxa_bak_dirs:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyDir(src, dst)
                logger.info("copy file : %s to %s" % (src, dst))

            for src in _znmsc_bak_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)
                logger.info("copy file : %s to %s" % (src, dst))

            self._ol.tar(self._local_path, backup_root)
            logger.info(" tar bak file : %s, src = %s" % (self._local_path, backup_root))
            return True, None

        except Exception, e:
            _err = "Fail to Create Backup Archive, Unknown Error, exc=%s" % str(e)
            logger.error(_err)
            return False, _err

    def backup(self):
        _pnf_bak_file = None
        try:
            # backup & download axgate pnf config
            _pnf_bak_file = self._plugin.backup(retries=3, retry_delay=3)

            if _pnf_bak_file is None:
                raise Exception(" - Failed to download Axgate backup file")

            # tar backup files to local path
            logger.info(" - start tar bak files")
            _ret, _err = self._tar_backup_files(_pnf_bak_file)
            if not _ret:
                raise Exception(_err)

            # send backup_data:<pnf_conf>
            with open(_pnf_bak_file, 'r') as f:
                axgate_backup_data = f.read()

            with open(self._local_path, 'r') as fb:
                full_backup_data = fb.read()
                backup_file = base64.b64encode(full_backup_data)

            # todo: done. skip. del backup tmp files. _axgate_bak_file, confs
            # self._del_tmp_backup()
            return True, axgate_backup_data, backup_file
        except Exception, e:
            _err = "Failed to execute backup: %s" % e
            logger.error(_err)
            return False, _err, None


class RestoreWoker(threading.Thread):
    def __init__(self, tid, restore_state, plugin, local_loc, backup_enc):
        self._tid = tid
        # self._remote_loc = remote_loc
        self._local_loc = local_loc
        self._backup_enc = backup_enc
        self._untar_loc = obc.DIR_RESTORE_ROOT
        self._pnf_plugin = plugin
        self._ol = OB_LIB(logger)
        self._statemgr = restore_state
        threading.Thread.__init__(self)

    # def _update_restore_state(self, state):
    #     logger.info(" - Update Restore-State: tid=%s, state=%s" % (self._tid, state))
    #     self._statemgr.set_state(obc.OP_RESTORE, state)

    def _restore_files(self, _root_dir, service_files, service_dirs=[]):
        try:
            for _file in service_files:
                src = os.path.normpath(_root_dir + "/" + _file)
                self._ol.copyFile(src, _file)
            logger.info("   Copy Service File, file=%s" % str(service_files))

            for _dir in service_dirs:
                if os.path.exists(_dir):
                    shutil.rmtree(_dir)
                src = os.path.normpath(_root_dir + "/" + _dir)
                self._ol.copyDir(src, _dir)
            logger.info("   Copy Service Dir, dir=%s" % str(service_dirs))
            return True, None
        except Exception, e:
            _err = "Fail to Restore Services, exc=%s" % str(e)
            logger.error(_err)
            return False, _err

    def run(self):
        _curStep = 0
        _totalStep = 6
        try:
            # 1. read n write tar backup file. > untar data
            if not os.path.exists(self._local_loc):
                _full_backup_data = base64.b64decode(self._backup_enc)

                with open(self._local_loc, 'wr') as f:
                    f.write(_full_backup_data)

            if not self._ol.untar(self._local_loc, self._untar_loc):
                logger.error("Fail to Restore, Backup File UnTar Error, tarfile=%s, dst=%s"
                                   % (self._local_loc, self._untar_loc))
                return

            _msg = "restore check files: %s" % self._local_loc
            self._statemgr.set_state(obc.STATE_DOING, _curStep+1, _totalStep, _msg)
            logger.info(" - Succ untar backup file, file=%s, dir=%s" % (self._local_loc, self._untar_loc))

            # 2. restore backup files
            # todo: 2.1. axgate os
            # _restore_target_root = self._untar_loc + axgate_bak_file
            # _restore_target_root = self._untar_loc + "/mnt/.../190221-1535/mnt/flash/data/onebox/onebox-agent/tmp/AXGATE_INSOFT_2019-02-13_172254_ZebOS.conf"
            # _restore_target_root = self._untar_loc + "/mnt/.../190221-1535/mnt/flash/data/onebox/onebox-agent/tmp/axgate_insoft_bak.conf"
            _restore_base_dir = self._untar_loc + os.path.dirname(self._local_loc)

            _pnf_restore_file = _restore_base_dir + obc.FILE_BACKUP_AXGATE
            _msg = "restore pnf = " + _pnf_restore_file
            logger.info(_msg)
            self._statemgr.set_state(obc.STATE_DOING, _curStep + 1, _totalStep, _msg)
            _ret, _err = self._pnf_plugin.restore(_pnf_restore_file)
            if not _ret:
                raise Exception(_err)
            else:
                logger.info("restore pnf done ------ ")

            # 2.2. oba
            _msg = "restore oba = %s%s" % (_restore_base_dir, obc.BACKUP_FILE_OBA)
            logger.info(_msg)
            self._statemgr.set_state(obc.STATE_DOING, _curStep + 1, _totalStep, _msg)
            if not self._restore_files(_restore_base_dir, obc.BACKUP_FILE_OBA):
                logger.warn(" - Fail to Restore oba ")
            logger.info("restore oba done ------ ")

            # 2.3. zbxa
            _msg = "restore zbxa = %s%s " % (_restore_base_dir, obc.BACKUP_FILE_ZBXA)
            logger.info(_msg)
            self._statemgr.set_state(obc.STATE_DOING, _curStep + 1, _totalStep, _msg)
            if not self._restore_files(_restore_base_dir, obc.BACKUP_FILE_ZBXA, obc.BACKUP_DIR_ZBXA):
                logger.warn(" - Fail to Restore zbxa")
            _ret, _err = self._pnf_plugin.restart_service(obc.SVC_NAME_ZBXA)
            if not _ret:
                raise Exception(_err)
            logger.info("restore zbxa done ------ ")

            # 2.4. znmsc
            # todo : skip. wait, till znmsc, aos cpm ready
            # _znmsc_restore_file = _restore_base_dir + obc.BACKUP_FILE_ZNMSC
            # _msg = "restore znmsc = " + _znmsc_restore_file
            logger.info(_msg)
            if not self._restore_files(_restore_base_dir, obc.BACKUP_FILE_ZNMSC):
                logger.warn(" - Fail to Recovery, znmsc restore error")
            _ret, _err = self._pnf_plugin.restart_service(obc.SVC_NAME_ZNMSC)
            if _ret:
                self._statemgr.set_state(obc.STATE_DOING, _curStep + 1, _totalStep, _msg)
            else:
                raise Exception(_err)
            logger.info("restore znmsc done ------ ")

            self._statemgr.set_state(obc.STATE_DONE, _totalStep, _totalStep, "restore completed")
        except Exception, e:
            logger.exception(e)
            self._statemgr.set_state(obc.STATE_ERROR, msg=str(e))

