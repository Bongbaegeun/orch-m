#!/usr/bin/python
#-*- coding: utf-8 -*-

from time import sleep
import ruamel.yaml, json
from onebox_agent.data import ob_constant as obc

import logging
logger = logging.getLogger(obc.OBA_NAME)


class ZBXA_CONF():
    def __init__(self, ob_id, plugin):
        self.plugin = plugin
        self.ob_id = ob_id
        self.conf_path = obc.FILE_ZBAX_CONF

    def update(self):
        try:
            new_host_name = 'Hostname = %s' % self.ob_id

            # find Hostname = AXPNF.OB1 and replace
            with open(self.conf_path, "r") as fr:
                zbx_conf = fr.read()

            with open(self.conf_path, "r") as f:
                lines = f.readlines()
                for line in lines:
                    if line.find('Hostname =') > -1:
                        old_host_name = line.strip()

            if old_host_name is not new_host_name:
                zbx_conf_new = zbx_conf.replace(old_host_name, new_host_name)
                with open(self.conf_path, "w") as fw:
                    fw.write(zbx_conf_new)

            # if restart:
            #     _ret, _err = self.plugin.restart_service(obc.SVC_NAME_ZBXA)
            #     if not _ret:
            #         raise Exception(_err)
            return None
        except Exception, e:
            return str(e)


class ZNMSC_CONF():
    def __init__(self, ob_id, plugin):
        self.plugin = plugin
        self.ob_id = ob_id
        self.bin_path = obc.FILE_ZNMSC_BIN
        self.oba_conf = obc.FILE_OBA_CONF

    def update(self, only_id=False):
        try:
            import commands as cmd
            cmd_set_obid = """ %s -uid %s """ % (self.bin_path, self.ob_id)
            status, ret = cmd.getstatusoutput(cmd_set_obid)

            if status is not 0:
                raise Exception("Failed to update znmsc.  %s" % ret)

            if not only_id:
                with open(self.oba_conf, "r") as f:
                    ob_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
                    znms_ip = ob_cfg['nms_ip']
                    znms_ports = ob_cfg['nms_port']

                cmd_set_addr = """ %s -mgr1 %s """ % (self.bin_path, znms_ip)
                for znms_port in znms_ports:
                    cmd_set_addr += """ %s """ % str(znms_port)

                status, ret = cmd.getstatusoutput(cmd_set_addr)
                if status is not 0:
                    raise Exception("Failed to update znmsc.  %s" % ret)

            # if restart:
            #     _ret, _err = self.plugin.restart_service(obc.SVC_NAME_ZNMSC)
            #     if not _ret:
            #         raise Exception(_err)
            return None
        except Exception, e:
            return str(e)

