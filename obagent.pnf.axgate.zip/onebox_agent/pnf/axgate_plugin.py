# -*- coding: utf-8 -*-

import urllib
from time import sleep
from onebox_agent.util import rest_api as api
import onebox_agent.data.ob_constant as obc
import logging
logger = logging.getLogger(obc.OBA_NAME)

SESSION_ID = None
HEADER = {"accept": "*/*", "content-Type": "application/x-www-form-urlencoded", "accept-charset": "utf-8"}
DEF_IP = "0.0.0.0"      #"127.0.0.1"
DEF_ID = "axroot"
DEF_PASS = "smflaqhNo1@"
# DEF_PASS = "Axgate12#$"
DEF_PORT = int(443)


class AxgatePlugin:
    def __init__(self):
        self._address = DEF_IP
        self._username = DEF_ID
        self._password = DEF_PASS

    def show_version(self, sid=None, retries=3, retry_delay=3):
        _version = None
        global SESSION_ID

        # if sid is None or not sid:
        #     logger.warn("No valid SESSION ID")
        #     return None

        for retry in range(1, retries + 1):
            if retry > 1:
                sleep(retry_delay)

            try:
                # curl --request POST \
                # --url "https://{address}:{port}/restrict/exec.cgi" \
                # --header "accept-charset: utf-8" \
                # --header "content-type: application/x-www-form-urlencoded" \
                # --header "Cookie: SessionID={SessionID}" \
                # --data "cmd=show version" -k -vvv

                if sid is not None:
                    HEADER["cookie"] = "SessionID=%s" % sid
                else:
                    ret = self.login()
                    if ret is None:
                        raise Exception("Can not Login to Axagte!!! ")
                    HEADER["cookie"] = "SessionID=%s" % SESSION_ID

                _url = str("https://%s:443/restrict/exec.cgi" % self._address)
                _header = HEADER
                _body = str("cmd=show version")

                _ret, _ecode, _resp = api.sendReq(_header, _url, 'POST', _body)

                if _ret is False or _ecode is not 200 and _resp is None:
                    return None

                result = int()
                rows = str(_resp).splitlines()
                for offset in range(0, len(rows)):
                    columns = rows[offset].split(":")
                    if len(columns) is not 2:
                        continue

                    if columns[0] == "result":
                        result = int(columns[1])
                        continue

                    if columns[0] == "version":
                        _version = columns[1]

                if result is not 1:
                    return None

                return _version
            except Exception as _exc:
                logger.exception("Failed to show version []....%s" % _exc)
        return None

    def login(self, retries=10, retry_delay=3):
        sid = None
        global SESSION_ID

        try:
            if SESSION_ID:
                _axgate_version = self.show_version(SESSION_ID)

                if _axgate_version:
                    logger.debug("Valid SESSION ID: '%s'" % str(SESSION_ID))
                    return SESSION_ID
        except Exception, e:
            self.logger.debug("Exception in check SESSION_ID: %s" %str(e))
            pass

        for retry in range(1, retries + 1):
            if retry > 1:   sleep(retry_delay)
            try:
                _url = str("https://%s:443/login.cgi" % self._address)
                _header = HEADER
                _body = str("username=%s&password=%s&desc=VNF" % (self._username, self._password))

                _ret, _ecode, _resp = api.sendReq(_header, _url, 'POST', _body, returnHeader=True)

                if _ret is True and _ecode == 200 and _resp is not None:
                    resp_headers = _resp['header']
                    resp_body = _resp['body']

                    results = str(resp_body).split(":")
                    if len(results) is not 2 or results[0] != "result":
                        raise Exception("invalid result = %s" % results)

                    if results[1] is 0:
                        raise Exception("invalid result = %s" % str(results[1]))

                    cookies = resp_headers.get_list("Set-Cookie")
                    for offset in range(0, len(cookies)):
                        if int(str(cookies[offset]).find("SessionID=")) > -1:
                            sid = cookies[offset][len(str("SessionID=")):]
                            break
                if not sid or len(sid) < 30:
                    raise Exception("invalid sid = %s" % sid)

                SESSION_ID = sid
                logger.debug("Succeed: AxGate Login: SessionID[%s]" % sid)
                return sid
            except Exception as _exc:
                sid = None
                logger.error("Fail to login axgate [%d/%d]: %s" % (retry, retries, _exc))
        return None


    def backup(self, retries=10, retry_delay=3):
        # 1. request axgate backup
        # curl -k -vX POST https://192.168.254.1:443/restrict/exec.cgi
        # -H "Content-type:application/x-www-form-urlencoded" - H "accept-charset:utf-8" \
        # -b "SessionID=22A56127563272844E4697012EA73CD7" \
        # -d 'cmd=backup config startup-config end'
        # >> message=AXGATE_AXGATE_vUTM_2018-08-ZebOS.conf
        #
        # 2. save backup as input filename
        # curl -k -b "SessionID=22A56127563272844E4697012EA73CD7" \
        # - H "Content-type:application/x-www-form-urlencoded" - H "accept-charset:utf-8" \
        # -vX POST https://192.168.254.1:443//restrict/downloadcfg.cgi
        # --data "filename=%s" -o %s' % (backup_file_name, working_dir + "/" + backup_file_name)

        global SESSION_ID
        for retry in range(1, retries + 1):
            if retry > 1:   sleep(retry_delay)
            _download_path = None
            _filename = None

            try:
                ret = self.login()
                if ret is None:
                    raise Exception("Can not Login to Axagte!!! ")

                _url = str("https://%s:443/restrict/exec.cgi" % self._address)
                HEADER["cookie"] = "SessionID=%s" % SESSION_ID
                _header = HEADER
                _body = "cmd=backup config startup-config"

                _ret, _ecode, _resp = api.sendReq(_header, _url, 'POST', _body)

                rows = str(_resp).splitlines()
                for offset in range(0, len(rows)):
                    columns = rows[offset].split(":")
                    if len(columns) is not 2:
                        continue

                    if columns[0] == "message":
                        _filename = str(columns[1])
                        if _filename is None or str(_filename).find('.conf') < 0:
                            raise Exception("Axgate backup file is not correct. %s" % _filename)

                if _ret is True and _ecode == 200 and _resp is not None:
                    # resp_headers = _resp['header']
                    # resp_body = _resp['body']
                    _url = str("https://%s:443/restrict/downloadcfg.cgi" % self._address)
                    _body = "filename=%s" % _filename

                    _ret, _ecode, _resp = api.sendReq(_header, _url, 'POST', _body)

                    _download_path = obc.FILE_BACKUP_AXGATE

                    if _ret is True and _ecode == 200 and _resp is not None:
                        with open(_download_path, 'w') as f:
                            f.write(_resp)
                        return _download_path

            except Exception, _exc:
                logger.error("Failed to backup %d / %d" % (retry, retries))
                logger.exception(_exc)

        logger.error("At Last Failed to backup axgate. return False")
        return None

    def restore(self, filename, retries=10, retry_delay=3):
        # curl -k -v -H "Content-type: multipart/form-data" \
        # - b "SessionID=20F052042F7A136E405541C91C0E0DCD" \
        # https://0.0.0.0:443/restrict/uploadcfg.cgi \
        # - F filename=@/var/onebox/backup/vnf/AXGATE_AXGATE_vUTM_2019-02-ZebOS.conf
        # result:1
        # message:none
        global SESSION_ID
        for retry in range(1, retries + 1):
            if retry > 1:
                sleep(retry_delay)

            try:
                ret = self.login()
                if ret is None:
                    raise Exception("Failed to Axagte Login!!! ")

                # start restore axgate from backup file
                __req_format = 'curl -k -v -H "Content-type: multipart/form-data" '
                __req_format += '-b "SessionID=%s" https://0.0.0.0:443/restrict/uploadcfg.cgi -F filename=@%s'

                # _req_cmd = __req_format % (self._address, SESSION_ID, filename)
                _req_cmd = __req_format % (SESSION_ID, filename)
                logger.debug(_req_cmd)

                import commands as cmd
                status, ret = cmd.getstatusoutput(_req_cmd)

                if status is not 0:
                    raise Exception("Failed to restore axgate :  %s" % ret)

                logger.debug(ret)
                if ret is not None:
                    rows = str(ret).splitlines()
                    for offset in range(0, len(rows)):
                        columns = rows[offset].split(":")
                        if len(columns) is not 2:
                            continue

                        if columns[0] == "result":
                            _result = str(columns[1])
                            if _result is None or _result is not "1":
                                raise Exception("Failed to restore axgate :  %s" % ret)

                # start save restored data
                _url = str("https://%s:443/restrict/exec.cgi" % self._address)
                HEADER["cookie"] = "SessionID=%s" % SESSION_ID
                _header = HEADER
                _body = urllib.urlencode({'cmd': 'write'})

                _ret, _ecode, _resp = api.sendReq(_header, _url, 'POST', _body)
                if _ret is False or _ecode is not 200 and _resp is None:
                    return None

                result = int()
                rows = str(_resp).splitlines()
                for offset in range(0, len(rows)):
                    columns = rows[offset].split(":")
                    if len(columns) is not 2:
                        continue
                    if columns[0] == "result":
                        result = int(columns[1])
                        continue
                    if columns[0] == "message":
                        ret_msg = str(columns[1])

                if result is not 1:
                    raise Exception(ret_msg)

                return True, None

            except Exception, _exc:
                logger.error("Failed to Restore [%d/%d]" % (retry, retries))
                logger.exception(_exc)

        _err = "At Last Failed to Restore axgate"
        return False, _err

    def reboot(self, retries=10, retry_delay=3):
        # cmd=reboot force
        # result:1
        # message:none
        global SESSION_ID
        for retry in range(1, retries + 1):
            if retry > 1:
                sleep(retry_delay)

            try:
                # curl --request POST \
                # --url "https://{address}:{port}/restrict/exec.cgi" \
                # --header "accept-charset: utf-8" \
                # --header "content-type: application/x-www-form-urlencoded" \
                # --header "Cookie: SessionID={SessionID}" \
                # --data "cmd=reboot force" -k -vvv

                ret = self.login()
                if ret is None:
                    raise Exception("Failed to Axagte Login!!! ")

                _url = str("https://%s:443/restrict/exec.cgi" % self._address)
                HEADER["cookie"] = "SessionID=%s" % SESSION_ID
                _header = HEADER
                _body = str("cmd=reboot force")

                _ret, _ecode, _resp = api.sendReq(_header, _url, 'POST', _body)

                if _ret is False or _ecode is not 200 and _resp is None:
                    return False, _resp

                result = int()
                rows = str(_resp).splitlines()
                for offset in range(0, len(rows)):
                    columns = rows[offset].split(":")
                    if len(columns) is not 2:
                        continue
                    if columns[0] == "result":
                        result = int(columns[1])
                        continue
                    if columns[0] == "message":
                        msg = int(columns[1])
                        continue

                if result is not 1:
                    return False, msg

                return True, None
            except Exception, _exc:
                _err = "Failed to Restore [%d/%d] %s" % (retry, retries, str(_exc))
                logger.error(_err)
        return False, _err

    def restart_service(self, svc_name, retries=3, retry_delay=3):
        _err = None
        for retry in range(1, retries + 1):
            if retry > 1:
                sleep(retry_delay)

            try:
                # just pkill <svc> in aos
                import commands as cmd
                _req_cmd = "pkill %s" % svc_name
                status, ret = cmd.getstatusoutput(_req_cmd)
                logger.debug("cmd=%s\n result =%d, %s" % (_req_cmd, status, ret))

                if status is not 0:
                    raise Exception(ret)

                return True, None
            except Exception, _exc:
                _err = "Failed to Restart [%d/%d] \n%s" % (retry, retries, str(_exc))
                logger.exception(_err)
        return False, _err

    def set_zbxa_znmsc(self, always_on=True, retries=3, retry_delay=3):
        _err = None
        for retry in range(1, retries + 1):
            if retry > 1:
                sleep(retry_delay)

            try:
                ret = self.login()
                if ret is None:
                    raise Exception("Can not Login to Axagte!!! ")

                _url = str("https://%s:443/restrict/exec.cgi" % self._address)
                HEADER["cookie"] = "SessionID=%s" % SESSION_ID
                _header = HEADER
                if always_on:
                    _body = urllib.urlencode(
                        {'cmd': 'configure terminal\npnf onebox process zabbix\npnf onebox process znmsc\nend\nwrite'}
                    )
                else:
                    _body = urllib.urlencode(
                        {'cmd': 'configure terminal\nno pnf onebox process zabbix\nno pnf onebox process znmsc\nend\nwrite'}
                    )

                _ret, _ecode, _resp = api.sendReq(_header, _url, 'POST', _body)
                if _ret is False or _ecode is not 200 and _resp is None:
                    return None

                result = int()
                rows = str(_resp).splitlines()
                for offset in range(0, len(rows)):
                    columns = rows[offset].split(":")
                    if len(columns) is not 2:
                        continue

                    if columns[0] == "result":
                        result = int(columns[1])
                        continue

                    if columns[0] == "message":
                        ret_msg = str(columns[1])

                if result is not 1:
                    raise Exception(ret_msg)

                return True, None
            except Exception, _exc:
                _err = "Failed to Set Always-running [%d/%d] \n%s" % (retry, retries, str(_exc))
                logger.exception(_err)
        return False, _err


