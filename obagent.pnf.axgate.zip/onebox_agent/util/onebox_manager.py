# -*- coding: utf-8 -*-
import os, json, ruamel.yaml, datetime
from onebox_agent.data import ob_constant as obc

import logging
logger = logging.getLogger(obc.OBA_NAME)


class BackupRestoreStateManager:
    def __init__(self, op=None, t_id=None):
        self._stat_file = obc.STAT_FILE_NAME
        self._op = op
        self._t_id = t_id

    def get_state(self):
        try:
            if not os.path.exists(self._stat_file):
                return None

            with open(self._stat_file, "r") as f:
                _stat_info = ruamel.yaml.safe_load(f)
                logger.debug(_stat_info)
                return _stat_info
        except Exception, e:
            logger.error("Fail to Get State, file=%s, exc=%s" % (self._stat_file, str(e)))
            logger.exception(e)
            return None

    def set_state(self, status, curStep=1, totalStep=1, msg=None, _log=False):
        try:
            if self._op is None:
                raise Exception("op code is None")
            if self._t_id is None:
                raise Exception("trasaction_id is None")

            _state = {'work_type': self._op, 'transaction_id': self._t_id, 'status': status, 'message': msg,
                      'current_step': curStep, 'total_step': totalStep }

            if not os.path.exists(os.path.dirname(self._stat_file)):
                os.makedirs(os.path.dirname(self._stat_file))

            with open(self._stat_file, 'w') as f:
                if type(_state) is dict:
                    f.write(json.dumps(_state))
            if _log:
                logger.info("SUCC: Set State, file=%s, status=%s" % (self._stat_file, str(_state)))

        except Exception, e:
            logger.error("Fail to Set State, file=%s, exc=%s" % (self._stat_file, str(e)))
            logger.exception(e)

    def chk_inprogress(self):
        '''
        check backup, restore, reboot in progress
        :return:  {'work_type': op, 'status': status, ...} or None
        '''
        obstate = self.get_state()
        if obstate is not None:
            if obstate.get('status', None) == obc.STATE_DOING:
                return obstate
        return None


# class BackupRestoreStateManager(StateManager):
#     '''
#     For backup, restore, reboot
#     state = {"work_type": "backup|restore|reboot", "status": "DOING|DONE|ERROR|FAIL" }
#     '''
#     def __init__(self):
#         self._stat_file = obc.STAT_FILE_NAME
#         # self._op_chk_progress = [obc.OP_BACKUP, obc.OP_RESTORE, obc.OP_REBOOT]
#         # self._op_chk_progress = [obc.OP_BACKUP, obc.OP_RESTORE]
#
#     def get_state(self):
#         self._get_state()
#
#     def set_state(self, op, tid, status, _log=False):
#         self._set_state()
#
#     def chk_inprogress(self):
#         '''
#         check backup, restore, reboot in progress
#         :return:  {'work_type': op, 'status': status, ...} or None
#         '''
#         obstate = self.get_state()
#         if obstate.get('status', None) == obc.STATE_DOING:
#             return obstate
#         return None


def new_tid():
    today = datetime.datetime.now()
    return today.strftime('%y%m%d%H%M')






