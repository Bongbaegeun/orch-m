# -*- coding: utf-8 -*-

import json
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from socket import error as serror


def sendReq(header, url, _method, _body=None, returnHeader=False, _to=5, cCrt=None, cKey=None, _passExc=False):
    """
    - FUNC: RestAPI로 URL 호출
    - INPUT
        header(M): HTTP Request Header
        url(M): HTTP Request URL
        _method(M): POST
        _body(M): json 형태
        timeout(O): URL 호출 후 timeout 시간
    - OUTPUT : True/False, 요청 결과 또는 HTTP Error Response
    """
    http_client = httpclient.HTTPClient()
    try:
        h = HTTPHeaders(header)
        if _body == None:
            strBody = None
        elif type(_body) == str:
            strBody = _body
        else:
            strBody = json.dumps(_body)

        if cCrt == None or cKey == None:
            req = HTTPRequest(validate_cert=False, url=url, headers=h, method=_method.upper(),
                              body=strBody, request_timeout=_to)
        else:
            req = HTTPRequest(validate_cert=False, url=url, headers=h, method=_method.upper(),
                              client_cert=cCrt,
                              client_key=cKey,
                              body=strBody, request_timeout=_to)

        response = http_client.fetch(request=req)

        _ret = (lambda x: True if x == 200 else False)(response.code)
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except:
            pass

        if returnHeader:
            return _ret, response.code, {"header": response.headers, "body": retBody}
        else:
            return _ret, response.code, retBody
    except httpclient.HTTPError, e:
        if _passExc: raise e

        _res = e.response
        _buf = None
        _body = None
        _ret = None
        if _res != None:
            _buf = (None if _res.buffer == None else _res.buffer.read())
            _ret = _buf
        if _res != None:
            _body = _res._body
            _ret = (_ret if _body == None else _body)
        _txt = "%s, res_body=%s, res_buf=%s" % (e, _body, _buf)

        if _ret != None:
            try:
                return False, e.code, json.loads(_ret)
            except Exception:
                return False, e.code, "HTTP ERROR: %s" % (_txt)
        else:
            return False, e.code, "HTTP ERROR: %s" % _txt
    except serror, e:
        if _passExc: raise e
        return False, 0, "SOCKET ERROR: url=%s, exc=%s" % (url, str(e))
    except Exception, e:
        if _passExc: raise e
        return False, None, "Unknown Error: %s" % str(e)
    finally:
        http_client.close()





