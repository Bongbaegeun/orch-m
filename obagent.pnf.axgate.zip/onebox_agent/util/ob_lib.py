#-*- coding: utf-8 -*-

import os, sys, shutil, datetime, tempfile, traceback
import tarfile


# import paramiko
# from onebox_agent.util import paramiko
# from scp import SCPClient
# from onebox_agent.util.scp import SCPClient
# from socket import error as socket_error
import commands as cmd
from time import sleep

_LOG_T = "[LIB-OB.%-4s]"
def _getLineNo():
    org_f = None
    try:
        raise Exception
    except:
        org_f = sys.exc_info()[2].tb_frame.f_back
    # On some versions of IronPython, currentframe() returns None if
    # IronPython isn't run with -X:Frames.
    if org_f is not None:
        f = org_f.f_back
    else:
        return None

    if f == None:
        return None

    l_no = f.f_lineno
    return l_no

class OB_LIB:
    def __init__(self, _logger=None):
        self.logger = _logger

    def _debug(self, msg):
        msg = _LOG_T % str(_getLineNo()) + " " + str(msg)
        if self.logger != None: self.logger.debug(msg)

    def _info(self, msg):
        msg = _LOG_T % str(_getLineNo()) + " " + str(msg)
        if self.logger != None: self.logger.info(msg)

    def _warn(self, msg):
        msg = _LOG_T % str(_getLineNo()) + " " + str(msg)
        if self.logger != None: self.logger.warning(msg)

    def _err(self, msg):
        msg = _LOG_T % str(_getLineNo()) + " " + str(msg)
        if self.logger != None: self.logger.error(msg)

    def _exc(self, exc):
        _SERR = tempfile.TemporaryFile()
        traceback.print_exc(exc, _SERR)
        _SERR.seek(0)
        msg = _SERR.read()
        msg = _LOG_T % str(_getLineNo()) + "\n" + str(msg)
        if self.logger != None: self.logger.fatal(msg)

    def scp_get(self, _host, _port, _src, _dst=None, retries=5, retry_delay=3):
        for retry in range(1, retries + 1):
            if retry > 1:
                sleep(retry_delay)

            try:
                _cmd_scp_get = "scp -i /mnt/flash/data/onebox/onebox-agent/key/id_rsa -o 'StrictHostKeyChecking=no' root@211.224.204.203:%s %s" \
                               % (_src, _dst)

                status, ret = cmd.getstatusoutput(_cmd_scp_get)

                if status is not 0:
                    raise Exception("scp get cmd = %s,  return = %s" % (_cmd_scp_get, ret))

                for retry2 in range(1, retries + 1):
                    sleep(retry_delay)
                    if os.path.exists(_dst):
                        self._info("SUCC: SCP-GET, host=%s, src=%s, dst=%s" % (_host, _src, _dst))
                        return True

                raise Exception("FAIL: Get . %s  to %s" % (_src, _dst))
            except Exception, e:
                self._err("Fail to Run SCP-GET [%d/%d], host=%s, src=%s, dst=%s, exc=%s"
                          % (retry, retries, _host, _src, _dst, str(e)))
        return False

    def scp_put(self, _host, _port, _src, _dst, retries=3, retry_delay=3):
        _errMsg = None
        for retry in range(1, retries + 1):
            if retry > 1:
                sleep(retry_delay)

            try:
                _cmd_remote_mkdir = "ssh -i /mnt/flash/data/onebox/onebox-agent/key/id_rsa root@%s "" mkdir -p %s """ % (_host, _dst)

                status, ret = cmd.getstatusoutput(_cmd_remote_mkdir)

                if status is not 0:
                    raise Exception("mkdir cmd = %s,  return = %s" % (_cmd_remote_mkdir, ret))

                _cmd_scp_put = "scp -i /mnt/flash/data/onebox/onebox-agent/key/id_rsa -o 'StrictHostKeyChecking=no' %s root@%s:%s" % (_src, _host, _dst)

                status, ret = cmd.getstatusoutput(_cmd_scp_put)

                if status is not 0:
                    raise Exception("scp-put cmd = %s,  return = %s" % (_cmd_scp_put, ret))
                return True, None
            except Exception, e:
                _errMsg = "Fail to Run SCP-PUT [%d/%d], host=%s, src=%s, dst=%s, exc=%s" \
                          % (retry, retries, _host, _src, _dst, str(e))
                self._err(_errMsg)
        return False, _errMsg

    def tar(self, output_filename, source_dir):
        try:
            if not os.path.exists(os.path.dirname(output_filename)):
                os.makedirs(os.path.dirname(output_filename))

            with tarfile.open(output_filename, "w:gz") as tar:
                # tar.add(source_dir, arcname=os.path.basename(source_dir))
                tar.add(source_dir)

            return True
        except Exception, e:
            self._err("Fail to Tar File, Unknown Error, out_file=%s, src_dir=%s, exc=%s"
                      % (output_filename, source_dir, str(e)))
            self._exc(e)
            return False

    def untar(self, _tar_file, _dst_dir):
        try:
            if os.path.exists(_dst_dir):
                shutil.rmtree(_dst_dir)

            if not os.path.exists(_tar_file):
                self._err("Fail to UnTar File, No File, file=%s" % str(_tar_file))
                return False
            else:
                tar = tarfile.open(_tar_file)
                tar.extractall(path=_dst_dir)
                tar.close()
                self._info("SUCC: UnTar File, file=%s, dst_dir=%s" % (_tar_file, _dst_dir))
                return True
        except Exception, e:
            self._err("Fail to UnTar File, Unknown Error, file=%s, dst_dir=%s, exc=%s" % (_tar_file, _dst_dir, str(e)))
            self._exc(e)
            return False

    def copyFile(self, _src, _dst):
        try:
            if not os.path.exists(_src):
                self._err("Fail to Copy File, No Source, src=%s, dst=%s" % (_src, _dst))
                return False

            if not os.path.exists(os.path.dirname(_dst)):
                os.makedirs(os.path.dirname(_dst))

            shutil.copy2(_src, _dst)

            return True
        except Exception, e:
            self._err("Fail to Copy File, src=%s, dst=%s, exc=%s" % (_src, _dst, str(e)))
            self._exc(e)
            return False

    def copyDir(self, _src, _dst):
        try:
            if not os.path.exists(_src):
                self._err("Fail to Copy Dir, No Source, src=%s, dst=%s" % (_src, _dst))
                return False

            shutil.copytree(_src, _dst)

            return True
        except Exception, e:
            self._err("Fail to Copy Dir, src=%s, dst=%s, exc=%s" % (_src, _dst, str(e)))
            self._exc(e)
            return False

    def delFile(self, absPath):
        try:
            if os.path.isfile(absPath) and os.path.isabs(absPath):
                os.remove(absPath)
                self._debug("Delete File, f=%s" % str(absPath))
        except Exception, e:
            self._exc(e)

    def delDir(self, dirPath):
        try:
            if os.path.isdir(dirPath) and os.path.exists(dirPath):
                os.removedirs(dirPath)
                self._debug("Delete Dir, %s" % str(dirPath))
            else:
                raise Exception('%s is not dir. ' % dirPath)
        except Exception, e:
            self._exc(e)

    def backupFile(self, absName, orgDir, bakDir):
        backupDir = None
        if bakDir != None and bakDir != '':
            if not os.path.isabs(bakDir):
                backupDir = os.path.normpath(os.path.join(orgDir, bakDir))
            else:
                backupDir = bakDir

            if not os.path.exists(backupDir):
                os.makedirs(backupDir)

            dttm = str(datetime.datetime.now().strftime("%Y%m%d_%H:%M:%S"))

            if os.path.isdir(absName):
                shutil.copytree(absName, backupDir + '_' + dttm)
            elif os.path.isfile(absName):
                shutil.copyfile(absName, os.path.join(backupDir, os.path.basename(absName) + '.' + dttm))
        return



