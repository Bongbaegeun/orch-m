#-*- coding: utf-8 -*-

import ruamel.yaml, json
from onebox_agent.data import ob_constant as obc


class _OB_HW():
    def __init__(self):
        self.model = ''
        self.cpu = ''
        self.num_cpus = 0
        self.num_cores_per_cpu = 0
        self.mem_size = 0

    def config(self, ob_cfg):
        self.model = ob_cfg['model']
        self.cpu = ob_cfg['cpu']
        self.num_cpus = ob_cfg['num_cpus']
        self.num_cores_per_cpu = ob_cfg['num_cores_per_cpu']
        self.mem_size = ob_cfg['mem_size']


class _OB_NIC():
    def __init__(self):
        self.iface_name = None
        self.mac_addr = None
        self.zone = None
        self.ip_type = None
        self.ip_addr =None
        self.gw_ip_addr = None
        self.description = None
        self.mgmt_boolean = False
        self.line_protocol = None
        self.link_status = None

    def config(self, nic_cfg):
        self.iface_name = nic_cfg['iface_name']
        self.mac_addr = nic_cfg['mac_addr']
        self.zone = nic_cfg['zone']
        self.ip_type = nic_cfg['ip_type']
        self.ip_addr = nic_cfg['ip_addr']
        self.gw_ip_addr = nic_cfg['gw_ip_addr']
        self.description = nic_cfg['description']
        self.mgmt_boolean = nic_cfg['mgmt_boolean']
        self.line_protocol = nic_cfg['link_protocol']
        self.link_status = nic_cfg['link_status']
        return self

'''
load from axgate info json  file, and it will be sent to orchf
only axgate hw 
'''
class ONEBOX_INFO:
    def __init__(self, info_path, logger):
        self.axgate_info_path = info_path
        self.logger = logger

    '''
    return json ob_info send to orchf 
    = axgate-info + onebox_type + oba_baseurl
    '''
    def load(self, first_noti=False):
        try:
            self.logger.info('load axgate info: file path = %s' % self.axgate_info_path)

            with open(self.axgate_info_path, 'r') as axinfo:
                ob_info_json = json.load(axinfo)

            # todo: get oba_baseurl, oba_version from axgate-info
            self.onebox_id = str(ob_info_json['onebox_id'])
            if not self.axgate_info_path:
                raise Exception('onebox_id is empty. in axgate-info')

            _nic_list = ob_info_json['nic']
            _have_mgmt = False
            for nic in _nic_list:
                if nic['mgmt_boolean'] is True:
                    _mgmt_ip = str(nic['ip_addr']).split('/')[0]
                    _oba_base_url = str(obc.OBA_BASE_URL_FORMAT % (_mgmt_ip, obc.OBA_SVC_PORT))
                    _have_mgmt = True

            if _have_mgmt is False:
                raise Exception('No mgmt ip info in axgate-info: %s' % self.axgate_info_path)

            ob_info_json['onebox_type'] = obc.DEF_OB_TYPE
            ob_info_json['oba_baseurl'] = _oba_base_url
            ob_info_json['oba_version'] = obc.OBA_VERSION
            ob_info_json['first_notify'] = first_noti

            return ob_info_json
        except Exception, e:
            self.logger.exception(e)
            return None


class OBA_CONF():
    def __init__(self):
        self.m_onebox_id = obc.DEF_OB_ID
        self.m_onebox_type = ''
        self.m_oba_base_path = ''
        self.m_axgate_info_path = ''
        self.m_mgmt_ip = ''
        self.m_mgmt_nic = ''
        self.m_mgmt_ip_type = ''
        self.m_mgmt_gw_ip = ''
        self.m_oba_base_url = ''
        self.m_oba_port = obc.OBA_SVC_PORT
        self.m_report_interval = 0
        self.m_version = ''
        self.m_orchf_url_ob_info = ''
        self.m_orchf_ip = ''
        self.m_orchf_port = ''

    def load(self, oba_cfg, logger):
        try:
            self.m_onebox_type = oba_cfg.get('onebox_type', obc.DEF_OB_TYPE)
            self.m_oba_base_path = oba_cfg.get('oba_base_path', obc.DIR_AGENT_BASE_PATH)
            self.m_axgate_info_path = oba_cfg['axgate_info_path']
            self.m_report_interval = int(oba_cfg.get('report_interval', 600))
            self.m_oba_port = oba_cfg.get('oba_port', obc.OBA_SVC_PORT)

            with open(self.m_axgate_info_path, 'r') as x:
                _x_info = json.load(x)

            self.m_onebox_id = str(_x_info['onebox_id'])
            if not self.m_onebox_id:
                raise Exception('onebox_id is empty')

            # set mgmt info
            _x_nic_list = _x_info['nic']
            _have_mgmt = False
            for nic in _x_nic_list:
                if nic['mgmt_boolean'] is True:
                    self.m_mgmt_ip = str(nic['ip_addr']).split('/')[0]
                    self.m_mgmt_nic = nic['iface_name']
                    self.m_mgmt_ip_type = nic['ip_type']
                    self.m_mgmt_gw_ip = nic['gw_ip_addr']
                    self.m_oba_base_url = str(obc.OBA_BASE_URL_FORMAT % (self.m_mgmt_ip, self.m_oba_port))
                    _have_mgmt =True

            if _have_mgmt is False:
                raise Exception('No mgmt ip info in axgate-info: %s' % self.m_axgate_info_path)

            # ob_info url- https://%s:%s/orch/server/%s/wf
            self.m_orchf_url_ob_info = str(oba_cfg['orchf_url_ob_info_tmpl'])
            self.m_orchf_ip = str(oba_cfg['orchf_ip'])
            self.m_orchf_port = str(oba_cfg['orchf_port'])

            return self
        except Exception, e:
            logger.exception(e)
            return None

    def update_from_axgate_info(self, axgate_info_path, logger):
        try:
            logger.info("Start update oba cfg from utm: axgate-info")
            with open(axgate_info_path, 'r') as x:
                _x_info = json.load(x)

            self.m_onebox_id = str(_x_info['onebox_id'])

            # set mgmt info
            _x_nic_list = _x_info['nic']
            _have_mgmt = False
            for nic in _x_nic_list:
                if nic['mgmt_boolean'] is True:
                    self.m_mgmt_ip = str(nic['ip_addr']).split('/')[0]
                    self.m_mgmt_nic = nic['iface_name']
                    self.m_mgmt_ip_type = nic['ip_type']
                    self.m_mgmt_gw_ip = nic['gw_ip_addr']
                    self.m_oba_base_url = str(obc.OBA_BASE_URL_FORMAT % (self.m_mgmt_ip, self.m_oba_port))
                    _have_mgmt = True

            if _have_mgmt is False:
                raise Exception('No mgmt ip info in axgate-info: %s' % self.m_axgate_info_path)

            self.write(obc.FILE_OBA_CONF, logger)
            return self
        except Exception, e:
            logger.exception(e)
            return None


    def write(self, oba_cfg_path, logger):
        try:
            with open(oba_cfg_path, "r") as f:
                _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)

            _oba_cfg['onebox_id'] = self.m_onebox_id
            _oba_cfg['onebox_type'] = self.m_onebox_type
            _oba_cfg['axgate_info_path'] = self.m_axgate_info_path
            _oba_cfg['mgmt_ip'] = self.m_mgmt_ip
            _oba_cfg['mgmt_nic'] = self.m_mgmt_nic
            _oba_cfg['mgmt_ip_type'] = self.m_mgmt_ip_type
            _oba_cfg['mgmt_gw_ip'] = self.m_mgmt_gw_ip
            _oba_cfg['oba_base_url'] = self.m_oba_base_url
            _oba_cfg['report_interval'] = self.m_report_interval

            with open(oba_cfg_path, 'w') as fw:
                fw.write(ruamel.yaml.dump(_oba_cfg, Dumper=ruamel.yaml.RoundTripDumper))

            return True

        except Exception, e:
            logger.exception(e)
            return False

