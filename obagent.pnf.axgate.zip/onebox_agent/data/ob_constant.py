#-*- coding: utf-8 -*-
#from enum import Enum

# aos agent version??? a.1.0.0  1.5.0
OBA_VERSION = "1.5.0"
OBA_SVC_PORT = 5556
OBA_BASE_URL_FORMAT = "https://%s:%s/v1"

OBA_NAME = "onebox-agent"
MONA_NAME = "zabbix-agentd"
NMSA_NAME = "znmsc"


DEF_OB_ID = "UNDEFINED.OB1"
DEF_OB_TYPE = "KtPnf"

# DEF_HOST_MGMT_IP = "10.0.101.254"
# DEF_HOST_MGMT_MASK = "255.255.255.0"
# DEF_HOST_MGMT_GW = "255.255.255.0"
# DEF_HOST_MGMT_NIC = "eth0"
#
# DEF_HOST_LOCAL_IP = "192.168.254.254"
# DEF_HOST_LOCAL_GW = "192.168.254.1"
# DEF_HOST_LOCAL_MASK = "255.255.255.0"
# DEF_LOCAL_IP_UTM = "192.168.254.1"

HTTP_HEADER = {'Accept': 'application/json', 'content-type': 'application/json'}
HTTP_BAD_REQUEST = 400
HTTP_INTERNAL_SERVER_ERROR = 500

CFG_REPORT_INTERVAL = "report_interval"

DIR_OB_KEY = ""

DIR_AGENT_BASE_PATH = "/mnt/flash/data/onebox/onebox-agent"
DIR_ZBXA_BASE_PATH = "/mnt/flash/data/onebox/zabbix"
DIR_ZNMSC_BASE_PATH = "/mnt/flash/data/onebox/onebox-znmsc"

DIR_OBA_TMP = DIR_AGENT_BASE_PATH + "/tmp"
DIR_BACKUP_ROOT = DIR_OBA_TMP + "/backup/%s"
DIR_RESTORE_ROOT = DIR_OBA_TMP + "/restore"
FILE_OBA_CONF = DIR_AGENT_BASE_PATH + "/conf/onebox-agent.conf"
FILE_ZBAX_CONF = DIR_ZBXA_BASE_PATH + "/conf/zabbix_agentd.conf"
DIR_ZBXA_KEY = DIR_ZBXA_BASE_PATH + "/conf/zabbix_agentd.conf.d/"
DIR_ZBXA_PLUGIN = DIR_ZBXA_BASE_PATH + "/plugin"
FILE_ZNMSC_BIN = DIR_ZNMSC_BASE_PATH + '/bin/znmsc'


FILE_BACKUP_AXGATE = DIR_OBA_TMP +"/axgate_insoft_bak.conf"
FILE_BACKUP_LOCAL = "backup-%s.tar.gz"
FILE_BACKUP_REMOTE = "/var/onebox/backup/%s/OneBox/%s"

# BACKUP, RESTORE TARGETS
BACKUP_FILE_OBA = [FILE_OBA_CONF]

BACKUP_FILE_ZBXA = [FILE_ZBAX_CONF]
BACKUP_DIR_ZBXA = [DIR_ZBXA_KEY, DIR_ZBXA_PLUGIN]

BACKUP_FILE_ZNMSC = [DIR_ZNMSC_BASE_PATH + "/znmsc.eini",
                     DIR_ZNMSC_BASE_PATH + "/znmsc.pkey"]
                     # DIR_ZNMSC_BASE_PATH + "/bin/znmsc"]
# vnf
# BACKUP_FILE_ZNMSC = [DIR_ZNMSC_BASE_PATH + "/znmsc.ini",
#                      DIR_ZNMSC_BASE_PATH + "/znmsc.pkey",
#                      DIR_ZNMSC_BASE_PATH + "/bin/znmsc"]

# SVC_NAME_ZBXA = ["zabbix-agentd"]
# SVC_NAME_ZNMSC = ["znmsc"]
# SVC_NAME_OBA = ["onebox-agent"]
SVC_NAME_ZBXA = "zabbix_agentd"
SVC_NAME_ZNMSC = "znmsc"
SVC_NAME_OBA = "onebox-agent"

# Status
STAT_DIR_BASE = "%s/tmp/.stat" % DIR_AGENT_BASE_PATH
STAT_FILE_NAME = "%s/onebox_state" % STAT_DIR_BASE

STATE_DOING = "DOING"
STATE_DONE = "DONE"
STATE_ERROR = "ERROR"
STATE_FAIL = "FAIL"
STATE_NONE = "NONE"
STATUS_ORCHF_NORMAL = "N__"

OP_NOTI_OBINFO = "NOTIFY-OBINFO"
OP_BACKUP = "BACKUP"
OP_RESTORE = "RESTORE"
OP_REBOOT = "REBOOT"
OP_VERSION = "VERSION"
OP_WAN_MONITOR = "WAN_MONITOR"
OP_RESTORE_PROGRESS = "RESTORE_PROGRESS"
OP_FILE_PUT = "FILE-PUT"
OP_FILE_DEL = "FILE-DEL"
OP_FILE_DEL_EXCLUDE = "FILE-DEL-EXCLUDE"
OP_ZBA_STATUS_MON_FILE = "ZBA-STATUS-MON-FILE"
OP_ZBA_RESTART = "ZBA-RESTART"

KEY_CLI_CRT = "/mnt/flash/data/onebox/agent/key/client.crt"
KEY_CLI_KEY = "/mnt/flash/data/onebox/agent/key/client.key"


def URL_ORCHF_BASE(_ip, _port):
    if type(_port) == int :
        return "https://%s:%d/orch" % (str(_ip), _port)
    else:
        return "https://%s:%s/orch" % (str(_ip), str(_port))

