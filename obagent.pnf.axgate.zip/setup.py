#!/usr/bin/env python
#-*- coding: utf-8 -*-

from setuptools import setup, find_packages

setup(
    name='onebox-agent',
    version='0.0.1',
    install_requires=['tornado'],
    packages=find_packages(),
    python_requires='==2.7',
    zip_safe=False,
    entry_points={
        'console_scripts':'onebox-agent=onebox_agent.obagent:main'
         }
)


