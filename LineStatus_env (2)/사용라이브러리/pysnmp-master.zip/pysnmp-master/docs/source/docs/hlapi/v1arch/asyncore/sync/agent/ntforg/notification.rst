
TRAP/INFORM notification
========================

.. toctree::
   :maxdepth: 2

.. autofunction:: pysnmp.hlapi.v1arch.sendNotification
