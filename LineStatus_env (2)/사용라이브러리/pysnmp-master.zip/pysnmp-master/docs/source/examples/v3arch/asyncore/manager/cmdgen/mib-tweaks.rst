.. toctree::
   :maxdepth: 2

MIB tweaks
----------

.. include:: /../../examples/v3arch/asyncore/manager/cmdgen/getnext-multiple-oids-and-resolve-with-mib.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/v3arch/asyncore/manager/cmdgen/getnext-multiple-oids-and-resolve-with-mib.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/v3arch/asyncore/manager/cmdgen/getnext-multiple-oids-and-resolve-with-mib.py>` script.


See also: :doc:`library reference </docs/api-reference>`.
