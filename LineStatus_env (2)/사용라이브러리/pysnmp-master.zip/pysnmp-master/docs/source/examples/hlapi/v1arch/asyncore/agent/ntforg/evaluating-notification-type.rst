.. toctree::
   :maxdepth: 2

Evaluating NOTIFICATION-TYPE
----------------------------

.. include:: /../../examples/hlapi/v1arch/asyncore/sync/agent/ntforg/v2c-trap-with-notification-objects.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/hlapi/v1arch/asyncore/sync/agent/ntforg/v2c-trap-with-notification-objects.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/hlapi/v1arch/asyncore/sync/agent/ntforg/v2c-trap-with-notification-objects.py>` script.


See also: :doc:`library reference </docs/api-reference>`.
