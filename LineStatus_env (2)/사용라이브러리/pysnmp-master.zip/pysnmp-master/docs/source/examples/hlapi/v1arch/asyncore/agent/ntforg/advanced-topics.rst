.. toctree::
   :maxdepth: 2

Advanced Notification Originator
--------------------------------

See also: :doc:`library reference </docs/api-reference>`.
