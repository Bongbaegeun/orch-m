.. toctree::
   :maxdepth: 2

SNMP versions
-------------

.. include:: /../../examples/hlapi/v1arch/asyncore/sync/manager/cmdgen/v1-get.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/hlapi/v1arch/asyncore/sync/manager/cmdgen/v1-get.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/hlapi/v1arch/asyncore/sync/manager/cmdgen/v1-get.py>` script.


.. include:: /../../examples/hlapi/v1arch/asyncore/sync/manager/cmdgen/v2c-get.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/hlapi/v1arch/asyncore/sync/manager/cmdgen/v2c-get.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/hlapi/v1arch/asyncore/sync/manager/cmdgen/v2c-get.py>` script.


See also: :doc:`library reference </docs/api-reference>`.
