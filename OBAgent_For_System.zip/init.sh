# wget https://bootstrap.pypa.io/pip/2.7/get-pip.py

# python get-pip.py

# pip install pyyaml -y
# pip install tornado -y

rpm -ivh zabbix-agent-3.0.32-1.el7.x86_64.rpm

mkdir -p /etc/onebox
mkdir -p /var/log/zabbix-agent/plugin
mkdir -p /etc/zabbix/zabbix_agentd.conf.d

chown zabbix:zabbix /var/log/zabbix -R
chown zabbix:zabbix /var/log/zabbix-agent -R

cp onebox-agent.conf /etc/onebox
cp onebox-agent.service  /usr/lib/systemd/system/

ln -s /usr/lib/systemd/system/onebox-agent.service /etc/systemd/system/multi-user.target.wants/onebox-agent.service

systemctl daemon-reload

# cpu 온도 표시 안됨 sensors -u 
# yum install lm_sensors hddtemp

