#!/usr/bin/python
#-*- coding: utf-8 -*-

import xms_api
import sys, yaml, os, logging
from xms_api import Logger

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/xms_cfg.yaml'

DEBUG_CPU=False

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger(logName='xms', logDir='/var/log/zabbix-agent', logFile='xms.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG).instance()

ip=cfg['vm_ip']
uID=cfg['vm_app_id']
#"net" : """ ethtool %s | grep "Link detected:" | awk '{print $3}' """,
scripts = { 
           "proc" : """ ps -ef | grep -v "grep" | grep -c "%s" """ ,
           "mem" : """ free | grep  "%s" | awk '{print $2":"$3":"$4":"$6":"$7}' """,
           "disk" : """ df | grep -v "Filesystem" | awk '{print $6":"$2":"$3":"$4}' """,
           "net" : """ ip link show %s | grep -c ",UP," """,
           "cpu_load" : """ cpu_info=$(top -bn 2 -d 0.5 | grep "load average" | tail -n 1); loads=${cpu_info##*:}; echo ${loads%%,*} """,
           "cpu_util" : """ cpu_info=$(top -bn 2 -d 0.5 | grep "Cpu" | tail -n 1); idle=${cpu_info##*ni,}; usage=${idle%%%id,*}; echo $usage """,
           "cpu_cnt" : """ cat /proc/cpuinfo | grep -c "processor" """,
           "rx_byte": """ cat /sys/class/net/%s/statistics/rx_bytes """,
           "tx_byte": """ cat /sys/class/net/%s/statistics/tx_bytes """,
           "ne_status": """https://%s/api/getApSwitchInfo.json?userId=%s"""
           }


def checkPing(ip):
    try :
        xms_api.run( logger, ip, scripts['cpu_util'], 5 )
        return 1
    except Exception, e:
        logger.exception(e)
    return 0

def procStatus( ip, proc ):
    try:
        ret = xms_api.run( logger, ip, scripts["proc"]%proc )
        return int(ret)
    except Exception, e:
        logger.exception(e)
        return None

def memUsage( ip, _type, isSwap=False ):
    mem = "Mem"
    if isSwap : mem = "Swap"
    try:
        ret = xms_api.run( logger, ip, scripts["mem"]%(mem) )
            
        _res = str(ret).split(':')
        total = int( _res[0].strip() )
        used = int( _res[1].strip() )
        free = int( _res[2].strip() )
        buff = int( (lambda x: '0' if x.strip() == '' or x == None else x.strip())(_res[3]) )
        cach = int( (lambda x: '0' if x.strip() == '' or x == None else x.strip())(_res[4]) )
        
        if str(_type).upper() == "TOTAL":   return total
        elif str(_type).upper() == "USED":  return used - buff - cach
        elif str(_type).upper() == "FREE":  return free + buff + cach
        elif str(_type).upper() == "UTIL":  return (used - buff - cach )*100/total
        else:
            logger.error('Unknown Mem Type, type=%s'%str(_type))
            return None
        
    except Exception, e:
        logger.exception(e)
        return None
    
def diskUsage( ip, _type, name ):
    res = xms_api.run( logger, ip, scripts["disk"] )
    
    for line in res.split("\n"):
        tmp = line.split(":")
        if str(tmp[0]) == name:
            try:
                ret = 0
                if str(_type).upper() == "TOTAL":
                    ret = int(tmp[2]) + int(tmp[3])
                elif str(_type).upper() == "USED":
                    ret = tmp[2]
                elif str(_type).upper() == "FREE":
                    ret = tmp[3]
                elif str(_type).upper() == "UTIL":
                    ret = round(float(tmp[2])*100.0/float(int(tmp[2]) + int(tmp[3])))
                else:
                    logger.error('Unknown Disk Type, type=%s'%str(_type))
                    return None
                return int(ret)
            except Exception, e:
                logger.exception(e)
                return None
    
    logger.error('Invalid Disk Value, val=%s'%str(res))
    return None

def netStatus( ip, name ):
    try:
        res = xms_api.run( logger, ip, scripts["net"]%(name) )
        return int(res)
    except Exception, e:
        logger.exception(e)
        return None

def cpuUsage( ip, _type ):
    try :
        if str(_type).upper() == "COUNT":
            script = scripts["cpu_cnt"]
            return int( xms_api.run( logger, ip, script ) )
        elif str(_type).upper() == "LOAD":
            script = scripts["cpu_load"]
            return float( xms_api.run( logger, ip, script ) )
        elif str(_type).upper() == "UTIL":
            script = scripts["cpu_util"]
            usage = float( xms_api.run( logger, ip, script ) )
            ret = 100.0 - usage
            if DEBUG_CPU and ret > 80.0 :
                topCpu = xms_api.run( logger, ip, 'top -bn 3 -d 0.3 | grep "Cpu" | tail -n 1')
                logger.debug( 'top> %s'%str(topCpu) )
                psCpu = xms_api.run( logger, ip, 'ps -aux --sort -pcpu | head -n 10')
                logger.debug( 'ps> %s'%str(psCpu) )
                topList = xms_api.run( logger, ip, 'top -bn 3 -d 0.3 -c | head -n 20')
                logger.debug( 'top proc> %s'%str(topList) )
            return ret
        else:
            logger.error('Unknown CPU Type, type=%s'%str(_type))
            return None
    except Exception, e:
        logger.exception(e)
        return None

def netRate( ip, name, _type ):
    fName = None
    try:
        import time
        
        if not os.path.exists( '/var/log/zabbix-agent/dat' ) :
            os.mkdir('/var/log/zabbix-agent/dat')
        if str(_type).lower() == 'rx':
            fName = '/var/log/zabbix-agent/dat/xms_%s_rx_bps.dat'%name
            bName = 'rx_byte'
        else:
            fName = '/var/log/zabbix-agent/dat/xms_%s_tx_bps.dat'%name
            bName = 'tx_byte'
        
        fd = os.open(fName, os.O_RDWR|os.O_CREAT)
        fileobj = os.fdopen(fd, 'rw+b')
        prevTxt = fileobj.read()
        
        byte = int( xms_api.run( logger, ip, scripts[bName]%name ) )
        bits = byte*8
        ts = time.time()
        txt = str(bits) + "," + str(ts)
        
        fileobj.seek(0)
        fileobj.truncate()
        
        fileobj.write(txt)
        fileobj.flush()
        fileobj.close()
        
        if prevTxt != None and str(prevTxt).find(',') >= 0 :
            bitts = str(prevTxt).split(',')
            prevBits = int(bitts[0])
            prevTs = float(bitts[1])
            
            if bits >= prevBits and ts > prevTs :
                bps = int((bits-prevBits)/(ts-prevTs))
            else:
                bps = None
        else :
            bps = None
        
        return bps
    except ValueError, ve:
        if fName != None and os.path.isfile( fName ):
            os.remove(fName)
        logger.exception(ve)
        return None
    except Exception, e:
        logger.error(fName)
        logger.exception(e)
        return None

def netRxRate( ip, name ):
    return netRate(ip, name, 'rx')

def netTxRate( ip, name ):
    return netRate(ip, name, 'tx')

XMS_IP = "211.224.204.210"

def chkNE( ip, neType, _type ):
    ip = XMS_IP
    ret = None
    try:
        header = xms_api.HEADER
        ret = xms_api.callAPI( 'GET', header, scripts['ne_status']%(ip, uID) )
        
        _Type = str(_type).upper()
        if int(ret['result']) == 0:
            netInfo = ret['list'][0]
            if neType == 'AP':
                if _Type == 'TOTAL':
                    return int(netInfo['ap_count'])
                elif _Type == 'FAULT':
                    return int(netInfo['ap_error'])
            elif neType == 'SW':
                if _Type == 'TOTAL':
                    return int(netInfo['switch_count'])
                elif _Type == 'FAULT':
                    return int(netInfo['switch_error'])
        else:
            logger.error('return result != 0 ')
            logger.error(ret)
            return None
        
        logger.error('no match, ip=%s, neType=%s, type=%s '%(str(ip), str(neType), str(_type)))
        logger.error(ret)
        return None
    except Exception, e:
        logger.error(ret)
        logger.exception(e)
        return None


if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            if chkType == "PING":
                print ( checkPing(ip) )
                exit(0)
            elif chkType == "PROC":
                print ( procStatus(ip, sys.argv[2]) )
                exit(0)
            elif chkType == "MEM":
                print ( memUsage(ip, sys.argv[2]) )
                exit(0)
            elif chkType == "SWAP":
                print ( memUsage(ip, sys.argv[2], True) )
                exit(0)
            elif chkType == "DISK":
                print ( diskUsage(ip, sys.argv[2], sys.argv[3]) )
                exit(0)
            elif chkType == "NET":
                if str(sys.argv[2]).upper() == 'STATUS' :
                    print ( netStatus(ip, sys.argv[3]) )
                    exit(0)
                elif str(sys.argv[2]).upper() == 'RX_RATE' :
                    print ( netRxRate(ip, sys.argv[3]) )
                    exit(0)
                elif str(sys.argv[2]).upper() == 'TX_RATE' :
                    print ( netTxRate(ip, sys.argv[3]) )
                    exit(0)
            elif chkType == "CPU":
                print ( cpuUsage(ip, sys.argv[2]) )
                exit(0)
            elif chkType == "AP":
                print ( chkNE(ip, 'AP', sys.argv[2]) )
                exit(0)
            elif chkType == "SW":
                print ( chkNE(ip, 'SW', sys.argv[2]) )
                exit(0)
            
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger.exception(e)
        print None
