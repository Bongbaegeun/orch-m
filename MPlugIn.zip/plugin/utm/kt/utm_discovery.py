#!/usr/bin/python
#-*- coding: utf-8 -*-

import utm_api
from utm_api import Logger
import sys, json, yaml, os, logging

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/utm_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger( logName='utm', logDir='/var/log/zabbix-agent', logFile='utm.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG ).instance()

ip = cfg['vm_ip']
ID = cfg['vm_id']
PASSWD = cfg['vm_passwd']

CMDS = {
        "CONN_SESS" : """https://%s/index.dao""",
        "AUTH" :   """https://%s/login.dao""",
        "OS_INFO":   """https://%s/logstat/sysinfo.dao""",
       }

def connSess(ip):
    try:
        utm_api.callAPI( CMDS['CONN_SESS']%ip, 'GET' )
        return 1
    except Exception, e:
        logger.exception(e)
        return 0

def login( ip, _id, passwd ):
    try:
        if connSess(ip) != 1 :
            return False
        ret = utm_api.callAPI( CMDS['AUTH']%ip, header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"},
                               reqBody='username=%s&passwd=%s&force=%s'%(_id, passwd, str(1)) )
        if str(ret).count("errorMsg") > 0 : 
            return False
        else: 
            return True
    except Exception, e:
        logger.exception(e)
        return False


def netList( ip, _id=ID, passwd=PASSWD ):
    info = { "data": [] }
    
    if not login( ip, _id, passwd ):
        logger.error( 'login Error, ip=%s, id=%s, pw=%s'%(str(ip), str(_id), str(passwd)) )
        return None
    
    try:
        ret = utm_api.callAPI( CMDS['OS_INFO']%ip, 'GET')
        if not type(ret) == dict :
            logger.error( 'netList body is not dict, ret=%s'%(ret) )
            return None
        
        for _if in ret['root']['trafficList'] :
            if _if['ifname'] in cfg['vm_net']:
                info['data'].append( { "{#NAME}": _if['ifname'] } )
        
        return info
    except Exception, e:
        logger.exception(e)
        return None

def daemonList():
    ret = { "data": [] }
    for item in cfg['vm_daemon']:
        ret["data"].append( { "{#NAME}": item } )
    return ret

if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            
            if str(chkType).upper() == "NETLIST":
                print( json.dumps(netList(ip), indent=4) )
                exit(0)
            elif str(chkType).upper() == "DAEMONLIST":
                print( json.dumps(daemonList(), indent=4) )
                exit(0)
#             elif chkType == "ENGINE":
#                 print( engineInfo(auth, ip, sys.argv[2]) )
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger.exception(e)
        print None




