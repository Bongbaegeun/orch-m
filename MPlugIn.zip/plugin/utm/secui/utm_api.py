#!/usr/bin/python
#-*- coding: utf-8 -*-

from pysnmp.entity.rfc3413.oneliner import cmdgen
from pysnmp.proto import rfc1902

import logging.handlers, os

class Singleton(object):
    _instance = None
    
    def __new__(self, *args, **kwargs):
        if not isinstance( self._instance, self ) :
            self._instance = object.__new__(self, *args, **kwargs)
        return self._instance

class Logger(Singleton):
    
    def __init__(self, logName, logDir='./', logFile='myLogger.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG):
        self._logger = logging.getLogger( logName )
        logging.getLogger( logName )
        formatter = logging.Formatter( '[%(asctime)s] %(levelname)s: %(message)s' )
        
        fileHandler = logging.handlers.RotatingFileHandler( logDir + "/" + logFile, maxBytes=logFileMaxByte, backupCount=logBackupCnt )
#         streamHandler = logging.StreamHandler()
        
        fileHandler.setFormatter( formatter )
#         streamHandler.setFormatter( formatter )
            
        self._logger.addHandler( fileHandler )
#         self._logger.addHandler( streamHandler )
        
        self._logger.setLevel( logLevel )
        
        os.chmod( fileHandler.baseFilename, 0777 )
    def instance(self):
        return self._logger

COMM='secui'

def sendGetOneMsg(ip, oid, comm=COMM, port=161):
    errorIndication, errorStatus, errorIndex, varBinds = cmdgen.CommandGenerator().getCmd(
        cmdgen.CommunityData( comm ),
        cmdgen.UdpTransportTarget( ( ip, port), timeout=1 ),
        oid,
    )

    rs = []
    # Check for errors and print out results
    if errorIndication:
        raise Exception(errorIndication)
    else:
        if errorStatus:
            raise Exception('%s at %s' % (
                errorStatus.prettyPrint(),
                errorIndex and varBinds[int(errorIndex)-1][0] or '?'
                )
            )
        else:
            for name, val in varBinds:
                rs.append( ( str(name), str(val) ) )
            return rs

    return None


def sendSetOneMsg(ip, oid, val, comm=COMM, port=161):
    
    errorIndication, errorStatus, errorIndex, varBinds = cmdgen.CommandGenerator().setCmd(
        cmdgen.CommunityData( comm ),
        cmdgen.UdpTransportTarget( (ip, port) ),
        (oid, rfc1902.Integer32(val)),
    )
    
    rs = []
    # Check for errors and print out results
    if errorIndication:
        raise Exception(errorIndication)
    else:
        if errorStatus:
            raise Exception('%s at %s' % (
                errorStatus.prettyPrint(),
                errorIndex and varBinds[int(errorIndex)-1] or '?'
                )
            )
        else:
            for name, val in varBinds:
                print('%s = %s' % (name.prettyPrint(), val.prettyPrint()))
                rs.append( ( str(name), str(val) ) )
                return rs
    

    return None

def sendGetBulkMsg(ip, oid, comm=COMM, port=161):
    
    errorIndication, errorStatus, errorIndex, varBinds = cmdgen.CommandGenerator().bulkCmd(
        cmdgen.CommunityData( comm ), 
        cmdgen.UdpTransportTarget( ( ip, port) ),
        0, 25,
        oid,
    )
    
    rs = []    
    # Check for errors and print out results
    if errorIndication:
        raise Exception(errorIndication)
    else:
        if errorStatus:
            raise Exception('%s at %s' % (
                errorStatus.prettyPrint(),
                errorIndex and varBinds[int(errorIndex)-1][0] or '?'
                )
            )
        else:
            for varBind in varBinds:
                for name, val in varBind:
                    rs.append({str(name): str(val)})
            return rs
    
    return None



