#!/usr/bin/python
#-*- coding: utf-8 -*-

import sys, json
import yaml, os, logging
from utm_api import Logger

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/utm_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger(logName='utm', logDir='/var/log/zabbix-agent', logFile='utm.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG).instance()

def procList():
    ret = { "data": [] }
    for item in cfg['vm_proc']:
        ret["data"].append( { "{#NAME}": item } )
    return ret

def netList():
    ret = { "data": [] }
    for item in cfg['vm_net']:
        ret["data"].append( { "{#NAME}": item } )
    return ret


if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            if chkType == "NETLIST":
                print ( json.dumps(netList(), indent=4) )
                exit(0)
            elif chkType == "PROCLIST":
                print ( json.dumps(procList(), indent=4) )
                exit(0)
            
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger.exception(e)
        print None

