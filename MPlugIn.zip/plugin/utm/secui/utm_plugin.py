#!/usr/bin/python
#-*- coding: utf-8 -*-

import utm_api
import sys, yaml, os, logging
from utm_api import Logger

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/utm_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger(logName='utm', logDir='/var/log/zabbix-agent', logFile='utm.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG).instance()

ip=cfg['vm_ip']
#"net" : """ ethtool %s | grep "Link detected:" | awk '{print $3}' """,
scripts = { 
           "ping" : """1.3.6.1.4.1.9560.1.10.2.1.1.0""",
           "proc" : """1.3.6.1.4.1.9560.1.10.2.6.%s""" ,
           "mem" : """1.3.6.1.4.1.9560.1.10.2.3.2""",
           "disk" : """1.3.6.1.4.1.9560.1.10.2.3.3""",
           "net" : """1.3.6.1.4.1.9560.1.10.2.2.1.4.%s""",
           "cpu_load": """1.3.6.1.4.1.9560.1.10.2.1.4.0""",
           "cpu_util" : """1.3.6.1.4.1.9560.1.10.2.3.1.1.6.0""",
           "conntrack" : """1.3.6.1.4.1.9560.1.10.2.4.37.0""",
           "dhcp_used" : """1.3.6.1.4.1.9560.1.10.2.3.4.1""",
           "rx_byte": """1.3.6.1.4.1.9560.1.10.2.2.1.5.%s""",
           "tx_byte": """1.3.6.1.4.1.9560.1.10.2.2.1.6.%s""",
           }


def checkPing(ip):
    try :
        utm_api.sendGetOneMsg(ip, scripts['ping'])
        return 1
    except Exception, e:
        logger.exception(e)
    return 0

def procStatus( ip, proc ):
    try:
        procIdx = None
        # DHCP, FW, NAT, VPN, IPS, APPCTRL, WF
        if str(proc).upper() == 'DHCP' :
            procIdx = '1.0'
        elif str(proc).upper() == 'FW' :
            procIdx = '2.0'
        elif str(proc).upper() == 'NAT' :
            procIdx = '3.0'
        elif str(proc).upper() == 'VPN' :
            procIdx = '4.0'
        elif str(proc).upper() == 'IPS' :
            procIdx = '5.0'
        elif str(proc).upper() == 'APPCTRL' :
            procIdx = '6.0'
        elif str(proc).upper() == 'WF' :
            procIdx = '7.0'
        else:
            logger.error('Unknown Proc Name=%s'%str(proc))
            return None
        
        ret = utm_api.sendGetOneMsg( ip, scripts["proc"]%procIdx )
        if ret != None and len(ret) > 0 and ret[0][1] != None :
            return int(ret[0][1])
        
        logger.error('Invalid Proc Return Value, val=%s'%str(ret))
        return None
    except Exception, e:
        logger.exception(e)
        return None

def memUsage( ip, _type ):
    try:
        ret = utm_api.sendGetBulkMsg( ip, scripts["mem"] )
        
        total = used = free = util = None
        for val in ret:
            if val.has_key( '1.3.6.1.4.1.9560.1.10.2.3.2.1.0' ) :
                total = int(val['1.3.6.1.4.1.9560.1.10.2.3.2.1.0'])
            elif val.has_key( '1.3.6.1.4.1.9560.1.10.2.3.2.2.0' ) :
                used = int(val['1.3.6.1.4.1.9560.1.10.2.3.2.2.0'])
            elif val.has_key( '1.3.6.1.4.1.9560.1.10.2.3.2.3.0' ) :
                free = int(val['1.3.6.1.4.1.9560.1.10.2.3.2.3.0'])
            elif val.has_key( '1.3.6.1.4.1.9560.1.10.2.3.2.4.0' ) :
                util = int(val['1.3.6.1.4.1.9560.1.10.2.3.2.4.0'])
        
        if str(_type).upper() == "TOTAL":   return total
        elif str(_type).upper() == "USED":  return used
        elif str(_type).upper() == "FREE":  return free
        elif str(_type).upper() == "UTIL":  return util
        else:
            logger.error('Unknown Mem Type, type=%s'%str(_type))
            return None
        
    except Exception, e:
        logger.exception(e)
        return None
    
def diskUsage( ip, _type ):
    try:
        ret = utm_api.sendGetBulkMsg( ip, scripts["disk"] )
        
        bsize = total = used = free = util = None
        for val in ret:
            if val.has_key( '1.3.6.1.4.1.9560.1.10.2.3.3.1.0' ) :
                bsize = int(val['1.3.6.1.4.1.9560.1.10.2.3.3.1.0'])
            elif val.has_key( '1.3.6.1.4.1.9560.1.10.2.3.3.2.0' ) :
                total = int(val['1.3.6.1.4.1.9560.1.10.2.3.3.2.0'])
            elif val.has_key( '1.3.6.1.4.1.9560.1.10.2.3.3.3.0' ) :
                used = int(val['1.3.6.1.4.1.9560.1.10.2.3.3.3.0'])
            elif val.has_key( '1.3.6.1.4.1.9560.1.10.2.3.3.4.0' ) :
                free = int(val['1.3.6.1.4.1.9560.1.10.2.3.3.4.0'])
            elif val.has_key( '1.3.6.1.4.1.9560.1.10.2.3.3.6.0' ) :
                util = int(val['1.3.6.1.4.1.9560.1.10.2.3.3.6.0'])
        
        if str(_type).upper() == "TOTAL":   return total * bsize
        elif str(_type).upper() == "USED":  return used * bsize
        elif str(_type).upper() == "FREE":  return free * bsize
        elif str(_type).upper() == "UTIL":  return util
        else:
            logger.error('Unknown Disk Type, type=%s'%str(_type))
            return None
    except Exception, e:
        logger.exception(e)
        return None

def netStatus( ip, name ):
    try:
        idx = str(name).replace('eth', '')
        ret = utm_api.sendGetOneMsg( ip, scripts["net"]%idx )
        if ret != None and len(ret) > 0 and str(ret[0][1]).count('UP') > 0 :
            return 1
        return 0
    except Exception, e:
        logger.exception(e)
        return None

def cpuUsage( ip, _type ):
    try:
        if str(_type).upper() == "UTIL" :
            ret = utm_api.sendGetOneMsg( ip, scripts["cpu_util"] )
            if ret != None and len(ret) > 0 and ret[0][1] != None :
                return float(ret[0][1])
        elif str(_type).upper() == "LOAD" :
            ret = utm_api.sendGetOneMsg( ip, scripts["cpu_load"] )
            if ret != None and len(ret) > 0 and ret[0][1] != None :
                vals = ret[0][1].split(',')
                return float(str(vals[0]).strip())
        
        logger.error('Unknown Cpu Type, type=%s'%str(_type))
        return None
    except Exception, e:
        logger.exception(e)
        return None

def conntrack( ip ):
    try:
        ret = utm_api.sendGetOneMsg( ip, scripts["conntrack"] )
        if ret != None and len(ret) > 0 and ret[0][1] != None :
            return int(ret[0][1])
        
        logger.error('Invalid Conntrack Return Value, val=%s'%str(ret))
        return None
    except Exception, e:
        logger.exception(e)
        return None

def dhcpUsage( ip ):
    try:
        ret = utm_api.sendGetOneMsg( ip, scripts["dhcp_used"] ) 
        if ret != None and len(ret) > 0 and ret[0][1] != None :
            return int(ret[0][1])
        logger.error('Invalid Dhcp Return Value, val=%s'%str(ret))
        return None
    except Exception, e:
        logger.exception(e)
        return None

def netRate( ip, name, _type ):
    try:
        import time
        
        fName = None
        if not os.path.exists( '/var/log/zabbix-agent/dat' ) :
            os.mkdir('/var/log/zabbix-agent/dat')
        if str(_type).lower() == 'rx':
            fName = '/var/log/zabbix-agent/dat/utm_%s_rx_bps.dat'%name
            bName = 'rx_byte'
        else:
            fName = '/var/log/zabbix-agent/dat/utm_%s_tx_bps.dat'%name
            bName = 'tx_byte'
        
        fd = os.open(fName, os.O_RDWR|os.O_CREAT)
        fileobj = os.fdopen(fd, 'rw+b')
        prevTxt = fileobj.read()
        
        idx = str(name).replace('eth', '')
        ret = utm_api.sendGetOneMsg( ip, scripts[bName]%idx )
        print ret
        if ret != None and len(ret) > 0 and ret[0][1] != None :
            bits = int(ret[0][1])*8
        else :
            return None
        
        ts = time.time()
        txt = str(bits) + "," + str(ts)
        
        fileobj.seek(0)
        fileobj.truncate()
        
        fileobj.write(txt)
        fileobj.flush()
        fileobj.close()
        
        if prevTxt != None and str(prevTxt).find(',') >= 0 :
            bitts = str(prevTxt).split(',')
            prevBits = int(bitts[0])
            prevTs = float(bitts[1])
            
            if bits >= prevBits and ts > prevTs :
                bps = int((bits-prevBits)/(ts-prevTs))
            else:
                bps = None
        else :
            bps = None
        
        return bps
    except ValueError, ve:
        if fName != None and os.path.isfile( fName ):
            os.remove(fName)
        logger.exception(ve)
        return None
    except Exception, e:
        logger.error(fName)
        logger.exception(e)
        return None

def netRxRate( ip, name ):
    return netRate(ip, name, 'rx')

def netTxRate( ip, name ):
    return netRate(ip, name, 'tx')

if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            if chkType == "PING":
                print ( checkPing(ip) )
                exit(0)
            elif chkType == "PROC":
                print ( procStatus(ip, sys.argv[2]) )
                exit(0)
            elif chkType == "MEM":
                print ( memUsage(ip, sys.argv[2]) )
                exit(0)
            elif chkType == "DISK":
                print ( diskUsage(ip, sys.argv[2]) )
                exit(0)
            elif chkType == "NET":
                if str(sys.argv[2]).upper() == 'CONNTRACK' :
                    print ( conntrack(ip) )
                    exit(0)
                elif str(sys.argv[2]).upper() == 'STATUS' :
                    print ( netStatus(ip, sys.argv[3]) )
                    exit(0)
                elif str(sys.argv[2]).upper() == 'RX_RATE' :
                    print ( netRxRate(ip, sys.argv[3]) )
                    exit(0)
                elif str(sys.argv[2]).upper() == 'TX_RATE' :
                    print ( netTxRate(ip, sys.argv[3]) )
                    exit(0)
            elif chkType == "CPU":
                print ( cpuUsage(ip, sys.argv[2]) )
                exit(0)
            elif chkType == "DHCP":
                print ( dhcpUsage(ip) )
                exit(0)
        
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger.exception(e)
        print None

