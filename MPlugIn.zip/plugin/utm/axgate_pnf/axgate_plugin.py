#!/usr/bin/python
#-*- coding: utf-8 -*-

import sys, json, os, re, axgate_api
import ruamel.yaml as yaml
from axgate_api import logger

VPN_STATUS_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/vpn_status.json'

def cpu(ip, type):
    try:
        
        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show resource cpu")
        
        lstBody = retBody.split('\n')

        if type == "cpuload" :
            if lstBody[0].find('result:0') > -1 :
                return None
            else :
                str = lstBody[3]
                if str[0] != 'T' :
                    return None
                    
                str = str.replace ('  ', ' ');
                sp = str.split (' ');

                cpuload = 100 -  ( float(sp[5]) / float( sp[1] ) * 100.0 )
                cpuload = format (cpuload, '.2f')
                if cpuload == '0.00' :
                    return '0'
                else :
                    return cpuload
        
        if type == "cpuutil" :
            if lstBody[0].find('result:0') > -1 :
                return None
            else :
                str = lstBody[3]
                if str[0] != 'T' :
                    return None
                    
                str = str.replace ('  ', ' ');
                sp = str.split (' ');

                cpuutil = float(sp[9]) / float( sp[1] ) * 100.0
                cpuutil = format (cpuutil, '.2f')
                if cpuutil == '0.00' :
                    return '0'
                else :
                    return cpuutil
        
        # print retBody
    except Exception, e:
        axgate_api.login(ip)
        logger(e, type)
        return None


def conntrack(ip, type):
    try:
        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show utm firewall")
                
        lstBody = retBody.split('\n')
        if lstBody[0].find('result:0') > -1 :
            return None
        pattern = "current sessions: [0-9]+"
        match = re.search(pattern, retBody)

        retStr = match.group() 
        conntrack = retStr.replace('current sessions: ', '')  

        # print retBody
        return conntrack

    except Exception, e:
        axgate_api.login(ip)
        logger(e, type)
        return None

def mem(ip, type):
    try:
        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show resource memory")

        lstBody = retBody.split('\n')

        if lstBody[0].find('result:0') > -1 :
            return None
        else :
            str = lstBody[3]
            if str[0] != 'T' :
                return None
                
            str = str.replace ('  ', ' ');
            sp = str.split (' ');

            mem = float(sp[5]) / float( sp[1] ) * 100.0
            mem = int( round (mem) )
            
            return mem
           
        # print retBody

    except Exception, e:
        axgate_api.login(ip)
        logger(e, type)
        return None

        
def disk(ip, type):
    try:
        
        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show resource storage")

        lstBody = retBody.split('\n')

        if lstBody[0].find('result:0') > -1 :
            return None
        else :
            pattern = "ext4 [0-9,' ']+"
            match = re.search(pattern, retBody)
            str = match.group() 
            str = str.replace('ext4 ', '')  
            
            sp = str.split (' ');

            disk = float(sp[2]) / float( sp[0] ) * 100.0

            return int( round (disk) )
           
    except Exception, e:
        axgate_api.login(ip)
        logger(e, type)
        return None

def connection(ip, type):
    try:
        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=ping 8.8.8.8 timeout 5 count 1")
                
        lstBody = retBody.split('\n')
        
        if lstBody[1].find('PING') > -1 :
            return 1
        else :
            return 0
            
    except Exception, e:
        axgate_api.login(ip)
        logger(e, type)
        return None
    
def isNumber(s):
  try:
    float(s)
    return True
  except ValueError:
    return False
    
    
def dhcp(ip, type):
    try:
        
        lstBody = []
        
        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show ip dhcp leases summary")

        lstBody = retBody.split('\n')

        if lstBody[0].find('result:0') > -1 :
            return 0
            

        return retBody.count ('  active  ')
        
    except Exception, e:
        axgate_api.login(ip)
        logger(e, type)
        return None


def calcRate(_if, _bytes, _type):
    try:
        import time
        
        dir_name = '/mnt/flash/data/onebox/zabbix/dat/'
        fName = None
        if not os.path.exists( dir_name ) :
            os.mkdir(dir_name)
        if str(_type).lower() == 'rx':
            fName = dir_name + 'utm_%s_rx_bps.dat'%_if
        else:
            fName = dir_name + 'utm_%s_tx_bps.dat'%_if

        
        fd = os.open(fName, os.O_RDWR|os.O_CREAT)
        fileobj = os.fdopen(fd, 'rw+b')
        prevTxt = fileobj.read()
        
        bits = int(_bytes)*8
        
        ts = time.time()
        txt = str(bits) + "," + str(ts)
        
        fileobj.seek(0)
        fileobj.truncate()
        
        fileobj.write(txt)
        fileobj.flush()
        fileobj.close()
        
        if prevTxt != None and str(prevTxt).find(',') >= 0 :
            bitts = str(prevTxt).split(',')
            prevBits = int(bitts[0])
            prevTs = float(bitts[1])
            
            if bits >= prevBits and ts > prevTs :
                bps = (bits-prevBits)/(ts-prevTs)
            else:
                bps = None
        else :
            bps = None
        
        return int(bps)
    except ValueError, ve:
        if fName != None and os.path.isfile( fName ):
            os.remove(fName)
        logger(ve)
        return None
    except Exception, e:
        logger(fName)
        logger(e)
        return None
            
        
def trafficInfo( ip, _if, _type ):

    try:
        
        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show ip interface brief")

        lstBody = retBody.split('\n')
                
        if lstBody[0].find('result:0') > -1 :
            return None

        for r in lstBody :
            line = re.sub(' +',' ',r)
            if _if in line :
                lst_line = line.split(" ")
                if_status = lst_line[2] # down, up

        if if_status is not None : 
            if if_status == 'down' :
                return None
        
        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show resource traffic")

                
        # print retBody
        
        lstBody2 = retBody.split('\n')
        
        if lstBody2[0] == 0 :
            return None
        
        for r in lstBody2:
            line = re.sub(' +',' ',r)
            if _if in line :
                # idx(3) in bytes, idx(4) out bytes
                lst_value = line.split(" ")

                if_rx = lst_value[3] 
                if_tx = lst_value[4]
       
                if str(_type).lower() == 'rx_rate' :
                    return calcRate(_if, if_rx, 'rx')
                    
                elif str(_type).lower() == 'tx_rate' :
                    return calcRate(_if, if_tx, 'tx')
                    
                break
        
        logger( 'Unknown Type, if=%s, type=%s'%(str(_if), str(_type)) )
        return None
    except Exception, e:
        logger(e, _type)
        return None

def daemon(ip, process):
    try:
            
        if process == "vpn" :
            return vpn(ip)

        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show checksum detail")
        
        lstBody = retBody.split('\n')
        
        if lstBody[0].find('result:0') > -1 :
            return None

        for r in lstBody :
            if r.find (process) > -1 :
                if r.find ('Success') > -1 :
                    return 1
        return 0
        
    except Exception, e:
        logger(e, process)
        return None
        

def netstatus( ip, _if ):
    try:
        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show ip interface brief")

        lstBody = retBody.split('\n')
                
        if lstBody[0].find('result:0') > -1 :
            return None

        for r in lstBody :
            line = re.sub(' +',' ',r)
            if _if in line :
                lst_line = line.split(" ")
                if_status = lst_line[2] # down, up
                
        if if_status == 'up' :
            return 1
        elif if_status == 'down' :
            return 0
        
        return None
    except Exception, e:
        logger(e, 'netstatus')
        return None

def save_vpn_status(total, active):
    try:
        # Delete 
        if os.path.isfile(VPN_STATUS_FILE):
            os.remove(VPN_STATUS_FILE)
    
        vpn_dict = {'vpn_totalcount': total, 'vpn_activecount' : active}

        with open( VPN_STATUS_FILE, 'w') as file :
            file.write(json.dumps(vpn_dict)) 
            

    except Exception, e:
        logger(e, 'save_vpn_status')
        
def vpn(ip):
    try:
            
        lstSSLType = ['dcube', 'ipsec']

        total = 0
        active = 0
        inactive = 0
        for SSLType in lstSSLType : 
                
            retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip,
                    header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show %s tunnel-count status" % SSLType )

            # print retBody
            lstBody = retBody.split('\n')
            
            try :
                if lstBody[0].find('result:1') > -1 :
                    sTotal = lstBody[1]
                    sActive = lstBody[2]
                    sInactive = lstBody[3]
                    
                    if sTotal.find ('total:') > -1 :
                        total = total + int( sTotal.replace('total:', '') )
                    
                    if sActive.find('active:') > -1 :
                        active = active + int( sActive.replace('active:', '') )
                        
                    if sInactive.find('inactive:') > -1 :
                        inactive = inactive + int( sInactive.replace('inactive:', '') )
                elif lstBody[0].find('result:0') > -1 :
                    continue
                        
                else :
                    return None
            except :
                return None

        save_vpn_status( total, active )
                
        if total <= 0 :
            return None
        elif total > 0 and inactive > 0 :
            return 0
        elif total > 0 and inactive == 0 :
            return 1

    except Exception, e:
        axgate_api.login(ip)
        logger(e, 'vpn')


def vpn_status (mode):
    try:
        if not os.path.isfile(VPN_STATUS_FILE):
            return None

        with open(VPN_STATUS_FILE, 'r') as file:
            data = json.load(file)
    
        ret = data[mode] 
        if ret == '' : 
            return None
        else :
            return ret
    
    except Exception, e:
        logger(e, 'vpn_status')

        
def vpncount(ip):
    try:
            
        lstSSLType = ['dcube', 'ipsec']

        count_total = 0
        NotSupport_Count = 0
        for SSLType in lstSSLType : 
            retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip,
                    header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show %s tunnel-count all" % SSLType )
            # print retBody
            lstBody = retBody.split('\n')
            try :
                if lstBody[0].find('result:1') > -1 :
                    sCount = lstBody[1]
                    if sCount.find ('count:') > -1 :
                        cnt = int( sCount.replace('count:', '') )
                        if cnt > 0 :
                            count_total = count_total + cnt
                        elif cnt == -1 :
                            NotSupport_Count += 1
                    
                elif lstBody[0].find('result:0') > -1 :
                    NotSupport_Count += 1
                    continue

                else :
                    return None
                    
            except :
                return None
          
        if NotSupport_Count == 3 :
            return None
        else : 
            return count_total
        
    except Exception, e:
        logger(e, 'vpncount')

        
def license(ip):
    try:

        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip,
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show license check")

        # print retBody
        lstBody = retBody.split('\n')
        
        try :
            if lstBody[0].find('result:1') > -1 :
                sRemaining = lstBody[4]
                if sRemaining.find ('remaining-days:') > -1 :
                    return int( sRemaining.replace('remaining-days:', '') )
        except :
            return None

        return None

    except Exception, e:
        logger(e, 'license')
        
        
def chkInternet( ip ):
    _SDEBUG = False
    _FDEBUG = True
    cmd = ''
    ret = ''
    try:
        cmd = axgate_api.CMDS['INTERNET1']
        ret = None
        try:
            ret = axgate_api.run( logger, ip, cmd )
            if int(ret) > 0 :
                if _SDEBUG : logger.debug("Succ to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
                return 1
        except Exception, e:
            logger("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
            logger(e)
        if _FDEBUG : logger.debug("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
        
        cmd = axgate_api.CMDS['INTERNET2']
        ret = None
        try:
            ret = axgate_api.run( logger, ip, cmd )
            if int(ret) > 0 :
                if _SDEBUG : logger.debug("Succ, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
                return 1
        except Exception, e:
            logger("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
            logger(e)
        if _FDEBUG : logger.debug("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
        
        cmd = axgate_api.CMDS['INTERNET3']
        ret = None
        try:
            ret = axgate_api.run( logger, ip, cmd )
            if int(ret) == 0 :
                if _SDEBUG : logger.debug("Succ, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
                return 1
        except Exception, e:
            logger("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
            logger(e)
        if _FDEBUG : logger.debug("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
        
        cmd = axgate_api.CMDS['INTERNET4'] % ORCHM_IP
        ret = None
        try:
            ret = axgate_api.run( logger, ip, cmd )
            if int(ret) == 0 :
                if _SDEBUG : logger.debug("Succ, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
                return 1
            else:
                if _FDEBUG : logger.debug("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
                return 0
        except Exception, e:
            logger("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
            logger(e)
    except Exception, e:
        logger(e, 'chkInternet' )
        logger('Internet Error, cmd=%s, ret=%s'%(str(cmd), str(ret)))
    return None


if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:

            ip = axgate_api.IP
            chkType = str(sys.argv[1]).lower()
            
            if chkType == "login":
                login(ip)
                exit(0)
            elif chkType == "cpuload":
                print( cpu(ip, chkType) )
                exit(0)

            elif chkType == "cpuutil":
                print( cpu(ip, chkType) )
                exit(0)
                
            elif chkType == "conntrack":
                print (conntrack(ip, chkType))
                exit(0)
                
            elif chkType == "mem":
                print ( mem(ip, chkType) )
                exit(0)
                
            elif chkType == "disk":
                print ( disk(ip, chkType) )
                exit(0)
                
            elif chkType == "connection" or chkType == "internet":
                print ( connection(ip, chkType) )
                exit(0)
                
            elif chkType == "dhcp":
                print ( dhcp(ip, chkType) )
                exit(0)

            elif chkType == "traffic":
                print( trafficInfo(ip, str(sys.argv[3]), str(sys.argv[2])) )
                exit(0)
                
            elif chkType == "netstatus":
                print ( netstatus(ip, str(sys.argv[2]) ) )
                exit(0)

                
            elif chkType == "daemon":
                print ( daemon(ip, str( sys.argv[2]) ))
                exit(0)
                
            elif chkType == "vpn":
                print ( vpn(ip) )
                exit(0)
                
            elif chkType == "vpncount":
                print ( vpncount(ip) )
                exit(0)

            elif chkType == "vpn_totalcount":
                print ( vpn_status('vpn_totalcount') )
                exit(0)
                
            elif chkType == "vpn_activecount":
                print ( vpn_status('vpn_activecount'))
                exit(0)

            elif chkType == "license":
                print ( license(ip) )
                exit(0)
        logger('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger(e)
        print None