#!/usr/bin/python
#-*- coding: utf-8 -*-
import sys, json, os, re, axgate_api
from axgate_api import logger
    
def netList( ip ):
    if not os.path.isfile(axgate_api.SESSION_FILENAME) :
        axgate_api.login(ip)

    info = { "data": [] }
    try:
        retHeaders, retBody = axgate_api.callAPI( axgate_api.CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % axgate_api.get_sessionID() }, reqBody="cmd=show ip interface brief")
        lstBody = retBody.split('\n')
        if lstBody[0] == 0 :
            return None
        else :
            pattern = "[a-z]{2,}[0-9]{1,2}"
            match = re.findall(pattern, retBody)
            if match.count == 0 :
                return None
        
            for _if in match :
                if _if in axgate_api.cfg['vm_net']:
                    info['data'].append( { "{#NAME}": _if } )
        return info
    except Exception, e:
        logger(e, 'netList')
        return None

def daemonList():
    ret = { "data": [] }
    for item in axgate_api.cfg['vm_daemon']:
        ret["data"].append( { "{#NAME}": item } )
    return ret

    
if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            ip = axgate_api.IP
            chkType = str(sys.argv[1]).upper()
            if str(chkType).upper() == "NETLIST":
                print( json.dumps(netList(ip), indent=4) )
                exit(0)
            elif str(chkType).upper() == "DAEMONLIST":
                print( json.dumps(daemonList(), indent=4) )
                exit(0)
        logger('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        print None
