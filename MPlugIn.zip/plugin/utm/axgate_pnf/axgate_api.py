#-*- coding: utf-8 -*-
import json, os, sys, re
import time
import urllib2, ssl
import ruamel.yaml as yaml

LOGFILE = '/mnt/flash/data/onebox/zabbix/log/axgate.log'
SESSION_FILENAME = '/mnt/flash/data/onebox/zabbix/plugin/_session'
HEADER = { "content-Type": "application/json;charset=UTF-8", "accept":"application/json" }
CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/axgate_cfg.yaml'
CMDS = {
        "EXEC" : """https://%s:443/restrict/exec.cgi""",
        "AUTH" : """https://%s:443/login.cgi""",
       }
       

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f, Loader=yaml.RoundTripLoader)
    
IP = cfg['vm_ip']
ID = cfg['vm_id']
PASSWD = cfg['vm_passwd']

def logger ( S, argtype='' ) :
    if os.path.isfile (LOGFILE) : 
        f = open(LOGFILE, 'a')
    else :
        f = open(LOGFILE, 'w')

    now = time.localtime()
    TimeFormat = "[%04d-%02d-%02d %02d:%02d:%02d] " % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
    TypeFormat = "[%s] " % argtype
    
    f.write ( TimeFormat + TypeFormat + str(S) + "\n")
    f.close()

def get_sessionID():
    sessionid = ''
    try:
        # Get Session
        fname = SESSION_FILENAME
        if os.path.isfile(fname) :
            f = open(fname, "r")
            sessionid = f.readline ()
            f.close
    except :
        sessionid = ''
    return sessionid

def login( ip, _id=ID, passwd=PASSWD ):
    try : 
        retHeaders, retBody = callAPI( CMDS['AUTH'] % ip , header={"content-Type": "application/x-www-form-urlencoded","accept-charset": "utf-8"}, reqBody='username=%s&password=%s&desc=VNF'%( _id, passwd) )
        #print retHeaders
        #print retBody
        pattern = "SessionID=[\w]{30,}"
        match = re.search(pattern, str(retHeaders))
        retStr = match.group() 
        sessionid = retStr.replace('SessionID=', '')  
        if str(retBody).count("errorMsg") > 0 : 
            return
        else: 
            f = open(SESSION_FILENAME, "w")
            f.write (sessionid)
            f.close        
            return
    except Exception, e:
        print e
        logger(e)
        return

def callAPI( _url, _method='POST', header=HEADER, reqBody=None, returnHeader=False ):
    try :
        if reqBody == None:
            strBody = None
        elif type(reqBody) == str:
            strBody = reqBody
        else:
            strBody = json.dumps( reqBody )
        
        req = urllib2.Request(_url, strBody, header)

        response = urllib2.urlopen(req, context=ssl._create_unverified_context())    
        
        retHeader = response.info().getheader('Set-cookie')
        retBody = response.read()
        
        # print retHeader
        # print retBody
        
    except Exception, e:
        return None, None
        
    return retHeader, retBody

