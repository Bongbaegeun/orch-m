#!/usr/bin/python
#-*- coding: utf-8 -*-

import axgate_api
from axgate_api import Logger
import sys, json, yaml, os, logging, re

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/axgate_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger( logName='axgate_disc', logDir='/var/log/zabbix-agent', logFile='axgate_disc.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG ).instance()

ip = cfg['vm_ip']
ID = cfg['vm_id']
PASSWD = cfg['vm_passwd']

CMDS = {
        "EXEC" :            """https://%s:443/restrict/exec.cgi""",
        "AUTH" :          """https://%s:443/login.cgi""",
       }




def login( ip, _id=ID, passwd=PASSWD ):
    try:
        # Get Session
        fname = axgate_api.SESSION_FILENAME

        if os.path.isfile(fname) :
            f = open(fname, "r")
            sessionid = f.readline ()
            f.close

            # SessionID check
            if len ( sessionid ) > 0 :
                retHeaders, retBody = axgate_api.callAPI( CMDS['EXEC']%ip,
                    header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s" % sessionid }, reqBody="cmd=show resource cpu")

                lstBody = retBody.split('\n')

                if lstBody[0].find('result:1') > -1 :
                    return sessionid
    except :
        sessionid = ''

        
    # re login
    try : 
        retHeaders, retBody = axgate_api.callAPI( CMDS['AUTH'] % ip , header={"content-Type": "application/x-www-form-urlencoded","accept-charset": "utf-8"}, reqBody='username=%s&password=%s&desc=VNF'%( _id, passwd) )

        # print retHeaders
        # print retBody
        
        pattern = "SessionID=[\w]{30,}"
        match = re.search(pattern, str(retHeaders))

        retStr = match.group() 
        sessionid = retStr.replace('SessionID=', '')  
        
        if str(retBody).count("errorMsg") > 0 : 
            return False
        else: 
            f = open(fname, "w")
            f.write (sessionid)
            f.close        
            return sessionid
            
    except Exception, e:
        logger.exception(e)
        return False



def netList( ip ):
    info = { "data": [] }
    
    sessionid = login (ip)
    
    if sessionid == 0 :
        logger.error( 'login Error, ip=%s, id=%s, pw=%s'%(str(ip), str(ID), str(PASSWD)) )
        return None
        
    try:
        
        retHeaders, retBody = axgate_api.callAPI( CMDS['EXEC']%ip, 
                header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*", "Cookie" : "SessionID=%s"%sessionid }, reqBody="cmd=show ip interface brief")
        
        lstBody = retBody.split('\n')

        if lstBody[0] == 0 :
            return None
        else :
            pattern = "[a-z]{2,}[0-9]{1,2}"
            match = re.findall(pattern, retBody)
            if match.count == 0 :
                return None
        
            for _if in match :
                if _if in cfg['vm_net']:
                    info['data'].append( { "{#NAME}": _if } )
        
        return info
    except Exception, e:
        logger.exception(e)
        return None

def daemonList():
    ret = { "data": [] }
    for item in cfg['vm_daemon']:
        ret["data"].append( { "{#NAME}": item } )
    return ret

    
if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            
            if str(chkType).upper() == "NETLIST":
                print( json.dumps(netList(ip), indent=4) )
                exit(0)
            elif str(chkType).upper() == "DAEMONLIST":
                print( json.dumps(daemonList(), indent=4) )
                exit(0)
                
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger.exception(e)
        print None




