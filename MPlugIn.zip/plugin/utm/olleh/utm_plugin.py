#!/usr/bin/python
#-*- coding: utf-8 -*-

import utm_api
import sys, yaml, os, logging
from utm_api import Logger

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/utm_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger(logName='utm', logDir='/var/log/zabbix-agent', logFile='utm.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG).instance()

ip=cfg['vm_ip']
#"net" : """ ethtool %s | grep "Link detected:" | awk '{print $3}' """,
scripts = { 
           "proc" : """ ps -ef | grep -v "grep" | grep -c "%s" """ ,
           "mem" : """ free | grep  "%s" | awk '{print $2":"$3":"$4":"$6":"$7}' """,
           "disk" : """ df | grep -v "Filesystem" | awk '{print $6":"$2":"$3":"$4}' """,
           "net" : """ ip link show %s | grep -c ",UP," """,
           "cpu_load" : """ cpu_info=$(top -bn 2 -d 0.5 | grep "load average" | tail -n 1); loads=${cpu_info##*:}; echo ${loads%%,*} """,
           "cpu_util" : """ cpu_info=$(top -bn 2 -d 0.5 | grep "Cpu" | tail -n 1); idle=${cpu_info##*ni,};usage=${idle%%%id,*};echo $usage """,
           "cpu_cnt" : """ cat /proc/cpuinfo | grep -c "processor" """,
           "conntrack" : """ conntrack -C """,
           "dhcp_used" : """ cat /var/lib/dhcp/dhcpd.leases | grep -c "binding state active" """,
           "job" : """ jobcontrol list | grep %s | grep -c "start.ok" """,
           "rx_byte": """ cat /sys/class/net/%s/statistics/rx_bytes """,
           "tx_byte": """ cat /sys/class/net/%s/statistics/tx_bytes """,
           "internet": """ timeout 3 nslookup kt.com | grep -c "kt.com" """,
#            "internet": """ gw=$(ip route | grep default | awk '{print $3}'); gwping=$(ping -c 1 -w 1 $gw | grep 'received' | awk '{print $4}'); remping=$(ping -c 1 -w 1 8.8.8.8 | grep 'received' | awk '{print $4}'); echo "$gwping,$remping" """,
           }


def checkPing(ip):
    try :
        utm_api.run( ip, 'ls', 2 )
        return 1
    except Exception, e:
        logger.exception(e)
    return 0

def procStatus( ip, proc ):
    try:
        ret = utm_api.run( ip, scripts["proc"]%proc )
        return int(ret)
    except Exception, e:
        logger.exception(e)
        return None

def memUsage( ip, _type, isSwap=False ):
    mem = "Mem"
    if isSwap : mem = "Swap"
    try:
        ret = utm_api.run( ip, scripts["mem"]%(mem) )
            
        _res = str(ret).split(':')
        total = int( _res[0].strip() )
        used = int( _res[1].strip() )
        free = int( _res[2].strip() )
        buff = int( (lambda x: '0' if x.strip() == '' or x == None else x.strip())(_res[3]) )
        cach = int( (lambda x: '0' if x.strip() == '' or x == None else x.strip())(_res[4]) )
        
        if str(_type).upper() == "TOTAL":   return total
        elif str(_type).upper() == "USED":  return used - buff - cach
        elif str(_type).upper() == "FREE":  return free + buff + cach
        elif str(_type).upper() == "UTIL":  return (used - buff - cach )*100/total
        else:
            logger.error('Unknown Mem Type, type=%s'%str(_type))
            return None
        
    except Exception, e:
        logger.exception(e)
        return None
    
def diskUsage( ip, _type, name ):
    res = utm_api.run( ip, scripts["disk"] )
    
    for line in res.split("\n"):
        tmp = line.split(":")
        if str(tmp[0]) == name:
            try:
                ret = 0
                if str(_type).upper() == "TOTAL":
                    ret = int(tmp[2]) + int(tmp[3])
                elif str(_type).upper() == "USED":
                    ret = tmp[2]
                elif str(_type).upper() == "FREE":
                    ret = tmp[3]
                elif str(_type).upper() == "UTIL":
                    ret = round(float(tmp[2])*100.0/float(int(tmp[2]) + int(tmp[3])))
                else:
                    logger.error('Unknown Disk Type, type=%s'%str(_type))
                    return None
                return int(ret)
            except Exception, e:
                logger.exception(e)
                return None
            
    logger.error('Invalid Disk Return Value, val=%s'%str(res))
    return None

def netStatus( ip, name ):
    try:
        res = utm_api.run( ip, scripts["net"]%(name) )
        return int(res)
    except Exception, e:
        logger.exception(e)
        return None

def cpuUsage( ip, _type ):
    try :
        if str(_type).upper() == "COUNT":
            script = scripts["cpu_cnt"]
            return int( utm_api.run( ip, script ) )
        elif str(_type).upper() == "LOAD":
            script = scripts["cpu_load"]
            return float( utm_api.run( ip, script ) )
        elif str(_type).upper() == "UTIL":
            script = scripts["cpu_util"]
            usage = float( utm_api.run( ip, script ) )
            return 100.0 - usage
        else:
            logger.error('Unknown Cpu Type, type=%s'%str(_type))
            return None
    except Exception, e:
        logger.exception(e)
        return None

def conntrack( ip ):
    try: 
        return int( utm_api.run( ip, scripts["conntrack"] ) )
    except Exception, e:
        logger.exception(e)
        return None

def dhcpUsage( ip ):
    try:
        return int( utm_api.run( ip, scripts["dhcp_used"] ) )
    except Exception, e:
        logger.exception(e)
        return None

def jobStatus( ip, name ):
    try:
        return int( utm_api.run( ip, scripts["job"]%name ) )
    except Exception, e:
        logger.exception(e)
        return None

def netRate( ip, name, _type ):
    try:
        import time
        
        fName = None
        if not os.path.exists( '/var/log/zabbix-agent/dat' ) :
            os.mkdir('/var/log/zabbix-agent/dat')
        if str(_type).lower() == 'rx':
            fName = '/var/log/zabbix-agent/dat/utm_%s_rx_bps.dat'%name
            bName = 'rx_byte'
        else:
            fName = '/var/log/zabbix-agent/dat/utm_%s_tx_bps.dat'%name
            bName = 'tx_byte'
        
        fd = os.open(fName, os.O_RDWR|os.O_CREAT)
        fileobj = os.fdopen(fd, 'rw+b')
        prevTxt = fileobj.read()
        
        byte = int( utm_api.run( ip, scripts[bName]%name ) )
        bits = byte*8
        ts = time.time()
        txt = str(bits) + "," + str(ts)
        
        fileobj.seek(0)
        fileobj.truncate()
        
        fileobj.write(txt)
        fileobj.flush()
        fileobj.close()
        
        if prevTxt != None and str(prevTxt).find(',') >= 0 :
            bitts = str(prevTxt).split(',')
            prevBits = int(bitts[0])
            prevTs = float(bitts[1])
            
            if bits >= prevBits and ts > prevTs :
                bps = int((bits-prevBits)/(ts-prevTs))
            else:
                bps = None
        else :
            bps = None
        
        return bps
    except ValueError, ve:
        if fName != None and os.path.isfile( fName ):
            os.remove(fName)
        logger.exception(ve)
        return None
    except Exception, e:
        logger.error(fName)
        logger.exception(e)
        return None

def netRxRate( ip, name ):
    return netRate(ip, name, 'rx')

def netTxRate( ip, name ):
    return netRate(ip, name, 'tx')

def _chkInternet( ip ):
    pingCnt = ''
    try:
        cmd = scripts['internet']
        pingRet = utm_api.run( ip, cmd )
        if pingRet == None or pingRet == '' :
            logger.error('Fail to exec internet_chk, ret=%s'%str(pingRet))
            return 0
        
        pingCnt = str(pingRet).split(',')
        if len(pingCnt) < 2 or \
            (( pingCnt[0] == None or pingCnt[0] == '' or int(pingCnt[0]) < 1) \
             and ( pingCnt[1] == None or pingCnt[1] == '' or int(pingCnt[1]) < 1 )) :
            logger.error('Invalid Internet Ping Return, ret=%s'%str(pingCnt))
            return 0
        return 1
    except Exception, e:
        logger.exception(e)
        logger.error('Internet Ping Error, ret=%s'%str(pingCnt))
        return None
    return 0

def chkInternet( ip ):
    pingCnt = ''
    try:
        cmd = scripts['internet']
        pingRet = utm_api.run( ip, cmd )
        if int(pingRet) < 1:
            return 0
        return 1
    except Exception, e:
        logger.exception(e)
        logger.error('Internet Ping Error, ret=%s'%str(pingCnt))
        return None
    return 0

if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            if chkType == "PING":
                print ( checkPing(ip) )
                exit(0)
            elif chkType == "INTERNET":
                print ( chkInternet(ip) )
                exit(0)
            elif chkType == "PROC":
                print ( procStatus(ip, sys.argv[2]) )
                exit(0)
            elif chkType == "MEM":
                print ( memUsage(ip, sys.argv[2]) )
                exit(0)
            elif chkType == "SWAP":
                print ( memUsage(ip, sys.argv[2], True) )
                exit(0)
            elif chkType == "DISK":
                print ( diskUsage(ip, sys.argv[2], sys.argv[3]) )
                exit(0)
            elif chkType == "NET":
                if str(sys.argv[2]).upper() == 'CONNTRACK' :
                    print ( conntrack(ip) )
                    exit(0)
                elif str(sys.argv[2]).upper() == 'STATUS' :
                    print ( netStatus(ip, sys.argv[3]) )
                    exit(0)
                elif str(sys.argv[2]).upper() == 'RX_RATE' :
                    print ( netRxRate(ip, sys.argv[3]) )
                    exit(0)
                elif str(sys.argv[2]).upper() == 'TX_RATE' :
                    print ( netTxRate(ip, sys.argv[3]) )
                    exit(0)
            elif chkType == "CPU":
                print ( cpuUsage(ip, sys.argv[2]) )
                exit(0)
            elif chkType == "DHCP":
                print ( dhcpUsage(ip) )
                exit(0)
            elif chkType == "JOB":
                print ( jobStatus(ip, sys.argv[2]) )
                exit(0)
            
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger.exception(e)
        print None
