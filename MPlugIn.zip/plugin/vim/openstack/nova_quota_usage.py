#!/usr/bin/python
#-*- coding: utf-8 -*-

import vim_api

import sys, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/vim_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

vim_api.setOSAuth( cfg['vim_id'], cfg["vim_passwd"], cfg["vim_domain"] )
HEADER = vim_api.HEADER
URL = vim_api.NOVA_URL
AUTH_TOKEN = vim_api.AUTH_TOKEN
PRJ_ID = vim_api.PROJECT_ID

def getType(quotaType):
    if str(quotaType).upper() == "TOTAL":
        return 1
    elif str(quotaType).upper() == "USED":
        return 2
    else:
        return 0

def getQuota( field ):
    res = vim_api.callAPI( "GET", HEADER, URL+"/os-quota-class-sets/"+PRJ_ID, token=AUTH_TOKEN )
    return res["quota_class_set"][field]

def getHypervisorStat( field ):
    res = vim_api.callAPI( "GET", HEADER, URL+"/os-hypervisors/statistics", token=AUTH_TOKEN )
    return res["hypervisor_statistics"][field]

def getKeyPairCount():
    res = vim_api.callAPI( "GET", HEADER, URL+"/os-keypairs", token=AUTH_TOKEN )
    return len(res["keypairs"])


def getInstanceInfo(quotaType):
    if quotaType == 1:      return getQuota("instances")
    elif quotaType == 2:    return getHypervisorStat("running_vms")
    else:
        total = getQuota("instances")
        usage = getHypervisorStat("running_vms")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)

def getCoreInfo(quotaType):
    if quotaType == 1:      return getQuota("cores")
    elif quotaType == 2:    return getHypervisorStat("vcpus_used")
    else:
        total = getQuota("cores")
        usage = getHypervisorStat("vcpus_used")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)

def getRamInfo(quotaType):
    if quotaType == 1:      return getQuota("ram")
    elif quotaType == 2:    return getHypervisorStat("memory_mb_used")
    else:
        total = getQuota("ram")
        usage = getHypervisorStat("memory_mb_used")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)

def getDiskInfo(quotaType):
    if quotaType == 1:      return getHypervisorStat("local_gb")
    elif quotaType == 2:    return getHypervisorStat("local_gb_used")
    else:
        total = getHypervisorStat("local_gb")
        usage = getHypervisorStat("local_gb_used")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)

def getKeyPairInfo(quotaType):
    if quotaType == 1:      return getQuota("key_pairs")
    elif quotaType == 2:    return getKeyPairCount()
    else:
        total = getQuota("key_pairs")
        usage = getKeyPairCount()
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)



if __name__ == '__main__':
    
    quotaName = None
    quotaType = None
    if len(sys.argv) >= 2:
        quotaName = sys.argv[1]
    if len(sys.argv) >= 3:
        quotaType = sys.argv[2]
    intType = getType(quotaType)
    
    if str(quotaName).upper() == "INSTANCE":
        print( getInstanceInfo(intType) )
    elif str(quotaName).upper() == "CORE":
        print( getCoreInfo(intType) )
    elif str(quotaName).upper() == "RAM":
        print( getRamInfo(intType) )
    elif str(quotaName).upper() == "DISK":
        print( getDiskInfo(intType) )
    elif str(quotaName).upper() == "KEYPAIR":
        print( getKeyPairInfo(intType) )
    else:
        print( "-1" )
    
