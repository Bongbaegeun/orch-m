#!/usr/bin/python
#-*- coding: utf-8 -*-

import vim_api

import json, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/vim_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

vim_api.setOSAuth( cfg['vim_id'], cfg["vim_passwd"], cfg["vim_domain"] )
HEADER = vim_api.HEADER
URL = vim_api.NOVA_URL
AUTH_TOKEN = vim_api.AUTH_TOKEN

def getVmList(netName):
    ret = { "data": [] }
    
    res = vim_api.callAPI( "GET", HEADER, URL+"/servers/detail", token=AUTH_TOKEN )
    for tarName in cfg ['vim_vm']:
        uuid = ''
        mgmtIP = ''
        for item in res["servers"]:
            name = item["name"]
            if str(name).find(tarName) >= 0 :
                uuid = item["id"]
                if item["addresses"].has_key(netName) :
                    mgmtIP = item["addresses"][netName][0]["addr"]
                else:
                    mgmtIP = ""
                
                break
        ret["data"].append( { "{#UUID}": uuid, "{#NAME}": tarName, "{#MGMTIP}": mgmtIP } )
    
    return ret

if __name__ == '__main__':
    print( json.dumps(getVmList(cfg["vim_mgmt_net"]), indent=4) )