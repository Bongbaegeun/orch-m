#!/bin/bash

VIM_TYPE="VNET"
VIM_NAME="$1"

LOG_DIR="/var/log/zabbix-agent"
LOG_FILE="$LOG_DIR/vim.log"

if [ ! -d $LOG_DIR ]
then
	mkdir -p $LOG_DIR
fi

source /var/onebox/openstack/admin-openrc.sh

vim_status=$(neutron --insecure net-show "$VIM_NAME" -c status -c name 2>&1)
res=$(echo $?)

if [ "$res" == 0 ]
then
        ret=$(echo "$vim_status" | grep status | grep -c "ACTIVE")
        if (( "$ret" < 1 ))
        then
                echo "["`date`"] ERROR :: $VIM_TYPE :: $VIM_NAME" >> $LOG_FILE
                echo "$vim_status" >> $LOG_FILE
        fi
        echo $ret
else
        echo "["`date`"] ERROR :: $VIM_TYPE :: $VIM_NAME :: ""$vim_status" >> $LOG_FILE
fi
