#!/usr/bin/python
#-*- coding: utf-8 -*-

import vim_api

import sys, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/vim_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

vim_api.setOSAuth( cfg['vim_id'], cfg["vim_passwd"], cfg["vim_domain"] )
HEADER = vim_api.HEADER
URL = vim_api.NEUTRON_URL
AUTH_TOKEN = vim_api.AUTH_TOKEN
PRJ_ID = vim_api.PROJECT_ID

def getType(quotaType):
    if str(quotaType).upper() == "TOTAL":
        return 1
    elif str(quotaType).upper() == "USED":
        return 2
    else:
        return 0

def getQuota( field ):
    res = vim_api.callAPI( "GET", HEADER, URL+"/v2.0/quotas/"+PRJ_ID, token=AUTH_TOKEN )
    return res["quota"][field]

def getCount( field ):
    res = vim_api.callAPI( "GET", HEADER, URL+"/v2.0/"+field, token=AUTH_TOKEN )
    return len(res[field.replace("-", "_")])


def getNetInfo(quotaType):
    if quotaType == 1:      return getQuota("network")
    elif quotaType == 2:    return getCount("networks")
    else:
        total = getQuota("network")
        usage = getCount("networks")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)

def getSubNetInfo(quotaType):
    if quotaType == 1:      return getQuota("subnet")
    elif quotaType == 2:    return getCount("subnets")
    else:
        total = getQuota("subnet")
        usage = getCount("subnets")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)

def getPortInfo(quotaType):
    if quotaType == 1:      return getQuota("port")
    elif quotaType == 2:    return getCount("ports")
    else:
        total = getQuota("port")
        usage = getCount("ports")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)

def getRouterInfo(quotaType):
    if quotaType == 1:      return getQuota("router")
    elif quotaType == 2:    return getCount("routers")
    else:
        total = getQuota("router")
        usage = getCount("routers")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)

def getFloatingIpInfo(quotaType):
    if quotaType == 1:      return getQuota("floatingip")
    elif quotaType == 2:    return getCount("floatingips")
    else:
        total = getQuota("floatingip")
        usage = getCount("floatingips")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)

def getSecuGroupInfo(quotaType):
    if quotaType == 1:      return getQuota("security_group")
    elif quotaType == 2:    return getCount("security-groups")
    else:
        total = getQuota("security_group")
        usage = getCount("security-groups")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)

def getSecuGroupRuleInfo(quotaType):
    if quotaType == 1:      return getQuota("security_group_rule")
    elif quotaType == 2:    return getCount("security-group-rules")
    else:
        total = getQuota("security_group_rule")
        usage = getCount("security-group-rules")
        if int(total) == 0 :
            return 0
        return int(usage)*100/int(total)



if __name__ == '__main__':
    
    quotaName = None
    quotaType = None
    if len(sys.argv) >= 2:
        quotaName = sys.argv[1]
    if len(sys.argv) >= 3:
        quotaType = sys.argv[2]
    intType = getType(quotaType)
    
    if str(quotaName).upper() == "NETWORK":
        print( getNetInfo(intType) )
    elif str(quotaName).upper() == "SUBNET":
        print( getSubNetInfo(intType) )
    elif str(quotaName).upper() == "PORT":
        print( getPortInfo(intType) )
    elif str(quotaName).upper() == "ROUTER":
        print( getRouterInfo(intType) )
    elif str(quotaName).upper() == "FLOATINGIP":
        print( getFloatingIpInfo(intType) )
    elif str(quotaName).upper() == "SECUGROUP":
        print( getSecuGroupInfo(intType) )
    elif str(quotaName).upper() == "SECUGROUPRULE":
        print( getSecuGroupRuleInfo(intType) )
    else:
        print None
    
