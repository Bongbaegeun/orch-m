#!/usr/bin/python
#-*- coding: utf-8 -*-


import json, yaml, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/vim_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

KEYSTONE_TOKEN_URL = cfg['vim_auth_url']

HEADER = { "content-Type": "application/json;charset=UTF-8", "accept":"application/json" }

def callAPI( _method, header, _url, reqBody=None, token=None, returnHeader=False ):
    
    http_client = httpclient.HTTPClient()
    
    if token is not None:
        header['X-Auth-Token'] =  token
    h = HTTPHeaders(header)
    
    if reqBody == None:
        strBody = None
    else:
        strBody = json.dumps( reqBody )
    
    req = HTTPRequest( url=_url, headers=h, method=_method.upper(), validate_cert=False, 
                       body=strBody, request_timeout=5 )
    
    response = http_client.fetch( request=req )
    http_client.close()
    
    if returnHeader :
        return { "header": response.headers, "body": json.loads(response.body) }
    else:
        return json.loads(response.body)


ENV_FILE="/var/onebox/openstack/admin-openrc.sh"

def setOSAuth( _id, passwd, domain ):
    import commands as cmd
    status, output = cmd.getstatusoutput( "cat %s | grep -v '^#' | grep OS_AUTH_URL="%ENV_FILE )
    authUrl = str(output).split('OS_AUTH_URL=')[1]
    url = str(authUrl).strip() + "/auth/tokens"
    
    reqBody = { "auth": { "identity": {
                                       "methods": ["password"],
                                       "password": {
                                                    "user": {
                                                             "name": _id,
                                                             "domain": { "id": domain},
                                                             "password": passwd
                                                             }
                                                    }
                                       },
                          "scope": {
                                    "project": {
                                                "name": _id,
                                                "domain": {"id": domain}
                                                }
                                    }
                         }
               }
    _method = "POST"
    header = HEADER
#     url = KEYSTONE_TOKEN_URL
    ret = callAPI(_method, header, url, reqBody, None, True)
    
    global AUTH_TOKEN, PROJECT_ID, NOVA_URL, NEUTRON_URL, GLANCE_URL
    AUTH_TOKEN = ret["header"]["X-Subject-Token"]
    PROJECT_ID = ret["body"]["token"]["project"]["id"]
    for catalog in ret["body"]["token"]["catalog"]:
        if catalog["type"] == "compute":
            NOVA_URL = catalog["endpoints"][0]["url"]
        elif catalog["type"] == "network":
            NEUTRON_URL = catalog["endpoints"][0]["url"]
        elif catalog["type"] == "image":
            GLANCE_URL = catalog["endpoints"][0]["url"]


if __name__ == '__main__':
    setOSAuth( "admin", "ohhberry3333", "default" )
    print "AUTH=%s, PROJECT_ID=%s, NOVA_URL=%s, NEUTRON_URL=%s, GLANCE_URL=%s"%(AUTH_TOKEN, PROJECT_ID, NOVA_URL, NEUTRON_URL, GLANCE_URL)