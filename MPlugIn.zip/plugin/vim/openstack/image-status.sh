#!/bin/bash

source /var/onebox/openstack/admin-openrc.sh

glance image-show $1 | grep -i "status" | grep -c -i "active"

