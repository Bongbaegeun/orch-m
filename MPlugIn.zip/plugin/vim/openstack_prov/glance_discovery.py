#!/usr/bin/python
#-*- coding: utf-8 -*-

import vim_api

import json, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/glance_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

vim_api.setOSAuth( cfg['vim_auth_url'], cfg['vim_id'], cfg["vim_passwd"], cfg["vim_domain"] )
HEADER = vim_api.HEADER
URL = vim_api.GLANCE_URL
AUTH_TOKEN = vim_api.AUTH_TOKEN


def getImageList():
    ret = { "data": [] }
    
    res = vim_api.callAPI( "GET", HEADER, URL+"/v2/images", token=AUTH_TOKEN )
    for image in cfg['vim_image']:
        uuid = ''
        size = ''
        for item in res["images"]:
            if item["name"] == image:
                uuid = item["id"]
                size = item["size"]
        ret["data"].append( { "{#UUID}": uuid, "{#NAME}": image, "{#SIZE}": size } )
    
    return ret

if __name__ == '__main__':
    print( json.dumps(getImageList(), indent=4) )
