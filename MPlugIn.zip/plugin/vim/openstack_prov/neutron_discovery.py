#!/usr/bin/python
#-*- coding: utf-8 -*-

import vim_api

import json, sys, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/neutron_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

vim_api.setOSAuth( cfg['vim_auth_url'], cfg['vim_id'], cfg["vim_passwd"], cfg["vim_domain"] )
HEADER = vim_api.HEADER
URL = vim_api.NEUTRON_URL
AUTH_TOKEN = vim_api.AUTH_TOKEN


def getNetList():
    ret = { "data": [] }
    
    res = vim_api.callAPI( "GET", HEADER, URL+"/v2.0/networks", token=AUTH_TOKEN )
    for vnet in cfg['vim_net'] :
        uuid = ''
        for item in res["networks"]:
            name = item["name"]
            if name == vnet:
                uuid = item["id"]
                break
        ret["data"].append( { "{#UUID}": uuid, "{#NAME}": vnet } )
    
    return ret

def getRouterList():
    ret = { "data": [] }
    
    res = vim_api.callAPI( "GET", HEADER, URL+"/v2.0/routers", token=AUTH_TOKEN )
    for rt in cfg['vim_router']:
        uuid = ''
        for item in res["routers"]:
            name = item["name"]
            if name == rt:
                uuid = item["id"]
                break
        ret["data"].append( { "{#UUID}": uuid, "{#NAME}": rt } )
    
    return ret

if __name__ == '__main__':
    
    listType = None
    if len(sys.argv) >= 2:
        listType = sys.argv[1]
    
    if str(listType).upper() == "NET":
        print( json.dumps(getNetList(), indent=4) )
    elif str(listType).upper() == "ROUTER":
        print( json.dumps(getRouterList(), indent=4) )
    else:
        print( json.dumps( { "data": [] }, indent=4 ) )
