#!/bin/bash

VIM_TYPE="VPORT"
VIM_NAME=`echo $1 | sed 's/^NS-[A-Za-z0-9]\{1,50\}.OB[0-9]\{1,5\}.//'`
VIM_NAME=`echo $VIM_NAME | sed 's/-V.[0-9]//g'`

LOG_DIR="/var/log/zabbix-agent"
LOG_FILE="$LOG_DIR/vim.log"

if [ ! -d $LOG_DIR ]
then
        mkdir -p $LOG_DIR
fi

source /var/onebox/openstack/admin-openrc.sh

vim_status=$(neutron --insecure port-list -c name -c status | sed 's/-V.[0-9]//g' 2>&1)
res=$(echo $?)

if [ "$res" == 0 ]
then
        ret=$(echo "$vim_status" | grep "$VIM_NAME" | grep -c "ACTIVE")
        if (( "$ret" < 1 ))
        then
                echo "["`date`"] ERROR.1 :: $VIM_TYPE :: $VIM_NAME" >> $LOG_FILE
                echo "$vim_status" >> $LOG_FILE
        fi
        echo $ret
else
        echo "["`date`"] ERROR.2 :: $VIM_TYPE :: $VIM_NAME :: ""$vim_status" >> $LOG_FILE
fi

