#!/usr/bin/python
#-*- coding: utf-8 -*-

import vim_api

import json, sys, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/neutron_prov_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

vim_api.setOSAuth( cfg['vim_auth_url'], cfg['vim_id'], cfg["vim_passwd"], cfg["vim_domain"] )
HEADER = vim_api.HEADER
URL = vim_api.NEUTRON_URL
AUTH_TOKEN = vim_api.AUTH_TOKEN


def getPortList():
    ret = { "data": [] }
    
    res = vim_api.callAPI( "GET", HEADER, URL+"/v2.0/ports", token=AUTH_TOKEN )
    for port in cfg['vim_port'] :
        uuid = ''
        mac = ''
        name = port
        for item in res["ports"]:
#             if ( item["id"] == port ) or ( item["mac_address"] == port )  :
#                 uuid = item["id"]
#                 mac = item["mac_address"]
#                 name = item['name']
#                 break
#             else:
                if str(item['name']).find(port) >= 0 :
                    uuid = item["id"]
                    mac = item["mac_address"]
                    name = port
                    break
    
        ret["data"].append( { "{#UUID}": uuid, "{#MAC}": mac, "{#NAME}":name } )
    
    return ret

if __name__ == '__main__':
    
    listType = None
    if len(sys.argv) >= 2:
        listType = sys.argv[1]
    
    if str(listType).upper() == "PORT":
        print( json.dumps(getPortList(), indent=4) )
    else:
        print( json.dumps( { "data": [] }, indent=4 ) )
