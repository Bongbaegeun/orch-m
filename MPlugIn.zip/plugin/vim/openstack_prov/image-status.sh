#!/bin/bash

source /var/onebox/openstack/admin-openrc.sh

glance --insecure image-show $1 | grep -i "status" | grep -c -i "active"

