#!/usr/bin/python
#-*- coding: utf-8 -*-
 
import callbox_api
from callbox_api import Logger
import sys, json, yaml, os, logging

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/callbox_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger( logName='callbox', logDir='/var/log/zabbix-agent', logFile='callbox.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG ).instance()

ip = cfg['vm_ip']
ID = cfg['vm_id']
PASSWD = cfg['vm_passwd']

CMDS = {
        "AUTH" :   """https://%s/onebox/login.dao""",
        "ETHERNET_INFO":   """https://%s/onebox/base/ethernet.dao""",
       }

def login( ip, _id, passwd ):
    try:
        ret = callbox_api.callAPI( CMDS['AUTH']%ip, header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"},
                               reqBody='username=%s&passwd=%s&force=%s'%(_id, passwd, str(1)) )
        if str(ret).count("errorMsg") > 0 : 
            return False
        else: 
            return True
    except Exception, e:
        logger.exception(e)
        return False


def netList( ip, _id=ID, passwd=PASSWD ):

    info = { "data": [] }

    if login( ip, _id, passwd ) :

        try:
        
            ret = callbox_api.callAPI( CMDS['ETHERNET_INFO']%ip, 'GET')
            
            if not type(ret) == list :
                logger.error( ' netList body is not dict, ret=%s'%(ret) )
                return None

            for _name in list( ret ) :
                
                if _name['name'] in cfg['vm_net']:
                    info['data'].append( { "{#NAME}": _name['name'] } )
        
            return info                
            
        except Exception, e:
            logger.exception(e)
            print e
            return None
    else :
        logger.error( 'Login failed,  id=%s,  passwd=%d'% (_id, passwd))
        return None

if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            
            if str(chkType).upper() == "NETLIST":
                print( json.dumps(netList(ip), indent=4) )
                exit(0)
                
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger.exception(e)
        print None
