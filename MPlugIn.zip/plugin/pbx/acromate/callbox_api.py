#!/usr/bin/python
#-*- coding: utf-8 -*-

import Crypto.Cipher.AES
orig_new = Crypto.Cipher.AES.new
def fixed_AES_new(key, *ls):
    if Crypto.Cipher.AES.MODE_CTR == ls[0] :
        ls = list(ls)
        ls[1] = ''
    return orig_new(key, *ls)

import json, paramiko
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import logging.handlers, os

HEADER={"Content-type": "application/x-www-form-urlencoded; charset=utf-8"}
METHOD="POST"

class Singleton(object):
    _instance = None
    
    def __new__(self, *args, **kwargs):
        if not isinstance( self._instance, self ) :
            self._instance = object.__new__(self, *args, **kwargs)
        return self._instance

class Logger(Singleton):
    
    def __init__(self, logName, logDir='./', logFile='myLogger.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG):
        self._logger = logging.getLogger( logName )
        logging.getLogger( logName )
        # 포매터를 만든다.
        formatter = logging.Formatter( '[%(asctime)s] %(levelname)s: %(message)s' )
        
        # 스트림과 파일로 로그를 출력하는 핸들러를 각각 만든다.
        fileHandler = logging.handlers.RotatingFileHandler( logDir + "/" + logFile, maxBytes=logFileMaxByte, backupCount=logBackupCnt )
#         streamHandler = logging.StreamHandler()
        
        # 각 핸들러에 포매터를 지정한다.
        fileHandler.setFormatter( formatter )
#         streamHandler.setFormatter( formatter )
            
        # 위에서 만든 로거 인스턴스에 스트림 핸들러화 파일핸들러를 붙인다.
        self._logger.addHandler( fileHandler )
#         self._logger.addHandler( streamHandler )
        
        # 로그 레벨 설정
        self._logger.setLevel( logLevel )
        
        os.chmod( fileHandler.baseFilename, 0777 )
    def instance(self):
        return self._logger


HEADER = { "content-Type": "application/json;charset=UTF-8", "accept":"application/json" }

def callAPI( _url, _method='POST', header=HEADER, reqBody=None, returnHeader=False ):
    
    http_client = httpclient.HTTPClient()
    h = HTTPHeaders(header)
	
    if reqBody == None:
        strBody = None

    elif type(reqBody) == str:
        strBody = reqBody
    else:
        strBody = json.dumps( reqBody )
    
    req = HTTPRequest( validate_cert=False,
                       url=_url, headers=h, method=_method.upper(), body=strBody, request_timeout=5 )
    
    response = http_client.fetch( request=req )
    http_client.close()
    
    retBody = response.body
    try:
        retBody = json.loads(response.body)
    except :
        pass
    
    if returnHeader :
        return { "header": response.headers, "body": retBody }
    else:
        return retBody

KEY_FILE="/var/onebox/key/zb_rsa" 

def run( _logger, ip, cmd, _timeout=5 ):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect( ip, username="root", key_filename=KEY_FILE, timeout=_timeout )
    except ValueError, e:
        _logger.warning("ssh connection warning -> "+str(e))
        Crypto.Cipher.AES.new = fixed_AES_new
        client.connect( ip, username="root", key_filename=KEY_FILE, timeout=_timeout )
    stdin, stdout, stderr = client.exec_command( cmd )
    ret = str(stdout.read()).strip()
    client.close()
    return ret

if __name__ == '__main__':
    print( callAPI("https://192.168.254.2/index.dao", "GET", {"Except":""}, None, True) )
#     print( callAPI("GET", {"Content-Type":"application/x-www-form-urlencoded"}, "https://192.168.10.9/webapi/status/network_interface", None, True) )
    

