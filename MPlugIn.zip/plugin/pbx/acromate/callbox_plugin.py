#!/usr/bin/python
#-*- coding: utf-8 -*-
import callbox_api
from callbox_api import Logger
import sys, yaml, os, logging
from __builtin__ import exit

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/callbox_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger( logName='callbox', logDir='/var/log/zabbix-agent', logFile='callbox.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG ).instance()

ip = cfg['vm_ip']
ID = cfg['vm_id']
PASSWD = cfg['vm_passwd']

CMDS = {
        "AUTH" :   """https://%s/onebox/login.dao""",
        "PBX_INFO": """https://%s/onebox/logstat/pbxinfo.dao""",
        "SYS_INFO": """https://%s/onebox/logstat/sysinfo.dao""",
        "NET_INFO": """https://%s/onebox/interface_monitor.dao""",
        "TRAFFIC_INFO": """https://%s/onebox/traffic_monitor.dao""",

        "CONNECT": """https://%s/onebox/index.dao""",
        
       }
       
def login( ip, _id, passwd ):
    try:
        ret = callbox_api.callAPI( CMDS['AUTH']%ip, header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"},
                               reqBody='username=%s&passwd=%s&force=%s'%(_id, passwd, str(1)) )
        if str(ret).count("errorMsg") > 0 : 
            return False
        else: 
            return True
    except Exception, e:
        logger.exception(e)
        return False



def sysInfo( ip, _what, _id=ID, passwd=PASSWD ):
    
    if login( ip, _id, passwd ) :

        try:
        
            ret = callbox_api.callAPI( CMDS['SYS_INFO']%ip, 'GET')
            
            # print ret 
            
            if not type(ret) == dict :
                logger.error( 'sys_Info body is not dict, ret=%s'%(ret) )
                return None

                
            if str(_what) == 'cpu' :
                return ret['cpu']

            if str(_what) == 'mem' :
                return ret['mem']
  
            if str(_what) == 'disk' :
                return ret['disk']

                
            logger.error( 'sys_Info Unknown Type, what=%s'% str(_what))
            return None
            
        except Exception, e:
            logger.exception(e)
            print e
            return None
    else :
        logger.error( 'Login failed,  id=%s,  passwd=%s'% (_id, passwd))
        return None
        

def netstatus( ip, _what, _if='eth0', _id=ID, passwd=PASSWD ):
    if login( ip, _id, passwd ) :
         
        try:
            ret = callbox_api.callAPI( CMDS['NET_INFO']%ip, header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"},
                                   reqBody='dev=%s'% _if)
            
            # curl -d "dev=eth0" -k https://192.168.0.2/onebox/interface_monitor.dao
            #   {"eth0":1}
    
            if not type(ret) == dict :
                logger.error( 'callbox_Info body is not dict, ret=%s'%(ret) )
                return None

            if ret.has_key(_if) :
                return ret[_if]
            else :
                return 0
                
            return None            
        
        except Exception, e:
            logger.exception(e)
            print e
            return None
    else :
        logger.error( 'Login failed,  id=%s,  passwd=%s'% (_id, passwd))
        return None



def traffic( ip, _what, _type, _if, _id=ID, passwd=PASSWD ):
    if login( ip, _id, passwd ) :
         
        try:
            ret = callbox_api.callAPI( CMDS['TRAFFIC_INFO']%ip, header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"},
                                   reqBody='dev=%s'%_if)
            
            # curl -d "dev=eth4" -k -s https://192.168.0.2/onebox/traffic_monitor.dao	"[
              # {
                # ""out_bytes"": 988,
                # ""out_pkts"": 1,
                # ""in_bytes"": 48,
                # ""in_pkts"": 0
              # },
              # {
                # ""total_out_bytes"": 16113249,
                # ""total_out_pkts"": 58091,
                # ""total_in_bytes"": 12151156,
                # ""total_in_pkts"": 63250
              # }
            # ]"

                
            if not type(ret) == list :
                logger.error( 'callbox_Info body is not list, ret=%s'%(ret) )
                return None
                
            if _type == 'rx_rate' : 
                return ret[0]['in_bytes']
            elif _type == 'tx_rate' : 
                return ret[0]['out_bytes']
                
            return None
            
        except Exception, e:
            logger.exception(e)
            print e
            return None
    else :
        logger.error( 'Login failed,  id=%s,  passwd=%s'% (_id, passwd))
        return None

        

def pbxInfo( ip, _what, _id=ID, passwd=PASSWD ):

    if login( ip, _id, passwd ) :

        try:
            ret = callbox_api.callAPI( CMDS['PBX_INFO']%ip, header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"},
                                   reqBody='item=%s'%_what)

            #print ret 

            if not type(ret) == dict :
                logger.error( 'callbox_Info body is not dict, ret=%s'%(ret) )
                return None

            if str(ret[_what]) == "True"  :
                return 1
            elif str(ret[_what]) == "False" :
                return 0

            return ret[_what]


        except Exception, e:
            logger.exception(e)
            print e
            return None
    else :
        logger.error( 'Login failed,  id=%s,  passwd=%s'% (_id, passwd))
        return None

        
        
def connect( ip ):

    try:
    
        ret = callbox_api.callAPI( CMDS['CONNECT']%ip, 'GET')
        
        # print ret 
        
        if not type(ret) == dict :
            logger.error( 'sys_Info body is not dict, ret=%s'%(ret) )
            return False
            
        if str(ret['success']) == "True"  :
            return 1
        elif str(ret['success']) == "False" :
            return 0
        
    except : 
        return False
        
		
if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1])
			
            if chkType == "connect" :
                print( connect(ip) )
                exit(0)

            if chkType == "cpu" :
                print( sysInfo(ip, chkType) )
                exit(0)
                
            if chkType == "mem" :
                print( sysInfo(ip, chkType) )
                exit(0)
                
            if chkType == "disk" :
                print( sysInfo(ip, chkType) )
                exit(0)

                
            # PBXINFO.DAO --------------------
            # cpuLoad  - vCPU load
            # pbxJobStatus  - VM내 주요 프로세스 상태확인 후 PBX 기능 정상동작 여부 (True/False)
            # pbxCurrentCall - # 현재 통화중인 Call 수 
            # pbxRegiPhoneCnt - vPBX에 연결된 내선 전화기 대수
            # pbxPhoneNumberCnt - vPBX에 생성된 전화번호 수               
            # pbxCall5minTotal - 5분간 전체 Call 수
            # pbxCall5minSuccess - 5분간 통화 성공 Call 수
            # pbxBizConnStatus - 기업망 호처리 등록 상태 (True/False)

            keylist = ['cpuLoad', 'pbxJobStatus', 'pbxCurrentCall', 'pbxRegiPhoneCnt', 'pbxPhoneNumberCnt',
            'pbxCall5minTotal', 'pbxCall5minSuccess', 'pbxBizConnStatus']
            
            if chkType == "netstatus" :
                if len(sys.argv) >= 3:
                    print( netstatus(ip, chkType, str( sys.argv[2]) ) )
                else :
                    print None
                    
                exit(0)
                
            if chkType == "traffic" :
                if len(sys.argv) >= 4:
                    print( traffic(ip, chkType, str( sys.argv[2]), str( sys.argv[3]) ) )
                else :
                    print None
                    
                exit(0)
                
            if keylist.count(chkType) > 0 :
                print( pbxInfo(ip, chkType) )
                exit(0)
                
            else :
                logger.error( "Unknow key : %s " % chkType ) 
                exit(0)
                    
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
		
        print None
		
    except Exception, e:
        logger.exception(e)
        print None

