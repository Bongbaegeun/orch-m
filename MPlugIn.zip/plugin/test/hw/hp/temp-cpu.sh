#!/bin/bash

randint=`cat /proc/sys/kernel/random/uuid `
number1=${randint:34:2}
number=$((0x$number1))
val=`expr $number % 70`
#val=`expr $number % 100`
echo $val
