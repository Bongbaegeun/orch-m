#!/usr/bin/python
#-*- coding: utf-8 -*-

import commands as cmd
import logging.handlers, os


class Singleton(object):
    _instance = None
    
    def __new__(self, *args, **kwargs):
        if not isinstance( self._instance, self ) :
            self._instance = object.__new__(self, *args, **kwargs)
        return self._instance

class Logger(Singleton):
    
    def __init__(self, logName, logDir='./', logFile='myLogger.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG):
        self._logger = logging.getLogger( logName )
        logging.getLogger( logName )
        # 포매터를 만든다.
        formatter = logging.Formatter( '[%(asctime)s] %(levelname)s: %(message)s' )
        
        # 스트림과 파일로 로그를 출력하는 핸들러를 각각 만든다.
        fileHandler = logging.handlers.RotatingFileHandler( logDir + "/" + logFile, maxBytes=logFileMaxByte, backupCount=logBackupCnt )
#         streamHandler = logging.StreamHandler()
        
        # 각 핸들러에 포매터를 지정한다.
        fileHandler.setFormatter( formatter )
#         streamHandler.setFormatter( formatter )
            
        # 위에서 만든 로거 인스턴스에 스트림 핸들러화 파일핸들러를 붙인다.
        self._logger.addHandler( fileHandler )
#         self._logger.addHandler( streamHandler )
        
        # 로그 레벨 설정
        self._logger.setLevel( logLevel )
        
        os.chmod( fileHandler.baseFilename, 0777 )
    def instance(self):
        return self._logger

KEY_FILE="/var/onebox/key/zb_rsa" 

def getQRouter(logger):
    status, output = cmd.getstatusoutput( "ip netns | grep qrouter" )
    if status == 0 :
        return output
    else:
        logger.error(output)
        return None

def execute( logger, _cmd, qrouter=None ):
    if qrouter == None:
        qrouter = getQRouter(logger)
    cmds = """sudo -u root ip netns exec %s %s"""%(qrouter, _cmd) 
    
    status, output = cmd.getstatusoutput( cmds )
    if status == 0 :
        return output
    else:
        logger.error("status=%s, output=%s"%(str(status), str(output)))
        return output

if __name__ == '__main__':
#     print( getQRouter() )
    print( execute("ifconfig") )





