#!/usr/bin/python
#-*- coding: utf-8 -*-

from apc_api import Logger
import sys, yaml, os, logging
import random

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/apc_cfg.yaml'

FAULT_YN = False

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger( logName='apc', logDir='/var/log/zabbix-agent', logFile='apc.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG ).instance()

ip = cfg['vm_ip']


def checkPing(ip):
    if FAULT_YN :
        return random.randint(0,5)
    else:
        return random.randint(1,5)

def cpuInfo( ip, _type ):
    if str(_type).upper() == 'LOAD':
        if FAULT_YN :
            return float(random.randint(0,10))/9.9
        else:
            return float(random.randint(0,4))/9.9
    elif str(_type).upper() == 'UTIL':
        if FAULT_YN :
            return float(random.randint(0,100))/9.9
        else:
            return float(random.randint(0,70))/9.9
    else:
        logger.error('Undefined CPU monitoring Type, type=%s'%str(_type))
        return None

def memInfo( ip, _type, isSwap=False ):
    total = 16000000000
    if FAULT_YN:
        used = random.randint(0, total)
    else:
        used = random.randint(0, total*0.7)
    free = total - used
    buff = random.randint(0, used)
    cach = random.randint(0, used-buff)
    
    if str(_type).upper() == "TOTAL":   return total
    elif str(_type).upper() == "USED":  return used - buff - cach
    elif str(_type).upper() == "FREE":  return free + buff + cach
    elif str(_type).upper() == "UTIL":  return (used - buff - cach )*100/total
    else:                               return None
    
def diskInfo( ip, _type, name ):
    total = 1000000000000
    if FAULT_YN:
        used = random.randint(0, total)
    else:
        used = random.randint(0, total*0.7)
    free = total - used
    
    if str(_type).upper() == "TOTAL":
        ret = total
    elif str(_type).upper() == "USED":
        ret = used
    elif str(_type).upper() == "FREE":
        ret = free
    elif str(_type).upper() == "UTIL":
        ret = float(used)*100/float(total)
    else:
        return None
    return int(ret)

def procStatus( ip, proc ):
    if FAULT_YN:
        return random.randint(0, 5)
    else:
        return random.randint(1, 5)

def netStatus( ip, name ):
    if FAULT_YN:
        return random.randint(0, 1)
    else:
        return 1

def netRxRate( ip, name ):
    if FAULT_YN:
        return random.randint(0, 300000000)
    else:
        return random.randint(0, 99000000)

def netTxRate( ip, name ):
    if FAULT_YN:
        return random.randint(0, 300000000)
    else:
        return random.randint(0, 99000000)

def countAP( ip ):
    return random.randint(0, 2)


if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            if chkType == "PING":
                print( checkPing(ip) )
            elif chkType == "CPU":
                print( cpuInfo(ip, sys.argv[2]) )
            elif chkType == "MEM":
                print( memInfo( ip, sys.argv[2]) )
            elif chkType == "SWAP":
                print ( memInfo(ip, sys.argv[2], True) )
            elif chkType == "DISK":
                print( diskInfo(ip, sys.argv[2], sys.argv[3]) )
            elif chkType == "PROC":
                print ( procStatus(ip, sys.argv[2]) )
            elif chkType == "NET":
                if str(sys.argv[2]).upper() == 'STATUS' :
                    print ( netStatus(ip, sys.argv[3]) )
                elif str(sys.argv[2]).upper() == 'RX_RATE' :
                    print ( netRxRate(ip, sys.argv[3]) )
                elif str(sys.argv[2]).upper() == 'TX_RATE' :
                    print ( netTxRate(ip, sys.argv[3]) )
            elif chkType == "AP_COUNT":
                print ( countAP(ip) )
    except Exception, e:
        logger.exception(e)



