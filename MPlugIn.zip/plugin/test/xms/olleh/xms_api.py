#!/usr/bin/python
#-*- coding: utf-8 -*-

import paramiko, json
import logging.handlers, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest

class Singleton(object):
    _instance = None
    
    def __new__(self, *args, **kwargs):
        if not isinstance( self._instance, self ) :
            self._instance = object.__new__(self, *args, **kwargs)
        return self._instance

class Logger(Singleton):
    
    def __init__(self, logName, logDir='./', logFile='myLogger.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG):
        self._logger = logging.getLogger( logName )
        logging.getLogger( logName )
        # 포매터를 만든다.
        formatter = logging.Formatter( '[%(asctime)s] %(levelname)s: %(message)s' )
        
        # 스트림과 파일로 로그를 출력하는 핸들러를 각각 만든다.
        fileHandler = logging.handlers.RotatingFileHandler( logDir + "/" + logFile, maxBytes=logFileMaxByte, backupCount=logBackupCnt )
#         streamHandler = logging.StreamHandler()
        
        # 각 핸들러에 포매터를 지정한다.
        fileHandler.setFormatter( formatter )
#         streamHandler.setFormatter( formatter )
            
        # 위에서 만든 로거 인스턴스에 스트림 핸들러화 파일핸들러를 붙인다.
        self._logger.addHandler( fileHandler )
#         self._logger.addHandler( streamHandler )
        
        # 로그 레벨 설정
        self._logger.setLevel( logLevel )
        os.chmod( fileHandler.baseFilename, 0777 )
    def instance(self):
        return self._logger

KEY_FILE="/var/onebox/key/zb_rsa" 

def conn( ip ):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#     client.load_system_host_keys()
    client.connect( ip, username="root", key_filename=KEY_FILE )
    return client

def run( ip, cmd, _timeout=5 ):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect( ip, username="root", key_filename=KEY_FILE, timeout=_timeout )
    stdin, stdout, stderr = client.exec_command( cmd )
    return str(stdout.read()).strip()

HEADER = { "content-Type": "application/json;charset=UTF-8", "accept":"application/json" }

def callAPI( _method, header, _url, reqBody=None, returnHeader=False ):
    
    http_client = httpclient.HTTPClient()
    h = HTTPHeaders(header)
    if reqBody == None:
        strBody = None
    else:
        strBody = json.dumps( reqBody )
    
    req = HTTPRequest( validate_cert=False,
                       url=_url, headers=h, method=_method.upper(), body=strBody, request_timeout=5 )
    
    response = http_client.fetch( request=req )
    http_client.close()
    
    if returnHeader :
        return { "header": response.headers, "body": json.loads(response.body) }
    else:
        return json.loads(response.body)



if __name__ == '__main__':
    print( "-----------> start ssh" )
    client = paramiko.SSHClient()
    print( "-----------> make client" )
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    print( "-----------> set key" )
    
    client.load_system_host_keys()
    client.connect('192.168.0.227')
    print( "-----------> conn" )
    
    stdin, stdout, stderr = client.exec_command(""" ps -ef | grep "%s"  """%"cron")
    print( "-----------> run cmd" )
    
    #print('in=%s'%stdin.read())
    ret = stdout.read()
    print('-----------> out=\n%s'%ret)
    print('-----------> err=\n%s'%stderr.read())

