#!/usr/bin/python

import sys, yaml, os, logging
from xms_api import Logger
import random

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/xms_cfg.yaml'

FAULT_YN = False

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger(logName='xms', logDir='/var/log/zabbix-agent', logFile='xms.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG).instance()

ip=cfg['vm_ip']
uID=cfg['vm_app_id']
#"net" : """ ethtool %s | grep "Link detected:" | awk '{print $3}' """,
scripts = { 
           "proc" : """ ps -ef | grep -v "grep" | grep -c "%s" """ ,
           "mem" : """ free | grep  "%s" | awk '{print $2":"$3":"$4":"$6":"$7}' """,
           "disk" : """ df | grep -v "Filesystem" | awk '{print $6":"$2":"$3":"$4}' """,
           "net" : """ ip link show %s | grep -c ",UP," """,
           "cpu_load" : """ cpu_info=$(top -n 1 -b | head -n 10 | grep "load average"); loads=${cpu_info##*:}; echo ${loads%%,*} """,
           "cpu_util" : """ cpu_info=$(top -n 1 -b | head -n 10 | grep "Cpu") ; idle=${cpu_info##*ni, }; usage=${idle%%%id,*}; echo $usage """,
           "cpu_cnt" : """ cat /proc/cpuinfo | grep -c "processor" """,
           "rx_byte": """ cat /sys/class/net/%s/statistics/rx_bytes """,
           "tx_byte": """ cat /sys/class/net/%s/statistics/tx_bytes """,
           "ne_status": """http://%s:8080/nms_module/getApSwitchInfo.json?userId=%s"""
           }


def checkPing(ip):
    if FAULT_YN :
        return random.randint(0,5)
    else:
        return random.randint(1,5)

def procStatus( ip, proc ):
    if FAULT_YN:
        return random.randint(0, 5)
    else:
        return random.randint(1, 5)

def memUsage( ip, _type, isSwap=False ):
    total = 16000000000
    if FAULT_YN:
        used = random.randint(0, total)
    else:
        used = random.randint(0, total*0.7)
    free = total - used
    buff = random.randint(0, used)
    cach = random.randint(0, used-buff)
    
    if str(_type).upper() == "TOTAL":   return total
    elif str(_type).upper() == "USED":  return used - buff - cach
    elif str(_type).upper() == "FREE":  return free + buff + cach
    elif str(_type).upper() == "UTIL":  return (used - buff - cach )*100/total
    else:                               return None
    
def diskUsage( ip, _type, name ):
    total = 1000000000000
    if FAULT_YN:
        used = random.randint(0, total)
    else:
        used = random.randint(0, total*0.7)
    free = total - used
    
    if str(_type).upper() == "TOTAL":
        ret = total
    elif str(_type).upper() == "USED":
        ret = used
    elif str(_type).upper() == "FREE":
        ret = free
    elif str(_type).upper() == "UTIL":
        ret = float(used)*100/float(total)
    else:
        return None
    return int(ret)

def netStatus( ip, name ):
    if FAULT_YN:
        return random.randint(0, 1)
    else:
        return 1

def cpuUsage( ip, _type ):
    try :
        if str(_type).upper() == "COUNT":
            if FAULT_YN :
                return random.randint(0,32)
            else:
                return random.randint(1,32)
        elif str(_type).upper() == "LOAD":
            if FAULT_YN :
                return float(random.randint(0,10))/9.9
            else:
                return float(random.randint(0,4))/9.9
        elif str(_type).upper() == "UTIL":
            if FAULT_YN :
                return float(random.randint(0,100))/9.9
            else:
                return float(random.randint(0,70))/9.9
        else:
            return None
    except Exception, e:
        logger.exception(e)
        return None

def netRxRate( ip, name ):
    if FAULT_YN:
        return random.randint(0, 300000000)
    else:
        return random.randint(0, 99000000)

def netTxRate( ip, name ):
    if FAULT_YN:
        return random.randint(0, 300000000)
    else:
        return random.randint(0, 99000000)

def chkNE( ip, neType, _type ):
    try:
        
        _Type = str(_type).upper()
        if neType == 'AP':
            if _Type == 'TOTAL':
                return random.randint(1, 5)
            elif _Type == 'FAULT':
                if FAULT_YN:
                    return random.randint(0, 1)
                else:
                    return 0
        elif neType == 'SW':
            if _Type == 'TOTAL':
                return random.randint(1, 5)
            elif _Type == 'FAULT':
                if FAULT_YN:
                    return random.randint(0, 1)
                else:
                    return 0
        
        logger.error('no match, ip=%s, neType=%s, type=%s '%(str(ip), str(neType), str(_type)))
        return None
    except Exception, e:
        logger.exception(e)
        return None


if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            if chkType == "PING":
                print ( checkPing(ip) )
            elif chkType == "PROC":
                print ( procStatus(ip, sys.argv[2]) )
            elif chkType == "MEM":
                print ( memUsage(ip, sys.argv[2]) )
            elif chkType == "SWAP":
                print ( memUsage(ip, sys.argv[2], True) )
            elif chkType == "DISK":
                print ( diskUsage(ip, sys.argv[2], sys.argv[3]) )
            elif chkType == "NET":
                if str(sys.argv[2]).upper() == 'STATUS' :
                    print ( netStatus(ip, sys.argv[3]) )
                elif str(sys.argv[2]).upper() == 'RX_RATE' :
                    print ( netRxRate(ip, sys.argv[3]) )
                elif str(sys.argv[2]).upper() == 'TX_RATE' :
                    print ( netTxRate(ip, sys.argv[3]) )
            elif chkType == "CPU":
                print ( cpuUsage(ip, sys.argv[2]) )
            elif chkType == "AP":
                print ( chkNE(ip, 'AP', sys.argv[2]) )
            elif chkType == "SW":
                print ( chkNE(ip, 'SW', sys.argv[2]) )
        else:
            print None
    except Exception, e:
        logger.exception(e)
