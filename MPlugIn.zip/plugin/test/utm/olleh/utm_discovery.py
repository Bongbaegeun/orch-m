#!/usr/bin/python
#-*- coding: utf-8 -*-

import sys, json
import yaml, os, logging
from utm_api import Logger

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/utm_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger(logName='utm', logDir='/var/log/zabbix-agent', logFile='utm.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG).instance()

ip=cfg['vm_ip']

scripts = {
           "nets" : """ ifconfig -a | grep "Link encap" | grep -v "lo" | awk '{print $1}' """,
           "disks" : """ df | grep -v "Filesystem" | awk '{print $6}' """,
           }




def jobList( ip ):
    ret = { "data": [] }
    for item in cfg['vm_job']:
        ret["data"].append( { "{#NAME}": item } )
    
    return ret

def procList( ip ):
    ret = { "data": [] }
    for item in cfg['vm_proc']:
        ret["data"].append( { "{#NAME}": item } )
    return ret

def netList( ip ):
    ret = { "data": [] }
    for item in cfg['vm_net']:
        ret["data"].append( { "{#NAME}": item } )
    return ret

def diskList( ip ):
    ret = { "data": [] }
    for item in cfg['vm_fs']:
        ret["data"].append( { "{#NAME}": item } )
    return ret


if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            if chkType == "JOBLIST":
                print ( json.dumps(jobList(ip), indent=4) )
            elif chkType == "NETLIST":
                print ( json.dumps(netList(ip), indent=4) )
            elif chkType == "PROCLIST":
                print ( json.dumps(procList(ip), indent=4) )
            elif chkType == "DISKLIST":
                print ( json.dumps(diskList(ip), indent=4) )
        else:
            print "None, len="+str(len(sys.argv))
    except Exception, e:
        logger.exception(e)
