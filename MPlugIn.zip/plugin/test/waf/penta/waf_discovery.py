#!/usr/bin/python
#-*- coding: utf-8 -*-

from waf_api import Logger
import sys, json, yaml, os, logging

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/waf_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger( logName='waf', logDir='/var/log/zabbix-agent', logFile='waf.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG ).instance()

ip = cfg['vm_ip']
ID = cfg['vm_app_id']
PASSWD = cfg['vm_app_passwd']

CMDS = {
       "AUTH" : """ curl --insecure -H "Expect:" -vX \
                POST https://%s/webapi/auth \
                -d 'id=%s&password=%s' """,
        "NETINFO":  """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET https://%s/webapi/status/network_interface """
       }


def netList( auth, ip ):
    ret = { "data": [] }

    for val in cfg['vm_net']:
        ret["data"].append( { "{#NAME}": val } )
    
    return ret

if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            
            if str(chkType).upper() == "NETLIST":
                print( json.dumps(netList('aa', ip), indent=4) )
#             elif chkType == "ENGINE":
#                 print( engineInfo(auth, ip, sys.argv[2]) )
    except Exception, e:
        logger.exception(e)



