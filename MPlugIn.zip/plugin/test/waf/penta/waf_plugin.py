#!/usr/bin/python
#-*- coding: utf-8 -*-

from waf_api import Logger
import sys, yaml, os, logging
import random

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/waf_cfg.yaml'

FAULT_YN = False

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger( logName='waf', logDir='/var/log/zabbix-agent', logFile='waf.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG ).instance()

ip = cfg['vm_ip']
ID = cfg['vm_app_id']
PASSWD = cfg['vm_app_passwd']

PERIOD_CPUMEM = 5
PERIOD_TRAFFIC = 5
PERIOD_NET = 20

CMDS = {
       "AUTH" : """ curl --insecure -H "Expect:" \
                -vX POST https://%s/webapi/auth \
                -d 'id=%s&password=%s' """,
       "DB" :   """ curl --insecure -s \
                -H "Content-Type:application/x-www-form-urlencoded" \
                -b "WP_SESSID=%s" \
                -X GET https://%s/webapi/status/database """,
        "ENGINE":   """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET https://%s/webapi/status/detection_engine """,
        "CPUINFO":  """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET https://%s/webapi/info/system/cpu """,
        "CPUMEM":   """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET "https://%s/webapi/statistics/system/cpu_mem?get_count=%s" """,
        "TRAFFIC":  """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET "https://%s/webapi/statistics/system/traffic?get_count=%s" """,
        "NET":      """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET "https://%s/webapi/statistics/nic_stat?stime=%s&etime=%s&interface_name_include=%s" """,
        "TIME": """ curl --insecure -H "Content-Type:application/x-www-form-urlencoded" \
                -b "WP_SESSID=%s" \
                -vX GET https://%s/webapi/info/version """,
        "NETINFO":  """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET https://%s/webapi/status/network_interface?interface_name=%s """,
       }


def checkPing(ip):
    if FAULT_YN :
        return random.randint(0,5)
    else:
        return random.randint(1,5)

def dbUsage( auth, ip, _type ):
    total = 1000000000000
    if FAULT_YN:
        used = random.randint(0, total)
    else:
        used = random.randint(0, total*0.7)
    free = total - used
    
    if str(_type).upper() == "TOTAL":
        ret = total
    elif str(_type).upper() == "USED":
        ret = used
    elif str(_type).upper() == "FREE":
        ret = free
    elif str(_type).upper() == "UTIL":
        ret = int(used)*100/int(total)
    else:
        return None
    return int(ret)

def engineInfo( auth, ip, _type ):
    if str(_type).upper() == "COUNT":
        if FAULT_YN :
            return random.randint(0,5)
        else:
            return random.randint(1,5)
    elif str(_type).upper() == "STATUS":
        if FAULT_YN :
            return random.randint(0,1)
        else:
            return random.randint(1,2)
    elif str(_type).upper() == "CPU_UTIL":
        if FAULT_YN :
            return random.randint(0,100)
        else:
            return random.randint(0,70)
    else:
        return None

def cpuInfo( auth, ip, _type ):
    if str(_type).upper() == "COUNT":
        if FAULT_YN :
            return random.randint(0,5)
        else:
            return random.randint(1,5)
    elif str(_type).upper() == "NAME":
        return "test"
    elif str(_type).upper() == "P_COUNT":
        if FAULT_YN :
            return random.randint(0,5)
        else:
            return random.randint(1,5)
    elif str(_type).upper() == "L_COUNT":
        if FAULT_YN :
            return random.randint(0,5)
        else:
            return random.randint(1,5)
    else:
        return None

def cpumemUsage( auth, ip, target, _type, period ):
    total = 16000000000
    if FAULT_YN:
        used = random.randint(0, total)
    else:
        used = random.randint(0, total*0.7)
    free = total - used
    
    if str(target).upper() == "MEM":
        if str(_type).upper() == "TOTAL":
            return total
        elif str(_type).upper() == "USED":
            return used
        elif str(_type).upper() == "FREE":
            return free
        elif str(_type).upper() == "UTIL":
            return used*100/total
        else:
            return None
    elif str(target).upper() == "CPU":
        if str(_type).upper() == "UTIL":
            return used*100/total
        else:
            return None
    else:
        return None

def trafficUsage( auth, ip, _type, period ):
    cps = tps = rate = random.randint(0, 100000000)
    
    if str(_type).upper() == "CPS":
        return cps
    elif str(_type).upper() == "TPS":
        return tps
    elif str(_type).upper() == "RATE":
        return rate
    else:
        return None

def netUsage( auth, ip, _type, period, name ):
    return random.randint(0, 100000000)

def netInfo( auth, ip, _type, name ):
    if str(_type).upper() == "STATUS":
        if FAULT_YN:
            return random.randint(0, 2)
        else:
            return random.randint(1, 2)
    elif str(_type).upper() == "SPEED":
        return 100000000
    else:
        return None


if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            auth = 'test'
            chkType = str(sys.argv[1]).upper()
            
            if chkType == "PING":
                print( checkPing(ip) )
            elif chkType == "DB":
                print( dbUsage(auth, ip, sys.argv[2]) )
            elif chkType == "ENGINE":
                print( engineInfo(auth, ip, sys.argv[2]) )
            elif chkType == "CPUINFO":
                print( cpuInfo(auth, ip, sys.argv[2]) )
            elif chkType == "CPU" or chkType == "MEM":
                if len(sys.argv) > 3 and str(sys.argv[3]) != '' :
                    period = int(sys.argv[3])
                else :
                    period = PERIOD_CPUMEM
                print( cpumemUsage(auth, ip, sys.argv[1], sys.argv[2], period) )
            elif chkType == "TRAFFIC":
                if len(sys.argv) > 3 and str(sys.argv[3]) != '' :
                    period = int(sys.argv[3])
                else :
                    period = PERIOD_TRAFFIC
                print( trafficUsage(auth, ip, sys.argv[2], period) )
            elif chkType == "NET":
                if len(sys.argv) > 4 and str(sys.argv[3]) != '' :
                    period = int(sys.argv[3])
                    name = str(sys.argv[4])
                else :
                    period = PERIOD_NET
                    name = str(sys.argv[3])
                print( netUsage(auth, ip, sys.argv[2], period, name) )
            elif chkType == "NETINFO":
                print( netInfo(auth, ip, sys.argv[2], sys.argv[3]) )
    except Exception, e:
        logger.exception(e)



