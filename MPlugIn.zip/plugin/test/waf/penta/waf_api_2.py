#!/usr/bin/python

import json
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest

HEADER = { "content-Type": "application/json;charset=UTF-8", "accept":"application/json" }

def callAPI( _method, header, _url, reqBody=None, returnHeader=False ):
    
    http_client = httpclient.HTTPClient()
    h = HTTPHeaders(header)
#     h.add("Set-Cookie", "WP_SESSID=qedp2gf44d1k3q3aeb8bebblq3")
    if reqBody == None:
        strBody = None
    else:
        strBody = json.dumps( reqBody )
    
    req = HTTPRequest( validate_cert=False,
                       url=_url, headers=h, method=_method.upper(), body=strBody, request_timeout=5 )
    
    response = http_client.fetch( request=req )
    http_client.close()
    
    if returnHeader :
        return { "header": response.headers, "body": json.loads(response.body) }
    else:
        return json.loads(response.body)


if __name__ == '__main__':
    print( callAPI("POST", {"Except":""}, "https://192.168.10.9/webapi/auth", "id=admin&password=wafpenta!23", True) )
#     print( callAPI("GET", {"Content-Type":"application/x-www-form-urlencoded"}, "https://192.168.10.9/webapi/status/network_interface", None, True) )
    