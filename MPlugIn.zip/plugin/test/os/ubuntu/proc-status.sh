#!/bin/bash

randint=`cat /proc/sys/kernel/random/uuid `
number1=${randint:29:7}
number=$((0x$number1))
val=`expr $number % 5 + 1`
#val=`expr $number % 5`
echo $val
