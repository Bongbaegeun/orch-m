#!/usr/bin/python

import json, sys, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/os_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)


def getProcList():
    _list = []
    for item in cfg['svr_proc']:
        _list.append({"{#NAME}":item})
    return {"data": _list}


def getSvcList():
    _list = []
    for item in cfg['svr_svc']:
        _list.append({"{#NAME}":item})
    return {"data": _list}

def getNetList():
    _list = []
    for item in cfg['svr_net']:
        _list.append({"{#NAME}":item})
    return {"data": _list}

def getFsList():
    _list = []
    for item in cfg['svr_fs']:
        _list.append({"{#NAME}":item})
    return {"data": _list}

if __name__ == '__main__':
    _type = None
    if len(sys.argv) >= 2:
        _type = sys.argv[1]
    
    if str(_type).upper() == 'PROC':
        print json.dumps(getProcList(), indent=2)
        exit()
    elif str(_type).upper() == 'SVC':
        print json.dumps(getSvcList(), indent=2)
        exit()
    elif str(_type).upper() == 'NET':
        print json.dumps(getNetList(), indent=2)
        exit()
    elif str(_type).upper() == 'FS':
        print json.dumps(getFsList(), indent=2)
        exit()
    else:
        exit()
    
    
    
