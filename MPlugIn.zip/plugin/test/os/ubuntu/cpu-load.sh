#!/bin/bash

randint=`cat /proc/sys/kernel/random/uuid `
number1=${randint:35:1}
number=$((0x$number1))
val=`expr $number % 4`
#val=`expr $number % 10`
echo $val
