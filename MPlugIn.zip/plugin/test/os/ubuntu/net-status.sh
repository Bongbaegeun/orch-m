#!/bin/bash

### STATUS
if [ "$1" == "status" ] || [ "$1" == "STATUS" ]
then
	#randint=`cat /proc/sys/kernel/random/uuid `
	#number1=${randint:34:2}
	#number=$((0x$number1))
	#val=`expr $number % 1`
	#echo $val
	echo '1'
### RX_BPS
elif [ "$1" == "rx_rate" ] || [ "$1" == "RX_RATE" ]
then
	randint=`cat /proc/sys/kernel/random/uuid `
	number1=${randint:29:7}
	number=$((0x$number1))
	val=`expr $number % 100000000`
	#val=`expr $number % 300000000`
	echo $val
### TX_BPS
elif [ "$1" == "tx_rate" ] || [ "$1" == "TX_RATE" ]
then
	randint=`cat /proc/sys/kernel/random/uuid `
	number1=${randint:29:7}
	number=$((0x$number1))
	val=`expr $number % 100000000`
	#val=`expr $number % 300000000`
	echo $val
fi
