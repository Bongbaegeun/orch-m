#!/bin/bash

function getUtil(){
	randint=`cat /proc/sys/kernel/random/uuid `
	number1=${randint:34:2}
	number=$((0x$number1))
	val=`expr $number % 70`
	#val=`expr $number % 100`
	echo $val
}

function getFree(){
	echo '10000000000'
}

if [[ "$1" == "" || "$1" == "util" || "$1" == "UTIL" ]]
then
	getUtil
elif [[ "$1" == "free" || "$1" == "FREE" ]]
then
	getFree
else
	echo ''
fi 

