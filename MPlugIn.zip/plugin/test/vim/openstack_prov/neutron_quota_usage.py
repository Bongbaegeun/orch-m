#!/usr/bin/python

import sys, yaml, os
import random

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/vim_cfg.yaml'

FAULT_YN = False

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)


def getType(quotaType):
    if str(quotaType).upper() == "TOTAL":
        return 1
    elif str(quotaType).upper() == "USED":
        return 2
    else:
        return 0

def getNetInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total

def getSubNetInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total

def getPortInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total

def getRouterInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total

def getFloatingIpInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total

def getSecuGroupInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total

def getSecuGroupRuleInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total



if __name__ == '__main__':
    
    quotaName = None
    quotaType = None
    if len(sys.argv) >= 2:
        quotaName = sys.argv[1]
    if len(sys.argv) >= 3:
        quotaType = sys.argv[2]
    intType = getType(quotaType)
    
    if str(quotaName).upper() == "NETWORK":
        print( getNetInfo(intType) )
    elif str(quotaName).upper() == "SUBNET":
        print( getSubNetInfo(intType) )
    elif str(quotaName).upper() == "PORT":
        print( getPortInfo(intType) )
    elif str(quotaName).upper() == "ROUTER":
        print( getRouterInfo(intType) )
    elif str(quotaName).upper() == "FLOATINGIP":
        print( getFloatingIpInfo(intType) )
    elif str(quotaName).upper() == "SECUGROUP":
        print( getSecuGroupInfo(intType) )
    elif str(quotaName).upper() == "SECUGROUPRULE":
        print( getSecuGroupRuleInfo(intType) )
    else:
        print( "-1" )
    
