#!/usr/bin/python

import json, sys, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/neutron_prov_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)


def getPortList():
    ret = { "data": [] }
    
    for port in cfg['vim_port'] :
        uuid = ''
        mac = ''
        name = port

        ret["data"].append( { "{#UUID}": uuid, "{#MAC}": mac, "{#NAME}":name } )
    
    return ret

if __name__ == '__main__':
    
    listType = None
    if len(sys.argv) >= 2:
        listType = sys.argv[1]
    
    if str(listType).upper() == "PORT":
        print( json.dumps(getPortList(), indent=4) )
    else:
        print( json.dumps( { "data": [] }, indent=4 ) )
