#!/usr/bin/python

import json, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/nova_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)


def getVmList(netName):
    ret = { "data": [] }
    
    for tarName in cfg ['vim_vm']:
        uuid = ''
        mgmtIP = ''

        ret["data"].append( { "{#UUID}": uuid, "{#NAME}": tarName, "{#MGMTIP}": mgmtIP } )
    
    return ret

if __name__ == '__main__':
    print( json.dumps(getVmList(cfg["vim_mgmt_net"]), indent=4) )
