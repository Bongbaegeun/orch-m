#!/usr/bin/python

import json, sys, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/vim_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)


def getNetList():
    ret = { "data": [] }
    
    for vnet in cfg['vim_net'] :
        uuid = ''
        ret["data"].append( { "{#UUID}": uuid, "{#NAME}": vnet } )
    
    return ret

def getRouterList():
    ret = { "data": [] }
    
    for rt in cfg['vim_router']:
        uuid = ''
        ret["data"].append( { "{#UUID}": uuid, "{#NAME}": rt } )
    
    return ret

def getPortList():
    ret = { "data": [] }
    
    for port in cfg['vim_port'] :
        uuid = ''
        mac = ''
        name = port
        ret["data"].append( { "{#UUID}": uuid, "{#MAC}": mac, "{#NAME}":name } )
    
    return ret

if __name__ == '__main__':
    
    listType = None
    if len(sys.argv) >= 2:
        listType = sys.argv[1]
    
    if str(listType).upper() == "NET":
        print( json.dumps(getNetList(), indent=4) )
    elif str(listType).upper() == "ROUTER":
        print( json.dumps(getRouterList(), indent=4) )
    elif str(listType).upper() == "PORT":
        print( json.dumps(getPortList(), indent=4) )
    else:
        print( json.dumps( { "data": [] }, indent=4 ) )