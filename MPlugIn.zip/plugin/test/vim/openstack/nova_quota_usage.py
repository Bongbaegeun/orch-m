#!/usr/bin/python

import sys, yaml, os
import random

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/vim_cfg.yaml'

FAULT_YN = False

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

def getType(quotaType):
    if str(quotaType).upper() == "TOTAL":
        return 1
    elif str(quotaType).upper() == "USED":
        return 2
    else:
        return 0

def getInstanceInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total

def getCoreInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total

def getRamInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total

def getDiskInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total

def getKeyPairInfo(quotaType):
    total = 100
    if FAULT_YN :
        used = random.randint(0, 100)
    else:
        used = random.randint(0, 69)
    
    if quotaType == 1:      return total
    elif quotaType == 2:    return used
    else:
        return used*100/total



if __name__ == '__main__':
    
    quotaName = None
    quotaType = None
    if len(sys.argv) >= 2:
        quotaName = sys.argv[1]
    if len(sys.argv) >= 3:
        quotaType = sys.argv[2]
    intType = getType(quotaType)
    
    if str(quotaName).upper() == "INSTANCE":
        print( getInstanceInfo(intType) )
    elif str(quotaName).upper() == "CORE":
        print( getCoreInfo(intType) )
    elif str(quotaName).upper() == "RAM":
        print( getRamInfo(intType) )
    elif str(quotaName).upper() == "DISK":
        print( getDiskInfo(intType) )
    elif str(quotaName).upper() == "KEYPAIR":
        print( getKeyPairInfo(intType) )
    else:
        print( "-1" )
    
