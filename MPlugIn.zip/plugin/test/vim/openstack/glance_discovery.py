#!/usr/bin/python

import json, yaml, os

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/vim_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)


def getImageList():
    ret = { "data": [] }
    
    for image in cfg['vim_image']:
        uuid = ''
        size = ''
        ret["data"].append( { "{#UUID}": uuid, "{#NAME}": image, "{#SIZE}": size } )
    
    return ret

if __name__ == '__main__':
    print( json.dumps(getImageList(), indent=4) )