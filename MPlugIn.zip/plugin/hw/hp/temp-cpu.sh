#!/bin/bash

LOG_FILE="/var/log/zabbix-agent/os.log"

sensor_ret=$(sensors -u)
temps=$(echo "$sensor_ret" | grep temp | grep input | awk '{print $2}' 2> /dev/null )

prev_temp=0
is_chk=0
for temp in ${temps[*]}
do
	if [ "${temp%*.*}" -gt "$prev_temp" ]
	then
		prev_temp=${temp%*.*}
		is_chk=1
	fi
done

if [ "$is_chk" -gt "0" ]
then
	echo $prev_temp
	if [ ! -z "${prev_temp%%.*}" ] && (( "${prev_temp%%.*}" > "60" ))
	then
		echo "+++++++++++++++++++++++++++++++++" >> $LOG_FILE
		echo "[["`date`"]]" >> $LOG_FILE
		echo "$sensor_ret" >> $LOG_FILE
		echo "+++++++++++++++++++++++++++++++++" >> $LOG_FILE
	fi
fi
