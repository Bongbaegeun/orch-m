#!/bin/ash
LOG_FILE="/mnt/flash/data/onebox/zabbix/log/cpu-util.log"

#cpuutil=$(top -bn 1 | grep -i cpu\(s\)| awk '{print $5}' | tr -d "%id," | awk '{print 100-$1}')
cpuutil=$(top -bn 1 | grep -i cpu\(s\)| awk -F, '{print $4}' | tr -d "%id," | awk '{print 100-$1}')

NOW=`date +%Y-%m-%d_%T`
echo "DATE=${NOW}  UTIL= ${cpuutil}" >> ${LOG_FILE}
echo ${cpuutil}