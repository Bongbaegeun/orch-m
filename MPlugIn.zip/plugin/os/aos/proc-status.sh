#!/bin/ash

input=$*

if [ -z ${input} ]
then
    echo "0"
    exit 1
fi
    
cmd=$(ps -ef | grep -v grep | grep -v $0 | grep -c $input )

if [ ${cmd} -gt 0 ]
then               
    echo "1"       
else        
    echo "0"
fi