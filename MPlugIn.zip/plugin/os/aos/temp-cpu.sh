#!/bin/ash

LOG_FILE="/mnt/flash/data/onebox/zabbix/log/os.log"

sensor_ret=$(sensors)
sensor_u=$(sensors -u)

temps=$(echo "$sensor_ret" | grep -E '^Core' | awk '{print $3}' | grep -oE '[0-9.]*' 2> /dev/null )

if [ -z "$temps" ]; then
    temps=$(echo "$sensor_u"  | grep temp | grep input | awk '{print $2}' 2> /dev/null )
fi                                                                                      

prev_temp=0
is_chk=0

for temp in $temps
do
        if [ "${temp%*.*}" -gt "$prev_temp" ]
        then
                prev_temp=${temp%*.*}
                is_chk=1
        fi
done

if [ "$is_chk" -gt "0" ]
then
        echo $prev_temp
fi
