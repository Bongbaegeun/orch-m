#!/bin/ash
LOG_FILE="/mnt/flash/data/onebox/zabbix/log/ping.log"
PV=$(ping -qc5 168.126.63.1 2>&1 | awk -F'/' 'END{ print (/^rtt/? $5 :"None") }')

echo "++++++++++++++ ping +++++++++++++" >> $LOG_FILE
echo "[["`date`"]]" >> $LOG_FILE
if [  ${PV%%.*} -ge 10000 ]; then
	echo "Value exceeds : $PV" >> $LOG_FILE
	PV="None"
fi
echo "$PV" >> $LOG_FILE
echo "$PV"
