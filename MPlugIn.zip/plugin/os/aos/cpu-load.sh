#!/bin/ash
LOG_FILE="/mnt/flash/data/onebox/zabbix/log/cpu-load.log"
cpu_info=$(top -bn 3 -d 0.3 | head -n 30 | grep "load average" | tail -n 1)
NOW=`date`
loads=${cpu_info##*:}
echo "DATE= $NOW LOAD= ${loads%%,*}" >> ${LOG_FILE}
echo ${loads%%,*}
