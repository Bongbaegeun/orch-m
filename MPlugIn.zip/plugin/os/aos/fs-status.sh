#!/bin/ash

LOG_FILE="/mnt/flash/data/onebox/zabbix/log/os.log"

if [ $# != 2 ]
then
    exit 1
fi

if [ "$1" == "util" ] || [ "$1" == "UTIL" ]
then
    tmp=$(df | awk '{print $5 " " $6}' 2> /dev/null)
    tmp=$(echo $?)
    if [ "$tmp" -eq "0" ]
    then
        fs_list=$(df $2 | awk '{print $5 " " $6}')
        util_rate=$(echo "$fs_list" | grep $2 | grep '%' )
    else
        fs_list=$(df $2)
        util_rate=$(echo "$fs_list" | grep $2 | grep '%' )
    fi
    utilrate1=${util_rate%%\%*}
    utilrate=${utilrate1##* }
	
    if [ -z "$utilrate" ]
    then
       echo "0"
    else
       echo $utilrate
    fi
    
    if [ ! -z "${utilrate%%.*}" ] && [ "${utilrate%%.*}" -gt 90 ]
    then
        echo "++++++++++++ fs util ++++++++++++" >> $LOG_FILE
        echo "[["`date`"]]" >> $LOG_FILE
        echo "$fs_list" >> $LOG_FILE
        echo "+++++++++++++++++++++++++++++++++" >> $LOG_FILE
    fi

fi

