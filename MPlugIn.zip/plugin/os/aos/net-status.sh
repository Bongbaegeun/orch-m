#!/bin/ash

EXEC_FILE="$0"
BASE_NAME=`basename "$EXEC_FILE"`
if [ "$EXEC_FILE" = "./$BASE_NAME" ] || [ "$EXEC_FILE" = "$BASE_NAME" ]; then
        FULL_PATH=`pwd`
else
        FULL_PATH=`echo "$EXEC_FILE" | sed 's/'"${BASE_NAME}"'$//'`
        cd "$FULL_PATH"                 > /dev/null 2>&1
        FULL_PATH=`pwd`
fi

dat_dir="/mnt/flash/data/onebox/zabbix/"
log_file="/mnt/flash/data/onebox/zabbix/log/os.log"


_log(){
    echo "[$(date +%Y%m%d.%H%M%S.%N)] $1" >> $log_file
}


if [ ! -d $dat_dir ]
then
    mkdir $dat_dir
fi

if [ $# != 2 ]
then
    exit 1
fi

_chk_nic=$(ifconfig $2 2>&1)
_chk_nic_ret=$(echo $?)

bps_monitor(){
    bit_fname=$1
    bytes=$2
    
    let "bits=$bytes*8"
    date_sec=$(date +%s.%N)

    
    if [ ! -f $bit_fname ]
    then
        echo 0
    else
        prv_dat=$(cat $bit_fname)
        prv_bits=${prv_dat%%,*}
        prv_date=${prv_dat##*,}
        if [ "$prv_bits" == "" ] || [ "$prv_date" == "" ] || [ "$bits" == "" ] || [ "$date_sec" == "" ]
        then 
            echo "0"
        else
            if [ ${bits} -ge ${prv_bits} ]
            then
                # bps=$(echo "($bits-$prv_bits)/($date_sec-$prv_date)"|bc)
                bps=`echo $bits $prv_bits $date_sec $prv_date | awk '{print int(($1-$2)/($3-$4))}'`
                if [ "$bps" == "0" ]
                then
                    echo "0"
                else
                    if [ "${bps%%.*}" == "" ]
                    then
                        echo "0$bps"
                    else
                        echo $bps
                    fi
                fi
            fi
        fi
        #let "bps=($bits-$prv_bits)/($date_sec-$prv_date)"
        #echo $bps
    fi
    
    echo $bits,$date_sec > $bit_fname
    
}

### STATUS
if [ "$1" == "status" ] || [ "$1" == "STATUS" ]
then
    
    net_info=$(/usr/sbin/ethtool $2 2>/dev/null | grep "Link detected:")
    state=${net_info##*:}
    if [ ${state} == "yes" ]
    then
        echo "1"
    else
        echo "0"
    fi
    
### RX_BPS
elif [ "$1" == "rx_rate" ] || [ "$1" == "RX_RATE" ]
then
    bit_fname="$dat_dir/$2_rx_bits.dat"
    bytes=$(cat /sys/class/net/$2/statistics/rx_bytes )
    bps_monitor $bit_fname $bytes
### TX_BPS
elif [ "$1" == "tx_rate" ] || [ "$1" == "TX_RATE" ]
then
    bit_fname="$dat_dir/$2_tx_bits.dat"
    bytes=$(cat /sys/class/net/$2/statistics/tx_bytes )
    bps_monitor $bit_fname $bytes
fi
