#!/bin/bash

input=$*
cmd="ps -ef | grep -v grep | grep -v $0 | grep -c \"$input\""
eval $cmd
