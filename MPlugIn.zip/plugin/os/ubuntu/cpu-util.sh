#!/bin/bash

LOG_FILE="/var/log/zabbix-agent/os.log"

cpu_list=$(top -bn 3 -d 0.3 | head -n 30)
cpu_info=$(echo "$cpu_list" | grep "Cpu" | tail -n 1)

#echo $cpu_info
NOW=`date`
idle=${cpu_info##*ni,}
#echo $loads
echo "DATE= $NOW LOAD= ${util%%,*}" >> /tmp/cpu-load.log
tmp=$(expr index "$idle" "%")
if [ "$tmp" -gt "0" ]
then
	usage=${idle%%\%id,*}
else
	usage=${idle%% id,*}
fi
util=$(echo "100.0-$usage"|bc)
if [ "$util" == "0" ]
then
	echo "0.0"
else
	if [ "${util%%.*}" == "" ]
	then
		echo "0$util"
	else
		echo $util
		if [ ! -z "${util%%.*}" ] && (( "${util%%.*}" > 90 ))
		then
			echo "++++++++++ cpu util +++++++++++++" >> $LOG_FILE
			echo "[["`date`"]]" >> $LOG_FILE
			echo "$cpu_list" >> $LOG_FILE
			echo "+++++++++++++++++++++++++++++++++" >> $LOG_FILE
		fi
	fi
fi




