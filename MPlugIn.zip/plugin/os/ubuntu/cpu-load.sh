#!/bin/bash

cpu_info=$(top -bn 3 -d 0.3 | head -n 30 | grep "load average" | tail -n 1)

#echo $cpu_info
NOW=`date`
loads=${cpu_info##*:}
#echo $loads
echo "DATE= $NOW LOAD= ${loads%%,*}" >> /tmp/cpu-load.log
echo ${loads%%,*}
