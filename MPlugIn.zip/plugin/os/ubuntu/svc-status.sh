#!/bin/bash

LOG_FILE="/var/log/zabbix-agent/os.log"

svc_info=$(service $1 status 2>/dev/null)

ret=$(echo "$svc_info" | grep -v "not" | grep -ci "running\|online\|실행" 2>/dev/null)

if [ -z "${ret}" ] || (( "${ret}" < 1 ))
then
	echo "+++++++++++++ svc +++++++++++++++" >> $LOG_FILE
	echo "[["`date`"]]" >> $LOG_FILE
	echo "svc : $1" >> $LOG_FILE
	echo "$svc_info" >> $LOG_FILE
	echo "+++++++++++++++++++++++++++++++++" >> $LOG_FILE
fi


NOW=`date`
echo "DATE= $NOW SVC= $1 COUNT= ${ret}" >> /tmp/svc-$1-status.log
echo $ret

