#!/bin/bash

EXEC_FILE="$0"
BASE_NAME=`basename "$EXEC_FILE"`
if [ "$EXEC_FILE" = "./$BASE_NAME" ] || [ "$EXEC_FILE" = "$BASE_NAME" ]; then
        FULL_PATH=`pwd`
else
        FULL_PATH=`echo "$EXEC_FILE" | sed 's/'"${BASE_NAME}"'$//'`
        cd "$FULL_PATH"                 > /dev/null 2>&1
        FULL_PATH=`pwd`
fi

dat_dir="/var/log/zabbix-agent/dat"
log_file="/var/log/zabbix-agent/os.log"


function _log(){
	echo "[$(date +%Y%m%d.%H%M%S.%N)] $1" >> $log_file
}


if [ ! -d $dat_dir ]
then
	mkdir $dat_dir
fi

if [ $# != 2 ]
then
	exit 1
fi


NIC_DRV="kern"

_chk_nic=$(ifconfig $2 2>&1)
_chk_nic_ret=$(echo $?)
if (( "$_chk_nic_ret" > 0 ))
then
	_dpdk_chk=$(ovs-vsctl get interface $2 options 2> /dev/null | grep -c dpdk )
	if (( "$_dpdk_chk" > 0 ))
	then
		NIC_DRV="dpdk"
	else
		_log "Fail to Find NIC Info, nic=$2"
		exit 1
	fi
fi


function bps_monitor(){
	bit_fname=$1
	bytes=$2
	
	let "bits=$bytes*8"
	date_sec=$(date +%s.%N)
	
	if [ ! -f $bit_fname ]
	then
		echo 0
	else
		prv_dat=$(cat $bit_fname)
		prv_bits=${prv_dat%%,*}
		prv_date=${prv_dat##*,}
		
		if [ "$prv_bits" == "" ] || [ "$prv_date" == "" ] || [ "$bits" == "" ] || [ "$date_sec" == "" ]
		then 
			echo "0"
		else
			if (( "$bits" >= "$prv_bits" ))
			then
				bps=$(echo "($bits-$prv_bits)/($date_sec-$prv_date)"|bc)
				if [ "$bps" == "0" ]
				then
					echo "0"
				else
					if [ "${bps%%.*}" == "" ]
					then
						echo "0$bps"
					else
						echo $bps
					fi
				fi
			fi
		fi
		#let "bps=($bits-$prv_bits)/($date_sec-$prv_date)"
		#echo $bps
	fi
	
	echo $bits,$date_sec > $bit_fname
	
}


function get_dpdk_nic_byte(){
	if_name=$1
	mon_type=$2
	
	_data=$(ovs-vsctl get interface $if_name statistics 2>&1)
	_chk_data=$(echo "$_data" | grep rx_bytes | grep tx_bytes)
	if [ "$_chk_data" == "" ]
	then
		_log "Fail to Get OVS-DPDK NIC Info, nic=$if_name, type=$mon_type, ret=$_data"
		exit 1
	fi
	
	_tmp_data=${_data#*"$mon_type"_bytes=*}
	_bytes=${_tmp_data%%,*}
	
	if [ "$_bytes" == "" ]
	then
		_log "test, f=$bit_fname, n=$if_name, t=$mon_type, bytes=$_bytes, data=$_chk_data"
	fi
	echo $_bytes
}



### STATUS
if [ "$1" == "status" ] || [ "$1" == "STATUS" ]
then
	
	## dpdk nic
	if [ "$NIC_DRV" == "dpdk" ]
	then
		net_info=$(ovs-vsctl get interface $2 link_state 2>&1)
		if [ "$net_info" == "up" ]
		then
			echo "1"
		elif [ "$net_info" == "down" ]
		then
			echo "0"
		else
			_log "DPDK-NIC Down, nic=$2, ret=$net_info"
			echo "0"
		fi
	## kern nic
	else
		net_info=$(/sbin/ethtool $2 2>/dev/null | grep "Link detected:")
		state=${net_info##*:}
		if [ ${state} == "yes" ]
		then
			echo "1"
		else
			echo "0"
		fi
	fi
	
	
### RX_BPS
elif [ "$1" == "rx_rate" ] || [ "$1" == "RX_RATE" ]
then
	bit_fname="$dat_dir/$2_rx_bits.dat"
	if [ "$NIC_DRV" == "dpdk" ]
	then
		bytes=$(get_dpdk_nic_byte $2 "rx")
	else
		bytes=$(cat /sys/class/net/$2/statistics/rx_bytes )
	fi
	bps_monitor $bit_fname $bytes
### TX_BPS
elif [ "$1" == "tx_rate" ] || [ "$1" == "TX_RATE" ]
then
	bit_fname="$dat_dir/$2_tx_bits.dat"
	if [ "$NIC_DRV" == "dpdk" ]
	then
		bytes=$(get_dpdk_nic_byte $2 "tx")
	else
		bytes=$(cat /sys/class/net/$2/statistics/tx_bytes )
	fi
	bps_monitor $bit_fname $bytes
fi
