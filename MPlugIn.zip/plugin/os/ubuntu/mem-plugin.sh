#!/bin/bash

LOG_FILE="/var/log/zabbix-agent/os.log"

mem_info=$(cat /proc/meminfo)

mem_tot=$(echo "$mem_info" | grep "^MemTotal")
total=${mem_tot##*:}
total=$(echo $total | awk '{print $1}')

mem_free=$(echo "$mem_info" | grep "^MemFree")
free=${mem_free##*:}
free=$(echo $free | awk '{print $1}')

mem_buffer=$(echo "$mem_info" | grep "^Buffers")
buffer=${mem_buffer##*:}
buffer=$(echo $buffer | awk '{print $1}')

mem_cache=$(echo "$mem_info" | grep "^Cached")
cache=${mem_cache##*:}
cache=$(echo $cache | awk '{print $1}')

function getUtil(){
	if [[ "$total" == "" || "$total" == "0" ]]
	then
		echo '0'
	else
		let "util=($total-$free-$buffer-$cache)*100/($total)"
		echo $util
		if [ ! -z "${util%%.*}" ] && (( "${util%%.*}" > 90 ))
		then
			echo "+++++++++++ mem util ++++++++++++" >> $LOG_FILE
			echo "[["`date`"]]" >> $LOG_FILE
			echo "$mem_info" >> $LOG_FILE
			echo "+++++++++++++++++++++++++++++++++" >> $LOG_FILE
		fi
	fi
}

function getFree(){
	if [[ "$total" == "" || "$total" == "0" ]]
	then
		echo '0' 
	else
		let "Free=($free+$buffer+$cache)*100/($total)"
		echo $Free
	fi
}

if [[ "$1" == "" || "$1" == "util" || "$1" == "UTIL" ]]
then
	getUtil
elif [[ "$1" == "free" || "$1" == "FREE" ]]
then
	getFree
else
	echo ''
fi 

