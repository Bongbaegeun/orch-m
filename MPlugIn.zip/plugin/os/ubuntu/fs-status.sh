#!/bin/bash

LOG_FILE="/var/log/zabbix-agent/os.log"

if [ $# != 2 ]
then
	exit 1
fi

if [ "$1" == "util" ] || [ "$1" == "UTIL" ]
then
	tmp=$(df --output=pcent,target 2> /dev/null)
	tmp=$(echo $?)
	if [ "$tmp" -eq "0" ]
	then
		fs_list=$(df $2 --output=pcent,target)
		util_rate=$(echo "$fs_list" | grep $2 | grep '%' )
	else
		fs_list=$(df $2)
		util_rate=$(echo "$fs_list" | grep $2 | grep '%' )
	fi
	utilrate1=${util_rate%%\%*}
	utilrate=${utilrate1##* }
	echo $utilrate
	if [ ! -z "${utilrate%%.*}" ] && (( "${utilrate%%.*}" > 90 ))
	then
		echo "++++++++++++ fs util ++++++++++++" >> $LOG_FILE
		echo "[["`date`"]]" >> $LOG_FILE
		echo "$fs_list" >> $LOG_FILE
		echo "+++++++++++++++++++++++++++++++++" >> $LOG_FILE
	fi
	exit 1
elif [ "$1" == "test" ] || [ "$1" == "TEST" ]
then
	echo $1
	exit 1	
fi

