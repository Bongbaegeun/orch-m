#!/usr/bin/python
#-*- coding: utf-8 -*-

from datetime import datetime, timedelta

import waf_api
from waf_api import Logger
import sys, json, yaml, os, logging

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/waf_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger( logName='waf', logDir='/var/log/zabbix-agent', logFile='waf.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG ).instance()

ip = cfg['vm_ip']
ID = cfg['vm_app_id']
PASSWD = cfg['vm_app_passwd']

PERIOD_CPUMEM = 5
PERIOD_TRAFFIC = 5
PERIOD_NET = 20

CMDS = {
       "AUTH" : """ curl --insecure -H "Expect:" \
                -vX POST https://%s/webapi/auth \
                -d 'id=%s&password=%s' """,
       "DB" :   """ curl --insecure -s \
                -H "Content-Type:application/x-www-form-urlencoded" \
                -b "WP_SESSID=%s" \
                -X GET https://%s/webapi/status/database """,
        "ENGINE":   """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET https://%s/webapi/status/detection_engine """,
        "CPUINFO":  """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET https://%s/webapi/info/system/cpu """,
        "CPUMEM":   """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET "https://%s/webapi/statistics/system/cpu_mem?get_count=%s" """,
        "TRAFFIC":  """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET "https://%s/webapi/statistics/system/traffic?get_count=%s" """,
        "NET":      """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET "https://%s/webapi/statistics/nic_stat?stime=%s&etime=%s&interface_name_include=%s" """,
        "TIME": """ curl --insecure -H "Content-Type:application/x-www-form-urlencoded" \
                -b "WP_SESSID=%s" \
                -vX GET https://%s/webapi/info/version """,
        "NETINFO":  """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET https://%s/webapi/status/network_interface?interface_name=%s """,
       }


def checkPing(ip):
    cmd = """ ping %s -c 2 -W 1 | grep 'transmitted' | awk '{print $4}' """%str(ip)
    
    res = waf_api.execute( logger, cmd )
    return int(res)

def getResp( cmd ):
    res = waf_api.execute( logger, cmd )
    for line in str(res).split("\n"):
        try:
            vals = json.loads( line )
            return vals
        except Exception, e:
#             logger.debug('GetResp Fail, cmd=%s, line=%s'%(str(cmd), str(line)))
            logger.exception(e)
    
    logger.error('Invalid Return Value, val=%s'%str(res))
    return None


def getAuth( ip, _id, passwd ):
    cmd = CMDS["AUTH"]%(ip, _id, passwd)
    res = waf_api.execute( logger, cmd )
    
    for line in str(res).split("\n"):
        start_idx = str( line ).find( "WP_SESSID=" )
        if start_idx > 0:
            start_idx = str( line ).find( "=", start_idx ) + 1
            end_idx = str( line ).find( ";", start_idx )
            if end_idx > start_idx :
                return str( line )[start_idx:end_idx]
    
    return None

def getDataTime( auth, ip, gap=0 ):
    cmd = CMDS["TIME"]%(auth, ip)
    res = waf_api.execute( logger, cmd )
    
    for line in str(res).split("\n"):
        start_idx = str( line ).find( "Date:" )
        if start_idx > 0:
            start_idx += 6
            end_idx = str( line ).find( "GMT", start_idx ) - 1
            if end_idx > start_idx :
                strDate = str( line )[start_idx:end_idx]
                now = datetime.strptime(strDate, "%a, %d %b %Y %H:%M:%S")
                return now.isoformat(), (now + timedelta(seconds=gap)).isoformat()
    
    return None, None

def dbUsage( auth, ip, _type ):
    cmd = CMDS["DB"]%(auth, ip)
    vals = getResp( cmd )
    if vals == None: 
        logger.error('None DB Value')
        return None
    
    if str(_type).upper() == "TOTAL":
        return vals["total_size"]
    elif str(_type).upper() == "USED":
        return vals["used_size"]
    elif str(_type).upper() == "FREE":
        return vals["available_size"]
    elif str(_type).upper() == "UTIL":
        return int(round(float(vals["used_size"])*100/float(vals["total_size"])))
    else:
        logger.error('Unknown DB Type, type=%s'%str(_type))
        return None

def engineInfo( auth, ip, _type ):
    cmd = CMDS["ENGINE"]%(auth, ip)
    vals = getResp( cmd )
    if vals == None: 
        logger.error('None Engine Value')
        return None
    
    if str(_type).upper() == "COUNT":
        return vals["de_total"]
    elif str(_type).upper() == "STATUS":
        for info in vals["de_info"]:
            if str(info["status"]).upper() != "NORMAL":
                return 0
        return 1
    elif str(_type).upper() == "CPU_UTIL":
        utils = 0 
        for info in vals["de_info"]:
            utils += info["cpu_used_rate"]
        return utils/int(vals["de_total"])
    else:
        logger.error('Unknown Engine Type, type=%s'%str(_type))
        return None

def cpuInfo( auth, ip, _type ):
    cmd = CMDS["CPUINFO"]%(auth, ip)
    vals = getResp(cmd)
#     logger.info( "CMD=%s, RES=\n%s"%(cmd, json.dumps(vals,indent=4)) )
    if vals == None: 
        logger.error('None CpuInfo Value')
        return None
    
    if str(_type).upper() == "COUNT":
        return vals["core_count"]
    elif str(_type).upper() == "NAME":
        return vals["model_name"]
    elif str(_type).upper() == "P_COUNT":
        return vals["physical_cpu_count"]
    elif str(_type).upper() == "L_COUNT":
        return vals["logical_cpu_count"]
    else:
        logger.error('Unknown CPUInfo Type, type=%s'%str(_type))
        return None

def cpumemUsage( auth, ip, target, _type, period ):
    cmd = CMDS["CPUMEM"]%(auth, ip, int(period)/PERIOD_CPUMEM)
    vals = getResp(cmd)
    if vals == None: 
        logger.error('None CPU/MEM Value')
        return None
    
    if type(vals["result"]) != list:
        logger.error('CPU/MEM Result is not List, val=%s'%str(vals['result']))
        return None
    
    cnt = memTotal = memFree = cpuIdle = memBuff = memCach = 0
    for val in vals["result"] :
        cnt += 1
        memTotal = val["memory_total"]
        memFree += val["memory_free"]
        memBuff += val["memory_buffer"]
        memCach += val["memory_cache"]
        cpuIdle += val["cpu_idle"]
    
    if cnt == 0:
        logger.error('CPU/MEM Count is 0')
        return None
    
    memFree = memFree/cnt
    memUsed = (memTotal - memFree - memBuff - memCach)/cnt
    cpuIdle = cpuIdle/cnt
    
    if str(target).upper() == "MEM":
        if str(_type).upper() == "TOTAL":
            return memTotal
        elif str(_type).upper() == "USED":
            return memUsed
        elif str(_type).upper() == "FREE":
            return memFree
        elif str(_type).upper() == "UTIL":
            return memUsed*100/memTotal
        else:
            logger.error('Unknown Mem Type, type=%s'%str(_type))
            return None
    elif str(target).upper() == "CPU":
        if str(_type).upper() == "UTIL":
            return 100 - cpuIdle
        else:
            logger.error('Unknown CPU Type, type=%s'%str(_type))
            return None
    else:
        logger.error('Unknown Cpu/Mem Type, target=%s'%str(target))
        return None

def trafficUsage( auth, ip, _type, period ):
    cmd = CMDS["TRAFFIC"]%(auth, ip, int(period)/PERIOD_TRAFFIC)
    vals = getResp(cmd)
    if vals == None: 
        logger.error('None Traffic Value')
        return None
    
    if type(vals["result"]) != list:
        logger.error('Traffic Result is not List, val=%s'%str(vals['result']))
        return None
    
    cnt = cps = tps = rate = 0
    for val in vals["result"] :
        cnt += 1
        cps += val["cps"]
        tps += val["tps"]
        rate += val["throughput"]
    
    if cnt == 0:
        logger.error('Traffic Count is 0')
        return None
    
    cps = cps/cnt
    tps = tps/cnt
    rate = rate/cnt
    
    if str(_type).upper() == "CPS":
        return cps
    elif str(_type).upper() == "TPS":
        return tps
    elif str(_type).upper() == "RATE":
        return rate
    else:
        logger.error('Unknown Traffic Type, type=%s'%str(_type))
        return None

def netUsage( auth, ip, _type, period, name ):
    if period == None or period == '' :
        period = PERIOD_NET
        
    etime, stime = getDataTime(auth, ip, -int(period))
    cmd = CMDS["NET"]%(auth, ip, stime, etime, name)
    vals = getResp(cmd)
    if vals == None:
        logger.error('None NetUsage Value')
        return None
    
    if type(vals["result"]) != list:
        logger.error('NetUsage Result is not List, val=%s'%str(vals['result']))
        return None
    
    statType = ""
    if str(_type).upper() == "RX_ERR":
        statType = "rx_err_avg"
    elif str(_type).upper() == "TX_ERR":
        statType = "tx_err_avg"
    elif str(_type).upper() == "RX_PKT":
        statType = "rx_pkt_avg"
    elif str(_type).upper() == "TX_PKT":
        statType = "tx_pkt_avg"
    elif str(_type).upper() == "RX_BYTE":
        statType = "rx_bytes_avg"
    elif str(_type).upper() == "TX_BYTE":
        statType = "tx_bytes_avg"
    elif str(_type).upper() == "RX_DROP":
        statType = "rx_drop_avg"
    elif str(_type).upper() == "TX_DROP":
        statType = "tx_drop_avg"
    elif str(_type).upper() == "COLLISION":
        statType = "collisions"
    else:
        logger.error('Unknown NetUsage Type, type=%s'%str(_type))
        return None
    
    cnt = nicStat = 0
    for val in vals["result"] :
        if str(val["interface_name"]).upper() == str(name).upper():
            for stat in val["statistics"]:
                cnt += 1
                nicStat += stat[statType]
            break
    
    if cnt == 0:
        logger.error('NetUsage Count is 0')
        return None
    else:
        return nicStat/cnt

def netInfo( auth, ip, _type, name ):
    cmd = CMDS["NETINFO"]%(auth, ip, name)
    vals = getResp(cmd)
    if vals == None: 
        logger.error('None NetInfo Value')
        return None
    
    for val in vals:
        if str(val["interface_name"]).upper() == str(name).upper():
            if str(_type).upper() == "STATUS":
                if str(val["link"]).upper() == "UP":
                    return 1
                else:
                    return 2
            elif str(_type).upper() == "SPEED":
                return val["speed"]
            else:
                logger.error('Unknown NetInfo Type, type=%s'%str(_type))
                return None
    
    logger.error('Invalid NetInfo Value, val=%s'%str(vals))
    return None


if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            auth = getAuth( ip, ID, PASSWD)
            chkType = str(sys.argv[1]).upper()
            
            if chkType == "PING":
                print( checkPing(ip) )
                exit(0)
            elif chkType == "DB":
                print( dbUsage(auth, ip, sys.argv[2]) )
                exit(0)
            elif chkType == "ENGINE":
                print( engineInfo(auth, ip, sys.argv[2]) )
                exit(0)
            elif chkType == "CPUINFO":
                print( cpuInfo(auth, ip, sys.argv[2]) )
                exit(0)
            elif chkType == "CPU" or chkType == "MEM":
                if len(sys.argv) > 3 and str(sys.argv[3]) != '' :
                    period = int(sys.argv[3])
                else :
                    period = PERIOD_CPUMEM
                print( cpumemUsage(auth, ip, sys.argv[1], sys.argv[2], period) )
                exit(0)
            elif chkType == "TRAFFIC":
                if len(sys.argv) > 3 and str(sys.argv[3]) != '' :
                    period = int(sys.argv[3])
                else :
                    period = PERIOD_TRAFFIC
                print( trafficUsage(auth, ip, sys.argv[2], period) )
                exit(0)
            elif chkType == "NET":
                if len(sys.argv) > 4 and str(sys.argv[3]) != '' :
                    period = int(sys.argv[3])
                    name = str(sys.argv[4])
                else :
                    period = PERIOD_NET
                    name = str(sys.argv[3])
                print( netUsage(auth, ip, sys.argv[2], period, name) )
                exit(0)
            elif chkType == "NETINFO":
                print( netInfo(auth, ip, sys.argv[2], sys.argv[3]) )
                exit(0)
            
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger.exception(e)
        print None



