#!/usr/bin/python
#-*- coding: utf-8 -*-

import waf_api
from waf_api import Logger
import sys, json, yaml, os, logging

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/waf_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger( logName='waf', logDir='/var/log/zabbix-agent', logFile='waf.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG ).instance()

ip = cfg['vm_ip']
ID = cfg['vm_app_id']
PASSWD = cfg['vm_app_passwd']

CMDS = {
       "AUTH" : """ curl --insecure -H "Expect:" -vX \
                POST https://%s/webapi/auth \
                -d 'id=%s&password=%s' """,
        "NETINFO":  """ curl --insecure -s \
                    -H "Content-Type:application/x-www-form-urlencoded" \
                    -b "WP_SESSID=%s" \
                    -X GET https://%s/webapi/status/network_interface """
       }

def getResp( cmd ):
    res = waf_api.execute( logger, cmd )
    for line in str(res).split("\n"):
        try:
            vals = json.loads( line )
            return vals
        except Exception, e:
#             logger.error('GetResp Err, cmd=%s, line=%s'%(str(cmd), str(line)))
            logger.exception(e)
    
    return None


def getAuth( ip, _id, passwd ):
    cmd = CMDS["AUTH"]%(ip, _id, passwd)
    res = waf_api.execute( logger, cmd )
    
    for line in str(res).split("\n"):
        start_idx = str( line ).find( "WP_SESSID=" )
        if start_idx > 0:
            start_idx = str( line ).find( "=", start_idx ) + 1
            end_idx = str( line ).find( ";", start_idx )
            if end_idx > start_idx :
                return str( line )[start_idx:end_idx]
    
    return None

def netList( auth, ip ):
    ret = { "data": [] }

    cmd = CMDS["NETINFO"]%(auth, ip)
    vals = getResp(cmd)
    if vals == None: return ret
    
    for val in vals:
        if val["interface_name"] in cfg['vm_net']:
            ret["data"].append( { "{#NAME}": val["interface_name"], "{#SPEED}": val["speed"], "{#LINK}": val["link"] } )
    
    return ret

if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            auth = getAuth( ip, ID, PASSWD)
            chkType = str(sys.argv[1]).upper()
            
            if str(chkType).upper() == "NETLIST":
                print( json.dumps(netList(auth, ip), indent=4) )
                exit(0)
#             elif chkType == "ENGINE":
#                 print( engineInfo(auth, ip, sys.argv[2]) )
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger.exception(e)
        print None



