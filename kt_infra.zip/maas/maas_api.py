#!/usr/bin/python
#-*- coding: utf-8 -*-


import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
HEADER1={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"}
METHOD="POST"

URL = "http://211.224.204.147/MAAS"

def callZB( url, reqBody, _method ):
    
    http_client = httpclient.HTTPClient()
    h = HTTPHeaders(HEADER)
    strBody = None
    if reqBody != None :
        strBody = json.dumps( reqBody )
    _request = HTTPRequest( url, headers=h, method=_method.upper(), body=strBody, request_timeout=10 )
    
    response = http_client.fetch( request=_request )
    http_client.close()
    
    resp = json.loads(response.body)
    
    return resp


def runAPI(arg):
    print(callZB(URL+'/api/1.0/nodes/?op=list', None, 'GET'))
    print(callZB(URL+'/api/1.0/account', {'op':'create_authorisation_token'}, 'POST'))





if __name__ == '__main__':
    runAPI(sys.argv)

