#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER = {"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'
NEW_PRT_SVR = 'NP'

REAL_PLG = 'R'
TEST_PLG = 'T'

URL = "http://211.224.204.207:8080/api"
URL_D = "http://211.224.204.207:8080/api"
URL_S = "http://211.224.204.244:8080/api"
URL_NP = "http://220.123.31.84:8080/api"

def callZB( url, reqBody=None ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	if reqBody == None:
		strBody = None
	elif type(reqBody) == str:
		strBody = reqBody
	else:
		strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def oneTouchOB(sType, _cmd):
	
	DOM = 'kt'
	UID = 'kttest012'
	UPW = '12341234'
	REQID = 'kttest25'
	REQPW = '1234'
	
	test = 'domain=%s&userId=%s'%(DOM, UID)
	
	if sType == DEV_SVR :
		url = URL_D
	elif sType == STG_SVR :
		url = URL_S
	elif sType == NEW_PRT_SVR :
		url = URL_NP
	else:
		print 'USAGE: CMD [D/S/NP] FUNC[CHK/REG/VIEW/DEL]'
		return
	
	if _cmd == 'CHK' :
		url += '/checkAccount.json'
		test += '&userPwd=%s'%(UPW)
	elif _cmd == 'REG' :
		url += '/registerAccount.json'
		test += '&userNm=%s&userPwd=%s&reqUserId=%s&reqPwd=%s&authStart=%s&authEnd=%s'%(
					'apitest', UPW, REQID, REQPW, '20160912', '20161012')
		if False :
			test += '&email=%s&telno=%s'%('test@kt.com', '010123443221')
	elif _cmd == 'VIEW' :
		url += '/viewAccount.json'
		test += '&reqUserId=%s&reqPwd=%s'%(REQID, REQPW)
	elif _cmd == 'DEL' :
		url += '/deleteAccount.json'
		test += '&reqUserId=%s&reqPwd=%s'%(REQID, REQPW)
	else :
		print 'USAGE: CMD [D/S/NP] FUNC[CHK/REG/VIEW/DEL]'
		return
	
	
	print( callZB( url, test ) )


if __name__ == '__main__':
	if len(sys.argv) >= 3:
		oneTouchOB(sys.argv[1], sys.argv[2])
	else:
		print 'USAGE: CMD [D/S/NP] FUNC[CHK/REG/VIEW/DEL]'
# 	if len(sys.argv) >= 2:
# 		svrNum = int(sys.argv[1])
# 		if svrNum == 1:
# 			oneTouchOB01()
# 		elif svrNum == 3:
# 			oneTouchOB03()
# 		elif svrNum == 4:
# 			oneTouchOB04()


