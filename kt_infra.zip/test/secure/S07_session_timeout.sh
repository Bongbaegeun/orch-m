#!/bin/bash

BACK_FILE="./session_timeout.back"

## CONFIG Modify
CONF_FILE="/etc/profile"
CHK_CONF=$(cat $CONF_FILE | grep "^export TMOUT")
if [ -z "$CHK_CONF" ]
then
	echo "export TMOUT=900" >> $CONF_FILE
	echo "N" >> $BACK_FILE
else
	echo "Y:$CHK_CONF" >> $BACK_FILE
	sed -i "s/^export TMOUT.*/export TMOUT=900/g" $CONF_FILE
fi

echo "Edit config --> $(grep "^export TMOUT" $CONF_FILE)"

