#!/bin/bash

BACK_FILE1="./pass_min_day.back1"

## CONFIG Modify
CONF_FILE="/etc/login.defs"
CHK_CONF=$(cat $CONF_FILE | grep "^PASS_MIN_DAYS")
if [ -z "$CHK_CONF" ]
then
	echo "PASS_MIN_DAYS 1" >> $CONF_FILE
	echo "N" >> $BACK_FILE1
else
	echo "Y:$CHK_CONF" >> $BACK_FILE1 
	sed -i "s/^PASS_MIN_DAYS.*/PASS_MIN_DAYS 1/g" $CONF_FILE
fi

echo "Edit config --> $(grep "^PASS_MIN_DAYS" $CONF_FILE)"

