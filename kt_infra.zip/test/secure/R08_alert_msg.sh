#!/bin/bash

BACK_FILE1="./alert_msg1.back"
BACK_FILE2="./alert_msg2.back"

## Config Restore
CONF_FILE="/etc/issue.net"
CHK_CONF1=$(cat $BACK_FILE1 | awk -F ":" '{print $1}')
CHK_CONF2=$(cat $BACK_FILE1 | awk -F ":" '{print $2}')
if [ "${CHK_CONF1}" == "N" ]
then
	sed -i "/^BANNER.*/d" $CONF_FILE
else
	sed -i "s/^BANNER.*/$CHK_CONF2/g" $CONF_FILE
fi

echo "Restore Line --> $(grep "^BANNER" $CONF_FILE)"

if [ -f $BACK_FILE1 ]
then
	rm $BACK_FILE1
	echo "Remove BackupFile, $BACK_FILE1"
fi


CONF_FILE="/etc/issue"
CHK_CONF1=$(cat $BACK_FILE2 | awk -F ":" '{print $1}')
CHK_CONF2=$(cat $BACK_FILE2 | awk -F ":" '{print $2}')
if [ "${CHK_CONF1}" == "N" ]
then
	sed -i "/^BANNER.*/d" $CONF_FILE
else
	sed -i "s/^BANNER.*/$CHK_CONF2/g" $CONF_FILE
fi

echo "Restore Line --> $(grep "^BANNER" $CONF_FILE)"

if [ -f $BACK_FILE2 ]
then
	rm $BACK_FILE2
	echo "Remove BackupFile, $BACK_FILE2"
fi
