#!/bin/bash

apt-get -y install make gcc

if [ ! -f "./openssl-1.0.1k.tar.gz" ]
then
	wget http://www.openssl.org/source/openssl-1.0.1k.tar.gz	
fi

tar -xvzf openssl-1.0.1k.tar.gz
cd openssl-1.0.1k
./config --prefix=/usr/
make
make install

cd ..

rm -r -f ./openssl-1.0.1k

openssl version
