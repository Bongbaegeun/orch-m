#!/bin/bash

BACK_FILE="./login_attempt.back"

## Config Restore
CONF_FILE="/etc/pam.d/common-auth"
CHK_CONF1=$(cat $BACK_FILE | awk -F ":" '{print $1}')
CHK_CONF2=$(cat $BACK_FILE | awk -F ":" '{print $2}')
if [ "${CHK_CONF1}" == "N" ]
then
	sed -i "/^auth.*required.*pam_tally2.so.*/d" $CONF_FILE
else
	sed -i "s/^auth.*required.*pam_tally2.so.*/$CHK_CONF2/g" $CONF_FILE
fi

echo "Restore Line --> $(grep "^auth.*required.*pam_tally2.so.*" $CONF_FILE)"

if [ -f $BACK_FILE ]
then
	rm $BACK_FILE
	echo "Remove BackupFile, $BACK_FILE"
fi

