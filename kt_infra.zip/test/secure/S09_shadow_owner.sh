#!/bin/bash

ls -al /etc/shadow >> shadow_owner.back

chmod 400 /etc/shadow
ls -al /etc/shadow 
