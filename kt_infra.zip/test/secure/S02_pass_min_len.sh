#!/bin/bash

BACK_FILE="./pass_min_len.back"

## CONFIG Modify
CONF_FILE="/etc/login.defs"
CHK_CONF=$(cat $CONF_FILE | grep "^PASS_MIN_LEN")
if [ -z "$CHK_CONF" ]
then
	echo "PASS_MIN_LEN 8" >> $CONF_FILE
	echo "N" >> $BACK_FILE
else
	echo "Y:$CHK_CONF" >> $BACK_FILE
	sed -i "s/^PASS_MIN_LEN.*/PASS_MIN_LEN 8/g" $CONF_FILE
fi

echo "Edit config --> $(grep "^PASS_MIN_LEN" $CONF_FILE)"

