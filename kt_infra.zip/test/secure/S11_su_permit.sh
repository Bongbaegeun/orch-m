#!/bin/bash

BACK_FILE="./su_permit.back"

## Check Group
GRP_NAME="wheel"
CHK_GRP=$(cat /etc/group | grep "^$GRP_NAME")
if [ -z "$CHK_GRP" ]
then
	groupadd $GRP_NAME
	echo "Create group $GRP_NAME"
fi

## Account Modify
for ID_INFO in $(cat /etc/shadow)
do
        ID_NAME=$(echo $ID_INFO |  awk -F ":" '{print $1}')
        ID_PASSWD=$(echo $ID_INFO |  awk -F ":" '{print $2}')
        if [ "$ID_PASSWD" != "!" ] && [ "$ID_PASSWD" != "*" ] 
        then
			usermod -a -G $GRP_NAME $ID_NAME
			echo "Add user -> $ID_NAME"
        fi
done

## CONFIG Modify
CONF_FILE="/etc/pam.d/su"
CHK_CONF=$(cat $CONF_FILE | grep "^auth.*required.*pam_wheel.so")
if [ -z "$CHK_CONF" ]
then
	echo "auth required pam_wheel.so group=wheel" >> $CONF_FILE
	echo "N" >> $BACK_FILE
else
	echo "Y:$CHK_CONF" >> $BACK_FILE
	sed -i "s/^auth.*required.*pam_wheel.so.*/auth required pam_wheel.so group=wheel/g" $CONF_FILE
fi

echo "Edit config --> $(grep "^auth.*required.*pam_wheel.so" $CONF_FILE)"

