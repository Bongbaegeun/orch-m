#!/bin/bash

BACK_FILE1="./pass_max_day.back1"
BACK_FILE2="./pass_max_day.back2"

## Config Restore
CONF_FILE="/etc/login.defs"
CHK_CONF1=$(cat $BACK_FILE1 | awk -F ":" '{print $1}')
CHK_CONF2=$(cat $BACK_FILE1 | awk -F ":" '{print $2}')
if [ "${CHK_CONF1}" == "N" ]
then
	sed -i "/^PASS_MAX_DAYS.*/d" $CONF_FILE
else
	sed -i "s/^PASS_MAX_DAYS.*/${CHK_CONF2}/g" $CONF_FILE 
fi

echo "Restore Line --> $(grep "^PASS_MAX_DAYS.*" $CONF_FILE)"

if [ -f $BACK_FILE1 ]
then
	rm $BACK_FILE1
	echo "Remove BackupFile1, $BACK_FILE1"
fi


## Account Restore
for ID_INFO in $(cat $BACK_FILE2)
do
	ID_NAME=$(echo $ID_INFO |  awk -F ":" '{print $1}')
	ID_MAX_DAY=$(echo $ID_INFO |  awk -F ":" '{print $2}')
	passwd -x $ID_MAX_DAY $ID_NAME > /dev/null
	echo "$ID_NAME'Max Day --> $ID_MAX_DAY"
done

if [ -f $BACK_FILE2 ]
then
	rm $BACK_FILE2
	echo "Remove BackupFile2, $BACK_FILE2"
fi


