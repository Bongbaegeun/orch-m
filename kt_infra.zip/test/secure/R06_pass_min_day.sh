#!/bin/bash

BACK_FILE1="./pass_min_day.back1"

## Config Restore
CONF_FILE="/etc/login.defs"
CHK_CONF1=$(cat $BACK_FILE1 | awk -F ":" '{print $1}')
CHK_CONF2=$(cat $BACK_FILE1 | awk -F ":" '{print $2}')
if [ "${CHK_CONF1}" == "N" ]
then
	sed -i "/^PASS_MIN_DAYS.*/d" $CONF_FILE
else
	sed -i "s/^PASS_MIN_DAYS.*/${CHK_CONF2}/g" $CONF_FILE 
fi

echo "Restore Line --> $(grep "^PASS_MIN_DAYS" $CONF_FILE)"

if [ -f $BACK_FILE1 ]
then
	rm $BACK_FILE1
	echo "Remove BackupFile, $BACK_FILE1"
fi

