#!/bin/bash

BACK_FILE1="./pass_max_day.back1"
BACK_FILE2="./pass_max_day.back2"

## CONFIG Modify
CONF_FILE="/etc/login.defs"
CHK_CONF=$(cat $CONF_FILE | grep "^PASS_MAX_DAYS")
if [ -z "$CHK_CONF" ]
then
	echo "PASS_MAX_DAYS 90" >> $CONF_FILE
	echo "N" >> $BACK_FILE1
else
	echo "Y:$CHK_CONF" >> $BACK_FILE1 
	sed -i "s/^PASS_MAX_DAYS.*/PASS_MAX_DAYS 90/g" $CONF_FILE
fi

echo "Edit config --> $(grep "^PASS_MAX_DAYS" $CONF_FILE)"


## Account Modify
for ID_INFO in $(cat /etc/shadow)
do
	ID_NAME=$(echo $ID_INFO |  awk -F ":" '{print $1}')
	ID_PASSWD=$(echo $ID_INFO |  awk -F ":" '{print $2}')
	ID_MAX_DAY=$(echo $ID_INFO |  awk -F ":" '{print $5}')
#	echo "$ID_NAME $ID_PASSWD $ID_MAX_DAY"
	if [ "$ID_PASSWD" != "!" ] && [ "$ID_PASSWD" != "*" ] && [ $ID_MAX_DAY -gt 90 ]
	then
		echo -n "$ID_NAME's Max Day : $ID_MAX_DAY -> "
		passwd -x 90 $ID_NAME > /dev/null
		ID_MAX_DAY_MOD=$(cat /etc/shadow | grep $ID_NAME | awk -F ":" '{print $5}')
		echo "$ID_MAX_DAY_MOD"
		echo "$ID_NAME:$ID_MAX_DAY" >> $BACK_FILE2
	fi
done


