#!/bin/bash

BACK_FILE="./password_complex.back"

## CONFIG Modify
CONF_FILE="/etc/pam.d/common-password"
CHK_CONF=$(cat $CONF_FILE | grep "^password.*requisite.*pam_cracklib.so")
if [ -z "$CHK_CONF" ]
then
	echo "password requisite pam_cracklib.so minlen=8 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1" >> $CONF_FILE
	echo "N" >> $BACK_FILE
else
	echo "Y:$CHK_CONF" >> $BACK_FILE
	sed -i "s/^password.*requisite.*pam_cracklib.so.*/password requisite pam_cracklib.so minlen=8 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1/g" $CONF_FILE
fi

apt-get install -y libpam-cracklib

echo "Edit config --> $(grep "^password.*requisite.*pam_cracklib.so" $CONF_FILE)"
echo "Install Pkg --> $(dpkg --list | grep libpam-cracklib)"
