#!/bin/bash

BACK_FILE1="./alert_msg1.back"
BACK_FILE2="./alert_msg2.back"

## CONFIG Modify
CONF_FILE="/etc/issue.net"
CHK_CONF=$(cat $CONF_FILE | grep "^BANNER")
if [ -z "$CHK_CONF" ]
then
	echo "BANNER=\"WARNING:Authorized use only.\\n\"" >> $CONF_FILE
	echo "N" >> $BACK_FILE1
else
	echo "Y:$CHK_CONF" >> $BACK_FILE1
	sed -i "s/^BANNER.*/BANNER=\"WARNING:Authorized use only.\\n\"/g" $CONF_FILE
fi

echo "Edit config --> $(grep "^BANNER" $CONF_FILE)"

CONF_FILE="/etc/issue"
CHK_CONF=$(cat $CONF_FILE | grep "^BANNER")
if [ -z "$CHK_CONF" ]
then
	echo "BANNER=\"WARNING:Authorized use only.\\n\"" >> $CONF_FILE
	echo "N" >> $BACK_FILE2
else
	echo "Y:$CHK_CONF" >> $BACK_FILE2
	sed -i "s/^BANNER.*/BANNER=\"WARNING:Authorized use only.\\n\"/g" $CONF_FILE
fi

echo "Edit config --> $(grep "^BANNER" $CONF_FILE)"
