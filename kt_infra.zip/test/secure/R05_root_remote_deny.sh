#!/bin/bash

BACK_FILE="./root_remote_deny.back"

## Config Restore
CONF_FILE="/etc/ssh/sshd_config"
CHK_CONF1=$(cat $BACK_FILE | awk -F ":" '{print $1}')
CHK_CONF2=$(cat $BACK_FILE | awk -F ":" '{print $2}')
if [ "${CHK_CONF1}" == "N" ]
then
	sed -i "/^PermitRootLogin.*/d" $CONF_FILE
else
	sed -i "s/^PermitRootLogin.*/$CHK_CONF2/g" $CONF_FILE
fi

service ssh restart

echo "Restore Line --> $(grep "^PermitRootLogin" $CONF_FILE)"
echo "ssh status --> $(service ssh status)"


if [ -f $BACK_FILE ]
then
	rm $BACK_FILE
fi

