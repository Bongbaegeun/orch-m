#!/bin/bash

BACK_FILE="./password_complex.back"

## Config Restore
CONF_FILE="/etc/pam.d/common-password"
CHK_CONF1=$(cat $BACK_FILE | awk -F ":" '{print $1}')
CHK_CONF2=$(cat $BACK_FILE | awk -F ":" '{print $2}')
if [ "${CHK_CONF1}" == "N" ]
then
	sed -i "/^password.*requisite.*pam_cracklib.so.*/d" $CONF_FILE
else
	sed -i "s/^password.*requisite.*pam_cracklib.so.*/$CHK_CONF2/g" $CONF_FILE
fi

echo "Restore Line --> $(grep "^password.*requisite.*pam_cracklib.so.*" $CONF_FILE)"

if [ -f $BACK_FILE ]
then
	rm $BACK_FILE
	echo "Remove BackupFile, $BACK_FILE"
fi

