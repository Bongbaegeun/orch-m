#!/bin/bash

BACK_FILE="./session_timeout.back"

## Config Restore
CONF_FILE="/etc/profile"
CHK_CONF1=$(cat $BACK_FILE | awk -F ":" '{print $1}')
CHK_CONF2=$(cat $BACK_FILE | awk -F ":" '{print $2}')
if [ "${CHK_CONF1}" == "N" ]
then
	sed -i "/^export TMOUT.*/d" $CONF_FILE
else
	sed -i "s/^export TMOUT.*/$CHK_CONF2/g" $CONF_FILE
fi

echo "Restore Line --> $(grep "^export TMOUT" $CONF_FILE)"

if [ -f $BACK_FILE ]
then
	rm $BACK_FILE
	echo "Remove BackupFile, $BACK_FILE"
fi

