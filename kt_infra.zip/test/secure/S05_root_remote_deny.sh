#!/bin/bash

BACK_FILE="./root_remote_deny.back"

## CONFIG Modify
CONF_FILE="/etc/ssh/sshd_config"
CHK_CONF=$(cat $CONF_FILE | grep "^PermitRootLogin")
if [ -z "$CHK_CONF" ]
then
	echo "PermitRootLogin without-password" >> $CONF_FILE
	echo "N" >> $BACK_FILE
else
	echo "Y:$CHK_CONF" >> $BACK_FILE
	sed -i "s/^PermitRootLogin.*/PermitRootLogin without-password/g" $CONF_FILE
fi

service ssh restart

echo "Edit config --> $(grep "^PermitRootLogin" $CONF_FILE)"
echo "ssh status --> $(service ssh status)"

