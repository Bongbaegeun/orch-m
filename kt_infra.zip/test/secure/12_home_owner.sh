#!/bin/bash

chmod 711 obsuser


