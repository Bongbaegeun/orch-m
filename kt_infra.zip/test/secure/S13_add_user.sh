#!/bin/bash

useradd -s /bin/bash onebox
passwd onebox


