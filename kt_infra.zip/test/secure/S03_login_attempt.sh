#!/bin/bash

BACK_FILE="./login_attempt.back"

## CONFIG Modify
CONF_FILE="/etc/pam.d/common-auth"
CHK_CONF=$(cat $CONF_FILE | grep "^auth.*required.*pam_tally2.so")
if [ -z "$CHK_CONF" ]
then
	sed -i "1s/^/auth required pam_tally2.so onerr=fail deny=5 unlock_time=180\n/" $CONF_FILE
	echo "N" >> $BACK_FILE
else
	echo "Y:$CHK_CONF" >> $BACK_FILE
	sed -i "s/^auth.*required.*pam_tally2.so.*/auth required pam_tally2.so onerr=fail deny=5 unlock_time=180/g" $CONF_FILE
fi

echo "Edit config --> $(grep "^auth.*required.*pam_tally2.so" $CONF_FILE)"
