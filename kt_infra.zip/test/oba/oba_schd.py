#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys, importlib, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from random import randint
from time import sleep

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL_N_STOP = "https://%s:5556/v1/scheduler/pause"
URL_N_RUN = "https://%s:5556/v1/scheduler/resume"
URL_N = "https://%s:5556/v1/onebox_info"

URL_W_STOP = "https://%s:5556/v1/wanmonitor/pause"
URL_W_RUN = "https://%s:5556/v1/wanmonitor/resume"
URL_W = "https://%s:5556/v1/wanmonitor"


def callAPI( url, reqBody, _meth=METHOD ):
    try:
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(HEADER)
        if _meth == METHOD :
            strBody = json.dumps( reqBody )
        else:
            strBody = None
        _request = HTTPRequest( url, headers=h, method=_meth.upper(), 
                                client_cert="/var/onebox/key/client_orch.crt",
                                client_key="/var/onebox/key/client_orch.key",
                                validate_cert=False, body=strBody, request_timeout=10 )
        
        response = http_client.fetch( request=_request )
        http_client.close()
        
        _ret = (lambda x: True if x == 200 else False)(response.code)
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except :
            pass 
        
        return _ret, retBody
    except httpclient.HTTPError, e:
        _res = e.response
        _buf = None
        _body = None
        _ret = None
        if _res != None :
            _buf = (None if _res.buffer == None else _res.buffer.read())
            _ret = _buf
        if _res != None :
            _body = _res._body
            _ret = (_ret if _body == None else _body)
        _txt = "%s, body=%s, buffer=%s"%( e, _body, _buf )
        print _txt
        return False, ( json.loads(_ret) if _ret != None else None )
    except Exception, e:
        return False, "Unknown Error: %s"%str(e)
    finally:
        http_client.close()
    

def main(_ip, _func):
    _ff = str(_func).upper()
    if _ff == "STOP_NOTI" :
        _url = URL_N_STOP%_ip
    elif _ff == "RESUME_NOTI" :
        _url = URL_N_RUN%_ip
    elif _ff == "STOP_WANMON" :
        _url = URL_W_STOP%_ip
    elif _ff == "RESUME_WANMON" :
        _url = URL_W_RUN%_ip
    elif _ff == "OBINFO" :
        _url = URL_N%_ip
    elif _ff == "WANMODE" :
        _url = URL_W%_ip
    else:
        print "Unknown FUCN, func=%s"%_ff
        return
    
    print _url
    print callAPI(_url, None, "GET")



if __name__ == '__main__':
    if len(sys.argv) == 3:
        main(sys.argv[1], sys.argv[2])
    else:
        print 'USAGE: CMD IP FUNC[STOP_NOTI/RESUME_NOTI/STOP_WANMON/RESUME_WANMON/OBINFO/WANMODE]'



