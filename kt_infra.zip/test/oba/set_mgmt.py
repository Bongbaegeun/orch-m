#!/usr/bin/python
#-*- coding: utf-8 -*-
import commands
from time import sleep


_IP = "10.0.1.33"
_NIC = "eth6"


def main():
    
    _cmd_get_ip = """ ifconfig %s | grep 'inet addr' | awk '{print $2}' | awk -F ":" '{print $2}'  """%_NIC
    _cmd_set_ip = """ ifconfig %s %s/24 up """%( _NIC, _IP )
    
    _cmd_get_port = """ ovs-vsctl port-to-br %s """%_NIC
    _cmd_del_port = """ ovs-vsctl del-port %s %s """%( "%s", _NIC )
    while True:
        sleep(10)
        
        try:
            _ret, _out = commands.getstatusoutput(_cmd_get_port)
            if str(_out).find("no port") < 0 :
                _ret, _out = commands.getstatusoutput(_cmd_del_port%str(_out).strip())
                print _out
            
            _ret, _out = commands.getstatusoutput(_cmd_get_ip)
            if _out == None or str(_out).strip() == "" :
                _ret, _out = commands.getstatusoutput(_cmd_set_ip)
            else:
                _ip = str(_out).strip()
                if _ip == _IP : 
                    continue
                else:
                    _ret, _out = commands.getstatusoutput(_cmd_set_ip)
        except Exception, e:
            pass







if __name__ == '__main__':
    main()


