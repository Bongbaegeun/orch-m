#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys, importlib, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from random import randint
from time import sleep

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "https://%s:5556/v1/vnf/unset"
URL_PROG = "https://%s:5556/v1/vnf/jobprogress/%s"

def callAPI( url, reqBody, _meth=METHOD ):
    try:
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(HEADER)
        if _meth == METHOD :
            strBody = json.dumps( reqBody )
        else:
            strBody = None
        _request = HTTPRequest( url, headers=h, method=_meth.upper(), 
                                client_cert="/var/onebox/key/client_orch.crt",
                                client_key="/var/onebox/key/client_orch.key",
                                validate_cert=False, body=strBody, request_timeout=10 )
        
        response = http_client.fetch( request=_request )
        http_client.close()
        
        _ret = (lambda x: True if x == 200 else False)(response.code)
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except :
            pass 
        
        return _ret, retBody
    except httpclient.HTTPError, e:
        _res = e.response
        _buf = None
        _body = None
        _ret = None
        if _res != None :
            _buf = (None if _res.buffer == None else _res.buffer.read())
            _ret = _buf
        if _res != None :
            _body = _res._body
            _ret = (_ret if _body == None else _body)
        _txt = "%s, body=%s, buffer=%s"%( e, _body, _buf )
        print _txt
        return False, ( json.loads(_ret) if _ret != None else None )
    except Exception, e:
        return False, "Unknown Error: %s"%str(e)
    finally:
        http_client.close()


def main(_arg):
    _ip = _arg[1]
    _url = URL%_ip
    
    _jid = "t%s"%str(randint(1, 1000000))
    
    _md = _arg[2]
    if not str(_md) in ['KT-VNF', 'AXGATE-UTM', 'ACROMATE-CALLBOX'] :
        print "Unknown VNF Model(%s), Model=[KT-VNF, AXGATE-UTM, ACROMATE-CALLBOX]"%str(_md)
        return 
    
    _body = {'job_id': _jid, 'vnf_model': _md}
    if len(_arg) > 3 : _body['vnf_type'] = _arg[3]
    if len(_arg) > 4 : 
        _wan = str(_arg[4]).split(',')
        _body['vnf_wan_list'] = _wan
    if len(_arg) > 5 : _body['vnf_vendor'] = _arg[5]
    if len(_arg) > 6 : _body['vnf_version'] = _arg[6]
    
    _ret = callAPI(_url, _body)
    print _ret
    print _jid
    _url = URL_PROG%( _ip, _jid )
    while True:
        sleep(2)
        _ret = callAPI(_url, None, "GET")
        print _ret
        print _jid
        if type(_ret[1]) == dict and _ret[1].has_key("status") :
            if _ret[1]['status'] == "DONE" or _ret[1]['status'] == "FAIL" :
                break


if __name__ == '__main__':
    if len(sys.argv) >= 3:
        main(sys.argv)
    else:
        print 'USAGE: CMD IP VNF_MODEL[KT-VNF, AXGATE-UTM, ACROMATE-CALLBOX], VNF_TYPE[UTM, PBX], VNF_WAN_LIST[physnet_wan1,physnet_wan2], VNF_VENDOR[kt, axgate, acromate], VNF_VERSION'



