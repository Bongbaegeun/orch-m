#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys, importlib, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from random import randint
from time import sleep

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "https://%s:5556/v1/vnf/set"
URL_PROG = "https://%s:5556/v1/vnf/jobprogress/%s"

def callAPI( url, reqBody, _meth=METHOD ):
    try:
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(HEADER)
        if _meth == METHOD :
            strBody = json.dumps( reqBody )
        else:
            strBody = None
        _request = HTTPRequest( url, headers=h, method=_meth.upper(), 
                                client_cert="/var/onebox/key/client_orch.crt",
                                client_key="/var/onebox/key/client_orch.key",
                                validate_cert=False, body=strBody, request_timeout=10 )
        
        response = http_client.fetch( request=_request )
        http_client.close()
        
        _ret = (lambda x: True if x == 200 else False)(response.code)
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except :
            pass 
        
        return _ret, retBody
    except httpclient.HTTPError, e:
        _res = e.response
        _buf = None
        _body = None
        _ret = None
        if _res != None :
            _buf = (None if _res.buffer == None else _res.buffer.read())
            _ret = _buf
        if _res != None :
            _body = _res._body
            _ret = (_ret if _body == None else _body)
        _txt = "%s, body=%s, buffer=%s"%( e, _body, _buf )
        print _txt
        return False, ( json.loads(_ret) if _ret != None else None )
    except Exception, e:
        return False, "Unknown Error: %s"%str(e)
    finally:
        http_client.close()


def main(_ip, _md, _tp, _wan, _vd=None, _vs=None):
    _url = URL%_ip
    
    _jid = "t%s"%str(randint(1, 1000000))
    
    if not str(_md) in ['KT-VNF', 'AXGATE-UTM', 'ACROMATE-CALLBOX'] :
        print "Unknown VNF Model(%s), Model=[KT-VNF, AXGATE-UTM, ACROMATE-CALLBOX]"%str(_md)
        return 
    
    if not str(_tp) in ['UTM', 'PBX'] :
        print "Unknown VNF Type(%s), Type=[UTM, PBX]"%str(_tp)
        return 
    
    _wl = str(_wan).split(',')
    if type(_wl) != list or len(_wl) < 1:
        print "Unknown VNF WAN(%s), WAN=[physnet_wan1,physnet_wan2 or physnet_extrawan1]"%str(_wan)
        return
    
    _body = {'job_id': _jid, 'vnf_model': _md, 'vnf_type': _tp, 'vnf_wan_list': _wl}
    if _vd != None : _body['vnf_vendor'] = _vd
    if _vs != None : _body['vnf_version'] = _vs
    
    _ret = callAPI(_url, _body)
    print _ret
    print _jid
    _url = URL_PROG%( _ip, _jid )
    while True:
        sleep(2)
        _ret = callAPI(_url, None, "GET")
        print _ret
        print _jid
        if type(_ret[1]) == dict and _ret[1].has_key("status") :
            if _ret[1]['status'] == "DONE" or _ret[1]['status'] == "FAIL" :
                break


if __name__ == '__main__':
    if len(sys.argv) >= 5:
        if len(sys.argv) == 5 :
            main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
        elif len(sys.argv) < 7 :
            main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
        else:
            main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])
    else:
        print 'USAGE: CMD IP VNF_MODEL[KT-VNF, AXGATE-UTM, ACROMATE-CALLBOX], VNF_TYPE[UTM, PBX], VNF_WAN_LIST[physnet_wan1,physnet_wan2], VNF_VENDOR[kt, axgate, acromate], VNF_VERSION'



