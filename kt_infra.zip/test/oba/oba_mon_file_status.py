#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys, importlib, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from random import randint
from time import sleep

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "https://%s:5556/zba/status/mon_file"

def callAPI( url, reqBody, _meth=METHOD ):
    try:
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(HEADER)
        if _meth == METHOD :
            strBody = json.dumps( reqBody )
        else:
            strBody = None
        _request = HTTPRequest( url, headers=h, method=_meth.upper(), 
                                client_cert="/var/onebox/key/client_orch.crt",
                                client_key="/var/onebox/key/client_orch.key",
                                validate_cert=False, body=strBody, request_timeout=10 )
        
        response = http_client.fetch( request=_request )
        http_client.close()
        
        _ret = (lambda x: True if x == 200 else False)(response.code)
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except :
            pass 
        
        return _ret, retBody
    except httpclient.HTTPError, e:
        _res = e.response
        _buf = None
        _body = None
        _ret = None
        if _res != None :
            _buf = (None if _res.buffer == None else _res.buffer.read())
            _ret = _buf
        if _res != None :
            _body = _res._body
            _ret = (_ret if _body == None else _body)
        _txt = "%s, body=%s, buffer=%s"%( e, _body, _buf )
        print _txt
        return False, ( json.loads(_ret) if _ret != None else None )
    except Exception, e:
        return False, "Unknown Error: %s"%str(e)
    finally:
        http_client.close()


def main(_ip):
    _url = URL%(_ip)
    _body = {"plug_root_dir":"/usr/plugin"}
    _body = {"plug_root_dir":"/usr/plugin", "zba_key_root_dir":"/etc/zabbix/zabbix_agentd.conf.d"}
    _ret = callAPI(_url, _body, "POST")
    print _ret



if __name__ == '__main__':
    if len(sys.argv) == 2:
        main(sys.argv[1])
    else:
        print 'USAGE: CMD IP'



