#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys, importlib, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from random import randint
from time import sleep

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL_RESTORE = "https://%s:5556/v1/restore"
URL_PROG = "https://%s:5556/v1/restore/progress?transaction_id=%s"

def callAPI( url, reqBody, _meth=METHOD ):
    try:
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(HEADER)
        if _meth == METHOD :
            strBody = json.dumps( reqBody )
        else:
            strBody = None
        _request = HTTPRequest( url, headers=h, method=_meth.upper(), 
                                client_cert="/var/onebox/key/client_orch.crt",
                                client_key="/var/onebox/key/client_orch.key",
                                validate_cert=False, body=strBody, request_timeout=10 )
        
        response = http_client.fetch( request=_request )
        http_client.close()
        
        _ret = (lambda x: True if x == 200 else False)(response.code)
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except :
            pass 
        
        return _ret, retBody
    except httpclient.HTTPError, e:
        _res = e.response
        _buf = None
        _body = None
        _ret = None
        if _res != None :
            _buf = (None if _res.buffer == None else _res.buffer.read())
            _ret = _buf
        if _res != None :
            _body = _res._body
            _ret = (_ret if _body == None else _body)
        _txt = "%s, body=%s, buffer=%s"%( e, _body, _buf )
        print _txt
        return False, ( json.loads(_ret) if _ret != None else None )
    except Exception, e:
        return False, "Unknown Error: %s"%str(e)
    finally:
        http_client.close()


def main(_ip):
    _url = URL_RESTORE%_ip
    
    _body = {'backup_server_ip': '211.224.204.156',
             'local_location': '/var/onebox/backup/OneBox/170906-1102/backup-170906-1102.tar.gz',
             'remote_location': '/var/onebox/backup/aa/OneBox/170906-1102/backup-170906-1102.tar.gz',
             'backup_data': {'out_of_band_mgmt': 0, 
                             'lan_office': {'interface': 'eth3,eth5', 'bridge': 'br-lan-office', 
                                            'ipaddress': {'subnet': '255.255.255.0', 
                                                          'address': '192.168.0.1', 
                                                          'gateway': None, 
                                                          'dhcp': False}}, 
                             'lan_server': {'interface': 'eth2,eth4', 'bridge': 'br-lan-server', 
                                            'ipaddress': {'subnet': '255.255.255.0', 
                                                          'address': '192.168.1.1', 
                                                          'gateway': None, 
                                                          'dhcp': False}}, 
                             'extra_mgmt': [{'interface': 'eth0', 'bridge': 'br-internet', 
                                             'ipaddress': {'subnet': '255.255.255.0', 
                                                           'address': '175.213.170.152', 
                                                           'gateway': '175.213.170.1', 
                                                           'dhcp': False}}, 
                                            {'interface': 'eth1', 'bridge': 'br-internet1', 
                                             'ipaddress': {'subnet': '255.255.255.128', 
                                                           'address': '211.224.204.234', 
                                                           'gateway': '211.224.204.129', 
                                                           'dhcp': False}}], 
                             'onebox_id': 'aa', 
                             'mgmt': {'interface': 'eth0', 'bridge': 'br-internet', 
                                      'ipaddress': {'subnet': '255.255.255.0', 
                                                    'address': '175.213.170.152', 
                                                    'gateway': '175.213.170.1', 
                                                    'dhcp': False}}, 
                             'extra_wan': [{'interface': 'eth0', 'bridge': 'br-wan', 
                                            'ipaddress': {'subnet': '255.255.255.0', 
                                                          'address': '175.213.170.152', 
                                                          'gateway': '175.213.170.1', 
                                                          'dhcp': False}}, 
                                           {'interface': 'eth1', 'bridge': 'br-wan1', 
                                            'ipaddress': {'subnet': '255.255.255.128', 
                                                          'address': '211.224.204.234', 
                                                          'gateway': '211.224.204.129', 
                                                          'dhcp': False}}]}
             }
    
    _ret = callAPI(_url, _body)
    print _ret
    
    _tid = str(_ret[1]['transaction_id'])
    _url = URL_PROG%( _ip, _tid )
    while True:
        sleep(2)
        _ret = callAPI(_url, None, "GET")
        print _ret
        if type(_ret[1]) == dict and _ret[1].has_key("status") and _ret[1]['status'] == "DONE":
            break
    


if __name__ == '__main__':
    if len(sys.argv) >= 2:
        main(sys.argv[1])
    else:
        print 'USAGE: CMD IP'



