#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

#HEADER={"content-type":"application/json-rpc"}
HEADER={"content-type":"application/json;charset=UTF-8", "accept":"application/json"}
METHOD="GET"

URL = "https://211.224.204.203:1443/"

def callZB( url ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, request_timeout=10)
#		ca_certs="/root/dev/kt_infra/test/https/server.crt",
#		client_key="/root/dev/kt_infra/test/https/client.key",
#		client_cert="/root/dev/kt_infra/test/https/client.crt", validate_cert=False, request_timeout=30 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	try:
		resp = json.loads(response.body)
	except Exception, e:
		return response.body

	return resp


def resume():
	print( callZB( URL ) )


if __name__ == '__main__':
	resume()
