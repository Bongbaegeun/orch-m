#-*- coding: utf-8 -*-

TTYPE = "AOS"
MODEL_LIST = ['v1.0']

# 2019. 1.18 - lsh
# *INSOFT# show version
# aos v2.1-octeon3(2.6-r32408-OBX 기반으로 개발됨.

def chkParam( params ):
    if params == None or len(params) < 1 :
        return '[ERROR] No Param, Params: 1. ModelType=%s'%str(MODEL_LIST)
    elif len(params) !=1 :
        return '[ERROR] Invalid Para -> %s, Params: ModelType'%str(params)
    
    p1 = str(params[0])
    if not p1 in MODEL_LIST :
        return '[ERROR] Unknown Model Type -> %s, Supported Model=%s'%(str(p1), str(MODEL_LIST))
    
    return None

def makeBody(_type, params, plugDir, HIST="10", TRND="180"):

    ret = chkParam(params)
    if ret != None :
        print ret
        return

    mType = params[0]
    
    REAP_H = '1'
    REAP_M = '1'
    REAP_L = '1'
    DISC_P = '300'
    if _type == 'REAL':
        STAT_H = "30"
        STAT_M = "60"
        STAT_L = "120"
        PERF_H = "60"
        PERF_M = "300"
        PERF_L = "600"
        REAP_H = '3'
        REAP_M = '2'
        REAP_L = '1'
    elif _type == 'TEST':
        STAT_H = "10"
        STAT_M = "30"
        STAT_L = "60"
        PERF_H = "30"
        PERF_M = "60"
        PERF_L = "120"
        DISC_P = "120"
    elif _type == 'SHOW' :
        STAT_H = "2"
        STAT_M = "10"
        STAT_L = "30"
        PERF_H = "10"
        PERF_M = "30"
        PERF_L = "60"
        DISC_P = "60"
    else:
        print "Invalid Template Type -> %s, Supported Type=[REAL, TEST, SHOW]"
        return

    print '=======>> Creating OS:%s:%s:%s Template'%(TTYPE, mType, _type)
    
    body = {
        "tid":'temp-create-1',
        "target_info":{
                'code':'os', 'type':'linux', "name":"OS-AOS", "visible":'운영체제[AOS]', 'model':mType, 
                'vendor_code':'axgate', "description":"AxGate AOS %s"%mType,
                'version':'v1.0','target_for':'OneTouch'
            },
        "group":[
            {'name': 'temperature', "visible":'온도', 'description':'SVR Temperature',
                 "item":[
                    {
                        "name":"SVR Temperature",
                        "visible":'서버 온도', 
                        "type":"SVR",
                        "item_id":"os.temp",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "unit":"°C",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Server Temperature",
                        "plugin":{
                                'name':'Temperature', 'type':'file', 
                                'script': plugDir+'/os/aos/temp-cpu.sh',
                                'param_num':0, 'description':'Svr Temperature'
                                },
                        "alarm_guide":{'name':'SVR Temperature Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 온도 확인 명령 수행: "sensors" 
4. 서버 FAN 상태 확인"""},
                        "threshold":[
                            {
                                "name":"[Warning] SVR Temperature Alarm",
                                "grade":"warning",
                                "description":"SVR Temperature Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"50"},{"op":"<", "value":"70"}]
                            },
                            {
                                "name":"[Minor] SVR Temperature Alarm",
                                "grade":"minor",
                                "description":"SVR Temperature Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Major] SVR Temperature Alarm",
                                "grade":"major",
                                "description":"SVR Temperature Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Critical] SVR Temperature Alarm",
                                "grade":"Critical",
                                "description":"SVR Temperature Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"90"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'cpu', "visible":'CPU', 'description':'AOS CPU Monitor',
            "item":[
                    {
                        "name":"CPU Load",
                        "visible":'CPU 부하', 
                        "type":"Load",
                        "item_id":"os.cpu.load",
                        "graph_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"job",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AOS CPU Load Average(1m)",
                        "plugin":{
                                'name':'AOS CPU Load', 'type':'file', 
                                'script': plugDir+'/os/aos/cpu-load.sh',
                                'description':'AOS CPU Load Average(1m)'
                                },
                        "alarm_guide":{'name':'CPU Load Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""}#,
#                         "threshold":[
#                             {
#                                 "name":"[Warning] CPU Load Alarm",
#                                 "grade":"warning",
#                                 "description":"CPU Load Warning",
#                                 "repeat":REAP_M, 
#                                 "conditions":["and", {"op":">=", "value":"8"},{"op":"<", "value":"8.5"}]
#                             },
#                             {
#                                 "name":"[Minor] CPU Load Alarm",
#                                 "grade":"Minor",
#                                 "description":"CPU Load Minor",
#                                 "repeat":REAP_M, 
#                                 "conditions":["and", {"op":">=", "value":"8.5"},{"op":"<", "value":"9"}]
#                             },
#                             {
#                                 "name":"[Major] CPU Load Alarm",
#                                 "grade":"Major",
#                                 "description":"CPU Load Major",
#                                 "repeat":REAP_M, 
#                                 "conditions":["and", {"op":">=", "value":"9"},{"op":"<", "value":"9.5"}]
#                             },
#                             {
#                                 "name":"[Critical] CPU Load Alarm",
#                                 "grade":"Critical",
#                                 "description":"CPU Load Critical",
#                                 "repeat":REAP_M, 
#                                 "conditions":{"op":">=", "value":"9.5"}
#                             }
#                         ]
                    },
                    {
                        "name":"CPU Util",
                        "visible":'CPU 사용률', 
                        "type":"Util",
                        "item_id":"os.cpu.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AOS CPU Util",
                        "plugin":{
                                'name':'AOS CPU Util', 'type':'file', 
                                'script': plugDir+'/os/aos/cpu-util.sh',
                                'description':'AOS CPU Util'
                                },
                        "alarm_guide":{'name':'CPU Util Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
                        "threshold":[
                            {
                                "name":"[Warning] CPU Util Alarm",
                                "grade":"warning",
                                "description":"CPU Util Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] CPU Util Alarm",
                                "grade":"Minor",
                                "description":"CPU Util Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] CPU Util Alarm",
                                "grade":"Major",
                                "description":"CPU Util Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] CPU Util Alarm",
                                "grade":"Critical",
                                "description":"CPU Util Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'mem', "visible":'메모리', 'description':'AOS Memory Monitor',
            "item":[
                    {
                        "name":"Memory UtilRate",
                        "visible":'메모리 사용률', 
                        "type":"Util",
                        "item_id":"os.mem.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AOS Memory UtilRate",
                        "plugin":{
                                'name':'AOS CPU Load', 'type':'file', 
                                'script': plugDir+'/os/aos/mem-plugin.sh',
                                'description':'AOS Memory UtilRate'
                                },
                        "alarm_guide":{'name':'Memory UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 메모리 사용이 많은 프로세스 확인: "ps -aux --sort -rss | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
                        "threshold":[
                            {
                                "name":"[Warning] Memory UtilRate Alarm",
                                "grade":"warning",
                                "description":"Memory UtilRate Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"85"}]
                            },
                            {
                                "name":"[Minor] Memory UtilRate Alarm",
                                "grade":"Minor",
                                "description":"Memory UtilRate Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"85"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] Memory UtilRate Alarm",
                                "grade":"Major",
                                "description":"Memory UtilRate Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] Memory UtilRate Alarm",
                                "grade":"Critical",
                                "description":"Memory UtilRate Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'process', "visible":'프로세스', 'description':'AOS Process Monitor',
            "discovery":[
                    {
                    "name":"Service Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OS Service Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OS Service Discovery', 'type':'file', 
                            'script': plugDir+'/os/aos/os_discovery.py',
                            'param_num':'1', 'plugin_param':['SVC'], 'description':'OS Service Discovery',
                            'cfg_name':'os_cfg.yaml', 'cfg_path':'./', 'cfg_input':['svr_svc', 'svr_proc', 'svr_net', 'svr_fs'],
                            'discovery_input':'svr_svc'
                            },
                    "item":[
                            {
                                "name":"Service Status",
                                "visible":'프로세스 상태[SERVICE]', 
                                "type":"Service",
                                "item_id":"os.proc.status",
                                "realtime_yn": 'y',
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_M,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"Service Status Monitor",
                                "plugin":{
                                        'name':'AOS Service Status', 'type':'file', 
                                        'script': plugDir+'/os/aos/svc-status.sh',
                                        'param_num':'1', 'description':'AOS Service Status(service)'
                                        },
                                "alarm_guide":{'name':'Service Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 서비스 상태 확인: "service $SVC_NAME status"
4. 서비스 다운 시 서비스 시작: "service $SVC_NAME start" """},
                                "threshold":[
                                    {
                                        "name":"[Critical] Service Down Alarm",
                                        "grade":"Critical",
                                        "description":"Service Down",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {'name': 'net', "visible":'네트워크', 'description':'AOS Network Monitor',
            "discovery":[
                    {
                    "name":"Network Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OS Network Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OS Network Discovery', 'type':'file', 
                            'script': plugDir+'/os/aos/os_discovery.py',
                            'param_num':'1', 'plugin_param':['NET'], 'description':'OS Network Discovery',
                            'cfg_name':'os_cfg.yaml', 'cfg_path':'./', 'cfg_input':['svr_svc', 'svr_proc', 'svr_net', 'svr_fs'],
                            'discovery_input':'svr_net'
                            },
                    "item":[
                            {
                                "name":"Network Status",
                                "visible":'네트워크 상태', 
                                "type":"Status",
                                "item_id":"os.net.if.status",
                                "data_type":"int",
                                "realtime_yn": 'y',
                                "value_type":"status",
                                "period":STAT_M,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"Network Status Monitor",
                                "plugin":{
                                        'name':'AOS Network Status', 'type':'file', 
                                        'script': plugDir+'/os/aos/net-status.sh',
                                        'param_num':'2', 'plugin_param':['status'], 'description':'AOS Network Status(ethtool)'
                                        },
                                "alarm_guide":{'name':'Network Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. NIC 상태 확인: "ethtool $IF_NAME"
4. 연결되어 있지 않을 경우, "ifconfig $IF_NAME up" 수행 또는 LAN 케이블 연결 상태 확인"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] Network I/F Down Alarm",
                                        "grade":"Critical",
                                        "description":"Network I/F Down",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            },
                            {
                                "name":"Network RX_Rate",
                                "visible":'네트워크 RX Rate', 
                                "type":"Rx Rate",
                                "item_id":"os.net.if.rx_rate",
                                "data_type":"int",
                                "period":PERF_M,
                                "history":HIST,
                                "statistic":TRND,
                                "graph_yn": 'y',
                                "realtime_yn": 'y',
                                "statistic_yn": 'y',
                                "unit":"bps",
                                "description":"Network RX Rate Monitor",
                                "plugin":{
                                        'name':'AOS Network Rx Rate', 'type':'file', 
                                        'script': plugDir+'/os/aos/net-status.sh',
                                        'param_num':'2', 'plugin_param':['rx_rate'], 'description':'AOS Network RX_Rate'
                                        },
                                "alarm_guide":{'name':'Network RX Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. RX 대역폭 확인: "ifstat -i $IF_NAME"
4. 장애 시, 개발팀 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Warning] Network RX_Rate Alarm",
                                        "grade":"warning",
                                        "description":"Network Rx_Rate Warning",
                                        "repeat":REAP_M, 
                                        "conditions":["and", {"op":">=", "value":"700000000"},{"op":"<", "value":"800000000"}]
                                    },
                                    {
                                        "name":"[Minor] Network RX_Rate Alarm",
                                        "grade":"Minor",
                                        "description":"Network Rx_Rate Minor",
                                        "repeat":REAP_M, 
                                        "conditions":["and", {"op":">=", "value":"800000000"},{"op":"<", "value":"900000000"}]
                                    },
                                    {
                                        "name":"[Major] Network RX_Rate Alarm",
                                        "grade":"Major",
                                        "description":"Network Rx_Rate Major",
                                        "repeat":REAP_M, 
                                        "conditions":["and", {"op":">=", "value":"900000000"},{"op":"<", "value":"950000000"}]
                                    },
                                    {
                                        "name":"[Critical] Network RX_Rate Alarm",
                                        "grade":"Critical",
                                        "description":"Network Rx_Rate Critical",
                                        "repeat":REAP_M, 
                                        "conditions":{"op":">=", "value":"950000000"}
                                    }
                                ]
                            },
                            {
                                "name":"Network TX_Rate",
                                "visible":'네트워크 TX Rate', 
                                "type":"Tx Rate",
                                "item_id":"os.net.if.tx_rate",
                                "data_type":"int",
                                "period":PERF_M,
                                "history":HIST,
                                "statistic":TRND,
                                "unit":"bps",
                                "graph_yn": 'y',
                                "realtime_yn": 'y',
                                "statistic_yn": 'y',
                                "description":"Network TX Rate Monitor",
                                "plugin":{
                                        'name':'AOS Network Tx Rate', 'type':'file', 
                                        'script': plugDir+'/os/aos/net-status.sh',
                                        'param_num':'2', 'plugin_param':['tx_rate'], 'description':'AOS Network TX_Rate'
                                        },
                                "alarm_guide":{'name':'Network TX Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. TX 대역폭 확인: "ifstat -i $IF_NAME"
4. 장애 시, 개발팀 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Warning] Network TX_Rate Alarm",
                                        "grade":"warning",
                                        "description":"Network TX_Rate Warning",
                                        "repeat":REAP_M, 
                                        "conditions":["and", {"op":">=", "value":"700000000"},{"op":"<", "value":"800000000"}]
                                    },
                                    {
                                        "name":"[Minor] Network TX_Rate Alarm",
                                        "grade":"Minor",
                                        "description":"Network TX_Rate Minor",
                                        "repeat":REAP_M, 
                                        "conditions":["and", {"op":">=", "value":"800000000"},{"op":"<", "value":"900000000"}]
                                    },
                                    {
                                        "name":"[Major] Network TX_Rate Alarm",
                                        "grade":"Major",
                                        "description":"Network TX_Rate Major",
                                        "repeat":REAP_M, 
                                        "conditions":["and", {"op":">=", "value":"900000000"},{"op":"<", "value":"950000000"}]
                                    },
                                    {
                                        "name":"[Critical] Network TX_Rate Alarm",
                                        "grade":"Critical",
                                        "description":"Network TX_Rate Critical",
                                        "repeat":REAP_M, 
                                        "conditions":{"op":">=", "value":"950000000"}
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {'name': 'fs', "visible":'파일시스템', 'description':'AOS FileSystem Monitor',
            "discovery":[
                    {
                    "name":"FileSystem Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OS FileSystem Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OS FileSystem Discovery', 'type':'file', 
                            'script': plugDir+'/os/aos/os_discovery.py',
                            'param_num':'1', 'plugin_param':['FS'], 'description':'OS FileSystem Discovery',
                            'cfg_name':'os_cfg.yaml', 'cfg_path':'./', 'cfg_input':['svr_svc', 'svr_proc', 'svr_net', 'svr_fs'],
                            'discovery_input':'svr_fs'
                            },
                    "item":[
                            {
                                "name":"FileSystem Util Rate",
                                "visible":'파일시스템 사용률', 
                                "type":"Util",
                                "item_id":"os.fs.util",
                                "data_type":"int",
                                "period":PERF_L,
                                "history":HIST,
                                "statistic":TRND,
                                "graph_yn": 'y',
                                "realtime_yn": 'y',
                                "statistic_yn": 'y',
                                'unit':'%',
                                "description":"FileSystem Util Rate Monitor",
                                "plugin":{
                                        'name':'AOS FileSystem Util Rate', 'type':'file', 
                                        'script': plugDir+'/os/aos/fs-status.sh',
                                        'param_num':'2', 'plugin_param':['util'], 'description':'AOS FileSystem Util Rate'
                                        },
                                "alarm_guide":{'name':'FileSystem Util Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 파일시스템 사용률 확인: "du -sh /*"
4. 사용량이 많은 파일 용도를 파악하여 불필요할 경우 삭제"""},
                                "threshold":[
                                    {
                                        "name":"[Warning] FileSystem Util Rate Alarm",
                                        "grade":"warning",
                                        "description":"FileSystem Util Rate Warning",
                                        "repeat":REAP_L, 
                                        "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                                    },
                                    {
                                        "name":"[Minor] FileSystem Util Rate Alarm",
                                        "grade":"Minor",
                                        "description":"FileSystem Util Rate Minor",
                                        "repeat":REAP_L, 
                                        "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                                    },
                                    {
                                        "name":"[Major] FileSystem Util Rate Alarm",
                                        "grade":"Major",
                                        "description":"FileSystem Util Rate Major",
                                        "repeat":REAP_L, 
                                        "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                                    },
                                    {
                                        "name":"[Critical] FileSystem Util Rate Alarm",
                                        "grade":"Critical",
                                        "description":"FileSystem Util Rate Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":">=", "value":"95"}
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    }
    
    return body


