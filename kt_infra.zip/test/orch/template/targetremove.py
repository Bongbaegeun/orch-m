#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from random import randint

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "https://%s:5555/target/remove"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def removeTemp(_ip, targetSeq):
	body = {'tid':'test-%s'%str(randint(1,100000)), 'target_seq':targetSeq}
	
	url = URL%_ip
	print( callZB( url, body ) )




if __name__ == '__main__':
	if len(sys.argv) >= 3:
		removeTemp(str(sys.argv[1]), str(sys.argv[2]))
	else:
		print 'USAGE: CMD IP TEMPLATE_SEQ'


