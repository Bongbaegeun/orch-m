﻿#-*- coding: utf-8 -*-
import threading
# from twx.botapi import TelegramBot, ReplyKeyboardMarkup

import telegram
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters

from collections import namedtuple
from threading import Timer,Thread,Event

import pymysql

import cookielib
import urllib, urllib2, Cookie
import json
import re
import logging
import logging.handlers
import glob



from bs4 import BeautifulSoup
from datetime import tzinfo, timedelta, datetime
import time, os

import config

# 봇 토큰, 봇 API 주소
# ppomppu_bot
# TOKEN = '186642662:AAF4e5pITq9NYz34lHGPQD6i105EA2IpHpo'
logger = logging.getLogger("mylogger")

DBHOST = config.mysql_host
DBPORT = config.mysql_port
DBUSER = config.mysql_user
DBPASSWORD = config.mysql_password
DBNAME = config.mysql_db
TOKEN = config.TELEGRAM_TOKEN 


# ine_bot
# TOKEN_INE = '186868233:AAGKWe0JhuS2CcA6btiDcnY7r3OonJqS88Y'
# BASE_URL = 'https://api.telegram.org/bot' + TOKEN + '/'

REPEAT_SEC = 60

# 봇이 응답할 명령어
CMD_BROADCAST = 'notice11'

CMD_START		= u'시작'
CMD_STOP        = u'종료'
CMD_ADD         = u'추가'
CMD_DEL         = u'삭제'
CMD_LIST1       = u'목'
CMD_LIST        = u'목록'
CMD_HELP1       = u'?'
CMD_HELP        = u'도움'
CMD_BOARD1		= u'게'
CMD_BOARD		= u'게시판'
CMD_ALRAM_TIME	= u'알람시간'

CMD_REPLY       = u'덧글'
CMD_REPLY_DEL   = u'덧글삭제'
CMD_REPLY_LIST  = u'덧글목록'

CMD_RECOM       = u'추천'
CMD_RECOM_DEL   = u'추천삭제'
CMD_RECOM_LIST  = u'추천목록'

CMD_DONATE		= u'기부'

CMD_RANK        = u'순위'

CMD_SOUND       = u'소리'


BASE_BOARD_LIST = [u'뽐뿌', u'휴뽐', u'해뽐', u'휴업', u'자게', u'휴포', u'해포', u'재포',u'캠포']
BASE_BOARD_URL = ['ppomppu', 'ppomppu2', 'ppomppu4', 'pmarket2', 'freeboard', 'phone', 'oversea', 'money','camping']

#MARKET_LIST = [u'뽐장', u'온장']
#MARKET_URL =  ['market', u'onmarket']

MARKET_LIST = [u'뽐장', u'휴장', u'쿠장', u'온장', u'해장']
MARKET_URL =  ['market', 'market_phone', 'cmarket', 'onmarket', 'market_oversea']

#BASE_BOARD_LIST.extend(MARKET_LIST)
#BASE_BOARD_URL.extend(MARKET_URL)


REPLY_COUNT_LIST = [5, 10, 20, 30, 50, 80, 100, 200]
RECOM_COUNT_LIST = [5, 10, 20, 30, 50, 80, 100]

ERROR_MSG1 = u" 예) 덧글 뽐뿌 50 \n"
ERROR_MSG11 = u" 이용가능 게시판을 확인하세요. \n 명령어 : 게시판"
ERROR_MSG2 = u" 예) 추가 뽐뿌 해피머니 \n"
ERROR_MSG3 = u" 예) 덧글삭제 뽐뿌 \n"
ERROR_MSG4 = u" 예) 알람시간 09-22\n"
ERROR_MSG5 = u" 장터는 덧글 알림 불가 "
ERROR_MSG5_1 = u" 장터는 추천 알림 불가 "

ERROR_MSG6 = u" 봇이 중지 되어 있어요. \n 시작 이라고 입력하세요."

ERROR_MSG7 = u" 예) 추천 뽐뿌 10 \n"
ERROR_MSG8 = u" 예) 추천삭제 뽐뿌 \n"

DEFAULT_SOUND = {"sound1" : True, "sound2" : True, "sound3" : True }

# 봇 사용법 & 메시지
USAGE = u"""[사용법] 아래 명령어를 메시지로 보내시면 됩니다.

한글명령
시작 - (봇 시작)
종료 - (봇 종료)

▶ 검색어 알람 ◀
게시판 - (알람 가능 게시판 보기)
추가 [게시판] [검색어] - (알람 검색어 추가)
  예) 추가 뽐뿌 해피머니
  
삭제 [검색어 | 모두] - (알람 검색어 삭제)
  예) 삭제 해피머니
  
목록 - ( 등록한 검색어 보기 )

▶ 덧글 알람 ◀
게시판 - (알람 가능 게시판 보기)
덧글 [게시판] [5, 10, 20, 30, 50, 80, 100, 200] - (덧글 알람)
  예) 덧글 해뽐 30
  
덧글삭제 [게시판] - (덧글알람 게시판 삭제)
  예) 덧글삭제  해뽐

▶ 추천 알람 ◀
덧글알람과 명령 동일
게시판, 추천, 추천목록, 추천삭제
  예) 추천 자게 10
  예) 추천삭제 자게

▶ 기타 ◀
알람시간(00-24) - (알람 지정시간 설정)
순위 - 인기검색어 순위 (1-30위)
소리 - 검색어,덧글,추천별로 소리 On / Off 기능
도움 - ( 보고 계신글 )
기부 - Paypal 또는 Toss로 개발자에게 기부하기 *

"""

MSG_START = u"""뽐뿌 알림봇을 시작합니다.
도움 을 입력하세요.
made by binsoore@naver.com"""

MSG_STOP  = u'뽐뿌 알림봇을 정지합니다.'

MSG_HELP = u"""
도움 이라고 입력하세요.
"""

MAX_STR_COUNT = 5
DONATE_MAX_STR_COUNT = 30

# List 초기화
chat_id_list = []
board_list = []
findstr_list = []

rchat_id_list = []
rboard_list = []
rcount_list = []


rc_chat_id_list = []
rc_board_list = []
rc_count_list = []


#알람시간 목록
LST_ALRAM_ID = []
LST_ALRAM_TIME = []

#검색어 알림 번호
LST_BBSNO_BOARD = []
LST_BBSNO_NO = []
LST_BBSNO_FINDSTR = []

#덧글 알림 번호
LST_REPLY_NO = []

#LST_REPLY_BBSNO_BOARD = []
#LST_REPLY_BBSNO_NO = []
#LST_REPLY_BBSNO_COUNT = []

#덧글 알림 번호
LST_RECOM_NO = []
#LST_RECOM_BBSNO_BOARD = []
#LST_RECOM_BBSNO_NO = []
#LST_RECOM_BBSNO_COUNT = []


# 채팅 활성화
LST_Enable_ID =[]
LST_Enable =[]
LST_Donated =[]

# 비교 검색한 게시판 번호
LST_COMPLETE_BBSNO = []

# 사용한 명령 목록.
LST_UPDATE_ID =[]

# 메시지 큐
LST_MESSAGE = []

# BlockID 는 실행시 저장해서, 재시작될때 풀림.
LST_BLOCK_ID = []


DICT_SOUND = {}


LOCK = threading.Lock()


# 전역, 뽐뿌게시판 미리 로그인
#login_data = urllib.urlencode({'user_id' : config.user_id, 'password' : config.password})
#request = urllib2.Request(config.login_page, login_data)
#response = urllib2.urlopen(request)
#cookie = response.headers.get('Set-Cookie')		


# 타이머 (Thread)
class GetCommand_Timer():

   def __init__(self,t,hFunction):
      self.t=t
      self.hFunction = hFunction
      self.thread = Timer(self.t,self.handle_function)

   def handle_function(self):
      self.hFunction()
      self.thread = Timer(self.t,self.handle_function)
      self.thread.start()

   def start(self):
      self.thread.start()

   def cancel(self):
      self.thread.cancel()
      
# 60 초에 한번 Donated 파일이 있으면 Init 호출
def MonitorDonated():
    for filename in glob.glob('/var/www/paypal/donated_*') :
        chat_id = filename.replace('/var/www/paypal/donated_', '') 
        logger.info ( "donated chatid : %s " % chat_id )
        send_msg(chat_id, u"** 기부회원으로 등록 되었습니다  ** .\n감사 합니다.")
        os.remove(filename)
        init()
        
    for filename in glob.glob('/var/www/paypal/toss_*') :
        chat_id = filename.replace('/var/www/paypal/toss_', '') 
        logger.info ( "donated chatid : %s " % chat_id )
        send_msg(chat_id, u"** 기부회원으로 등록 되었습니다  ** .\n감사 합니다.")
        os.remove(filename)
        init()



def GetMessage():
    # 큐에 있는것 모두 꺼내서 쓰레드로 전송 
    i = 0
    LOCK.acquire()
    while len(LST_MESSAGE) > 0 :
        i = i + 1
        if i > 10 : 
            # print "Message Queue : %s" % len(LST_MESSAGE)
            break
        # print i
        Msg = LST_MESSAGE.pop(0)
        msgThr = threading.Thread( target=send_msg_alram, 
                                            args=(Msg[0], Msg[1], Msg[2]))
        msgThr.start()	
    LOCK.release()

        
def cmd_help(chat_id):
    u"""cmd_help: 봇 사용법 메시지 발송
    chat_id: (integer) 채팅 ID
    """
    str = ""
    if donate_member(chat_id) :
        str = u"\n ** 당신은 [기부회원] 입니다. **"
        
    send_msg(chat_id, USAGE + str)

def set_AlramTime(chat_id, sTime):
    u"""set_enabled: 봇 활성화/비활성화 상태 변경
    chat_id:    (integer) 봇을 활성화/비활성화할 채팅 ID
    enabled:    (boolean) 지정할 활성화/비활성화 상태
    """
    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)

    curs.execute ( u"""INSERT INTO alram_time (chat_id, sTime)
        VALUES (%s, %s) 
        ON DUPLICATE KEY 
        UPDATE chat_id = %s, stime = %s """, (chat_id, sTime, chat_id, sTime) )
        
    db.commit()

    # 알람 List 추가
    try : 
        idx = LST_ALRAM_ID.index (chat_id)
        LST_ALRAM_TIME[idx] = sTime
    except :
        LST_ALRAM_ID.append(chat_id)
        LST_ALRAM_TIME.append (sTime)
    
def cmd_alram_time(chat_id, text):
    u"""cmd_alrma_time: 지정시간 알람
    text: (integer) 설정시간
    """
    
    str = text
    str = str.replace(CMD_ALRAM_TIME,'')
    str = str.replace(u'시간','')
    str = str.replace(' ', '')

    if str == "" :
        try :
            idx = LST_ALRAM_ID.index(chat_id)
        except :
            idx = -1
            
        if idx > -1 :
            send_msg(chat_id, u"현재 알람 [%s]" % LST_ALRAM_TIME[idx])
        else :
            send_msg(chat_id, ERROR_MSG4)
            
        return
        
    # 하이픈이 포함 되었나?
    if str.find ("-") == -1 :
        send_msg(chat_id, ERROR_MSG4)
        return
        
    str_list = str.split("-")
    if not isNumber(str_list[0]) or not isNumber(str_list[1]):
        send_msg(chat_id, ERROR_MSG4)
        return
        
    if int(str_list[0]) > int(str_list[1]) :
        send_msg(chat_id, ERROR_MSG4)
        return
    
    try :
        if int(str_list[0]) > 24 or int(str_list[1]) > 24:
            send_msg(chat_id, ERROR_MSG4)
            return
        else :
            set_AlramTime (chat_id, str)
            try : 
                idx = LST_ALRAM_ID.index(chat_id)
                LST_ALRAM_ID[idx] = chat_id
                LST_ALRAM_TIME[idx] = str
            except :
                LST_ALRAM_ID.append (chat_id)
                LST_ALRAM_TIME.append (str)	
                
            send_msg(chat_id, u"알람시간 [%s] 설정 완료" % str)
    except :
        send_msg(chat_id, ERROR_MSG4)
        return


def get_enabled(chat_id):
    u"""get_enabled: 봇 활성화/비활성화 상태 반환
    return: (boolean)
    """
    try :
        idx = LST_Enable_ID.index(chat_id)
        if LST_Enable[idx] == 1 :
            return True
    except :
        return False
    
    return False

def donate_member(chat_id):
    u"""기부한 회원이냐 ? 
    return: (boolean)
    """
    try :
        idx = LST_Enable_ID.index(chat_id)
        if LST_Donated[idx] == 1 :
            return True
    except :
        return False
    
    return False
    
    
def init ():
    try :
        db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
        curs = db.cursor(pymysql.cursors.DictCursor)

        NowDate = datetime.now()
        
        # List 초기화
        chat_id_list[:] = []
        board_list[:] = []
        findstr_list[:] = []

        rchat_id_list[:] = []
        rboard_list[:] = []
        rcount_list[:] = []
        
        rc_chat_id_list[:] = []
        rc_board_list[:] = []
        rc_count_list[:] = []

        # EnableStatus
        LST_Enable_ID [:] =[]
        LST_Enable [:] =[]
        LST_Donated [:] =[]

        # 검색한 게시판 번호
        LST_COMPLETE_BBSNO[:] = []

        
        #알람시간 목록
        LST_ALRAM_ID[:] = []
        LST_ALRAM_TIME[:] = []

        #검색어 알림 번호
        LST_BBSNO_BOARD[:] = []
        LST_BBSNO_NO[:] = []
        LST_BBSNO_FINDSTR[:] = []

        #덧글 알림 번호
        LST_REPLY_NO[:] = []
        
        #추천수
        LST_RECOM_NO[:] = []
        
        # 2019. 1.24  다음 기부자 발생시 아래 쿼리로 변경할것.
        # paypal 테이플 없는줄 알고 수작업 했는데 있네. join 해서 처리.
        #  SELECT A.enabled, A.chat_id, B.amount as donated 
        #FROM EnableStatus A
        #LEFT OUTER JOIN paypal B ON A.chat_id = B.chat_id
        #ORDER BY B.amount DESC,  A.date
        
        # 기부자 우선, 그후 가입일순
        rowcount = curs.execute ( """SELECT * FROM EnableStatus order by donated DESC, date""" )
        if rowcount > 0 : 
            for r in curs.fetchall() :
                LST_Enable_ID.append( r['chat_id'] )
                LST_Enable.append( r['enabled'] )
                if r['donated'] > 0 :
                    LST_Donated.append( 1 )
                else :
                    LST_Donated.append( 0 )
        
        # 검색어 알람
        rowcount = curs.execute ( """SELECT * FROM save_str""")
        for r in curs.fetchall() :
            chat_id_list.append(r['chat_id'])
            board_list.append(r['board'])
            # 소문자 저장.
            sstr = r['findstr']
            findstr_list.append(sstr.lower())

        # 덧글 카운터
        rowcount = curs.execute ( """SELECT * FROM save_reply""")
        for r in curs.fetchall() :
            rchat_id_list.append(r['chat_id'])
            rboard_list.append(r['board'])
            rcount_list.append(r['count'])


        # 추천 카운터
        rowcount = curs.execute ( """SELECT * FROM save_recom""")
        for r in curs.fetchall() :
            rc_chat_id_list.append(r['chat_id'])
            rc_board_list.append(r['board'])
            rc_count_list.append(r['count'])

        # 검색어 알림.
        rowcount = curs.execute ( """SELECT * FROM end_str""")
        for r in curs.fetchall() :
            LST_BBSNO_NO.append( r['no'] )
            LST_BBSNO_BOARD.append( r['board'] )
            sstr = r['findstr']
            LST_BBSNO_FINDSTR.append( sstr.lower() )


        #카운터 알림
        sstr = ''
        sstr = sstr.encode('utf-8')
        rowcount = curs.execute ( """SELECT * FROM end_reply""")
        for r in curs.fetchall() :
            sstr = r['no'] + ',' + r['board'] + ',%d' % r['count']
            LST_REPLY_NO.append ( sstr )

        sorted(LST_REPLY_NO)
        
        #추천 알림
        rowcount = curs.execute ( """SELECT * FROM end_recom""")
        for r in curs.fetchall() :
            sstr = r['no'] + ',' + r['board'] + ',%d' % r['count']
            LST_RECOM_NO.append ( sstr )
        sorted(LST_RECOM_NO)

            
        # 알람시간 목록
        rowcount = curs.execute ( """SELECT * FROM alram_time""")
        for r in curs.fetchall() :
            LST_ALRAM_ID.append (r['chat_id'])
            LST_ALRAM_TIME.append (r['stime'])
            
        # 소리 목록
        rowcount = curs.execute ( """SELECT * FROM sound""")
        for r in curs.fetchall() :
            DICT_SOUND[r['chat_id']] = eval(r['value'])
            # logger.info (DICT_SOUND[r['chat_id']])

            
    except Exception, e :
        logger.error ( "def init : %s " % str(e) )
        return 
        
        
    logger.info( '==== INIT END  ' )
    
def delete_db() :
    NowDate = datetime.now()
    
    # 매 정시 로그 삭제. 1분에 호출됨..
    if '00' == NowDate.strftime('%M') :
        db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
        curs = db.cursor(pymysql.cursors.DictCursor)

        # 3일 지난 data 삭제
        TwoDay = NowDate + timedelta(days=-2)
        FiveDay = NowDate + timedelta(days=-5)

        # 2020. 7. 5 
        # 해뽐 2일치만 하니 자정넘어 예전 Data Push 된다.
        # 해뽐은 5일치 보관하게 ...
        curs.execute ( """DELETE FROM end_str WHERE date < %s """ % FiveDay.strftime('%Y%m%d'))
        db.commit()

        curs.execute ( """DELETE FROM end_reply WHERE date < %s """ % FiveDay.strftime('%Y%m%d'))
        db.commit()
        
        curs.execute ( """DELETE FROM end_recom WHERE date < %s """ % FiveDay.strftime('%Y%m%d'))
        db.commit()


        # 해뽐 아닌건 2일치만 보관
        curs.execute ( u"""DELETE FROM end_str WHERE date < %s and board <> '해뽐' """ % TwoDay.strftime('%Y%m%d'))
        db.commit()
        
        curs.execute ( """DELETE FROM end_reply WHERE date < %s and board <> '해뽐' """ % TwoDay.strftime('%Y%m%d'))
        db.commit()
        
        curs.execute ( """DELETE FROM end_recom WHERE date < %s and board <> '해뽐' """ % TwoDay.strftime('%Y%m%d'))
        db.commit()

        init()

def cmd_broadcast ( text ) :
    # 공지사항 
    str = u"[뽐뿌알람봇 공지] %s" % (text)
    str = str.replace(CMD_BROADCAST,'')

    logger.info ( u"전체공지 : " + str )

    LOCK.acquire()
    for r in LST_Enable_ID :
        LST_MESSAGE.append ( [r, str, 0] ) 
    LOCK.release()
    
def call_url( ):
    # send_msg(27693025, " get ")
    # DB 미리 읽기
    # 검색어 목록
    # logger.info("start")
    # url call !
    
    delete_db()

    NowDate = datetime.now()
    #print NowDate
    logger.info( NowDate )

    #TwoDay = NowDate + timedelta(days=-2) 
    #print TwoDay.strftime('%Y-%m-%d')
    
#	curs.execute ( """DELETE FROM end_str WHERE date < %s """ % TwoDay.strftime('%Y-%m-%d'))
    PAGE_LIST = ['&page=3', '&page=2', '' ]
    
    for i, b in enumerate(BASE_BOARD_URL) :
        for j, page in enumerate(PAGE_LIST) :
            # 자유게시판 아니면 page=3 검색 하지마.
            if b != 'freeboard' and j == 0 :
                continue
                
            addr = "http://m.ppomppu.co.kr/new/bbs_list.php?id=" + b + page
            if b in ['ppomppu', 'ppomppu4'] :
                pasing_url(addr, BASE_BOARD_LIST[i], "p1")
            elif b in MARKET_URL :
                pasing_url(addr, BASE_BOARD_LIST[i], "market")
            else :
                pasing_url(addr, BASE_BOARD_LIST[i], "p2")



def cmd_add(chat_id, text):
    u"""cmd_add: 검색어 등록
    chat_id: (integer) 채팅 ID
    text:    (string)  사용자가 보낸 메시지 내용
    """

    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)


#	db.query("set character_set_connection=utf8;")
#	db.query("set character_set_server=utf8;")
#	db.query("set character_set_client=utf8;")
#	db.query("set character_set_results=utf8;")
#	db.query("set character_set_database=utf8;")
     
#	query = "SQL Sentence"
#	curs.execute("set names utf8")	
    
    str = text
    str = str.replace('/add','')
    str = str.replace(u'추가','')
    str = str.replace('[','')
    str = str.replace(']','')
    str = str.replace('?','')
    str = str.replace(',','')

    
    if str == "" :
        send_msg(chat_id, ERROR_MSG2)
        return

    # 공백으로 분리
    slist = str.split()

    # 명령어 검증	
    if len(slist) == 1 :
        send_msg(chat_id, ERROR_MSG2)
        return

    if not slist[0] in BASE_BOARD_LIST :
        send_msg(chat_id, ERROR_MSG2)
        return

    if len(slist[1]) <= 1 :
        send_msg(chat_id, u" 검색어는 2자 이상" )
        return			
        
    if len(slist[1]) >= 20 :
        send_msg(chat_id, u" 검색어는 20자 이하" )
        return

    rowcount = curs.execute ( """SELECT * FROM save_str	WHERE chat_id= %s""" % chat_id )
    
    for r in curs.fetchall():
        if r["board"] == slist[0] and r["findstr"] == slist[1] : 
            #if r.findstr.find(str.strip()) > -1 : 
            send_msg(chat_id, u" 중복입니다.")
            return	

            
    # 기부자 인가?
    donated = donate_member(chat_id) 
    
    if ( MAX_STR_COUNT > rowcount ) or ( donated and DONATE_MAX_STR_COUNT > rowcount ) :
        curs.execute ( """INSERT INTO save_str (chat_id, board, findstr) 
            VALUES (%s, %s, %s)""", (chat_id, slist[0], slist[1]))
        db.commit()
        send_msg(chat_id, u"%s 게시판 [%s] 알람 등록" % (slist[0], slist[1]))

        # List 추가
        chat_id_list.append(chat_id)
        board_list.append(slist[0])
        findstr_list.append(slist[1].lower())
        
    else :
        if donated :
            send_msg(chat_id, u" 최대 저장 %d 개를 초과 했습니다." % DONATE_MAX_STR_COUNT)
        else :
            send_msg(chat_id, u" 최대 저장 %d 개를 초과 했습니다. 기부회원은 %d개 등록가능" % ( MAX_STR_COUNT, DONATE_MAX_STR_COUNT))
        return

    db.close()
    
    
    
def cmd_rank(chat_id):
    u"""cmd_rank: 인기순위 30위
    chat_id: (integer) 채팅 ID
    """
    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)


    # 랭킹 뽑기
    rowcount = curs.execute ( """select findstr, count(*) as cnt from save_str
                                group by findstr
                                order by cnt DESC limit 30""")
                                
    i = 1
    rankstr = u"▶ 인기 검색어 ◀ \n"
    for r in curs.fetchall() :
        rankstr = rankstr + u"No. %d  :  %s,     %d 건 \n" % ( i, r["findstr"], r["cnt"] )
        i = i + 1

    send_msg(chat_id, rankstr)	
    db.close()

    
def cmd_list(chat_id):
    u"""cmd_list: 저장된 검색어 목록 보기
    chat_id: (integer) 채팅 ID
    """

    check_ok = False
    count = 0
    str = u'▶ 검색어 알람 ◀\n'
    for i, r in enumerate(chat_id_list) :
        if r == chat_id :
            check_ok = True
            str = str + u"  [%s] 게시판, [%s] \n" % (board_list[i], findstr_list[i])
            count = count + 1


    if not check_ok :
        str = str + u'  등록된 검색어가 없습니다\n'
    else :
        # 총 카운터 보여줌.
        str = str + u"    총 %s 건\n" % count

    str = str + '\n'
    check_ok = False
    str = str + u'▶ 덧글수 알람 ◀\n'
    for i, r in enumerate(rchat_id_list) :
        if rchat_id_list[i] == chat_id : 
            check_ok = True
            str = str + u"  (%s) 게시판 덧글수 [%d] \n" % (rboard_list[i], rcount_list[i])
    if not check_ok :
        str = str + u"  등록된 덧글수 알람이 없습니다.\n"

        
    str = str + '\n'
    check_ok = False
    str = str + u'▶ 추천수 알람 ◀\n'
    for i, r in enumerate(rc_chat_id_list) :
        if rc_chat_id_list[i] == chat_id : 
            check_ok = True
            str = str + u"*%s* 게시판, 추천수 [%d]\n" % (rc_board_list[i], rc_count_list[i])

    if not check_ok :
        str = str + u"  등록된 추천수 알람이 없습니다.\n"
    
    logger.info ( str )
    send_msg(chat_id, str)
    

def cmd_del(chat_id, text):
    u"""cmd_del: 검색어 삭제
    text: (string) 삭제 검색어
    """
    global chat_id_list, board_list, findstr_list
                
    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)

    str = text.lower()
    str = str.replace('/del','')
    str = str.replace(u'삭제','')
    str = str.replace(' ','')

    if str == u"모두" :
        curs.execute ( """DELETE FROM save_str WHERE chat_id= %s""" % chat_id)
        msg = u" 게시판 알람 모두 삭제 "
        send_msg(chat_id, msg)
    else :
        rowcount = curs.execute ( """SELECT board FROM save_str WHERE chat_id= %s AND findstr=%s""", (chat_id, str))
        if rowcount > 0 : 
            for r in curs.fetchall() :
                curs.execute ( """DELETE FROM save_str WHERE chat_id= %s AND findstr = %s""", (chat_id, str))
                msg = u" [%s] 게시판, [%s] 알람 삭제 " % (r['board'], str)
                send_msg(chat_id, msg)

        else :
            msg = u" [%s] 검색어 없음\n 예) 삭제 해피머니" % (str)
            send_msg(chat_id, msg)
            return
            
    db.commit()
    db.close()


    
    # List_obj 에서도 삭제
    # 삭제는 역순으로 ~
    # logger.info ( "chat_id : %s,  str : %s" % (chat_id, str) ) 
    for i in reversed(range(len(chat_id_list))) :
        if chat_id_list[i] == chat_id : 
            if str == u"모두" : 
                del chat_id_list[i]
                del board_list[i]
                del findstr_list[i]
                continue
                
            if findstr_list[i] == str :
                del chat_id_list[i]
                del board_list[i]
                del findstr_list[i]
                break
                

def isNumber(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def cmd_reply(chat_id, text):
    u"""cmd_reply: 덧글 갯수 저장
    text : (string) 덧글 게시판, 카운터
    """
    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)

    str = text
    str = str.replace(CMD_REPLY,'')
    str = str.replace(u'댓글','')
    str = str.replace(u'리플','')

    #send_msg(chat_id, str)

    if str == "" :
        send_msg(chat_id, ERROR_MSG1)
        return

    # 공백으로 분리
    slist = str.split()

    if slist[0] == u"삭제" :
        cmd_reply_del (chat_id, str.replace(u'삭제',''))
        return
        
    if slist[0] == u"목록" :
        cmd_reply_list (chat_id)
        return
    
    
    # 명령어 검증	
    if len(slist) == 1 :
        send_msg(chat_id, ERROR_MSG1)
        return

    if not isNumber(slist[1]) :
        send_msg(chat_id, ERROR_MSG1)
        return
            
    # 장터는 덧글 알림 금지	
    if slist[0] in MARKET_LIST :
        send_msg(chat_id, ERROR_MSG5)
        return

    if not slist[0] in BASE_BOARD_LIST :
        send_msg(chat_id, ERROR_MSG11)
        return
    
        
    if not int(slist[1]) in REPLY_COUNT_LIST :
        send_msg(chat_id, ERROR_MSG1)
        return
        
    cnt = int (slist[1])
        
    curs.execute ( u"""INSERT INTO  save_reply (chat_id, board, count )
        VALUES (%s, %s, %s) 
        ON DUPLICATE KEY 
        UPDATE chat_id = %s, board = %s, count = %s""", (chat_id, slist[0], cnt, chat_id, slist[0], cnt) )
        
    db.commit()
        
    msg = u"%s 게시판 덧글 %d개 이상 알람 등록" % (slist[0], int(slist[1]))
    send_msg(chat_id, msg)
        
    # 덧글List 추가
    updated = False
    for idx, r in enumerate(rchat_id_list) :
        if r == chat_id and rboard_list[idx] == slist[0] :
            rcount_list[idx] = int(slist[1])
            updated = True
            break

    # for 검사후 못 찾았으면 추가.
    if not updated :
        rchat_id_list.append(chat_id)
        rboard_list.append(slist[0])
        rcount_list.append(int(slist[1]))


def cmd_recom(chat_id, text):
    u"""cmd_recom: 추천 갯수 저장
    text : (string) 추천 게시판, 카운터
    """
    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)

    str = text
    str = str.replace(CMD_RECOM,'')

    #send_msg(chat_id, str)

    if str == "" :
        send_msg(chat_id, ERROR_MSG7)
        return

    # 공백으로 분리
    slist = str.split()

    if slist[0] == u"삭제" :
        cmd_recom_del (chat_id, str.replace(u'삭제',''))
        return
        
    if slist[0] == u"목록" :
        cmd_list (chat_id)
        return
    
    
    # 명령어 검증	
    if len(slist) == 1 :
        send_msg(chat_id, ERROR_MSG7)
        return

    if not isNumber(slist[1]) :
        send_msg(chat_id, ERROR_MSG7)
        return
            
    if not slist[0] in BASE_BOARD_LIST :
        send_msg(chat_id, ERROR_MSG11)
        return
    
    # 장터는 추천 알림 금지	
    if slist[0] in MARKET_LIST :
        send_msg(chat_id, ERROR_MSG5_1)
        return
        
    if not int(slist[1]) in RECOM_COUNT_LIST :
        send_msg(chat_id, ERROR_MSG7)
        return
        
    cnt = int (slist[1])
        
    curs.execute ( u"""INSERT INTO  save_recom (chat_id, board, count )
        VALUES (%s, %s, %s) 
        ON DUPLICATE KEY 
        UPDATE chat_id = %s, board = %s, count = %s""", (chat_id, slist[0], cnt, chat_id, slist[0], cnt) )
        
    db.commit()
        
    msg = u"%s 게시판 추천 %d개 이상 알람 등록" % (slist[0], int(slist[1]))
    send_msg(chat_id, msg)
        
    # 추천List 추가
    updated = False
    for idx, r in enumerate(rc_chat_id_list) :
        if r == chat_id and rc_board_list[idx] == slist[0] :
            rc_count_list[idx] = int(slist[1])
            updated = True
            break

    # for 검사후 못 찾았으면 추가.
    if not updated :
        rc_chat_id_list.append(chat_id)
        rc_board_list.append(slist[0])
        rc_count_list.append(int(slist[1]))


#추천 삭제		
def cmd_recom_del(chat_id, text):
    u"""cmd_recom_del: 추천 갯수 삭제
    chat_id: (integer) 채팅 ID
    text: (string) 검색어
    """
    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)

    str = text
    str = str.replace(CMD_RECOM_DEL,'')
    str = str.replace(' ','')

    if str == "" :
        send_msg(chat_id, ERROR_MSG8)
        return

    rowcount = curs.execute ( """SELECT * FROM save_recom WHERE chat_id = %s AND board = %s""", (chat_id, str))
    if rowcount > 0 : 
        # 삭제
        for r in curs.fetchall():
            curs.execute ( """DELETE FROM save_recom WHERE chat_id= %s AND board = %s""", (chat_id, str))
            msg = u" %s 게시판, 추천 %d 이상 삭제 " % (r["board"], r["count"])
            send_msg(chat_id, msg)
            
        db.commit()
        
        # 덧글 List_obj 에서도 삭제
        for i, r in enumerate(rc_chat_id_list) :
            if rc_chat_id_list[i] == chat_id : 
                if rc_board_list[i] == str :
                    del rc_chat_id_list[i]
                    del rc_board_list[i]
                    del rc_count_list[i]
                    break;
                
        
#추천 목록
def cmd_recom_list(chat_id):
    u"""cmd_recom_list: 추천갯수 목록
    chat_id: (integer) 채팅 ID
    text : (string) 전달 문자
    """
    
    check_ok = False
    str = ''
    for i, r in enumerate(rc_chat_id_list) :
        if rc_chat_id_list[i] == chat_id : 
            str = str + u"%s 게시판 추천 %d개 이상 \n" % (rc_board_list[i], rc_count_list[i])
            check_ok = True
            
    if check_ok :
        send_msg(chat_id, str)
    else :
        send_msg(chat_id, u" 등록된 알람이 없습니다.")
        return
                
        
        
#기부
def cmd_donate(chat_id):
    u"""cmd_donate: 기부 링크 
    chat_id: (integer) 채팅 ID
    """
    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)

    # 기부인원수, 기부금액
    done_count = 0
    done_paypal = 0
    done_toss = 0    
    rowcount = curs.execute ( """select count(chat_id) cnt , sum(amount) amount, product from paypal group by product""")
    if rowcount > 0 : 
        for r in curs.fetchall() :
            done_count += r['cnt']
            if r['product'] == 'ppomppubot' :
                done_paypal += r['amount']
            else :
                done_toss += r['amount']
    
    send_msg(chat_id, u"""Paypal 또는 Toss 앱으로 개발자에게 기부.
아래 링크를 클릭 해주세요.

*Donated 특전* 
1. 최 우선 알람. 
2. 검색어 %d개 등록

* 기부 참여자 *
참여인원 : %s 명
Paypal : $ %s
Toss : %s 원

""" % ( DONATE_MAX_STR_COUNT, done_count, format(done_paypal, ','), format(done_toss, ',')))

    donate_url = "https://donate.ine.kr/ppomppubot.php?id=" + chat_id
    send_msg(chat_id, donate_url)
   
    return
                
                
# 덧글삭제		
def cmd_reply_del(chat_id, text):
    u"""cmd_reply_del: 댓굴 갯수 삭제
    chat_id: (integer) 채팅 ID
    text: (string) 검색어
    """
    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)

    str = text
    str = str.replace(CMD_REPLY_DEL,'')
    str = str.replace(u'리플삭제','')
    str = str.replace(u'댓글삭제','')
    str = str.replace(' ','')

    if str == "" :
        send_msg(chat_id, ERROR_MSG3)
        return

    rowcount = curs.execute ( """SELECT * FROM save_reply WHERE chat_id = %s AND board = %s""", (chat_id, str))
    if rowcount > 0 : 
        # 삭제
        for r in curs.fetchall():
            curs.execute ( """DELETE FROM save_reply WHERE chat_id= %s AND board = %s""", (chat_id, str))
            msg = u" %s 게시판, 덧글 %d 이상 삭제 " % (r["board"], r["count"])
            send_msg(chat_id, msg)
            
        db.commit()
        
        # 덧글 List_obj 에서도 삭제
        for i, r in enumerate(rchat_id_list) :
            if rchat_id_list[i] == chat_id : 
                if rboard_list[i] == str :
                    del rchat_id_list[i]
                    del rboard_list[i]
                    del rcount_list[i]
                    break;
    else :
        send_msg(chat_id, ERROR_MSG3)
        return    
        

def cmd_reply_list(chat_id):
    u"""cmd_reply_list: 덧글 갯수 저장
    chat_id: (integer) 채팅 ID
    text : (string) 전달 문자
    """
    
    check_ok = False
    str = ''
    for i, r in enumerate(rchat_id_list) :
        if rchat_id_list[i] == chat_id : 
            str = str + u"%s 게시판 덧글 %d개 이상 \n" % (rboard_list[i], rcount_list[i])
            check_ok = True
            
    if check_ok :
        send_msg(chat_id, str)
    else :
        send_msg(chat_id, u" 등록된 알람이 없습니다.")
        return
        
    
# 시작		
def cmd_start(chat_id):
    u"""cmd_start: 봇을 활성화하고, 활성화 메시지 발송
    chat_id: (integer) 채팅 ID
    """
    set_enabled(chat_id, True)
    send_msg(chat_id, MSG_START)
    #send_msg(chat_id, MSG_START, keyboard=CUSTOM_KEYBOARD)

    
def cmd_stop(chat_id):
    u"""cmd_stop: 봇을 비활성화하고, 비활성화 메시지 발송
    chat_id: (integer) 채팅 ID
    """
    send_msg(chat_id, MSG_STOP)
    set_enabled(chat_id, False)

    
def set_enabled(chat_id, enabled):
    u"""set_enabled: 봇 활성화/비활성화 상태 변경
    chat_id:    (integer) 봇을 활성화/비활성화할 채팅 ID
    enabled:    (boolean) 지정할 활성화/비활성화 상태
    """
    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)
    
    #Query = "INSERT INTO  EnableStatus (chat_id, enabled) VALUES (%s, %d) ON DUPLICATE KEY UPDATE chat_id = %s, enabled = %d"
    #print Query
    curs.execute ( """INSERT INTO  EnableStatus (chat_id, enabled) 
        VALUES (%s, %r) ON DUPLICATE KEY 
        UPDATE chat_id = %s, enabled = %r""", (chat_id, enabled, chat_id, enabled))

    db.commit()

    try :
        idx = LST_Enable_ID.index(chat_id)
        LST_Enable[idx] = enabled
    except :
        LST_Enable_ID.append(chat_id)
        LST_Enable.append(enabled)
        LST_Donated.append(0)
    
    
def log( text ) :
    send_msg(27693025, text)
    
    
def send_msg(chat_id, text, mode=0, reply_to=None, no_preview=None, keyboard=None):
    params = {
    'chat_id': str(chat_id),
    'text': text.encode('utf-8','replace'),
    }
    
    if reply_to:
        params['reply_to_message_id'] = reply_to
    if no_preview:
        params['disable_web_page_preview'] = no_preview
        
    try:
        # print "%s,  %s " % ( chat_id, text ) 
        #urllib2.urlopen(BASE_URL + 'sendMessage', urllib.urlencode(params)).read()
        # disable_notification=False
        sw = False
        if chat_id in DICT_SOUND :
            switch = DICT_SOUND[chat_id]
            if mode == 1 :    # 검색어 매치
                sw = not switch['sound1']
            elif mode == 2 :  # 덧글수 알람
                sw = not switch['sound2']
            elif mode == 3 :  # 추천수 알람
                sw = not switch['sound3']
       
        # 검색어 Match 시 검색어 부분에 Bold 처리        
#        if mode == 1 :
#            bot.send_message(int(chat_id), text, parse_mode='HTML', disable_notification=sw)
#        else : 
        bot.send_message(int(chat_id), text, disable_notification=sw)

        
    except Exception as e: 
        logger.info("Error Chat_id : %s,  %s " % (chat_id, str(e)))
        
        emessage = str(e)
        if emessage.find ( 'blocked' ) > -1 :
            LST_BLOCK_ID.append ( chat_id )

        if emessage.find ( 'deactivated' ) > -1 :
            LST_BLOCK_ID.append ( chat_id )
            
        # emessage = str(e)
        #if emessage.find ( 'Forbidden' ) > -1 :
        #    set_enabled(chat_id, False)
            
        #if emessage.find ( 'Timed' ) > -1 :
        #    set_enabled(chat_id, False)
            
        # set_enabled(chat_id, False)
        #logging.exception(e)
        #bot.sendMessage(chat_id, str(datetime.datetime.now()))
        
        
def handle(msg):
    # print msg
    # Update(update_id=209534597, message=Message(message_id=2539, sender=User(id=27693025, first_name=u'\uc0c1\ud6c8', last_name=u'\uc774', username=u'binsoore'), date=1462163732, chat=Chat(id=27693025, type=u'private', title=None, username=u'binsoore', first_name=u'\uc0c1\ud6c8', last_name=u'\uc774'), forward_from=None, forward_date=None, reply_to_message=None, text=u'\ubaa9\ub85d', audio=None, document=None, photo=None, sticker=None, video=None, voice=None, caption=None, contact=None, location=None, new_chat_participant=None, left_chat_participant=None, new_chat_title=None, new_chat_photo=None, delete_chat_photo=None, group_chat_created=None, supergroup_chat_created=None, channel_chat_created=None, migrate_to_chat_id=None, migrate_from_chat_id=None), inline_query=None, chosen_inline_result=None)
    #chat_id = str( msg['chat']['Chat']['id'] )

    #print 'Handle ======='
    chat_id = str( msg.message.chat.id )
    text = msg.message.text	
    
    #print "%s,  %s" % ( chat_id, text )
    
    if text == None :
        return

    text = text.replace("'", "")
        
    logger.info( 'chat_id : %s,  message: %s' % (chat_id, text) )

    # SQL Inject 
    
    insert_log (chat_id, text)

    # 블럭된 ID 가 입력을 했을때, 블럭 해제 처리
    if chat_id in LST_BLOCK_ID :
        LST_BLOCK_ID.remove(chat_id)
    
    
    if text.find ( CMD_START ) == 0 :
        cmd_start(chat_id)
        return

    if text.find ( CMD_STOP ) == 0 :
        cmd_stop(chat_id)
        return

        
    # 봇 꺼짐상태
    if (not get_enabled(chat_id)):
        send_msg(chat_id, ERROR_MSG6)
        return

    # 목록	
    if text.find ( CMD_BROADCAST ) == 0 :
        cmd_broadcast(text)
        return
        
    # 목록	
    if text == CMD_LIST or text == CMD_LIST1 :
        cmd_list(chat_id)
        return

    # 소리 
    if text.find (CMD_SOUND) == 0 :
        cmd_sound(chat_id, text)
        return		

        
    # 검색어 추가
    if text.find ( CMD_ADD ) == 0 :
        cmd_add(chat_id, text)
        return		
        
    # 순위
    if CMD_RANK in text :
        cmd_rank(chat_id)
        return		
        
    if text.find ( CMD_DEL ) == 0 :
        cmd_del(chat_id, text)
        return
        
    # 덧글
    if text.find ( CMD_REPLY_DEL) == 0 or text.find ( u'리플삭제' ) == 0 or text.find ( u'댓글삭제' ) == 0 :
        cmd_reply_del(chat_id, text)
        return
        
    if text == CMD_REPLY_LIST or text == u'리플목록' or text == u'댓글목록' :
        cmd_list(chat_id)
        return

    if text.find ( CMD_REPLY ) == 0 or text.find ( u'리플' ) == 0 or text.find ( u'댓글' ) == 0 :
        cmd_reply(chat_id, text)
        return

        
    # 추천
    if text.find ( CMD_RECOM_DEL) == 0 :
        cmd_recom_del(chat_id, text)
        return
        
    # 추천목록
    if text == CMD_RECOM_LIST :
        cmd_list(chat_id)
        return

    if text.find (CMD_RECOM) == 0 :
        cmd_recom(chat_id, text)
        return

        
    # 시간
    if text.find ( CMD_ALRAM_TIME ) == 0 or text.find ( u'시간' ) == 0:
        cmd_alram_time(chat_id, text)
        return
        
    if text.find ( CMD_HELP ) == 0 or text.find ( CMD_HELP1 ) == 0:
        cmd_help(chat_id)
        return
    
    if CMD_BOARD == text or CMD_BOARD1 == text :
        cmd_board(chat_id)
        return
    # 기부
    if text == CMD_DONATE :
        cmd_donate(chat_id)
        return


        
    send_msg (chat_id, MSG_HELP)
    

    # 시간
#	if text == '/time':
#		bot.sendMessage(chat_id, str(datetime.datetime.now()))
#		return

def cmd_board(chat_id):
    u"""cmd_board: 게시판 목록
    chat_id: (integer) 채팅 ID
    """
    str = ''
    for r in BASE_BOARD_LIST :
        str = str + r + ' / '
        
    send_msg(chat_id, str)


def cmd_sound(chat_id, text):
    u"""cmd_sound: 검색어, 덧글, 추천수별 소리 On/Off 
    text: (integer) 
    """
    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
    curs = db.cursor(pymysql.cursors.DictCursor)
    
    sMsg = u"검색어: %s,  덧글: %s,  추천: %s \n\n 도움말 : http://bitly.kr/d3sths1"

    try : 
        
        if chat_id in DICT_SOUND :
            switch = DICT_SOUND[chat_id]
        else : 
            switch = DEFAULT_SOUND
        

        bChange = False
        if text.find(u"검색어") > 0 :
            bChange = True
            switch['sound1'] = not switch['sound1']

        if text.find(u"덧글") > 0 :
            bChange = True
            switch['sound2'] = not switch['sound2']

        if text.find(u"추천") > 0 :
            bChange = True
            switch['sound3'] = not switch['sound3']
            
        if bChange :
            curs.execute ( u"""INSERT INTO sound (chat_id, value )
                VALUES (%s, %s) 
                ON DUPLICATE KEY 
                UPDATE chat_id = %s, value = %s""", (chat_id, str(switch), chat_id, str(switch)))
            db.commit()
        
            DICT_SOUND[chat_id] = switch

        # 가공
        
        sMsg = sMsg % (switch['sound1'], switch['sound2'], switch['sound3'])
        
        sMsg = sMsg.replace ("True", "On")
        sMsg = sMsg.replace ("False", "Off")
        
        logger.info (sMsg)
        send_msg(chat_id, sMsg)
        
        db.close()

    except Exception as e: 
        logger.info("def cmd_sound Error,  Chat_id : %s,  %s " % (chat_id, str(e)))


def pasing_url( link, board_name, type ):
    global RasbMode
    
    # 마켓일경우 로그인 필요.
    try :
        if type == 'market' :
            #login_data = urllib.urlencode({'user_id' : config.user_id, 'password' : config.password})
            #request = urllib2.Request(config.login_page, login_data)
            #response = urllib2.urlopen(request)
            #cookie = response.headers.get('Set-Cookie')		

            request = urllib2.Request(link)
            request.add_header('cookie', cookie)
            response = urllib2.urlopen(request)
            content = response.read()
        else :	
        
            # print link
            request = urllib2.Request(link)
            # request = urllib2.Request(link , headers={'User-agent', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:23.0) Gecko/20131011 Firefox/23.0'})
            content = urllib2.urlopen(request).read()
        

    except Exception, e :
        logger.info ( 'Error urlopen %s : %s ' % ( board_name, str(e)  ) )
        return
        
    # BeautifulSoup 로 파싱
    soup = BeautifulSoup(content, "lxml")

    if type == "p1" :	
        elements=soup.findAll("li", {"class" : "none-border"})
    elif "ppomppu2" in link :
        elements=soup.findAll("li")
    else :
        elements=soup.findAll("a", {"class" : "noeffect"})
    
    for el in reversed(elements):
        reply = 0
    
        # li 에 쓰레기 정보 들어온다. menu_list.php 제외
        if 'menu_list.php' in el : 
            continue

        if 'thumbnail'in el : 
            continue
            
            
        if type == "p1" :	
            # 뽐뿌, 해외뽐뿌 게시판 파싱
            url = el.find('a')['href']
            title = el.find('span', {"class" : "cont"})
            if title == None :
                continue
            else :
                title = title.text
                title = title.lower()

            try : 
                info = ""
                _info = el.find('span', {"class" : "info"})
                if hasattr(_info, 'text') :
                    info = _info.text
                
            except Exception, e :
                logger.error ( 'el.find(span) : %s ' % str(e) )
                info = ""
                # print str (e)
            
            reply = el.find('span', {"class" : "rp"})
            if hasattr(reply, 'text') :
                reply= reply.text
            else :
                reply  = "0"
                
            recoms = el.find_all('span')
            if len(recoms) > 3 :
                temps = recoms[len(recoms)-1].text
                temp = temps.split("/")
                if len(temp) > 1 :
                    recom = temp[1].strip() 
                else :
                    recom = 0
                
            else :
               recom = "0"
  
            url= 'https://www.ppomppu.co.kr/zboard/' + url.strip()
            url= url.replace("bbs_", "")

            bbs_no = url.split("&")
            if len(bbs_no) < 2 : 
                continue
                
            bbs_no = bbs_no[1].replace("no=", "")

            # title= 	title.strip()
            # info= 	info.strip()
            # replys = replys.split()
            # reply = replys[0]
            # try :
                # if len(replys) > 1 : 
                    # recom = replys[1]
                    # recom = recom.strip()
                # else :
                    # recom = 0
            # except Exception, e:
                # logger.error ( ' link : %s\n board_name : %s\n type : %s\n ' % ( link, board_name, type ) )
                # logger.error ( 'recom = replys[1] : %s' % str(e) )            
                # recom = 0
            
        else :
            # 기타 게시판 파싱.
            # print el
            try : 
                if 'ppomppu2' in link : 
                    if "menu_list.php" in el :
                        continue
                        
                    title = el.find("p", {"class" : "title"})
                    if title == None :
                        continue
                    else :
                        title = title.text

                    reply = el.find('span', {"class" : "label-comment"})
                   
                    if reply == None :
                        reply = '0'
                    else :
                        reply = reply.text
                        
                    url = el.find('a')['href']
                   
                    recom = '0'
                    # print url
                    
                else :
                    title = el.find('strong')
                    url = el['href']
                    # 덧글
                    # logger.info ( el )
                    
                    if title == None :
                        continue
                    else :
                        title = title.text
                        
                    #reply = el.find("span", {"class" : "rp"}).text
                    #reply = reply.replace('[', '')
                    #reply = reply.replace(']','')
                    # replycount = el.find('span', {'class' : 'hi'})

                    replycount = el.find('span', {'class' : 'rp'})

                    if hasattr(replycount, 'text') :
                        reply = replycount.text
                    else :
                        reply = '0'

                    recoms = el.find('span', {'class' : 'hi'})
                    if hasattr(recoms, 'text') :
                        temp = recoms.text
                        temp = temp.split("/")
                        if len(temp) > 2 : 
                            recom = temp[1].strip()
                        else :
                            recom = "0"
                        
                    else :
                        recom = '0'
                    
                title = title.lower()
                
                # logger.info ( title )

                # PC 용
                # http://www.ppomppu.co.kr/zboard/view.php?id=ppomppu&no=310472&page=1
                
                # 모바일용
                # http://m.ppomppu.co.kr/new/bbs_view.php?id=ppomppu&no=310437
                
            except Exception, e :
                logger.error ( ' link : %s\n board_name : %s\n type : %s\n ' % ( link, board_name, type ) )
                logger.error ( 'el : %s ' % el )
                logger.error ( 'ppomppu2 in link recom : %s' % str(e) )            
                continue
                
            title = title.lower()

            # PC 용
            # http://www.ppomppu.co.kr/zboard/view.php?id=ppomppu&no=310472&page=1
            
            # 모바일용
            # http://m.ppomppu.co.kr/new/bbs_view.php?id=ppomppu&no=310437



            # 20.10.27, 쇼핑쪽 게시판은 url 정보가 다르다.
            # 정상적인 게시물
            # <a href="bbs_view.php?id=ppomppu&no=368819&page=1
            # <a href='bbs_view.php?id=phone&no=3642385&page=1'>
            
            # 쇼핑쪽 게시물
            # <a href="?id=ppomppu2&no=45010&page=1">
            # 아래 수정.
            for category in ['ppomppu2', 'pmarket2'] :
                if category in link : 
                    url = "bbs_view.php" + url


            url= 'https://www.ppomppu.co.kr/zboard/' + url.strip()
            url= url.replace("bbs_", "")

            bbs_no = url.split("&")
            if len(bbs_no) < 2 : 
                continue
            bbs_no = bbs_no[1].replace("no=", "")


        url= url.replace("&page=1", "")
        url= url.replace("&page=2", "")

        
        # 장터는 덧글, 추천 무시.
        if type == 'market' :
            return

        logger.info ( title )

        # 검색어 목록 초기화, 지역변수들임. 
        LST_SAVE_STR = [] 
        LST_SAVE_BBS_NO = []
        LST_SAVE_BOARD_NAME = []
        LST_SAVE_FS = []


        if board_name+bbs_no not in LST_COMPLETE_BBSNO :
            LST_COMPLETE_BBSNO.append ( board_name+bbs_no )

            # 검색어 매치 
            # 1 Page 만 파싱하고, 2, 3페이지는 덧글수, 추천수만 본다.
            if "page" not in link :
                for i, fs in enumerate(findstr_list) :
                    if  board_list[i] == board_name :
                        if title.find ( fs ) > -1 :
                            # 저장 되었는지 확인
                            # { TODO : 검색어 DB 삭제? }
                            # 검색어 DB 에 저장할 필요가 있나? 
                            # 최근등록자는 최근게시물 알람이 안오는 문제?
                            # 이미 메시지 전송된 게시물번호
                            # 게시판 이름 같고, 게시판 번호 같으면 패스
                            if check_bbsno(bbs_no.strip(), board_name.strip(), fs) : 
                                #if send_msg_alram(chat_id_list[i], u"[%s] " % board_name + title + " \n " + url) :

                                # 검색어에 Bold 처리 
                                # title = title.replace( fs, "<b>"+fs+"</b>" )
                                msg = u"[%s] " % board_name + title + " \n " + url

                                # 기부자는 제일 먼저 처리
                                LOCK.acquire()

                                if donate_member(chat_id_list[i]) :
                                    LST_MESSAGE.insert ( 0, [chat_id_list[i], msg, 1] ) 
                                else :
                                    LST_MESSAGE.append ( [chat_id_list[i], msg, 1] ) 
                                LOCK.release()



                                try : 
                                    a = LST_SAVE_STR.index(bbs_no+board_name+fs)
                                except : 
                                    LST_SAVE_STR.append(bbs_no+board_name+fs)
                                    LST_SAVE_BBS_NO.append(bbs_no)
                                    LST_SAVE_BOARD_NAME.append(board_name)
                                    LST_SAVE_FS.append(fs)
                                
                for i, r in enumerate(LST_SAVE_STR) :
                    save_bbsno(LST_SAVE_BBS_NO[i], LST_SAVE_BOARD_NAME[i], LST_SAVE_FS[i])
                            
                # 장터는 검색어 매치만. 덧글 Count X
                if type == 'market' : 
                    continue
        
        
        # 덧글 카운터 목록
        LST_SAVE_STR[:] = [] 
        LST_SAVE_BBS_NO[:] = []
        LST_SAVE_BOARD_NAME[:] = []
        LST_SAVE_CNT = []
        LST_SAVE_SEND_COUNT = []
        
        offset = -1
        
        loop = True
        while loop:
            try:
            
                # 속도증가를 위해 for 대신 list 의 index 사용
                offset = rboard_list.index( board_name, offset+1 )
                # 숫자검증
                if not isNumber(reply) :
                    continue
                c = int(reply)
                cnt = rcount_list[offset]
                
                #send_msg(27693025, " %d, %d " % (c, cnt))
                # 덧글이 크면 알림
                if c >= cnt :
                    if reply_recom_check_bbsno('reply', bbs_no+','+board_name+',%d' % cnt) : 
                        #if send_msg_alram(rchat_id_list[offset], u"(%s) " % board_name + title + " \n " + url) :
                        msg = u"(%s) " % board_name + title + " \n " + url
                        LOCK.acquire()

                        if donate_member(rchat_id_list[offset]) :
                            LST_MESSAGE.insert ( 0, [rchat_id_list[offset], msg, 2] ) 
                        else :
                            LST_MESSAGE.append ( [rchat_id_list[offset], msg, 2] ) 
                        LOCK.release()

                        try : 
                            idx = LST_SAVE_STR.index(bbs_no+board_name+str(cnt))
                            LST_SAVE_SEND_COUNT[idx] = LST_SAVE_SEND_COUNT[idx] + 1
                        except : 
                            LST_SAVE_STR.append(bbs_no+board_name+str(cnt))
                            LST_SAVE_BBS_NO.append(bbs_no)
                            LST_SAVE_BOARD_NAME.append(board_name)
                            LST_SAVE_CNT.append(cnt)
                            LST_SAVE_SEND_COUNT.append(1)
                
            except ValueError:
                loop = False
            
        for i, r in enumerate(LST_SAVE_STR) :
            reply_recom_save_bbsno('reply', LST_SAVE_BBS_NO[i], LST_SAVE_BOARD_NAME[i], LST_SAVE_CNT[i], LST_SAVE_SEND_COUNT[i])
            
            
            
        # 추천 카운터 목록
        offset = -1
        LST_SAVE_STR[:] = [] 
        LST_SAVE_BBS_NO[:] = []
        LST_SAVE_BOARD_NAME[:] = []
        LST_SAVE_CNT[:] = []
        LST_SAVE_SEND_COUNT[:] = []

        loop = True
        while loop:
            try:
                offset = rc_board_list.index( board_name, offset+1 )
                
                # 숫자검증
                if not isNumber(recom) :
                    continue
                c = int(recom)
                cnt = rc_count_list[offset]
                
                # 추천이 크면 알림
                if c >= cnt :
                    if reply_recom_check_bbsno('recom', bbs_no+','+board_name+',%d' % cnt) : 
                        #if send_msg_alram(rc_chat_id_list[offset], u"*%s* " % board_name + title + " \n " + url) :
                        msg = u"*%s* " % board_name + title + " \n " + url
                        
                        LOCK.acquire()
                        if donate_member(rc_chat_id_list[offset]) :
                            LST_MESSAGE.insert ( 0, [rc_chat_id_list[offset], msg, 3] ) 
                        else :
                            LST_MESSAGE.append ( [rc_chat_id_list[offset], msg, 3] ) 
                        LOCK.release()    

                        
                        try : 
                            idx = LST_SAVE_STR.index(bbs_no+board_name+str(cnt))
                            LST_SAVE_SEND_COUNT[idx] = LST_SAVE_SEND_COUNT[idx] + 1
                        except : 
                            LST_SAVE_STR.append(bbs_no+board_name+str(cnt))
                            LST_SAVE_BBS_NO.append(bbs_no)
                            LST_SAVE_BOARD_NAME.append(board_name)
                            LST_SAVE_CNT.append(cnt)
                            LST_SAVE_SEND_COUNT.append(1)
                            
            except ValueError:
                loop = False
                            
        for i, r in enumerate(LST_SAVE_STR) :
            reply_recom_save_bbsno('recom', LST_SAVE_BBS_NO[i], LST_SAVE_BOARD_NAME[i], LST_SAVE_CNT[i], LST_SAVE_SEND_COUNT[i])
        
        
# 게시판 번호가 저장
def save_bbsno(no, board_name, findstr):
    try :
        db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
        curs = db.cursor(pymysql.cursors.DictCursor)
        
        curs.execute ( """INSERT INTO end_str (no, board, findstr) 
            VALUES (%s, %s, %s)""", (no, board_name, findstr.lower()))
        db.commit()

        LST_BBSNO_NO.append(no)
        LST_BBSNO_BOARD.append(board_name)
        LST_BBSNO_FINDSTR.append(findstr)
    except Exception, e:
        logger.error ( 'save_bbsno : %s ' % str(e) )            

def insert_log(chat_id, text):
    try :
    
        # 사용자 입력 로그, 저장
        db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
        curs = db.cursor(pymysql.cursors.DictCursor)
        
        curs.execute ( """INSERT INTO log (chat_id, text) 
            VALUES (%s, %s)""", (chat_id, text))
        db.commit()
    except Exception, e:
        logger.error ( 'insert_log : %s ' % str(e) )            
        
    
def reply_recom_save_bbsno(type, no, board_name, count, send_count):
    try : 
        db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
        curs = db.cursor(pymysql.cursors.DictCursor)
        
        if type == 'reply' :
            LST_REPLY_NO.append(no + ','+ board_name + ',%d' % count )
            curs.execute ( """INSERT INTO end_reply (no, board, count, send_count) 
                VALUES (%s, %s, %s, %s)""", (no, board_name, count, send_count))
        else :
            LST_RECOM_NO.append(no + ','+ board_name + ',%d' % count )
            curs.execute ( """INSERT INTO end_recom (no, board, count, send_count) 
                VALUES (%s, %s, %s, %s)""", (no, board_name, count, send_count))
                
        db.commit()
    except Exception, e:
        logger.error ( 'reply_recom_save_bbsno : %s ' % str(e) )            
    
    
def send_msg_alram(chat_id, text, mode=0):
#    try : 
#	if chat_id != 27693025 :
#		return

    # 봇이 꺼져 있으면 발신 금지
    if (not get_enabled(chat_id)):
        return

    # Block ID 이면 전송 금지
    if chat_id in LST_BLOCK_ID :
        return

        
    try :
        idx = LST_ALRAM_ID.index(chat_id)
    except :
        send_msg(chat_id, text, mode)
        return True

    # 시간설정 없으면 	
    if idx == -1 : 
        send_msg(chat_id, text, mode)
        return True

    st = LST_ALRAM_TIME[idx]
    sTime = st.split("-")

    if len(sTime) < 2 :
        send_msg(chat_id, text, mode)
        return True
        
    dt = datetime.now()

    #send_msg(27693025, '%d' % dt.hour)

    ## 시간에 포함되면 알람. 아니면 무시
    if int(sTime[0]) <= dt.hour and int(sTime[1]) > dt.hour :
        send_msg(chat_id, text, mode)
        return True
#    except Exception, e:
        # print 'Error send_msg_alram : %s ' % str(e)
#        print 'Error send_msg_alram : ' 
        
# 게시판 번호가 Push 알람 되었는지 검사
def check_bbsno(bbsno, board_name, findstr):
    try : 
        result = 1
        # for idx, r in enumerate(LST_BBSNO_NO) :
        # for idx, r in reversed(list(enumerate(LST_BBSNO_NO))):           
        for idx in reversed(range(len(LST_BBSNO_NO))) :        
            try :
                dbstr = LST_BBSNO_NO[idx]+','+LST_BBSNO_BOARD[idx]+','+LST_BBSNO_FINDSTR[idx]
            except :
                dbstr = ""
            fstr = bbsno+','+board_name + ',' + findstr
            if dbstr == fstr :
                result = 0
                break;
        return result
    except Exception, e:
        logger.error ( 'check_bbsno : %s ' % str(e) )            
        

# 덧글 카운터가 Push 알람 되었는지 검사
def reply_recom_check_bbsno(type, str):
    try : 
        result = 1
        offset = -1
        while True :
            try :
                if type == 'reply' :
                    offset = LST_REPLY_NO.index ( str, offset+1)
                else :
                    offset = LST_RECOM_NO.index ( str, offset+1)
                result = 0
            except :
                break;
        
        return result
        
    except Exception, e:
        logger.error ( 'reply_recom_check_bbsno : %s ' % str(e) )            
        

    
def init_logger():

    if not os.path.isdir('./log') :
        os.mkdir('./log')
        
    # 로거 인스턴스 생성
    # logger = logging.getLogger("mylogger")


    # 포매터를 만든다
    # formatter = logging.Formatter('[%(levelname)s|%(filename)s:%(lineno)s] %(asctime)s > %(message)s')
    formatter = logging.Formatter(' [%(asctime)s][%(levelname)s|%(filename)s:%(lineno)s] %(message)s')

    fileMaxByte = 1024 * 1024 * 10  # 10MB

    # 화면, 파일 각각 핸들러 생성
    filename = "./log/ppomppu.log"
    fileHandler = logging.handlers.RotatingFileHandler(filename, maxBytes=fileMaxByte, backupCount=10)

    fileHandler.setFormatter(formatter)
    streamHandler = logging.StreamHandler()
    streamHandler.setFormatter(formatter)
    # 핸들러를 생성된 logger 에 추가한다.
    logger.addHandler(fileHandler)
    logger.addHandler(streamHandler)
    logger.setLevel(logging.DEBUG)
    
##########################################################################	
#    db = pymysql.connect(host=DBHOST, port = DBPORT, user=DBUSER, password=DBPASSWORD, db=DBNAME, charset='utf8')
#curs = db.cursor(pymysql.cursors.DictCursor)

def ReceiveMsg (bot, update) :
    handle (update)

if __name__ == "__main__":     

    # 라즈베리파이에서 실행하나? 
    RasbMode = False

    init_logger()
    # logger = LOG
    logger.info ( " ppomppu_bot ==> Start !! " )  


    if os.path.exists('./ras.mode') :
        RasbMode = True
        # TOKEN = TOKEN_INE
        # BASE_URL = 'https://api.telegram.org/bot' + TOKEN_INE + '/'
        logger.info ( 'RaspBerry PI Run' )
    else :
        logger.info ('smsoft4.ine.kr Run' )
        
        
    #bot = TelegramBot(TOKEN)
    
    bot = telegram.Bot(TOKEN)
    updater = Updater(token=TOKEN)
    dp = updater.dispatcher
    dp.add_handler(MessageHandler(Filters.text, ReceiveMsg))
    # dp.add_handler(CommandHandler("notice11", cmd_broadcast))    
    
    # MessageHandler 메세지를 받았을때 행동합니다. 
    updater.start_polling()


    #bot.update_bot_info().wait()
    logger.info( bot.username )
    logger.info('Start !!')
    
    init()

    # updater.idle()
    
    # Update(update_id=209534597, message=Message(message_id=2539, sender=User(id=27693025, first_name=u'\uc0c1\ud6c8', last_name=u'\uc774', username=u'binsoore'), date=1462163732, chat=Chat(id=27693025, type=u'private', title=None, username=u'binsoore', first_name=u'\uc0c1\ud6c8', last_name=u'\uc774'), forward_from=None, forward_date=None, reply_to_message=None, text=u'\ubaa9\ub85d', audio=None, document=None, photo=None, sticker=None, video=None, voice=None, caption=None, contact=None, location=None, new_chat_participant=None, left_chat_participant=None, new_chat_title=None, new_chat_photo=None, delete_chat_photo=None, group_chat_created=None, supergroup_chat_created=None, channel_chat_created=None, migrate_to_chat_id=None, migrate_from_chat_id=None), inline_query=None, chosen_inline_result=None)

    # 명령 수신 체크
    # 명령 수신 체크
    Tm = GetCommand_Timer(60, MonitorDonated)
    Tm.start()

    # 메세지 큐에서 하나씩 꺼내서 전송
    Tm2 = GetCommand_Timer(1, GetMessage)
    Tm2.start()

    call_url()
    
    # 1분후 조회			
    now = datetime.now()
    timegap = timedelta(minutes=2)

    while True:
        # 뽐뿌 Site 파싱
        if datetime.now() > now + timegap :
            now = datetime.now()
            try : 
                call_url()
            except :
                continue
        
        time.sleep(1)
        