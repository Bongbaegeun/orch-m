#-*- coding: utf-8 -*-

TTYPE = "CAR"
MODEL_LIST = ['3030']

def chkParam( params ):
    if params == None or len(params) < 1 :
        return '[ERROR] No Param, Params: 1. ModelType=%s'%str(MODEL_LIST)
    elif len(params) !=1 :
        return '[ERROR] Invalid Para -> %s, Params: ModelType'%str(params)
    
    p1 = str(params[0])
    if not p1 in MODEL_LIST :
        return '[ERROR] Unknown Model Type -> %s, Supported Model=%s'%(str(p1), str(MODEL_LIST))
    
    return None

def makeBody(_type, params, plugDir, HIST="10", TRND="180"):
    ret = chkParam(params)
    if ret != None :
        print ret
        return

    mType = params[0]
    
    REAP_H = '1'
    REAP_M = '1'
    REAP_L = '1'
    if _type == 'REAL':
        STAT_H = "30"
        STAT_M = "60"
        STAT_L = "120"
        PERF_H = "60"
        PERF_M = "300"
        PERF_L = "600"
        REAP_H = '3'
        REAP_M = '2'
        REAP_L = '1'
    elif _type == 'TEST':
        STAT_H = "10"
        STAT_M = "30"
        STAT_L = "60"
        PERF_H = "30"
        PERF_M = "60"
        PERF_L = "120"
    elif _type == 'SHOW' :
        STAT_H = "2"
        STAT_M = "10"
        STAT_L = "30"
        PERF_H = "10"
        PERF_M = "30"
        PERF_L = "60"
    else:
        print "Invalid Template Type -> %s, Supported Type=[REAL, TEST, SHOW]"
        return

    print '=======>> Creating HW:%s:%s:%s Template'%(TTYPE, mType, _type)
    
    body = {
        "tid":'temp-create-car1',
        "target_info":{
                'code':'hw', 'type':'svr', 'vendor_code':'car', 'model':mType, 
                "name":"CAR SVR", "visible":'CAR 서버', "description":"CAR %s Monitoring"%mType,
                'version':'v1.0', 'target_for':'OneTouch'
            },
        "group":[
            {'name': 'net', 'visible':'네트워크', 'description':'CAR SVR Network',
                 "item":[
                    {
                        "name":"SVR Connection",
                        "visible":'서버 연결 상태',
                        "type":"SVR Connection",
                        "item_id":"hw.svr.net.conn.hw",
                        "monitor_method":"simple",
                        "zb_type":"ping_check",
                        "realtime_yn": 'y',
                        "data_type":"int",
                        "value_type":"status",
                        "period":STAT_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"CAR Server Connection",
                        "alarm_guide":{'name':'CAR Connection Alarm', 'guide':"""1. One-Box 서버 Ping 확인: "ping $IP"
2. 장애 시, LAN 포트 연결 상태 확인
3. H/W 담당자 및 개발팀 연락"""},
#                         "threshold_zb_yn":"y",
                        "threshold":[
                            {
                                "name":"[Critical] SVR Connection Release Alarm",
                                "grade":"Critical",
                                "description":"SVR Connection Release",
                                "repeat":REAP_H, 
                                "conditions":{"op":"<=", "value":"0"}
                            }
                        ]
                    },
                    {
                        "name":"ZBA Connection",
                        'visible':'ZBA 연결상태',
                        "type":"ZBA Connection",
                        "item_id":"hw.svr.net.conn.mon_agt",
                        "monitor_method":"simple",
                        "zb_type":"tcp_port_10050_check",
                        "realtime_yn": 'y',
                        "data_type":"int",
                        "value_type":"status",
                        "period":STAT_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Zabbix Agent Port Check",
                        "alarm_guide":{'name':'ZBA Connection Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Zabbix Agent 프로세스 확인: "service zabbix-agent status"
4. Down 상태일 경우 재기동: "service zabbix-agent start" """},
                        "threshold":[
                            {
                                "name":"[Critical] ZBA Connection Release Alarm",
                                "grade":"Critical",
                                "description":"ZBA Connection Release",
                                "repeat":REAP_H, 
                                "conditions":{"op":"<=", "value":"0"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'item', "visible":'감시항목', 'description':'Server Item',
                'item':[
                    {
                        "name":"Item Inactive",
                        "visible":'비활성 감시항목', 
                        "type":"Inactive",
                        "item_id":"hw.svr.etc.inactive_item.rate",
                        "monitor_method":"trap",
                        "zb_type":"item_inactive",
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Server Item Inactive Count",
                        "alarm_guide":{'name':'Item Inactive Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 감시 로그 확인: " tail -fn 500 /var/log/zabbix-agent/*.log ", " tail -fn 500 /var/log/zabbix-agent/plugin/*.log "
4. Zabbix 서버 연결 상태 확인: "nc -z $ZABBIX_SERVER_IP 10051"
5. 서버 담당자 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] SVR Item Inactive Alarm",
                                "grade":"warning",
                                "description":"SVR Item Inactive Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"30"},{"op":"<", "value":"40"}]
                            },
                            {
                                "name":"[Minor] SVR Item Inactive Alarm",
                                "grade":"minor",
                                "description":"SVR Item Inactive Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"40"},{"op":"<", "value":"60"}]
                            },
                            {
                                "name":"[Major] SVR Item Inactive Alarm",
                                "grade":"major",
                                "description":"SVR Item Inactive Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"60"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Critical] SVR Item Inactive Alarm",
                                "grade":"Critical",
                                "description":"SVR Item Inactive Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"80"}
                            }
                        ]
                    }
                ]
            }
        ]
    }
    
    return body


