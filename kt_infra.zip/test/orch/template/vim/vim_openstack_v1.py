#-*- coding: utf-8 -*-

TTYPE = "OPENSTACK"
MODEL_LIST = ['kilo']

def chkParam( params ):
    if params == None or len(params) < 1 :
        return '[ERROR] No Param, Params: 1. ModelType=%s'%str(MODEL_LIST)
    elif len(params) !=1 :
        return '[ERROR] Invalid Para -> %s, Params: ModelType'%str(params)
    
    p1 = str(params[0])
    if not p1 in MODEL_LIST :
        return '[ERROR] Unknown Model Type -> %s, Supported Model=%s'%(str(p1), str(MODEL_LIST))
    
    return None

def makeBody(_type, params, plugDir, HIST="10", TRND="180"):
    ret = chkParam(params)
    if ret != None :
        print ret
        return

    mType = params[0]
    
    REAP_H = '1'
    REAP_M = '1'
    REAP_L = '1'
    DISC_P = '300'
    if _type == 'REAL':
        STAT_H = "30"
        STAT_M = "60"
        STAT_L = "120"
        PERF_H = "60"
        PERF_M = "300"
        PERF_L = "600"
        REAP_H = '3'
        REAP_M = '2'
        REAP_L = '1'
    elif _type == 'TEST':
        STAT_H = "10"
        STAT_M = "30"
        STAT_L = "60"
        PERF_H = "30"
        PERF_M = "60"
        PERF_L = "120"
        DISC_P = "120"
    elif _type == 'SHOW' :
        STAT_H = "2"
        STAT_M = "10"
        STAT_L = "30"
        PERF_H = "10"
        PERF_M = "30"
        PERF_L = "60"
        DISC_P = "60"
    else:
        print "Invalid Template Type -> %s, Supported Type=[REAL, TEST, SHOW]"
        return

    print '=======>> Creating VIM:%s:%s:%s Template'%(TTYPE, mType, _type)
    
    body = {
        "tid":'temp-create-1',
        "target_info":{
                'code':'vim', 'type':'openstack', "name":"VIM-OpenStack", "visible":'오픈스택[VIM]', 'model':mType, 
                'vendor_code':'openstack', "description":"OpenStack %s Monitoring"%mType,
                'version':'v1.1', 'target_for':'OneTouch'
            },
        "group":[
            {'name': 'openstack-quota', "visible":'오픈스택 Quota', 'description':'OpenStack Quota Monitor',
             "item":[
                    {
                        "name":"VM Quota UtilRate",
                        "visible":'VM Quota 사용률',
                        "type":"VM Util",
                        "item_id":"vim.osp.quota.util.vm",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VM UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VM UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/nova_quota_usage.py',
                                'param_num':'2', 'plugin_param':['INSTANCE', 'UTIL'], 'description':'OpenStack Quota VM UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VM UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "nova quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VM UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VM UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VM UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VM UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VM UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VM UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VM UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VM UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VCore Quota UtilRate",
                        "visible":'가상 Core Quota 사용률', 
                        "type":"VCore Util",
                        "item_id":"vim.osp.quota.util.vcore",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VCore UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VCore UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/nova_quota_usage.py',
                                'param_num':'2', 'plugin_param':['CORE', 'UTIL'], 'description':'OpenStack Quota VCore UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VCore UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "nova quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VCore UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VCore UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VCore UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VCore UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VCore UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VCore UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VCore UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VCore UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VRam Quota UtilRate",
                        "visible":'가상 RAM Quota 사용률', 
                        "type":"VRam Util",
                        "item_id":"vim.osp.quota.util.vmem",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VRam UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VRam UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/nova_quota_usage.py',
                                'param_num':'2', 'plugin_param':['RAM', 'UTIL'], 'description':'OpenStack Quota VRam UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VRam UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "nova quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VRam UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VRam UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VRam UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VRam UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VRam UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VRam UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VRam UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VRam UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VDisk Quota UtilRate",
                        "visible":'가상 Disk Quota 사용률', 
                        "type":"VDisk Util",
                        "item_id":"vim.osp.quota.util.vdisk",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VDisk UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VDisk UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/nova_quota_usage.py',
                                'param_num':'2', 'plugin_param':['DISK', 'UTIL'], 'description':'OpenStack Quota VDisk UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VDisk UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "nova quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VDisk UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VDisk UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VDisk UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VDisk UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VDisk UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VDisk UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VDisk UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VDisk UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VKeyPair Quota UtilRate",
                        "visible":'가상 접속Key Quota 사용률', 
                        "type":"VKeyPair Util",
                        "item_id":"vim.osp.quota.util.vkey",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VKeyPair UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VKeyPair UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/nova_quota_usage.py',
                                'param_num':'2', 'plugin_param':['KEYPAIR', 'UTIL'], 'description':'OpenStack Quota VKeyPair UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VKeyPair UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "nova quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VKeyPair UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VKeyPair UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VKeyPair UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VKeyPair UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VKeyPair UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VKeyPair UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VKeyPair UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VKeyPair UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VNet Quota UtilRate",
                        "visible":'가상 네트워크 Quota 사용률', 
                        "type":"VNet Util",
                        "item_id":"vim.osp.quota.util.vnet",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VNet UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VNet UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/neutron_quota_usage.py',
                                'param_num':'2', 'plugin_param':['NETWORK', 'UTIL'], 'description':'OpenStack Quota VNet UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VNet UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "neutron quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VNet UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VNet UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VNet UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VNet UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VNet UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VNet UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VNet UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VNet UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VSubnet Quota UtilRate",
                        "visible":'가상 서브넷 Quota 사용률', 
                        "type":"VSubnet Util",
                        "item_id":"vim.osp.quota.util.vsubnet",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VSubnet UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VSubnet UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/neutron_quota_usage.py',
                                'param_num':'2', 'plugin_param':['SUBNET', 'UTIL'], 'description':'OpenStack Quota VSubnet UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VSubnet UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "neutron quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VSubnet UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VSubnet UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VSubnet UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VSubnet UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VSubnet UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VSubnet UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VSubnet UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VSubnet UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VPort Quota UtilRate",
                        "visible":'가상 Port Quota 사용률', 
                        "type":"VPort Util",
                        "item_id":"vim.osp.quota.util.vport",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VPort UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VPort UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/neutron_quota_usage.py',
                                'param_num':'2', 'plugin_param':['PORT', 'UTIL'], 'description':'OpenStack Quota VPort UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VPort UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "neutron quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VPort UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VPort UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VPort UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VPort UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VPort UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VPort UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VPort UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VPort UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VRouter Quota UtilRate",
                        "visible":'가상 라우터 Quota 사용률', 
                        "type":"VRouter Util",
                        "item_id":"vim.osp.quota.util.vrouter",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VRouter UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VRouter UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/neutron_quota_usage.py',
                                'param_num':'2', 'plugin_param':['ROUTER', 'UTIL'], 'description':'OpenStack Quota VRouter UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VRouter UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "neutron quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VRouter UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VRouter UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VRouter UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VRouter UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VRouter UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VRouter UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VRouter UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VRouter UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VFloatingIP Quota UtilRate",
                        "visible":'플로팅IP Quota 사용률', 
                        "type":"VFloatingIP Util",
                        "item_id":"vim.osp.quota.util.floatingip",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VFloatingIP UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VFloatingIP UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/neutron_quota_usage.py',
                                'param_num':'2', 'plugin_param':['FLOATINGIP', 'UTIL'], 'description':'OpenStack Quota VFloatingIP UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VFloatingIP UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "neutron quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VFloatingIP UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VFloatingIP UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VFloatingIP UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VFloatingIP UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VFloatingIP UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VFloatingIP UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VFloatingIP UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VFloatingIP UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VSecurityGroup Quota UtilRate",
                        "visible":'보안그룹 Quota 사용률', 
                        "type":"VSecurityGroup Util",
                        "item_id":"vim.osp.quota.util.scgrp",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VSecurityGroup UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VSecurityGroup UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/neutron_quota_usage.py',
                                'param_num':'2', 'plugin_param':['SECUGROUP', 'UTIL'], 'description':'OpenStack Quota VSecurityGroup UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VSecurityGroup UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "neutron quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VSecurityGroup UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VSecurityGroup UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VSecurityGroup UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VSecurityGroup UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VSecurityGroup UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VSecurityGroup UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VSecurityGroup UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VSecurityGroup UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    },
                    {
                        "name":"VSecurityGroupRule Quota UtilRate",
                        "visible":'보안그룹룰 Quota 사용률', 
                        "type":"VSecurityGroupRule Util",
                        "item_id":"vim.osp.quota.util.scgrp_rule",
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Openstack VSecurityGroupRule UtilRate",
                        "plugin":{
                                'name':'OpenStack Quota VSecurityGroupRule UtilRate', 'type':'file', 
                                'script': plugDir+'/vim/openstack_prov/neutron_quota_usage.py',
                                'param_num':'2', 'plugin_param':['SECUGROUPRULE', 'UTIL'], 'description':'OpenStack Quota VSecurityGroupRule UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                                'lib_name':'vim_api.py', 'lib_path':'./', 
                                'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain']
                                },
                        "alarm_guide":{'name':'VSecurityGroupRule UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Nove Quota 상태 확인: "neutron quota-show"
4. 장애 시, 개발팀에게 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] VSecurityGroupRule UtilRate Alarm",
                                "grade":"warning",
                                "description":"OpenStack VSecurityGroupRule UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] VSecurityGroupRule UtilRate Alarm",
                                "grade":"Minor",
                                "description":"OpenStack VSecurityGroupRule UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] VSecurityGroupRule UtilRate Alarm",
                                "grade":"Major",
                                "description":"OpenStack VSecurityGroupRule UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] VSecurityGroupRule UtilRate Alarm",
                                "grade":"Critical",
                                "description":"OpenStack VRouter UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            },
                        ]
                    }
                ]## item
            },
            {'name': 'openstack-vinfra-status', "visible":'오픈스택 가상자원 상태', 'description':'OpenStack VirtualInfra Status Monitor',
            "discovery":[
                    {
                    "name":"VNet Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OpenStack VNetwork Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OpenStack VNetwork Discovery', 'type':'file', 
                            'script': plugDir+'/vim/openstack_prov/neutron_discovery.py',
                            'param_num':'1', 'plugin_param':['NET'], 'description':'OpenStack VNetwork Discovery',
                            'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                            'lib_name':'vim_api.py', 'lib_path':'./', 
                            'cfg_name':'neutron_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain', 'vim_net'],
                            'discovery_input':'vim_net'
                            },
                    "item":[
                            {
                                "name":"VNet Status",
                                "visible":'가상 네트워크 상태', 
                                "type":"VNet Status",
                                "item_id":"vim.osp.status.vnet",
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_L,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"OpenStack VNetwork status",
                                "plugin":{
                                        'name':'OpenStack VNet Status', 'type':'file', 
                                        'script': plugDir+'/vim/openstack_prov/vnet-status.sh',
                                        'param_num':'1', 'description':'OpenStack VNet Status'
                                        },
                                "alarm_guide":{'name':'VNET Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 가상 네트워크 상태 확인: "neutron net-show $NET_NAME"
4. 장애 시, 개발팀에게 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] VNetwork Status Down Alarm",
                                        "grade":"critical",
                                        "description":"OpenStack VNetwork Status Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    },
                    {
                    "name":"VRouter Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OpenStack VRouter Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OpenStack VRouter Discovery', 'type':'file', 
                            'script': plugDir+'/vim/openstack_prov/neutron_discovery.py',
                            'param_num':'1', 'plugin_param':['ROUTER'], 'description':'OpenStack VRouter Discovery',
                            'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                            'lib_name':'vim_api.py', 'lib_path':'./', 
                            'cfg_name':'neutron_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain', 'vim_router'],
                            'discovery_input':'vim_router'
                            },
                    "item":[
                            {
                                "name":"VRouter Status",
                                "visible":'가상 라우터 상태', 
                                "type":"VRouter Status",
                                "item_id":"vim.osp.status.vrouter",
                                "graph_yn": 'n',
                                "realtime_yn": 'n',
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_L,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"OpenStack VRouter status",
                                "plugin":{
                                        'name':'openstack vrouter status', 'type':'file',
                                        'script': plugDir+'/vim/openstack_prov/vrouter-status.sh',
                                        'param_num':'1', 'description':'OpenStack VRouter Status'
                                        },
                                "alarm_guide":{'name':'VRouter Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 가상 라우터 상태 확인: "neutron router-show $ROUTER_NAME"
4. 장애 시, 개발팀에게 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] VRouter Status Down Alarm",
                                        "grade":"critical",
                                        "description":"OpenStack VRouter Status Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    }
                ]## discovery
            }
        ]
    }
    
    return body


