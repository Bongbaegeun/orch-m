#-*- coding: utf-8 -*-

TTYPE = "XMS"
VENDER = "KT"
MODEL_LIST = ['v1.0']

def chkParam( params ):
    if params == None or len(params) < 1 :
        return '[ERROR] No Param, Params: 1. ModelType=%s'%str(MODEL_LIST)
    elif len(params) !=1 :
        return '[ERROR] Invalid Para -> %s, Params: ModelType'%str(params)
    
    p1 = str(params[0])
    if not p1 in MODEL_LIST :
        return '[ERROR] Unknown Model Type -> %s, Supported Model=%s'%(str(p1), str(MODEL_LIST))
    
    return None

def makeBody(_type, params, plugDir, HIST="10", TRND="180"):
    ret = chkParam(params)
    if ret != None :
        print ret
        return

    mType = params[0]
    
    REAP_H = '1'
    REAP_M = '1'
    REAP_L = '1'
    DISC_P = '300'
    if _type == 'REAL':
        STAT_H = "30"
        STAT_M = "60"
        STAT_L = "120"
        PERF_H = "60"
        PERF_M = "300"
        PERF_L = "600"
        REAP_H = '3'
        REAP_M = '2'
        REAP_L = '1'
    elif _type == 'TEST':
        STAT_H = "10"
        STAT_M = "30"
        STAT_L = "60"
        PERF_H = "30"
        PERF_M = "60"
        PERF_L = "120"
        DISC_P = "120"
    elif _type == 'SHOW' :
        STAT_H = "2"
        STAT_M = "10"
        STAT_L = "30"
        PERF_H = "10"
        PERF_M = "30"
        PERF_L = "60"
        DISC_P = "60"
    else:
        print "Invalid Template Type -> %s, Supported Type=[REAL, TEST, SHOW]"
        return

    print '=======>> Creating VNF:%s:%s:%s:%s Template'%(TTYPE, VENDER, mType, _type)
    
    body = {
        "tid":'temp-create-1',
        "target_info":{
                'code':'vnf', 'type':'XMS', "name":"VNF-XMS", 'visible':'XMS[VNF]', 'model':mType,
                'vendor_code':'kt', "description":"KT XMS %s Monitoring"%mType, 
                'version':'v1.1', 'target_for':'Provisioning'
                },
        "group":[
            {'name': 'openstack-vinfra-status', 'visible':'가상자원 상태', 'description':'OpenStack VirtualInfra Status Monitor',
            "discovery":[
                    {
                    "name":"VM Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OpenStack VM Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OpenStack VM Discovery', 'type':'file',
                            'script': plugDir+'/vim/openstack_prov/nova_discovery.py',
                            'param_num':'0', 'description':'OpenStack VM Discovery',
                            'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                            'lib_name':'vim_api.py', 'lib_path':'./', 
                            'cfg_name':'nova_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_vm"],
                            'discovery_input':'vim_vm'
                            },
                    "item":[
                            {
                                "name":"XMS VM Status",
                                'visible':'VM 상태',
                                "type":"VM Status",
                                "item_id":"vim.osp.status.vm",
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_L,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"OpenStack VM status",
                                "plugin":{
                                        'name':'OpenStack VM Status', 'type':'file', 
                                        'script': plugDir+'/vim/openstack_prov/vm-status.sh',
                                        'param_num':'1', 'description':'OpenStack VM Status'
                                        },
                                "alarm_guide":{'name':'XMS VM Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. VM 상태 확인: "nova list"
4. 다운 상태일 경우, VM 기동: "nova start $VM_NAME"
5. 장애 시, 오픈스택 관리자에게 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] XMS VM Status Down Alarm",
                                        "grade":"critical",
                                        "description":"OpenStack XMS VM Status Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    },
                    {
                    "name":"VPort Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OpenStack VPort Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OpenStack VPort Discovery', 'type':'file', 
                            'script': plugDir+'/vim/openstack_prov/neutron_discovery_prov.py',
                            'param_num':'1', 'plugin_param':['PORT'], 'description':'OpenStack VPort Discovery',
                            'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                            'lib_name':'vim_api.py', 'lib_path':'./', 
                            'cfg_name':'neutron_prov_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain', 'vim_port'],
                            'discovery_input':'vim_port'
                            },
                    "item":[
                            {
                                "name":"XMS VPort Status",
                                'visible':'가상 Port 상태',
                                "type":"VPort Status",
                                "item_id":"vim.osp.status.vport",
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_L,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"OpenStack VPort status",
                                "plugin":{
                                        'name':'openstack vrouter status', 'type':'file',
                                        'script': plugDir+'/vim/openstack_prov/vport-status.sh',
                                        'param_num':'1', 'description':'OpenStack VPort Status'
                                        },
                                "alarm_guide":{'name':'XMS VPort Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 가상 Port 상태 확인: "neutron port-list -c name -c fixed_ips -c status"
4. 장애 시, 오픈스택 관리자에게 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] XMS VPort Status Down Alarm",
                                        "grade":"critical",
                                        "description":"OpenStack XMS VPort Status Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    }
                ]## discovery
            },
            {'name': 'vcpu', 'visible':'가상 CPU', 'description':'XMS VCPU Monitor',
                 "item":[
                    {
                        "name":"VCPU Load",
                        'visible':'가상 CPU 부하',
                        "type":"Load",
                        "item_id":"vnf.cpu.load",
                        "graph_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"job",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"KT XMS VCPU Load",
                        "plugin":{
                                'name':'KT XMS CPU Load', 'type':'file', 
                                'script': plugDir+'/xms/olleh/xms_plugin.py',
                                'param_num':'2', 'plugin_param':['cpu', 'load'], 'description':'KT XMS CPU Load',
                                'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                'lib_name':'xms_api.py', 'lib_path':'./', 
                                'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
                                },
                        "alarm_guide":{'name':'XMS VCPU Load Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 XMS 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""}#,
#                         "threshold":[
#                             {
#                                 "name":"[Warning] XMS VCPU Load Alarm",
#                                 "grade":"warning",
#                                 "description":"KT XMS VCPU Load Warning",
#                                 "repeat":REAP_M, 
#                                 "conditions":["and", {"op":">=", "value":"2.8"},{"op":"<", "value":"3.2"}]
#                             },
#                             {
#                                 "name":"[Minor] XMS VCPU Load Alarm",
#                                 "grade":"minor",
#                                 "description":"KT XMS VCPU Load Minor",
#                                 "repeat":REAP_M, 
#                                 "conditions":["and", {"op":">=", "value":"3.2"},{"op":"<", "value":"3.6"}]
#                             },
#                             {
#                                 "name":"[Major] XMS VCPU Load Alarm",
#                                 "grade":"major",
#                                 "description":"KT XMS VCPU Load Major",
#                                 "repeat":REAP_M, 
#                                 "conditions":["and", {"op":">=", "value":"3.6"},{"op":"<", "value":"4"}]
#                             },
#                             {
#                                 "name":"[Critical] XMS VCPU Load Alarm",
#                                 "grade":"Critical",
#                                 "description":"KT XMS VCPU Load Critical",
#                                 "repeat":REAP_M, 
#                                 "conditions":{"op":">=", "value":"4"}
#                             }
#                         ]
                    },
                    {
                        "name":"VCPU Util",
                        'visible':'가상 CPU 사용률',
                        "type":"Util",
                        "item_id":"vnf.cpu.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"KT XMS VCPU Util",
                        "plugin":{
                                'name':'KT XMS CPU Util', 'type':'file', 
                                'script': plugDir+'/xms/olleh/xms_plugin.py',
                                'param_num':'2', 'plugin_param':['cpu', 'util'], 'description':'KT XMS CPU Load',
                                'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                'lib_name':'xms_api.py', 'lib_path':'./', 
                                'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
                                },
                        "alarm_guide":{'name':'XMS VCPU Util Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 XMS 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
                        "threshold":[
                            {
                                "name":"[Warning] XMS VCPU Util Alarm",
                                "grade":"warning",
                                "description":"KT XMS VCPU Util Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] XMS VCPU Util Alarm",
                                "grade":"minor",
                                "description":"KT XMS VCPU Util Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] XMS VCPU Util Alarm",
                                "grade":"major",
                                "description":"KT XMS VCPU Util Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] XMS VCPU Util Alarm",
                                "grade":"Critical",
                                "description":"KT XMS VCPU Util Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'vmem', 'visible':'가상 메모리', 'description':'XMS VMemory Monitor',
                 "item":[
                    {
                        "name":"VMEM UtilRate",
                        'visible':'가상 메모리 사용률',
                        "type":"Util",
                        "item_id":"vnf.mem.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"KT XMS Memory UtilRate",
                        "plugin":{
                                'name':'KT XMS Memory UtilRate', 'type':'file', 
                                'script': plugDir+'/xms/olleh/xms_plugin.py',
                                'param_num':'2', 'plugin_param':['mem', 'util'], 'description':'KT XMS Memory UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                'lib_name':'xms_api.py', 'lib_path':'./', 
                                'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
                                },
                        "alarm_guide":{'name':'XMS VMem UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 XMS 클릭하여 Console 접속 후 로그인
3. 메모리 사용이 많은 프로세스 확인: "ps -aux --sort -rss | head -n $LINE_NUM"
4. 불필요한 프로세스 정지 또는 XMS 담당자 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] XMS VMem UtilRate Alarm",
                                "grade":"warning",
                                "description":"KT XMS VMem UtilRate Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] XMS VMem UtilRate Alarm",
                                "grade":"Minor",
                                "description":"KT XMS VMem UtilRate Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] XMS VMem UtilRate Alarm",
                                "grade":"Major",
                                "description":"KT XMS VMem UtilRate Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] XMS VMem UtilRate Alarm",
                                "grade":"Critical",
                                "description":"KT XMS VMem UtilRate Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'vnet', 'visible':'가상 네트워크', 'description':'XMS VNetwork Monitor',
             "item":[
                {
                    "name":"XMS Connection",
                    'visible':'XMS 연결상태',
                    "type":"Connection",
                    "item_id":"vnf.net.conn.vm",
                    "data_type":"int",
                    "value_type":"status",
                    "period":STAT_H,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"KT XMS Connection Check",
                    "plugin":{
                            'name':'KT XMS Network ConnTrack', 'type':'file', 
                            'script': plugDir+'/xms/olleh/xms_plugin.py',
                            'param_num':'1', 'plugin_param':['ping'], 'description':'KT XMS Connection Check',
                            'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                            'lib_name':'xms_api.py', 'lib_path':'./', 
                            'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'XMS Connection Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. "nova list" 명령을 통해 XMS 접속IP 확인 후 SSH 연결: "ssh $XMS_IP"
4. 장애 시, 개발팀 및 오픈스택 담당자 연락"""},
                    "threshold":[
                        {
                            "name":"[Critical] XMS Connection Alarm",
                            "grade":"critical",
                            "description":"KT XMS Connection Critical",
                            "repeat":REAP_H, 
                            "conditions":{"op":"<=", "value":"0"}
                        }
                    ]
                }
                ],
            "discovery":[
                {
                "name":"XMS VNet Discovery",
                "period":DISC_P,
                "remain":"1",
                "description":"KT XMS VNet Discovery",
                "return_field":'NAME',
                "plugin":{
                        'name':'KT XMS VNet Discovery', 'type':'file',
                        'script': plugDir+'/xms/olleh/xms_discovery.py',
                        'param_num':'1', 'plugin_param':['NETLIST'], 'description':'KT XMS VNet Discovery',
                        'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                        'lib_name':'xms_api.py', 'lib_path':'./', 
                        'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_net'],
                        'discovery_input':'vm_net'
                        },
                "item":[
                        {
                            "name":"XMS VNet I/F Status",
                            'visible':'XMS 네트워크 상태',
                            "type":"Status",
                            "item_id":"vnf.net.if.status",
                            "data_type":"int",
                            "value_type":"status",
                            "period":STAT_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"KT XMS Network I/F Status",
                            "plugin":{
                                    'name':'KT XMS Network I/F Status', 'type':'file', 
                                    'script': plugDir+'/xms/olleh/xms_plugin.py',
                                    'param_num':'3', 'plugin_param':['net', 'status'], 'description':'KT XMS Network I/F Status',
                                    'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                    'lib_name':'xms_api.py', 'lib_path':'./', 
                                    'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
                                    },
                            "alarm_guide":{'name':'XMS VNet I/F Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 XMS 클릭하여 Console 접속 후 로그인
3. NIC 상태 확인: "ethtool $IF_NAME"
4. 장애 시, 개발팀 및 오픈스택 담당자 연락"""},
                            "threshold":[
                                {
                                    "name":"[Critical] XMS VNet I/F Status Down",
                                    "grade":"critical",
                                    "description":"XMS VNet I/F Status Down",
                                    "repeat":REAP_L, 
                                    "conditions":{"op":"<=", "value":"0"}
                                }
                            ]
                        },
                        {
                            "name":"XMS VNet Rx_Rate",
                            'visible':'XMS 네트워크 RxRate',
                            "type":"Rx Rate",
                            "item_id":"vnf.net.if.rx_rate",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "data_type":"int",
                            "unit":"bps",
                            "period":PERF_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"KT XMS Network Rx_Rate",
                            "plugin":{
                                    'name':'KT XMS Network Rx_Rate', 'type':'file', 
                                    'script': plugDir+'/xms/olleh/xms_plugin.py',
                                    'param_num':'3', 'plugin_param':['net', 'rx_rate'], 'description':'KT XMS Network Rx_Rate',
                                    'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                    'lib_name':'xms_api.py', 'lib_path':'./', 
                                    'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
                                    },
                            "alarm_guide":{'name':'XMS VNet Rx_Rate Alarm', 'guide':"""1. 장애 시, 개발팀 및 XMS 담당자 연락"""},
                            "threshold":[
                                {
                                    "name":"[Warning] XMS VNet Rx_Rate Alarm",
                                    "grade":"warning",
                                    "description":"KT XMS VNet Rx_Rate Warning",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"60000000"},{"op":"<", "value":"70000000"}]
                                },
                                {
                                    "name":"[Minor] XMS VNet Rx_Rate Alarm",
                                    "grade":"Minor",
                                    "description":"KT XMS VNet Rx_Rate Minor",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"70000000"},{"op":"<", "value":"80000000"}]
                                },
                                {
                                    "name":"[Major] XMS VNet Rx_Rate Alarm",
                                    "grade":"Major",
                                    "description":"KT VNet Rx_Rate Major",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"80000000"},{"op":"<", "value":"90000000"}]
                                },
                                {
                                    "name":"[Critical] XMS VNet Rx_Rate Alarm",
                                    "grade":"Critical",
                                    "description":"KT XMS VNet Rx_Rate Critical",
                                    "repeat":REAP_M, 
                                    "conditions":{"op":">=", "value":"90000000"}
                                }
                            ]
                        },
                        {
                            "name":"XMS VNet Tx_Rate",
                            'visible':'XMS 네트워크 TxRate',
                            "type":"Tx Rate",
                            "item_id":"vnf.net.if.tx_rate",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "data_type":"int",
                            "unit":"bps",
                            "period":PERF_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"KT XMS Network Tx_Rate",
                            "plugin":{
                                    'name':'KT XMS Network Tx_Rate', 'type':'file', 
                                    'script': plugDir+'/xms/olleh/xms_plugin.py',
                                    'param_num':'3', 'plugin_param':['net', 'tx_rate'], 'description':'KT XMS Network Tx_Rate',
                                    'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                    'lib_name':'xms_api.py', 'lib_path':'./', 
                                    'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
                                    },
                            "alarm_guide":{'name':'XMS VNet Tx_Rate Alarm', 'guide':"""1. 장애 시, 개발팀 및 XMS 담당자 연락"""},
                            "threshold":[
                                {
                                    "name":"[Warning] XMS VNet Tx_Rate Alarm",
                                    "grade":"warning",
                                    "description":"KT XMS VNet Tx_Rate Warning",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"60000000"},{"op":"<", "value":"70000000"}]
                                },
                                {
                                    "name":"[Minor] XMS VNet Tx_Rate Alarm",
                                    "grade":"Minor",
                                    "description":"KT XMS VNet Tx_Rate Minor",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"70000000"},{"op":"<", "value":"80000000"}]
                                },
                                {
                                    "name":"[Major] XMS VNet Tx_Rate Alarm",
                                    "grade":"Major",
                                    "description":"KT VNet Tx_Rate Major",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"80000000"},{"op":"<", "value":"90000000"}]
                                },
                                {
                                    "name":"[Critical] XMS VNet Tx_Rate Alarm",
                                    "grade":"Critical",
                                    "description":"KT XMS VNet Tx_Rate Critical",
                                    "repeat":REAP_M, 
                                    "conditions":{"op":">=", "value":"90000000"}
                                }
                            ]
                        }
                    ]
                }
                ]
            },
            {'name': 'vdisk', 'visible':'가상 Disk', 'description':'XMS VDisk Monitor',
            "discovery":[
                {
                "name":"XMS VDisk Discovery",
                "period":DISC_P,
                "remain":"1",
                "description":"KT XMS VDisk Discovery",
                "return_field":'NAME',
                "plugin":{
                        'name':'KT XMS VDisk Discovery', 'type':'file',
                        'script': plugDir+'/xms/olleh/xms_discovery.py',
                        'param_num':'1', 'plugin_param':['DISKLIST'], 'description':'KT XMS VDisk Discovery',
                        'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                        'lib_name':'xms_api.py', 'lib_path':'./', 
                        'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_fs'],
                        'discovery_input':'vm_fs'
                        },
                "item":[
                        {
                            "name":"XMS VDisk UtilRate",
                            'visible':'XMS Disk 사용률',
                            "type":"Util",
                            "item_id":"vnf.fs.util",
                            "data_type":"float",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "unit":"%",
                            "period":PERF_L,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"KT XMS VDisk UtilRate",
                            "plugin":{
                                    'name':'KT XMS VDisk UtilRate', 'type':'file', 
                                    'script': plugDir+'/xms/olleh/xms_plugin.py',
                                    'param_num':'3', 'plugin_param':['disk', 'util'], 'description':'KT XMS VDisk UtilRate',
                                    'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                    'lib_name':'xms_api.py', 'lib_path':'./', 
                                    'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
                                    },
                            "alarm_guide":{'name':'XMS VDisk UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 XMS 클릭하여 Console 접속 후 로그인
3. 파일시스템 사용률 확인: "du -sh /*"
4. 사용량이 많은 파일 용도를 파악하여 불필요할 경우 삭제"""},
                            "threshold":[
                                {
                                    "name":"[Warning] XMS VDisk UtilRate Alarm",
                                    "grade":"warning",
                                    "description":"KT XMS VDisk UtilRate Warning",
                                    "repeat":REAP_L, 
                                    "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                                },
                                {
                                    "name":"[Minor] XMS VDisk UtilRate Alarm",
                                    "grade":"Minor",
                                    "description":"KT XMS VDisk UtilRate Minor",
                                    "repeat":REAP_L, 
                                    "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                                },
                                {
                                    "name":"[Major] XMS VDisk UtilRate Alarm",
                                    "grade":"Major",
                                    "description":"KT VDisk UtilRate Major",
                                    "repeat":REAP_L, 
                                    "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                                },
                                {
                                    "name":"[Critical] XMS VDisk UtilRate Alarm",
                                    "grade":"Critical",
                                    "description":"KT XMS VDisk UtilRate Critical",
                                    "repeat":REAP_L, 
                                    "conditions":{"op":">=", "value":"95"}
                                }
                            ]
                        }
                    ]
                }
                ]
            },
            {'name': 'vproc', 'visible':'가상 프로세스', 'description':'XMS Process Monitor',
            "discovery":[
                {
                "name":"XMS Process Discovery",
                "period":DISC_P,
                "remain":"1",
                "description":"KT XMS Process Discovery",
                "return_field":'NAME',
                "plugin":{
                        'name':'KT XMS Process Discovery', 'type':'file',
                        'script': plugDir+'/xms/olleh/xms_discovery.py',
                        'param_num':'1', 'plugin_param':['PROCLIST'], 'description':'KT XMS VProcess Discovery',
                        'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                        'lib_name':'xms_api.py', 'lib_path':'./', 
                        'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_proc'],
                        'discovery_input':'vm_proc'
                        },
                "item":[
                        {
                            "name":"XMS Process Status",
                            'visible':'XMS 프로세스[PS] 상태',
                            "type":"Status",
                            "item_id":"vnf.proc.status",
                            "data_type":"int",
                            "value_type":"status",
                            "realtime_yn": 'y',
                            "period":STAT_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"KT XMS Process Status",
                            "plugin":{
                                    'name':'KT XMS Process Status', 'type':'file', 
                                    'script': plugDir+'/xms/olleh/xms_plugin.py',
                                    'param_num':'2', 'plugin_param':['proc'], 'description':'KT XMS Process Status',
                                    'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                    'lib_name':'xms_api.py', 'lib_path':'./', 
                                    'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
                                    },
                            "alarm_guide":{'name':'XMS Process Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 XMS 클릭하여 Console 접속 후 로그인
3. 프로세스 상태 확인: "ps -ef | grep -v grep | grep $PROC_NAME"
4. 프로세스 다운 시 해당 프로세스 시작"""},
                            "threshold":[
                                {
                                    "name":"[Critical] XMS Process Status Alarm",
                                    "grade":"Critical",
                                    "description":"KT XMS Process Status Critical",
                                    "repeat":REAP_L, 
                                    "conditions":{"op":"<=", "value":"0"}
                                }
                            ]
                        }
                    ]
                }
                ]
            },
            {'name': 'ap', 'visible':'AP', 'description':'XMS AP Monitor',
                 "item":[
                    {
                        "name":"AP Count",
                        'visible':'AP 대수',
                        "type":"APCount",
                        "item_id":"vnf.spec.ap.total",
                        "realtime_yn": 'y',
                        "data_type":"int",
                        "period":STAT_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"KT XMS AP Count",
                        "plugin":{
                                'name':'KT XMS AP Count', 'type':'file', 
                                'script': plugDir+'/xms/olleh/xms_plugin.py',
                                'param_num':'2', 'plugin_param':['ap', 'total'], 'description':'KT XMS AP Count',
                                'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                'lib_name':'xms_api.py', 'lib_path':'./', 
                                'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'XMS AP Count Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 XMS 클릭하여 WEB 접속 후 로그인
3. 메뉴 "Network Manager"에서 "NMS Dashboard" 선택 후 장애 내역 확인
4. 장애 시, 개발팀 및 XMS 담당자 연락"""}
                    },
                    {
                        "name":"AP Fault Count",
                        'visible':'AP 장애 대수',
                        "type":"APFault",
                        "item_id":"vnf.spec.ap.fault",
                        "realtime_yn": 'y',
                        "data_type":"int",
                        "period":STAT_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"KT XMS AP Fault Count",
                        "plugin":{
                                'name':'KT XMS AP Fault Count', 'type':'file', 
                                'script': plugDir+'/xms/olleh/xms_plugin.py',
                                'param_num':'2', 'plugin_param':['ap', 'fault'], 'description':'KT XMS AP Fault Count',
                                'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                'lib_name':'xms_api.py', 'lib_path':'./', 
                                'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'XMS AP Fault Count Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 XMS 클릭하여 WEB 접속 후 로그인
3. 메뉴 "Network Manager"에서 "NMS Dashboard" 선택 후 장애 내역 확인
4. 장애 시, 개발팀 및 XMS 담당자 연락"""},
                        "threshold":[
                            {
                                "name":"[Critical] XMS AP Fault Alarm",
                                "grade":"Critical",
                                "description":"KT XMS AP Fault",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"1"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'sw', 'visible':'SW', 'description':'XMS SW Monitor',
                 "item":[
                    {
                        "name":"SW Count",
                        'visible':'SW 대수',
                        "type":"SWCount",
                        "item_id":"vnf.spec.sw.total",
                        "realtime_yn": 'y',
                        "data_type":"int",
                        "period":STAT_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"KT XMS SW Count",
                        "plugin":{
                                'name':'KT XMS SW Count', 'type':'file', 
                                'script': plugDir+'/xms/olleh/xms_plugin.py',
                                'param_num':'2', 'plugin_param':['sw', 'total'], 'description':'KT XMS SW Count',
                                'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                'lib_name':'xms_api.py', 'lib_path':'./', 
                                'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'XMS SW Count Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 XMS 클릭하여 WEB 접속 후 로그인
3. 메뉴 "Network Manager"에서 "NMS Dashboard" 선택 후 장애 내역 확인
4. 장애 시, 개발팀 및 XMS 담당자 연락"""}
                    },
                    {
                        "name":"SW Fault Count",
                        'visible':'SW 장애 대수',
                        "type":"SWFault",
                        "item_id":"vnf.spec.sw.fault",
                        "realtime_yn": 'y',
                        "data_type":"int",
                        "period":STAT_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"KT XMS SW Fault Count",
                        "plugin":{
                                'name':'KT XMS SW Fault Count', 'type':'file', 
                                'script': plugDir+'/xms/olleh/xms_plugin.py',
                                'param_num':'2', 'plugin_param':['sw', 'fault'], 'description':'KT XMS SW Fault Count',
                                'lib_type':'file', 'lib_script':plugDir+'/xms/olleh/xms_api.py',
                                'lib_name':'xms_api.py', 'lib_path':'./', 
                                'cfg_name':'xms_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'XMS SW Fault Count Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 XMS 클릭하여 WEB 접속 후 로그인
3. 메뉴 "Network Manager"에서 "NMS Dashboard" 선택 후 장애 내역 확인
4. 장애 시, 개발팀 및 XMS 담당자 연락"""},
                        "threshold":[
                            {
                                "name":"[Critical] XMS SW Fault Alarm",
                                "grade":"Critical",
                                "description":"KT XMS SW Fault",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"1"}
                            }
                        ]
                    }
                ]
            }
        ]
    }
    
    return body


