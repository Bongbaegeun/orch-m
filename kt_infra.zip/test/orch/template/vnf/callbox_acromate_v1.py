#-*- coding: utf-8 -*-
TTYPE = "PBX"
VENDER = "ACROMATE"
MODEL_LIST = ['v1.0']

def chkParam( params ):
    if params == None or len(params) < 1 :
        return '[ERROR] No Param, Params: 1. ModelType=%s'%str(MODEL_LIST)
    elif len(params) !=1 :
        return '[ERROR] Invalid Para -> %s, Params: ModelType'%str(params)
    
    p1 = str(params[0])
    if not p1 in MODEL_LIST :
        return '[ERROR] Unknown Model Type -> %s, Supported Model=%s'%(str(p1), str(MODEL_LIST))
    
    return None

def makeBody(_type, params, plugDir, HIST="10", TRND="180"):
    ret = chkParam(params)
    if ret != None :
        print ret
        return

    mType = params[0]
    
    REAP_H = '1'
    REAP_M = '1'
    REAP_L = '1'
    DISC_P = '300'
    if _type == 'REAL':
        STAT_H = "30"
        STAT_M = "60"
        STAT_L = "120"
        PERF_H = "60"
        PERF_M = "300"
        PERF_L = "600"
        REAP_H = '3'
        REAP_M = '2'
        REAP_L = '1'
    elif _type == 'TEST':
        STAT_H = "10"
        STAT_M = "30"
        STAT_L = "60"
        PERF_H = "30"
        PERF_M = "60"
        PERF_L = "120"
        DISC_P = "120"
    elif _type == 'SHOW' :
        STAT_H = "2"
        STAT_M = "10"
        STAT_L = "30"
        PERF_H = "10"
        PERF_M = "30"
        PERF_L = "60"
        DISC_P = "60"
    else:
        print "Invalid Template Type -> %s, Supported Type=[REAL, TEST, SHOW]"
        return

    print '=======>> Creating VNF:%s:%s:%s:%s Template'%(TTYPE, VENDER, mType, _type)
    
    body = {
        "tid":'temp-create-1',
        "target_info":{
                'code':'vnf', 'type':'PBX', "name":"VNF-CALLBOX", 'visible':'CALLBOX [VNF]', 'model':mType,
                'vendor_code':'acromate', "description":"ACROMATE CALLBOX %s Monitoring"%mType, 
                'version':'v1.0', 'target_for':'Provisioning'
                },
        "group":[
            {'name': 'openstack-vinfra-status', 'visible':'가상자원 상태', 'description':'OpenStack VirtualInfra Status Monitor',
            "discovery":[
                    {
                    "name":"VM Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OpenStack VM Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OpenStack VM Discovery',
							'type':'file',
                            'script': plugDir+'/vim/openstack_prov/nova_discovery.py',
                            'param_num':'0',
							'description':'OpenStack VM Discovery',
                            'lib_type':'file',
							'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                            'lib_name':'vim_api.py',
							'lib_path':'./', 
                            'cfg_name':'nova_cfg.yaml',
							'cfg_path':'./',
							'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_vm"],
                            'discovery_input':'vim_vm'
                            },
                    "item":[
                            {
                                "name":"CALLBOX VM Status",
                                'visible':'CALLBOX VM 상태',
                                "type":"CALLBOX VM Status",
                                "item_id":"vim.osp.status.vm",
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_L,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"OpenStack VM status",
                                "plugin":{
                                        'name':'OpenStack VM Status', 
										'type':'file', 
                                        'script': plugDir+'/vim/openstack_prov/vm-status.sh',
                                        'param_num':'1',
										'description':'OpenStack VM Status'
                                        },
                                "alarm_guide":{'name':'CALLBOX VM Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. VM 상태 확인: "nova list"
4. 다운 상태일 경우, VM 기동: "nova start $VM_NAME"
5. 장애 시, 오픈스택 관리자에게 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] CALLBOX VM Status Down Alarm",
                                        "grade":"critical",
                                        "description":"OpenStack CALLBOX VM Status Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    },
                    {
                    "name":"VPort Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OpenStack VPort Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OpenStack VPort Discovery', 
							'type':'file', 
                            'script': plugDir+'/vim/openstack_prov/neutron_discovery_prov.py',
                            'param_num':'1', 
							'plugin_param':['PORT'], 
							'description':'OpenStack VPort Discovery',
                            'lib_type':'file',
							'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                            'lib_name':'vim_api.py', 
							'lib_path':'./', 
                            'cfg_name':'neutron_prov_cfg.yaml', 
							'cfg_path':'./', 
							'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain', 'vim_port'],
                            'discovery_input':'vim_port'
                            },
                    "item":[
                            {
                                "name":"CALLBOX VPort Status",
                                'visible':'CALLBOX 가상 Port 상태',
                                "type":"CALLBOX VPort Status",
                                "item_id":"vim.osp.status.vport",
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_L,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"OpenStack VPort status",
                                "plugin":{
                                        'name':'openstack vrouter status', 
										'type':'file',
                                        'script': plugDir+'/vim/openstack_prov/vport-status.sh',
                                        'param_num':'1', 
										'description':'OpenStack VPort Status'
                                        },
                                "alarm_guide":{'name':'CALLBOX VPort Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 가상 Port 상태 확인: "neutron port-list -c name -c fixed_ips -c status"
4. 장애 시, 오픈스택 관리자에게 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] CALLBOX VPort Status Down Alarm",
                                        "grade":"critical",
                                        "description":"OpenStack CALLBOX VPort Status Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    }
                ]## discovery
            },
			
			
			#vCALLBOX 모니터
            {'name': 'vcpu', 'visible':'가상 CPU', 'description':'VCPU Monitor',
                 "item":[
                    {
                        "name":"CALLBOX VCPU Util",
                        'visible':'CALLBOX 가상 CPU 사용률',
                        "type":"Util",
                        "item_id":"vnf.cpu.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"CALLBOX VCPU Util",
                        "plugin":{
                                'name':'CALLBOX CPU Util', 
								'type':'file', 
                                'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                                'param_num':'1', 
								'plugin_param':['cpu'], 
								'description':'CALLBOX CPU Util',
                                'lib_type':'file',
								'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                                'lib_name':'callbox_api.py', 
								'lib_path':'./', 
                                'cfg_name':'callbox_cfg.yaml',
								'cfg_path':'./', 
								'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'CALLBOX VCPU Util Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 CALLBOX 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
                        "threshold":[
                            {
                                "name":"[Warning] CALLBOX VCPU Util Alarm",
                                "grade":"warning",
                                "description":"CALLBOX VCPU Util Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] CALLBOX VCPU Util Alarm",
                                "grade":"minor",
                                "description":"CALLBOX VCPU Util Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] CALLBOX VCPU Util Alarm",
                                "grade":"major",
                                "description":"CALLBOX VCPU Util Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] CALLBOX VCPU Util Alarm",
                                "grade":"Critical",
                                "description":"CALLBOX VCPU Util Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    },
                    
                    {
                        "name":"CALLBOX VCPU Load",
                        'visible':'CALLBOX 가상 CPU 부하',
                        "type":"Load",
                        "item_id":"vnf.cpu.load",
                        "graph_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"job",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"CALLBOX UTM VCPU Load",
                        "plugin":{
                                'name':'CALLBOX CPU Load', 
								'type':'file', 
                                'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                                'param_num':'1', 
								'plugin_param':['cpuLoad'], 
								'description':'CALLBOX CPU Load',
                                'lib_type':'file',
								'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                                'lib_name':'callbox_api.py', 
								'lib_path':'./', 
                                'cfg_name':'callbox_cfg.yaml',
								'cfg_path':'./', 
								'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM VCPU Load Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""}
                    },                    
                ]
            },
            {'name': 'vmem', 'visible':'가상 메모리', 'description':'VMemory Monitor',
                 "item":[
                    {
                        "name":"CALLBOX VMEM UtilRate",
                        'visible':'CALLBOX 가상 메모리 사용률',
                        "type":"Util",
                        "item_id":"vnf.mem.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"CALLBOX Memory UtilRate",
                        "plugin":{
                                'name':'CALLBOX Memory UtilRate',
								'type':'file', 
                                'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                                'param_num':'1', 
								'plugin_param':['mem'],
								'description':'CALLBOX Memory UtilRate',
                                'lib_type':'file',
								'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                                'lib_name':'callbox_api.py',
								'lib_path':'./', 
                                'cfg_name':'callbox_cfg.yaml', 
								'cfg_path':'./', 
								'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'CALLBOX VMem UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 CALLBOX 클릭하여 Console 접속 후 로그인
3. 메모리 사용이 많은 프로세스 확인: "ps -aux --sort -rss | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
                        "threshold":[
                            {
                                "name":"[Warning] CALLBOX VMem UtilRate Alarm",
                                "grade":"warning",
                                "description":"CALLBOX VMem UtilRate Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] CALLBOX VMem UtilRate Alarm",
                                "grade":"Minor",
                                "description":"CALLBOX VMem UtilRate Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] CALLBOX VMem UtilRate Alarm",
                                "grade":"Major",
                                "description":"CALLBOX VMem UtilRate Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] CALLBOX VMem UtilRate Alarm",
                                "grade":"Critical",
                                "description":" CALLBOX VMem UtilRate Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },

            {'name': 'callbox', 'visible':'callbox 모니터 ', 'description':'callbox 모니터',
             "item":[
                {
                    "name":"CALLBOX Job status",
                    'visible':'CALLBOX 프로세스 상태  확인',
                    "type":"jobstatus",
                    "item_id":"vnf.spec.job.status",
                    "graph_yn": 'y',
                    "realtime_yn": 'y',                    
                    "data_type":"int",
                    "value_type":"status",                    
                    "period":STAT_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"CALLBOX Job status",
                    "plugin":{
                            'name':'CALLBOX Job status',
							'type':'file', 
                            'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                            'param_num':'1',
							'plugin_param':['pbxJobStatus'], 
							'description':'CALLBOX Job status',
                            'lib_type':'file',
							'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                            'lib_name':'callbox_api.py', 
							'lib_path':'./', 
                            'cfg_name':'callbox_cfg.yaml', 
							'cfg_path':'./', 
							'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'CALLBOX Job status alarm', 'guide':"""1. 장애 시, CALLBOX 담당자 연락"""},
                    "threshold":[
                        {
                            "name":"[Critical] Job status alarm",
                            "grade":"critical",
                            "description":"Job status Critical",
                            "repeat":REAP_H, 
                            "conditions":{"op":"<=", "value":"0"}
                        }
                    ]
                },
                {
                    "name":"CALLBOX Current Call",
                    'visible':'CALLBOX 현재 통화중인 Call 수',
                    "type":"currentcall",
                    "item_id":"vnf.call.amount",
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"CALLBOX Current Call",
                    "plugin":{
                            'name':'CALLBOX Current Call',
							'type':'file', 
                            'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                            'param_num':'1',
							'plugin_param':['pbxCurrentCall'], 
							'description':'CALLBOX Current Call',
                            'lib_type':'file',
							'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                            'lib_name':'callbox_api.py', 
							'lib_path':'./', 
                            'cfg_name':'callbox_cfg.yaml', 
							'cfg_path':'./', 
							'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'CALLBOX  Current call alarm', 'guide':"""1. 장애 시, CALLBOX 담당자 연락"""},
                },
                {
                    "name":"CALLBOX Register inner phone count",
                    'visible':'CALLBOX 연결된 내선 전화기 대수',
                    "type":"PhoneCount",
                    "item_id":"vnf.phone.amount",
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"CALLBOX Register inner phone count",
                    "plugin":{
                            'name':'CALLBOX Register inner phone count',
							'type':'file', 
                            'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                            'param_num':'1',
							'plugin_param':['pbxRegiPhoneCnt'], 
							'description':'CALLBOX Register Inner Phone Count',
                            'lib_type':'file',
							'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                            'lib_name':'callbox_api.py', 
							'lib_path':'./', 
                            'cfg_name':'callbox_cfg.yaml', 
							'cfg_path':'./', 
							'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'CALLBOX Register inner phone count alarm', 'guide':"""1. 장애 시, CALLBOX 담당자 연락"""},
                },
                {
                    "name":"CALLBOX Phone number count",
                    'visible':'CALLBOX 생성된 전화번호 수',
                    "type":"NumberCount",
                    "item_id":"vnf.phone.number.total",
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"CALLBOX Phone number count",
                    "plugin":{
                            'name':'CALLBOX Phone number count',
							'type':'file', 
                            'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                            'param_num':'1',
							'plugin_param':['pbxPhoneNumberCnt'], 
							'description':'CALLBOX Phone Number Count',
                            'lib_type':'file',
							'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                            'lib_name':'callbox_api.py', 
							'lib_path':'./', 
                            'cfg_name':'callbox_cfg.yaml', 
							'cfg_path':'./', 
							'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'CALLBOX Phone number count alarm', 'guide':"""1. 장애 시, CALLBOX 담당자 연락"""},
                },
                {
                    "name":"CALLBOX Call 5 minute total count",
                    'visible':'CALLBOX 5분간 전체 Call 수',
                    "type":"5minTotalCount",
                    "item_id":"vnf.call.5min.total",
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"CALLBOX Call 5 minute total count",
                    "plugin":{
                            'name':'CALLBOX Call 5 minute total count',
							'type':'file', 
                            'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                            'param_num':'1',
							'plugin_param':['pbxCall5minTotal'], 
							'description':'CALLBOX Call 5 minute total count',
                            'lib_type':'file',
							'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                            'lib_name':'callbox_api.py', 
							'lib_path':'./', 
                            'cfg_name':'callbox_cfg.yaml', 
							'cfg_path':'./', 
							'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'CALLBOX Call 5 minute total count alarm', 'guide':"""1. 장애 시, CALLBOX 담당자 연락"""},
                },
                {
                    "name":"CALLBOX Call 5 minute success count",
                    'visible':'CALLBOX 5분간 통화성공 Call 수',
                    "type":"5minSuccCount",
                    "item_id":"vnf.call.5min.success",
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"CALLBOX Call 5 minute success count",
                    "plugin":{
                            'name':'CALLBOX Call 5 minute success count',
							'type':'file', 
                            'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                            'param_num':'1',
							'plugin_param':['pbxCall5minSuccess'], 
							'description':'CALLBOX Call 5 minute success count',
                            'lib_type':'file',
							'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                            'lib_name':'callbox_api.py', 
							'lib_path':'./', 
                            'cfg_name':'callbox_cfg.yaml', 
							'cfg_path':'./', 
							'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'CALLBOX Call 5 minute success count alarm', 'guide':"""1. 장애 시, CALLBOX 담당자 연락"""},
                },
                {
                    "name":"CALLBOX Biz Connection",
                    'visible':'CALLBOX 기업망 호처리 등록 상태',
                    "type":"BizConnect",
                    "item_id":"vnf.biz.conn.status",
                    "graph_yn": 'y',
                    "realtime_yn": 'y',                    
                    "data_type":"int",
                    "value_type":"status",
                    "period":STAT_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"CALLBOX Biz Connection Status",
                    "plugin":{
                            'name':'CALLBOX Biz Connection',
							'type':'file', 
                            'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                            'param_num':'1',
							'plugin_param':['pbxBizConnStatus'], 
							'description':'CALLBOX Biz Connection Status',
                            'lib_type':'file',
							'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                            'lib_name':'callbox_api.py', 
							'lib_path':'./', 
                            'cfg_name':'callbox_cfg.yaml', 
							'cfg_path':'./', 
							'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'CALLBOX Biz Connection Alarm', 'guide':"""1. 장애 시, CALLBOX 담당자 연락"""},
                    "threshold":[
                        {
                            "name":"[Critical] CALLBOX Biz Connection Alarm",
                            "grade":"critical",
                            "description":"CALLBOX Biz Connection Critical",
                            "repeat":REAP_H, 
                            "conditions":{"op":"<=", "value":"0"}
                        }
                    ]
                }
                ]
            },


            {'name': 'vnet', 'visible':'가상 네트워크', 'description':'VNetwork Monitor',
            "discovery":[
                {
                "name":"CALLBOX VNet Discovery",
                "period":DISC_P,
                "remain":"1",
                "description":"CALLBOX VNet Discovery",
                "return_field":'NAME',
                "plugin":{
                        'name':'CALLBOX VNet Discovery', 
						'type':'file',
                        'script': plugDir+'/pbx/acromate/callbox_discovery.py',
                        'param_num':'1', 
						'plugin_param':['NETLIST'],
						'description':'CALLBOX VNet Discovery',
                        'lib_type':'file',
						'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                        'lib_name':'callbox_api.py', 
						'lib_path':'./', 
                        'cfg_name':'callbox_cfg.yaml', 
						'cfg_path':'./', 
						'cfg_input':['vm_id', 'vm_passwd', 'vm_ip', 'vm_net'],
                        'discovery_input':'vm_net'
                        },
                "item":[
                        {
                            "name":"CALLBOX VNet I/F Status",
                            'visible':'CALLBOX 네트워크 상태',
                            "type":"Status",
                            "item_id":"vnf.net.if.status",
                            "data_type":"int",
                            "value_type":"status",
                            "period":STAT_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"CALLBOX Network I/F Status",
                            "plugin":{
                                    'name':'CALLBOX Network I/F Status', 
									'type':'file', 
                                    'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                                    'param_num':'2', 
									'plugin_param':['netstatus'], 
									'description':'CALLBOX Network I/F Status',
                                    'lib_type':'file',
									'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                                    'lib_name':'callbox_api.py',
									'lib_path':'./', 
                                    'cfg_name':'callbox_cfg.yaml', 
									'cfg_path':'./', 
									'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'CALLBOX VNet I/F Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 CALLBOX 클릭하여 Console 접속 후 로그인
3. NIC 상태 확인: "ethtool $IF_NAME"
4. 장애 시, 개발팀 연락"""},
                            "threshold":[
                                {
                                    "name":"[Critical] CALLBOX VNet I/F Status Down",
                                    "grade":"critical",
                                    "description":"CALLBOX VNet I/F Status Down",
                                    "repeat":REAP_L, 
                                    "conditions":{"op":"<=", "value":"0"}
                                }
                            ]
                        },
                        {
                            "name":"CALLBOX VNet Rx_Rate",
                            'visible':'CALLBOX 네트워크 RxRate',
                            "type":"Rx Rate",
                            "item_id":"vnf.net.if.rx_rate",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "data_type":"int",
                            "unit":"bps",
                            "period":PERF_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"CALLBOX Network Rx_Rate",
                            "plugin":{
                                    'name':'CALLBOX Network Rx_Rate', 'type':'file', 
                                    'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                                    'param_num':'3', 
                                    'plugin_param':['traffic', 'rx_rate'], 
                                    'description':'CALLBOX Network Rx_Rate',
                                    'lib_type':'file', 
                                    'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                                    'lib_name':'callbox_api.py', 
                                    'lib_path':'./', 
                                    'cfg_name':'callbox_cfg.yaml', 
                                    'cfg_path':'./', 
                                    'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'CALLBOX VNet Rx_Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 CALLBOX 클릭하여 Console 접속 후 로그인
3. RX 대역폭 확인: "ifstat -i $IF_NAME"
4. 장애 시, 개발팀과 CALLBOX 담당자에게 연락"""},
                            "threshold":[
                                {
                                    "name":"[Warning] CALLBOX VNet Rx_Rate Alarm",
                                    "grade":"warning",
                                    "description":"CALLBOX VNet Rx_Rate Warning",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"500000000"},{"op":"<", "value":"600000000"}]
                                },
                                {
                                    "name":"[Minor] CALLBOX VNet Rx_Rate Alarm",
                                    "grade":"Minor",
                                    "description":"CALLBOX VNet Rx_Rate Minor",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"600000000"},{"op":"<", "value":"650000000"}]
                                },
                                {
                                    "name":"[Major] CALLBOX VNet Rx_Rate Alarm",
                                    "grade":"Major",
                                    "description":"VNet Rx_Rate Major",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"650000000"},{"op":"<", "value":"700000000"}]
                                },
                                {
                                    "name":"[Critical] CALLBOX VNet Rx_Rate Alarm",
                                    "grade":"Critical",
                                    "description":"CALLBOX VNet Rx_Rate Critical",
                                    "repeat":REAP_M, 
                                    "conditions":{"op":">=", "value":"700000000"}
                                }
                            ]
                        },
                        {
                            "name":"CALLBOX VNet Tx_Rate",
                            'visible':'CALLBOX 네트워크 TxRate',
                            "type":"Tx Rate",
                            "item_id":"vnf.net.if.tx_rate",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "data_type":"int",
                            "unit":"bps",
                            "period":PERF_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"CALLBOX Network Tx_Rate",
                            "plugin":{
                                    'name':'CALLBOX Network Tx_Rate',
									'type':'file', 
                                    'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                                    'param_num':'3',
									'plugin_param':['traffic', 'tx_rate'],
									'description':'CALLBOX Network Tx_Rate',
                                    'lib_type':'file', 
									'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                                    'lib_name':'callbox_api.py',
									'lib_path':'./', 
                                    'cfg_name':'callbox_cfg.yaml',
									'cfg_path':'./',
									'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'CALLBOX VNet Tx_Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 CALLBOX 클릭하여 Console 접속 후 로그인
3. TX 대역폭 확인: "ifstat -i $IF_NAME"
4. 장애 시, 개발팀과 CALLBOX 담당자에게 연락"""},
                            "threshold":[
                                {
                                    "name":"[Warning] CALLBOX VNet Tx_Rate Alarm",
                                    "grade":"warning",
                                    "description":"CALLBOX VNet Tx_Rate Warning",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"500000000"},{"op":"<", "value":"600000000"}]
                                },
                                {
                                    "name":"[Minor] CALLBOX VNet Tx_Rate Alarm",
                                    "grade":"Minor",
                                    "description":"CALLBOX VNet Tx_Rate Minor",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"600000000"},{"op":"<", "value":"650000000"}]
                                },
                                {
                                    "name":"[Major] CALLBOX VNet Tx_Rate Alarm",
                                    "grade":"Major",
                                    "description":"VNet Tx_Rate Major",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"650000000"},{"op":"<", "value":"700000000"}]
                                },
                                {
                                    "name":"[Critical] CALLBOX VNet Tx_Rate Alarm",
                                    "grade":"Critical",
                                    "description":"CALLBOX VNet Tx_Rate Critical",
                                    "repeat":REAP_M, 
                                    "conditions":{"op":">=", "value":"700000000"}
                                }
                            ]
                        }
                    ]
                }
                ]
            },
            {'name': 'vdisk', 'visible':'가상 Disk', 'description':'VDisk Monitor',
             "item":[
                    {
                        "name":"CALLBOX VDisk UtilRate",
                        'visible':'CALLBOX Disk 사용률',
                        "type":"Util",
                        "item_id":"vnf.fs.util",
                        "data_type":"float",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"CALLBOX VDisk UtilRate",
                        "plugin":{
                                'name':'CALLBOX VDisk UtilRate',
								'type':'file', 
                                'script': plugDir+'/pbx/acromate/callbox_plugin.py',
                                'param_num':'1',
								'plugin_param':['disk'], 
								'description':'CALLBOX VDisk UtilRate',
                                'lib_type':'file', 
								'lib_script':plugDir+'/pbx/acromate/callbox_api.py',
                                'lib_name':'callbox_api.py', 
								'lib_path':'./', 
                                'cfg_name':'callbox_cfg.yaml', 
								'cfg_path':'./', 
								'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'CALLBOX VDisk UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 CALLBOX 클릭하여 Console 접속 후 로그인
3. 파일시스템 사용률 확인: "du -sh /*"
4. 사용량이 많은 파일 용도를 파악하여 불필요할 경우 삭제"""},
                        "threshold":[
                            {
                                "name":"[Warning] CALLBOX VDisk UtilRate Alarm",
                                "grade":"warning",
                                "description":"CALLBOX VDisk UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] CALLBOX VDisk UtilRate Alarm",
                                "grade":"Minor",
                                "description":"CALLBOX VDisk UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] CALLBOX VDisk UtilRate Alarm",
                                "grade":"Major",
                                "description":"VDisk UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] CALLBOX VDisk UtilRate Alarm",
                                "grade":"Critical",
                                "description":"CALLBOX VDisk UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            }
           
        ]
    }
    
    return body