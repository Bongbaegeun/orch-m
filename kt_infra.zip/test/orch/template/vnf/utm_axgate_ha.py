#-*- coding: utf-8 -*-

TTYPE = "UTM"
VENDER = "AXGATE"
MODEL_LIST = ['v1.0', 'v1.2', 'v1.3']

def chkParam( params ):
    if params == None or len(params) < 1 :
        return '[ERROR] No Param, Params: 1. ModelType=%s'%str(MODEL_LIST)
    elif len(params) !=1 :
        return '[ERROR] Invalid Para -> %s, Params: ModelType'%str(params)
    
    p1 = str(params[0])
    if not p1 in MODEL_LIST :
        return '[ERROR] Unknown Model Type -> %s, Supported Model=%s'%(str(p1), str(MODEL_LIST))
    
    return None

def makeBody(_type, params, plugDir, HIST="10", TRND="180"):
    ret = chkParam(params)
    if ret != None :
        print ret
        return

    mType = params[0]
    
    REAP_H = '1'
    REAP_M = '1'
    REAP_L = '1'
    DISC_P = '300'
    
    if _type == 'REAL':
        STAT_H = "30"
        STAT_M = "60"
        STAT_L = "120"
        PERF_H = "60"
        PERF_M = "300"
        PERF_L = "600"
        REAP_H = '3'
        REAP_M = '2'
        REAP_L = '1'
        
    elif _type == 'TEST':
        STAT_H = "10"
        STAT_M = "30"
        STAT_L = "60"
        PERF_H = "30"
        PERF_M = "60"
        PERF_L = "120"
        DISC_P = "120"
        
    elif _type == 'SHOW' :
        STAT_H = "2"
        STAT_M = "10"
        STAT_L = "30"
        PERF_H = "10"
        PERF_M = "30"
        PERF_L = "60"
        DISC_P = "60"
    else:
        print "Invalid Template Type -> %s, Supported Type=[REAL, TEST, SHOW]"
        return

    print '=======>> Creating VNF:%s:%s:%s:%s Template'%(TTYPE, VENDER, mType, _type)
    
    body = {
        "tid":'temp-create-1',
        "target_info":{
                'code':'vnf', 'type':'UTM', "name":"VNF-AXGATE UTM", 'visible':'AXGATE UTM[VNF]', 'model':mType,
                'vendor_code':'axgate', "description":"AXGATE UTM %s Monitoring"%mType, 
                'version':'v1.0', 'target_for':'Provisioning'
                },
        "group":[
            {'name': 'openstack-vinfra-status', 'visible':'가상자원 상태', 'description':'OpenStack VirtualInfra Status Monitor',
            "discovery":[
                    {
                    "name":"VM Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OpenStack VM Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OpenStack VM Discovery', 'type':'file',
                            'script': plugDir+'/vim/openstack_prov/nova_discovery.py',
                            'param_num':'0',
                            'description':'OpenStack VM Discovery',
                            'lib_type':'file',
                            'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                            'lib_name':'vim_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'nova_cfg.yaml',
                            'cfg_path':'./', 
                            'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_vm"],
                            'discovery_input':'vim_vm'
                            },
                    "item":[
                            {
                                "name":"UTM VM Status",
                                'visible':'VM 상태',
                                "type":"VM Status",
                                "item_id":"vim.osp.status.vm",
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_L,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"OpenStack VM status",
                                "plugin":{
                                        'name':'OpenStack VM Status',
                                        'type':'file', 
                                        'script': plugDir+'/vim/openstack_prov/vm-status.sh',
                                        'param_num':'1',
                                        'description':'OpenStack VM Status'
                                        },
                                "alarm_guide":{'name':'UTM VM Status Alarm', 
                                'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. VM 상태 확인: "nova list"
4. 다운 상태일 경우, VM 기동: "nova start $VM_NAME"
5. 장애 시, 오픈스택 관리자에게 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] UTM VM Status Down Alarm",
                                        "grade":"critical",
                                        "description":"OpenStack UTM VM Status Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    },
                    {
                    "name":"VPort Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OpenStack VPort Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OpenStack VPort Discovery',
                            'type':'file', 
                            'script': plugDir+'/vim/openstack_prov/neutron_discovery_prov.py',
                            'param_num':'1',
                            'plugin_param':['PORT'], 'description':'OpenStack VPort Discovery',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                            'lib_name':'vim_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'neutron_prov_cfg.yaml',
                            'cfg_path':'./',
                            'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain', 'vim_port'],
                            'discovery_input':'vim_port'
                            },
                    "item":[
                            {
                                "name":"UTM VPort Status",
                                'visible':'가상 Port 상태',
                                "type":"VPort Status",
                                "item_id":"vim.osp.status.vport",
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_L,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"OpenStack VPort status",
                                "plugin":{
                                        'name':'openstack vrouter status',
                                        'type':'file',
                                        'script': plugDir+'/vim/openstack_prov/vport-status.sh',
                                        'param_num':'1',
                                        'description':'OpenStack VPort Status'
                                        },
                                "alarm_guide":{'name':'UTM VPort Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 가상 Port 상태 확인: "neutron port-list -c name -c fixed_ips -c status"
4. 장애 시, 오픈스택 관리자에게 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] UTM VPort Status Down Alarm",
                                        "grade":"critical",
                                        "description":"OpenStack UTM VPort Status Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    }
                ]## discovery
            },
            
            {'name': 'vcpu', 'visible':'가상 CPU', 'description':'UTM VCPU Monitor',
                 "item":[
                    {
                        "name":"VCPU Load",
                        'visible':'가상 CPU 부하',
                        "type":"Load",
                        "item_id":"vnf.cpu.load",
                        "graph_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"job",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM VCPU Load",
                        "plugin":{
                                'name':'AXGATE UTM CPU Load',
                                'type':'file', 
                                'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                'param_num':'1',
                                'plugin_param':['cpuload'],
                                'description':'AXGATE UTM CPU Load',
                                'lib_type':'file', 'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                'lib_name':'axgate_api.py', 'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM VCPU Load Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""}
                    },
                    {
                        "name":"VCPU Util",
                        'visible':'가상 CPU 사용률',
                        "type":"Util",
                        "item_id":"vnf.cpu.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM VCPU Util",
                        "plugin":{
                                'name':'AXGATE UTM CPU Util',
                                'type':'file', 
                                'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                'param_num':'1',
                                'plugin_param':['cpuutil'],
                                'description':'AXGATE UTM CPU Util',
                                'lib_type':'file',
                                'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                'lib_name':'axgate_api.py',
                                'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml',
                                'cfg_path':'./',
                                'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM VCPU Util Alarm',
                        'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
                        "threshold":[
                            {
                                "name":"[Warning] UTM VCPU Util Alarm",
                                "grade":"warning",
                                "description":"AXGATE UTM VCPU Util Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] UTM VCPU Util Alarm",
                                "grade":"minor",
                                "description":"AXGATE UTM VCPU Util Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] UTM VCPU Util Alarm",
                                "grade":"major",
                                "description":"AXGATE UTM VCPU Util Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] UTM VCPU Util Alarm",
                                "grade":"Critical",
                                "description":"AXGATE UTM VCPU Util Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'vmem', 'visible':'가상 메모리', 'description':'UTM VMemory Monitor',
                 "item":[
                    {
                        "name":"VMEM UtilRate",
                        'visible':'가상 메모리 사용률',
                        "type":"Util",
                        "item_id":"vnf.mem.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM Memory UtilRate",
                        "plugin":{
                                'name':'AXGATE UTM Memory UtilRate', 'type':'file', 
                                'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                'param_num':'1', 
                                'plugin_param':['mem'], 
                                'description':'AXGATE UTM Memory UtilRate',
                                'lib_type':'file', 
                                'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                'lib_name':'axgate_api.py', 
                                'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml', 
                                'cfg_path':'./', 
                                'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM VMem UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. 메모리 사용이 많은 프로세스 확인: "ps -aux --sort -rss | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
                        "threshold":[
                            {
                                "name":"[Warning] UTM VMem UtilRate Alarm",
                                "grade":"warning",
                                "description":"AXGATE UTM VMem UtilRate Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] UTM VMem UtilRate Alarm",
                                "grade":"Minor",
                                "description":"AXGATE UTM VMem UtilRate Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] UTM VMem UtilRate Alarm",
                                "grade":"Major",
                                "description":"AXGATE UTM VMem UtilRate Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] UTM VMem UtilRate Alarm",
                                "grade":"Critical",
                                "description":"AXGATE UTM VMem UtilRate Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            
            {'name': 'vnet', 'visible':'가상 네트워크', 'description':'UTM VNetwork Monitor',
             "item":[
                {
                    "name":"UTM ConnTrack",
                    'visible':'UTM ConnTrack',
                    "type":"ConnTrack",
                    "item_id":"vnf.spec.conntrack",
                    "graph_yn": 'y',
                    "realtime_yn": 'y',
                    "statistic_yn": 'y',
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM Network ConnTrack",
                    "plugin":{
                            'name':'AXGATE UTM Network ConnTrack', 
                            'type':'file', 
                            'script': plugDir+'/utm/axgate/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['conntrack'],
                            'description':'AXGATE UTM Network ConnTrack',
                            'lib_type':'file',
                            'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                            'lib_name':'axgate_api.py',
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml',
                            'cfg_path':'./', 'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                            },
                    "alarm_guide":{'name':'UTM VNet ConnTrack Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""}
                },
                
                
                {
                    "name":"UTM VPN Count",
                    'visible':'UTM VPN 전체 세션수',
                    "type":"VPNCount",
                    "item_id":"vnf.net.vpn.count",
                    "graph_yn": 'y',
                    "realtime_yn": 'y',
                    "statistic_yn": 'y',
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM VPN Count",
                    "plugin":{
                            'name':'AXGATE UTM VPN Count', 
                            'type':'file', 
                            'script': plugDir+'/utm/axgate/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['vpncount'],
                            'description':'AXGATE UTM VPN Count',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                            'lib_name':'axgate_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml', 
                            'cfg_path':'./', 
                            'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'AXGATE UTM VPN Count Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""},
                },                
                
                {
                    "name":"UTM VPN Total Tunnel",
                    'visible':'UTM VPN Total 터널수',
                    "type":"VPN_TotalTunnel",
                    "item_id":"vnf.net.vpn.totaltunnel",
                    "graph_yn": 'y',
                    "realtime_yn": 'y',
                    "statistic_yn": 'y',
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM VPN Total Tunnel",
                    "plugin":{
                            'name':'AXGATE UTM VPN Total Tunnel', 
                            'type':'file', 
                            'script': plugDir+'/utm/axgate/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['vpn_totalcount'],
                            'description':'AXGATE UTM VPN Total Tunnel',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                            'lib_name':'axgate_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml', 
                            'cfg_path':'./', 
                            'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'AXGATE UTM VPN Total Tunnel Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""},
                },                

                {
                    "name":"UTM VPN Active Tunnel",
                    'visible':'UTM VPN Active 터널수',
                    "type":"VPN_ActiveTunnel",
                    "item_id":"vnf.net.vpn.activetunnel",
                    "graph_yn": 'y',
                    "realtime_yn": 'y',
                    "statistic_yn": 'y',
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM VPN Active Tunnel",
                    "plugin":{
                            'name':'AXGATE UTM VPN Active Tunnel', 
                            'type':'file', 
                            'script': plugDir+'/utm/axgate/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['vpn_activecount'],
                            'description':'AXGATE UTM VPN Active Tunnel',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                            'lib_name':'axgate_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml', 
                            'cfg_path':'./', 
                            'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'AXGATE UTM VPN Active Tunnel Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""},
                },                
                
                {
                    "name":"UTM Connection",
                    'visible':'UTM 연결상태',
                    "type":"Connection",
                    "item_id":"vnf.net.conn.vm",
                    "data_type":"int",
                    "value_type":"status",
                    "period":STAT_H,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM Connection Check",
                    "plugin":{
                            'name':'AXGATE UTM Connection', 
                            'type':'file', 
                            'script': plugDir+'/utm/axgate/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['connection'],
                            'description':'AXGATE UTM Connection Check',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                            'lib_name':'axgate_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml', 
                            'cfg_path':'./', 
                            'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'UTM Connection Alarm', 
                    'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. UTM Public IP의 Ping 확인: "ping $UTM_PUBLIC_IP"
4. 장애 시, 개발팀 및 오픈스택 담당자 연락"""},
                    "threshold":[
                        {
                            "name":"[Critical] UTM Connection Alarm",
                            "grade":"critical",
                            "description":"AXGATE UTM Connection Critical",
                            "repeat":REAP_H, 
                            "conditions":{"op":"<=", "value":"0"}
                        }
                    ]
                },
                {
                    "name":"UTM Internet Connection",
                    'visible':'UTM 인터넷 연결상태',
                    "type":"InterConnection",
                    "item_id":"vnf.spec.internet_conn",
                    "data_type":"int",
                    "value_type":"status",
                    "period":STAT_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM Internet Connection Check",
                    "plugin":{
                            'name':'AXGATE UTM Internet Connection',
                            'type':'file', 
                            'script': plugDir+'/utm/axgate/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['internet'], 
                            'description':'AXGATE UTM Internet Connection Check',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                            'lib_name':'axgate_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml', 
                            'cfg_path':'./', 
                            'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'AXGATE UTM Internet Connection Alarm', 
                    'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. WAN 인터페이스 확인 : "ethtool eth1"
4. Default GateWay 확인 : "ip route | grep default"
5. 장애 시, UTM 담당자 연락"""},
                    "threshold":[
                        {
                            "name":"[Critical] AXGATE UTM Internet Connection Alarm",
                            "grade":"critical",
                            "description":"AXGATE UTM Internet Connection Critical",
                            "repeat":REAP_H, 
                            "conditions":{"op":"<=", "value":"0"}
                        }
                    ]
                }
                
                
                ],
            "discovery":[
                {
                "name":"UTM VNet Discovery",
                "period":DISC_P,
                "remain":"1",
                "description":"AXGATE UTM VNet Discovery",
                "return_field":'NAME',
                "plugin":{
                        'name':'AXGATE UTM VNet Discovery',
                        'type':'file',
                        'script': plugDir+'/utm/axgate/axgate_discovery.py',
                        'param_num':'1', 
                        'plugin_param':['NETLIST'], 
                        'description':'AXGATE UTM VNet Discovery',
                        'lib_type':'file', 
                        'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                        'lib_name':'axgate_api.py', 
                        'lib_path':'./', 
                        'cfg_name':'axgate_cfg.yaml', 
                        'cfg_path':'./', 
                        'cfg_input':['vm_id', 'vm_passwd', 'vm_ip', 'vm_net'],
                        'discovery_input':'vm_net'
                        },
                "item":[
                        {
                            "name":"UTM VNet I/F Status",
                            'visible':'UTM 네트워크 상태',
                            "type":"Status",
                            "item_id":"vnf.net.if.status",
                            "data_type":"int",
                            "value_type":"status",
                            "period":STAT_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"AXGATE UTM Network I/F Status",
                            "plugin":{
                                    'name':'AXGATE UTM Network I/F Status', 
                                    'type':'file', 
                                    'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                    'param_num':'2', 
                                    'plugin_param':['netstatus'], 
                                    'description':'AXGATE UTM Network I/F Status',
                                    'lib_type':'file', 
                                    'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                    'lib_name':'axgate_api.py', 
                                    'lib_path':'./', 
                                    'cfg_name':'axgate_cfg.yaml', 
                                    'cfg_path':'./', 
                                    'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'UTM VNet I/F Status Alarm', 
                            'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. NIC 상태 확인: "ethtool $IF_NAME"
4. 장애 시, 개발팀 연락"""},
                            "threshold":[
                                {
                                    "name":"[Critical] UTM VNet I/F Status Down",
                                    "grade":"critical",
                                    "description":"UTM VNet I/F Status Down",
                                    "repeat":REAP_L, 
                                    "conditions":{"op":"<=", "value":"0"}
                                }
                            ]
                        },
                        {
                            "name":"UTM VNet Rx_Rate",
                            'visible':'UTM 네트워크 RxRate',
                            "type":"Rx Rate",
                            "item_id":"vnf.net.if.rx_rate",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "data_type":"int",
                            "unit":"bps",
                            "period":PERF_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"AXGATE UTM Network Rx_Rate",
                            "plugin":{
                                    'name':'AXGATE UTM Network Rx_Rate', 
                                    'type':'file', 
                                    'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                    'param_num':'3', 
                                    'plugin_param':['traffic', 'rx_rate'], 
                                    'description':'AXGATE UTM Network Rx_Rate',
                                    'lib_type':'file', 
                                    'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                    'lib_name':'axgate_api.py', 
                                    'lib_path':'./', 
                                    'cfg_name':'axgate_cfg.yaml', 
                                    'cfg_path':'./', 
                                    'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'UTM VNet Rx_Rate Alarm', 
                            'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. RX 대역폭 확인: "ifstat -i $IF_NAME"
4. 장애 시, 개발팀과 UTM 담당자에게 연락"""},
                            "threshold":[
                                {
                                    "name":"[Warning] UTM VNet Rx_Rate Alarm",
                                    "grade":"warning",
                                    "description":"AXGATE UTM VNet Rx_Rate Warning",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"500000000"},{"op":"<", "value":"600000000"}]
                                },
                                {
                                    "name":"[Minor] UTM VNet Rx_Rate Alarm",
                                    "grade":"Minor",
                                    "description":"AXGATE UTM VNet Rx_Rate Minor",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"600000000"},{"op":"<", "value":"650000000"}]
                                },
                                {
                                    "name":"[Major] UTM VNet Rx_Rate Alarm",
                                    "grade":"Major",
                                    "description":"AXGATE VNet Rx_Rate Major",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"650000000"},{"op":"<", "value":"700000000"}]
                                },
                                {
                                    "name":"[Critical] UTM VNet Rx_Rate Alarm",
                                    "grade":"Critical",
                                    "description":"AXGATE UTM VNet Rx_Rate Critical",
                                    "repeat":REAP_M, 
                                    "conditions":{"op":">=", "value":"700000000"}
                                }
                            ]
                        },
                        {
                            "name":"UTM VNet Tx_Rate",
                            'visible':'UTM 네트워크 TxRate',
                            "type":"Tx Rate",
                            "item_id":"vnf.net.if.tx_rate",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "data_type":"int",
                            "unit":"bps",
                            "period":PERF_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"AXGATE UTM Network Tx_Rate",
                            "plugin":{
                                    'name':'AXGATE UTM Network Tx_Rate', 
                                    'type':'file', 
                                    'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                    'param_num':'3', 
                                    'plugin_param':['traffic', 'tx_rate'], 
                                    'description':'AXGATE UTM Network Tx_Rate',
                                    'lib_type':'file', 
                                    'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                    'lib_name':'axgate_api.py', 
                                    'lib_path':'./', 
                                    'cfg_name':'axgate_cfg.yaml', 
                                    'cfg_path':'./', 
                                    'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'UTM VNet Tx_Rate Alarm', 
                            'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. TX 대역폭 확인: "ifstat -i $IF_NAME"
4. 장애 시, 개발팀과 UTM 담당자에게 연락"""},
                            "threshold":[
                                {
                                    "name":"[Warning] UTM VNet Tx_Rate Alarm",
                                    "grade":"warning",
                                    "description":"AXGATE UTM VNet Tx_Rate Warning",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"500000000"},{"op":"<", "value":"600000000"}]
                                },
                                {
                                    "name":"[Minor] UTM VNet Tx_Rate Alarm",
                                    "grade":"Minor",
                                    "description":"AXGATE UTM VNet Tx_Rate Minor",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"600000000"},{"op":"<", "value":"650000000"}]
                                },
                                {
                                    "name":"[Major] UTM VNet Tx_Rate Alarm",
                                    "grade":"Major",
                                    "description":"AXGATE VNet Tx_Rate Major",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"650000000"},{"op":"<", "value":"700000000"}]
                                },
                                {
                                    "name":"[Critical] UTM VNet Tx_Rate Alarm",
                                    "grade":"Critical",
                                    "description":"AXGATE UTM VNet Tx_Rate Critical",
                                    "repeat":REAP_M, 
                                    "conditions":{"op":">=", "value":"700000000"}
                                }
                            ]
                        }
                    ]
                }
                ]
            },
            
            {'name': 'vdisk', 'visible':'가상 Disk', 'description':'UTM VDisk Monitor',
            "item":[
                    {
                        "name":"UTM VDisk UtilRate",
                        'visible':'UTM Disk 사용률',
                        "type":"Util",
                        "item_id":"vnf.fs.util",
                        "data_type":"float",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM VDisk UtilRate",
                        "plugin":{
                                'name':'AXGATE UTM VDisk UtilRate', 
                                'type':'file', 
                                'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                'param_num':'1', 
                                'plugin_param':['disk'], 
                                'description':'AXGATE UTM VDisk UtilRate',
                                'lib_type':'file', 
                                'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                'lib_name':'axgate_api.py', 
                                'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml', 
                                'cfg_path':'./', 'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM VDisk UtilRate Alarm', 
                        'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. 파일시스템 사용률 확인: "du -sh /*"
4. 사용량이 많은 파일 용도를 파악하여 불필요할 경우 삭제"""},
                        "threshold":[
                            {
                                "name":"[Warning] UTM VDisk UtilRate Alarm",
                                "grade":"warning",
                                "description":"AXGATE UTM VDisk UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] UTM VDisk UtilRate Alarm",
                                "grade":"Minor",
                                "description":"AXGATE UTM VDisk UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] UTM VDisk UtilRate Alarm",
                                "grade":"Major",
                                "description":"AXGATE VDisk UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] UTM VDisk UtilRate Alarm",
                                "grade":"Critical",
                                "description":"AXGATE UTM VDisk UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            
            {'name': 'daemon', 'visible':'UTM Daemon', 'description':'UTM Daemon Monitor',
            "discovery":[
                {
                "name":"UTM Daemon Discovery",
                "period":DISC_P,
                "remain":"1",
                "description":"AXGATE UTM Daemon Discovery",
                "return_field":'NAME',
                "plugin":{
                        'name':'AXGATE UTM Daemon Discovery', 
                        'type':'file',
                        'script': plugDir+'/utm/axgate/axgate_discovery.py',
                        'param_num':'1', 
                        'plugin_param':['DAEMONLIST'], 
                        'description':'AXGATE UTM Daemon Discovery',
                        'lib_type':'file', 
                        'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                        'lib_name':'axgate_api.py', 
                        'lib_path':'./', 
                        'cfg_name':'axgate_cfg.yaml', 
                        'cfg_path':'./', 
                        'cfg_input':['vm_daemon'],
                        'discovery_input':'vm_daemon'
                        },
                "item":[
                        {
                            "name":"UTM Daemon Status",
                            'visible':'UTM Daemon 상태',
                            "type":"Status",
                            "item_id":"vnf.proc.status",
                            "data_type":"int",
                            "value_type":"status",
                            "period":STAT_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"AXGATE UTM Daemon Status",
                            "plugin":{
                                    'name':'AXGATE UTM Daemon Status', 
                                    'type':'file', 
                                    'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                    'param_num':'2', 
                                    'plugin_param':['DAEMON'], 
                                    'description':'AXGATE UTM Daemon Status',
                                    'lib_type':'file', 
                                    'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                    'lib_name':'axgate_api.py', 
                                    'lib_path':'./', 
                                    'cfg_name':'axgate_cfg.yaml', 
                                    'cfg_path':'./', 
                                    'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'UTM Daemon Status Alarm', 
                            'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. Job 상태 확인: "jobcontrol list | grep $JOB_NAME"
4. 장애 시, UTM 담당자 연락"""},
                            "threshold":[
                                {
                                    "name":"[Critical] UTM Daemon Status Down",
                                    "grade":"critical",
                                    "description":"AXGATE UTM Daemon Status Down",
                                    "repeat":REAP_L, 
                                    "conditions":{"op":"<=", "value":"0"}
                                }
                            ]
                        }
                    ]
                }
                ]
            },
            {'name': 'dhcp', 'visible':'DHCP', 'description':'UTM DHCP Monitor',
                 "item":[
                    {
                        "name":"DHCP Usage",
                        'visible':'UTM DHCP 사용량',
                        "type":"Usage",
                        "item_id":"vnf.spec.dhcp.use",
                        "graph_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM DHCP Usage",
                        "plugin":{
                                'name':'AXGATE UTM DHCP Usage', 
                                'type':'file', 
                                'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                'param_num':'1', 
                                'plugin_param':['dhcp'], 
                                'description':'AXGATE UTM DHCP Usage',
                                'lib_type':'file', 
                                'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                'lib_name':'axgate_api.py', 
                                'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml', 
                                'cfg_path':'./', 'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM DHCP Usage Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""}
                    }
                ]
            },

            {'name': 'license', 'visible':'UTM License', 'description':'UTM License',
            "item":[
                    {
                        "name":"UTM License Status",
                        'visible':'UTM 라이센스 상태',
                        "type":"Status",
                        "item_id":"vnf.utm.license.status",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "data_type":"int",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM License Status",
                        "plugin":{
                                'name':'AXGATE UTM License Status', 
                                'type':'file', 
                                'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                'param_num':'1', 
                                'plugin_param':['license'], 
                                'description':'AXGATE UTM License Status',
                                'lib_type':'file', 
                                'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                'lib_name':'axgate_api.py', 
                                'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml', 
                                'cfg_path':'./', 'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'AXGATE UTM License Status Alarm', 'guide':"""1. 장애 시, AXGATE UTM 담당자 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] AXGATE UTM License Status Alarm",
                                "grade":"warning",
                                "description":"AXGATE UTM License Status Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":"<=", "value":"12"},{"op":">", "value":"9"}]
                            },
                            {
                                "name":"[Minor] AXGATE UTM License Status Alarm",
                                "grade":"minor",
                                "description":"AXGATE UTM License Status Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":"<=", "value":"9"},{"op":">", "value":"6"}]
                            },
                            {
                                "name":"[Major] AXGATE UTM License Status Alarm",
                                "grade":"major",
                                "description":"AXGATE UTM License Status Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":"<=", "value":"6"},{"op":">", "value":"3"}]
                            },
                            {
                                "name":"[Critical] AXGATE UTM License Status Alarm",
                                "grade":"Critical",
                                "description":"AXGATE UTM License Status Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":"<=", "value":"3"}
                            },
                        ]                        
                    }
                ]
            },
            {'name': 'ha', 'visible':'HA Status', 'description':'HA Status',
            "item":[
                    {
                        "name":"HA Status",
                        'visible':'HA 상태',
                        "type":"Status",
                        "item_id":"vnf.utm.ha.status",
                        "graph_yn": 'n',
                        "realtime_yn": 'y',
                        "data_type":"int",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE HA Status",
                        "plugin":{
                                'name':'AXGATE HA Status', 
                                'type':'file', 
                                'script': plugDir+'/utm/axgate/axgate_plugin.py',
                                'param_num':'1', 
                                'plugin_param':['ha'], 
                                'description':'AXGATE ha Status',
                                'lib_type':'file', 
                                'lib_script':plugDir+'/utm/axgate/axgate_api.py',
                                'lib_name':'axgate_api.py', 
                                'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml', 
                                'cfg_path':'./', 'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'AXGATE HA Status Alarm', 'guide':"""1. 장애 시, AXGATE UTM 담당자 연락"""},
                        "threshold":[
                            {
                                "name":"[Critical] AXGATE HA Status Alarm",
                                "grade":"Critical",
                                "description":"AXGATE HA Status Inactive",
                                "repeat":REAP_M, 
                                "conditions":{"op":"<=", "value":"0"}
                            }
                        ]
                    }
                ]
            }
            
        ]
    }
    
    return body
