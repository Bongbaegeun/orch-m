#-*- coding: utf-8 -*-

TTYPE = "UTM"
VENDER = "AXGATE"
MODEL_LIST = ['pv1.0']

def chkParam( params ):
    if params == None or len(params) < 1 :
        return '[ERROR] No Param, Params: 1. ModelType=%s'%str(MODEL_LIST)
    elif len(params) !=1 :
        return '[ERROR] Invalid Para -> %s, Params: ModelType'%str(params)
    
    p1 = str(params[0])
    if not p1 in MODEL_LIST :
        return '[ERROR] Unknown Model Type -> %s, Supported Model=%s'%(str(p1), str(MODEL_LIST))
    
    return None

def makeBody(_type, params, plugDir, HIST="10", TRND="180"):

   
    ret = chkParam(params)
    if ret != None :
        print ret
        return

    mType = params[0]
    
    REAP_H = '1'
    REAP_M = '1'
    REAP_L = '1'
    DISC_P = '300'
    
    if _type == 'REAL':
        STAT_H = "30"
        STAT_M = "60"
        STAT_L = "120"
        PERF_H = "60"
        PERF_M = "300"
        PERF_L = "600"
        REAP_H = '3'
        REAP_M = '2'
        REAP_L = '1'
        
    elif _type == 'TEST':
        STAT_H = "10"
        STAT_M = "30"
        STAT_L = "60"
        PERF_H = "30"
        PERF_M = "60"
        PERF_L = "120"
        DISC_P = "120"
        
    elif _type == 'SHOW' :
        STAT_H = "2"
        STAT_M = "10"
        STAT_L = "30"
        PERF_H = "10"
        PERF_M = "30"
        PERF_L = "60"
        DISC_P = "60"
    else:
        print "Invalid Template Type -> %s, Supported Type=[REAL, TEST, SHOW]"
        return

    print '=======>> Creating PNF:%s:%s:%s:%s Template'%(TTYPE, VENDER, mType, _type)
    
    body = {
        "tid":'temp-create-1',
        "target_info":{
                'code':'pnf', 'type':'UTM', "name":"PNF-AXGATE UTM", 'visible':'AXGATE UTM[PNF]', 'model':mType,
                'vendor_code':'axgate', "description":"AXGATE UTM %s Monitoring"%mType, 
                'version':'v1.0', 'target_for':'Provisioning'
                },
        "group":[
            {'name': 'vcpu', 'visible':'UTM CPU', 'description':'UTM CPU Monitor',
                 "item":[
                    {
                        "name":"CPU Load",
                        'visible':'CPU 부하',
                        "type":"Load",
                        "item_id":"vnf.cpu.load",
                        "graph_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"job",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM CPU Load",
                        "plugin":{
                                'name':'AXGATE UTM CPU Load',
                                'type':'file', 
                                'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                                'param_num':'1',
                                'plugin_param':['cpuload'],
                                'description':'AXGATE UTM CPU Load',
                                'lib_type':'file', 'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                                'lib_name':'axgate_api.py', 'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM CPU Load Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""}
                    },
                    {
                        "name":"CPU Util",
                        'visible':'UTM CPU 사용률',
                        "type":"Util",
                        "item_id":"vnf.cpu.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM CPU Util",
                        "plugin":{
                                'name':'AXGATE UTM CPU Util',
                                'type':'file', 
                                'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                                'param_num':'1',
                                'plugin_param':['cpuutil'],
                                'description':'AXGATE UTM CPU Util',
                                'lib_type':'file',
                                'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                                'lib_name':'axgate_api.py',
                                'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml',
                                'cfg_path':'./',
                                'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM CPU Util Alarm',
                        'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
                        "threshold":[
                            {
                                "name":"[Warning] UTM CPU Util Alarm",
                                "grade":"warning",
                                "description":"AXGATE UTM CPU Util Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] UTM CPU Util Alarm",
                                "grade":"minor",
                                "description":"AXGATE UTM CPU Util Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] UTM CPU Util Alarm",
                                "grade":"major",
                                "description":"AXGATE UTM CPU Util Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] UTM CPU Util Alarm",
                                "grade":"Critical",
                                "description":"AXGATE UTM CPU Util Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'vmem', 'visible':'UTM 메모리', 'description':'UTM Memory Monitor',
                 "item":[
                    {
                        "name":"MEM UtilRate",
                        'visible':'UTM 메모리 사용률',
                        "type":"Util",
                        "item_id":"vnf.mem.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM Memory UtilRate",
                        "plugin":{
                                'name':'AXGATE UTM Memory UtilRate', 'type':'file', 
                                'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                                'param_num':'1', 
                                'plugin_param':['mem'], 
                                'description':'AXGATE UTM Memory UtilRate',
                                'lib_type':'file', 
                                'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                                'lib_name':'axgate_api.py', 
                                'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml', 
                                'cfg_path':'./', 
                                'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM VMem UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. 메모리 사용이 많은 프로세스 확인: "ps -aux --sort -rss | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
                        "threshold":[
                            {
                                "name":"[Warning] UTM Mem UtilRate Alarm",
                                "grade":"warning",
                                "description":"AXGATE UTM Mem UtilRate Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] UTM Mem UtilRate Alarm",
                                "grade":"Minor",
                                "description":"AXGATE UTM Mem UtilRate Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] UTM Mem UtilRate Alarm",
                                "grade":"Major",
                                "description":"AXGATE UTM Mem UtilRate Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] UTM Mem UtilRate Alarm",
                                "grade":"Critical",
                                "description":"AXGATE UTM Mem UtilRate Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            
            {'name': 'vnet', 'visible':'UTM 네트워크', 'description':'UTM VNetwork Monitor',
             "item":[
                {
                    "name":"UTM ConnTrack",
                    'visible':'UTM ConnTrack',
                    "type":"ConnTrack",
                    "item_id":"vnf.spec.conntrack",
                    "graph_yn": 'y',
                    "realtime_yn": 'y',
                    "statistic_yn": 'y',
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM Network ConnTrack",
                    "plugin":{
                            'name':'AXGATE UTM Network ConnTrack', 
                            'type':'file', 
                            'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['conntrack'],
                            'description':'AXGATE UTM Network ConnTrack',
                            'lib_type':'file',
                            'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                            'lib_name':'axgate_api.py',
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml',
                            'cfg_path':'./', 'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                            },
                    "alarm_guide":{'name':'UTM VNet ConnTrack Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""}
                },
                
                
                {
                    "name":"UTM VPN Count",
                    'visible':'UTM VPN 전체 세션수',
                    "type":"VPNCount",
                    "item_id":"vnf.net.vpn.count",
                    "graph_yn": 'y',
                    "realtime_yn": 'y',
                    "statistic_yn": 'y',
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM VPN Count",
                    "plugin":{
                            'name':'AXGATE UTM VPN Count', 
                            'type':'file', 
                            'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['vpncount'],
                            'description':'AXGATE UTM VPN Count',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                            'lib_name':'axgate_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml', 
                            'cfg_path':'./', 
                            'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'AXGATE UTM VPN Count Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""},
                },                
                
                {
                    "name":"UTM VPN Total Tunnel",
                    'visible':'UTM VPN Total 터널수',
                    "type":"VPN_TotalTunnel",
                    "item_id":"vnf.net.vpn.totaltunnel",
                    "graph_yn": 'y',
                    "realtime_yn": 'y',
                    "statistic_yn": 'y',
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM VPN Total Tunnel",
                    "plugin":{
                            'name':'AXGATE UTM VPN Total Tunnel', 
                            'type':'file', 
                            'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['vpn_totalcount'],
                            'description':'AXGATE UTM VPN Total Tunnel',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                            'lib_name':'axgate_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml', 
                            'cfg_path':'./', 
                            'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'AXGATE UTM VPN Total Tunnel Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""},
                },                

                {
                    "name":"UTM VPN Active Tunnel",
                    'visible':'UTM VPN Active 터널수',
                    "type":"VPN_ActiveTunnel",
                    "item_id":"vnf.net.vpn.activetunnel",
                    "graph_yn": 'y',
                    "realtime_yn": 'y',
                    "statistic_yn": 'y',
                    "data_type":"int",
                    "period":PERF_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM VPN Active Tunnel",
                    "plugin":{
                            'name':'AXGATE UTM VPN Active Tunnel', 
                            'type':'file', 
                            'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['vpn_activecount'],
                            'description':'AXGATE UTM VPN Active Tunnel',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                            'lib_name':'axgate_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml', 
                            'cfg_path':'./', 
                            'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'AXGATE UTM VPN Active Tunnel Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""},
                },                
                
                {
                    "name":"UTM Connection",
                    'visible':'UTM 연결상태',
                    "type":"Connection",
                    "item_id":"vnf.net.conn.vm",
                    "data_type":"int",
                    "value_type":"status",
                    "period":STAT_H,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM Connection Check",
                    "plugin":{
                            'name':'AXGATE UTM Connection', 
                            'type':'file', 
                            'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['connection'],
                            'description':'AXGATE UTM Connection Check',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                            'lib_name':'axgate_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml', 
                            'cfg_path':'./', 
                            'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'UTM Connection Alarm', 
                    'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. UTM Public IP의 Ping 확인: "ping $UTM_PUBLIC_IP"
4. 장애 시, 개발팀 및 오픈스택 담당자 연락"""},
                    "threshold":[
                        {
                            "name":"[Critical] UTM Connection Alarm",
                            "grade":"critical",
                            "description":"AXGATE UTM Connection Critical",
                            "repeat":REAP_H, 
                            "conditions":{"op":"<=", "value":"0"}
                        }
                    ]
                },
                {
                    "name":"UTM Internet Connection",
                    'visible':'UTM 인터넷 연결상태',
                    "type":"InterConnection",
                    "item_id":"vnf.spec.internet_conn",
                    "data_type":"int",
                    "value_type":"status",
                    "period":STAT_M,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"AXGATE UTM Internet Connection Check",
                    "plugin":{
                            'name':'AXGATE UTM Internet Connection',
                            'type':'file', 
                            'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                            'param_num':'1', 
                            'plugin_param':['internet'], 
                            'description':'AXGATE UTM Internet Connection Check',
                            'lib_type':'file', 
                            'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                            'lib_name':'axgate_api.py', 
                            'lib_path':'./', 
                            'cfg_name':'axgate_cfg.yaml', 
                            'cfg_path':'./', 
                            'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'AXGATE UTM Internet Connection Alarm', 
                    'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. WAN 인터페이스 확인 : "ethtool eth1"
4. Default GateWay 확인 : "ip route | grep default"
5. 장애 시, UTM 담당자 연락"""},
                    "threshold":[
                        {
                            "name":"[Critical] AXGATE UTM Internet Connection Alarm",
                            "grade":"critical",
                            "description":"AXGATE UTM Internet Connection Critical",
                            "repeat":REAP_H, 
                            "conditions":{"op":"<=", "value":"0"}
                        }
                    ]
                }
                
                
                ],
            "discovery":[
                {
                "name":"UTM VNet Discovery",
                "period":DISC_P,
                "remain":"1",
                "description":"AXGATE UTM VNet Discovery",
                "return_field":'NAME',
                "plugin":{
                        'name':'AXGATE UTM VNet Discovery',
                        'type':'file',
                        'script': plugDir+'/utm/axgate_pnf/axgate_discovery.py',
                        'param_num':'1', 
                        'plugin_param':['NETLIST'], 
                        'description':'AXGATE UTM VNet Discovery',
                        'lib_type':'file', 
                        'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                        'lib_name':'axgate_api.py', 
                        'lib_path':'./', 
                        'cfg_name':'axgate_cfg.yaml', 
                        'cfg_path':'./', 
                        'cfg_input':['vm_id', 'vm_passwd', 'vm_ip', 'vm_net'],
                        'discovery_input':'vm_net'
                        },
                "item":[
                        {
                            "name":"UTM VNet I/F Status",
                            'visible':'UTM 네트워크 상태',
                            "type":"Status",
                            "item_id":"vnf.net.if.status",
                            "data_type":"int",
                            "value_type":"status",
                            "period":STAT_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"AXGATE UTM Network I/F Status",
                            "plugin":{
                                    'name':'AXGATE UTM Network I/F Status', 
                                    'type':'file', 
                                    'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                                    'param_num':'2', 
                                    'plugin_param':['netstatus'], 
                                    'description':'AXGATE UTM Network I/F Status',
                                    'lib_type':'file', 
                                    'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                                    'lib_name':'axgate_api.py', 
                                    'lib_path':'./', 
                                    'cfg_name':'axgate_cfg.yaml', 
                                    'cfg_path':'./', 
                                    'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'UTM VNet I/F Status Alarm', 
                            'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. NIC 상태 확인: "ethtool $IF_NAME"
4. 장애 시, 개발팀 연락"""},
                            "threshold":[
                                {
                                    "name":"[Critical] UTM VNet I/F Status Down",
                                    "grade":"critical",
                                    "description":"UTM VNet I/F Status Down",
                                    "repeat":REAP_L, 
                                    "conditions":{"op":"<=", "value":"0"}
                                }
                            ]
                        },
                        {
                            "name":"UTM VNet Rx_Rate",
                            'visible':'UTM 네트워크 RxRate',
                            "type":"Rx Rate",
                            "item_id":"vnf.net.if.rx_rate",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "data_type":"int",
                            "unit":"bps",
                            "period":PERF_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"AXGATE UTM Network Rx_Rate",
                            "plugin":{
                                    'name':'AXGATE UTM Network Rx_Rate', 
                                    'type':'file', 
                                    'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                                    'param_num':'3', 
                                    'plugin_param':['traffic', 'rx_rate'], 
                                    'description':'AXGATE UTM Network Rx_Rate',
                                    'lib_type':'file', 
                                    'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                                    'lib_name':'axgate_api.py', 
                                    'lib_path':'./', 
                                    'cfg_name':'axgate_cfg.yaml', 
                                    'cfg_path':'./', 
                                    'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'UTM VNet Rx_Rate Alarm', 
                            'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. RX 대역폭 확인: "ifstat -i $IF_NAME"
4. 장애 시, 개발팀과 UTM 담당자에게 연락"""},
                            "threshold":[
                                {
                                    "name":"[Warning] UTM VNet Rx_Rate Alarm",
                                    "grade":"warning",
                                    "description":"AXGATE UTM VNet Rx_Rate Warning",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"500000000"},{"op":"<", "value":"600000000"}]
                                },
                                {
                                    "name":"[Minor] UTM VNet Rx_Rate Alarm",
                                    "grade":"Minor",
                                    "description":"AXGATE UTM VNet Rx_Rate Minor",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"600000000"},{"op":"<", "value":"650000000"}]
                                },
                                {
                                    "name":"[Major] UTM VNet Rx_Rate Alarm",
                                    "grade":"Major",
                                    "description":"AXGATE VNet Rx_Rate Major",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"650000000"},{"op":"<", "value":"700000000"}]
                                },
                                {
                                    "name":"[Critical] UTM VNet Rx_Rate Alarm",
                                    "grade":"Critical",
                                    "description":"AXGATE UTM VNet Rx_Rate Critical",
                                    "repeat":REAP_M, 
                                    "conditions":{"op":">=", "value":"700000000"}
                                }
                            ]
                        },
                        {
                            "name":"UTM VNet Tx_Rate",
                            'visible':'UTM 네트워크 TxRate',
                            "type":"Tx Rate",
                            "item_id":"vnf.net.if.tx_rate",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "data_type":"int",
                            "unit":"bps",
                            "period":PERF_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"AXGATE UTM Network Tx_Rate",
                            "plugin":{
                                    'name':'AXGATE UTM Network Tx_Rate', 
                                    'type':'file', 
                                    'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                                    'param_num':'3', 
                                    'plugin_param':['traffic', 'tx_rate'], 
                                    'description':'AXGATE UTM Network Tx_Rate',
                                    'lib_type':'file', 
                                    'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                                    'lib_name':'axgate_api.py', 
                                    'lib_path':'./', 
                                    'cfg_name':'axgate_cfg.yaml', 
                                    'cfg_path':'./', 
                                    'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'UTM VNet Tx_Rate Alarm', 
                            'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. TX 대역폭 확인: "ifstat -i $IF_NAME"
4. 장애 시, 개발팀과 UTM 담당자에게 연락"""},
                            "threshold":[
                                {
                                    "name":"[Warning] UTM VNet Tx_Rate Alarm",
                                    "grade":"warning",
                                    "description":"AXGATE UTM VNet Tx_Rate Warning",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"500000000"},{"op":"<", "value":"600000000"}]
                                },
                                {
                                    "name":"[Minor] UTM VNet Tx_Rate Alarm",
                                    "grade":"Minor",
                                    "description":"AXGATE UTM VNet Tx_Rate Minor",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"600000000"},{"op":"<", "value":"650000000"}]
                                },
                                {
                                    "name":"[Major] UTM VNet Tx_Rate Alarm",
                                    "grade":"Major",
                                    "description":"AXGATE VNet Tx_Rate Major",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"650000000"},{"op":"<", "value":"700000000"}]
                                },
                                {
                                    "name":"[Critical] UTM VNet Tx_Rate Alarm",
                                    "grade":"Critical",
                                    "description":"AXGATE UTM VNet Tx_Rate Critical",
                                    "repeat":REAP_M, 
                                    "conditions":{"op":">=", "value":"700000000"}
                                }
                            ]
                        }
                    ]
                }
                ]
            },
            
            {'name': 'vdisk', 'visible':'UTM Disk', 'description':'UTM Disk Monitor',
            "item":[
                    {
                        "name":"UTM Disk UtilRate",
                        'visible':'UTM Disk 사용률',
                        "type":"Util",
                        "item_id":"vnf.fs.util",
                        "data_type":"float",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM Disk UtilRate",
                        "plugin":{
                                'name':'AXGATE UTM Disk UtilRate', 
                                'type':'file', 
                                'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                                'param_num':'1', 
                                'plugin_param':['disk'], 
                                'description':'AXGATE UTM Disk UtilRate',
                                'lib_type':'file', 
                                'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                                'lib_name':'axgate_api.py', 
                                'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml', 
                                'cfg_path':'./', 'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM VDisk UtilRate Alarm', 
                        'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. 파일시스템 사용률 확인: "du -sh /*"
4. 사용량이 많은 파일 용도를 파악하여 불필요할 경우 삭제"""},
                        "threshold":[
                            {
                                "name":"[Warning] UTM Disk UtilRate Alarm",
                                "grade":"warning",
                                "description":"AXGATE UTM Disk UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] UTM Disk UtilRate Alarm",
                                "grade":"Minor",
                                "description":"AXGATE UTM Disk UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] UTM Disk UtilRate Alarm",
                                "grade":"Major",
                                "description":"AXGATE Disk UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] UTM Disk UtilRate Alarm",
                                "grade":"Critical",
                                "description":"AXGATE UTM Disk UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            
            {'name': 'daemon', 'visible':'UTM Daemon', 'description':'UTM Daemon Monitor',
            "discovery":[
                {
                "name":"UTM Daemon Discovery",
                "period":DISC_P,
                "remain":"1",
                "description":"AXGATE UTM Daemon Discovery",
                "return_field":'NAME',
                "plugin":{
                        'name':'AXGATE UTM Daemon Discovery', 
                        'type':'file',
                        'script': plugDir+'/utm/axgate_pnf/axgate_discovery.py',
                        'param_num':'1', 
                        'plugin_param':['DAEMONLIST'], 
                        'description':'AXGATE UTM Daemon Discovery',
                        'lib_type':'file', 
                        'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                        'lib_name':'axgate_api.py', 
                        'lib_path':'./', 
                        'cfg_name':'axgate_cfg.yaml', 
                        'cfg_path':'./', 
                        'cfg_input':['vm_daemon'],
                        'discovery_input':'vm_daemon'
                        },
                "item":[
                        {
                            "name":"UTM Daemon Status",
                            'visible':'UTM Daemon 상태',
                            "type":"Status",
                            "item_id":"vnf.proc.status",
                            "data_type":"int",
                            "value_type":"status",
                            "period":STAT_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"AXGATE UTM Daemon Status",
                            "plugin":{
                                    'name':'AXGATE UTM Daemon Status', 
                                    'type':'file', 
                                    'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                                    'param_num':'2', 
                                    'plugin_param':['DAEMON'], 
                                    'description':'AXGATE UTM Daemon Status',
                                    'lib_type':'file', 
                                    'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                                    'lib_name':'axgate_api.py', 
                                    'lib_path':'./', 
                                    'cfg_name':'axgate_cfg.yaml', 
                                    'cfg_path':'./', 
                                    'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                    },
                            "alarm_guide":{'name':'UTM Daemon Status Alarm', 
                            'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. Job 상태 확인: "jobcontrol list | grep $JOB_NAME"
4. 장애 시, UTM 담당자 연락"""},
                            "threshold":[
                                {
                                    "name":"[Critical] UTM Daemon Status Down",
                                    "grade":"critical",
                                    "description":"AXGATE UTM Daemon Status Down",
                                    "repeat":REAP_L, 
                                    "conditions":{"op":"<=", "value":"0"}
                                }
                            ]
                        }
                    ]
                }
                ]
            },
            {'name': 'dhcp', 'visible':'DHCP', 'description':'UTM DHCP Monitor',
                 "item":[
                    {
                        "name":"DHCP Usage",
                        'visible':'UTM DHCP 사용량',
                        "type":"Usage",
                        "item_id":"vnf.spec.dhcp.use",
                        "graph_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"AXGATE UTM DHCP Usage",
                        "plugin":{
                                'name':'AXGATE UTM DHCP Usage', 
                                'type':'file', 
                                'script': plugDir+'/utm/axgate_pnf/axgate_plugin.py',
                                'param_num':'1', 
                                'plugin_param':['dhcp'], 
                                'description':'AXGATE UTM DHCP Usage',
                                'lib_type':'file', 
                                'lib_script':plugDir+'/utm/axgate_pnf/axgate_api.py',
                                'lib_name':'axgate_api.py', 
                                'lib_path':'./', 
                                'cfg_name':'axgate_cfg.yaml', 
                                'cfg_path':'./', 'cfg_input':['vm_id', 'vm_passwd', 'vm_ip']
                                },
                        "alarm_guide":{'name':'UTM DHCP Usage Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""}
                    }
                ]
            }
        ]
    }
    
    return body
