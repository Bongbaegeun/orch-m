#-*- coding: utf-8 -*-

TTYPE = "WAF"
VENDER = "PENTA"
MODEL_LIST = ['v1.0']

def chkParam( params ):
    if params == None or len(params) < 1 :
        return '[ERROR] No Param, Params: 1. ModelType=%s'%str(MODEL_LIST)
    elif len(params) !=1 :
        return '[ERROR] Invalid Para -> %s, Params: ModelType'%str(params)
    
    p1 = str(params[0])
    if not p1 in MODEL_LIST :
        return '[ERROR] Unknown Model Type -> %s, Supported Model=%s'%(str(p1), str(MODEL_LIST))
    
    return None

def makeBody(_type, params, plugDir, HIST="10", TRND="180"):
    ret = chkParam(params)
    if ret != None :
        print ret
        return

    mType = params[0]
    
    REAP_H = '1'
    REAP_M = '1'
    REAP_L = '1'
    DISC_P = '300'
    if _type == 'REAL':
        STAT_H = "30"
        STAT_M = "60"
        STAT_L = "120"
        PERF_H = "60"
        PERF_M = "300"
        PERF_L = "600"
        REAP_H = '3'
        REAP_M = '2'
        REAP_L = '1'
    elif _type == 'TEST':
        STAT_H = "10"
        STAT_M = "30"
        STAT_L = "60"
        PERF_H = "30"
        PERF_M = "60"
        PERF_L = "120"
        DISC_P = "120"
    elif _type == 'SHOW' :
        STAT_H = "2"
        STAT_M = "10"
        STAT_L = "30"
        PERF_H = "10"
        PERF_M = "30"
        PERF_L = "60"
        DISC_P = "60"
    else:
        print "Invalid Template Type -> %s, Supported Type=[REAL, TEST, SHOW]"
        return

    print '=======>> Creating VNF:%s:%s:%s:%s Template'%(TTYPE, VENDER, mType, _type)
    
    body = {
        "tid":'temp-create-1',
        "target_info":{
                'code':'vnf', 'type':'WAF', "name":"VNF-WAF", 'visible':'WAF[VNF]', 'model':mType,
                'vendor_code':'pentas', "description":"WAF Penta %s Monitoring"%mType,
                'version':'v1.0', 'target_for':'Provisioning'
            },
        "group":[
            {'name': 'openstack-vinfra-status', 'visible':'가상자원 상태', 'description':'OpenStack VirtualInfra Status Monitor',
            "discovery":[
                    {
                    "name":"VM Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OpenStack VM Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OpenStack VM Discovery', 'type':'file',
                            'script': plugDir+'/vim/openstack_prov/nova_discovery.py',
                            'param_num':'0', 'description':'OpenStack VM Discovery',
                            'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                            'lib_name':'vim_api.py', 'lib_path':'./', 
                            'cfg_name':'nova_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_vm"],
                            'discovery_input':'vim_vm'
                            },
                    "item":[
                            {
                                "name":"WAF VM Status",
                                'visible':'VM 상태',
                                "type":"VM Status",
                                "item_id":"vim.osp.status.vm",
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_L,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"OpenStack VM status",
                                "plugin":{
                                        'name':'OpenStack VM Status', 'type':'file', 
                                        'script': plugDir+'/vim/openstack_prov/vm-status.sh',
                                        'param_num':'1', 'description':'OpenStack VM Status'
                                        },
                                "alarm_guide":{'name':'VM Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. VM 상태 확인: "nova list"
4. 다운 상태일 경우, VM 기동: "nova start $VM_NAME"
5. 장애 시, 오픈스택 관리자에게 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] WAF VM Status Down Alarm",
                                        "grade":"critical",
                                        "description":"OpenStack WAF Status Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    },
                    {
                    "name":"VPort Discovery",
                    "period":DISC_P,
                    "remain":"1",
                    "description":"OpenStack VPort Discovery",
                    "return_field":'NAME',
                    "plugin":{
                            'name':'OpenStack VPort Discovery', 'type':'file', 
                            'script': plugDir+'/vim/openstack_prov/neutron_discovery_prov.py',
                            'param_num':'1', 'plugin_param':['PORT'], 'description':'OpenStack VPort Discovery',
                            'lib_type':'file', 'lib_script':plugDir+'/vim/openstack_prov/vim_api.py',
                            'lib_name':'vim_api.py', 'lib_path':'./', 
                            'cfg_name':'neutron_prov_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain', 'vim_port'],
                            'discovery_input':'vim_port'
                            },
                    "item":[
                            {
                                "name":"WAF VPort Status",
                                'visible':'가상 Port 상태',
                                "type":"VPort Status",
                                "item_id":"vim.osp.status.vport",
                                "data_type":"int",
                                "value_type":"status",
                                "period":STAT_L,
                                "history":HIST,
                                "statistic":TRND,
                                "description":"OpenStack VPort status",
                                "plugin":{
                                        'name':'openstack vrouter status', 'type':'file',
                                        'script': plugDir+'/vim/openstack_prov/vport-status.sh',
                                        'param_num':'1', 'description':'OpenStack VPort Status'
                                        },
                                "alarm_guide":{'name':'VPort Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 가상 Port 상태 확인: "neutron port-list -c name -c fixed_ips -c status"
4. 장애 시, 오픈스택 관리자에게 연락"""},
                                "threshold":[
                                    {
                                        "name":"[Critical] WAF VPort Status Down Alarm",
                                        "grade":"critical",
                                        "description":"OpenStack VPort Status Critical",
                                        "repeat":REAP_L, 
                                        "conditions":{"op":"<=", "value":"0"}
                                    }
                                ]
                            }
                        ]
                    }
                ]## discovery
            },
            {'name': 'vcpu', 'visible':'가상 CPU', 'description':'Penta WAF VCPU Monitor',
                 "item":[
                    {
                        "name":"VCPU UtilRate",
                        'visible':'가상 CPU 사용률',
                        "type":"Util",
                        "item_id":"vnf.cpu.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Penta WAF VCPU UtilRate",
                        "plugin":{
                                'name':'Penta WAF VCPU UtilRate', 'type':'file', 
                                'script': plugDir+'/waf/penta/waf_plugin.py',
                                'param_num':'2', 'plugin_param':['CPU', 'UTIL'], 'description':'Penta WAF VCPU UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                'lib_name':'waf_api.py', 'lib_path':'./', 
                                'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'WAF VCPU UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
                        "threshold":[
                            {
                                "name":"[Warning] WAF VCPU UtilRate Alarm",
                                "grade":"warning",
                                "description":"Penta WAF VCPU UtilRate Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] WAF VCPU UtilRate Alarm",
                                "grade":"minor",
                                "description":"Penta WAF VCPU UtilRate Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] WAF VCPU UtilRate Alarm",
                                "grade":"major",
                                "description":"Penta WAF VCPU UtilRate Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] WAF VCPU UtilRate Alarm",
                                "grade":"Critical",
                                "description":"Penta WAF VCPU UtilRate Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'vmem', 'visible':'가상 메모리', 'description':'Penta WAF VMemory Monitor',
                 "item":[
                    {
                        "name":"VMEM UtilRate",
                        'visible':'가상 메모리 사용률',
                        "type":"Util",
                        "item_id":"vnf.mem.util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "unit":"%",
                        "period":PERF_H,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Penta WAF Memory UtilRate",
                        "plugin":{
                                'name':'Penta WAF Memory UtilRate', 'type':'file', 
                                'script': plugDir+'/waf/penta/waf_plugin.py',
                                'param_num':'2', 'plugin_param':['MEM', 'UTIL'], 'description':'Penta WAF Memory UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                'lib_name':'waf_api.py', 'lib_path':'./', 
                                'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'WAF VMem UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WAF 클릭하여 Console 접속 후 로그인
3. 메모리 사용이 많은 프로세스 확인: "ps -aux --sort -rss | head -n $LINE_NUM"
4. 불필요한 프로세스 정지 또는 WAF 담당자 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] WAF VMem UtilRate Alarm",
                                "grade":"warning",
                                "description":"Penta WAF VMem UtilRate Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] WAF VMem UtilRate Alarm",
                                "grade":"Minor",
                                "description":"Penta WAF VMem UtilRate Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] WAF VMem UtilRate Alarm",
                                "grade":"Major",
                                "description":"Penta WAF VMem UtilRate Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] WAF VMem UtilRate Alarm",
                                "grade":"Critical",
                                "description":"Penta WAF VMem UtilRate Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'traffic', 'visible':'Traffic', 'description':'Penta WAF Traffic Monitor',
                 "item":[
                    {
                        "name":"Traffic CPS",
                        'visible':'Traffic CPS',
                        "type":"CPS",
                        "item_id":"vnf.spec.cps",
                        "graph_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "unit":"cps",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Penta WAF Traffic CPS",
                        "plugin":{
                                'name':'Penta WAF Traffic CPS', 'type':'file', 
                                'script': plugDir+'/waf/penta/waf_plugin.py',
                                'param_num':'2', 'plugin_param':['TRAFFIC', 'CPS'], 'description':'Penta WAF Traffic CPS',
                                'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                'lib_name':'waf_api.py', 'lib_path':'./', 
                                'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'WAF Traffic CPS Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WAF 클릭하여 WEB 접속 후 로그인
3. 장애 내역 확인 및 트래픽 통계 확인
4. 장애 시, WAF 담당자 연락"""}
                    },
                    {
                        "name":"Traffic TPS",
                        'visible':'Traffic TPS',
                        "type":"TPS",
                        "item_id":"vnf.spec.tps",
                        "graph_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "unit":"tps",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Penta WAF Traffic TPS",
                        "plugin":{
                                'name':'Penta WAF Traffic TPS', 'type':'file', 
                                'script': plugDir+'/waf/penta/waf_plugin.py',
                                'param_num':'2', 'plugin_param':['TRAFFIC', 'TPS'], 'description':'Penta WAF Traffic TPS',
                                'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                'lib_name':'waf_api.py', 'lib_path':'./', 
                                'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'WAF Traffic TPS Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WAF 클릭하여 WEB 접속 후 로그인
3. 장애 내역 확인 및 트래픽 통계 확인
4. 장애 시, WAF 담당자 연락"""}
                    },
                    {
                        "name":"Traffic Rate",
                        'visible':'Traffic Rate',
                        "type":"Rate",
                        "item_id":"vnf.spec.bps",
                        "graph_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "unit":"bps",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Penta WAF Traffic Rate",
                        "plugin":{
                                'name':'Penta WAF Traffic Rate', 'type':'file', 
                                'script': plugDir+'/waf/penta/waf_plugin.py',
                                'param_num':'2', 'plugin_param':['TRAFFIC', 'RATE'], 'description':'Penta WAF Traffic Rate',
                                'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                'lib_name':'waf_api.py', 'lib_path':'./', 
                                'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'WAF Traffic Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WAF 클릭하여 WEB 접속 후 로그인
3. 장애 내역 확인 및 트래픽 통계 확인
4. 장애 시, WAF 담당자 연락"""}
                    }
                ]
            },
            {'name': 'network', 'visible':'네트워크', 'description':'Penta WAF Network Monitor',
            "item":[
                {
                    "name":"WAF Connection",
                    'visible':'WAF 연결상태',
                    "type":"Connection",
                    "item_id":"vnf.net.conn.vm",
                    "data_type":"int",
                    "value_type":"status",
                    "period":STAT_H,
                    "history":HIST,
                    "statistic":TRND,
                    "description":"Penta WAF Connection Check",
                    "plugin":{
                            'name':'Penta WAF Network ConnTrack', 'type':'file', 
                            'script': plugDir+'/waf/penta/waf_plugin.py',
                            'param_num':'1', 'plugin_param':['ping'], 'description':'Penta WAF Connection Check',
                            'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                            'lib_name':'waf_api.py', 'lib_path':'./', 
                            'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
                            },
                    "alarm_guide":{'name':'WAF Connection Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. "nova list" 명령을 통해 WAF 접속IP 확인 후 WAF Ping: "ping $WAF_IP"
4. 장애 시, 개발팀 연락"""},
                    "threshold":[
                        {
                            "name":"[Critical] WAF Connection Alarm",
                            "grade":"critical",
                            "description":"Penta WAF Connection Critical",
                            "repeat":REAP_H, 
                            "conditions":{"op":"<=", "value":"0"}
                        }
                    ]
                }
                ],
            "discovery":[
                {
                "name":"WAF Network Discovery",
                "period":DISC_P,
                "remain":"1",
                "description":"Penta WAF Network Discovery",
                "return_field":'NAME',
                "plugin":{
                        'name':'Penta WAF Network Discovery', 'type':'file',
                        'script': plugDir+'/waf/penta/waf_discovery.py',
                        'param_num':'1', 'plugin_param':['NETLIST'], 'description':'Penta WAF Network Discovery',
                        'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                        'lib_name':'waf_api.py', 'lib_path':'./', 
                        'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd', 'vm_net'],
                        'discovery_input':'vm_net'
                        },
                "item":[
                        {
                            "name":"WAF Network I/F Status",
                            'visible':'WAF 네트워크 상태',
                            "type":"Status",
                            "item_id":"vnf.net.if.status",
                            "data_type":"int",
                            "value_type":"status",
                            "period":STAT_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"Penta WAF Network I/F Status",
                            "plugin":{
                                    'name':'Penta WAF Network I/F Status', 'type':'file', 
                                    'script': plugDir+'/waf/penta/waf_plugin.py',
                                    'param_num':'3', 'plugin_param':['NETINFO', 'status'], 'description':'Penta WAF Network I/F Status',
                                    'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                    'lib_name':'waf_api.py', 'lib_path':'./', 
                                    'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                    },
                            "alarm_guide":{'name':'WAF Network I/F Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WAF 클릭하여 Console 접속 후 로그인
3. NIC 상태 확인: "ethtool $IF_NAME"
4. 장애 시, 개발팀 연락"""},
                            "threshold":[
                                {
                                    "name":"[Critical] WAF Network I/F Status Down",
                                    "grade":"critical",
                                    "description":"Penta WAF Network I/F Status Down",
                                    "repeat":REAP_L, 
                                    "conditions":{"op":"<=", "value":"0"}
                                }
                            ]
                        },
                        {
                            "name":"WAF Network Rx_Rate",
                            'visible':'WAF 네트워크 RxRate',
                            "type":"Rx Rate",
                            "item_id":"vnf.net.if.rx_rate",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "data_type":"int",
                            "unit":"bps",
                            "period":PERF_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"Penta WAF Network Rx_Rate",
                            "plugin":{
                                    'name':'Penta WAF Network Rx_Rate', 'type':'file', 
                                    'script': plugDir+'/waf/penta/waf_plugin.py',
                                    'param_num':'3', 'plugin_param':['net', 'rx_byte'], 'description':'Penta WAF Network Rx_Rate',
                                    'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                    'lib_name':'waf_api.py', 'lib_path':'./', 
                                    'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                    },
                            "alarm_guide":{'name':'WAF Network Rx_Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WAF 클릭하여 WEB 접속 후 로그인
3. 장애 내역 확인 및 Rx 통계 확인
4. 장애 시, 개발팀 및 WAF 담당자 연락"""},
                            "threshold":[
                                {
                                    "name":"[Warning] WAF Network Rx_Rate Alarm",
                                    "grade":"warning",
                                    "description":"Penta WAF Network Rx_Rate Warning",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"60000000"},{"op":"<", "value":"70000000"}]
                                },
                                {
                                    "name":"[Minor] WAF Network Rx_Rate Alarm",
                                    "grade":"Minor",
                                    "description":"Penta WAF Network Rx_Rate Minor",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"70000000"},{"op":"<", "value":"80000000"}]
                                },
                                {
                                    "name":"[Major] WAF Network Rx_Rate Alarm",
                                    "grade":"Major",
                                    "description":"Penta WAF Network Rx_Rate Major",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"80000000"},{"op":"<", "value":"90000000"}]
                                },
                                {
                                    "name":"[Critical] WAF Network Rx_Rate Alarm",
                                    "grade":"Critical",
                                    "description":"Penta WAF Network Rx_Rate Critical",
                                    "repeat":REAP_M, 
                                    "conditions":{"op":">=", "value":"90000000"}
                                }
                            ]
                        },
                        {
                            "name":"WAF Network Tx_Rate",
                            'visible':'WAF 네트워크 TxRate',
                            "type":"Tx Rate",
                            "item_id":"vnf.net.if.tx_rate",
                            "graph_yn": 'y',
                            "realtime_yn": 'y',
                            "statistic_yn": 'y',
                            "data_type":"int",
                            "unit":"bps",
                            "period":PERF_M,
                            "history":HIST,
                            "statistic":TRND,
                            "description":"Penta WAF Network Tx_Rate",
                            "plugin":{
                                    'name':'Penta WAF Network Tx_Rate', 'type':'file', 
                                    'script': plugDir+'/waf/penta/waf_plugin.py',
                                    'param_num':'3', 'plugin_param':['net', 'tx_byte'], 'description':'Penta WAF Network Tx_Rate',
                                    'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                    'lib_name':'waf_api.py', 'lib_path':'./', 
                                    'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                    },
                            "alarm_guide":{'name':'WAF Network Tx_Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WAF 클릭하여 WEB 접속 후 로그인
3. 장애 내역 확인 및 Tx 통계 확인
4. 장애 시, 개발팀 및 WAF 담당자 연락"""},
                            "threshold":[
                                {
                                    "name":"[Warning] WAF Network Tx_Rate Alarm",
                                    "grade":"warning",
                                    "description":"Penta WAF Network Tx_Rate Warning",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"60000000"},{"op":"<", "value":"70000000"}]
                                },
                                {
                                    "name":"[Minor] WAF Network Tx_Rate Alarm",
                                    "grade":"Minor",
                                    "description":"Penta WAF Network Tx_Rate Minor",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"70000000"},{"op":"<", "value":"80000000"}]
                                },
                                {
                                    "name":"[Major] WAF Network Tx_Rate Alarm",
                                    "grade":"Major",
                                    "description":"Penta WAF Network Tx_Rate Major",
                                    "repeat":REAP_M, 
                                    "conditions":["and", {"op":">=", "value":"80000000"},{"op":"<", "value":"90000000"}]
                                },
                                {
                                    "name":"[Critical] WAF Network Tx_Rate Alarm",
                                    "grade":"Critical",
                                    "description":"Penta WAF Network Tx_Rate Critical",
                                    "repeat":REAP_M, 
                                    "conditions":{"op":">=", "value":"90000000"}
                                }
                            ]
                        }
                    ]
                }
                ]
            },
            {'name': 'db', 'visible':'DB', 'description':'WAF DB Monitor',
                 "item":[
                    {
                        "name":"DB UtilRate",
                        'visible':'DB 사용률',
                        "type":"Util",
                        "item_id":"vnf.spec.db_util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"int",
                        "unit":"%",
                        "period":PERF_L,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Penta WAF DB UtilRate",
                        "plugin":{
                                'name':'Penta WAF DB UtilRate', 'type':'file', 
                                'script': plugDir+'/waf/penta/waf_plugin.py',
                                'param_num':'2', 'plugin_param':['db', 'util'], 'description':'Penta WAF DB UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                'lib_name':'waf_api.py', 'lib_path':'./', 
                                'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'WAF DB UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WAF 클릭하여 WEB 접속 후 로그인
3. 장애 내역 확인 및 DB 테이블 상태 확인
4. 장애 시, WAF 담당자 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] WAF DB UtilRate Alarm",
                                "grade":"warning",
                                "description":"Penta WAF DB UtilRate Warning",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] WAF DB UtilRate Alarm",
                                "grade":"Minor",
                                "description":"Penta WAF DB UtilRate Minor",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] WAF DB UtilRate Alarm",
                                "grade":"Major",
                                "description":"Penta WAF DB UtilRate Major",
                                "repeat":REAP_L, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] WAF DB UtilRate Alarm",
                                "grade":"Critical",
                                "description":"Penta WAF DB UtilRate Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    }
                ]
            },
            {'name': 'engine', 'visible':'ENGINE', 'description':'WAF Process ENGINE Monitor',
                 "item":[
                    {
                        "name":"ENGINE CPU_UtilRate",
                        'visible':'ENGINE CPU 사용률',
                        "type":"CPU Util",
                        "item_id":"vnf.spec.engine.cpu_util",
                        "graph_yn": 'y',
                        "realtime_yn": 'y',
                        "statistic_yn": 'y',
                        "data_type":"float",
                        "unit":"%",
                        "period":PERF_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Penta WAF ENGINE CPU_UtilRate",
                        "plugin":{
                                'name':'Penta WAF ENGINE CPU_UtilRate', 'type':'file', 
                                'script': plugDir+'/waf/penta/waf_plugin.py',
                                'param_num':'2', 'plugin_param':['ENGINE', 'CPU_UTIL'], 'description':'Penta WAF ENGINE CPU_UtilRate',
                                'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                'lib_name':'waf_api.py', 'lib_path':'./', 
                                'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'WAF ENGINE CPU_UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WAF 클릭하여 WEB 접속 후 로그인
3. 장애 내역 확인 및 WAF Engine 상태 확인
4. 장애 시, WAF 담당자 연락"""},
                        "threshold":[
                            {
                                "name":"[Warning] WAF ENGINE CPU_UtilRate Alarm",
                                "grade":"warning",
                                "description":"Penta WAF ENGINE CPU_UtilRate Warning",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"75"},{"op":"<", "value":"80"}]
                            },
                            {
                                "name":"[Minor] WAF ENGINE CPU_UtilRate Alarm",
                                "grade":"Minor",
                                "description":"Penta WAF ENGINE CPU_UtilRate Minor",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
                            },
                            {
                                "name":"[Major] WAF ENGINE CPU_UtilRate Alarm",
                                "grade":"Major",
                                "description":"Penta WAF ENGINE CPU_UtilRate Major",
                                "repeat":REAP_M, 
                                "conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
                            },
                            {
                                "name":"[Critical] WAF ENGINE CPU_UtilRate Alarm",
                                "grade":"Critical",
                                "description":"Penta WAF ENGINE CPU_UtilRate Critical",
                                "repeat":REAP_M, 
                                "conditions":{"op":">=", "value":"95"}
                            }
                        ]
                    },
                    {
                        "name":"ENGINE Status",
                        'visible':'ENGINE 상태',
                        "type":"Status",
                        "item_id":"vnf.spec.engine.status",
                        "data_type":"int",
                        "value_type":"status",
                        "period":STAT_M,
                        "history":HIST,
                        "statistic":TRND,
                        "description":"Penta WAF ENGINE Status",
                        "plugin":{
                                'name':'Penta WAF ENGINE Status', 'type':'file', 
                                'script': plugDir+'/waf/penta/waf_plugin.py',
                                'param_num':'2', 'plugin_param':['ENGINE', 'STATUS'], 'description':'Penta WAF ENGINE Status',
                                'lib_type':'file', 'lib_script':plugDir+'/waf/penta/waf_api.py',
                                'lib_name':'waf_api.py', 'lib_path':'./', 
                                'cfg_name':'waf_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_app_id', 'vm_app_passwd']
                                },
                        "alarm_guide":{'name':'WAF ENGINE Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WAF 클릭하여 WEB 접속 후 로그인
3. 장애 내역 확인 및 WAF Engine 상태 확인
4. 장애 시, WAF 담당자 연락"""},
                        "threshold":[
                            {
                                "name":"[Critical] WAF ENGINE Status Alarm",
                                "grade":"critical",
                                "description":"WAF ENGINE Status Critical",
                                "repeat":REAP_L, 
                                "conditions":{"op":"<=", "value":"0"}
                            }
                        ]
                    }
                ]
            }
        ]
    }
    
    return body


