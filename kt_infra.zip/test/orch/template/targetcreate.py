#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys, importlib, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from random import randint

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

PLUGIN_DIR = "/usr/local/plugin"

HIST = "10"
TRND = "180"

URL = "https://%s:5555/target"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def createTemp(argv):
	
	if argv[1] == None or str(argv[1]) == '':
		print '[ERROR] Invalid Orch-m IP-> %s'%str(argv[1])
		return 
	orchmUrl = URL%str(argv[1])
	
	orchmType = str(argv[2]).upper()
	if orchmType != 'TEST' and orchmType != 'REAL' and orchmType != 'SHOW':
		print '[ERROR] Invalid Template Type -> %s, Select TEST, REAL or SHOW.'%(orchmType)
		return 
	
	tempFile = str(argv[3])
	if not os.path.exists( tempFile ):
		print '[ERROR] Invalid Template File -> %s'%(tempFile)
		return
	modName = (tempFile.replace('.py', '')).replace('/', '.')
	
	params = None
	if len(argv) > 4:
		params = argv[4:]
	
	tempMod = importlib.import_module( modName )
	body = tempMod.makeBody(orchmType, params, PLUGIN_DIR, HIST, TRND)
	
	if body != None :
		body['tid'] = "test_%s"%str(randint(1, 1000000))
		print orchmUrl
		print body
		print( callZB( orchmUrl, body ) )


if __name__ == '__main__':
	if len(sys.argv) >= 4:
		createTemp(sys.argv)
	else:
		print 'USAGE: CMD IP [TEST/REAL/SHOW] TEMPLATE PARAMS...'



