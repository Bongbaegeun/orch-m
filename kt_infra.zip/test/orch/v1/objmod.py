#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "https://211.224.204.203:5555/server/item/mod/object"
# URL = "http://211.224.204.248:5555/server/item/mod/object"
# URL = "http://220.123.31.82:5555/server/item/mod/object"
# URL = "https://112.175.253.33:5555/server/item/mod/object"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp

# Object list �� ���������.

def modObject():
	# VDisk UtilRate
	test={
		"tid":'svr-item-mod-obj-1',
		"svr_seq":1934,
		"item_cat_seq":1031, #39, 40, 41
# 		"item_cat_seq":52, #host i/f status
# 		"item_cat_seq":53, #host i/f rx
# 		"item_cat_seq":16, #host i/f tx
# 		"item_cat_seq":1140,
#		"moniteminstanceseq" : 47316
# 		"object_list":["global_mgmt_net", "public_net", "net_office", "net_internet", "net_server"]
# 		"object_list":['/home/onebox/tomcat/bin/bootstrap.jar']
#		"object_list":['eth7']
# 		"object_list":['p2p1', 'p2p2', 'p2p3']
# 		"object_list":[	'authentication','backup','firewall','jobsengine','network','dhcp']
# 		"object_list":[	'python obagent.py', 'rabbitmq-server', '/usr/sbin/mysqld']
# 		"object_list":['zabbix-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
# 		"object_list":['zabbix-agent', 'zabbix-server', 'apache2', 'postgresql', 'onebox-agent']
	}
	
	print( callZB( URL, test ) )


if __name__ == '__main__':
	modObject()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


