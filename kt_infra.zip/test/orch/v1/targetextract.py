#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'

# URL = "http://211.224.204.203:5555/server/del"
URL = "http://211.224.204.248:5555/target/extract"
URL_D = "http://211.224.204.203:5555/target/extract"
URL_S = "http://211.224.204.248:5555/target/extract"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body, encoding='utf-8')
	
	return resp

def extractTarget(sType, targetSeq, fName):
	
	if sType == DEV_SVR:
		url = URL_D
	elif sType == STG_SVR:
		url = URL_S
	else :
		return 
	
	test={
		'tid':'target-extract-1',
		'target_seq':targetSeq
		}
	
	ret = callZB( url, test )
	temp = {"template":ret['response']}
	tempStr = json.dumps(temp, indent=2, ensure_ascii=False)
	
	f = open( str(fName), 'w+' )
	f.write( tempStr )
	f.close()
	os.chmod( fName, 0644 )
	

if __name__ == '__main__':
	if len(sys.argv) >= 3:
		extractTarget(sys.argv[1], int(sys.argv[2]), sys.argv[3])
	else:
		print 'USAGE: CMD [D/S/P] TARGET_SEQ FILE_NAME'
# 	if len(sys.argv) >= 2:
# 		svrNum = int(sys.argv[1])
# 		if svrNum == 1:
# 			delServer1()
# 		elif svrNum == 3:
# 			delServer3()
# 		elif svrNum == 4:
# 			delServer4()
# 	delServer4()
# 	delServer3()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


