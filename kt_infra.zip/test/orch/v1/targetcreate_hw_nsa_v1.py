#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'
RS_SVR = 'RS'
NEW_PRT_SVR = 'NP'

REAL_PLG = 'R'
REAL_FAST_PLG = 'RF'
TEST_PLG = 'T'

# URL = "http://211.224.204.248:5555/target"
URL = "http://211.224.204.203:5555/target"
URL_D = "http://211.224.204.203:5555/target"
URL_S = "http://211.224.204.248:5555/target"
URL_P = "http://211.224.204.222:5555/target"
URL_NP = "http://220.123.31.82:5555/target"
URL_RS = "http://210.183.241.171:5555/target"

PLUGIN_DIR = "/usr/local/plugin"
PLUGIN_TEST_DIR = "/usr/local/plugin/test"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def createTemp(sType, pType):
	HIST = "10"
	TRND = "180"
	
	CRI_P = "10"
	MAJ_P = "30"
	MIN_P = "60"
	WAN_P = "150"
	NOR_P = "300"
	
	if sType == DEV_SVR :
		url = URL_D
	elif sType == STG_SVR :
		url = URL_S
	elif sType == PRT_SVR :
		url = URL_P
	elif sType == NEW_PRT_SVR :
		url = URL_NP
	elif sType == RS_SVR :
		url = URL_RS
	else:
		return
	
	mType = '5150'
	if pType == REAL_PLG :
		pDir = PLUGIN_DIR
		
	elif pType == REAL_FAST_PLG :
		pDir = PLUGIN_DIR
		CRI_P = "2"
		MAJ_P = "5"
		MIN_P = "10"
		WAN_P = "15"
		NOR_P = "20"
	elif pType == TEST_PLG :
		pDir = PLUGIN_TEST_DIR
		mType = 'Test'
	else:
		return
	
	test={
		"tid":'temp-create-1',
		"target_info":{
				'code':'hw', 'type':'svr', 'vendor_code':'nsa', 'model':mType, 
				"name":"NSA SVR", "visible":'NSA 서버', "description":"NSA %s Monitoring"%mType,
				'version':'v1.0', 'target_for':'OneTouch'
			},
		"group":[
			{'name': 'net', 'visible':'네트워크', 'description':'NSA SVR Network',
				 "item":[
					{
						"name":"SVR Connection",
						"visible":'서버 연결 상태',
						"type":"SVR Connection",
						"monitor_method":"simple",
						"zb_type":"ping_check",
						"realtime_yn": 'y',
						"data_type":"int",
						"value_type":"status",
						"period":CRI_P,
						"history":HIST,
						"statistic":TRND,
						"description":"NSA Server Connection",
						"alarm_guide":{'name':'SVR Connection Alarm', 'guide':"""1. One-Box 서버 Ping 확인: "ping $IP"
2. 장애 시, LAN 포트 연결 상태 확인
3. H/W 담당자 및 개발팀 연락 """},
# 						"threshold_zb_yn":"y",
						"threshold":[
							{
								"name":"[Critical] SVR Connection Release Alarm",
								"grade":"Critical",
								"description":"SVR Connection Release",
								"repeat":"1", 
								"conditions":{"op":"<=", "value":"0"}
							}
						]
					},
					{
						"name":"ZBA Connection",
						'visible':'ZBA 연결상태',
						"type":"ZBA Connection",
						"monitor_method":"simple",
						"zb_type":"tcp_port_10050_check",
						"realtime_yn": 'y',
						"data_type":"int",
						"value_type":"status",
						"period":CRI_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Zabbix Agent Port Check",
						"alarm_guide":{'name':'ZBA Connection Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Zabbix Agent 프로세스 확인: "service zabbix-agent status"
4. Down 상태일 경우 재기동: "service zabbix-agent start" """},
						"threshold":[
							{
								"name":"[Critical] ZBA Connection Release Alarm",
								"grade":"Critical",
								"description":"ZBA Connection Release",
								"repeat":"1", 
								"conditions":{"op":"<=", "value":"0"}
							}
						]
					}
				]
			},
			{'name': 'item', "visible":'감시항목', 'description':'Server Item',
				'item':[
					{
						"name":"Item Inactive",
						"visible":'비활성 감시항목', 
						"type":"Inactive",
						"monitor_method":"trap",
						"zb_type":"item_inactive",
						"realtime_yn": 'y',
						"statistic_yn": 'y',
						"data_type":"float",
						"period":MIN_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Server Item Inactive Count",
						"alarm_guide":{'name':'Item Inactive Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 감시 로그 확인: " tail -fn 500 /var/log/zabbix-agent/*.log ", " tail -fn 500 /var/log/zabbix-agent/plugin/*.log "
4. Zabbix 서버 연결 상태 확인: "nc -z $ZABBIX_SERVER_IP 10051"
5. 서버 담당자 연락"""},
						"threshold":[
							{
								"name":"[Warning] SVR Item Inactive Alarm",
								"grade":"warning",
								"description":"SVR Item Inactive Warning",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"20"},{"op":"<", "value":"30"}]
							},
							{
								"name":"[Minor] SVR Item Inactive Alarm",
								"grade":"minor",
								"description":"SVR Item Inactive Minor",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"30"},{"op":"<", "value":"40"}]
							},
							{
								"name":"[Major] SVR Item Inactive Alarm",
								"grade":"major",
								"description":"SVR Item Inactive Major",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"40"},{"op":"<", "value":"50"}]
							},
							{
								"name":"[Critical] SVR Item Inactive Alarm",
								"grade":"Critical",
								"description":"SVR Item Inactive Critical",
								"repeat":"1", 
								"conditions":{"op":">=", "value":"50"}
							}
						]
					}
				]
			}
		]
	}
	
	print( callZB( url, test ) )




if __name__ == '__main__':
	if len(sys.argv) >= 3:
		createTemp(sys.argv[1], sys.argv[2])
	else:
		print 'USAGE: CMD [D/S/P/NP/RS] [R/T]'
# 	createTemp()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


