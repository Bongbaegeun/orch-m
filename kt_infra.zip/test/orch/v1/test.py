#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.203:5555/test"
URL_A = "http://211.224.204.203:5555/perf/test"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def test():
	# ob1
	test={
		'tid':'svr-add-1',
		'svr_info': {'seq':'16', 'uuid':'TJB-SVR-UUID-005', 'name':'TJB.01', 
					 'ip':'211.224.204.205', 'mon_port':'10050', 'desc':'TJB Server #1'},
		'target_info': [ 
					{'target_seq':'1', 'plugin_path':'/usr/plugin/hw'}, 
					{'target_seq':'2', 'plugin_path':'/usr/plugin/os'},
					{'target_seq':'3', 'plugin_path':'/usr/plugin/vim', "vim_id": "admin", "vim_passwd": "ohhberry3333", "vim_domain": "default", "vim_mgmt_net": "ext-net", 'url':"http://211.224.204.207:35357/v3/auth/tokens"}, 
					{'target_seq':'4', 'plugin_path':'/usr/plugin/utm', 'vm_ip':'192.168.2.14', 'auth': { 'key': '/home/ohhara/plugin/vutm/id_rsa'}}, 
					{'target_seq':'5', 'plugin_path':'/usr/plugin/waf', 'vm_ip':'192.168.10.41', 'auth': { 'id':'admin', 'passwd':'wafpenta!23' }} 
					],
		'item_params': [
					{'discovery_seq': '2', 'params':['em1', 'em2', 'em3', 'em4', 'br0']},
					{'discovery_seq': '3', 'params':['/']},
					{'discovery_seq': '4', 'params':['/usr/sbin/mysqld', 'ob_agent.py']},
					{'discovery_seq': '5', 'params':['nova-api', "nova-conductor", "nova-compute", "nova-scheduler",
                     "nova-cert", "nova-consoleauth", "nova-novncproxy"]},
					{'discovery_seq': '7', 'params':['vUTM', 'waf']},
					{'discovery_seq': '11', 'params':['/']},
					{'discovery_seq': '14', 'params':['jobsengine']},
					{'discovery_seq': '15', 'params':['eth0', 'eth1']},
					]
		}
	
	print( callZB( URL, test ) )

def plugin():
	# ob1
	test={
		'tid':'svr-add-1',
# 		'svr_info': {'seq':'1', 'uuid':'TEST-SVR-UUID-001', 'name':'Forbiz.01', 
# 					 'ip':'211.224.204.207', 'mon_port':'10050', 'desc':'Forbiz Server #1'},
		'svr_info': {'seq':'16', 'uuid':'TJB-SVR-UUID-005', 'name':'TJB.01', 
					 'ip':'211.224.204.205', 'mon_port':'10050', 'desc':'TJB Server #1'},
		'target_info': [ 
					{'target_seq':'1', 'plugin_path':'/usr/plugin/hw'}, 
					{'target_seq':'2', 'plugin_path':'/usr/plugin/os', 
						'cfg':{ 
							"svr_proc":[ "/usr/sbin/mysqld", "obagent.py" ], 
							"svr_svc":[ "nova-api", "nova-conductor", "nova-compute", "nova-scheduler",
									"nova-cert", "nova-consoleauth", "nova-novncproxy", "neutron-server",
									"neutron-plugin-openvswitch-agent", "neutron-dhcp-agent", "neutron-l3-agent",
									"neutron-metadata-agent", "glance-api", "glance-registry", "heat-api", 
									"heat-engine", "apache2", "ntp", "ssh", "zabbix-agent" ]
							}
					},
					{'target_seq':'3', 'plugin_path':'/usr/plugin/vim', 
						'cfg':{
							'vim_auth_url':"http://211.224.204.207:35357/v3/auth/tokens",
							"vim_id": "admin", 
							"vim_passwd": "ohhberry3333", 
							"vim_domain": "default", 
							"vim_mgmt_net": "global_mgmt_net", 
							'vim_vm':[ 'vUTM', 'vWAF' ],
							"vim_net":['net_server', 'net_blue', 'net_local', 'public_net', 'net_office', 'net_internet', 'global_mgmt_net'], 
							"vim_port":['168b4827-456d-4c07-bba4-6839cda28f78', 'fa:16:3e:a9:f0:c2', 'd1864250-2c07-4ccc-afb0-f8db183be84b'], 
							"vim_router":['global_mgmt_router'], 
							"vim_image":['vUTM_0621', 'waf_NL_20150922_02_proxy.img']
							}
					},
					{'target_seq':'4', 'plugin_path':'/usr/plugin/utm', 
						'cfg':{
							'vm_ip':'192.168.2.227', 
							'vm_proc': ['jobsengine', 'syslog-ng'],
							'vm_job': ['jobsengine', 'snort'],
							'vm_net': ['eth0', 'eth1', 'eth2', 'eth3', 'eth4', 'br0', 'br1', 'br2'],
							'vm_fs': ['/', '/var', '/var/log']
							}
					}, 
					{'target_seq':'5', 'plugin_path':'/usr/plugin/waf', 
						'cfg':{
							'vm_ip': '192.168.10.9',
							'vm_app_id': 'admin',
							'vm_app_passwd': 'wafpenta!23',
							'svr_net': ['eth0', 'eth1']
						}
					}
					],
		'item_params': [
					{'discovery_seq': '2', 'params':['em1', 'em2', 'em3', 'em4', 'br0']},
					{'discovery_seq': '3', 'params':['/']},
					{'discovery_seq': '4', 'params':['/usr/sbin/mysqld', 'ob_agent.py']},
					{'discovery_seq': '5', 'params':['nova-api', "nova-conductor", "nova-compute", "nova-scheduler",
                     "nova-cert", "nova-consoleauth", "nova-novncproxy"]},
					{'discovery_seq': '7', 'params':['vUTM', 'waf']},
					{'discovery_seq': '11', 'params':['/']},
					{'discovery_seq': '14', 'params':['jobsengine']},
					{'discovery_seq': '15', 'params':['eth0', 'eth1']},
					]
		}
	
	print( callZB( URL, test ) )


def perfGraph():
	test={"stime":"2015-11-16 00:00:00",
		"etime":"2015-11-16 23:59:59",
		"itemseq":"1",
		"datatype":"histroy",
		"svr_uuid":"TEST-SVR-UUID-001"}
	
	print( callZB( URL_A, test ) )


if __name__ == '__main__':
	plugin()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


