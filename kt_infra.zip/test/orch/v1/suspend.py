#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.203:5555/monitor/suspend"

def callZB( url, reqBody ):
    
    http_client = httpclient.HTTPClient()
    h = HTTPHeaders(HEADER)
    strBody = json.dumps( reqBody )
    _request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=30 )
    
    response = http_client.fetch( request=_request )
    http_client.close()
    
    resp = json.loads(response.body)
    
    return resp


def suspend(_type):
    # VDisk UtilRate
    if _type == 'VNF':
        tList = [{'target_seq':290},{'target_seq':297}]
    elif _type == 'ONEBOX':
        tList = [
#                  {'target_code': 'hw',
#                     'target_type': 'svr',
#                     'vendor_code': 'hp',
#                     'target_model': 'DL XXX'},
#                  {  'target_code': 'os',
#                     'target_type': 'linux',
#                     'vendor_code': 'ubuntu',
#                     'target_model': 'trusty 14.04'},
#                  {  'target_code': 'vim',
#                     'target_type': 'openstack',
#                     'vendor_code': 'openstack',
#                     'target_model': 'kilo'},{'target_seq':290},{'target_seq':297}
                 ]
    else:
        return
    
    test={
        "tid":'monitor-suspend-1',
        "type":_type,
        "svr_info":{"seq":16},
#         "svr_info":{"seq":20},
        'target_info': tList
    }
    
    print( callZB( URL, test ) )


if __name__ == '__main__':
    if len(sys.argv) >= 2:
        suspend(str(sys.argv[1]).upper())
#     if len(sys.argv) >= 3:
#         faultType = str(sys.argv[1]).upper()
#         if str(faultType).upper() == 'CPU':
#             faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
#         elif str(faultType).upper() == 'UTM':
#             faultUTMNet(int(sys.argv[2]))


