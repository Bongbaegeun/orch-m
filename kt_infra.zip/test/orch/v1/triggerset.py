#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.203:5555/server/item/mod/threshold"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def modTrigger():
	# VDisk UtilRate
	test={
		"tid":'svr-item-mod-thres-1',
		"item_seq":7085,
		"threshold":{
			"operator":"le",
			"repeat":2,
			"grade_info":[
				{'grade':'critical', 'value':0}
			]
		}
	}
	
	print( callZB( URL, test ) )


def modTriggerProto():
	# VRouter-Status
	test={
		"tid":'svr-item-mod-thres-1',
		"item_seq":3130,
		"threshold":{
			"operator":"ge",
			"repeat":2,
			"grade_info":[
				{'grade':'minor', 'value':5},
				{'grade':'major', 'value':6}
			]
		}
	}
	
	print( callZB( URL, test ) )


if __name__ == '__main__':
	modTrigger()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


