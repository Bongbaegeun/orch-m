#!/usr/bin/python
#-*- coding: utf-8 -*-

import commands as cmd
from time import sleep
import logging.handlers, os
from ctypes import cast

class Singleton(object):
    _instance = None
    
    def __new__(self, *args, **kwargs):
        if not isinstance( self._instance, self ) :
            self._instance = object.__new__(self, *args, **kwargs)
        return self._instance

class Logger(Singleton):
    
    def __init__(self, logName, logDir='./', logFile='myLogger.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG):
        self._logger = logging.getLogger( logName )
        logging.getLogger( logName )
        # 포매터를 만든다.
        formatter = logging.Formatter( '[%(asctime)s] %(levelname)s: %(message)s' )
        
        # 스트림과 파일로 로그를 출력하는 핸들러를 각각 만든다.
        fileHandler = logging.handlers.RotatingFileHandler( logDir + "/" + logFile, maxBytes=logFileMaxByte, backupCount=logBackupCnt )
#         streamHandler = logging.StreamHandler()
        
        # 각 핸들러에 포매터를 지정한다.
        fileHandler.setFormatter( formatter )
#         streamHandler.setFormatter( formatter )
            
        # 위에서 만든 로거 인스턴스에 스트림 핸들러화 파일핸들러를 붙인다.
        self._logger.addHandler( fileHandler )
#         self._logger.addHandler( streamHandler )
        
        # 로그 레벨 설정
        self._logger.setLevel( logLevel )
        
        os.chmod( fileHandler.baseFilename, 0666 )
    def instance(self):
        return self._logger

KEY_FILE="/var/onebox/key/zb_rsa" 

logger = Logger('chk_with', './', 'chk_with.log').instance()

def execute():
	try:
		ip = '183.98.121.151'
		_cmd = "ping %s -i 1 -c 1 -W 1 | grep received"%ip
		status, output = cmd.getstatusoutput( _cmd )
		_recv = str(output).split(',')[1]
		_recvNum = int(str(_recv).split('received')[0].strip())
		if _recvNum < 1:
			logger.error( ip + ">> " + str(output) )
	except Exception, e:
		logger.error( ip + ">> " + str(output) )
		logger.critical(e)
	

  
        


class SPC(object):
    
    def __init__(self):
        pass

    def __str__(self):
        dd = dict(self.__dict__)
        d = {}
        for k in dd.keys():
            if type(dd[k]) == list or type(dd[k]) == tuple :
                d[k] = []
                for t in dd[k]:
                    print isinstance(t, SPC)
                    if isinstance(t, SPC) :
                        d[k].append(t.__dict__)
                    else :
                        d[k].append(t)
            elif isinstance(dd[k], SPC) :
                d[k] = dd[k].__dict__
            else:
                d[k] = dd[k]
        
        return str(d)
    
    
class A(SPC):
    def __init__(self, asdf):
        self.a=None
        self.b=None
        pass
    



class B(SPC):
    def __init__(self, a):
        self.b=[a,a,a]
        self.n='bb'



def makeA():
    aa = A(1)
    aa.a=1
    aa.b='b'
    return aa

def relayA(aa):
    return aa

def setA():
    
    aa = makeA()
    
    aaa = A
    aaa = relayA(aa)
    
    
    import copy
    bb = copy.copy(aa)
    print bb.a
    print bb
    
    print ''
    
    b = B(aaa)
    print b
    

if __name__ == '__main__':
# 	while True:
# 		execute()
# 		sleep(1)
    setA()





