#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'
MOK_SVR = 'MOK'

# URL = "http://211.224.204.203:5555/server/del"
URL = "https://211.224.204.248:5555/server/del"
URL_D = "https://211.224.204.203:5555/server/del"
URL_S = "https://211.224.204.248:5555/server/del"
URL_P = "https://211.224.204.222:5555/server/del"
URL_MOK = "https://192.168.123.13:5555/server/del"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp

def delServer(sType, ctrlName):
	
	if sType == DEV_SVR and ctrlName == 'ORCH_SVR':
		url = URL_D
		svrIP = '211.224.204.203'
		svrSeq = 68
		svrUuid = 'system-orch-svr-01'
		obID = 'System.Orch.Svr.01'
  
	elif sType == DEV_SVR and ctrlName == 'ORCH_WEB':
		url = URL_D
		svrIP = '211.224.204.209'
		svrSeq = 794
		svrUuid = 'system-orch-web-01'
		obID = 'Orch.Web.01'
  
	elif sType == DEV_SVR and ctrlName == 'ZB_SVR':
		url = URL_D
		svrIP = '211.224.204.208'
		svrSeq = 1
		svrUuid = 'system-zabbix-svr-01'
		obID = 'ZBX.SVR.01'
  
	elif sType == DEV_SVR and ctrlName == 'XMS':
		url = URL_D
		svrIP = '211.224.204.207'
		svrSeq = 71
		svrUuid = 'system-xms-svr-01'
		obID = 'System.XMS.Svr.01'
	elif sType == STG_SVR and ctrlName == 'ORCH_CTRL':
		url = URL_S
		svrIP = '211.224.204.248'
		svrSeq = 1
		svrUuid = 'system-orch-ctrl-01'
		obID = 'System.Orch.Ctrl.01'
	elif sType == STG_SVR and ctrlName == 'ORCH_DB':
		url = URL_S
		svrIP = '211.224.204.249'
		svrSeq = 3
		svrUuid = 'system-orch-db-01'
		obID = 'System.Orch.Db.01'
	elif sType == STG_SVR and ctrlName == 'ORCH_WEB':
		url = URL_S
		svrIP = '211.224.204.247'
		svrSeq = 2
		svrUuid = 'system-orch-web-01'
		obID = 'System.Orch.Web.01'
	elif sType == STG_SVR and ctrlName == 'ZB_SVR':
		url = URL_S
		svrIP = '211.224.204.250'
		svrSeq = 4
		svrUuid = 'system-zabbix-svr-01'
		obID = 'System.Zabbix.Svr.01'
	elif sType == STG_SVR and ctrlName == 'ZB_DB':
		url = URL_S
		svrIP = '211.224.204.211'
		svrSeq = 5
		svrUuid = 'system-zabbix-db-01'
		obID = 'System.Zabbix.Db.01'
	elif sType == STG_SVR and ctrlName == 'XMS':
		url = URL_S
		svrIP = '211.224.204.244'
		svrSeq = 6
		svrUuid = 'system-xms-svr-01'
		obID = 'System.XMS.Svr.01'
	elif sType == PRT_SVR and ctrlName == 'ORCH_SVR':
		url = URL_P
		svrIP = '211.224.204.222'
		svrSeq = 46
		svrUuid = 'system-orch-svr-01'
		obID = 'System.Orch.Svr.01'
	elif sType == PRT_SVR and ctrlName == 'ORCH_WEB':
		url = URL_P
		svrIP = '211.224.204.230'
		svrSeq = 47
		svrUuid = 'system-orch-web-01'
		obID = 'System.Orch.Web.01'
	elif sType == PRT_SVR and ctrlName == 'ETC_SVR':
		url = URL_P
		svrIP = '211.224.204.133'
		svrSeq = 49
		svrUuid = 'system-etc-svr-01'
		obID = 'System.Etc.Svr.01'
	elif sType == PRT_SVR and ctrlName == 'XMS':
		url = URL_P
		svrIP = '211.224.204.148'
		svrSeq = 50
		svrUuid = 'system-xms-svr-01'
		obID = 'System.XMS.Svr.01'
	elif sType == MOK_SVR and ctrlName == 'ORCH_WEB':
		url = URL_MOK
		svrIP = '192.168.123.10'
		svrSeq = 3
		svrUuid = 'system-orch-web-01'
		obID = 'ORCH.WEB.01'
	elif sType == MOK_SVR and ctrlName == 'ZB_DB':
		url = URL_MOK
		svrIP = '192.168.123.18'
		svrSeq = 2
		svrUuid = 'system-zbx-db-01'
		obID = 'ZBX.DB.01'
	elif sType == MOK_SVR and ctrlName == 'XMS_WEB':
		url = URL_MOK
		svrIP = '112.175.253.208'
		svrSeq = 7
		svrUuid = 'system-xms-web-01'
		obID = 'XMS.WEB.01'
	elif sType == MOK_SVR and ctrlName == 'XMS_SVR':
		url = URL_MOK
		svrIP = '192.168.123.26'
		svrSeq = 8
		svrUuid = 'system-xms-svr-01'
		obID = 'XMS.SVR.01'
	else :
		print 'USAGE: CMD [D/S/P/MOK] CTRL_SVR_NAME[ORCH_SVR/ORCH_CTRL/ORCH_DB/ORCH_WEB/ZB_SVR/ZB_CTRL/ZB_DB/XMS/XMS_WEB/XMS_SVR/ETC_SVR]'
		return
	
	test={
		'tid':'test-ctrl-svr-del-'+str(randint(0, 10000)),
		'svr_info': {'seq':svrSeq, 'uuid':svrUuid, 'onebox_id':obID, 'ip':svrIP}
		}
	
	print( callZB( url, test ) )




if __name__ == '__main__':
	if len(sys.argv) >= 3:
		delServer(sys.argv[1], sys.argv[2])
	else:
		print 'USAGE: CMD [D/S/P/MOK] CTRL_SVR_NAME[ORCH_SVR/ORCH_CTRL/ORCH_DB/ORCH_WEB/ZB_SVR/ZB_CTRL/ZB_DB/XMS/XMS_WEB/XMS_SVR/ETC_SVR]'

# 	if len(sys.argv) >= 2:
# 		svrNum = int(sys.argv[1])
# 		if svrNum == 1:
# 			delServer1()
# 		elif svrNum == 3:
# 			delServer3()
# 		elif svrNum == 4:
# 			delServer4()
# 	delServer4()
# 	delServer3()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


