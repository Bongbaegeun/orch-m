#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.203:5555/fault"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=1 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def faultOsCPU(isProblem, grade):
	
	if isProblem:
		status = 1
		problem = 'PROBLEM'
	else:
		status = 0
		problem = 'OK'
	
	if grade == 0 :
		grd = 'NORMAL'
		val = '0.9 job'
	elif grade == 1:
		grd = 'INFO'
		val = '1.2 job'
	elif grade == 2:
		grd = 'WARNING'
		val = '3.2 job'
	elif grade == 3:
		grd = 'MINOR'
		val = '4.2 job'
	elif grade == 4:
		grd = 'MAJOR'
		val = '5.2 job'
	elif grade == 5:
		grd = 'CRICITAL'
		val = '6.2 job'
	else:
		grd = 'UNKNOWN'
		val = '0 job'
	
	
	test={	"to":URL,
			"subject":"[%s] CPU Load -> %s"%(grd, problem),
			"body":{
				"host":{
			  	"name": "TEST-SVR-UUID-001",
			  	"visible": "OneBox03",
			  	"ip": "211.224.204.207"
			  },
			"item":[
			 	{"id": "25341", "key":"2.cpu.load", "name":"CPU load", "value":val, "desc":"", "last_value": val, "last_func":val, "log_src": "*UNKNOWN*"},
			  	{"id": "25341", "key":"2.cpu.load", "name":"CPU load", "value":val, "desc":""}
				],
			"event":{
			  "id": "62898", "status":"OK", "value": "0", "age": "0m", "date": datetime.now().strftime("%Y.%m.%d"), "time": datetime.now().strftime("%H:%M:%S")
			  },
			"trigger":{
			  "id": "13650", "name":"[%s] CPU Load"%grd, "template":"2. OS temp", "status":problem, "status_code":str(status), "grade":grd, "grade_code":str(grade), "desc":"dddd"
			  }
			}
		}
	
	print( callZB( URL, test ) )


def faultUTMNet(isProblem):
	
	if isProblem:
		status = 1
		problem = 'PROBLEM'
		grd = 'CRICITAL'
		val = '0'
		grade = 5
	else:
		status = 0
		problem = 'OK'
		grd = 'CRICITAL'
		val = '1'
		grade = 5
	
	test={	"to":URL,
			"subject":"[%s] UTM Net Status -> %s"%(grd, problem),
			"body":{
				"host":{
			  	"name": "TEST-SVR-UUID-001",
			  	"visible": "OneBox03",
			  	"ip": "211.224.204.207"
			  },
			"item":[
			 	{"id": "25341", "key":"4.net.status[eth4]", "name":"Net Status", "value":val, "desc":"", "last_value": val, "last_func":val, "log_src": "*UNKNOWN*"},
			  	{"id": "25341", "key":"4.net.status[eth4]", "name":"Net Status", "value":val, "desc":""}
				],
			"event":{
			  "id": "62898", "status":"OK", "value": "0", "age": "0m", "date": datetime.now().strftime("%Y.%m.%d"), "time": datetime.now().strftime("%H:%M:%S")
			  },
			"trigger":{
			  "id": "13650", "name":"[%s] UTM Net status"%grd, "template":"2. OS temp", "status":problem, "status_code":str(status), "grade":grd, "grade_code":str(grade), "desc":"dddd"
			  }
			}
		}
	
	print( callZB( URL, test ) )






if __name__ == '__main__':
	if len(sys.argv) >= 3:
		faultType = str(sys.argv[1]).upper()
		if str(faultType).upper() == 'CPU':
			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
		elif str(faultType).upper() == 'UTM':
			faultUTMNet(int(sys.argv[2]))


