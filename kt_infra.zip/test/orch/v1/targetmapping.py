#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.203:5555/target/mapping"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def getTarget():
	# VDisk UtilRate
	test={
		"tid":'target-create-1',
		"vdud_list":[
			{"vdud_seq":107, "vdud_type":"UTM", "vdud_vendor":"olleh", "vdud_version":"2"},
			{"vdud_seq":108, "vdud_type":"WAF", "vdud_vendor":"pentas", "vdud_version":"1"},
		]
	}
	
	print( callZB( URL, test ) )


if __name__ == '__main__':
	getTarget()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


