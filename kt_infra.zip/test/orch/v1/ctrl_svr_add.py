#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from random import randint

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'
NEW_PRT_SVR = 'NP'
MOK = 'MOK'

REAL_PLG = 'R'
TEST_PLG = 'T'

# URL = "http://211.224.204.203:5555/server"
URL = "https://211.224.204.248:5555/server"

URL_D = "https://211.224.204.203:5555/server"
URL_S = "https://211.224.204.248:5555/server"
URL_P = "https://211.224.204.222:5555/server"
URL_NP = "https://220.123.31.82:5555/server"
URL_MOK = "https://192.168.123.13:5555/server"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, 
				client_cert="/var/onebox/key/client_orch.crt",
				client_key="/var/onebox/key/client_orch.key",
						body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def oneTouchOB(sType, ctrlName):
	
	if sType == DEV_SVR and ctrlName == 'ORCH_SVR':
		url = URL_D
		svrIP = '211.224.204.203'
		svrInfo = {'seq':794, 'uuid':'system-orch-svr-01', 'onebox_id':'System.Orch.Svr.01', 'name':'Orch.Svr.01', 
 					 'ip':svrIP, 'desc':'Orchestrator Server(Ctrl+DB) #01', 'service_number':'Ctrl_svr_add'+str(randint(0, 10000))   }
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['postgresql', 'mysql', 'zabbix-agent', 'onebox-agent']
		procList = ['python orchm.py', 'python ./obord.py', 'ZabbixAPIGateway.jar', 'MCSAgent']
		netList = ['eth0']

		
	elif sType == DEV_SVR and ctrlName == 'ORCH_WEB':
		url = URL_D
		svrIP = '211.224.204.209'
		svrInfo = {'seq':798, 'uuid':'system-orch-web-01', 'onebox_id':'Orch.Web.01', 'name':'Orch.Web.01', 
 					 'ip':svrIP, 'desc':'Orchestrator Web Server #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-agent', 'onebox-agent']
		procList = ['tomcat']
		netList = ['eth0']


		
	elif sType == DEV_SVR and ctrlName == 'ZB_SVR':
		url = URL_D
		svrIP = '211.224.204.208'
		svrInfo = {'seq':1, 'uuid':'system-zabbix-svr-01', 'onebox_id':'ZBX.SVR.01', 'name':'ZBX.SVR.01', 
 					 'ip':svrIP, 'desc':'Zabbix Server(Ctrl+DB) #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'centos'
		oTargetModel = '7.X'
		svcList = ['zabbix-server', 'postgresql', 'apache2', 'zabbix-agent']
		procList = ['onebox-agent']
		netList = ['enp3s0f0']
		
	elif sType == DEV_SVR and ctrlName == 'XMS':
		url = URL_D
		svrIP = '211.224.204.207'
		svrInfo = {'seq':71, 'uuid':'system-xms-svr-01', 'onebox_id':'System.XMS.Svr.01', 'name':'XMS.Svr.01', 
 					 'ip':svrIP, 'desc':'XMS Server(Ctrl+DB) #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'centos'
		oTargetModel = '6.X'
		svcList = ['mysql', 'zabbix-agent']
		procList = ['tomcat', 'onebox-agent']
		netList = ['eth1']
	elif sType == STG_SVR and ctrlName == 'ORCH_CTRL':
		url = URL_S
		svrIP = '211.224.204.248'
		svrInfo = {'seq':1, 'uuid':'system-orch-ctrl-01', 'onebox_id':'System.Orch.Ctrl.01', 'name':'Orch.Ctrl.01', 
 					 'ip':svrIP, 'desc':'Orchestrator Ctrl #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-agent', 'onebox-agent']
		procList = ['python orchm.py', 'python ./obord.py', 'ZabbixAPIGateway.jar', 'MCSAgent']
		netList = ['eth1']
		
	elif sType == STG_SVR and ctrlName == 'ORCH_DB':
		url = URL_S
		svrIP = '211.224.204.249'
		svrInfo = {'seq':3, 'uuid':'system-orch-db-01', 'onebox_id':'System.Orch.Db.01', 'name':'Orch.DB.01', 
 					 'ip':svrIP, 'desc':'Orchestrator DB #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['postgresql', 'mysql', 'zabbix-agent', 'onebox-agent']
		procList = []
		netList = ['eth1']
	elif sType == STG_SVR and ctrlName == 'ORCH_WEB':
		url = URL_S
		svrIP = '211.224.204.247'
		svrInfo = {'seq':2, 'uuid':'system-orch-web-01', 'onebox_id':'System.Orch.Web.01', 'name':'Orch.Web.01', 
 					 'ip':svrIP, 'desc':'Orchestrator Web Server #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-agent', 'onebox-agent']
		procList = ['tomcat']
		netList = ['eth1']
	elif sType == STG_SVR and ctrlName == 'ZB_SVR':
		url = URL_S
		svrIP = '211.224.204.250'
		svrInfo = {'seq':4, 'uuid':'system-zabbix-svr-01', 'onebox_id':'System.Zabbix.Svr.01', 'name':'Zabbix.Svr.01', 
 					 'ip':svrIP, 'desc':'Zabbix SVR #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-server', 'apache2', 'zabbix-agent', 'onebox-agent', 'postgresql']
		procList = []
		netList = ['eth1']
	elif sType == STG_SVR and ctrlName == 'ZB_DB':
		url = URL_S
		svrIP = '211.224.204.211'
		svrInfo = {'seq':5, 'uuid':'system-zabbix-db-01', 'onebox_id':'System.Zabbix.Db.01', 'name':'Zabbix.DB.01', 
 					 'ip':svrIP, 'desc':'Zabbix DB #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['postgresql', 'apache2', 'zabbix-agent', 'onebox-agent']
		procList = []
		netList = ['eth1']
	elif sType == STG_SVR and ctrlName == 'XMS':
		url = URL_S
		svrIP = '211.224.204.244'
		svrInfo = {'seq':6, 'uuid':'system-xms-svr-01', 'onebox_id':'System.XMS.Svr.01', 'name':'XMS.Svr.01', 
 					 'ip':svrIP, 'desc':'XMS Server(Ctrl+DB) #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'centos'
		oTargetModel = '6.X'
		svcList = ['mysql', 'zabbix-agent']
		procList = ['tomcat', 'onebox-agent']
		netList = ['eth1']
	elif sType == PRT_SVR and ctrlName == 'ORCH_SVR':
		url = URL_P
		svrIP = '211.224.204.222'
		svrInfo = {'seq':46, 'uuid':'system-orch-svr-01', 'onebox_id':'System.Orch.Svr.01', 'name':'Orch.Svr.01', 
 					 'ip':svrIP, 'desc':'Orch Server #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-agent', 'onebox-agent']
		procList = ['python orchm.py', 'python ./obord.py', 'ZabbixAPIGateway.jar', 'MCSAgent']
		netList = ['em2']
	elif sType == PRT_SVR and ctrlName == 'ORCH_WEB':
		url = URL_P
		svrIP = '211.224.204.230'
		svrInfo = {'seq':47, 'uuid':'system-orch-web-01', 'onebox_id':'System.Orch.Web.01', 'name':'Orch.Web.01', 
 					 'ip':svrIP, 'desc':'Orch Web #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-agent', 'onebox-agent']
		procList = ['tomcat']
		netList = ['eth0']
	elif sType == PRT_SVR and ctrlName == 'ETC_SVR':
		url = URL_P
		svrIP = '211.224.204.133'
		svrInfo = {'seq':49, 'uuid':'system-etc-svr-01', 'onebox_id':'System.Etc.Svr.01', 'name':'Etc.Svr.01', 
 					 'ip':svrIP, 'desc':'ETC Server(ZB+OrchDB) #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-server', 'apache2', 'postgresql', 'mysql', 'zabbix-agent', 'onebox-agent']
		procList = []
		netList = ['em1']
	elif sType == PRT_SVR and ctrlName == 'XMS':
		url = URL_P
		svrIP = '211.224.204.148'
		svrInfo = {'seq':50, 'uuid':'system-xms-svr-01', 'onebox_id':'System.XMS.Svr.01', 'name':'XMS.Svr.01', 
 					 'ip':svrIP, 'desc':'XMS Server(Ctrl+DB) #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'centos'
		oTargetModel = '6.X'
		svcList = ['mysql', 'zabbix-agent']
		procList = ['tomcat', 'onebox-agent']
		netList = ['eth1']
	elif sType == NEW_PRT_SVR and ctrlName == 'ORCH_SVR':
		url = URL_NP
		svrIP = '220.123.31.82'
		svrInfo = {'seq':2, 'uuid':'system-orch-svr-01', 'onebox_id':'System.Orch.Svr.01', 'name':'Orch.Svr.01', 
 					 'ip':svrIP, 'desc':'Orch Server #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-agent', 'onebox-agent', 'mysql', 'postgresql']
		procList = ['python orchm.py', 'python ./obord.py', 'ZabbixAPIGateway.jar', 'MCSAgent', 'tomcat']
		netList = ['em1']
	elif sType == NEW_PRT_SVR and ctrlName == 'ETC_SVR':
		url = URL_NP
		svrIP = '220.123.31.83'
		svrInfo = {'seq':3, 'uuid':'system-etc-svr-01', 'onebox_id':'System.Etc.Svr.01', 'name':'Etc.Svr.01', 
 					 'ip':svrIP, 'desc':'ETC Server(ZB) #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-server', 'apache2', 'postgresql', 'mysql', 'zabbix-agent', 'onebox-agent']
		procList = []
		netList = ['em1']
	elif sType == NEW_PRT_SVR and ctrlName == 'XMS':
		url = URL_NP
		svrIP = '220.123.31.84'
		svrInfo = {'seq':4, 'uuid':'system-xms-svr-01', 'onebox_id':'System.XMS.Svr.01', 'name':'XMS.Svr.01', 
 					 'ip':svrIP, 'desc':'XMS Server(Ctrl+DB) #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'centos'
		oTargetModel = '6.X'
		svcList = ['mysql', 'zabbix-agent']
		procList = ['tomcat', 'onebox-agent']
		netList = ['eth1']
	elif sType == MOK and ctrlName == 'ORCH_WEB':
		url = URL_MOK
		svrIP = '192.168.123.10'
		svrInfo = {'seq':3, 'uuid':'system-orch-web-01', 'onebox_id':'ORCH.WEB.01', 'name':'ORCH.WEB.01', 
 					 'ip':svrIP, 'desc':'ORCH WEB #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-agent', 'onebox-agent']
		procList = ['tomcat']
		netList = ['bond0']
	elif sType == MOK and ctrlName == 'ORCH_CTRL':
		url = URL_MOK
		svrIP = '192.168.123.13'
		svrInfo = {'seq':5, 'uuid':'system-orch-ctrl-01', 'onebox_id':'ORCH.CTRL.01', 'name':'ORCH.CTRL.01', 
 					 'ip':svrIP, 'desc':'ORCH CTRL #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-agent', 'onebox-agent']
		procList = ['python orchm.py', 'python ./obord.py', 'ZabbixAPIGateway.jar', 'MCSAgent']
		netList = ['bond0']
	elif sType == MOK and ctrlName == 'ORCH_DB':
		url = URL_MOK
		svrIP = '192.168.123.14'
		svrInfo = {'seq':4, 'uuid':'system-orch-db-01', 'onebox_id':'ORCH.DB.01', 'name':'ORCH.DB.01', 
 					 'ip':svrIP, 'desc':'ORCH DB #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['postgresql', 'mysql', 'zabbix-agent', 'onebox-agent']
		procList = []
		netList = ['bond0']
	elif sType == MOK and ctrlName == 'ZB_SVR':
		url = URL_MOK
		svrIP = '192.168.123.17'
		svrInfo = {'seq':1, 'uuid':'system-zbx-svr-01', 'onebox_id':'ZBX.SVR.01', 'name':'ZBX.SVR.01', 
 					 'ip':svrIP, 'desc':'ZBX SVR #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['zabbix-server', 'apache2', 'zabbix-agent', 'onebox-agent']
		procList = []
		netList = ['bond0']
	elif sType == MOK and ctrlName == 'ZB_DB':
		url = URL_MOK
		svrIP = '192.168.123.18'
		svrInfo = {'seq':2, 'uuid':'system-zbx-db-01', 'onebox_id':'ZBX.DB.01', 'name':'ZBX.DB.01', 
 					 'ip':svrIP, 'desc':'ZBX DB #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['postgresql', 'zabbix-agent', 'onebox-agent']
		procList = []
		netList = ['bond0']
	elif sType == MOK and ctrlName == 'VNF_SVR':
		url = URL_MOK
		svrIP = '192.168.123.21'
		svrInfo = {'seq':6, 'uuid':'system-vnf-svr-01', 'onebox_id':'VNF.SVR.01', 'name':'VNF.SVR.01', 
 					 'ip':svrIP, 'desc':'VNF SVR #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'ubuntu'
		oTargetModel = 'trusty 14.04'
		svcList = ['apache2', 'zabbix-agent', 'onebox-agent']
		procList = []
		netList = ['bond0']
	elif sType == MOK and ctrlName == 'XMS_WEB':
		url = URL_MOK
		svrIP = '112.175.253.208'
		svrInfo = {'seq':7, 'uuid':'system-xms-web-01', 'onebox_id':'XMS.WEB.01', 'name':'XMS.WEB.01', 
 					 'ip':svrIP, 'desc':'XMS WEB #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'centos'
		oTargetModel = '6.X'
		svcList = ['zabbix-agent']
		procList = ['onebox-agent', '/usr/local/apache/bin/httpd']
		netList = ['bond0']
	elif sType == MOK and ctrlName == 'XMS_SVR':
		url = URL_MOK
		svrIP = '192.168.123.26'
		svrInfo = {'seq':8, 'uuid':'system-xms-svr-01', 'onebox_id':'XMS.SVR.01', 'name':'XMS.SVR.01', 
 					 'ip':svrIP, 'desc':'XMS SVR #01'}
		hTargetCode = 'hp'
		hTargetModel = 'DL XXX'
		oVendorCode = 'centos'
		oTargetModel = '6.X'
		svcList = ['mysql', 'zabbix-agent']
		procList = ['onebox-agent', '/usr/local/tomcat/bin/bootstrap.jar']
		netList = ['bond0']
	else :
		print 'USAGE: CMD [D/S/P/MOK] CTRL_SVR_NAME[ORCH_SVR/ORCH_CTRL/ORCH_DB/ORCH_WEB/ZB_SVR/ZB_CTRL/ZB_DB/XMS/XMS_WEB/XMS_SVR/ETC_SVR]'
		return
	
	test={
		'tid':'test-ctrl-svr-add-'+str(randint(0, 10000)),
		'svr_info': svrInfo,
		'target_info': [
					{
					'target_code': 'hw',
					'target_type': 'svr',
					'vendor_code': hTargetCode,
					'target_model': hTargetModel
					},
					{
					'target_code': 'os',
					'target_type': 'linux',
					'vendor_code': oVendorCode,
					'target_model': oTargetModel,
					'cfg':{ 
						"svr_svc":svcList,
						"svr_proc":procList,
						"svr_net":netList,
						"svr_fs":[ "/" ]
						}
					}
				]
		}

	
	print( callZB( url, test ) )


if __name__ == '__main__':
	if len(sys.argv) >= 3:
		oneTouchOB(sys.argv[1], sys.argv[2])
	else:
		print 'USAGE: CMD [D/S/P/NP/MOK] CTRL_SVR_NAME[ORCH_SVR/ORCH_CTRL/ORCH_DB/ORCH_WEB/ZB_SVR/ZB_CTRL/ZB_DB/XMS/XMS_WEB/XMS_SVR/ETC_SVR]'
# 	if len(sys.argv) >= 2:
# 		svrNum = int(sys.argv[1])
# 		if svrNum == 1:
# 			oneTouchOB01()
# 		elif svrNum == 3:
# 			oneTouchOB03()
# 		elif svrNum == 4:
# 			oneTouchOB04()


