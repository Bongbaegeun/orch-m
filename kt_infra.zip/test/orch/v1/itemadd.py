#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'

URL = "https://211.224.204.203:5555/target/item/add"
URL_D = "https://211.224.204.203:5555/target/item/add"
URL_S = "https://211.224.204.248:5555/target/item/add"
URL_P = "https://220.123.31.82:5555/target/item/add"
PLUGIN_DIR = "/usr/local"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


HIST = "10"
TRND = "180"

CRI_P = "10"
MAJ_P = "30"
MIN_P = "60"
WAN_P = "150"
NOR_P = "300"

ZBA_CONN = {
	"name":"ZBA Connection",
	'visible':'ZBA 연결상태',
	"type":"ZBA Connection",
	"monitor_method":"simple",
	"zb_type":"tcp_port_10050_check",
	"realtime_yn": 'y',
	"data_type":"int",
	"value_type":"status",
	"period":CRI_P,
	"history":HIST,
	"statistic":TRND,
	"description":"Zabbix Agent Port Check",
	"alarm_guide":{'name':'ZBA Connection Alarm', 'guide':'Check One-Box Zabbix-Agent Service'},
	"threshold":[
		{
			"name":"[Critical] ZBA Connection Release Alarm",
			"grade":"Critical",
			"description":"ZBA Connection Release",
			"repeat":"1", 
			"conditions":{"op":"<=", "value":"0"}
		}
	]
}

CPU_UTIL = {
	"name":"VCPU Util",
	'visible':'가상 CPU 사용률',
	"type":"Util",
	"graph_yn": 'y',
	"realtime_yn": 'y',
	"data_type":"float",
	"unit":"%",
	"period":MAJ_P,
	"history":HIST,
	"statistic":TRND,
	"description":"WiMS VCPU Util",
	"plugin":{
			'name':'WiMS CPU Util', 'type':'file', 
			'script': PLUGIN_DIR+'/plugin/apc/olleh/apc_plugin.py',
			'param_num':'2', 'plugin_param':['cpu', 'util'], 'description':'WiMS CPU Load',
			'lib_type':'file', 'lib_script':PLUGIN_DIR+'/plugin/apc/olleh/apc_api.py',
			'lib_name':'apc_api.py', 'lib_path':'./', 
			'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
			},
	"alarm_guide":{'name':'WiMS VCPU Util Alarm', 'guide':'Check WiMS Top Status'},
	"threshold":[
		{
			"name":"[Warning] WiMS VCPU Util Alarm",
			"grade":"warning",
			"description":"WiMS VCPU Util Warning",
			"repeat":"1", 
			"conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
		},
		{
			"name":"[Minor] WiMS VCPU Util Alarm",
			"grade":"minor",
			"description":"WiMS VCPU Util Minor",
			"repeat":"1", 
			"conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
		},
		{
			"name":"[Major] WiMS VCPU Util Alarm",
			"grade":"major",
			"description":"WiMS VCPU Util Major",
			"repeat":"1", 
			"conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
		},
		{
			"name":"[Critical] WiMS VCPU Util Alarm",
			"grade":"Critical",
			"description":"WiMS VCPU Util Critical",
			"repeat":"1", 
			"conditions":{"op":">=", "value":"95"}
		}
	]
}

TEMP_SVR = {
	"name":"SVR Temperature",
	"visible":'서버 온도', 
	"type":"SVR",
	"graph_yn": 'y',
	"realtime_yn": 'y',
	"data_type":"int",
	"unit":"°C",
	"period":MAJ_P,
	"history":HIST,
	"statistic":TRND,
	"description":"Server Temperature",
	"plugin":{
			'name':'Temperature', 'type':'file', 
			'script': '/usr/local/plugin'+'/os/ubuntu/temp-cpu.sh',
			'param_num':0, 'description':'Svr Temperature'
			},
	"alarm_guide":{'name':'SVR Temperature Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 온도 확인 명령 수행: "sensors" 
4. 서버 FAN 상태 확인"""},
	"threshold":[
		{
			"name":"[Warning] SVR Temperature Alarm",
			"grade":"warning",
			"description":"SVR Temperature Warning",
			"repeat":"1", 
			"conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
		},
		{
			"name":"[Minor] SVR Temperature Alarm",
			"grade":"minor",
			"description":"SVR Temperature Minor",
			"repeat":"1", 
			"conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
		},
		{
			"name":"[Major] SVR Temperature Alarm",
			"grade":"major",
			"description":"SVR Temperature Major",
			"repeat":"1", 
			"conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"100"}]
		},
		{
			"name":"[Critical] SVR Temperature Alarm",
			"grade":"Critical",
			"description":"SVR Temperature Critical",
			"repeat":"1", 
			"conditions":{"op":">=", "value":"100"}
		}
	]
}


GRP_FAN = {'name': 'fan', "visible":'FAN', 'description':'Server Fan'}

FAN_STATUS = {
	"name":"Fan Status",
	"visible":'Fan 상태', 
	"type":"Status",
	"value_type":"status",
	"data_type":"int",
	"period":MIN_P,
	"history":HIST,
	"statistic":TRND,
	"description":"Server Fan Status",
	"plugin":{
			'name':'Fan Status', 'type':'file', 
			'script': '/usr/local/plugin'+'/hw/hp/ipmi_chassis.py',
			'param_num':2, 'plugin_param':['fan', 'status'], 'description':'Server Fan Status'
			},
	"alarm_guide":{'name':'Fan Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Fan 상태 확인 명령 수행: "ipmitool chassis status | grep Fan" 
4. 서버 FAN 상태 확인 및 서버 담당자 연락"""},
	"threshold":[
		{
			"name":"[Critical] Fan Status Down Alarm",
			"grade":"Critical",
			"description":"Server Fan Status Down",
			"repeat":"1", 
			"conditions":{"op":"<=", "value":"0"}
		}
	]
}

GRP_POWER = {'name': 'power', "visible":'Power', 'description':'Server Power'}

POWER_OVERLOAD = {
	"name":"Power OverLoad",
	"visible":'Power 과부하', 
	"type":"Overload",
	"value_type":"status",
	"data_type":"int",
	"period":MIN_P,
	"history":HIST,
	"statistic":TRND,
	"description":"Server Power OverLoad Status",
	"plugin":{
			'name':'Power OverLoad', 'type':'file', 
			'script': '/usr/local/plugin'+'/hw/hp/ipmi_chassis.py',
			'param_num':2, 'plugin_param':['power', 'overload'], 'description':'Server Power OverLoad Status'
			},
	"alarm_guide":{'name':'Power OverLoad Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Power 상태 확인 명령 수행: "ipmitool chassis status | grep Power" 
4. 서버 담당자 연락"""},
	"threshold":[
		{
			"name":"[Critical] Power OverLoad Alarm",
			"grade":"Critical",
			"description":"Server Power OverLoad Fault",
			"repeat":"1", 
			"conditions":{"op":"<=", "value":"0"}
		}
	]
}

POWER_STATUS = {
	"name":"Power Status",
	"visible":'Power 상태', 
	"type":"Status",
	"value_type":"status",
	"data_type":"int",
	"period":MAJ_P,
	"history":HIST,
	"statistic":TRND,
	"description":"Server Power Status",
	"plugin":{
			'name':'Power Status', 'type':'file', 
			'script': '/usr/local/plugin'+'/hw/hp/ipmi_chassis.py',
			'param_num':2, 'plugin_param':['power', 'status'], 'description':'Server Power Status'
			},
	"alarm_guide":{'name':'Power Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Power 상태 확인 명령 수행: "ipmitool chassis status | grep Power" 
4. 서버 담당자 연락"""},
	"threshold":[
		{
			"name":"[Critical] Power Status Down Alarm",
			"grade":"Critical",
			"description":"Server Power Status Down",
			"repeat":"1", 
			"conditions":{"op":"<=", "value":"0"}
		}
	]
}

POWER_CTRL = {
	"name":"Power Control Status",
	"visible":'Power 제어 상태', 
	"type":"Control",
	"value_type":"status",
	"data_type":"int",
	"period":MAJ_P,
	"history":HIST,
	"statistic":TRND,
	"description":"Server Power Control Status",
	"plugin":{
			'name':'Power Control Status', 'type':'file', 
			'script': '/usr/local/plugin'+'/hw/hp/ipmi_chassis.py',
			'param_num':2, 'plugin_param':['power', 'control'], 'description':'Server Power Control Status'
			},
	"alarm_guide":{'name':'Power Control Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Power 상태 확인 명령 수행: "ipmitool chassis status | grep Power" 
4. 서버 담당자 연락"""},
	"threshold":[
		{
			"name":"[Critical] Power Control Fault Alarm",
			"grade":"Critical",
			"description":"Server Power Control Fault",
			"repeat":"1", 
			"conditions":{"op":"<=", "value":"0"}
		}
	]
}

GRP_ITEM = {'name': 'item', "visible":'감시항목', 'description':'Server Item'}

ITEM_INACT = {
	"name":"Item Inactive",
	"visible":'비활성 감시항목', 
	"type":"Inactive",
	"monitor_method":"trap",
	"zb_type":"item_inactive",
	"realtime_yn": 'y',
	"data_type":"float",
	"period":MIN_P,
	"history":HIST,
	"statistic":TRND,
	"description":"Server Item Inactive Count",
	"alarm_guide":{'name':'Item Inactive Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 감시 로그 확인: " tail -fn 500 /var/log/zabbix-agent/*.log ", " tail -fn 500 /var/log/zabbix-agent/plugin/*.log "
4. Zabbix 서버 연결 상태 확인: "nc -z $ZABBIX_SERVER_IP 10051"
5. 서버 담당자 연락"""},
	"threshold":[
		{
			"name":"[Warning] SVR Item Inactive Alarm",
			"grade":"warning",
			"description":"SVR Item Inactive Warning",
			"repeat":"1", 
			"conditions":["and", {"op":">=", "value":"20"},{"op":"<", "value":"30"}]
		},
		{
			"name":"[Minor] SVR Item Inactive Alarm",
			"grade":"minor",
			"description":"SVR Item Inactive Minor",
			"repeat":"1", 
			"conditions":["and", {"op":">=", "value":"30"},{"op":"<", "value":"40"}]
		},
		{
			"name":"[Major] SVR Item Inactive Alarm",
			"grade":"major",
			"description":"SVR Item Inactive Major",
			"repeat":"1", 
			"conditions":["and", {"op":">=", "value":"40"},{"op":"<", "value":"50"}]
		},
		{
			"name":"[Critical] SVR Item Inactive Alarm",
			"grade":"Critical",
			"description":"SVR Item Inactive Critical",
			"repeat":"1", 
			"conditions":{"op":">=", "value":"50"}
		}
	]
}




ENDIAN_UTM_INTERNET = {
	"name":"UTM Internet Connection",
	'visible':'UTM 인터넷 연결상태',
	"type":"InterConnection",
	"graph_yn": 'y',
	"data_type":"int",
	"value_type":"status",
	"period":CRI_P,
	"history":HIST,
	"statistic":TRND,
	"description":"Olleh UTM Internet Connection Check",
	"plugin":{
			'name':'Olleh UTM Internet Connection', 'type':'file', 
			'script': PLUGIN_DIR+'/plugin/utm/olleh/utm_plugin.py',
			'param_num':'1', 'plugin_param':['internet'], 'description':'Olleh UTM Internet Connection Check',
			'lib_type':'file', 'lib_script':PLUGIN_DIR+'/plugin/utm/olleh/utm_api.py',
			'lib_name':'utm_api.py', 'lib_path':'./', 
			'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
			},
	"alarm_guide":{'name':'Olleh UTM Internet Connection Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. WAN 인터페이스 확인 : "ethtool eth1"
4. Default GateWay 확인 : "ip route | grep default"
5. 장애 시, UTM 담당자 연락"""},
	"threshold":[
		{
			"name":"[Critical] Olleh UTM Internet Connection Alarm",
			"grade":"critical",
			"description":"Olleh UTM Internet Connection Critical",
			"repeat":"3", 
			"conditions":{"op":"<=", "value":"0"}
		}
	]
}

DURUAN_UTM_INTERNET = {
	"name":"UTM Internet Connection",
	'visible':'UTM 인터넷 연결상태',
	"type":"InterConnection",
	"graph_yn": 'y',
	"data_type":"int",
	"value_type":"status",
	"period":CRI_P,
	"history":HIST,
	"statistic":TRND,
	"description":"KT UTM Internet Connection Check",
	"plugin":{
			'name':'KT UTM Internet Connection', 'type':'file', 
			'script': PLUGIN_DIR+'/plugin/utm/kt/utm_plugin.py',
			'param_num':'1', 'plugin_param':['internet'], 'description':'KT UTM Internet Connection Check',
			'lib_type':'file', 'lib_script':PLUGIN_DIR+'/plugin/utm/kt/utm_api.py',
			'lib_name':'utm_api.py', 'lib_path':'./', 
			'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
			},
	"alarm_guide":{'name':'KT UTM Internet Connection Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. WAN 인터페이스 확인 : "ethtool eth1"
4. Default GateWay 확인 : "ip route | grep default"
5. 장애 시, UTM 담당자 연락"""},
	"threshold":[
		{
			"name":"[Critical] KT UTM Internet Connection Alarm",
			"grade":"critical",
			"description":"KT UTM Internet Connection Critical",
			"repeat":"3", 
			"conditions":{"op":"<=", "value":"0"}
		}
	]
}


PING_20210330 = {
	"name":"SVR Ping",
	"visible":'네트워크 ping - 168.126.63.1', 
	"item_id":"os.net.ping",
	"type":"ping",
	"graph_yn": 'n',
	"realtime_yn": 'n',
	"data_type":"float",
	"unit":"ms",
	"period":60,
	"history":HIST,
	"statistic":TRND,
	"description":"Server Ping - 168.126.63.1",
	"plugin":{
			'name':'ping', 'type':'file', 
			'script': '/usr/local/plugin'+'/os/ubuntu/ping.sh',
			'param_num':0, 'description':'Server Ping - 168.126.63.1'
			},
	"alarm_guide":{'name':'Server Ping Alarm', 'guide':"""1. ping 168.126.63.1 확인
2. 장애 시 Onebox 담당자 연락"""},
	"threshold":[
        {
            "name":"[Warning] Network ping ( 168.126.63.1 ) 50ms~100ms > Count 5 ( 5 minute )",
            "grade":"warning",
            "description":"Network ping ( 168.126.63.1 ) warning",
            "repeat":"5", 
            "conditions":["and", {"op":">=", "value":"50"},{"op":"<", "value":"100"}]
        },
        {
            "name":"[Minor] Network ping ( 168.126.63.1 ) 100ms~200ms > Count 5 ( 5 minute )",
            "grade":"minor",
            "description":"Network ping ( 168.126.63.1 ) Minor",
            "repeat":"5", 
            "conditions":["and", {"op":">=", "value":"100"},{"op":"<", "value":"200"}]
        },
        {
            "name":"[Major] Network ping ( 168.126.63.1 ) 200ms~300ms > Count 5 ( 5 minute )",
            "grade":"major",
            "description":"Network ping ( 168.126.63.1 ) Major",
            "repeat":"5", 
            "conditions":["and", {"op":">=", "value":"200"},{"op":"<", "value":"300"}]
        },
		{
			"name":"[Critical] Network ping ( 168.126.63.1 ) 300ms > Count 5 ( 5 minute )",
			"grade":"critical",
			"description":"Network ping ( 168.126.63.1 ) Critical",
			"repeat":"5", 
			"conditions":{"op":">", "value":"300"}
		}
	]            
}


PING_VNF = {
	"name":"SVR Ping",
	"visible":'RTT 상태', 
	"item_id":"os.net.ping",
	"type":"ping",
	"graph_yn": 'n',
	"realtime_yn": 'n',
	"data_type":"float",
	"unit":"ms",
	"period":60,
	"history":HIST,
	"statistic":TRND,
	"description":"Server Ping - 168.126.63.1",
	"plugin":{
			'name':'ping', 'type':'file', 
			'script': '/usr/local/plugin'+'/os/ubuntu/ping.sh',
			'param_num':0, 'description':'Server Ping - 168.126.63.1'
			},
	"alarm_guide":{'name':'Server Ping Alarm', 'guide':"""1. ping 168.126.63.1 확인
2. 장애 시 Onebox 담당자 연락"""},
}



PING_PNF = {
	"name":"SVR Ping",
	"visible":'RTT 상태', 
	"item_id":"os.net.ping",
	"type":"ping",
	"graph_yn": 'n',
	"realtime_yn": 'n',
	"data_type":"float",
	"unit":"ms",
	"period":60,
	"history":HIST,
	"statistic":TRND,
	"description":"Server Ping - 168.126.63.1",
	"plugin":{
			'name':'ping', 'type':'file', 
			'script': '/usr/local/plugin'+'/os/aos/ping.sh',
			'param_num':0, 'description':'Server Ping - 168.126.63.1'
			},
	"alarm_guide":{'name':'Server Ping Alarm', 'guide':"""1. ping 168.126.63.1 확인
2. 장애 시 Onebox 담당자 연락"""},
}


def addItem(sType):
	if sType == DEV_SVR :
		url = URL_D
	elif sType == STG_SVR :
		url = URL_S
	elif sType == PRT_SVR :
		url = URL_P
	else:
		print 'USAGE: CMD [D/S/P] '
		return
        
	test={
		"tid":'temp-item-add-1',
		"target_seq":9,
 		"group_seq":32,
#		"group_info":GRP_ITEM,
# 		'monitor_yn':'y',
		"item": PING_VNF
	}
	print( callZB( url, test ) )


if __name__ == '__main__':
	if len(sys.argv) >= 2:
		addItem(sys.argv[1])
	else:
		print 'USAGE: CMD [D/S/P] '
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


