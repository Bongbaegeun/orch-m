#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'

REAL_PLG = 'R'
TEST_PLG = 'T'

# URL = "http://211.224.204.203:5555/server"
URL = "http://211.224.204.248:5555/server"
URL_D = "http://211.224.204.203:5555/server"
URL_S = "http://211.224.204.248:5555/server"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def oneTouchOB(sType, svrID, pType):
	
	if sType == DEV_SVR and svrID == 1:
		url = URL_D
		svrIP = '211.224.204.205'
		svrInfo = {'seq':16, 'uuid':'TJB-SVR-UUID-005', 'name':'TJB.01', 
 					'onebox_id':'TJB.01', 'ip':svrIP, 'desc':'TJB Server #1'}
		targetCode = 'hp'
		targetModel = 'DL XXX'
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['em1','em2', 'em3', 'em4']
		mapping = {'wan':'em2', 'server':'em4', 'office1':'em3', 'office2':'em1'}
	elif sType == DEV_SVR and svrID == 2:
		url = URL_D
		svrIP = '211.224.204.167'
		svrInfo = {'seq':102, 'uuid':'328a5264-3a79-11e6-8287-0017a44b1649', 
				'name':'rs2016a.OB89', 
 					'onebox_id':'rs2016a.OB89', 'ip':svrIP, 'desc':'KTS Server #1'}
		targetCode = 'dell'
		targetModel = 'R420'
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['em1','em2', 'em3']
		mapping = {'wan':'em1', 'office1':'em2', 'server':'em3'}
	elif sType == DEV_SVR and svrID == 4:
		url = URL_D
		svrIP = '211.224.204.157'
		svrInfo = {'seq':20, 'uuid':'f117e5d4-88d6-11e5-8465-0017a44b1649', 'name':'KTS.01', 
 					'onebox_id':'KTS.01', 'ip':svrIP, 'desc':'KTS Server #1'}
		targetCode = 'hp'
		targetModel = 'DL XXX'
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['em1','em2', 'em3', 'em4']
		mapping = {'wan':'em2', 'server':'em4', 'office1':'em3', 'office2':'em1'}
	elif sType == STG_SVR and svrID == 1:
		url = URL_S
		svrIP = '211.224.204.213'
		svrInfo = {'seq':16, 'uuid':'OneBox-S2', 'name':'TJB.01', 
					'onebox_id':'TJB.01', 'ip':svrIP, 'desc':'TJB Server #1'}
		targetCode = 'dell'
		targetModel = 'R420'
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['em2','p2p2', 'p2p3', 'p2p4']
		mapping = {'wan':'p2p4', 'server':'p2p3', 'office1':'p2p2', 'office2':'em2'}
	elif sType == STG_SVR and svrID == 4:
		url = URL_S
		svrIP = '211.224.204.212'
		svrInfo = {'seq':20, 'uuid':'OneBox-S', 'name':'KTS.01', 
					'onebox_id':'KTS.01', 'ip':svrIP, 'desc':'KTS Server #1'}
		targetCode = 'dell'
		targetModel = 'R420'
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['em2','p2p2', 'p2p3', 'p2p4']
		mapping = {'wan':'p2p4', 'server':'p2p3', 'office1':'p2p2', 'office2':'em2'}
	else :
		return
	
	if pType == REAL_PLG :
		mType1 = targetModel
		mType2 = 'trusty 14.04'
		mType3 = 'kilo'
	elif pType == TEST_PLG :
		mType1 = 'Test'
		mType2 = 'Test'
		mType3 = 'Test'
	else:
		return
	
	ospUrl = "http://%s:35357/v3/auth/tokens"%svrIP
	
	test={
		'tid':'svr-add-test1',
		'svr_info': svrInfo,
		'target_info': [
					{
					'target_code': 'hw',
					'target_type': 'svr',
					'vendor_code': targetCode,
					'target_model': mType1
					},
					{
					'target_code': 'os',
					'target_type': 'linux',
					'vendor_code': 'ubuntu',
					'target_model': mType2,
					'cfg':{ 
						"svr_net":netList,
						"svr_fs":[ "/" ]
						},
					'mapping':mapping
					},
					{
					'target_code': 'vim',
					'target_type': 'openstack',
					'vendor_code': 'openstack',
					'target_model': mType3,
					'cfg':{ 
						'vim_auth_url':ospUrl,
						"vim_id": "admin", 
						"vim_passwd": "onebox2016!", 
						"vim_domain": "default", 
						"vim_mgmt_net": "global_mgmt_net",
						"vim_net":['global_mgmt_net','public_net', 'net_office', 'net_internet', 'net_server'],
						"vim_router":[ "global_mgmt_router" ]
						}
					}
				]
		}

	
	print( callZB( url, test ) )


def oneTouchOB01(sType):
	
	if sType == DEV_SVR:
		svrInfo = {'seq':16, 'uuid':'TJB-SVR-UUID-005', 'name':'TJB.01', 
 					 'ip':'211.224.204.205', 'desc':'TJB Server #1'}
	elif sType == STG_SVR:
		svrInfo = {'seq':16, 'uuid':'OneBox-S2', 'name':'TJB.01', 
					 'ip':'211.224.204.213', 'desc':'TJB Server #1'}
	
	test={
		'tid':'svr-add-test1',
		'svr_info': {'seq':16, 'uuid':'OneBox-S2', 'name':'TJB.01', 
					 'ip':'211.224.204.213', 'desc':'TJB Server #1'},
		'target_info': [
					{
					'target_code': 'hw',
					'target_type': 'svr',
					'vendor_code': 'hp',
					'target_model': 'DL XXX'
					},
					{
					'target_code': 'os',
					'target_type': 'linux',
					'vendor_code': 'ubuntu',
					'target_model': 'trusty 14.04',
					'cfg':{ 
						"svr_svc":['zabbix-agent', 'nova-api', 'apache2', 'neutron-server', 'glance-api'],
						"svr_proc":['zabbix_agentd: collector', 'zabbix_agentd: listener', 'zabbix_agentd: active', 
									'python obagent.py', 'python vnfmd.py', 'rabbitmq-server', '/usr/sbin/mysqld'],
# 						"svr_net":['em1','em2', 'em3', 'em4'],
						"svr_net":['p2p1','p2p2'],
						"svr_fs":[ "/" ]
						}
					},
					{
					'target_code': 'vim',
					'target_type': 'openstack',
					'vendor_code': 'openstack',
					'target_model': 'kilo',
					'cfg':{ 
# 						'vim_auth_url':"http://211.224.204.205:35357/v3/auth/tokens",
						'vim_auth_url':"http://211.224.204.213:35357/v3/auth/tokens",
						"vim_id": "admin", 
						"vim_passwd": "ohhberry3333", 
						"vim_domain": "default", 
						"vim_mgmt_net": "global_mgmt_net",
						"vim_net":['global_mgmt_net','public_net', 'net_office', 'net_internet', 'net_server'],
						"vim_router":[ "global_mgmt_router" ]
						}
					}
				]
		}

	
	print( callZB( URL, test ) )

def oneTouchOB04(sType):
	test={
		'tid':'svr-add-test1',
# 		'svr_info': {'seq':20, 'uuid':'f117e5d4-88d6-11e5-8465-0017a44b1649', 'name':'KTS.01', 
# 					 'ip':'211.224.204.157', 'desc':'KTS Server #1'},
		'svr_info': {'seq':85, 'uuid':'test-ob58', 'name':'TEST1.OB58', 
					 'onebox_id':'TEST1.OB58', 'ip':'211.224.204.158', 'desc':'Test ZB 3.0'},
		'target_info': [
					{
					'target_code': 'hw',
					'target_type': 'svr',
					'vendor_code': 'nsa',
					'target_model': '3130'
					},
					{
					'target_code': 'os',
					'target_type': 'linux',
					'vendor_code': 'ubuntu',
					'target_model': 'trusty 14.04',
					'cfg':{ 
						"svr_svc":['zabbix-agent'],
						"svr_proc":['onebox-agent'],
# 						"svr_net":['em1','em2', 'em3', 'em4'],
						"svr_net":['eth0','eth1'],
						"svr_fs":[ "/" ]
						},
					'mapping':{'wan':'eth1'}
					},
# 					{
# 					'target_code': 'vim',
# 					'target_type': 'openstack',
# 					'vendor_code': 'openstack',
# 					'target_model': 'kilo',
# 					'cfg':{ 
# # 						'vim_auth_url':"http://211.224.204.157:35357/v3/auth/tokens",
# 						'vim_auth_url':"http://211.224.204.158:35357/v3/auth/tokens",
# 						"vim_id": "admin", 
# 						"vim_passwd": "onebox2016!", 
# 						"vim_domain": "default", 
# 						"vim_mgmt_net": "global_mgmt_net",
# 						"vim_net":['global_mgmt_net','public_net', 'net_office', 'net_internet', 'net_server'],
# 						"vim_router":[ "global_mgmt_router" ]
# 						}
# 					}
				]
		}

	
	print( callZB( sType, test ) )


if __name__ == '__main__':
	oneTouchOB04(URL_S)
	if len(sys.argv) >= 4:
		oneTouchOB(sys.argv[1], int(sys.argv[2]), sys.argv[3])
	else:
		print 'USAGE: CMD [D/S] SVRSEQ [R/T]'
# 	if len(sys.argv) >= 2:
# 		svrNum = int(sys.argv[1])
# 		if svrNum == 1:
# 			oneTouchOB01()
# 		elif svrNum == 3:
# 			oneTouchOB03()
# 		elif svrNum == 4:
# 			oneTouchOB04()


