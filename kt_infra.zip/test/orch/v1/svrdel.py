#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
NEW_PRT_SVR = 'NP'

URL = "https://211.224.204.203:5555/server/del"
# URL = "http://211.224.204.248:5555/server/del"
URL_D = "https://211.224.204.203:5555/server/del"
URL_S = "https://211.224.204.248:5555/server/del"
URL_NP = "https://220.123.31.82:5555/server/del"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp

def delServer(sType, svrID):
	
	if sType == DEV_SVR and svrID == 1:
		url = URL_D
		svrSeq = '16'
		svrUuid = 'TJB-SVR-UUID-005'
		svrIP = '211.224.204.205'
		svrObid = 'TJB.01'
	elif sType == DEV_SVR and svrID == 2:
		url = URL_D
		svrSeq = '102'
		svrUuid = '328a5264-3a79-11e6-8287-0017a44b1649'
		svrIP = '211.224.204.167'
		svrObid = 'rs2016a.OB89'
	elif sType == DEV_SVR and svrID == 4:
		url = URL_D
		svrSeq = '20'
		svrUuid = 'f117e5d4-88d6-11e5-8465-0017a44b1649'
		svrIP = '211.224.204.157'
		svrObid = 'KTS.01'
	elif sType == STG_SVR and svrID == 1:
		url = URL_S
		svrSeq = '16'
		svrUuid = 'OneBox-S2'
		svrIP = '211.224.204.213'
		svrObid = 'TJB.01'
	elif sType == STG_SVR and svrID == 2:
		url = URL_S
		svrSeq = '73'
		svrUuid = 'manual-uuid-onebox-37'
		svrIP = '211.224.204.142'
		svrObid = 'WITHNET2.OB37'
	elif sType == STG_SVR and svrID == 4:
		url = URL_S
		svrSeq = '20'
		svrUuid = 'OneBox-S'
		svrIP = '211.224.204.212'
		svrObid = 'KTS.01'
	elif sType == STG_SVR and svrID == 37:
		url = URL_S
		svrSeq = '53'
		svrUuid = 'eb21ecda-e45a-11e5-bf7d-080027ca3ef9'
		svrIP = '211.224.204.138'
		svrObid = 'WITHNET.OB37'
	elif sType == STG_SVR and svrID == 48:
		url = URL_S
		svrSeq = '65'
		svrUuid = 'c108ecfc-fc8b-11e5-bf7d-080027ca3ef9'
		svrIP = '211.224.204.138'
		svrObid = 'NSA5150.OB48'
	elif sType == STG_SVR and svrID == 65:
		url = URL_S
		svrSeq = '70'
		svrUuid = 'd962b7a4-3306-11e6-bf7d-080027ca3ef9'
		svrIP = '211.224.204.228'
		svrObid = 'GiGATech.OB65'
	else :
		return 
	
	test={
		'tid':'svr-del-1',
		'svr_info': {'seq':svrSeq, 'onebox_id':svrUuid, 'onebox_id':svrObid, 'ip':svrIP}
		}
	
	print( callZB( url, test ) )

def delServer1():
	# ob1
	test={
		'tid':'svr-del-1',
# 		'svr_info': {'seq':'16', 'uuid':'TJB-SVR-UUID-005', 'ip':'211.224.204.205'}
		'svr_info': {'seq':'16', 'onebox_id':'OneBox-S2', 'ip':'211.224.204.213'}
		}
	
	print( callZB( URL, test ) )

def delServer4():
	# ob1
	test={
		'tid':'svr-del-1',
		'svr_info': {'seq':'20', 'onebox_id':'OneBox-S', 'ip':'211.224.204.212'}
# 		'svr_info': {'seq':'20', 'uuid':'f117e5d4-88d6-11e5-8465-0017a44b1649', 'ip':'211.224.204.157'}
		}
	
	print( callZB( URL, test ) )

def delServer3():
	# ob1
	test={
		'tid':'svr-del-11',
		'svr_info': {'seq':'257', 'onebox_id':'G400-DUMP.OB1', 'ip':'211.224.204.184'}
# 		'svr_info': {'seq':'53', 'uuid':'eb21ecda-e45a-11e5-bf7d-080027ca3ef9', 'ip':'211.224.204.111'}
		}
	
	print( callZB( URL_D, test ) )

def delServer4():
	# ob1
	test={
		'tid':'svr-del-1',
		'svr_info': {'seq':'85', 'onebox_id':'TEST1.OB58', 'ip':'211.224.204.158'}
# 		'svr_info': {'seq':'53', 'uuid':'eb21ecda-e45a-11e5-bf7d-080027ca3ef9', 'ip':'211.224.204.111'}
		}
	
	print( callZB( URL_S, test ) )

if __name__ == '__main__':
	delServer3()
# 	if len(sys.argv) >= 3:
# 		delServer(sys.argv[1], int(sys.argv[2]))
# 	if len(sys.argv) >= 2:
# 		svrNum = int(sys.argv[1])
# 		if svrNum == 1:
# 			delServer1()
# 		elif svrNum == 3:
# 			delServer3()
# 		elif svrNum == 4:
# 			delServer4()
# 	delServer4()
# 	delServer3()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


