#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'

# URL = "http://211.224.204.203:5555/server/del"
URL = "http://211.224.204.248:5555/server/mod"
URL_D = "http://211.224.204.203:5555/server/mod"
URL_S = "http://211.224.204.248:5555/server/mod"
URL_P = "http://211.224.204.222:5555/server/mod"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp

def modServer(sType, svrID, svrIP):
	
	if sType == DEV_SVR and svrID == 1:
		url = URL_D
		svrSeq = '16'
		_svrIP = '211.224.204.205'
	elif sType == DEV_SVR and svrID == 4:
		url = URL_D
		svrSeq = '20'
		_svrIP = '211.224.204.157'
	elif sType == STG_SVR and svrID == 1:
		url = URL_S
		svrSeq = '16'
		_svrIP = '211.224.204.213'
	elif sType == STG_SVR and svrID == 4:
		url = URL_S
		svrSeq = '20'
		_svrIP = '211.224.204.212'
	elif sType == PRT_SVR and svrID == 10:
		url = URL_P
		svrSeq = '53'
		_svrIP = '211.224.204.139'
	else :
		return 
	
	if svrIP == None:
		svrIP = _svrIP
	
	test={
		'tid':'svr-del-1',
		'svr_info': {'seq':svrSeq, 'new_ip':svrIP, 'mod_desc':'test'}
		}
	
	print( callZB( url, test ) )

if __name__ == '__main__':
	if len(sys.argv) == 3:
		modServer(sys.argv[1], int(sys.argv[2]), None)
	elif len(sys.argv) == 4:
		modServer(sys.argv[1], int(sys.argv[2]), sys.argv[3])
# 	if len(sys.argv) >= 2:
# 		svrNum = int(sys.argv[1])
# 		if svrNum == 1:
# 			delServer1()
# 		elif svrNum == 3:
# 			delServer3()
# 		elif svrNum == 4:
# 			delServer4()
# 	delServer4()
# 	delServer3()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


