#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'

URL_D = "https://211.224.204.203:5555/server/target/add"
URL_S = "https://211.224.204.248:5555/server/target/add"
URL_P = "https://211.224.204.222:5555/server/target/add"
URL = "https://211.224.204.203:5555/server/target/add"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def modServer(sType, svrID):
	if sType == DEV_SVR and svrID == 1:
		url = URL_D
		svrIP = '211.224.204.205'
		svrInfo = {'seq':16, 'uuid':'TJB-SVR-UUID-005', 'onebox_id':'TJB.01', 'ip':svrIP}
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['em1','em2', 'em3', 'em4']
		mapping = {'wan':'em2', 'server':'em4', 'office1':'em3', 'office2':'em1'}
	elif sType == DEV_SVR and svrID == 4:
		url = URL_D
		svrIP = '211.224.204.157'
		svrInfo = {'seq':20, 'uuid':'f117e5d4-88d6-11e5-8465-0017a44b1649', 'onebox_id':'KTS.01', 'ip':svrIP}
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['em1','em2', 'em3', 'em4']
		mapping = {'wan':'em2', 'server':'em4', 'office1':'em3', 'office2':'em1'}
	elif sType == STG_SVR and svrID == 1:
		url = URL_S
		svrIP = '211.224.204.213'
		svrInfo = {'seq':16, 'uuid':'OneBox-S2', 'onebox_id':'TJB.01', 'ip':svrIP}
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['em2','p2p2', 'p2p3', 'p2p4']
		mapping = {'wan':'p2p4', 'server':'p2p3', 'office1':'p2p2', 'office2':'em2'}
	elif sType == STG_SVR and svrID == 4:
		url = URL_S
		svrIP = '211.224.204.212'
		svrInfo = {'seq':20, 'uuid':'OneBox-S', 'onebox_id':'KTS.01', 'ip':svrIP}
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['em2','p2p2', 'p2p3', 'p2p4']
		mapping = {'wan':'p2p4', 'server':'p2p3', 'office1':'p2p2', 'office2':'em2'}
	elif sType == STG_SVR and svrID == 5:
		url = URL_S
		svrIP = '211.224.204.137'
		svrInfo = {'seq':56, 'uuid':'ca7078b8-efc6-11e5-bf7d-080027ca3ef9', 'onebox_id':'T330-R.OB38', 'ip':svrIP}
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['p1p1','p4p1', 'p2p3', 'p2p4']
		mapping = {'wan':'p1p1', 'server':'p2p4', 'office1':'p4p1', 'office2':'p2p3'}
	elif sType == PRT_SVR and svrID == 1:
		url = URL_P
		svrIP = '183.98.121.151'
		svrInfo = {'seq':53, 'uuid':'eb21ecda-e45a-11e5-bf7d-080027ca3ef9', 'onebox_id':'WITHNET.OB37', 'ip':svrIP}
		svcList = ['zabbix-agent', 'onebox-agent', 'onebox-vnfm', 'nova-api', 'apache2', 'neutron-server', 'glance-api']
		procList = ['rabbitmq-server', '/usr/sbin/mysqld']
		netList = ['em2','p2p2', 'p2p3', 'p2p4']
		mapping = {'wan':'p2p4', 'server':'p2p3', 'office1':'p2p2', 'office2':'em2'}
	else :
		return
	
	# ob1
	test={
		'tid':'tar-add-1',
		'svr_info': svrInfo,
		'target_info': [ 
# 					{
# 					'target_code': 'hw',
# 					'target_type': 'svr',
# 					'vendor_code': 'hp',
# 					'target_model': 'DL XXX',
# 					'target_for':'OneTouch',
# 					},
					{
					'target_code': 'hw',
					'target_type': 'svr',
					'vendor_code': 'dell',
					'target_model': 'R420',
					'target_for':'OneTouch',
					},
# 					{
# 					'target_code': 'os',
# 					'target_type': 'linux',
# 					'vendor_code': 'ubuntu',
# 					'target_model': 'trusty 14.04',
# 					'target_for':'OneTouch',
# 					'cfg':{ 
# 						"svr_svc":svcList,
# 						"svr_proc":procList,
# 						"svr_net":netList,
# 						"svr_fs":[ "/" ]
# 						},
# 					'mapping':mapping
# 					},
				]
		}
	
	print( callZB( url, test ) )




if __name__ == '__main__':
	if len(sys.argv) >= 3:
		modServer(sys.argv[1], int(sys.argv[2]))
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


