#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'

REAL_PLG = 'R'
TEST_PLG = 'T'

# URL = "http://211.224.204.248:5555/target"
URL = "http://211.224.204.203:5555/target"
URL_D = "http://211.224.204.203:5555/target"
URL_S = "http://211.224.204.248:5555/target"
URL_P = "http://211.224.204.222:5555/target"
PLUGIN_DIR = "/usr/local/plugin"
PLUGIN_TEST_DIR = "/usr/local/plugin/test"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def createTemp(sType, pType):
	HIST = "10"
	TRND = "180"
	
	CRI_P = "10"
	MAJ_P = "30"
	MIN_P = "60"
	WAN_P = "150"
	NOR_P = "300"
	
	if sType == DEV_SVR :
		url = URL_D
	elif sType == STG_SVR :
		url = URL_S
	elif sType == PRT_SVR :
		url = URL_P
	else:
		return
	
	if pType == REAL_PLG :
		pDir = PLUGIN_DIR
		mType = 'DL XXX'
	elif pType == TEST_PLG :
		pDir = PLUGIN_TEST_DIR
		mType = 'Test'
	else:
		return
	
	test={
		"tid":'temp-create-1',
		"target_info":{
				'code':'hw', 'type':'svr', 'vendor_code':'hp', 'model':mType, 
				"name":"HP-SVR", "visible":'HP 서버', "description":"HP DL XXX Monitoring",
				'version':'v1.0', 'target_for':'OneTouch'
			},
		"group":[
			{'name': 'net', 'visible':'네트워크', 'description':'HP SVR Network',
				 "item":[
					{
						"name":"SVR Connection",
						"visible":'서버 연결 상태',
						"type":"SVR Connection",
						"monitor_method":"simple",
						"zb_type":"ping_check",
						"realtime_yn": 'y',
						"data_type":"int",
						"value_type":"status",
						"period":CRI_P,
						"history":HIST,
						"statistic":TRND,
						"description":"HP Server Connection",
						"alarm_guide":{'name':'SVR Connection Alarm', 'guide':"""1. One-Box 서버 Ping 확인: "ping $IP"
2. 장애 시, LAN 포트 연결 상태 확인
3. H/W 담당자 및 개발팀 연락"""},
# 						"threshold_zb_yn":"y",
						"threshold":[
							{
								"name":"[Critical] SVR Connection Release Alarm",
								"grade":"Critical",
								"description":"SVR Connection Release",
								"repeat":"1", 
								"conditions":{"op":"<=", "value":"0"}
							}
						]
					},
					{
						"name":"ZBA Connection",
						'visible':'ZBA 연결상태',
						"type":"ZBA Connection",
						"monitor_method":"simple",
						"zb_type":"tcp_port_10050_check",
						"realtime_yn": 'y',
						"data_type":"int",
						"value_type":"status",
						"period":CRI_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Zabbix Agent Port Check",
						"alarm_guide":{'name':'ZBA Connection Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Zabbix Agent 프로세스 확인: "service zabbix-agent status"
4. Down 상태일 경우 재기동: "service zabbix-agent start" """},
						"threshold":[
							{
								"name":"[Critical] ZBA Connection Release Alarm",
								"grade":"Critical",
								"description":"ZBA Connection Release",
								"repeat":"1", 
								"conditions":{"op":"<=", "value":"0"}
							}
						]
					}
				]
			},
			{'name': 'fan', "visible":'FAN', 'description':'Server Fan',
				'item':[
					{
						"name":"Fan Status",
						"visible":'Fan 상태', 
						"type":"Status",
						"value_type":"status",
						"data_type":"int",
						"period":MIN_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Server Fan Status",
						"plugin":{
								'name':'Fan Status', 'type':'file', 
								'script': '/usr/local/plugin'+'/hw/hp/ipmi_chassis.py',
								'param_num':2, 'plugin_param':['fan', 'status'], 'description':'Server Fan Status'
								},
						"alarm_guide":{'name':'Fan Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Fan 상태 확인 명령 수행: "ipmitool chassis status | grep Fan" 
4. 서버 FAN 상태 확인 및 서버 담당자 연락"""},
						"threshold":[
							{
								"name":"[Critical] Fan Status Down Alarm",
								"grade":"Critical",
								"description":"Server Fan Status Down",
								"repeat":"1", 
								"conditions":{"op":"<=", "value":"0"}
							}
						]
					}
				]
			},
			{'name': 'power', "visible":'Power', 'description':'Server Power',
				'item':[
					{
						"name":"Power OverLoad",
						"visible":'Power 과부하', 
						"type":"Overload",
						"value_type":"status",
						"data_type":"int",
						"period":MIN_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Server Power OverLoad Status",
						"plugin":{
								'name':'Power OverLoad', 'type':'file', 
								'script': '/usr/local/plugin'+'/hw/hp/ipmi_chassis.py',
								'param_num':2, 'plugin_param':['power', 'overload'], 'description':'Server Power OverLoad Status'
								},
						"alarm_guide":{'name':'Power OverLoad Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Power 상태 확인 명령 수행: "ipmitool chassis status | grep Power" 
4. 서버 담당자 연락"""},
						"threshold":[
							{
								"name":"[Critical] Power OverLoad Alarm",
								"grade":"Critical",
								"description":"Server Power OverLoad Fault",
								"repeat":"1", 
								"conditions":{"op":"<=", "value":"0"}
							}
						]
					},
					{
						"name":"Power Status",
						"visible":'Power 상태', 
						"type":"Status",
						"value_type":"status",
						"data_type":"int",
						"period":MAJ_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Server Power Status",
						"plugin":{
								'name':'Power Status', 'type':'file', 
								'script': '/usr/local/plugin'+'/hw/hp/ipmi_chassis.py',
								'param_num':2, 'plugin_param':['power', 'status'], 'description':'Server Power Status'
								},
						"alarm_guide":{'name':'Power Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Power 상태 확인 명령 수행: "ipmitool chassis status | grep Power" 
4. 서버 담당자 연락"""},
						"threshold":[
							{
								"name":"[Critical] Power Status Down Alarm",
								"grade":"Critical",
								"description":"Server Power Status Down",
								"repeat":"1", 
								"conditions":{"op":"<=", "value":"0"}
							}
						]
					},
					{
						"name":"Power Control Status",
						"visible":'Power 제어 상태', 
						"type":"Control",
						"value_type":"status",
						"data_type":"int",
						"period":MAJ_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Server Power Control Status",
						"plugin":{
								'name':'Power Control Status', 'type':'file', 
								'script': '/usr/local/plugin'+'/hw/hp/ipmi_chassis.py',
								'param_num':2, 'plugin_param':['power', 'control'], 'description':'Server Power Control Status'
								},
						"alarm_guide":{'name':'Power Control Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. Power 상태 확인 명령 수행: "ipmitool chassis status | grep Power" 
4. 서버 담당자 연락"""},
						"threshold":[
							{
								"name":"[Critical] Power Control Fault Alarm",
								"grade":"Critical",
								"description":"Server Power Control Fault",
								"repeat":"1", 
								"conditions":{"op":"<=", "value":"0"}
							}
						]
					}
				]
			}
		]
	}
	
	print( callZB( url, test ) )




if __name__ == '__main__':
	if len(sys.argv) >= 3:
		createTemp(sys.argv[1], sys.argv[2])
	else:
		print 'USAGE: CMD [D/S/P] [R/T]'
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


