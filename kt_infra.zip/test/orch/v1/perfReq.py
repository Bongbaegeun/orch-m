#!/usr/bin/python
#-*- coding: utf-8 -*-

import json
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

#URL = "http://211.224.204.203:5555/perf"
URL_NP = "http://220.123.31.82:5555/perf"

def callZB( url, reqBody, isJson=True ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=6 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	if isJson:
		resp = json.loads(response.body)
	else:
		resp = response
	return resp


def perfHistoryTest():
	test={ 
		'svr_uuid': '256bc0e6-68c7-11e6-9f06-f0921c1957ec',
		'itemseq': 32,
		'datatype': 'histroy',
		'stime': '2016-09-02 00:00:00',
		'etime': '2016-09-03 00:00:00'
		}
	#31,32,34,35,37,38
	ret = callZB( URL_NP, test )
	vals = ret['response']['perf_list']
	for res in vals :
		print str(datetime.fromtimestamp(float(res['clock']))) + ',' + res['value']
	#print( callZB( URL_NP, test ) )


def perfGraphTest():
	test={ 
		'svr_uuid': 'TEST-SVR-UUID-001',
		'itemseq': 1,
		'datatype': 'graph',
		'stime': '2015-10-31 23:39:51',
		'etime': '2015-10-31 23:40:51'
		}
	
	print( callZB( URL, test, False ) )

if __name__ == '__main__':
	
	perfHistoryTest()
# 	perfGraphTest()



