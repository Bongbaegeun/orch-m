#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.203:5555/target"
PLUGIN_DIR = "/usr/local/plugin"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	print response.code
	resp = json.loads(response.body)
	
	return resp


def createTemp():
	
	test={
		"tid":'temp-create-1',
		"target_info":{
				'code':'vim', 'type':'openstack', "name":"오픈스택-OneTouch", 
				'version':'kilo-onetouch', 'vendor_code':'openstack', "description":"오픈스택 원터치 감시",
				'model':'kilo', 'target_for':'OneTouch'
			},
		"group":[
			{'name': 'vcpu', 'description':'UTM VCPU Monitor',
				 "item":[
					{
						"name":"가상 CPU 부하",
						"type":"Load",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"active_yn":"n",
						"statistic_yn": 'y',
						"data_type":"float",
						"unit":"job",
						"period":"10",
						"history":"30",
						"statistic":"365",
						"description":"올레 UTM 가상 CPU 부하 감시",
						"plugin":{
								'name':'올레 UTM CPU Load', 'type':'file', 
								'script': PLUGIN_DIR+'/utm/olleh/utm_plugin.py',
								'param_num':'2', 'plugin_param':['cpu', 'load'], 'description':'Olleh UTM CPU Load',
								'lib_type':'file', 'lib_script':PLUGIN_DIR+'/utm/olleh/utm_api.py',
								'lib_name':'utm_api.py', 'lib_path':'./', 
								'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
								},
						"alarm_guide":{'name':'UTM VCPU Load Alarm', 'guide':'Check UTM Top Status'},
						"threshold":[
							{
								"name":"[Warning] UTM VCPU 부하 장애",
								"grade":"warning",
								"description":"Olleh UTM VCPU Load Warning",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"4"},{"op":"<", "value":"6"}]
							},
							{
								"name":"[Minor] UTM VCPU Load Alarm",
								"grade":"Minor",
								"description":"Olleh UTM VCPU Load Minor",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"6"},{"op":"<", "value":"7"}]
							},
							{
								"name":"[Major] UTM VCPU Load Alarm",
								"grade":"Major",
								"description":"Olleh UTM VCPU Load Major",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"7"},{"op":"<", "value":"8"}]
							},
							{
								"name":"[Critical] UTM VCPU Load Alarm",
								"grade":"Critical",
								"description":"Olleh UTM VCPU Load Critical",
								"repeat":"1", 
								"conditions":{"op":">=", "value":"8"}
							}
						]
					}
				]
			}
		]
	}
	
	print( callZB( URL, test ) )


if __name__ == '__main__':
	createTemp()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


