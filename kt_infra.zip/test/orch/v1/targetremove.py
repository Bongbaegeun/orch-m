#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'
RS_SVR = 'RS'

URL = "http://211.224.204.203:5555/target/remove"
URL_D = "http://211.224.204.203:5555/target/remove"
URL_S = "http://211.224.204.248:5555/target/remove"
URL_P = "http://211.224.204.222:5555/target/remove"
URL_RS = "http://210.183.241.171:5555/target/remove"
# URL = "http://211.224.204.248:5555/target/remove"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def removeTemp(sType, targetSeq):
	if sType == DEV_SVR :
		url = URL_D
	elif sType == STG_SVR :
		url = URL_S
	elif sType == PRT_SVR :
		url = URL_P
	elif sType == RS_SVR :
		url = URL_RS
	else:
		return
	
	test={'tid':'temp-remove-1', 'target_seq':targetSeq}
	
	print( callZB( url, test ) )




if __name__ == '__main__':
	if len(sys.argv) >= 3:
		removeTemp(str(sys.argv[1]), str(sys.argv[2]))
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


