#!/usr/bin/python
#-*- coding: utf-8 -*-

import json
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.203:5555/fault"
URL_PERF = "http://211.224.204.203:5555/perf"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=1 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def faultTest():
	test={	"to":URL,
			"subject":"[Warning] CPU Load -> OK",
			"body":{
				"host":{
			  	"name": "TEST-SVR-UUID-001",
			  	"visible": "OneBox03",
			  	"ip": "211.224.204.207"
			  },
			"item":[
			 	{"id": "25341", "key":"2.cpu.load", "name":"CPU load", "value":"2.58 job", "desc":"", "last_value": "2.58 job", "last_func":"2.58 job", "log_src": "*UNKNOWN*"},
			  	{"id": "25341", "key":"2.cpu.load", "name":"CPU load", "value":"2.58 job", "desc":""}
				],
			"event":{
			  "id": "62898", "status":"OK", "value": "0", "age": "0m", "date": "2015.10.20", "time": "15:53:05"
			  },
			"trigger":{
			  "id": "13650", "name":"[Warning] CPU Load", "template":"2. OS temp", "status":"OK", "status_code":"0", "grade":"Warning", "grade_code":"2", "desc":"dddd"
			  }
			}
		}
	
	print( callZB( URL, test ) )

	test={	"to":URL,
			"subject":"[Warning] CPU Load -> OK",
			"body":{
				"host":{
			  	"name": "TEST-SVR-UUID-001",
			  	"visible": "OneBox03",
			  	"ip": "211.224.204.207"
			  },
			"item":[
			 	{"id": "25341", "key":"4.net.satus[eth4]", "name":"CPU load", "value":"1", "desc":"", "last_value": "2.58 job", "last_func":"2.58 job", "log_src": "*UNKNOWN*"},
			  	{"id": "25341", "key":"4.net.satus[eth4]", "name":"CPU load", "value":"1", "desc":""}
				],
			"event":{
			  "id": "62898", "status":"OK", "value": "0", "age": "0m", "date": "2015.10.20", "time": "15:53:05"
			  },
			"trigger":{
			  "id": "13650", "name":"[Warning] CPU Load", "template":"2. OS temp", "status":"OK", "status_code":"0", "grade":"Warning", "grade_code":"2", "desc":"dddd"
			  }
			}
		}
	
	print( callZB( URL, test ) )


def perfData():
	
	print ( callZB( URL_PERF, test ) )










if __name__ == '__main__':
	
	faultTest()



