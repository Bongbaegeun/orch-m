#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'
NEW_PRT_SVR = 'NP'
RS_SVR = 'RS'

REAL_PLG = 'R'
TEST_PLG = 'T'

# URL = "http://211.224.204.203:5555/target"
URL = "http://211.224.204.248:5555/target"
URL_D = "http://211.224.204.203:5555/target"
URL_S = "http://211.224.204.248:5555/target"
URL_P = "http://211.224.204.222:5555/target"
URL_NP = "http://220.123.31.82:5555/target"
URL_RS = "http://210.183.241.171:5555/target"
PLUGIN_DIR = "/usr/local/plugin"
PLUGIN_TEST_DIR = "/usr/local/plugin/test"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def createTemp(sType, pType):
	HIST = "10"
	TRND = "180"
	
	CRI_P = "10"
	MAJ_P = "30"
	MIN_P = "60"
	WAN_P = "150"
	NOR_P = "300"
	
	if sType == DEV_SVR :
		url = URL_D
	elif sType == STG_SVR :
		url = URL_S
	elif sType == PRT_SVR :
		url = URL_P
	elif sType == NEW_PRT_SVR :
		url = URL_NP
	elif sType == RS_SVR :
		url = URL_RS
		CRI_P = "2"
		MAJ_P = "5"
		MIN_P = "10"
		WAN_P = "15"
		NOR_P = "20"
	else:
		return
	
	if pType == REAL_PLG :
		pDir = PLUGIN_DIR
		mType = '2.0'
	elif pType == TEST_PLG :
		pDir = PLUGIN_TEST_DIR
		mType = 'Test'
	else:
		return
	
	test={
		"tid":'temp-create-1',
		"target_info":{
				'code':'vnf', 'type':'WiFi-AC', "name":"VNF-WiFi-AC", 'visible':'WiMS[VNF]', 'model':mType,
				'vendor_code':'kt', "description":"KT APC %s Monitoring"%mType, 
				'version':'v1.0', 'target_for':'Provisioning'
			},
		"group":[
			{'name': 'openstack-vinfra-status', 'visible':'가상자원 상태', 'description':'OpenStack VirtualInfra Status Monitor',
			"discovery":[
					{
					"name":"VM Discovery",
					"period":MIN_P,
					"remain":"1",
					"description":"OpenStack VM Discovery",
					"return_field":'NAME',
					"plugin":{
							'name':'OpenStack VM Discovery', 'type':'file',
							'script': pDir+'/vim/openstack_prov/nova_discovery.py',
							'param_num':'0', 'description':'OpenStack VM Discovery',
							'lib_type':'file', 'lib_script':pDir+'/vim/openstack_prov/vim_api.py',
							'lib_name':'vim_api.py', 'lib_path':'./', 
							'cfg_name':'nova_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_vm"],
							'discovery_input':'vim_vm'
							},
					"item":[
							{
								"name":"WiMS VM Status",
								'visible':'VM 상태',
								"type":"VM Status",
								"data_type":"int",
								"value_type":"status",
								"period":MIN_P,
								"history":HIST,
								"statistic":TRND,
								"description":"OpenStack VM status",
								"plugin":{
										'name':'OpenStack VM Status', 'type':'file', 
										'script': pDir+'/vim/openstack_prov/vm-status.sh',
										'param_num':'1', 'description':'OpenStack VM Status'
										},
								"alarm_guide":{'name':'WiMS VM Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. VM 상태 확인: "nova list"
4. 다운 상태일 경우, VM 기동: "nova start $VM_NAME"
5. 장애 시, 개발팀에게 연락"""},
								"threshold":[
									{
										"name":"[Critical] WiMS VM Status Down Alarm",
										"grade":"critical",
										"description":"OpenStack WiMS VM Status Critical",
										"repeat":"1", 
										"conditions":{"op":"<=", "value":"0"}
									}
								]
							}
						]
					},
					{
					"name":"VPort Discovery",
					"period":MIN_P,
					"remain":"1",
					"description":"OpenStack VPort Discovery",
					"return_field":'NAME',
					"plugin":{
							'name':'OpenStack VPort Discovery', 'type':'file', 
							'script': pDir+'/vim/openstack_prov/neutron_discovery_prov.py',
							'param_num':'1', 'plugin_param':['PORT'], 'description':'OpenStack VPort Discovery',
							'lib_type':'file', 'lib_script':pDir+'/vim/openstack_prov/vim_api.py',
							'lib_name':'vim_api.py', 'lib_path':'./', 
							'cfg_name':'neutron_prov_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain', 'vim_port'],
							'discovery_input':'vim_port'
							},
					"item":[
							{
								"name":"WiMS VPort Status",
								'visible':'가상 Port 상태',
								"type":"VPort Status",
								"data_type":"int",
								"value_type":"status",
								"period":MIN_P,
								"history":HIST,
								"statistic":TRND,
								"description":"OpenStack VPort status",
								"plugin":{
										'name':'openstack vrouter status', 'type':'file',
										'script': pDir+'/vim/openstack_prov/vport-status.sh',
										'param_num':'1', 'description':'OpenStack VPort Status'
										},
								"alarm_guide":{'name':'WiMS VPort Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 가상 Port 상태 확인: "neutron port-list -c name -c fixed_ips -c status"
4. 장애 시, 개발팀에게 연락"""},
								"threshold":[
									{
										"name":"[Critical] WiMS VPort Status Down Alarm",
										"grade":"critical",
										"description":"OpenStack WiMS VPort Status Critical",
										"repeat":"1", 
										"conditions":{"op":"<=", "value":"0"}
									}
								]
							}
						]
					}
				]## discovery
			},
			{'name': 'vcpu', 'visible':'가상 CPU', 'description':'WiMS VCPU Monitor',
				 "item":[
					{
						"name":"VCPU Load",
						'visible':'가상 CPU 부하',
						"type":"Load",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"data_type":"float",
						"unit":"job",
						"period":MAJ_P,
						"history":HIST,
						"statistic":TRND,
						"description":"WiMS VCPU Load",
						"plugin":{
								'name':'WiMS CPU Load', 'type':'file', 
								'script': pDir+'/apc/olleh/apc_plugin.py',
								'param_num':'2', 'plugin_param':['cpu', 'load'], 'description':'WiMS CPU Load',
								'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
								'lib_name':'apc_api.py', 'lib_path':'./', 
								'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
								},
						"alarm_guide":{'name':'WiMS VCPU Load Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WiMS 클릭하여 WEB 접속 후 로그인
3. "Alarm"에서 장애 내역 확인
4. 장애 시, 개발팀 및 WiMS 담당자 연락"""},
						"threshold":[
							{
								"name":"[Warning] WiMS VCPU Load Alarm",
								"grade":"warning",
								"description":"WiMS VCPU Load Warning",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"4"},{"op":"<", "value":"6"}]
							},
							{
								"name":"[Minor] WiMS VCPU Load Alarm",
								"grade":"minor",
								"description":"WiMS VCPU Load Minor",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"6"},{"op":"<", "value":"7"}]
							},
							{
								"name":"[Major] WiMS VCPU Load Alarm",
								"grade":"major",
								"description":"WiMS VCPU Load Major",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"7"},{"op":"<", "value":"8"}]
							},
							{
								"name":"[Critical] WiMS VCPU Load Alarm",
								"grade":"Critical",
								"description":"WiMS VCPU Load Critical",
								"repeat":"1", 
								"conditions":{"op":">=", "value":"8"}
							}
						]
					},
					{
						"name":"VCPU Util",
						'visible':'가상 CPU 사용률',
						"type":"Util",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"data_type":"float",
						"unit":"%",
						"period":MAJ_P,
						"history":HIST,
						"statistic":TRND,
						"description":"WiMS VCPU Util",
						"plugin":{
								'name':'WiMS CPU Util', 'type':'file', 
								'script': pDir+'/apc/olleh/apc_plugin.py',
								'param_num':'2', 'plugin_param':['cpu', 'util'], 'description':'WiMS CPU Load',
								'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
								'lib_name':'apc_api.py', 'lib_path':'./', 
								'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
								},
						"alarm_guide":{'name':'WiMS VCPU Util Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WiMS 클릭하여 WEB 접속 후 로그인
3. "Alarm"에서 장애 내역 확인
4. 장애 시, 개발팀 및 WiMS 담당자 연락"""},
						"threshold":[
							{
								"name":"[Warning] WiMS VCPU Util Alarm",
								"grade":"warning",
								"description":"WiMS VCPU Util Warning",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
							},
							{
								"name":"[Minor] WiMS VCPU Util Alarm",
								"grade":"minor",
								"description":"WiMS VCPU Util Minor",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
							},
							{
								"name":"[Major] WiMS VCPU Util Alarm",
								"grade":"major",
								"description":"WiMS VCPU Util Major",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
							},
							{
								"name":"[Critical] WiMS VCPU Util Alarm",
								"grade":"Critical",
								"description":"WiMS VCPU Util Critical",
								"repeat":"1", 
								"conditions":{"op":">=", "value":"95"}
							}
						]
					}
				]
			},
			{'name': 'vmem', 'visible':'가상 메모리', 'description':'WiMS VMemory Monitor',
				 "item":[
					{
						"name":"VMEM UtilRate",
						'visible':'가상 메모리 사용률',
						"type":"Util",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"data_type":"int",
						"unit":"%",
						"period":MAJ_P,
						"history":HIST,
						"statistic":TRND,
						"description":"WiMS Memory UtilRate",
						"plugin":{
								'name':'WiMS Memory UtilRate', 'type':'file', 
								'script': pDir+'/apc/olleh/apc_plugin.py',
								'param_num':'2', 'plugin_param':['mem', 'util'], 'description':'WiMS Memory UtilRate',
								'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
								'lib_name':'apc_api.py', 'lib_path':'./', 
								'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
								},
						"alarm_guide":{'name':'WiMS VMem UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WiMS 클릭하여 Console 접속 후 로그인
3. 메모리 사용이 많은 프로세스 확인: "ps -aux --sort -rss | head -n $LINE_NUM"
4. 불필요한 프로세스 정지 또는 WiMS 담당자 연락"""},
						"threshold":[
							{
								"name":"[Warning] WiMS VMem UtilRate Alarm",
								"grade":"warning",
								"description":"WiMS VMem UtilRate Warning",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
							},
							{
								"name":"[Minor] WiMS VMem UtilRate Alarm",
								"grade":"Minor",
								"description":"WiMS VMem UtilRate Minor",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
							},
							{
								"name":"[Major] WiMS VMem UtilRate Alarm",
								"grade":"Major",
								"description":"WiMS VMem UtilRate Major",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
							},
							{
								"name":"[Critical] WiMS VMem UtilRate Alarm",
								"grade":"Critical",
								"description":"WiMS VMem UtilRate Critical",
								"repeat":"1", 
								"conditions":{"op":">=", "value":"95"}
							}
						]
					}
				]
			},
			{'name': 'vnet', 'visible':'가상 네트워크', 'description':'WiMS VNetwork Monitor',
			 "item":[
				{
					"name":"WiMS Connection",
					'visible':'WiMS 연결상태',
					"type":"Connection",
					"data_type":"int",
					"realtime_yn": 'y',
					"value_type":"status",
					"period":CRI_P,
					"history":HIST,
					"statistic":TRND,
					"description":"WiMS Connection Check",
					"plugin":{
							'name':'WiMS Network ConnTrack', 'type':'file', 
							'script': pDir+'/apc/olleh/apc_plugin.py',
							'param_num':'1', 'plugin_param':['ping'], 'description':'WiMS Connection Check',
							'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
							'lib_name':'apc_api.py', 'lib_path':'./', 
							'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
							},
					"alarm_guide":{'name':'WiMS Connection Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. "nova list" 명령을 통해 WiMS 접속IP 확인 후 SSH 연결: "ssh $WiMS_IP"
4. 장애 시, 개발팀 및 오픈스택 담당자 연락"""},
					"threshold":[
						{
							"name":"[Critical] WiMS Connection Alarm",
							"grade":"critical",
							"description":"WiMS Connection Critical",
							"repeat":"1", 
							"conditions":{"op":"<=", "value":"0"}
						}
					]
				}
				],
			"discovery":[
				{
				"name":"WiMS VNet Discovery",
				"period":MIN_P,
				"remain":"1",
				"description":"WiMS VNet Discovery",
				"return_field":'NAME',
				"plugin":{
						'name':'WiMS VNet Discovery', 'type':'file',
						'script': pDir+'/apc/olleh/apc_discovery.py',
						'param_num':'1', 'plugin_param':['NETLIST'], 'description':'WiMS VNet Discovery',
						'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
						'lib_name':'apc_api.py', 'lib_path':'./', 
						'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_net'],
						'discovery_input':'vm_net'
						},
				"item":[
						{
							"name":"WiMS VNet I/F Status",
							'visible':'WiMS 네트워크 상태',
							"type":"Status",
							"data_type":"int",
							"realtime_yn": 'y',
							"value_type":"status",
							"period":MIN_P,
							"history":HIST,
							"statistic":TRND,
							"description":"WiMS Network I/F Status",
							"plugin":{
									'name':'Olleh WiMS Network I/F Status', 'type':'file', 
									'script': pDir+'/apc/olleh/apc_plugin.py',
									'param_num':'3', 'plugin_param':['net', 'status'], 'description':'WiMS Network I/F Status',
									'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
									'lib_name':'apc_api.py', 'lib_path':'./', 
									'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
									},
							"alarm_guide":{'name':'WiMS VNet I/F Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WiMS 클릭하여 Console 접속 후 로그인
3. NIC 상태 확인: "ethtool $IF_NAME"
4. 장애 시, 개발팀 및 오픈스택 담당자 연락"""},
							"threshold":[
								{
									"name":"[Critical] WiMS VNet I/F Status Down",
									"grade":"critical",
									"description":"WiMS VNet I/F Status Down",
									"repeat":"1", 
									"conditions":{"op":"<=", "value":"0"}
								}
							]
						},
						{
							"name":"WiMS VNet Rx_Rate",
							'visible':'WiMS 네트워크 RxRate',
							"type":"Rx Rate",
							"unit":"bps",
							"graph_yn": 'y',
							"realtime_yn": 'y',
							"data_type":"int",
							"period":MAJ_P,
							"history":HIST,
							"statistic":TRND,
							"description":"WiMS Network Rx_Rate",
							"plugin":{
									'name':'WiMS Network Rx_Rate', 'type':'file', 
									'script': pDir+'/apc/olleh/apc_plugin.py',
									'param_num':'3', 'plugin_param':['net', 'rx_rate'], 'description':'WiMS Network Rx_Rate',
									'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
									'lib_name':'apc_api.py', 'lib_path':'./', 
									'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
									},
							"alarm_guide":{'name':'WiMS VNet Rx_Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WiMS 클릭하여 WEB 접속 후 로그인
3. "Alarm"에서 장애 내역 확인
4. 장애 시, 개발팀 및 WiMS 담당자 연락"""},
							"threshold":[
								{
									"name":"[Warning] WiMS VNet Rx_Rate Alarm",
									"grade":"warning",
									"description":"WiMS VNet Rx_Rate Warning",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"60000000"},{"op":"<", "value":"70000000"}]
								},
								{
									"name":"[Minor] WiMS VNet Rx_Rate Alarm",
									"grade":"Minor",
									"description":"WiMS VNet Rx_Rate Minor",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"70000000"},{"op":"<", "value":"80000000"}]
								},
								{
									"name":"[Major] WiMS VNet Rx_Rate Alarm",
									"grade":"Major",
									"description":"WiMS VNet Rx_Rate Major",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"80000000"},{"op":"<", "value":"90000000"}]
								},
								{
									"name":"[Critical] WiMS VNet Rx_Rate Alarm",
									"grade":"Critical",
									"description":"WiMS VNet Rx_Rate Critical",
									"repeat":"1", 
									"conditions":{"op":">=", "value":"90000000"}
								}
							]
						},
						{
							"name":"WiMS VNet Tx_Rate",
							'visible':'WiMS 네트워크 TxRate',
							"type":"Tx Rate",
							"unit":"bps",
							"graph_yn": 'y',
							"realtime_yn": 'y',
							"data_type":"int",
							"period":MAJ_P,
							"history":HIST,
							"statistic":TRND,
							"description":"WiMS Network Tx_Rate",
							"plugin":{
									'name':'WiMS Network Tx_Rate', 'type':'file', 
									'script': pDir+'/apc/olleh/apc_plugin.py',
									'param_num':'3', 'plugin_param':['net', 'tx_rate'], 'description':'WiMS Network Tx_Rate',
									'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
									'lib_name':'apc_api.py', 'lib_path':'./', 
									'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
									},
							"alarm_guide":{'name':'WiMS VNet Tx_Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WiMS 클릭하여 WEB 접속 후 로그인
3. "Alarm"에서 장애 내역 확인
4. 장애 시, 개발팀 및 WiMS 담당자 연락"""},
							"threshold":[
								{
									"name":"[Warning] WiMS VNet Tx_Rate Alarm",
									"grade":"warning",
									"description":"WiMS VNet Tx_Rate Warning",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"60000000"},{"op":"<", "value":"70000000"}]
								},
								{
									"name":"[Minor] WiMS VNet Tx_Rate Alarm",
									"grade":"Minor",
									"description":"WiMS VNet Tx_Rate Minor",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"70000000"},{"op":"<", "value":"80000000"}]
								},
								{
									"name":"[Major] WiMS VNet Tx_Rate Alarm",
									"grade":"Major",
									"description":"WiMS VNet Tx_Rate Major",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"80000000"},{"op":"<", "value":"90000000"}]
								},
								{
									"name":"[Critical] WiMS VNet Tx_Rate Alarm",
									"grade":"Critical",
									"description":"WiMS VNet Tx_Rate Critical",
									"repeat":"1", 
									"conditions":{"op":">=", "value":"90000000"}
								}
							]
						}
					]
				}
				]
			},
			{'name': 'vdisk', 'visible':'가상 Disk', 'description':'WiMS VDisk Monitor',
			"discovery":[
				{
				"name":"WiMS VDisk Discovery",
				"period":WAN_P,
				"remain":"1",
				"description":"WiMS VDisk Discovery",
				"return_field":'NAME',
				"plugin":{
						'name':'WiMS VDisk Discovery', 'type':'file',
						'script': pDir+'/apc/olleh/apc_discovery.py',
						'param_num':'1', 'plugin_param':['DISKLIST'], 'description':'WiMS VDisk Discovery',
						'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
						'lib_name':'apc_api.py', 'lib_path':'./', 
						'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_fs'],
						'discovery_input':'vm_fs'
						},
				"item":[
						{
							"name":"WiMS VDisk UtilRate",
							'visible':'WiMS Disk 사용률',
							"type":"Util",
							"unit":"%",
							"graph_yn": 'y',
							"realtime_yn": 'y',
							"data_type":"float",
							"period":WAN_P,
							"history":HIST,
							"statistic":TRND,
							"description":"WiMS VDisk UtilRate",
							"plugin":{
									'name':'WiMS VDisk UtilRate', 'type':'file', 
									'script': pDir+'/apc/olleh/apc_plugin.py',
									'param_num':'3', 'plugin_param':['disk', 'util'], 'description':'WiMS VDisk UtilRate',
									'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
									'lib_name':'apc_api.py', 'lib_path':'./', 
									'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
									},
							"alarm_guide":{'name':'WiMS VDisk UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WiMS 클릭하여 WEB 접속 후 로그인
3. "Alarm"에서 장애 내역 확인
4. 장애 시, 개발팀 및 WiMS 담당자 연락"""},
							"threshold":[
								{
									"name":"[Warning] WiMS VDisk UtilRate Alarm",
									"grade":"warning",
									"description":"WiMS VDisk UtilRate Warning",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
								},
								{
									"name":"[Minor] WiMS VDisk UtilRate Alarm",
									"grade":"Minor",
									"description":"WiMS VDisk UtilRate Minor",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
								},
								{
									"name":"[Major] WiMS VDisk UtilRate Alarm",
									"grade":"Major",
									"description":"WiMS VDisk UtilRate Major",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
								},
								{
									"name":"[Critical] WiMS VDisk UtilRate Alarm",
									"grade":"Critical",
									"description":"WiMS VDisk UtilRate Critical",
									"repeat":"1", 
									"conditions":{"op":">=", "value":"95"}
								}
							]
						}
					]
				}
				]
			},
			{'name': 'ap', 'visible':'관리 AP', 'description':'WiMS AP Monitor',
			"item":[
				{
					"name":"WiMS AP Count",
					'visible':'연동AP Count',
					"graph_yn": 'y',
					"realtime_yn": 'y',
					"type":"APCount",
					"data_type":"int",
					"period":MIN_P,
					"history":HIST,
					"statistic":TRND,
					"description":"WiMS AP Count Check",
					"plugin":{
							'name':'WiMS AP Count', 'type':'file', 
							'script': pDir+'/apc/olleh/apc_plugin.py',
							'param_num':'1', 'plugin_param':['ap_count'], 'description':'WiMS AP Count Check',
							'lib_type':'file', 'lib_script':pDir+'/apc/olleh/apc_api.py',
							'lib_name':'apc_api.py', 'lib_path':'./', 
							'cfg_name':'apc_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
							},
					"alarm_guide":{'name':'WiMS AP Count Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 WiMS 클릭하여 WEB 접속 후 로그인
3. "AP List"에서 AP 목록 확인
4. 장애 시, 개발팀 및 WiMS 담당자 연락"""}
				}
				]
			},
		]
	}
	
	print( callZB( url, test ) )




if __name__ == '__main__':
	if len(sys.argv) >= 3:
		createTemp(sys.argv[1], sys.argv[2])
	else:
		print 'USAGE: CMD [D/S/P/NP/RS] [R/T]'
# 	createTemp()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


