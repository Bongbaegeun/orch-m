#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'
NEW_PRT_SVR = 'NP'
RS_SVR = 'RS'

REAL_PLG = 'R'
TEST_PLG = 'T'

URL = "http://211.224.204.203:5555/target"
URL_D = "http://211.224.204.203:5555/target"
URL_S = "http://211.224.204.248:5555/target"
URL_P = "http://211.224.204.222:5555/target"
URL_NP = "http://220.123.31.82:5555/target"
URL_RS = "http://210.183.241.171:5555/target"
# URL = "http://211.224.204.248:5555/target"
PLUGIN_DIR = "/usr/local/plugin"
PLUGIN_TEST_DIR = "/usr/local/plugin/test"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def createTemp(sType, pType, tType):
	HIST = "10"
	TRND = "180"
	
	CRI_P = "10"
	MAJ_P = "30"
	MIN_P = "60"
	WAN_P = "150"
	NOR_P = "300"
	
	if sType == DEV_SVR :
		url = URL_D
	elif sType == STG_SVR :
		url = URL_S
	elif sType == PRT_SVR :
		url = URL_P
	elif sType == NEW_PRT_SVR :
		url = URL_NP
	elif sType == RS_SVR :
		url = URL_RS
		CRI_P = "2"
		MAJ_P = "5"
		MIN_P = "10"
		WAN_P = "15"
		NOR_P = "20"
	else:
		return
	
	if pType == REAL_PLG :
		pDir = PLUGIN_DIR
		mType = '1.0'
	elif pType == TEST_PLG :
		pDir = PLUGIN_TEST_DIR
		mType = 'Test'
	else:
		return
	
	if int(tType) == 1:
		tInfo = {
				'code':'vnf', 'type':'UTM', "name":"VNF-UTM", 'visible':'UTM[VNF]', 'model':mType,
				'vendor_code':'olleh', "description":"Olleh UTM Monitoring(UTM-Only)", 
				'version':'v1.0', 'target_for':'Provisioning'
				}
	elif int(tType) == 2:
		tInfo = {
				'code':'vnf', 'type':'UTM', "name":"VNF-UTM", 'visible':'UTM[VNF]', 'model':mType,
				'vendor_code':'olleh', "description":"Olleh UTM Monitoring(UTM-withWAF)", 
				'version':'v2.0', 'target_for':'Provisioning'
				}
	elif int(tType) == 3:
		tInfo = {
				'code':'vnf', 'type':'UTM', "name":"VNF-UTM", 'visible':'UTM[VNF]', 'model':mType,
				'vendor_code':'olleh', "description":"Olleh UTM Monitoring(UTM-withWiMS)", 
				'version':'v3.0', 'target_for':'Provisioning'
				}
	else:
		return
	
	test={
		"tid":'temp-create-1',
		"target_info":tInfo,
		"group":[
			{'name': 'openstack-vinfra-status', 'visible':'가상자원 상태', 'description':'OpenStack VirtualInfra Status Monitor',
			"discovery":[
					{
					"name":"VM Discovery",
					"period":MIN_P,
					"remain":"1",
					"description":"OpenStack VM Discovery",
					"return_field":'NAME',
					"plugin":{
							'name':'OpenStack VM Discovery', 'type':'file',
							'script': pDir+'/vim/openstack_prov/nova_discovery.py',
							'param_num':'0', 'description':'OpenStack VM Discovery',
							'lib_type':'file', 'lib_script':pDir+'/vim/openstack_prov/vim_api.py',
							'lib_name':'vim_api.py', 'lib_path':'./', 
							'cfg_name':'nova_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_vm"],
							'discovery_input':'vim_vm'
							},
					"item":[
							{
								"name":"UTM VM Status",
								'visible':'VM 상태',
								"type":"VM Status",
								"data_type":"int",
								"value_type":"status",
								"period":MIN_P,
								"history":HIST,
								"statistic":TRND,
								"description":"OpenStack VM status",
								"plugin":{
										'name':'OpenStack VM Status', 'type':'file', 
										'script': pDir+'/vim/openstack_prov/vm-status.sh',
										'param_num':'1', 'description':'OpenStack VM Status'
										},
								"alarm_guide":{'name':'UTM VM Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. VM 상태 확인: "nova list"
4. 다운 상태일 경우, VM 기동: "nova start $VM_NAME"
5. 장애 시, 오픈스택 관리자에게 연락"""},
								"threshold":[
									{
										"name":"[Critical] UTM VM Status Down Alarm",
										"grade":"critical",
										"description":"OpenStack UTM VM Status Critical",
										"repeat":"1", 
										"conditions":{"op":"<=", "value":"0"}
									}
								]
							}
						]
					},
					{
					"name":"VPort Discovery",
					"period":MIN_P,
					"remain":"1",
					"description":"OpenStack VPort Discovery",
					"return_field":'NAME',
					"plugin":{
							'name':'OpenStack VPort Discovery', 'type':'file', 
							'script': pDir+'/vim/openstack_prov/neutron_discovery_prov.py',
							'param_num':'1', 'plugin_param':['PORT'], 'description':'OpenStack VPort Discovery',
							'lib_type':'file', 'lib_script':pDir+'/vim/openstack_prov/vim_api.py',
							'lib_name':'vim_api.py', 'lib_path':'./', 
							'cfg_name':'neutron_prov_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vim_auth_url', 'vim_id', 'vim_passwd', 'vim_domain', 'vim_port'],
							'discovery_input':'vim_port'
							},
					"item":[
							{
								"name":"UTM VPort Status",
								'visible':'가상 Port 상태',
								"type":"VPort Status",
								"data_type":"int",
								"value_type":"status",
								"period":MIN_P,
								"history":HIST,
								"statistic":TRND,
								"description":"OpenStack VPort status",
								"plugin":{
										'name':'openstack vrouter status', 'type':'file',
										'script': pDir+'/vim/openstack_prov/vport-status.sh',
										'param_num':'1', 'description':'OpenStack VPort Status'
										},
								"alarm_guide":{'name':'UTM VPort Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. 가상 Port 상태 확인: "neutron port-list -c name -c fixed_ips -c status"
4. 장애 시, 오픈스택 관리자에게 연락"""},
								"threshold":[
									{
										"name":"[Critical] UTM VPort Status Down Alarm",
										"grade":"critical",
										"description":"OpenStack UTM VPort Status Critical",
										"repeat":"1", 
										"conditions":{"op":"<=", "value":"0"}
									}
								]
							}
						]
					}
				]## discovery
			},
			{'name': 'vcpu', 'visible':'가상 CPU', 'description':'UTM VCPU Monitor',
				 "item":[
					{
						"name":"VCPU Load",
						'visible':'가상 CPU 부하',
						"type":"Load",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"statistic_yn": 'y',
						"data_type":"float",
						"unit":"job",
						"period":MAJ_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Olleh UTM VCPU Load",
						"plugin":{
								'name':'Olleh UTM CPU Load', 'type':'file', 
								'script': pDir+'/utm/olleh/utm_plugin.py',
								'param_num':'2', 'plugin_param':['cpu', 'load'], 'description':'Olleh UTM CPU Load',
								'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
								'lib_name':'utm_api.py', 'lib_path':'./', 
								'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
								},
						"alarm_guide":{'name':'UTM VCPU Load Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
						"threshold":[
							{
								"name":"[Warning] UTM VCPU Load Alarm",
								"grade":"warning",
								"description":"Olleh UTM VCPU Load Warning",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"4"},{"op":"<", "value":"6"}]
							},
							{
								"name":"[Minor] UTM VCPU Load Alarm",
								"grade":"minor",
								"description":"Olleh UTM VCPU Load Minor",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"6"},{"op":"<", "value":"7"}]
							},
							{
								"name":"[Major] UTM VCPU Load Alarm",
								"grade":"major",
								"description":"Olleh UTM VCPU Load Major",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"7"},{"op":"<", "value":"8"}]
							},
							{
								"name":"[Critical] UTM VCPU Load Alarm",
								"grade":"Critical",
								"description":"Olleh UTM VCPU Load Critical",
								"repeat":"1", 
								"conditions":{"op":">=", "value":"8"}
							}
						]
					},
					{
						"name":"VCPU Util",
						'visible':'가상 CPU 사용률',
						"type":"Util",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"statistic_yn": 'y',
						"data_type":"float",
						"unit":"%",
						"period":MAJ_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Olleh UTM VCPU Util",
						"plugin":{
								'name':'Olleh UTM CPU Util', 'type':'file', 
								'script': pDir+'/utm/olleh/utm_plugin.py',
								'param_num':'2', 'plugin_param':['cpu', 'util'], 'description':'Olleh UTM CPU Util',
								'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
								'lib_name':'utm_api.py', 'lib_path':'./', 
								'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
								},
						"alarm_guide":{'name':'UTM VCPU Util Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. CPU 사용이 많은 프로세스 확인: "ps -aux --sort -pcpu | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
						"threshold":[
							{
								"name":"[Warning] UTM VCPU Util Alarm",
								"grade":"warning",
								"description":"Olleh UTM VCPU Util Warning",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
							},
							{
								"name":"[Minor] UTM VCPU Util Alarm",
								"grade":"minor",
								"description":"Olleh UTM VCPU Util Minor",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
							},
							{
								"name":"[Major] UTM VCPU Util Alarm",
								"grade":"major",
								"description":"Olleh UTM VCPU Util Major",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
							},
							{
								"name":"[Critical] UTM VCPU Util Alarm",
								"grade":"Critical",
								"description":"Olleh UTM VCPU Util Critical",
								"repeat":"1", 
								"conditions":{"op":">=", "value":"95"}
							}
						]
					}
				]
			},
			{'name': 'vmem', 'visible':'가상 메모리', 'description':'UTM VMemory Monitor',
				 "item":[
					{
						"name":"VMEM UtilRate",
						'visible':'가상 메모리 사용률',
						"type":"Util",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"statistic_yn": 'y',
						"data_type":"int",
						"unit":"%",
						"period":MAJ_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Olleh UTM Memory UtilRate",
						"plugin":{
								'name':'Olleh UTM Memory UtilRate', 'type':'file', 
								'script': pDir+'/utm/olleh/utm_plugin.py',
								'param_num':'2', 'plugin_param':['mem', 'util'], 'description':'Olleh UTM Memory UtilRate',
								'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
								'lib_name':'utm_api.py', 'lib_path':'./', 
								'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
								},
						"alarm_guide":{'name':'UTM VMem UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. 메모리 사용이 많은 프로세스 확인: "ps -aux --sort -rss | head -n $LINE_NUM"
4. 불필요한 프로세스 정지"""},
						"threshold":[
							{
								"name":"[Warning] UTM VMem UtilRate Alarm",
								"grade":"warning",
								"description":"Olleh UTM VMem UtilRate Warning",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
							},
							{
								"name":"[Minor] UTM VMem UtilRate Alarm",
								"grade":"Minor",
								"description":"Olleh UTM VMem UtilRate Minor",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
							},
							{
								"name":"[Major] UTM VMem UtilRate Alarm",
								"grade":"Major",
								"description":"Olleh UTM VMem UtilRate Major",
								"repeat":"1", 
								"conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
							},
							{
								"name":"[Critical] UTM VMem UtilRate Alarm",
								"grade":"Critical",
								"description":"Olleh UTM VMem UtilRate Critical",
								"repeat":"1", 
								"conditions":{"op":">=", "value":"95"}
							}
						]
					}
				]
			},
			{'name': 'vnet', 'visible':'가상 네트워크', 'description':'UTM VNetwork Monitor',
			 "item":[
				{
					"name":"UTM ConnTrack",
					'visible':'UTM ConnTrack',
					"type":"ConnTrack",
					"graph_yn": 'y',
					"realtime_yn": 'y',
					"statistic_yn": 'y',
					"data_type":"int",
					"period":MAJ_P,
					"history":HIST,
					"statistic":TRND,
					"description":"Olleh UTM Network ConnTrack",
					"plugin":{
							'name':'Olleh UTM Network ConnTrack', 'type':'file', 
							'script': pDir+'/utm/olleh/utm_plugin.py',
							'param_num':'2', 'plugin_param':['net', 'conntrack'], 'description':'Olleh UTM Network ConnTrack',
							'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
							'lib_name':'utm_api.py', 'lib_path':'./', 
							'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
							},
					"alarm_guide":{'name':'UTM VNet ConnTrack Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""}
				},
				{
					"name":"UTM Connection",
					'visible':'UTM 연결상태',
					"type":"Connection",
					"data_type":"int",
					"realtime_yn": 'y',
					"value_type":"status",
					"period":CRI_P,
					"history":HIST,
					"statistic":TRND,
					"description":"Olleh UTM Connection Check",
					"plugin":{
							'name':'Olleh UTM Connection', 'type':'file', 
							'script': pDir+'/utm/olleh/utm_plugin.py',
							'param_num':'1', 'plugin_param':['ping'], 'description':'Olleh UTM Connection Check',
							'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
							'lib_name':'utm_api.py', 'lib_path':'./', 
							'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
							},
					"alarm_guide":{'name':'UTM Connection Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버 Console 접속 후 로그인
3. UTM Public IP의 Ping 확인: "ping $UTM_PUBLIC_IP"
4. 장애 시, 개발팀 및 오픈스택 담당자 연락"""},
					"threshold":[
						{
							"name":"[Critical] UTM Connection Alarm",
							"grade":"critical",
							"description":"Olleh UTM Connection Critical",
							"repeat":"3", 
							"conditions":{"op":"<=", "value":"0"}
						}
					]
				},
				{
					"name":"UTM Internet Connection",
					'visible':'UTM 인터넷 연결상태',
					"type":"InterConnection",
					"graph_yn": 'y',
					"data_type":"int",
					"value_type":"status",
					"period":CRI_P,
					"history":HIST,
					"statistic":TRND,
					"description":"Olleh UTM Internet Connection Check",
					"plugin":{
							'name':'Olleh UTM Internet Connection', 'type':'file', 
							'script': pDir+'/utm/olleh/utm_plugin.py',
							'param_num':'1', 'plugin_param':['internet'], 'description':'Olleh UTM Internet Connection Check',
							'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
							'lib_name':'utm_api.py', 'lib_path':'./', 
							'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
							},
					"alarm_guide":{'name':'Olleh UTM Internet Connection Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. WAN 인터페이스 확인 : "ethtool eth1"
4. Default GateWay 확인 : "ip route | grep default"
5. 장애 시, UTM 담당자 연락"""},
					"threshold":[
						{
							"name":"[Critical] Olleh UTM Internet Connection Alarm",
							"grade":"critical",
							"description":"Olleh UTM Internet Connection Critical",
							"repeat":"3", 
							"conditions":{"op":"<=", "value":"0"}
						}
					]
				}
				],
			"discovery":[
				{
				"name":"UTM VNet Discovery",
				"period":MIN_P,
				"remain":"1",
				"description":"Olleh UTM VNet Discovery",
				"return_field":'NAME',
				"plugin":{
						'name':'Olleh UTM VNet Discovery', 'type':'file',
						'script': pDir+'/utm/olleh/utm_discovery.py',
						'param_num':'1', 'plugin_param':['NETLIST'], 'description':'Olleh UTM VNet Discovery',
						'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
						'lib_name':'utm_api.py', 'lib_path':'./', 
						'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_net'],
						'discovery_input':'vm_net'
						},
				"item":[
						{
							"name":"UTM VNet I/F Status",
							'visible':'UTM 네트워크 상태',
							"type":"Status",
							"data_type":"int",
							"realtime_yn": 'y',
							"value_type":"status",
							"period":MIN_P,
							"history":HIST,
							"statistic":TRND,
							"description":"Olleh UTM Network I/F Status",
							"plugin":{
									'name':'Olleh UTM Network I/F Status', 'type':'file', 
									'script': pDir+'/utm/olleh/utm_plugin.py',
									'param_num':'3', 'plugin_param':['net', 'status'], 'description':'Olleh UTM Network I/F Status',
									'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
									'lib_name':'utm_api.py', 'lib_path':'./', 
									'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
									},
							"alarm_guide":{'name':'UTM VNet I/F Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. NIC 상태 확인: "ethtool $IF_NAME"
4. 장애 시, 개발팀 연락"""},
							"threshold":[
								{
									"name":"[Critical] UTM VNet I/F Status Down",
									"grade":"critical",
									"description":"UTM VNet I/F Status Down",
									"repeat":"1", 
									"conditions":{"op":"<=", "value":"0"}
								}
							]
						},
						{
							"name":"UTM VNet Rx_Rate",
							'visible':'UTM 네트워크 RxRate',
							"type":"Rx Rate",
							"graph_yn": 'y',
							"realtime_yn": 'y',
							"statistic_yn": 'y',
							"data_type":"int",
							"unit":"bps",
							"period":MAJ_P,
							"history":HIST,
							"statistic":TRND,
							"description":"Olleh UTM Network Rx_Rate",
							"plugin":{
									'name':'Olleh UTM Network Rx_Rate', 'type':'file', 
									'script': pDir+'/utm/olleh/utm_plugin.py',
									'param_num':'3', 'plugin_param':['net', 'rx_rate'], 'description':'Olleh UTM Network Rx_Rate',
									'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
									'lib_name':'utm_api.py', 'lib_path':'./', 
									'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
									},
							"alarm_guide":{'name':'UTM VNet Rx_Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. RX 대역폭 확인: "ifstat -i $IF_NAME"
4. 장애 시, 개발팀과 UTM 담당자에게 연락"""},
							"threshold":[
								{
									"name":"[Warning] UTM VNet Rx_Rate Alarm",
									"grade":"warning",
									"description":"Olleh UTM VNet Rx_Rate Warning",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"60000000"},{"op":"<", "value":"70000000"}]
								},
								{
									"name":"[Minor] UTM VNet Rx_Rate Alarm",
									"grade":"Minor",
									"description":"Olleh UTM VNet Rx_Rate Minor",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"70000000"},{"op":"<", "value":"80000000"}]
								},
								{
									"name":"[Major] UTM VNet Rx_Rate Alarm",
									"grade":"Major",
									"description":"Olleh VNet Rx_Rate Major",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"80000000"},{"op":"<", "value":"90000000"}]
								},
								{
									"name":"[Critical] UTM VNet Rx_Rate Alarm",
									"grade":"Critical",
									"description":"Olleh UTM VNet Rx_Rate Critical",
									"repeat":"1", 
									"conditions":{"op":">=", "value":"90000000"}
								}
							]
						},
						{
							"name":"UTM VNet Tx_Rate",
							'visible':'UTM 네트워크 TxRate',
							"type":"Tx Rate",
							"graph_yn": 'y',
							"realtime_yn": 'y',
							"statistic_yn": 'y',
							"data_type":"int",
							"unit":"bps",
							"period":MAJ_P,
							"history":HIST,
							"statistic":TRND,
							"description":"Olleh UTM Network Tx_Rate",
							"plugin":{
									'name':'Olleh UTM Network Tx_Rate', 'type':'file', 
									'script': pDir+'/utm/olleh/utm_plugin.py',
									'param_num':'3', 'plugin_param':['net', 'tx_rate'], 'description':'Olleh UTM Network Tx_Rate',
									'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
									'lib_name':'utm_api.py', 'lib_path':'./', 
									'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
									},
							"alarm_guide":{'name':'UTM VNet Tx_Rate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. TX 대역폭 확인: "ifstat -i $IF_NAME"
4. 장애 시, 개발팀과 UTM 담당자에게 연락"""},
							"threshold":[
								{
									"name":"[Warning] UTM VNet Tx_Rate Alarm",
									"grade":"warning",
									"description":"Olleh UTM VNet Tx_Rate Warning",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"60000000"},{"op":"<", "value":"70000000"}]
								},
								{
									"name":"[Minor] UTM VNet Tx_Rate Alarm",
									"grade":"Minor",
									"description":"Olleh UTM VNet Tx_Rate Minor",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"70000000"},{"op":"<", "value":"80000000"}]
								},
								{
									"name":"[Major] UTM VNet Tx_Rate Alarm",
									"grade":"Major",
									"description":"Olleh VNet Tx_Rate Major",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"80000000"},{"op":"<", "value":"90000000"}]
								},
								{
									"name":"[Critical] UTM VNet Tx_Rate Alarm",
									"grade":"Critical",
									"description":"Olleh UTM VNet Tx_Rate Critical",
									"repeat":"1", 
									"conditions":{"op":">=", "value":"90000000"}
								}
							]
						}
					]
				}
				]
			},
			{'name': 'vdisk', 'visible':'가상 Disk', 'description':'UTM VDisk Monitor',
			"discovery":[
				{
				"name":"UTM VDisk Discovery",
				"period":WAN_P,
				"remain":"1",
				"description":"Olleh UTM VDisk Discovery",
				"return_field":'NAME',
				"plugin":{
						'name':'Olleh UTM VDisk Discovery', 'type':'file',
						'script': pDir+'/utm/olleh/utm_discovery.py',
						'param_num':'1', 'plugin_param':['DISKLIST'], 'description':'Olleh UTM VDisk Discovery',
						'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
						'lib_name':'utm_api.py', 'lib_path':'./', 
						'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_fs'],
						'discovery_input':'vm_fs'
						},
				"item":[
						{
							"name":"UTM VDisk UtilRate",
							'visible':'UTM Disk 사용률',
							"type":"Util",
							"data_type":"float",
							"graph_yn": 'y',
							"realtime_yn": 'y',
							"unit":"%",
							"period":WAN_P,
							"history":HIST,
							"statistic":TRND,
							"description":"Olleh UTM VDisk UtilRate",
							"plugin":{
									'name':'Olleh UTM VDisk UtilRate', 'type':'file', 
									'script': pDir+'/utm/olleh/utm_plugin.py',
									'param_num':'3', 'plugin_param':['disk', 'util'], 'description':'Olleh UTM VDisk UtilRate',
									'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
									'lib_name':'utm_api.py', 'lib_path':'./', 
									'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
									},
							"alarm_guide":{'name':'UTM VDisk UtilRate Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. 파일시스템 사용률 확인: "du -sh /*"
4. 사용량이 많은 파일 용도를 파악하여 불필요할 경우 삭제"""},
							"threshold":[
								{
									"name":"[Warning] UTM VDisk UtilRate Alarm",
									"grade":"warning",
									"description":"Olleh UTM VDisk UtilRate Warning",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"70"},{"op":"<", "value":"80"}]
								},
								{
									"name":"[Minor] UTM VDisk UtilRate Alarm",
									"grade":"Minor",
									"description":"Olleh UTM VDisk UtilRate Minor",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"80"},{"op":"<", "value":"90"}]
								},
								{
									"name":"[Major] UTM VDisk UtilRate Alarm",
									"grade":"Major",
									"description":"Olleh VDisk UtilRate Major",
									"repeat":"1", 
									"conditions":["and", {"op":">=", "value":"90"},{"op":"<", "value":"95"}]
								},
								{
									"name":"[Critical] UTM VDisk UtilRate Alarm",
									"grade":"Critical",
									"description":"Olleh UTM VDisk UtilRate Critical",
									"repeat":"1", 
									"conditions":{"op":">=", "value":"95"}
								}
							]
						}
					]
				}
				]
			},
			{'name': 'Job', 'visible':'UTM Job', 'description':'UTM Job Monitor',
			"discovery":[
				{
				"name":"UTM Job Discovery",
				"period":WAN_P,
				"remain":"1",
				"description":"Olleh UTM Job Discovery",
				"return_field":'NAME',
				"plugin":{
						'name':'Olleh UTM Job Discovery', 'type':'file',
						'script': pDir+'/utm/olleh/utm_discovery.py',
						'param_num':'1', 'plugin_param':['JOBLIST'], 'description':'Olleh UTM VDisk Discovery',
						'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
						'lib_name':'utm_api.py', 'lib_path':'./', 
						'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip', 'vm_job'],
						'discovery_input':'vm_job'
						},
				"item":[
						{
							"name":"UTM Job Status",
							'visible':'UTM Job 상태',
							"type":"Status",
							"data_type":"int",
							"value_type":"status",
							"period":MIN_P,
							"history":HIST,
							"statistic":TRND,
							"description":"Olleh UTM Job Status",
							"plugin":{
									'name':'Olleh UTM Job Status', 'type':'file', 
									'script': pDir+'/utm/olleh/utm_plugin.py',
									'param_num':'2', 'plugin_param':['job'], 'description':'Olleh UTM Job Status',
									'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
									'lib_name':'utm_api.py', 'lib_path':'./', 
									'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
									},
							"alarm_guide":{'name':'UTM Job Status Alarm', 'guide':"""1. Inventory -> 자원관리 클릭
2. One-Box 서버에서 UTM 클릭하여 Console 접속 후 로그인
3. Job 상태 확인: "jobcontrol list | grep $JOB_NAME"
4. 장애 시, UTM 담당자 연락"""},
							"threshold":[
								{
									"name":"[Critical] UTM Job Status Down",
									"grade":"critical",
									"description":"UTM Job Status Down",
									"repeat":"1", 
									"conditions":{"op":"<=", "value":"0"}
								}
							]
						}
					]
				}
				]
			},
			{'name': 'dhcp', 'visible':'DHCP', 'description':'UTM DHCP Monitor',
				 "item":[
					{
						"name":"DHCP Usage",
						'visible':'UTM DHCP 사용량',
						"type":"Usage",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"statistic_yn": 'y',
						"data_type":"int",
						"period":MIN_P,
						"history":HIST,
						"statistic":TRND,
						"description":"Olleh UTM DHCP Usage",
						"plugin":{
								'name':'Olleh UTM DHCP Usage', 'type':'file', 
								'script': pDir+'/utm/olleh/utm_plugin.py',
								'param_num':'1', 'plugin_param':['dhcp'], 'description':'Olleh UTM DHCP Usage',
								'lib_type':'file', 'lib_script':pDir+'/utm/olleh/utm_api.py',
								'lib_name':'utm_api.py', 'lib_path':'./', 
								'cfg_name':'utm_cfg.yaml', 'cfg_path':'./', 'cfg_input':['vm_ip']
								},
						"alarm_guide":{'name':'UTM DHCP Usage Alarm', 'guide':"""1. 장애 시, 개발팀 및 UTM 담당자 연락"""}
					}
				]
			},
		]
	}
	
	print( callZB( url, test ) )




if __name__ == '__main__':
	if len(sys.argv) >= 4:
		createTemp(sys.argv[1], sys.argv[2], int(sys.argv[3]))
	else:
		print 'USAGE: CMD [D/S/P/NP/RS] [R/T] [1/2/3]'
# 	createTemp()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


