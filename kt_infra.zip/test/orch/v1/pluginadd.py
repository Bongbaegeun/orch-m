#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.203:5555/plugin"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp

# params
# Mandatory: name, type, target_seq
# Option: script, group_seq, plugin_param, param_num, description, 
#    lib_type, lib_script, lib_path, lib_name
#    cfg_path, cfg_name, cfg_input 
def addPlugin():
	# ob1
# 	test={
# 		'tid':'plg-add-1',
# 		'name':'test-add-p', 'type':'builtin', 'target_seq':'7'
# 		}
	
# 	test={
# 		'tid':'plg-add-1',
# 		'name':'test-add-p', 'type':'text', 'target_seq':'6',
# 		'script': 'ps -ef | grep $1'
# # 		,
# 		}
	
	
	test={
		'tid':'plg-add-1',
		'name':'openstack image discovery', 'type':'file', 'target_seq':'6',
		'script': '/usr/local/plugin/vim/openstack_prov/glance_discovery.py',
		'param_num':'0', 'description':'OpenStack Image Discovery',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'glance_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_image"],
		'discovery_input':'vim_image'
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vm discovery', 'type':'file', 'target_seq':'7',
		'script': '/usr/local/plugin/vim/openstack_prov/nova_discovery.py',
		'param_num':'0', 'description':'OpenStack VM Discovery',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'nova_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_vm"],
		'discovery_input':'vim_vm'
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vnet discovery', 'type':'file', 'target_seq':'6',
		'script': '/usr/local/plugin/vim/openstack_prov/neutron_discovery.py',
		'param_num':'1', 'plugin_param':["NET"], 'description':'OpenStack VNetwork Discovery',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'neutron_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_net", "vim_router"],
		'discovery_input':'vim_net'
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vrouter discovery', 'type':'file', 'target_seq':'6',
		'script': '/usr/local/plugin/vim/openstack_prov/neutron_discovery.py',
		'param_num':'1', 'plugin_param':["ROUTER"], 'description':'OpenStack VRouter Discovery',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'neutron_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_net", "vim_router"],
		'discovery_input':'vim_router'
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vport discovery', 'type':'file', 'target_seq':'7',
		'script': '/usr/local/plugin/vim/openstack_prov/neutron_discovery_prov.py',
		'param_num':'1', 'plugin_param':["PORT"], 'description':'OpenStack VPort Discovery',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'neutron_prov_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net", "vim_port"],
		'discovery_input':"vim_port"
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack image status', 'type':'file', 'target_seq':'6', 'group_seq':'18',
		'script': '/usr/local/plugin/vim/openstack_prov/image-status.sh',
		'param_num':'1', 'description':'OpenStack Image Status'
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vnet quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/neutron_quota_usage.py',
		'param_num':'1', 'plugin_param':["NETWORK"], 'description':'OpenStack VNet Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vsubnet quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/neutron_quota_usage.py',
		'param_num':'1', 'plugin_param':["SUBNET"], 'description':'OpenStack VSubNet Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vport quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/neutron_quota_usage.py',
		'param_num':'1', 'plugin_param':["PORT"], 'description':'OpenStack VPort Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vrouter quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/neutron_quota_usage.py',
		'param_num':'1', 'plugin_param':["ROUTER"], 'description':'OpenStack VRouter Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack floatingip quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/neutron_quota_usage.py',
		'param_num':'1', 'plugin_param':["FLOATINGIP"], 'description':'OpenStack FLOATINGIP Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack securityGroup quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/neutron_quota_usage.py',
		'param_num':'1', 'plugin_param':["SECUGROUP"], 'description':'OpenStack SECUGROUP Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack securityGroupRule quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/neutron_quota_usage.py',
		'param_num':'1', 'plugin_param':["SECUGROUPRULE"], 'description':'OpenStack SECUGROUPRULE Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack instance quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/nova_quota_usage.py',
		'param_num':'1', 'plugin_param':["INSTANCE"], 'description':'OpenStack INSTANCE Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack core quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/nova_quota_usage.py',
		'param_num':'1', 'plugin_param':["CORE"], 'description':'OpenStack CORE Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack ram quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/nova_quota_usage.py',
		'param_num':'1', 'plugin_param':["RAM"], 'description':'OpenStack RAM Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack disk quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/nova_quota_usage.py',
		'param_num':'1', 'plugin_param':["DISK"], 'description':'OpenStack DISK Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack keypair quota util', 'type':'file', 'target_seq':'6', 'group_seq':'16',
		'script': '/usr/local/plugin/vim/openstack_prov/nova_quota_usage.py',
		'param_num':'1', 'plugin_param':["KEYPAIR"], 'description':'OpenStack KEYPAIR Quota UtilRate',
		'lib_type':'file', 'lib_script':'/usr/local/plugin/vim/openstack_prov/vim_api.py',
		'lib_name':'vim_api.py', 'lib_path':'./', 
		'cfg_name':'vim_cfg.yaml', 'cfg_path':'./', 'cfg_input':["vim_auth_url", "vim_id", "vim_passwd", "vim_domain", "vim_mgmt_net"]
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vm status', 'type':'file', 'target_seq':'7', 'group_seq':'17',
		'script': '/usr/local/plugin/vim/openstack_prov/vm-status.sh',
		'param_num':'1', 'description':'OpenStack VM Status'
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vnet status', 'type':'file', 'target_seq':'6', 'group_seq':'18',
		'script': '/usr/local/plugin/vim/openstack_prov/vnet-status.sh',
		'param_num':'1', 'description':'OpenStack VNet Status'
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vport status', 'type':'file', 'target_seq':'7', 'group_seq':'17',
		'script': '/usr/local/plugin/vim/openstack_prov/vport-status.sh',
		'param_num':'1', 'description':'OpenStack VPort Status'
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	test={
		'tid':'plg-add-1',
		'name':'openstack vrouter status', 'type':'file', 'target_seq':'6', 'group_seq':'18',
		'script': '/usr/local/plugin/vim/openstack_prov/vrouter-status.sh',
		'param_num':'1', 'description':'OpenStack VRouter Status'
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )
	

def addtest():
	test={
		'tid':'plg-add-1',
		'name':'openstack vrouter status', 'type':'script', 'target_seq':'6', 'group_seq':'18',
		'script': 'ls -al',
		'param_num':'0', 'description':'OpenStack VRouter Status'
		}
	
	print( callZB( "http://211.224.204.203:5555/plugin", test ) )



if __name__ == '__main__':
# 	addPlugin()
	addtest()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


