#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.203:5555/target"
PLUGIN_DIR = "/usr/local"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def createTemp():
	
	test={
		"tid":'temp-create-1',
		"target_info":{
				'code':'vim', 'type':'openstack-oneTouch', "name":"VIM-OpenStack", 'version':'kilo-v0.1',
				'vendor_code':'openstack', "description":"OpenStack Monitoring(OneTouch)"
			},
		"group":[
			{'name': 'Quota', 'description':'OpenStack Quota Monitor',
				 "item":[
					{
						"name":"cpu load",
						"type":"Load",
						"zb_key":"system.cpu.load[percpu,avg1]",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"statistic_yn": 'y',
						"data_type":"float",
						"unit":"job",
						"period":"10",
						"history":"30",
						"statistic":"365",
						"description":"CPU Load Average",
						"plugin":{
								'name':'ZB OS CPU Load', 'type':'builtin', 
								'description':'ZB OS Linux Load avg 1 Min'
								},
						"alarm_guide":{'name':'CPU Load Alarm',
										'guide':'check CPU Load'},
						"threshold":[
							{
								"name":"cpu 사용률 warning",
								"grade":"warning",
								"description":"CPU Utilization Warning",
								"repeat":"1", 
								"conditions":[
										"and", {"op":"<", "value":"20"},
										["or",{"op":">", "value":"10"},{"op":"=", "value":"10"}]
									]
							},
							{
								"name":"CPU user time",
								"grade":"major",
								"description":"Endian CPU Utilization Major",
								"repeat":"1",
								"conditions":{"op":"=", "value":"23"}
							},
							{
								"name":"CPU user time2",
								"grade":"critical",
								"description":"Endian CPU Utilization Critical",
								"repeat":"2",
								"conditions":{"op":"=", "value":"33"}
							}
							
						]
					},
					{
						"name":"mem available",
						"type":"free",
						"zb_key":"vm.memory.size[available]",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"data_type":"int",
						"unit":"B",
						"period":"15",
						"statistic":"365",
						"description":"MEM available",
						"plugin":{
								'name':'ZB OS Memory Free', 'type':'builtin', 
								'description':'ZB OS Linux Memory Free'
								}
					}
				
				],## item
			"discovery":[
					{
					"name":"nic discovery",
					"zb_key":"net.if.discovery",
					"period":"3600",
					"remain":"1",
					"description":"OS Discovery",
					"return_field":'IFNAME',
					"plugin":{
							'name':'ZB OS Net discovery', 'type':'builtin', 
							'description':'ZB Linux Net Discovery',
							'discovery_input':'zb_net_list'
							},
					"item":[
						{
							"name":"net status",
							"type":"Status",
							"graph_yn": 'n',
							"realtime_yn": 'n',
							"data_type":"int",
							"value_type":"status",
							"period":"30",
							"statistic":"365",
							"description":"NET status",
							"plugin":{
									'name':'LX Net Status', 'type':'file', 
									'script': PLUGIN_DIR+'/plugin/os/ubuntu/net-status.sh',
									'param_num':'1', 'description':'Linux Net Status'
									},
							"alarm_guide":{'name':'NET Status Alarm',
											'guide':'check ifconfig'},
							"threshold":[
								{
									"name":"nic_status_down",
									"grade":"minor",
									"description":"nic status down",
									"repeat":"1",
									"conditions":{"op":"<", "value":"0"}
								}
							]
						}
						
						]
					
					}
				]## discovery
			},
			{'name': 'test-grp2', 'description':'grp2 for test',
				 "item":[
					{
						"name":"cpu load",
						"type":"Load",
						"graph_yn": 'y',
						"realtime_yn": 'y',
						"statistic_yn": 'y',
						"data_type":"float",
						"unit":"%",
						"period":"10",
						"history":"30",
						"statistic":"365",
						"description":"CPU Load Average 1-Min",
						"plugin":{
								'name':'LX CPU Load', 'type':'file', 
								'script': PLUGIN_DIR+'/plugin/os/ubuntu/cpu-load.sh',
								'param_num':'0', 'description':'Linux CPU Load'
								},
						"alarm_guide":{'name':'CPU Load Alarm',
										'guide':'check CPU Load'},
						"threshold":[
							{
								"name":"cpu 사용률 warning",
								"grade":"warning",
								"description":"CPU Utilization Warning",
								"repeat":"1", 
								"conditions":[
										"and", {"op":"<", "value":"20"},
										["or",{"op":">", "value":"10"},{"op":"=", "value":"10"}]
									]
							},
							{
								"name":"CPU user time2",
								"grade":"critical",
								"description":"Endian CPU Utilization Critical",
								"repeat":"2",
								"conditions":{"op":"=", "value":"33"}
							}
							
						]
					},
					{
						"name":"MonAgent Conn Status",
						"type":"free",
						"zb_key":"agent.ping",
						"graph_yn": 'n',
						"realtime_yn": 'n',
						"data_type":"int",
						"period":"30",
						"statistic":"365",
						"description":"agent status",
						"plugin":{
								'name':'ZB Agent Conn', 'type':'builtin', 
								'description':'ZB Agent Ping Chk'
								}
					}
				
					],## item
				"discovery":[
					{
						"name":"svc discovery",
						"period":"300",
						"remain":"1",
						"return_field":'SVCNAME',
						"description":"SVC Discovery",
						"plugin":{
								'name':'LX SVC Discovery', 'type':'file', 
								'script': PLUGIN_DIR+'/plugin/os/ubuntu/os_discovery.py',
								'param_num':'1', 'plugin_param':['svc'], 'description':'LINUX SVC Discovery',
								'cfg_name':'os_cfg.yaml', 'cfg_path':'./', 'cfg_input':['svr_svc'],
								'discovery_input':'svr_svc'
								},
						"item":[
							{
								"name":"svc status",
								"type":"Status",
								"graph_yn": 'n',
								"realtime_yn": 'n',
								"data_type":"int",
								"value_type":"status",
								"period":"30",
								"statistic":"365",
								"description":"SVC status",
								"plugin":{
										'name':'LX SVC Status', 'type':'file', 
										'script': PLUGIN_DIR+'/plugin/os/ubuntu/svc-status.sh',
										'param_num':'1', 'description':'Linux Service Status'
										},
								"alarm_guide":{'name':'SVC Status Alarm',
												'guide':'check Service command'},
								"threshold":[
									{
										"name":"svc critical alarm",
										"grade":"critical",
										"description":"svc status down",
										"repeat":"1",
										"conditions":{"op":"<", "value":"0"}
									}
								]
							}
							
						]
						
					}
				]## discovery
			}
		]
	}
	
	print( callZB( URL, test ) )




if __name__ == '__main__':
	createTemp()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


