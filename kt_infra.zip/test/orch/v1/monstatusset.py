#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.203:5555/server/item/mod/monstatus"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def modItem():
	## Mandatory : tid, svr_seq, item_seq
	## Optional : new_period, new_history, new_statistic
# 	test={'tid':'item-mod-real-1', 'svr_seq':16, 'item_seq':2720, 'monitor_yn':'y'
	test={'tid':'item-mod-real-1', 'svr_seq':20, 'item_seq':7359, 'monitor_yn':'n'
		}
	
	print( callZB( URL, test ) )




if __name__ == '__main__':
	modItem()
# 	if len(sys.argv) >= 2:
# 		modItem(str(sys.argv[1]))
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


