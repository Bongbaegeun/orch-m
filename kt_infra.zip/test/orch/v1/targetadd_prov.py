#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'

URL= "https://211.224.204.203:5555/server/target/add"
URL_D= "https://211.224.204.203:5555/server/target/add"
URL_S= "http://211.224.204.248:5555/server/target/add"
URL_NP= "http://220.123.31.82:5555/server/target/add"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, body=strBody, request_timeout=10 )
	
	try:
		response = http_client.fetch( request=_request )
		http_client.close()
		print response.code
		resp = json.loads(response.body)
		
		return resp
	except Exception, e:
		print e.response.body

def prov(sType, svrID ):
	if sType == DEV_SVR and svrID == 1:
		url = URL_D
		svrIP = '211.224.204.205'
		svrInfo = {'seq':16, 'uuid':'TJB-SVR-UUID-005', 'onebox_id':'TJB.01', 'ip':svrIP}
	elif sType == DEV_SVR and svrID == 2:
		url = URL_D
		svrIP = '211.224.204.167'
		svrInfo = {'seq':102, 'uuid':'328a5264-3a79-11e6-8287-0017a44b1649', 'onebox_id':'KTS.01', 'ip':svrIP}
	elif sType == DEV_SVR and svrID == 4:
		url = URL_D
		svrIP = '211.224.204.157'
		svrInfo = {'seq':20, 'uuid':'f117e5d4-88d6-11e5-8465-0017a44b1649', 'onebox_id':'KTS.01', 'ip':svrIP}
	elif sType == STG_SVR and svrID == 1:
		url = URL_S
		svrIP = '211.224.204.213'
		svrInfo = {'seq':16, 'uuid':'OneBox-S2', 'onebox_id':'TJB.01', 'ip':svrIP}
	elif sType == STG_SVR and svrID == 2:
		url = URL_S
		svrIP = '211.224.204.138'
		svrInfo = {'seq':65, 'uuid':'c108ecfc-fc8b-11e5-bf7d-080027ca3ef9', 'onebox_id':'NSA5150.OB48', 'ip':svrIP}
	elif sType == STG_SVR and svrID == 4:
		url = URL_S
		svrIP = '211.224.204.212'
		svrInfo = {'seq':20, 'uuid':'OneBox-S', 'onebox_id':'KTS.01', 'ip':svrIP}
	else :
		return
	
	ospUrl = "http://%s:35357/v3/auth/tokens"%svrIP
	
	test = {
		'tid':'tar-add-1',
		"svr_info": {"onebox_id": "rs2016a.OB89", "ip": "211.224.204.167", 
					"uuid": "328a5264-3a79-11e6-8287-0017a44b1649", "seq": 102},
		"target_info": [
			{"target_seq": 290,
			"cfg": {
				"vm_name": "SERV_main_Olleh-UTM", 
				"vim_mgmt_net": "global_mgmt_net", 
				"vim_domain": "default", 
				"vm_ip": "192.168.254.1", 
				"vim_id": "admin", 
				"vim_port": ["rs2016a.Basic-GiGA-Server-Storage-PBX-PORT_blue_Olleh-UTM", 
							"rs2016a.Basic-GiGA-Server-Storage-PBX-PORT_green_Olleh-UTM", 
							"rs2016a.Basic-GiGA-Server-Storage-PBX-PORT_orange_Olleh-UTM", 
							"rs2016a.Basic-GiGA-Server-Storage-PBX-PORT_mgmt_Olleh-UTM", 
							"rs2016a.Basic-GiGA-Server-Storage-PBX-PORT_red_Olleh-UTM"], 
				"vim_passwd": "onebox2016!", 
				"vim_auth_url": "http://211.224.204.167:35357/v3/auth/tokens", 
				"vm_id": "root", 
				"vm_passwd": "qazwsx123", 
				"vim_vm": ["SERV_main_Olleh-UTM"]}}, 
			{"target_seq": 297, 
			"cfg": {
				"vm_name": "SERV_main_XMS", 
				"vim_mgmt_net": "global_mgmt_net", 
				"vim_domain": "default", 
				"vm_ip": "192.168.254.2", 
				"vim_id": "admin", 
				"vm_app_id": "kttest01", 
				"vim_port": ["rs2016a.Basic-GiGA-Server-Storage-PBX-PORT_mgmt_XMS", 
							"rs2016a.Basic-GiGA-Server-Storage-PBX-PORT_local_XMS", 
							"rs2016a.Basic-GiGA-Server-Storage-PBX-PORT_svc_XMS"], 
				"vim_passwd": "onebox2016!", 
				"vm_app_passwd": "1234", 
				"vim_auth_url": "http://211.224.204.167:35357/v3/auth/tokens", 
				"vm_id": "root", 
				"vm_passwd": "qazwsx123", 
				"vim_vm": ["SERV_main_XMS"]}}
		]

	}
	
# 	test={
# 		'tid':'tar-add-1',
# 		'svr_info': svrInfo,
# 		'target_info': [ 
# 					{'target_seq':244, 
# 					'cfg':{
# 						'vm_name':'UTM',
# 						'vm_ip':"192.168.2.114",
# 						'vm_net':['br0', 'eth0'],
# 						'vm_fs':['/'],
# 						'vm_job':['authentication'],
# 						'vim_auth_url':ospUrl,
# 						"vim_id": "admin", 
# 						"vim_passwd": "onebox2016!", 
# 						"vim_domain": "default", 
# 						"vim_mgmt_net": "global_mgmt_net", 
# 						'vim_vm':[ 'TJB.Basic-WIMS-SERV_main_Olleh-UTM' ],
# 						"vim_port":['TJB.Basic-WIMS-PORT_mgmt_Olleh-UTM-2qefzrrp2q4p'] 
# 						}
# 					},
# 					{'target_seq':247, 
# 					'cfg':{
#						'vm_name':'WAF',
# 						"vm_ip":"192.168.10.41",
# 						"vm_app_id":"admin",
# 						"vm_app_passwd":"wafpenta!23",
# 						"vm_net":['eth0'],
# 						'vim_auth_url':ospUrl,
# 						"vim_id": "admin", 
# 						"vim_passwd": "ohhberry3333", 
# 						"vim_domain": "default", 
# 						"vim_mgmt_net": "global_mgmt_net", 
# 						'vim_vm':[ 'vWAF' ],
# 						"vim_port":['TJB.Basic-Service-PORT_svc_Penta-WAF-'] 
# 						}
# 					},
# 					{'target_seq':248, 
# 					'cfg':{
# 						'vm_name':'WIMS',
# 						"vm_ip":"192.168.10.27",
# 						'vm_net':['eth1'],
# 						'vm_fs':['/'],
# 						'vm_proc':['Wac_ce.jar', 'Wac_nei.jar', 'Wac_emp.jar', 'Wac_dbg.jar',
# 									 'Wac_stm.jar', 'Wac_unm.jar', 'Wac_scp.jar', 'Wac_pm.jar',
# 									 'Wac_rsm.jar', 'wtd_mgr', 'fork_mgr', 'sm_mgr', 'as_mgr',
# 									 'at_mgr', 'sv_mgr'],
# 						'vim_auth_url':ospUrl,
# 						"vim_id": "admin", 
# 						"vim_passwd": "ohhberry3333", 
# 						"vim_domain": "default", 
# 						"vim_mgmt_net": "global_mgmt_net", 
# 						'vim_vm':[ 'TJB.Basic-WIMS-SERV_main_WIMS' ],
# 						"vim_port":['TJB.Basic-WIMS-PORT_svc_WIMS-fq6aefjxp6oj'] 
# 						}
# 					},
# 					{'target_seq':297, 
# 					'cfg':{
# 						'vm_name':'XMS',
# 						"vm_ip":"192.168.10.135",
# 						'vm_net':['eth1'],
# 						'vm_fs':['/'],
# 						'vm_proc':['Wac_ce.jar', 'Wac_nei.jar', 'Wac_emp.jar', 'Wac_dbg.jar',
# 									 'Wac_stm.jar', 'Wac_unm.jar', 'Wac_scp.jar', 'Wac_pm.jar',
# 									 'Wac_rsm.jar', 'wtd_mgr', 'fork_mgr', 'sm_mgr', 'as_mgr',
# 									 'at_mgr', 'sv_mgr'],
# 						'vim_auth_url':ospUrl,
# 						"vim_id": "admin", 
# 						"vim_passwd": "ohhberry3333", 
# 						"vim_domain": "default", 
# 						"vim_mgmt_net": "global_mgmt_net", 
# 						'vim_vm':[ 'TJB.Basic-WIMS-SERV_main_WIMS' ],
# 						"vim_port":['TJB.Basic-WIMS-PORT_svc_WIMS-fq6aefjxp6oj'] 
# 						}
# 					},
# 				]
# 		}
	
	print( callZB( url, test ) )


def provAll():
	test={
		'tid':'tar-add-1',
		'svr_info': {'seq':'102', 'onebox_id':'rs2016a.OB89', 'uuid':'328a5264-3a79-11e6-8287-0017a44b1649', 'ip':'211.224.204.167'},
		'target_info': [ 
					{'target_seq':330, 
					'cfg':{
						'vm_name':'UTM',
						'vm_ip':"192.168.4.252",
						'vm_app_id':'oadmin',
						'vm_app_passwd': "#2kdnjsqkrtm",
# 						'vm_net':['br0', 'eth0'],
# 						'vm_fs':['/'],
# 						'vm_job':['authentication','backup','dhcp', 'firewall', 'jobsengine', 'network'],
						'vim_auth_url':"http://211.224.204.167:35357/v3/auth/tokens",
						"vim_id": "admin", 
						"vim_passwd": "ohhberry3333", 
						"vim_domain": "default", 
						"vim_mgmt_net": "global_mgmt_net", 
						'vim_vm':[ 'vUTM' ],
						"vim_port":['TJB.Basic-Service-PORT_red_Olleh-UTM-'] 
						}
					},
# 					{'target_seq':288, 
# 					'cfg':{
#						'vm_name':'WAF',
# 						"vm_ip":"192.168.10.41",
# 						"vm_id":"admin",
# 						"vm_passwd":"wafpenta!23",
# 						"vm_net":['eth0'],
# 						'vim_auth_url':"http://211.224.204.205:35357/v3/auth/tokens",
# 						"vim_id": "admin", 
# 						"vim_passwd": "ohhberry3333", 
# 						"vim_domain": "default", 
# 						"vim_mgmt_net": "global_mgmt_net", 
# 						'vim_vm':[ 'vWAF' ],
# 						"vim_port":['TJB.Basic-Service-PORT_svc_Penta-WAF-'] 
# 						}
# 					},
# 					{'target_seq':294, 
# 					'cfg':{
# 						'vm_name':'WIMS',
# 						"vm_ip":"192.168.10.59",
# # 						'vm_net':['eth1'],
# # 						'vm_fs':['/'],
# # 						'vm_proc':['Wac_ce.jar', 'Wac_nei.jar', 'Wac_emp.jar', 'Wac_dbg.jar',
# # 									 'Wac_stm.jar', 'Wac_unm.jar', 'Wac_scp.jar', 'Wac_pm.jar',
# # 									 'Wac_rsm.jar', 'wtd_mgr', 'fork_mgr', 'sm_mgr', 'as_mgr',
# # 									 'at_mgr', 'sv_mgr'],
# 						'vim_auth_url':"http://211.224.204.205:35357/v3/auth/tokens",
# 						"vim_id": "admin", 
# 						"vim_passwd": "ohhberry3333", 
# 						"vim_domain": "default", 
# 						"vim_mgmt_net": "global_mgmt_net", 
# 						'vim_vm':[ '_WiMS' ],
# 						"vim_port":['WiMS-port-xxxx'] 
# 						}
# 					}
				]
		}
	
	print( callZB( URL, test ) )


def provWithnet():
	test = {"tid": "469ad5ee-2006-11e7-8287-0017a44b1648", "svr_info": {"onebox_id": "HATEST.OB1", "ip": "211.224.204.162", "uuid": "7860245e-1f42-11e7-8287-0017a44b1649", "seq": 148}, "target_info": [{"cfg": {"vm_name": "SERV_main_KT-VNF", "vim_mgmt_net": "global_mgmt_net", "vim_domain": "default", "vm_ip": "192.168.254.1", "service_number": "dsaffddasd", "vim_id": "admin", "vim_port": ["NS-HATEST.OB1.AUTO-NSD-INSDEV3__1-PORT_local_KT-VNF", "NS-HATEST.OB1.AUTO-NSD-INSDEV3__1-PORT_red_KT-VNF", "NS-HATEST.OB1.AUTO-NSD-INSDEV3__1-PORT_orange_KT-VNF", "NS-HATEST.OB1.AUTO-NSD-INSDEV3__1-PORT_mgmt_KT-VNF", "NS-HATEST.OB1.AUTO-NSD-INSDEV3__1-PORT_redR1_KT-VNF", "NS-HATEST.OB1.AUTO-NSD-INSDEV3__1-PORT_green_KT-VNF"], "vim_passwd": "kt@ne130X", "vim_auth_url": "http://211.224.204.162:35357/v3/auth/tokens", "vm_id": "root", "vm_passwd": "smflaqh#1", "vim_vm": ["SERV_main_KT-VNF"]}, "target_seq": 11, "wan_if_num": 2, "vdudseq": 22}]}
	
	
	
	print( callZB( URL_D, test ) )



if __name__ == '__main__':
	provWithnet()
# 	if len(sys.argv) >= 3:
# 		prov(sys.argv[1], int(sys.argv[2]))
# 	provAll()
# 	if len(sys.argv) >= 2:
# 		prov1(str(sys.argv[1]))
# 	modServer()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


