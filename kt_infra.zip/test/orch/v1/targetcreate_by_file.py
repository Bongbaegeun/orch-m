#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'

# URL = "http://211.224.204.248:5555/target"
URL = "http://211.224.204.203:5555/target"
URL_D = "http://211.224.204.203:5555/target"
URL_S = "http://211.224.204.248:5555/target"
URL_P = "http://211.224.204.222:5555/target"
PLUGIN_DIR = "/usr/local/plugin"
PLUGIN_TEST_DIR = "/usr/local/plugin/test"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def createTemp(sType, fName):
	if sType == DEV_SVR :
		url = URL_D
	elif sType == STG_SVR :
		url = URL_S
	elif sType == PRT_SVR :
		url = URL_P
	else:
		return
	
	f = open( str(fName), 'r+' )
	tempStr = f.read()
	f.close()
	
	temp = json.loads( tempStr )
	temp = temp['template']
	temp["tid"] = 'temp-create-1'
	temp['target_info']['version'] = 'v2.0'
	
	print( callZB( url, temp ) )




if __name__ == '__main__':
	if len(sys.argv) >= 2:
		createTemp(sys.argv[1], sys.argv[2])
	else:
		print 'USAGE: CMD [D/S/P] FILE_NAME'
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


