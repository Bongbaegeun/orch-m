#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

DEV_SVR = 'D'
STG_SVR = 'S'
PRT_SVR = 'P'

URL = "http://211.224.204.203:5555/server/target/del"
URL_D = "http://211.224.204.203:5555/server/target/del"
URL_S = "http://211.224.204.248:5555/server/target/del"
URL_P = "http://211.224.204.222:5555/server/target/del"
# URL = "http://211.224.204.248:5555/server/target/del"

def callZB( url, reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=30 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp

def delTempAll(sType, svrID):
	if sType == DEV_SVR and svrID == 1:
		url = URL_D
		svrIP = '211.224.204.205'
		svrInfo = {'seq':16, 'uuid':'TJB-SVR-UUID-005', 'onebox_id':'TJB.01', 'ip':svrIP}
	elif sType == DEV_SVR and svrID == 2:
		url = URL_D
		svrIP = '211.224.204.167'
		svrInfo = {'seq':102, 'uuid':'328a5264-3a79-11e6-8287-0017a44b1649', 'onebox_id':'rs2016a.OB89', 'ip':svrIP}
	elif sType == DEV_SVR and svrID == 4:
		url = URL_D
		svrIP = '211.224.204.157'
		svrInfo = {'seq':20, 'uuid':'f117e5d4-88d6-11e5-8465-0017a44b1649', 'onebox_id':'KTS.01', 'ip':svrIP}
	elif sType == STG_SVR and svrID == 1:
		url = URL_S
		svrIP = '211.224.204.213'
		svrInfo = {'seq':16, 'uuid':'OneBox-S2', 'onebox_id':'TJB.01', 'ip':svrIP}
	elif sType == STG_SVR and svrID == 2:
		url = URL_S
		svrIP = '211.224.204.138'
		svrInfo = {'seq':65, 'uuid':'c108ecfc-fc8b-11e5-bf7d-080027ca3ef9', 'onebox_id':'NSA5150.OB48', 'ip':svrIP}
	elif sType == STG_SVR and svrID == 4:
		url = URL_S
		svrIP = '211.224.204.212'
		svrInfo = {'seq':20, 'uuid':'OneBox-S', 'onebox_id':'KTS.01', 'ip':svrIP}
	elif sType == STG_SVR and svrID == 5:
		url = URL_S
		svrIP = '211.224.204.137'
		svrInfo = {'seq':56, 'uuid':'ca7078b8-efc6-11e5-bf7d-080027ca3ef9', 'onebox_id':'T330-R.OB38', 'ip':svrIP}
	elif sType == PRT_SVR and svrID == 1:
		url = URL_P
		svrIP = '183.98.121.151'
		svrInfo = {'seq':53, 'uuid':'eb21ecda-e45a-11e5-bf7d-080027ca3ef9', 'onebox_id':'WITHNET.OB37', 'ip':svrIP}
	else :
		return
	
	test={
		'tid':'tar-del-1',
		'svr_info': svrInfo,
		'target_info': [ 
					{'target_seq':'290'}, 
					{'target_seq':'297'}, 
# 					{'target_seq':291}, 
# 					{'target_seq':294}, 
# 					{'target_seq':297}
					]
		}
	
	print( callZB( url, test ) )
	
def modServer():
	# ob1
	test={
		'tid':'tar-del-1',
# 		'svr_info': {'seq':'1', 'uuid':'TEST-SVR-UUID-001', 'name':'Forbiz.01', 
# 					 'ip':'211.224.204.207', 'mon_port':'10050', 'desc':'Forbiz Server #1'},
		'svr_info': {'seq':'16', 'uuid':'TJB-SVR-UUID-005', 'ip':'211.224.204.205'},
		'target_info': [ 
					{'target_seq':'4'}, 
					{'target_seq':'5'}
					]
		}
	
	print( callZB( URL, test ) )


def delTempAll1():
	test={
		'tid':'tar-del-1',
		'svr_info': {'seq':'16', 'uuid':'TJB-SVR-UUID-005', 'ip':'211.224.204.205'},
		'target_info': [ 
					{'target_seq':'280'}, 
# 					{'target_seq':'281'}, 
					{'target_seq':'284'}
					]
		}
	
	print( callZB( URL, test ) )

def delTempAll3():
	test={
		'tid':'tar-del-1',
		'svr_info': {'seq':'1', 'uuid':'TEST-SVR-UUID-001', 'ip':'211.224.204.207'},
		'target_info': [ 
					{'target_seq':'277'}, 
					{'target_seq':'278'}
					]
		}
	
	print( callZB( URL, test ) )

def delTempAll4():
	test={
		'tid':'tar-del-1',
		'svr_info': {'seq':'102', 'onebox_id':'rs2016a.OB89', 'uuid':'328a5264-3a79-11e6-8287-0017a44b1649', 'ip':'211.224.204.167'},
		'target_info': [ 
					{'target_seq':'330'}, 
# 					{'target_seq':'294'}, 
# 					{'target_seq':'294'}
					]
		}
	
	print( callZB( URL, test ) )

if __name__ == '__main__':
	delTempAll4()
	if len(sys.argv) >= 3:
		delTempAll(sys.argv[1], int(sys.argv[2]))
# 	delTempAll4()
# 	if len(sys.argv) >= 2:
# 		svrNum = int(sys.argv[1])
# 		if svrNum == 1:
# 			delTempAll1()
# 		elif svrNum == 3:
# 			delTempAll3()
# 		elif svrNum == 4:
# 			delTempAll4()
# 	if len(sys.argv) >= 3:
# 		faultType = str(sys.argv[1]).upper()
# 		if str(faultType).upper() == 'CPU':
# 			faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
# 		elif str(faultType).upper() == 'UTM':
# 			faultUTMNet(int(sys.argv[2]))


