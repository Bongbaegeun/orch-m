#!/usr/bin/python
#-*- coding: utf-8 -*-

import utm_api
from utm_api import Logger
import sys, yaml, os, logging
from __builtin__ import exit

CFG_FILE = os.path.dirname( os.path.abspath( __file__ ) )+'/utm_cfg.yaml'

cfg = None
with open(CFG_FILE, "r") as f:
    cfg = yaml.load(f)

logger = Logger( logName='utm', logDir='/var/log/zabbix-agent', logFile='utm.log', logFileMaxByte=10*1024*1024, logBackupCnt=10, logLevel=logging.DEBUG ).instance()

ip = cfg['vm_ip']
ID = cfg['vm_id']
PASSWD = cfg['vm_passwd']

CMDS = {
        "CONN_SESS" : """https://%s/index.dao""",
        "AUTH" :   """https://%s/login.dao""",
        "OS_INFO":   """https://%s/logstat_sysinfo.dao""",
        "NET_INFO": """https://%s/interface_monitor.dao""",
        "TRAFFIC": """https://%s/traffic_monitor.dao""",
        "DHCP": """https://%s/lease_count.dao""",
        "DAEMON": """https://%s/daemon_monitor.dao""",
        "INTERNET1": """ ping -c 1 -w 1 8.8.8.8 | grep 'received' | awk '{print $4}' """,
        "INTERNET2": """ busybox timeout -t 3 nslookup kt.com | grep -c "kt.com" """,
        "INTERNET3": """ nc -w 3 -v -z kt.com 80;echo $? """,
        "INTERNET4": """ curl -k --connect-timeout 3 https://%s:5555 > /dev/null; echo $? """,
#         "INTERNET": """ busybox timeout -t 3 nslookup kt.com | grep -c "kt.com" """,
#         "INTERNET": """ gw=$(ip route | grep default | awk '{print $3}'); gwping=$(ping -c 1 -w 1 $gw | grep 'received' | awk '{print $4}'); remping=$(ping -c 1 -w 1 8.8.8.8 | grep 'received' | awk '{print $4}'); echo "$gwping,$remping" """,
        "DISK" : """ df | grep "%s" | grep -vi "^filesystem" | awk '{print $%s}' """
       }

def connSess(ip):
    try:
        utm_api.callAPI( CMDS['CONN_SESS']%ip, 'GET' )
        return 1
    except Exception, e:
        logger.exception(e)
        return 0

def login( ip, _id, passwd ):
    try:
        if connSess(ip) != 1 :
            return False
        ret = utm_api.callAPI( CMDS['AUTH']%ip, header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"},
                               reqBody='username=%s&passwd=%s&force=%s'%(_id, passwd, str(1)) )
        if str(ret).count("errorMsg") > 0 : 
            return False
        else: 
            return True
    except Exception, e:
        logger.exception(e)
        return False


def osInfo( ip, _what, _type, _id=ID, passwd=PASSWD ):
#     if not login( ip, _id, passwd ):
#         logger.error( 'login Error, ip=%s, id=%s, pw=%s'%(str(ip), str(_id), str(passwd)) )
#         return None
    
    try:
        ret = utm_api.callAPI( CMDS['OS_INFO']%ip, 'GET')
        if not type(ret) == dict :
            logger.error( 'OSInfo body is not dict, ret=%s'%(ret) )
            return None
        
        if str(_what).lower() == 'cpu' :
            if str(_type).lower() == 'load' :
                return ret['root']['curStat']['load1']
            elif str(_type).lower() == 'util' :
                return ret['root']['curStat']['cpu']
        elif str(_what).lower() == 'mem' :
            if str(_type).lower() == 'total' :
                return ret['root']['curStat']['totalMem']
            elif str(_type).lower() == 'used' :
                return ret['root']['curStat']['usedMem']
            elif str(_type).lower() == 'free' :
                return ret['root']['curStat']['totalMem'] - ret['root']['curStat']['usedMem']
            elif str(_type).lower() == 'util' :
                return ret['root']['curStat']['mem']
        elif str(_what).lower() == 'swap' :
            if str(_type).lower() == 'total' :
                return ret['root']['curStat']['totalSwap']
            elif str(_type).lower() == 'used' :
                return ret['root']['curStat']['usedSwap']
            elif str(_type).lower() == 'free' :
                return ret['root']['curStat']['totalSwap'] - ret['root']['curStat']['usedSwap']
            elif str(_type).lower() == 'util' :
                return ret['root']['curStat']['swap']
        elif str(_what).lower() == 'disk' :
            if str(_type).lower() == 'total' :
                return ret['root']['curStat']['totalDisk']
            elif str(_type).lower() == 'used' :
                return ret['root']['curStat']['usedDisk']
            elif str(_type).lower() == 'free' :
                return ret['root']['curStat']['totalDisk'] - ret['root']['curStat']['usedDisk']
            elif str(_type).lower() == 'util' :
                return ret['root']['curStat']['disk']
        elif str(_what).lower() == 'conntrack' :
            if str(_type).lower() == 'total' :
                return ret['root']['curStat']['totalSession']
            else :
                return ret['root']['curStat']['session']
        elif str(_what).lower() == 'db' :
            if str(_type).lower() == 'total' :
                return ret['root']['curStat']['totaldb']
            elif str(_type).lower() == 'used' :
                return ret['root']['curStat']['useddb']
            elif str(_type).lower() == 'free' :
                return ret['root']['curStat']['totaldb'] - ret['root']['curStat']['useddb']
            elif str(_type).lower() == 'util' :
                return ret['root']['curStat']['db']
        
        logger.error( 'Unknown Type, what=%s, type=%s'%(str(_what), str(_type)) )
        return None
    except Exception, e:
        logger.exception(e)
        return None

def netInfo( ip, _if, _id=ID, passwd=PASSWD ):
#     if not login( ip, _id, passwd ):
#         logger.error( 'login Error, ip=%s, id=%s, pw=%s'%(str(ip), str(_id), str(passwd)) )
#         return None
    
    try:
        ret = utm_api.callAPI( CMDS['NET_INFO']%ip, header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"},
                               reqBody='dev=%s'%(_if))
        if not type(ret) == dict :
            logger.error( 'NetInfo body is not dict, ret=%s'%(ret) )
            return None
        
        if ret.has_key(_if) :
            return ret[_if]
        else:
            logger.error('No Net Interface, %s'%str(_if))
        
        return None
    except Exception, e:
        logger.exception(e)
        return None

def calcRate(_if, _bytes, _type):
    try:
        import time
        
        fName = None
        if not os.path.exists( '/var/log/zabbix-agent/dat' ) :
            os.mkdir('/var/log/zabbix-agent/dat')
        if str(_type).lower() == 'rx':
            fName = '/var/log/zabbix-agent/dat/utm_%s_rx_bps.dat'%_if
        else:
            fName = '/var/log/zabbix-agent/dat/utm_%s_tx_bps.dat'%_if
        
        fd = os.open(fName, os.O_RDWR|os.O_CREAT)
        fileobj = os.fdopen(fd, 'rw+b')
        prevTxt = fileobj.read()
        
        bits = _bytes*8
        ts = time.time()
        txt = str(bits) + "," + str(ts)
        
        fileobj.seek(0)
        fileobj.truncate()
        
        fileobj.write(txt)
        fileobj.flush()
        fileobj.close()
        
        if prevTxt != None and str(prevTxt).find(',') >= 0 :
            bitts = str(prevTxt).split(',')
            prevBits = int(bitts[0])
            prevTs = float(bitts[1])
            
            if bits >= prevBits and ts > prevTs :
                bps = int((bits-prevBits)/(ts-prevTs))
            else:
                bps = None
        else :
            bps = None
        
        return bps
    except ValueError, ve:
        if fName != None and os.path.isfile( fName ):
            os.remove(fName)
        logger.exception(ve)
        return None
    except Exception, e:
        logger.error(fName)
        logger.exception(e)
        return None
    

def trafficInfo( ip, _if, _type, _id=ID, passwd=PASSWD ):
#     if not login( ip, _id, passwd ):
#         logger.error( 'login Error, ip=%s, id=%s, pw=%s'%(str(ip), str(_id), str(passwd)) )
#         return None
    
    try:
        ret = utm_api.callAPI( CMDS['TRAFFIC']%ip, header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"},
                               reqBody='dev=%s'%(_if))
        
        if not type(ret) == list :
            logger.error( 'traffic body is not list, ret=%s'%(ret) )
            return None
        
        for _info in ret :
            if str(_type).lower() == 'rx_rate' and _info.has_key('total_in_bytes') :
                return calcRate(_if, _info['total_in_bytes'], 'rx')
            elif str(_type).lower() == 'tx_rate' and _info.has_key('total_out_bytes') :
                return calcRate(_if, _info['total_out_bytes'], 'tx')
        
        logger.error( 'Unknown Type, if=%s, type=%s'%(str(_if), str(_type)) )
        return None
    except Exception, e:
        logger.exception(e)
        return None

def dhcp( ip, _id=ID, passwd=PASSWD ):
#     if not login( ip, _id, passwd ):
#         logger.error( 'login Error, ip=%s, id=%s, pw=%s'%(str(ip), str(_id), str(passwd)) )
#         return None
    
    try:
        ret = utm_api.callAPI( CMDS['DHCP']%ip, header={"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"},
                               reqBody='getCount=1')
        if not type(ret) == dict :
            logger.error( 'dhcp body is not dict, ret=%s'%(ret) )
            return None
        
        return ret['Count']
    except Exception, e:
        logger.exception(e)
        return None

def daemon( ip, procName, _id=ID, passwd=PASSWD ):
#     if not login( ip, _id, passwd ):
#         logger.error( 'login Error, ip=%s, id=%s, pw=%s'%(str(ip), str(_id), str(passwd)) )
#         return None
    
    try:
        ret = utm_api.callAPI( CMDS['DAEMON']%ip, 'GET')
        if not type(ret) == dict :
            logger.error( 'daemon body is not dict, ret=%s'%(ret) )
            return None
        
        ## proc : pm, httpd, postgres, sysmonitor, logmonitor, daemonmanager, syslog-ng, ulogd
        return ret[procName]
    except Exception, e:
        logger.exception(e)
        return None


def diskInfo(_ip, _type, _obj=""):
    try:
        _mode = 5
        if str(_type).upper() == "UTIL" :
            _mode = 5
        elif str(_type).upper() == "FREE" :
            _mode = 4
        elif str(_type).upper() == "TOTAL" :
            _mode = 2
        elif str(_type).upper() == "USED" :
            _mode = 3
        else:
            logger.error("Invalid Disk Pararm, _type=%s"%str(_type))
            return None
        
        cmd = CMDS['DISK']%(_obj, str(_mode))
        ret = utm_api.run( logger, ip, cmd )
        if ret == None or str(ret).strip() == '' :
            logger.error('Fail to Get FileSystem Info, cmd=%s, ret=%s'%(cmd, str(ret)))
            return None
        
        _fInfos = str(ret).split()
        if len(_fInfos) < 1:
            logger.error('Fail to Get FileSystem Info, cmd=%s, ret=%s'%(cmd, str(ret)))
            return None
        
        fInfos = []
        for __val in _fInfos :
            fInfos.append( int(str(__val).replace("%", "")) )
        
        if _obj == "":
            if _mode in (5, 3) :
                _val = max(fInfos)
            else:
                _val = min(fInfos)
        else:
            _val = fInfos[0]
        
        if _mode == 5 :
            _val = str(_val).replace("%", "")
        
        return _val
    except Exception, e:
        logger.exception(e)
        return None


def _chkInternet( ip ):
    pingCnt = ''
    try:
        cmd = CMDS['INTERNET']
        pingRet = utm_api.run( logger, ip, cmd )
        if pingRet == None or pingRet == '' :
            logger.error('Fail to exec internet_chk, ret=%s'%str(pingRet))
            return 0
        
        pingCnt = str(pingRet).split(',')
        if len(pingCnt) < 2 or \
            (( pingCnt[0] == None or pingCnt[0] == '' or int(pingCnt[0]) < 1) \
             and ( pingCnt[1] == None or pingCnt[1] == '' or int(pingCnt[1]) < 1 )) :
            logger.error('Invalid Internet Ping Return, ret=%s'%str(pingCnt))
            return 0
        return 1
    except Exception, e:
        logger.exception(e)
        logger.error('Internet Ping Error, ret=%s'%str(pingCnt))
    return None

ORCHM_IP="211.224.204.203"
def chkInternet( ip ):
    _SDEBUG = False
    _FDEBUG = True
    cmd = ''
    ret = ''
    try:
        cmd = CMDS['INTERNET1']
        ret = None
        try:
            ret = utm_api.run( logger, ip, cmd )
            if int(ret) > 0 :
                if _SDEBUG : logger.debug("Succ to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
                return 1
        except Exception, e:
            logger.error("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
            logger.exception(e)
        if _FDEBUG : logger.debug("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
        
        cmd = CMDS['INTERNET2']
        ret = None
        try:
            ret = utm_api.run( logger, ip, cmd )
            if int(ret) > 0 :
                if _SDEBUG : logger.debug("Succ, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
                return 1
        except Exception, e:
            logger.error("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
            logger.exception(e)
        if _FDEBUG : logger.debug("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
        
        cmd = CMDS['INTERNET3']
        ret = None
        try:
            ret = utm_api.run( logger, ip, cmd )
            if int(ret) == 0 :
                if _SDEBUG : logger.debug("Succ, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
                return 1
        except Exception, e:
            logger.error("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
            logger.exception(e)
        if _FDEBUG : logger.debug("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
        
        cmd = CMDS['INTERNET4'] % ORCHM_IP
        ret = None
        try:
            ret = utm_api.run( logger, ip, cmd )
            if int(ret) == 0 :
                if _SDEBUG : logger.debug("Succ, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
                return 1
            else:
                if _FDEBUG : logger.debug("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
                return 0
        except Exception, e:
            logger.error("Fail to Chk Internet, cmd=%s, ret=%s"%( str(cmd), str(ret) ))
            logger.exception(e)
    except Exception, e:
        logger.exception(e)
        logger.error('Internet Error, cmd=%s, ret=%s'%(str(cmd), str(ret)))
    return None


if __name__ == '__main__':
    try:
        if len(sys.argv) >= 2:
            chkType = str(sys.argv[1]).upper()
            
            if chkType == "PING":
                print( connSess(ip) )
                exit(0)
            elif chkType == "INTERNET":
                print( chkInternet(ip) )
                exit(0)
            elif chkType == "CPU" or chkType == "MEM" or chkType == "SWAP" \
                or chkType == "DB" :
                print( osInfo(ip, chkType, str(sys.argv[2])) )
                exit(0)
            elif chkType == "DISK" :
                print( diskInfo(ip, str(sys.argv[2])) )
                exit(0)
            elif chkType == "NET" and len(sys.argv) >= 4 and str(sys.argv[2]).upper() == 'STATUS':
                print( netInfo(ip, sys.argv[3]) )
                exit(0)
            elif chkType == "CONNTRACK" :
                if len(sys.argv) >= 3:
                    print( osInfo(ip, chkType, str(sys.argv[2])) )
                    exit(0)
                else:
                    print( osInfo(ip, chkType, None) )
                    exit(0)
            elif chkType == "TRAFFIC":
                print( trafficInfo(ip, str(sys.argv[3]), str(sys.argv[2])) )
                exit(0)
            elif chkType == "DHCP" :
                print( dhcp(ip) )
                exit(0)
            elif chkType == "DAEMON" :
                if len(sys.argv) >= 3:
                    print( daemon(ip, sys.argv[2]) )
                    exit(0)
        logger.error('Invalid Parameters, Args=%s'%str(sys.argv))
        print None
    except Exception, e:
        logger.exception(e)
        print None





