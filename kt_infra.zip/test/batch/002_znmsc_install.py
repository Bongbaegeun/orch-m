#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys, psycopg2, paramiko, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from time import sleep

import logging
from logging import handlers

BNAME = str(os.path.basename(__file__)).replace(".py", "")

TAG="batch_" + BNAME + "_"+str(datetime.now().strftime("%Y%m%d-%H%M%S"))
logger = logging.getLogger(TAG)
logger.setLevel(logging.DEBUG)
fmt = logging.Formatter("[%(asctime)s][%(levelname)-5s][%(module)s.%(lineno)04d] %(message)s")
log_handler = handlers.RotatingFileHandler(TAG+".log", maxBytes=1024 * 1024 * 10, backupCount=5)
log_handler.setFormatter(fmt)
logger.addHandler(log_handler)
logger.propagate = False
stdfmt = logging.Formatter("%(message)s")
stdout_handler = logging.StreamHandler(sys.stdout)
stdout_handler.setFormatter(stdfmt)
logger.addHandler(stdout_handler)

import Crypto.Cipher.AES
orig_new = Crypto.Cipher.AES.new
def fixed_AES_new(key, *ls):
    if Crypto.Cipher.AES.MODE_CTR == ls[0] :
        ls = list(ls)
        ls[1] = ''
    return orig_new(key, *ls)

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "https://%s:5555/server/item/mod/object"

# KEY_FILE = "/root/.ssh/id_rsa.pub"
# DB_NAME = "orch_v1"
# DB_USER = "onebox"
# DB_PASS = "kkh@2016!ok"
# DB_PORT = 5432
KEY_FILE = "/root/.ssh/id_rsa.pub"
DB_NAME = "orch_v1"
DB_USER = "nfv"
DB_PASS = "ohhberry3333"
DB_PORT = 5432

IDX = datetime.now().strftime("%Y_%m_%d_01")


def callZB( url, reqBody ):
    
    http_client = httpclient.HTTPClient()
    h = HTTPHeaders(HEADER)
    strBody = json.dumps( reqBody )
    _request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, body=strBody, request_timeout=30 )
    
    response = http_client.fetch( request=_request )
    http_client.close()
    
    resp = json.loads(response.body)
    
    return resp

def run( ip, cmd, _port=9922, _timeout=5 ):
    client = paramiko.SSHClient()
    try:
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            client.connect( ip, port=_port, username="root", key_filename=KEY_FILE, timeout=_timeout )
        except ValueError, e:
            Crypto.Cipher.AES.new = fixed_AES_new
            client.connect( ip, port=_port, username="root", key_filename=KEY_FILE, timeout=_timeout )
        stdin, stdout, stderr = client.exec_command( cmd )
        ret = str(stdout.read()).strip()
    except Exception, e:
        logger.error("[ERROR] Fail to SSH CMD, ip=%s, cmd=%s"%(str(ip), str(cmd)))
        logger.exception(e)
    client.close()
    return ret

def psql(_ip, _sql, isSelect, param=None, _dbConn=None):
    if _dbConn == None : 
        dbConn = psycopg2.connect( database=DB_NAME, user=DB_USER, password=DB_PASS,
                             host=_ip, port=DB_PORT )
        dbConn.autocommit = True
    else:
        dbConn = _dbConn
    
    cur = dbConn.cursor()
    cur.execute( _sql )
    
    dic = None
    if isSelect:
        dic = []
        columns = [desc[0] for desc in cur.description]
        rows = cur.fetchall()
        for row in rows:
            d = dict(zip(columns, row))
            if type(param) == str and param != "" :
                dic.append( d[param] )
            else:
                dic.append(d)
    else:
        if type(param) == bool and param == True :
            try:
                cur.execute('SELECT LASTVAL()')
                ret = cur.fetchone()
                if ret == None or len(ret) < 1 :
                    dic = None
                else:
                    dic = ret[0]
            except Exception, e:
                logger.info( sql )
                logger.exception( e )
                dic = None
        else:
            dic = int(cur.rowcount)
    
    cur.close()
    if _dbConn == None :
        dbConn.close()
    
    return dic

def backupFiles(_obIP, bfList):
    for bf in bfList :
        _cmd = """ mkdir -p /var/onebox/backup/batch/%s/%s 2>&1 """%(IDX, os.path.dirname(bf))
        _ret = run(_obIP, _cmd)
        if _ret != "" :
            logger.error( "      [ERROR] Fail to MKDIR, cmd=%s, ret=%s"%(_cmd, str(_ret)) )
            return False
        
        _cmd = """ cp %s /var/onebox/backup/batch/%s/%s 2>&1  """%(bf, IDX, bf)
        _ret = run(_obIP, _cmd)
        if _ret != "" :
            logger.error( "      [ERROR] Fail to Copy, cmd=%s, ret=%s"%(_cmd, str(_ret)) )
            return False
    return True

def restoreFiles(_obIP, bfList):
    logger.info( "  * File: %s"%str(bfList) )
    if _obIP == None :
        logger.error( "    [ERROR] No OB IP" )
        return
    
    for bf in bfList :
        _cmd = """ cp /var/onebox/backup/batch/%s%s %s 2>&1 """%(IDX, bf, bf)
        _ret = run(_obIP, _cmd)
        if str(_ret).strip() != "" :
            logger.error( "    [ERROR] cmd=%s, ret=%s"%(_cmd, str(_ret)) )
    return




class Batch:
    
#     ZNMS_IP = "112.175.253.45"
    ZNMS_IP = "211.45.120.9"
    ZNMS_PORTS = [6092, 6093]
    
#     ITEM_CAT_SEQ = 38
    ITEM_CAT_SEQ = 50
    
    ZNMSC_FILE = "./znmsc"
    ZNMSC_DIR = "/var/onebox/softwares/onebox-znmsc/bin/"
    
    OBLIST = ["HATEST.OB1"]
    
    def __init__(self, orchIP, orchDBIP):
        self.orchIP = orchIP
        self.orchDBIP = orchDBIP
        self.url = URL%orchIP
    
    def batch(self):
        _idx = 0
        
        if not os.path.isfile(self.ZNMSC_FILE) :
            logger.error("[FATAL] No ZNMSC Binary File!!!!, path=./znmsc")
            return 
        
        for obID in self.OBLIST :
            _idx += 1
            logger.info( "########## %s %s batch, progress=%s/%s ##########"%(obID, IDX, str(_idx), str(len(self.OBLIST))) )
            try:
                if self.installZnmsc(obID) :
                    logger.info("[SUCC] Update Complete\n\n")
                
            except Exception, e:
                logger.error("[ERROR] Fail to Batch, ob=%s\n\n"%str(obName))
                logger.exception(e)
        
    def installZnmsc(self, obID):
        try:
            ### 사전 조회 : OB_SEQ, OB_IP, ITEM_OBJECT
            logger.info("- Loading....")
            
            GET_SQL = """ 
SELECT ii.serverseq ob_seq, svr.mgmtip, ii.monitorobject
FROM tb_server svr, tb_moniteminstance ii
WHERE svr.onebox_id='%s' AND svr.serverseq=ii.serverseq 
AND ii.delete_dttm is null AND ii.monitemcatseq=%s """%(obID, str(self.ITEM_CAT_SEQ))
            ret = psql(self.orchDBIP, GET_SQL, True)
            if ret == None or len(ret) < 1 :
                logger.error("  [ERROR] No Data, obid=%s, itemcatseq=%s"%(obID, str(self.ITEM_CAT_SEQ)))
                return False
            
            obSeq = ret[0]['ob_seq']
            obIP = ret[0]['mgmtip']
            itemObj = []
            for _ii in ret :
                itemObj.append(_ii['monitorobject'])
            
            GET_SVC_SQL = """ 
SELECT service_number FROM tb_moniteminstance
WHERE serverseq=%s AND delete_dttm is null AND monitemcatseq=%s
GROUP BY service_number """%(str(obSeq), str(self.ITEM_CAT_SEQ))
            ret = psql(self.orchDBIP, GET_SVC_SQL, True, 'service_number')
            if ret == None or len(ret) != 1 :
                logger.error("  [ERROR] No Service_Number, obSeq=%s, itemcatseq=%s, ret=%s"%(str(obSeq), str(self.ITEM_CAT_SEQ), str(ret)))
                return False
            osSvcNum = ret[0]
            
            logger.info("  * OB_SEQ: %s\n  * OB_IP: %s\n  * ITEM_OBJ: %s\n  * SVC_NUM: %s"%(str(obSeq), obIP, str(itemObj), osSvcNum))
            
            
            logger.info("- ZNMSC Setting....")

            ### znmsc 설치
            logger.info("  1. ZNMSC Install")
            
            ## znmsc Dir 생성
            logger.info("    1-1. Make ZNMSC DIR -> %s"%self.ZNMSC_DIR)
            _CMD = """ mkdir -p %s """%self.ZNMSC_DIR
            ret = run(obIP, _CMD)
            if ret == None or ret != "" :
                logger.error("    [ERROR] Fail to Make ZNMSC DIR, cmd=%s, ret=%s"%(_CMD, ret))
                return False
            
            ## znmsc binary 복사
            logger.info("    1-2. Send ZNMSC Binary")
            import commands
            _CMD = """ scp -P 9922 -o StrictHostKeyChecking=no %s %s:%s """%( self.ZNMSC_FILE, obIP, self.ZNMSC_DIR )
            res, ret = commands.getstatusoutput(_CMD)
            if res != 0 :
                logger.error("    [ERROR] Fail to Send ZNMSC Binary, cmd=%s, ret=%s"%(_CMD, ret))
                return False
            
            ## znmsc 설치
            logger.info("    1-3. Install ZNMSC")
            _CMD = """ %s/znmsc -install """ %( self.ZNMSC_DIR )
            ret = run(obIP, _CMD)
            if ret == None or str(ret).find("completed") < 0 :
                logger.error("    [ERROR] Fail to Install ZNMSC, cmd=%s, ret=%s"%(_CMD, ret))
                return False
            logger.info("      SC : %s"%str(ret).replace("\n", "\n           "))
            
            ## znmsc 설정
            logger.info("    1-4. Set ZNMSC Collector ID")
            _CMD = """ %s/znmsc -uid %s """ %( self.ZNMSC_DIR, obID )
            ret = run(obIP, _CMD)
            if ret == None or str(ret).find(obID) < 0 :
                logger.error("    [ERROR] Fail to Set ZNMSC Collector ID, cmd=%s, ret=%s"%(_CMD, ret))
                return False
            logger.info("      SC : %s"%str(ret).replace("\n", "\n           "))
            
            logger.info("    1-5. Set ZNMSC Server Info")
            _CMD = """ %s/znmsc -mgr1 %s """ %( self.ZNMSC_DIR, self.ZNMS_IP )
            for zPort in self.ZNMS_PORTS :
                _CMD += "%s "%str(zPort)
            ret = run(obIP, _CMD)
            if ret == None or str(ret).find(self.ZNMS_IP) < 0 :
                logger.error("    [ERROR] Fail to Set ZNMSC Server Info, cmd=%s, ret=%s"%(_CMD, ret))
                return False
            logger.info("      SC : %s"%str(ret).replace("\n", "\n           "))
            
            ## znmsc 시작
            logger.info("    1-6. Start ZNMSC")
            _CMD = """ service znmsc restart """
            ret = run(obIP, _CMD)
            if ret == None or str(ret).find("Starting") < 0 :
                logger.error("    [ERROR] Fail to Start ZNMSC, cmd=%s, ret=%s"%(_CMD, ret))
                return False
            logger.info("      SC : %s"%str(ret).replace("\n", "\n           "))
            
            
            ### svc plugin 수정
            logger.info("  2. Service Monitoring Plugin Update")
            
            logger.info("    2-1. Find Service Monitor Plugin")
            _CMD = """ find /usr/plugin/ -name svc-status.sh """
            ret = run(obIP, _CMD)
            if ret == None :
                logger.error("    [ERROR] Fail to Find Service Monitor Plugin, cmd=%s, ret=%s"%(_CMD, ret))
                return False            
            logger.info("      SC : %s"%str(ret).replace("\n", "\n           "))
            
            logger.info("    2-2. Update Service Monitor Plugin")
            pList = str(ret).split()
            for pName in pList :
                if pName != None and type(pName) == str and str(pName).strip() != "" :
                    __CMD = """ sed -i "s/grep -c /grep -ci /g" %s """ %pName
                    _ret = run(obIP, __CMD)
                    if _ret == None :
                        logger.error("    [ERROR] Fail to Update Service Monitor Plugin, cmd=%s, ret=%s"%(__CMD, _ret))
                        return False
                    else:
                        logger.info("      SC : Update %s"%str(pName))
                else:
                    logger.error("    [ERROR] Fail to Get Service Monitor Plugin Name, cmd=%s, ret=%s"%(_CMD, pList))
                    return False
            
            
            ### view 설정
            logger.info("  3. ZNMSC Web-View Setting")
            
            ## Object 추가
            logger.info("    3-1. Add ZNMSC Item, itemCatSeq=%s"%self.ITEM_CAT_SEQ)
            if not "znmsc" in itemObj :
                modObj = itemObj + ["znmsc"]
                _TID = "batch-%s-icat_%s-%s"%(obID, str(self.ITEM_CAT_SEQ), str(datetime.now().strftime("%Y%m%d-%H:%M:%S")))
                _body={
                    "tid":_TID,
                    "svr_seq":obSeq,
                    "item_cat_seq":self.ITEM_CAT_SEQ,
                    "object_list":modObj
                }
                ret = callZB(self.url, _body)
                logger.info(ret)
                if ret['result'] == 'SC' :
                    logger.info( "      SC : body=%s"%str(_body).replace("\n", "\n           ") )
                else:
                    logger.error( "      [ERROR] body=%s, ret=%s"%(str(_body), str(ret)) )
                    return False
                
            sqlUpdateOsSvc = """ UPDATE tb_moniteminstance SET service_number='%s'
            WHERE delete_dttm is null AND service_number is null
                AND serverseq=%s AND monitemcatseq=%s """%(str(osSvcNum), str(obSeq), str(self.ITEM_CAT_SEQ))
            _ret = psql(self.orchDBIP, sqlUpdateOsSvc, False)
            if _ret == None :
                logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
                return _rest
            else:
                logger.info( "      SC : Set OsSvc_Inf's SVC_Num, svc_num=%s, ret=%s"%(str(osSvcNum), str(_ret)) )
                
            
            ## View DB 업데이트
            logger.info("    3-2. Update NMS View")
            IIS_SQL = """
SELECT moniteminstanceseq iis FROM tb_moniteminstance
WHERE serverseq=%s AND delete_dttm is null AND monitemcatseq=%s AND monitorobject='%s' """%(str(obSeq), str(self.ITEM_CAT_SEQ), 'znmsc')
            ret = psql(self.orchDBIP, IIS_SQL, True, 'iis')
            if ret == None or len(ret) < 1:
                logger.error("      [ERROR] Fail to Get ItemInstance znmsc, sql=%s"%IIS_SQL)
                return False
            
            iis = ret[0]
            logger.info("      SC : body=%s"%str(iis).replace("\n", "\n           "))
            
            DEL_SQL = """ DELETE FROM tb_monviewinstance WHERE serverseq=%s AND viewseq=%s """%(str(obSeq), str(60))
            ret = psql(self.orchDBIP, DEL_SQL, False)
            
            INS_SQL = """
INSERT INTO tb_monviewinstance( serverseq, viewseq, monitorobject, moniteminstanceseq) 
VALUES (%s, 60, 'znmsc', %s); """%(str(obSeq), str(iis))
            ret = psql(self.orchDBIP, INS_SQL, False)
            if ret == None :
                logger.error("      [ERROR] Fail to Insert View Inst, sql=%s"%INS_SQL)
                return False
            
            return True
        except Exception, e:
            logger.error("  [ERROR] Fail to Setting ZNMSC")
            logger.exception(e)
            return False


if __name__ == '__main__':
    if len(sys.argv) >= 3:
        bn = Batch(str(sys.argv[1]).strip(), str(sys.argv[2]).strip())
        bn.batch()
    else:
        print "wrong parameter, Orch-M IP, Orch-M DB IP"



