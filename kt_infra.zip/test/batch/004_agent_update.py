#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys, psycopg2, paramiko, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from time import sleep

import logging
from logging import handlers

BNAME = str(os.path.basename(__file__)).replace(".py", "")

TAG="batch_" + BNAME + "_"+str(datetime.now().strftime("%Y%m%d-%H%M%S"))
logger = logging.getLogger(TAG)
logger.setLevel(logging.DEBUG)
fmt = logging.Formatter("[%(asctime)s][%(levelname)-5s][%(module)s.%(lineno)04d] %(message)s")
log_handler = handlers.RotatingFileHandler(TAG+".log", maxBytes=1024 * 1024 * 10, backupCount=5)
log_handler.setFormatter(fmt)
logger.addHandler(log_handler)
logger.propagate = False
stdfmt = logging.Formatter("%(message)s")
stdout_handler = logging.StreamHandler(sys.stdout)
stdout_handler.setFormatter(stdfmt)
logger.addHandler(stdout_handler)

import Crypto.Cipher.AES
orig_new = Crypto.Cipher.AES.new
def fixed_AES_new(key, *ls):
    if Crypto.Cipher.AES.MODE_CTR == ls[0] :
        ls = list(ls)
        ls[1] = ''
    return orig_new(key, *ls)

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "https://%s:5555/"

# KEY_FILE = "/root/.ssh/id_rsa.pub"
# DB_NAME = "orch_v1"
# DB_USER = "onebox"
# DB_PASS = "kkh@2016!ok"
# DB_PORT = 5432
KEY_FILE = "/root/.ssh/id_rsa.pub"
DB_NAME = "orch_v1"
DB_USER = "nfv"
DB_PASS = "ohhberry3333"
DB_PORT = 5432

IDX = datetime.now().strftime("%Y_%m_%d_01")


def callZB( url, reqBody ):
    
    http_client = httpclient.HTTPClient()
    h = HTTPHeaders(HEADER)
    strBody = json.dumps( reqBody )
    _request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, body=strBody, request_timeout=30 )
    
    response = http_client.fetch( request=_request )
    http_client.close()
    
    resp = json.loads(response.body)
    
    return resp

def run( ip, cmd, _port=9922, _timeout=5 ):
    client = paramiko.SSHClient()
    try:
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            client.connect( ip, port=_port, username="root", key_filename=KEY_FILE, timeout=_timeout )
        except ValueError, e:
            Crypto.Cipher.AES.new = fixed_AES_new
            client.connect( ip, port=_port, username="root", key_filename=KEY_FILE, timeout=_timeout )
        stdin, stdout, stderr = client.exec_command( cmd )
        ret = str(stdout.read()).strip()
    except Exception, e:
        logger.error("[ERROR] Fail to SSH CMD, ip=%s, cmd=%s"%(str(ip), str(cmd)))
        logger.exception(e)
    client.close()
    return ret

def psql(_ip, _sql, isSelect, param=None, _dbConn=None):
    if _dbConn == None : 
        dbConn = psycopg2.connect( database=DB_NAME, user=DB_USER, password=DB_PASS,
                             host=_ip, port=DB_PORT )
        dbConn.autocommit = True
    else:
        dbConn = _dbConn
    
    cur = dbConn.cursor()
    cur.execute( _sql )
    
    dic = None
    if isSelect:
        dic = []
        columns = [desc[0] for desc in cur.description]
        rows = cur.fetchall()
        for row in rows:
            d = dict(zip(columns, row))
            if type(param) == str and param != "" :
                dic.append( d[param] )
            else:
                dic.append(d)
    else:
        if type(param) == bool and param == True :
            try:
                cur.execute('SELECT LASTVAL()')
                ret = cur.fetchone()
                if ret == None or len(ret) < 1 :
                    dic = None
                else:
                    dic = ret[0]
            except Exception, e:
                logger.info( sql )
                logger.exception( e )
                dic = None
        else:
            dic = int(cur.rowcount)
    
    cur.close()
    if _dbConn == None :
        dbConn.close()
    
    return dic

def backupFiles(_obIP, bfList):
    for bf in bfList :
        _cmd = """ mkdir -p /var/onebox/backup/batch/%s/%s 2>&1 """%(IDX, os.path.dirname(bf))
        _ret = run(_obIP, _cmd)
        if _ret != "" :
            logger.error( "      [ERROR] Fail to MKDIR, cmd=%s, ret=%s"%(_cmd, str(_ret)) )
            return False
        
        _cmd = """ cp %s /var/onebox/backup/batch/%s/%s 2>&1  """%(bf, IDX, bf)
        _ret = run(_obIP, _cmd)
        if _ret != "" :
            logger.error( "      [ERROR] Fail to Copy, cmd=%s, ret=%s"%(_cmd, str(_ret)) )
            return False
    return True

def restoreFiles(_obIP, bfList):
    logger.info( "  * File: %s"%str(bfList) )
    if _obIP == None :
        logger.error( "    [ERROR] No OB IP" )
        return
    
    for bf in bfList :
        _cmd = """ cp /var/onebox/backup/batch/%s%s %s 2>&1 """%(IDX, bf, bf)
        _ret = run(_obIP, _cmd)
        if str(_ret).strip() != "" :
            logger.error( "    [ERROR] cmd=%s, ret=%s"%(_cmd, str(_ret)) )
    return




class Batch:
    
    OBLIST = ["HATEST.OB1"]
    
    AGENT_NAME = "onebox-agent"
    AGENT_DIR = "/var/onebox/softwares/onebox-agent/ver.0.0.1"
    AGENT_BRANCH = "20170605_public_ip_mod"
    
    def __init__(self, orchIP, orchDBIP):
        self.orchIP = orchIP
        self.orchDBIP = orchDBIP
    
    def batch(self):
        _idx = 0
        
        for obID in self.OBLIST :
            _idx += 1
            logger.info( "########## %s %s batch, progress=%s/%s ##########"%(obID, IDX, str(_idx), str(len(self.OBLIST))) )
            try:
                if self.doUpdate(obID) :
                    logger.info("[SUCC] Update Complete\n\n")
                
            except Exception, e:
                logger.error("[ERROR] Fail to Batch, ob=%s\n\n"%str(obName))
                logger.exception(e)
    
    def startAgt(self, obIP):
        _CMD = """ service %s restart """%self.AGENT_NAME
        ret = run(obIP, _CMD)
        logger.info(" [RESTORE] agent restart, ret=%s"%str(ret))
    
    def doUpdate(self, obID):
        _restart = False
        obIP = None
        try:
            ### 사전 조회 : 
            logger.info("- Loading....")
            
            GET_SQL = """ SELECT serverseq, mgmtip FROM tb_server WHERE onebox_id='%s' GROUP BY serverseq, mgmtip """%(obID)
            ret = psql(self.orchDBIP, GET_SQL, True)
            if ret == None or len(ret) != 1 :
                logger.error("  [ERROR] No Data, obid=%s, ret=%s"%(obID, str(ret)))
                return False
            
            obSeq = ret[0]['serverseq']
            obIP = ret[0]['mgmtip']
            if obSeq == None or str(obSeq).strip() == '' or obIP == None or str(obIP).strip() == '' :
                logger.error("  [ERROR] No Data, obid=%s, ret=%s"%(obID, str(ret)))
                return False
            
            logger.info("  * OB_SEQ: %s\n  * OB_IP: %s\n"%(str(obSeq), obIP))
            
            
            ### Update 수행
            logger.info("- Updating....")
            
            ## GIT Pull
            logger.info("  1. GIT Pull, Agent=%s"%self.AGENT_NAME)
            
            _CMD = """ cd %s ; git pull ; git checkout %s """%(self.AGENT_DIR, self.AGENT_BRANCH)
            ret = run(obIP, _CMD)
            if ret == None :
                logger.error("   [ERROR] Fail to GIT PULL, cmd=%s, ret=%s"%(_CMD, ret))
                return False
            
            if str(ret).find("Already up-to-date") != 0 and str(ret).find("Updating") != 0 :
                logger.error("   [ERROR] Fail to GIT PULL, cmd=%s, ret=%s"%(_CMD, ret))
                return False
            logger.info("   ---> Res: %s"%str(ret).replace("\n", "\n             ") )
            
            
            ## Agent Stop
            logger.info("  2. Stop Agent, Agent=%s"%self.AGENT_NAME)
            
            _CMD = """ service %s stop """%self.AGENT_NAME
            ret = run(obIP, _CMD)
            if ret == None :
                logger.error("   [ERROR] Fail to Stop Agent, cmd=%s, ret=%s"%(_CMD, ret))
                return False
            logger.info("   ---> Res: %s"%str(ret).replace("\n", "\n             ") )
            
            _restart = True
            
            ## Agent Source Compile
            logger.info("  3. Re-Install Agent, Agent=%s"%self.AGENT_NAME)
            
            logger.info("    3-1. UnInstall Agent, Agent=%s"%self.AGENT_NAME)
            
            _CMD = """ cd %s ; pip uninstall -y %s """%(self.AGENT_DIR, self.AGENT_NAME)
            ret = run(obIP, _CMD)
            if ret == None :
                logger.error("   [ERROR] Fail to UnInstall Agent, cmd=%s, ret=%s"%(_CMD, ret))
                self.startAgt(obIP)
                return False
            logger.info("     ---> Res: %s"%str(ret).replace("\n", "\n               ") )
            
            logger.info("    3-2. Install Agent, Agent=%s"%self.AGENT_NAME)
            
            _CMD = """ cd %s ; python setup.py install > /dev/null """%self.AGENT_DIR
            ret = run(obIP, _CMD)
            if ret == None or str(ret) != "" :
                logger.error("   [ERROR] Fail to Install Agent, cmd=%s, ret=%s"%(_CMD, ret))
                self.startAgt(obIP)
                return False
            
            
            ## Start Agent
            logger.info("  4. Start Agent, Agent=%s"%self.AGENT_NAME)
            logger.info("    4-1. Run Agent")
            
            _CMD = """ service %s start """%self.AGENT_NAME
            ret = run(obIP, _CMD)
            if ret == None :
                logger.error("     [ERROR] Fail to Start Agent, cmd=%s, ret=%s"%(_CMD, ret))
                self.startAgt(obIP)
                return False
            logger.info("     ---> SC: %s"%str(ret).replace("\n", "\n               ") )
            
            logger.info("    4-2. Check Agent")
            
            _CMD = """ service %s status """%self.AGENT_NAME
            ret = run(obIP, _CMD)
            if ret == None or str(ret).lower().find('running') < 0 :
                logger.error("     [ERROR] Fail to Check Agent, cmd=%s, ret=%s"%(_CMD, ret))
                self.startAgt(obIP)
                return False
            logger.info("     ---> SC: %s"%str(ret).replace("\n", "\n               ") )
            
            return True
        except Exception, e:
            logger.error("  [ERROR] Fail to Update")
            logger.exception(e)
            if _restart and obIP != None :
                self.startAgt(obIP)
            return False


if __name__ == '__main__':
    if len(sys.argv) >= 3:
        bn = Batch(str(sys.argv[1]).strip(), str(sys.argv[2]).strip())
        bn.batch()
    else:
        print "wrong parameter, Orch-M IP, Orch-M DB IP"



