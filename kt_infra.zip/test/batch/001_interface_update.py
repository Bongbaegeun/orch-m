#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys, psycopg2, paramiko, os
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime
from time import sleep

import logging
from logging import handlers

TAG="batch_001_interface_update_"+str(datetime.now().strftime("%Y%m%d-%H%M%S"))
logger = logging.getLogger(TAG)
logger.setLevel(logging.DEBUG)
fmt = logging.Formatter("[%(asctime)s][%(levelname)-5s][%(module)s.%(lineno)04d] %(message)s")
log_handler = handlers.RotatingFileHandler(TAG+".log", maxBytes=1024 * 1024 * 10, backupCount=5)
log_handler.setFormatter(fmt)
logger.addHandler(log_handler)
logger.propagate = False
stdfmt = logging.Formatter("%(message)s")
stdout_handler = logging.StreamHandler(sys.stdout)
stdout_handler.setFormatter(stdfmt)
logger.addHandler(stdout_handler)

import Crypto.Cipher.AES
orig_new = Crypto.Cipher.AES.new
def fixed_AES_new(key, *ls):
    if Crypto.Cipher.AES.MODE_CTR == ls[0] :
        ls = list(ls)
        ls[1] = ''
    return orig_new(key, *ls)

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "https://%s:5555/server/item/mod/object"

KEY_FILE = "/root/.ssh/id_rsa.pub"
DB_NAME = "orch_v1"
DB_USER = "nfv"
DB_PASS = "ohhberry3333"
DB_PORT = 5432

OBA_CFG = "/etc/onebox/onebox-agent.conf"
# HOST_NET_ITEM_CATS = [39, 40, 41]
# UTM_NET_ITEM_CATS = [65, 66, 67]
# OS_TEMP_SEQ = 6
# UTM_TEMP_SEQ = 8
HOST_NET_ITEM_CATS = [51, 52, 53]
UTM_NET_ITEM_CATS = [77, 78, 79]
OS_TEMP_SEQ = 9
UTM_TEMP_SEQ = 11

IDX = datetime.now().strftime("%Y_%m_%d_01")
PLIST = ["HATEST.OB1"]
bfList = [ "/etc/onebox/onebox-agent.conf" ]

REST_FILE = 1
REST_ITEM = 2 ## object 변경 및 viewinstance의 moniteminstanceseq 업데이트 필요
REST_VIEW = 4 ## DB rollback 후 viewinstance의 moniteminstanceseq 업데이트 필요

def callZB( url, reqBody ):
    
    http_client = httpclient.HTTPClient()
    h = HTTPHeaders(HEADER)
    strBody = json.dumps( reqBody )
    _request = HTTPRequest( url, headers=h, method=METHOD.upper(), validate_cert=False, body=strBody, request_timeout=30 )
    
    response = http_client.fetch( request=_request )
    http_client.close()
    
    resp = json.loads(response.body)
    
    return resp

def run( ip, cmd, _port=9922, _timeout=5 ):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect( ip, port=_port, username="root", key_filename=KEY_FILE, timeout=_timeout )
    except ValueError, e:
        Crypto.Cipher.AES.new = fixed_AES_new
        client.connect( ip, port=_port, username="root", key_filename=KEY_FILE, timeout=_timeout )
    stdin, stdout, stderr = client.exec_command( cmd )
    ret = str(stdout.read()).strip()
    client.close()
    return ret

def psql(_ip, _sql, isSelect, param=None, _dbConn=None):
    if _dbConn == None : 
        dbConn = psycopg2.connect( database=DB_NAME, user=DB_USER, password=DB_PASS,
                             host=_ip, port=DB_PORT )
        dbConn.autocommit = True
    else:
        dbConn = _dbConn
    
    cur = dbConn.cursor()
    cur.execute( _sql )
    
    dic = None
    if isSelect:
        dic = []
        columns = [desc[0] for desc in cur.description]
        rows = cur.fetchall()
        for row in rows:
            d = dict(zip(columns, row))
            if type(param) == str and param != "" :
                dic.append( d[param] )
            else:
                dic.append(d)
    else:
        if type(param) == bool and param == True :
            try:
                cur.execute('SELECT LASTVAL()')
                ret = cur.fetchone()
                if ret == None or len(ret) < 1 :
                    dic = None
                else:
                    dic = ret[0]
            except Exception, e:
                logger.info( sql )
                logger.exception( e )
                dic = None
        else:
            dic = int(cur.rowcount)
    
    cur.close()
    if _dbConn == None :
        dbConn.close()
    
    return dic


def backupFiles(_obIP, bfList):
    for bf in bfList :
        _cmd = """ mkdir -p /var/onebox/backup/batch/%s/%s 2>&1 """%(IDX, os.path.dirname(bf))
        _ret = run(_obIP, _cmd)
        if _ret != "" :
            logger.error( "      [ERROR] Fail to MKDIR, cmd=%s, ret=%s"%(_cmd, str(_ret)) )
            return False
        
        _cmd = """ cp %s /var/onebox/backup/batch/%s/%s 2>&1  """%(bf, IDX, bf)
        _ret = run(_obIP, _cmd)
        if _ret != "" :
            logger.error( "      [ERROR] Fail to Copy, cmd=%s, ret=%s"%(_cmd, str(_ret)) )
            return False
    return True


def restoreFiles(_obIP, bfList):
    logger.info( "  * File: %s"%str(bfList) )
    if _obIP == None :
        logger.error( "    [ERROR] No OB IP" )
        return
    
    for bf in bfList :
        _cmd = """ cp /var/onebox/backup/batch/%s%s %s 2>&1 """%(IDX, bf, bf)
        _ret = run(_obIP, _cmd)
        if str(_ret).strip() != "" :
            logger.error( "    [ERROR] cmd=%s, ret=%s"%(_cmd, str(_ret)) )
    return

def restoreItem(_url, pInfo, obSeq, hostNet, utmNet):
    logger.info( "  * Item: HostNet=%s, utmNet=%s"%(str(hostNet), str(utmNet)) )
    if hostNet == None or utmNet == None :
        logger.error( "    [ERROR] No NetInfo, host=%s, utm=%s"%(str(hostNet), str(utmNet)) )
        return 
    
    logger.info( "    1. Host Net Item" )
    for icSeq in HOST_NET_ITEM_CATS :
        _TID = "batch-%s-icat_%s-%s"%(pInfo, str(icSeq), str(datetime.now().strftime("%Y%m%d-%H:%M:%S")))
        _data={
            "tid":_TID,
            "svr_seq":obSeq,
            "item_cat_seq":icSeq, #39,40,41
            "object_list":hostNet
        }
        _ret = None
        try:
            _ret = callZB(_url, _data)
            if _ret['result'] == 'SC' :
                logger.info( "      SC : ItemCatSeq=%s"%str(icSeq) )
            else:
                logger.error( "      [ERROR] ItemCatSeq=%s, ret=%s"%(str(icSeq), str(_ret)) )
        except Exception, e:
            logger.error( "      [ERROR] ItemCatSeq=%s, ret=%s"%(str(icSeq), str(_ret)) )
            logger.exception( e )
    
    logger.info( "    2. UTM Net Item" )
    for icSeq in UTM_NET_ITEM_CATS :
        _TID = "batch-%s-icat_%s-%s"%(pInfo, str(icSeq), str(datetime.now().strftime("%Y%m%d-%H:%M:%S")))
        _data={
            "tid":_TID,
            "svr_seq":obSeq,
            "item_cat_seq":icSeq, #39,40,41
            "object_list":utmNet
        }
        _ret = None
        try:
            _ret = callZB(_url, _data)
            if _ret['result'] == 'SC' :
                logger.info( "      SC : ItemCatSeq=%s"%str(icSeq) )
            else:
                logger.error( "      [ERROR] ItemCatSeq=%s, ret=%s"%(str(icSeq), str(_ret)) )
        except Exception, e:
            logger.error( "      [ERROR] ItemCatSeq=%s, ret=%s"%(str(icSeq), str(_ret)) )
            logger.exception( e )

def restoreView(rbDB):
    logger.info( "  * View" )
    if rbDB == None : 
        logger.error( "      [ERROR] No RB DB" )
        return
    
    rbDB.rollback()

def refreshView(_db_ip, svrSeq):
    logger.info( "  * View Item" )
    if svrSeq == None :
        logger.error( "    [ERROR] No Server Seq" )
        return
    
    _viewSeq = ['8','9','10','11','12','13','14','15','16','17','18','19','38','39','40','41','51','52','53','54','55','56','57','58','59']
    
    _sql = """
    UPDATE tb_monviewinstance vi SET moniteminstanceseq=vv.moniteminstanceseq
    FROM (
        SELECT ii.serverseq, ii.moniteminstanceseq, vm.monitorobject, vm.viewseq
        FROM (SELECT vi.serverseq, vi.viewseq, viewname, targetcode, targettype, groupname, monitortype, monitorobject 
            FROM tb_monviewinstance vi, tb_monviewcatalog vc
            WHERE vi.serverseq=%s AND vi.viewseq in (%s) AND vi.viewseq=vc.viewseq) vm, tb_moniteminstance ii
        LEFT OUTER JOIN tb_montargetcatalog tc ON ii.montargetcatseq=tc.montargetcatseq
        LEFT OUTER JOIN tb_mongroupcatalog gc ON ii.mongroupcatseq=gc.mongroupcatseq
        WHERE ii.delete_dttm is null AND ii.serverseq=vm.serverseq
            AND vm.groupname=gc.groupname AND vm.monitortype=ii.monitortype
            AND ( (vm.targettype is not null AND vm.targettype=tc.targettype) OR (vm.targettype is null AND vm.targetcode=tc.targetcode) )
            AND ( (vm.monitorobject is not null AND ii.monitorobject=vm.monitorobject ) OR (vm.monitorobject is null AND ii.monitorobject is null) )
        ORDER BY serverseq, vm.viewseq ) vv
    WHERE vi.serverseq=vv.serverseq AND vi.viewseq=vv.viewseq 
        AND ( (vi.monitorobject is not null AND vi.monitorobject=vv.monitorobject ) OR (vi.monitorobject is null AND vv.monitorobject is null) )
    """%(str(svrSeq), ",".join(_viewSeq))
    
    return psql(_db_ip, _sql, False)


# SELECT * FROM tb_monviewinstance vi
# WHERE vi.serverseq=156 AND vi.moniteminstanceseq not in (
#     SELECT moniteminstanceseq FROM tb_moniteminstance ii
#     WHERE ii.serverseq=156 AND ii.delete_dttm is null
# )



class Batch_Net:
    obIP = None
    ORG_MON_ITEM = None
    RB_DB = None
    OB_SEQ = None
    _URL = None
    
    def __init__(self, orchIP, orchDBIP):
        self.orchIP = orchIP
        self.orchDBIP = orchDBIP
        self._URL = URL%orchIP
    
    ## 호스트 및 utm 인터페이스 object 변경 작업
    def batch(self):
        orchIP=self.orchIP
        orchDBIP=self.orchDBIP
        
        _idx = 1
        for pInfo in PLIST :
            ret = 0
            self.obIP = None
            self.ORG_MON_ITEM = None
            self.RB_DB = None
            self.OB_SEQ = None
            logger.info( "########## %s %s batch, progress=%s/%s ##########"%(pInfo, IDX, str(_idx), str(len(PLIST))) )
            try:
                ret = self.modNetObject(orchIP, orchDBIP, pInfo, _idx)
                if ret > 0 :
                    logger.info( "- Restore ...." )
                    if ret & REST_FILE :
                        restoreFiles(self.obIP, bfList)
                    if ret & REST_ITEM :
                        restoreItem(self._URL, pInfo, self.OB_SEQ, self.ORG_MON_ITEM['host_net'], self.ORG_MON_ITEM['utm_net'])
                    if ret & REST_VIEW :
                        restoreView(self.RB_DB)
                    if ret & REST_ITEM or ret & REST_VIEW :
                        refreshView(orchDBIP, self.OB_SEQ)
                    logger.info( "  [Done] Restore..." )
                    logger.error( "[FAIL] Update Fail  !!!!!!!!!!\n\n" )
                else:
                    logger.info( "[SUCC] Update Complete\n\n" )
            except Exception, e:
                logger.error( "[ERROR] Fail to Batch, ob=%s\n\n"%pInfo )
                logger.exception( e )
            _idx += 1
            if self.RB_DB != None :
                self.RB_DB.commit()
                self.RB_DB.close()
            
            if ret > 0:
                sys.exit()
            
    
    def modNetObject(self, orchIP, orchDBIP, pInfo, _idx):
        _rest = 0
        
        ## 정보 수집
        logger.info( "- Loading...." )
        # onebox 정보 
        sqlGetOBIP = """ SELECT mgmtip, serverseq FROM tb_server WHERE onebox_id='%s' """%pInfo
        _ret = psql(orchDBIP, sqlGetOBIP, True)
        self.obIP = _ret[0]['mgmtip']
        self.OB_SEQ = int(_ret[0]['serverseq'])
        if self.obIP == None or str(self.obIP).strip() == "" or self.OB_SEQ == None :
            logger.info( "    [ERROR] No OB Info, ret=%s"%str(_ret) )
            return 0
        logger.info( "  1. OB IP: %s, Seq: %s"%(self.obIP, self.OB_SEQ) )
        
        # onebox office interface
        _cmd = """ ovs-vsctl list-ports br-lan-office | grep -v phy """
        _ret = run(self.obIP, _cmd)
        offIf = str(_ret).split()
        _offIf = ",".join(offIf)
        if _offIf == None or _offIf.strip() == "" :
            logger.error( "    [ERROR] No Office Interface" )
            return 0
        logger.info( "  2. OFF_IF: %s"%_offIf )
        
        # onebox server interface
        _cmd = """ ovs-vsctl list-ports br-lan-server | grep -v phy """
        _ret = run(self.obIP, _cmd)
        svrIf = str(_ret).split()
        _svrIf = ",".join(svrIf)
#         if _svrIf == None or _svrIf.strip() == "" :
#             logger.error( "    [ERROR] No Server Interface" )
#             return 0
        logger.info( "  3. SVR_IF: %s"%_svrIf )
        
        # onebox wan interface
        sqlGetOBWan = """ SELECT monitorobject FROM tb_monviewinstance 
        WHERE serverseq=%s AND viewseq=8 Group by monitorobject """%(str(self.OB_SEQ))
        _ret = psql(orchDBIP, sqlGetOBWan, True, "monitorobject")
        wanIf = _ret
        if wanIf == None or len(wanIf) < 1 :
            logger.error( "    [ERROR] No Wan Info, ret=%s"%str(_ret) )
            return 0
        logger.info( "  4. WAN_IF: %s"%wanIf )
        
#         # onebox utm.wan interface
#         utmWanIf = []
#         for _br in ["br-wan", "br-wan1", "br-wan2", "br-wan3"] :
#             _cmd = """ ovs-vsctl list-ports %s | grep -v phy """%_br
#             _ret = run(self.obIP, _cmd)
#             utmWanIf += str(_ret).split()
#         logger.info( "  5. UTM_WAN_IF: %s"%_svrIf )
        
        # OS Network Interface Service Number
        OS_TEMP_SEQ
        sqlGetSvcNum = """ SELECT montargetcatseq, service_number FROM tb_moniteminstance ii
        WHERE serverseq=%s AND delete_dttm is null AND montargetcatseq in (%s, %s)
        GROUP BY montargetcatseq, service_number """%(str(self.OB_SEQ), str(OS_TEMP_SEQ), str(UTM_TEMP_SEQ))
        _ret = psql(orchDBIP, sqlGetSvcNum, True)
        svcNums = _ret
        if svcNums == None or len(svcNums) != 2 :
            logger.error( "    [ERROR] Invalide Service Number, ret=%s"%str(_ret) )
            return 0
        osSvcNum = None
        utmSvcNum = None
        for _svcNum in svcNums :
            try:
                if str(OS_TEMP_SEQ) == str(_svcNum['montargetcatseq']).strip() :
                    osSvcNum = _svcNum['service_number']
                elif str(UTM_TEMP_SEQ) == str(_svcNum['montargetcatseq']).strip() :
                    utmSvcNum = _svcNum['service_number']
                else:
                    logger.error( "    [ERROR] Invalide Service Number, ret=%s"%str(_ret) )
                    return 0
            except Exception, e:
                logger.error( "    [ERROR] Invalide Service Number, ret=%s"%str(_ret) )
                return 0
        
        if osSvcNum == None or utmSvcNum == None :
            logger.error( "    [ERROR] Invalide Service Number, ret=%s"%str(_ret) )
            return 0
        logger.info( "  5. Service Number: OS=%s, UTM=%s"%(osSvcNum, utmSvcNum) )
        
        
        ## 0. backup
        logger.info( "- Backup...." )
        # OBA CFG
        _cmd = """ mkdir -p /var/onebox/backup/batch/%s  """%IDX
        run(self.obIP, _cmd)
        
        _ret = backupFiles(self.obIP, bfList)
        if not _ret :
            logger.error( "    [ERROR] Fail to Backup" )
            return 0
        logger.info( "  1. backup, f=%s"%str(bfList) )
        
        # MonItem Instance
        sqlGetHostNet = """ SELECT monitorobject FROM tb_moniteminstance
        WHERE serverseq=%s AND monitemcatseq=%s AND delete_dttm is null Group by monitorobject"""%(str(self.OB_SEQ), str(HOST_NET_ITEM_CATS[0]))
        _ret = psql(orchDBIP, sqlGetHostNet, True, "monitorobject")
        hostNet = _ret
        if hostNet == None or len(hostNet) < 1 :
            logger.error( "    [ERROR] No Host Network Info, ret=%s"%str(_ret) )
            return 0
        logger.info( "  2. Host Net: %s"%hostNet )
        
        sqlGetUtmNet = """ SELECT monitorobject FROM tb_moniteminstance
        WHERE serverseq=%s AND monitemcatseq=%s AND delete_dttm is null Group by monitorobject"""%(str(self.OB_SEQ), str(UTM_NET_ITEM_CATS[0]))
        _ret = psql(orchDBIP, sqlGetUtmNet, True, "monitorobject")
        utmNet = _ret
        if utmNet == None or len(utmNet) < 1 :
            logger.error( "    [ERROR] No UTM Network Info, ret=%s"%str(_ret) )
            return 0
        logger.info( "  3. UTM Net: %s"%utmNet )
        self.ORG_MON_ITEM = {"host_net": hostNet, "utm_net": utmNet}
        
        # MonView Instance
        self.RB_DB = psycopg2.connect( database=DB_NAME, user=DB_USER, password=DB_PASS,
                                     host=orchDBIP, port=DB_PORT )
        self.RB_DB.autocommit = False
        
        try:
            logger.info( "- Update...." )
            _rest = REST_FILE
            ## 1. oba 설정 변경
            # office
            logger.info( "  1. OBA Config: Office Net -> %s"%_offIf )
            _cmd = """ sed -i "s/^lan_office_nic:.*/lan_office_nic: %s/g" %s 2>&1 """%(_offIf, OBA_CFG)
            _ret = run(self.obIP, _cmd)
            if str(_ret).strip() != "" :
                logger.error( "    [ERROR] Fail to Set OBA Cfg, cmd=%s"%_cmd )
                return _rest
            
            _cmd = """ grep "^lan_office_nic" %s | grep -c "%s" """%(OBA_CFG, _offIf)
            _ret = run(self.obIP, _cmd)
            try:
                if int(_ret)  < 1 :
                    logger.error( "    [ERROR] Fail to Set OBA Cfg, cmd=%s, ret=%s"%(_cmd, _ret) )
                    return _rest
            except Exception:
                logger.error( "    [ERROR] Fail to Set OBA Cfg, cmd=%s, ret=%s"%(_cmd, _ret) )
                return _rest
            
            # server
            logger.info( "  2. OBA Config: Server Net -> %s"%_svrIf )
            _cmd = """ sed -i "s/^lan_server_nic:.*/lan_server_nic: %s/g" %s 2>&1 """%(_svrIf, OBA_CFG)
            _ret = run(self.obIP, _cmd)
            if str(_ret).strip() != "" :
                logger.error( "    [ERROR] Fail to Set OBA Cfg, cmd=%s"%_cmd )
                return _rest
            
            _cmd = """ grep "^lan_server_nic" %s | grep -c "%s" """%(OBA_CFG, _svrIf)
            _ret = run(self.obIP, _cmd)
            try:
                if int(_ret)  < 1 :
                    logger.error( "    [ERROR] Fail to Set OBA Cfg, cmd=%s, ret=%s"%(_cmd, _ret) )
                    restoreFiles(self.obIP, bfList)
                    return _rest
            except Exception:
                logger.error( "    [ERROR] Fail to Set OBA Cfg, cmd=%s, ret=%s"%(_cmd, _ret) )
                return _rest
            
            ## 2. orch-m 인터페이스 설정 변경
            # host : office, server 변경
            # utm : server 추가
            _rest += REST_ITEM
            
            HOST_NET_IFS = wanIf + offIf + svrIf
            logger.info( "  3. Host Item Update: CatSeqs=%s, Objects=%s"%(str(HOST_NET_ITEM_CATS), str(HOST_NET_IFS)) )
            for icSeq in HOST_NET_ITEM_CATS :
                _TID = "batch-%s-icat_%s-%s"%(pInfo, str(icSeq), str(datetime.now().strftime("%Y%m%d-%H:%M:%S")))
                _data={
                    "tid":_TID,
                    "svr_seq":self.OB_SEQ,
                    "item_cat_seq":icSeq, #39,40,41
                    "object_list":HOST_NET_IFS
                }
                _ret = None
                try:
                    _ret = callZB(self._URL, _data)
                    if _ret['result'] == 'SC' :
                        logger.info( "   SC : Add O_Net Item, ItemCatSeq=%s"%str(icSeq) )
                    else:
                        logger.error( "   [ERROR] Fail to Add OS_Net Item, ItemCatSeq=%s, ret=%s"%(str(icSeq), str(_ret)) )
                        return _rest
                    
                    sqlUpdateOsSvc = """ UPDATE tb_moniteminstance SET service_number='%s'
                    WHERE delete_dttm is null AND service_number is null
                        AND serverseq=%s AND monitemcatseq=%s """%(str(osSvcNum), str(self.OB_SEQ), str(icSeq))
                    _ret = psql(orchDBIP, sqlUpdateOsSvc, False)
                    if _ret == None :
                        logger.error( "   [ERROR] DB Fail, sql=%s"%_viewSql )
                        return _rest
                    else:
                        logger.info( "   SC : Set OsNet_Inf's SVC_Num, svc_num=%s, ret=%s"%(str(osSvcNum), str(_ret)) )
                    
                except Exception, e:
                    logger.info( "   [ERROR] ItemCatSeq=%s, ret=%s"%(str(icSeq), str(_ret)) )
                    logger.exception( e )
                    return _rest
            
            UTM_NET_IFS = utmNet
            logger.info( "  4. UTM Item Update: CatSeqs=%s, Objects=%s"%(str(UTM_NET_ITEM_CATS), str(UTM_NET_IFS)) )
            for icSeq in UTM_NET_ITEM_CATS :
                _TID = "batch-%s-icat_%s-%s"%(pInfo, str(icSeq), str(datetime.now().strftime("%Y%m%d-%H:%M:%S")))
                _data={
                    "tid":_TID,
                    "svr_seq":self.OB_SEQ,
                    "item_cat_seq":icSeq, #65, 66, 67
                    "object_list":UTM_NET_IFS
                }
                _ret = None
                try:
                    _ret = callZB(self._URL, _data)
                    if _ret['result'] == 'SC' :
                        logger.info( "   SC : ItemCatSeq=%s"%str(icSeq) )
                    else:
                        logger.error( "   [ERROR] ItemCatSeq=%s, ret=%s"%(str(icSeq), str(_ret)) )
                        return _rest
                    
                    sqlUpdateUtmSvc = """ UPDATE tb_moniteminstance SET service_number='%s'
                    WHERE delete_dttm is null AND service_number is null
                        AND serverseq=%s AND monitemcatseq=%s """%(str(utmSvcNum), str(self.OB_SEQ), str(icSeq))
                    _ret = psql(orchDBIP, sqlUpdateOsSvc, False)
                    if _ret == None :
                        logger.error( "   [ERROR] DB Fail, sql=%s"%_viewSql )
                        return _rest
                    else:
                        logger.info( "   SC : Set UtmNet_Inf's SVC_Num, svc_num=%s, ret=%s"%(str(utmSvcNum), str(_ret)) )
                    
                except Exception, e:
                    logger.error( "   [ERROR] ItemCatSeq=%s, ret=%s"%(str(icSeq), str(_ret)) )
                    logger.exception( e )
                    return _rest
            
            logger.info( "   4-1. Check Service Number" )
            sqlGetNullSvc = """ SELECT moniteminstanceseq FROM tb_moniteminstance 
            WHERE serverseq=%s AND delete_dttm is null AND montargetcatseq in (%s, %s) AND service_number is null
            """%(str(self.OB_SEQ), str(OS_TEMP_SEQ), str(UTM_TEMP_SEQ))
            _ret = psql(orchDBIP, sqlGetNullSvc, True, "moniteminstanceseq")
            if _ret == None or len(_ret) > 0 :
                logger.error( "    [ERROR] Null ServiceNumber, ret=%s"%str(_ret) )
                return 0
            else:
                logger.info( "      OK..")
            
            ## 3. tb_monviewinstance 업데이트
            # host : net.office1, net.office2 관련 object null 처리(11~16)
            #        기존 net.office 제거
            #        net.office 추가(51~53)
            #        net.server 제거 후 새로 추가(17~19)
            # utm : utm.net 관련 object null 처리 (38~41)
            #        기존 utm.wan/office/server 제거(54~59)
            #        utm.wan, utm.office, utm.server 추가(54~59)
            _rest += REST_VIEW
            logger.info( "  5. View Update" )
            
            # net.office1/2 null 처리(11~16)
            logger.info( "    5-1. office1 & office2 Null Setting" )
            _viewSql = """ UPDATE tb_monviewinstance SET monitorobject=null, moniteminstanceseq=null
                            WHERE serverseq=%s AND viewseq in (11,12,13,14,15,16) """%str(self.OB_SEQ)
            _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
            if _ret == None :
                logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
            
            # 기존 net.office 제거(51~53)
            logger.info( "    5-2. Prev net.office Delete" )
            _viewSql = """ DELETE FROM tb_monviewinstance WHERE serverseq=%s AND viewseq in (51, 52, 53) """%str(self.OB_SEQ)
            _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
            if _ret == None :
                logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
            
            # net.office 추가(51~53)
            logger.info( "    5-3. New net.office Insert, if=%s"%str(offIf) )
            for vSeq in (51, 52, 53) :
                for mObj in offIf :
                    _viewSql = """ INSERT INTO tb_monviewinstance(serverseq, viewseq, monitorobject)
                                    VALUES (%s, %s, '%s') """%(str(self.OB_SEQ), str(vSeq), mObj)
                    _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
                    if _ret == None :
                        logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
                        return _rest
            
            # net.server 제거(17~19)
            logger.info( "    5-4. Prev net.server Delete" )
            _viewSql = """ DELETE FROM tb_monviewinstance WHERE serverseq=%s AND viewseq in (17, 18, 19) """%str(self.OB_SEQ)
            _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
            if _ret == None :
                logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
            
            # net.server 새로 추가(17~19)
            logger.info( "    5-5. New net.server Insert, if=%s"%str(svrIf) )
            for vSeq in (17, 18, 19) :
                if len(svrIf) < 1:
                    _viewSql = """ INSERT INTO tb_monviewinstance(serverseq, viewseq, monitorobject)
                                    VALUES (%s, %s, null) """%(str(self.OB_SEQ), str(vSeq))
                    _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
                    if _ret == None :
                        logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
                        return _rest
                else:
                    for mObj in svrIf :
                        _viewSql = """ INSERT INTO tb_monviewinstance(serverseq, viewseq, monitorobject)
                                        VALUES (%s, %s, '%s') """%(str(self.OB_SEQ), str(vSeq), mObj)
                        _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
                        if _ret == None :
                            logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
                            return _rest
            
            # utm.net 관련 object null 처리 (38~41)
            logger.info( "    5-6. utm.net Null Setting" )
            _viewSql = """ UPDATE tb_monviewinstance SET monitorobject=null
                            WHERE serverseq=%s AND viewseq in (38, 39, 40, 41) """%str(self.OB_SEQ)
            _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
            if _ret == None :
                logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
            
            # 기존 utm.wan/office/server 제거(54~59)
            logger.info( "    5-7. Prev utm.wan/office/server Delete" )
            _viewSql = """ DELETE FROM tb_monviewinstance WHERE serverseq=%s AND viewseq in (54, 55, 56, 57, 58, 59) """%str(self.OB_SEQ)
            _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
            if _ret == None :
                logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
            
            # utm.wan, utm.office, utm.server 추가(54~59)
            # utm.off = 56, 57
            logger.info( "    5-8. New utm.office Insert, if=eth2" )
            for vSeq in (56, 57) :
                _viewSql = """ INSERT INTO tb_monviewinstance(serverseq, viewseq, monitorobject)
                                VALUES (%s, %s, 'eth2') """%(str(self.OB_SEQ), str(vSeq))
                _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
                if _ret == None :
                    logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
                    return _rest
            
            # utm.svr = 58, 59
            logger.info( "    5-9. New utm.server Insert, if=eth3" )
            for vSeq in (58, 59) :
                _viewSql = """ INSERT INTO tb_monviewinstance(serverseq, viewseq, monitorobject)
                                VALUES (%s, %s, 'eth3') """%(str(self.OB_SEQ), str(vSeq))
                _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
                if _ret == None :
                    logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
                    return _rest
            
            # utm.wan = 54, 55
            utmWanIf = ["eth1"]
            if len(wanIf) > 1 :
                for _i in range(1, len(wanIf)) :
                    utmWanIf.append("eth%s"%str(_i+4))
            
            logger.info( "    5-10. New utm.wan Insert, if=%s"%str(utmWanIf) )
            for vSeq in (54, 55) :
                for mObj in utmWanIf :
                    _viewSql = """ INSERT INTO tb_monviewinstance(serverseq, viewseq, monitorobject)
                                    VALUES (%s, %s, '%s') """%(str(self.OB_SEQ), str(vSeq), mObj)
                    _ret = psql(self.orchDBIP, _viewSql, False, None, self.RB_DB)
                    if _ret == None :
                        logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
                        return _rest
            
            # View DB Commit
            logger.info( "    5-11. View DB Commit" )
            self.RB_DB.commit()
            
            
            ## View Update
            logger.info( "  6. View ItemInstSeq Update" )
            refreshView(self.orchDBIP, self.OB_SEQ)
            
            
            ## Check View
            logger.info( "  7. Check View ItemInstSeq" )
            _viewSql = """ SELECT * FROM tb_monviewinstance vi WHERE vi.serverseq=%s AND vi.moniteminstanceseq not in (
                                 SELECT moniteminstanceseq FROM tb_moniteminstance ii
                                 WHERE ii.serverseq=%s AND ii.delete_dttm is null)"""%(str(self.OB_SEQ), str(self.OB_SEQ))
            _ret = psql(self.orchDBIP, _viewSql, True)
            if _ret == None :
                logger.error( "      [ERROR] DB Fail, sql=%s"%_viewSql )
            else:
                if len(_ret) == 0 :
                    logger.info( "    SC : UPdate View" )
                else:
                    for _dat in _ret :
                        logger.error( "    [ERROR] %s"%str(_dat) )
            
            ## OBA 재기동
            logger.info( "  8. OBAgt Restart" )
            _rest = 0
            _cmd = """ service onebox-agent restart """
            run(self.obIP, _cmd)
            
            _cmd = """ service onebox-agent status """
            _ret = run(self.obIP, _cmd)
            if str(_ret).strip().find("running") < 0 :
                logger.error( "    [ERROR] Fail to Restart OBAgt, cmd=%s"%_cmd )
                return _rest
            
            return 0
        except Exception, e:
            logger.error( "[ERROR] Fail to Update OB" )
            logger.exception( e )
            return _rest


if __name__ == '__main__':
    if len(sys.argv) >= 3:
        bn = Batch_Net(str(sys.argv[1]).strip(), str(sys.argv[2]).strip())
        bn.batch()
    else:
        print "wrong parameter, Orch-M IP, Orch-M DB IP"
#         faultType = str(sys.argv[1]).upper()
#         if str(faultType).upper() == 'CPU':
#             faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
#         elif str(faultType).upper() == 'UTM':
#             faultUTMNet(int(sys.argv[2]))



