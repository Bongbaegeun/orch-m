#!/usr/bin/python
#-*- coding: utf-8 -*-

from time import sleep
import time

class MsData(object):
    
    def __init__(self, tid, tName, fName):
        self.tid = tid
        self.tName = tName
        self.fName = fName
        self.initDic = {}
        self.prevDic = {}
        self.ifList = []
        self.notiUrl = None

    def setIfList(self, ifList ):
        self.ifList = ifList
        
    def setNotiUrl(self, url):
        self.notiUrl = url



TID = "20170731-001"
TNAME = "perf_chk"
FNAME = "./perf_chk.data"
DETAIL = "perf_chk"
IDX = "20170731"

PERIOD = 3

MS_DATA = MsData(TID, TNAME, FNAME)
MS_DATA.setIfList(["eth0", "tap0d990f3d-11", "tap4ef14e7c-69", "int-br-wan1"])
# MS_DATA.setIfList(["eth0", "eth1", "eth2", "eth3"])








def writeFile( fName, _data ):
    fileobj = open( fName, 'a+')
    
    data = str(_data)
    newLine = False
    if ( type(_data) == tuple ) or ( type(_data) == list ) :
        data = ''
        for dd in _data :
            if ( type(dd) == tuple ) or ( type(dd) == list ) :
                newLine = True
                for d in dd :
                    data += (str(d)+';')
                data += '\n'
            else:
                data += (str(dd)+';')
    
    fileobj.writelines(data)
    
    fileobj.flush()
    fileobj.close()



def runMS( _detail, _idx, msData, avgCalc=True ):
    
    with open("/proc/net/dev", "rt") as f:
        lines = f.readlines()
    currTs = time.time()
    
    readData = {}
    for line in lines[2:]:
        
        #face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed
        # eth0: 4903483   63392    0    0    0     0          0         0 14592970   66617    0    0    0     0       0          0     
        
        # interface 구분자(:)가 존재하는지 검사
        colon = line.rfind(':')         # -> 4
        assert colon > 0, repr(line)
        
        # interface 이름을 추출
        name    = line[:colon].strip()     # -> eth0
        if ( len(msData.ifList) != 0 ) and list(msData.ifList).count(name) == 0 :
            continue
        # interface 트래픽 정보 추출
        fields      = line[colon + 1:].strip().split()  # -> ['4903483', '63392', '0', '0', '0', '0', '0', '0', '14592970', '66617', '0', '0', '0', '0', '0', '0']
        
        # 트래픽 정보 분석
        
        bytes_recv  = int(fields[0])
        packets_recv= int(fields[1])
        errin       = int(fields[2])
        dropin      = int(fields[3])
        
        bytes_sent  = int(fields[8])
        packets_sent= int(fields[9])
        errout      = int(fields[10])
        dropout     = int(fields[11])
        
        readData[name] = (currTs, 
                         bytes_sent, bytes_recv, 
                         packets_sent, packets_recv,
                         errin, errout, 
                         dropin, dropout)
    
    # OVS 통계
    # CMD> ovs-vsctl find Interface status={}
    # CMD> ovs-vsctl find Interface status={}| grep statistics
    import linux_plugin as osPlugin
    ovsData = osPlugin.getOvsIfStats( msData.ifList, True )
    ovsData.update( readData )
    
    allData = ovsData
    statData = []
    
    for key in allData.keys():
        if not msData.initDic.has_key(key) :
            msData.initDic[key] = allData[key]
            msData.prevDic[key] = (0.0,0,0,0,0,0,0,0,0)
        else:
            initD = msData.initDic[key]
            currD = allData[key]
            
            ## 누적
            accTs = currD[0] - initD[0]
            accTxBytes = currD[1] - initD[1]
            accRxBytes = currD[2] - initD[2]
            accTxPkts = currD[3] - initD[3]
            accRxPkts = currD[4] - initD[4]
            accInErrs = currD[5] - initD[5]
            accOutErrs = currD[6] - initD[6]
            accInDrops = currD[7] - initD[7]
            accOutDrops = currD[8] - initD[8]
            
            ## 평균
            if msData.prevDic.has_key(key):
                
                if avgCalc :
                    prevD = msData.prevDic[key]
                    tsGap = accTs - prevD[0]
                    
                    txBps = round( (float(accTxBytes - prevD[1])/tsGap), 2)
                    rxBps = round( (float(accRxBytes - prevD[2])/tsGap), 2)
                    txPps = round( (float(accTxPkts - prevD[3])/tsGap), 2)
                    rxPps = round( (float(accRxPkts - prevD[4])/tsGap), 2)
                    interInErr = accInErrs - prevD[5]
                    interOutErr = accOutErrs - prevD[6]
                    interInDrops = accInDrops - prevD[7]
                    interOutDrops = accOutDrops - prevD[8]
                    
                    calcData = (_detail, _idx, key, currD[0], accTs, 
                                accTxBytes, accRxBytes, accTxPkts, accRxPkts,
                                accInErrs, accOutErrs, accInDrops, accOutDrops,
                                txBps, rxBps, txPps, rxPps,
                                interInErr, interOutErr, interInDrops, interOutDrops)
                else:
                    calcData = (_detail, _idx, key, currD[0], accTs, 
                                accTxBytes, accRxBytes, accTxPkts, accRxPkts,
                                accInErrs, accOutErrs, accInDrops, accOutDrops)
#                 if key =='qvbb49cb0f8-22':
#                     print initD
#                     print currD
#                     print prevD
#                     print calcData
                statData.append( calcData )
                
            ## 이전 값 교체
            msData.prevDic[key] = (accTs, 
                                   accTxBytes, accRxBytes,
                                   accTxPkts, accRxPkts,
                                   accInErrs, accOutErrs,
                                   accInDrops, accOutDrops)
    
    writeFile(msData.fName, statData)
    
    return


if __name__ == '__main__':
    
    while True:
        runMS(DETAIL, IDX, MS_DATA)
        sleep(PERIOD)
    

