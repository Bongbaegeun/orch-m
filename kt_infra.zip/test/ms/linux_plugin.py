#-*- coding: utf-8 -*-

import subprocess, platform

def exec_cmd(cmd, inputtext=None):
    
    if platform.system() == 'Windows':
        proc = subprocess.Popen(cmd,
            stdin=subprocess.PIPE, \
            stdout=subprocess.PIPE, \
            stderr=subprocess.PIPE, \
            shell=True)
    else:  
        proc = subprocess.Popen(cmd,
            stdin=subprocess.PIPE, \
            stdout=subprocess.PIPE, \
            stderr=subprocess.PIPE, \
            shell=True, \
            close_fds=True)
        
    (response, error) = proc.communicate(inputtext)            
    if error != '':
        raise RuntimeError("[%s] command Error \n[%s]" % (cmd, error))
    else:
        return response.strip()


def getLinkList():
    cmd = "ls /sys/class/net/ 2>/dev/null | awk '{print $0}'"
    ret = exec_cmd(cmd)
    if ret != None and ret != '':
        return ret.strip().split('\n')
    else:
        return []

def getPhyIfaceList():
    cmd = "ls /sys/class/net -l 2>/dev/null | grep -v '/devices/virtual/' | grep 'net' | awk '{print $9}'"
    ret = exec_cmd(cmd)
    if ret != None and ret != '':
        return ret.strip().split('\n')
    else:
        return []


def getOvsBrList():
    cmd = "ovs-vsctl list-br 2>/dev/null"
    ret = exec_cmd(cmd)
    if ret != None and ret != '':
        return ret.strip().split('\n')
    else:
        return []

def getOvsBrIf( ovsBr ):
    cmd = "ovs-vsctl list-ports %s 2>/dev/null"%ovsBr
    ret = exec_cmd(cmd)
    if ret != None and ret != '':
        return ret.strip().split('\n')
    else:
        return []

def getOvsIfList(_vmIfIdList):
    vmIfIdList = []
    if type(_vmIfIdList) == str :
        vmIfIdList.append(_vmIfIdList)
    else:
        vmIfIdList = _vmIfIdList
    
    vmOvsIfList = []
    for vmIfId in vmIfIdList :
        cmd = "ls /sys/class/net 2>/dev/null | grep %s"%str(vmIfId)
        ret = exec_cmd(cmd)
        if ret != None and ret != '':
            vmOvsIfList += ret.strip().split('\n')
    return vmOvsIfList


def getOvsBrInfoList():
    ovsBrInfoList = {}    
    ovsBrList = getOvsBrList()
    for ovsBr in ovsBrList :
        ovsBrIfList = getOvsBrIf(ovsBr)
        ovsBrInfoList[ovsBr] = ovsBrIfList
    
    return ovsBrInfoList

def getOvsLinkInfoList():
    linkList = {}
    
    cmd = "ovs-vsctl find Interface option!={} 2>/dev/null | grep name | awk '{print $3}'"
    ret = exec_cmd(cmd)
    if ret == None or ret == '':
        return {}    
    ifNames = ret.strip().split('\n')
    
    doneList = []
    for _ifName in ifNames:
        ifName = str(_ifName).replace('"', '')
        if doneList.count(ifName) == 0 :
            _cmd = "ovs-vsctl get Interface %s option 2>/dev/null"%str(ifName)
            _ret = exec_cmd(_cmd)
            if _ret != None and _ret != '':
                peer = str(_ret).strip().replace('{peer=', '').replace('}', '')
                if peer != None and peer != '':
                    peer = str(peer).replace('"', '')
                    doneList.append(peer)
                    linkList[ifName] = peer
    
    return linkList

def getOvsIfStats( ovsIfList=None, onlyOvsLink=True ):
    ovsIfStat = {}    
    # CMD> ovs-vsctl find Interface status={}
    # CMD> ovs-vsctl find Interface status={}| grep statistics
    cmd = "ovs-vsctl find Interface status={} 2>/dev/null | grep '^name' | awk '{print $3}' "
    ret = exec_cmd(cmd)
    if ret == None or ret == '':
        return ovsIfStat
    
    ifList = []
    for line in ret.strip().split('\n') :
        _ifName = str(line).strip()
        _ifName = _ifName.replace('"', '')
        if _ifName == None or _ifName == '':
            continue
        ifList.append( _ifName )
    ifList = list(set(ifList))
    
    _ifList = []
    if ovsIfList != None :
        for _tmpIf in ifList :
            if list(ovsIfList).count( _tmpIf ) > 0 :
                _ifList.append(_tmpIf)
        ifList = _ifList
    
#     readData[name] = (currTs, 
#                      bytes_sent, bytes_recv, 
#                      packets_sent, packets_recv,
#                      errin, errout, 
#                      dropin, dropout)
    import time
    for ifName in ifList :
        cmd = "ovs-vsctl find Interface name=%s, status={} 2>/dev/null | grep statistics"%str(ifName)
        ret = exec_cmd(cmd)
        currTs = time.time()
        if ret == None or ret == '':
            continue
        
        ifStat = [currTs, 0, 0, 0, 0, 0, 0, 0, 0]
        for line in ret.strip().split('\n'):
            if line == None or line == '' :
                continue
            sIdx = str(line).find('{') + 1
            dIdx = str(line).find('}')
            if sIdx >= dIdx :
                continue
            
            stats = str(line)[sIdx:dIdx].split(',')
            for _stat in stats :
                stat = str(_stat).strip()
                if str(stat).count( 'tx_bytes=' ) > 0 :
                    ifStat[1] = int(stat.replace('tx_bytes=', ''))
                elif str(stat).count( 'rx_bytes=' ) > 0 :
                    ifStat[2] = int(stat.replace('rx_bytes=', ''))
                elif str(stat).count( 'tx_packets=' ) > 0 :
                    ifStat[3] = int(stat.replace('tx_packets=', ''))
                elif str(stat).count( 'rx_packets=' ) > 0 :
                    ifStat[4] = int(stat.replace('rx_packets=', ''))
                elif str(stat).count( 'rx_errors=' ) > 0 :
                    ifStat[5] = int(stat.replace('rx_errors=', ''))
                elif str(stat).count( 'tx_errors=' ) > 0 :
                    ifStat[6] = int(stat.replace('tx_errors=', ''))
                elif str(stat).count( 'rx_dropped=' ) > 0 :
                    ifStat[7] = int(stat.replace('rx_dropped=', ''))
                elif str(stat).count( 'tx_dropped=' ) > 0 :
                    ifStat[8] = int(stat.replace('tx_dropped=', ''))
            
        ovsIfStat[ifName] = tuple(ifStat)
    
    return ovsIfStat



def getLxBrList():
    cmd = "brctl show 2>/dev/null | grep -v '^\s' | grep -v 'bridge name' | awk '{print $1}'"
    ret = exec_cmd(cmd)
    if ret != None and ret != '':
        return ret.strip().split('\n')
    else:
        return []

def getLxBrIf( lxBr ):
    brIfList = []
    
    cmd = "brctl show %s 2>/dev/null | grep %s | awk '{print $4}'"%(str(lxBr), str(lxBr))
    ret = exec_cmd(cmd)
    if ret != None and ret != '':
        brIfList.append(ret)
    
    cmd = "brctl show %s 2>/dev/null | grep '^\s' | awk '{print $1}'"%str(lxBr)
    ret = exec_cmd(cmd)
    if ret != None and ret != '':
        brIfList += ret.strip().split('\n')
    
    return brIfList

def getLxBrInfoList():
    lxBrInfoList = {}    
    lxBrList = getLxBrList()
    for lxBr in lxBrList :
        lxBrIfList = getLxBrIf(lxBr)
        lxBrInfoList[lxBr] = lxBrIfList
    
    return lxBrInfoList

def getLxLinkInfoList():
    linkList = {}    
    ifList = []
    lxBrList = getLxBrList()
    for lxBr in lxBrList :
        ifList += getLxBrIf(lxBr)
    
    doneList = []
    for ifName in ifList :
        if doneList.count(ifName) == 0:
            cmd1 = "ethtool -S %s 2>/dev/null | grep peer | awk '{print $2}'"%str(ifName)
            ret1 = exec_cmd(cmd1)
            if ret1 == None or ret1 == '':
                continue
            
            cmd2 = "ip link show 2>/dev/null | grep '^%s:' | awk '{print $2}'"%str(ret1)
            ret2 = exec_cmd(cmd2)
            if ret2 == None or ret2 == '':
                continue
            
            peer = ret2.replace(':', '').strip()
            if peer == None or peer == '' :
                continue
            
            doneList.append( peer )
            linkList[ifName] = peer
    
    return linkList

def getVmIfaceList(vmInfoList):
    vmIfList = {}
    
    from xml.etree import ElementTree
    for vmInfo in vmInfoList :
        vmTapList = []
        vmName = vmInfo[0]
        vmId = vmInfo[1]
        
        tree = ElementTree.parse( '/var/lib/nova/instances/%s/libvirt.xml'%str(vmId) )
        note = tree.getroot()
        dev = note.find('devices')
        ifList = dev.findall('interface')
        for ifInfo in ifList :
            ifTarget = ifInfo.find('target')
            ifTap = ifTarget.get('dev')
            vmTapList.append(ifTap)
        vmIfList[vmName]=vmTapList
    
    return vmIfList


def getRecentFile( fDir, fPattern ):
    cmd = "find %s -name '%s' -type f -mmin -1 -exec ls -t {} + 2>/dev/null | head -n 1 "%(str(fDir), str(fPattern))
    ret = exec_cmd(cmd)
    if ret != None and ret != '':
        return ret
    
    return None

def getLastLine( fName ):
    cmd = "tail -n 10 %s | grep -v '^$\|@@' | tail -n 1"%str(fName)
    ret = exec_cmd(cmd)
    if ret != None and ret != '':
        return str(ret)
    
    return None

def readData( fName, tDetail, tIdx ):
    cmd = "cat %s | grep '^%s;%s\|^@@.*%s'"%(str(fName), str(tDetail), str(tIdx), str(tDetail))
    ret = exec_cmd(cmd)
    if ret != None and ret != '':
        return ret.strip().split('\n')
    
    return None

# def readAllData( fName, tDetail, stime=None, etime=None ):
#     cmd = "cat %s | grep -v '^$\|@@' "%str(fName)
#     if tDetail != None :
#         cmd += " | grep '^%s'"%str(tDetail)
#     ret = exec_cmd(cmd)
#     if ret != None and ret != '':
#         return ret.strip().split('\n')
#     
#     return None

