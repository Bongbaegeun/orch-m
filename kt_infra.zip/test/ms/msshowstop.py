#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

URL = "http://211.224.204.213:7373/ms/show/stop"

def callZB( url, reqBody ):
    
    http_client = httpclient.HTTPClient()
    h = HTTPHeaders(HEADER)
    strBody = json.dumps( reqBody )
    _request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
    
    response = http_client.fetch( request=_request )
    http_client.close()
    
    resp = json.loads(response.body)
    
    return resp


def test(name):
    url = URL
    test = {'tid':1, 'noti_url':'http://211.224.204.134:7979/ms/noti'}
    print( callZB( url, test ) )


if __name__ == '__main__':
    if len(sys.argv) >= 2:
        test(sys.argv[1])
#     else:
#         print 'USAGE: CMD [D/S/P] '
#     if len(sys.argv) >= 3:
#         faultType = str(sys.argv[1]).upper()
#         if str(faultType).upper() == 'CPU':
#             faultOsCPU(int(sys.argv[2]), int(sys.argv[3]))
#         elif str(faultType).upper() == 'UTM':
#             faultUTMNet(int(sys.argv[2]))


