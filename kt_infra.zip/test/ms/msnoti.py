#!/usr/bin/python
#-*- coding: utf-8 -*-


import sys, yaml, threading, logging, json
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from tornado.web import Application
from tornado.web import RequestHandler
from time import sleep



class MsHandler(RequestHandler):
    
    def post(self):
        reqdata = self.request.body
        self.src = self.request.remote_ip
        
        req = json.loads(self.request.body)
        if req.has_key('data'):
            for data in req['data'] :
                print data
                
        self.write({'result':'SC'})
        self.flush()

class httpSvrThread(threading.Thread):
    """
    - FUNC: Rest API 생성 클래스
    - INPUT
        applictions(M): URL, 처리 Handler, 인자 정의 객체
        port(M): API 용 포트
        proc(M): API 처리 프로세스 개수
    """
    def __init__(self, applictions, port, proc):
        threading.Thread.__init__(self)
        self.svr = HTTPServer(applictions)
        self.svr.bind(port)
        self.svr.start(proc)
    
    def run(self):
        IOLoop.current().start()

def makeApp(  ):
    """
    - FUNC: URL, Handler, 인자 설정 객체 생성
    - INPUT
        _cfg(M): 설정 정보 객체
    - OUTPUT : Application 객체
    """
    app = Application( [('/ms/noti', MsHandler)] )
    
    return app



def startAPI( app, cfg ):
    """
    - FUNC: API 쓰레드 시작
    - INPUT
        app(M): Application 객체
        cfg(M): 설정 정보 객체
    """
    svr = httpSvrThread(app, cfg['port'], cfg['procNum'])
    svr.start()



def start( ):
    cfg = {'port':7979, 'procNum':1}
    app = makeApp( )
    startAPI( app, cfg )


def main(  ):
    start(  )
    

if __name__ == '__main__':
    main()

