P_NAME='msnoti.py'

python $P_NAME $* &

