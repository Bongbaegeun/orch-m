P_NAME='msnoti.py'

ps -ef | grep python | grep -v "grep" | grep "$P_NAME"


