#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from _codecs import ascii_encode

ZBMS_URL="http://211.224.204.203:8080"
HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

def callZB( url, reqBody, hasBuffer=False ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=5 )
	
	response = http_client.fetch( request=request )
	http_client.close()
	
	if hasBuffer: 
		return response
	else: 
		body = json.loads(response.body)
		return body
	

def test( cfg ):
	with open(cfg, "r") as f:
		cfgf = json.load(f)
	
	url = ZBMS_URL + cfgf['url']
	reqBody = cfgf['body']
	hasBuffer = cfgf.has_key('has_buffer')
	print "--->url=%s,\n--->body=%s,\n--->hasBuffer=%s"%(str(url), str(reqBody), str(hasBuffer))
	print callZB(url, reqBody, hasBuffer)

if __name__ == '__main__':
	if len(sys.argv) >= 2:
		cfgName = sys.argv[1]
		test(cfgName)


