#!/usr/bin/python

import zb_api

def showJson(msg):
    if type(msg)==dict:
        zb_api.analResult(msg)
    else :
        print msg


def printLog(msg):
    print msg

