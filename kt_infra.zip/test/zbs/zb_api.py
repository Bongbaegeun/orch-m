#!/usr/bin/python

import json
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest

ZBS_URL="http://211.224.204.250/zabbix/api_jsonrpc.php"
HEADER={"content-type":"application/json-rpc"}
METHOD="POST"

def callZB( reqBody ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	strBody = json.dumps( reqBody )
	request = HTTPRequest( ZBS_URL, headers=h, method=METHOD.upper(), body=strBody, request_timeout=1 )
	
	response = http_client.fetch( request=request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def isSucc( ret ):
	if ret.has_key("result"):
		return True
	else :
		return False	
	


def analResult( res ):
	if res.has_key("result") : 
		print "SUCCESS"
		print( json.dumps(res, indent=2) )
	elif res.has_key("error") :
		print "!!!ERROR"
		print "Reason: "+ res["error"]["message"]
		print "Descript: "+ res["error"]["data"]
	else :
		print "Invalid Result Msg"
	
TEST={"jsonrpc":"2.0","method":"apiinfo.version","id":1,"auth":"","params":{}}
GET_TEMP={"id":"1","method":"template.get","params":{"output":"extend","filter":{"host":["230"]}},"jsonrpc":"2.0","auth":"12b3e702c3a6ce1a9be92a32f2405b98"}

if __name__ == '__main__':
	print( callZB(  ) )
