#!/usr/bin/python

import zb_api
from util import showJson, printLog
#from mediatype_handler import getID as getMediaTypeID

import json
from getpass import getuser

def login( name, passwd, userData=False, tid=1 ):
    printLog("Login")
    reqBody = {"jsonrpc": "2.0", "method": "user.login", "id": tid,
               "params": {
                          "user": name,
                          "password": passwd
                          }
               }
    if userData :
        reqBody["params"]["userData"] = "true"
    
    return zb_api.callZB(reqBody)


def getAuth( name, passwd, tid=1 ):
    printLog("Auth")
    resMsg = login( name, passwd, False, tid )
    
    return resMsg["result"]


def getGroup(auth, name, tid=1):
    printLog("getGroup")
    reqBody = {"jsonrpc": "2.0", "method": "usergroup.get", "auth": auth, "id": tid,
               "params": {
                          "filter": {"name":name}
                          }
               }
    
    return zb_api.callZB(reqBody)


def getGroupID(auth, name, tid=1):
    printLog("getGroupID")
    ret = getGroup(auth, name, tid)
    print ret
    if zb_api.isSucc(ret):
        return ret["result"][0]["usrgrpid"] 
    else:
        return None


def create( auth, name, passwd, usrgrp, auto_login=1, user_medias=None, tid=1 ):
    printLog("create")
    
    gid = getGroupID(auth, usrgrp, tid)
    
    reqBody = {"jsonrpc": "2.0", "method": "user.create", "auth": auth, "id": tid,
               "params": {
                          "alias": name,
                          "passwd": passwd,
                          "usrgrps": [{"usrgrpid":str(gid)}],
                          "autologin": auto_login
                          }
               }
    if user_medias != None :
        reqBody["params"]["user_medias"] = user_medias
    
    return zb_api.callZB(reqBody)


def get( auth, name, tid=1 ):
    printLog("get")
    reqBody = {"jsonrpc": "2.0", "method": "user.get", "auth": auth, "id": tid,
               "params": {
                          "filter": {"alias":name}
                          }
               }
    
    return zb_api.callZB(reqBody)


def getID( auth, name, tid=1 ):
    printLog("getID")
    ret = get( auth, name, tid )
    if zb_api.isSucc( ret ) :
        return ret["result"][0]["userid"]
    else:
        return None


def delete( auth, name, tid=1 ):
    printLog("delete")
    id = getID( auth, name, tid )
    reqBody = {"jsonrpc": "2.0", "method": "user.delete", "auth": auth, "id": tid,
               "params": [id]
               }
    
    return zb_api.callZB(reqBody)


def update( name, passwd, usrgrps ):
    printLog("update")
    #TBD
    return None


#0 - (default) not classified; 
#1 - information; 
#2 - warning; 
#3 - average; 
#4 - high; 
#5 - disaster.
# duplicated
def addMedia( auth, uid, mTypeName, serverity, sendTo="ORCH-M", tid=1 ):
    printLog("addMedia")
    mTypeID = getMediaTypeID(auth, mTypeName, tid)
    reqBody = {"jsonrpc": "2.0", "method": "user.addmedia", "auth": auth, "id": tid,
               "params": {
                          "users": [{"userid": uid}],
                          "medias": {
                                     "mediatypeid": mTypeID,
                                     "sendto": sendTo,
                                     "active": 0,
                                     "severity": serverity,
                                     "period": "1-7,00:00-24:00"
                                     }
                          }
               }
    
    return zb_api.callZB(reqBody)


def getMedia( auth, uid, tid=1 ):
    printLog("getMedia")
    reqBody = {"jsonrpc": "2.0", "method": "usermedia.get", "auth": auth, "id": tid,
               "params": {
#                           "filter": {"description":mTypeName},
                            "output": "extend",
                            "userids": uid
                          }
               }

    return zb_api.callZB(reqBody)


def getMediaID( auth, uid, tid=1 ):
    printLog("getMedia")
    ret = getMedia(auth, uid, tid)
    if zb_api.isSucc(ret):
        return ret["result"][0]["mediaid"]
    else:
        return None
    

def deleteMedia( auth, uid, mTypeName, tid=1 ):
    printLog("delMedia")
    mid = getMediaID(auth, uid)
    reqBody = {"jsonrpc": "2.0", "method": "user.deletemedia", "auth": auth, "id": tid,
               "params": [ mid ]
               }
    
    return zb_api.callZB(reqBody)



if __name__ == '__main__':
    #showJson( login( "Admin", "zabbix" ) )
    #showJson( login( "Admin", "zabbix", True ) )
    auth = getAuth( "Admin", "zabbix")
    #showJson( create( auth, "test2", "zabbix","Zabbix administrators" ) )
    #showJson( get(auth,"test2") )
#     showJson( delete(auth,"test2") )
#     showJson(getGroupID(auth, ["Zabbix administrators"]))
#     showJson( getMediaTypeID(auth, "test-script") )
    uid = getID(auth, "test2")
#     auth = getAuth( "test2", "zabbix")
#     showJson( addMedia(auth, uid, "test-script", 4) )
#     showJson( deleteMedia(auth, uid, "test-script") )
    
    


