#!/usr/bin/python

import zb_api
from util import showJson, printLog
import user_handler



def get( auth, name, tid=1 ):
    printLog("get")
#    reqBody = {"jsonrpc": "2.0", "method": "template.get", "auth": auth, "id": tid,
#               "params": {
#                          "output": "extend",
#                          "filter": {"host":["230"]}
#                          }
#               }
    reqBody = {"id":"1","method":"template.get","params":{"output":"extend","filter":{"host":["230"]}},"jsonrpc":"2.0","auth":auth}
    return zb_api.callZB(reqBody)


def getID( auth, name, tid=1 ):
    printLog("getID")
    ret = get(auth, name, tid)
    if zb_api.isSucc(ret):
        return ret["result"][0]["templateid"]
    else:
        return None


def create( auth, name, groups, hostName=None, tid=1 ):
    printLog("create")
    reqBody = {"jsonrpc": "2.0", "method": "template.create", "auth": auth, "id": tid,
               "params": {
                          "name": name
                          }
               }
    if hostName == None:
        reqBody["params"]["host"] = name
    else:
        reqBody["params"]["host"] = hostName
    if type(groups) == list:
        reqBody["params"]["groups"] = groups
    else:
        reqBody["params"]["groups"] = { "groupid": int(groups) }
    
    return zb_api.callZB(reqBody)


def createByGroupName( auth, name, gName, hostName=None, tid=1 ):
    printLog("createByGroupName")
    gid = host_handler.getGroupID( auth, gName, tid)
    
    return create( auth, name, gid, hostName, tid)


def delete( auth, id, tid=1 ):
    printLog("delete")
    reqBody = {"jsonrpc": "2.0", "method": "template.delete", "auth": auth, "id": tid,
               "params": [id]
               }
    
    return zb_api.callZB(reqBody)


def deleteByName( auth, name, tid=1 ):
    printLog("deleteByName")
    id = getID(auth, name, tid)
    
    return delete(auth, id, tid)


if __name__ == '__main__':
    auth = user_handler.getAuth( "Admin", "zabbix" )
#     showJson( get(auth, "Template App Openstack" ) )
#     showJson( getID(auth, "Template App Openstack" ) )
#     showJson( createByGroupName(auth, "test-temp1", "Templates") )
    showJson( get(auth, "230" ) )
#     showJson( deleteByName(auth, "test-temp1" ) )

