#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from datetime import datetime

HEADER = {"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"}
METHOD="POST"

URL = "http://:9099/sdi/sdn/nfv"


def callZB( url, reqBody=None ):
	
	http_client = httpclient.HTTPClient()
	h = HTTPHeaders(HEADER)
	if reqBody == None:
		strBody = None
	elif type(reqBody) == str:
		strBody = reqBody
	else:
		strBody = json.dumps( reqBody )
	_request = HTTPRequest( url, headers=h, method=METHOD.upper(), body=strBody, request_timeout=10 )
	
	response = http_client.fetch( request=_request )
	http_client.close()
	
	resp = json.loads(response.body)
	
	return resp


def notiAlarm(customer, nfv_id):
	
	test = {
		"customer" : customer,
		"nfv_id" : int(nfv_id),
		"onebox" :{ "status" : "off" }
		}
	
	print( callZB( url, test ) )


if __name__ == '__main__':
	if len(sys.argv) >= 3:
		notiAlarm(sys.argv[1], sys.argv[2])
	else:
		print 'USAGE: CMD CUSTOMER_NAME NFV_ID'


