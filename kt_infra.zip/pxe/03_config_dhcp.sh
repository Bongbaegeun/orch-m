#!/bin/bash

source pxe.cfg

config_dhcp_svr() {
	echo "INTERFACES=\"${IF_NAME}\"" > /etc/default/dhcp3-server
}

config_dhcp_d() {
	cp /etc/dhcp/dhcpd.conf /etc/dhcp/dhcpd.conf.bak
	echo "subnet ${IF_SUBNET} netmask ${IF_NETMASK} {
range ${IF_DHCP_START} ${IF_DHCP_END};
option subnet-mask ${IF_NETMASK};
option routers ${IF_IP};
option broadcast-address 10.0.1.255;
filename \"pxelinux.0\";
next-Server ${IF_IP};
}" >> /etc/dhcp/dhcpd.conf
}

start_dhcp() {
	service  isc-dhcp-server restart
}

config_dhcp_svr
config_dhcp_d
start_dhcp


