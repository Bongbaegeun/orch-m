#!/bin/bash

config_nfv() {
	echo "/var/lib/tftpboot/Ubuntu/14.04/amd64 *(ro,async,no_root_squash,no_subtree_check)" >> /etc/exports
}

start_nfv() {
	exportfs -a
	service nfs-kernel-server restart
}

config_nfv
start_nfv

