#!/bin/bash

source pxe.cfg

### network setting

#-- interfaces
# This file describes the network interfaces available on your system
# and how to activate them. For more information, see interfaces(5).

# The loopback network interface
auto lo
iface lo inet loopback

source interfaces.d/*.cfg

#-- em2.cfg
auto ${IF_NAME}
iface ${IF_NAME} inet static
address ${IF_IP}
netmask ${IF_NETMASK}


service networking restart

