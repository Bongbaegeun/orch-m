#!/bin/bash

apt-get update
apt-get install -y isc-dhcp-Server inetutils-inetd tftpd-hpa syslinux nfs-kernel-Server

