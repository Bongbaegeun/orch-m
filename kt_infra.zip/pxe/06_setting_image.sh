#!/bin/bash

mount -o loop ./image/ubuntu-14.04.4-server-amd64.iso /media/
cp -r /media/* /var/lib/tftpboot/Ubuntu/14.04/amd64/
cp -r /media/.disk /var/lib/tftpboot/Ubuntu/14.04/amd64/
cp /media/install/initrd.gz /media/install/vmlinuz /var/lib/tftpboot/Ubuntu/

