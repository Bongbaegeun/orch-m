#!/bin/bash

config_inetd() {
	echo "tftp dgram udp wait root /usr/sbin/in.tftpd /usr/sbin/in.tftpd -s /var/lib/tftpboot" >> /etc/inetd.conf
}

config_tftpd() {
	cp /etc/default/tftpd-hpa /etc/default/tftpd-hpa.bak
	echo "TFTP_USERNAME=\"tftp\"
TFTP_DIRECTORY=\"/var/lib/tftpboot\"
TFTP_ADDRESS=\"[::]:69\"
TFTP_OPTIONS=\"--secure\"
RUN_DAEMON=\"yes\"
OPTIONS=\"-l -s /var/lib/tftpboot\"" > /etc/default/tftpd-hpa
}

auto_start() {
	update-inetd --enable BOOT
	service tftpd-hpa restart
}

check_status() {
	netstat -lu | grep "tftp"
}

#config_inetd
#config_tftpd
#auto_start
check_status


