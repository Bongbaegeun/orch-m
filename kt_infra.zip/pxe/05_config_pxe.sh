#!/bin/bash

source pxe.cfg

make_dir() {
	mkdir -p /var/lib/tftpboot
	mkdir -p /var/lib/tftpboot/pxelinux.cfg
	mkdir -p /var/lib/tftpboot/Ubuntu/14.04/amd64/
	cp /usr/lib/syslinux/vesamenu.c32 /var/lib/tftpboot/
	cp /usr/lib/syslinux/pxelinux.0 /var/lib/tftpboot/
}

config_pxelinux() {
	echo "DEFAULT vesamenu.c32
TIMEOUT 100
PROMPT 0
MENU INCLUDE pxelinux.cfg/PXE.conf
NOESCAPE 1
LABEL Try Ubuntu 14.04 Server
MENU LABEL Try Ubuntu 14.04 Server
kernel Ubuntu/vmlinuz
append boot=casper netboot=nfs nfsroot=${IF_IP}:/var/lib/tftpboot/Ubuntu/14.04/amd64
initrd=Ubuntu/initrd.lz quiet splash
ENDTEXT
LABEL Install Ubuntu 14.04 Server
MENU LABEL Install Ubuntu 14.04 Server
kernel Ubuntu/vmlinuz
append boot=casper automatic-ubiquity netboot=nfs nfsroot=${IF_IP}:/var/lib/tftpboot/Ubuntu/14.04/amd64
initrd=Ubuntu/initrd.lz quiet splash
ENDTEXT" > /var/lib/tftpboot/pxelinux.cfg/default
}

config_pxe() {
	echo "MENU TITLE PXE Server
NOESCAPE 1
ALLOWOPTIONS 1
PROMPT 0
MENU WIDTH 80
MENU ROWS 14
MENU TABMSGROW 24
MENU MARGIN 10
MENU COLOR border 30;44 #ffffffff #00000000 std" > /var/lib/tftpboot/pxelinux.cfg/pxe.conf
}

make_dir
config_pxelinux
config_pxe

