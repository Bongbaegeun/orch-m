package.path = package.path ..";?.lua;test/?.lua;app/?.lua;"

printf("Lua Version      : %s\n", pktgen.info.Lua_Version);
printf("Pktgen Version   : %s\n", pktgen.info.Pktgen_Version);
printf("Pktgen Copyright : %s\n", pktgen.info.Pktgen_Copyright);
printf("Pktgen Authors   : %s\n", pktgen.info.Pktgen_Authors);

printf("\nHello World!!!!\nStart Test!!!!!\n");

DEBUG = false;

--pktSizes = { 64, 128, 256, 512, 1024, 1518 };
pktSizes = {1024};
lossLevs = { 0.0 };
interLossCri = 0.2;

chkRepeat = 1;
passCri = 0.6;
lossCri = 0.5;
period = 21;
chkPeriod = 5;
pktByte = 512;
bpsRate = 53;
resultWait = 0.05;

envFile = "ohhara/ops-vari.txt"
--envFile = "ohhara/nsa3130.txt"
--envFile = "ohhara/nsa3130-osp.txt"
--envFile = "ohhara/nsa5150.txt"
--envFile = "ohhara/nsa5150-osp.txt"
--envFile = "ohhara/nsa3130-mf2.txt"

rateFile = "ohhara/data/rate_"..pktByte.."byte_"..bpsRate.."ratePerc_"..lossCri.."loss.txt";
lossFile = "ohhara/data/loss_"..pktByte.."byte_"..bpsRate.."ratePerc_"..lossCri.."loss.txt";

--file1:write("p1.rxbps;p1.txbps;p3.rxbps;p3.txbps;p1.rxpkt;p1.txpkt;p3.rxpkt;p3.txpkt");

local function writeFile(fileName, txt)
  local ffile1 = io.open(fileName, "a+");
  ffile1:write(txt);
  ffile1:close();
end


local function writeRate()
  --prints("portstat", pktgen.portStats("1,3", "port"));
  local portRate = pktgen.portStats("1,3", "rate");
  local port1_rxbps = portRate[1].mbits_rx;
  local port1_txbps = portRate[1].mbits_tx;
  local port3_rxbps = portRate[3].mbits_rx;
  local port3_txbps = portRate[3].mbits_tx;
  
  local port1_rxpkt = portRate[1].pkts_rx;
  local port1_txpkt = portRate[1].pkts_tx;
  local port3_rxpkt = portRate[3].pkts_rx;
  local port3_txpkt = portRate[3].pkts_tx;
  
  local portStat = pktgen.portStats("1,3", "port");
  local port1_rxbyte = portStat[1].ibytes;
  local port1_txbyte = portStat[1].obytes;
  local port3_rxbyte = portStat[3].ibytes;
  local port3_txbyte = portStat[3].obytes;

  local port1_rxpkts = portStat[1].ipackets;
  local port1_txpkts = portStat[1].opackets;
  local port3_rxpkts = portStat[3].ipackets;
  local port3_txpkts = portStat[3].opackets;
  
  local file1=io.open(rateFile, "a+");
  file1:write(port1_rxbps..";"..port1_txbps..";"..port3_rxbps..";"..port3_txbps);
  file1:write(";"..port1_rxpkt..";"..port1_txpkt..";"..port3_rxpkt..";"..port3_txpkt);
  file1:write(";"..port1_rxbyte..";"..port1_txbyte..";"..port3_rxbyte..";"..port3_txbyte);
  file1:write(";"..port1_rxpkts..";"..port1_txpkts..";"..port3_rxpkts..";"..port3_txpkts);
  file1:write("\n");
  file1:close();
end




init_p1_rxpkt = 0;
init_p1_txpkt = 0;
init_p3_rxpkt = 0;
init_p3_txpkt = 0;

local function writeLoss(p1_rxp, p1_txp, p3_rxp, p3_txp)

  local portStat = pktgen.portStats("1,3", "port");
  local p1_rxpkt = portStat[1].ipackets;
  local p1_txpkt = portStat[1].opackets;
  local p3_rxpkt = portStat[3].ipackets;
  local p3_txpkt = portStat[3].opackets;
  
  local p1_tx = math.abs(p1_txpkt - p1_txp);
  local p3_tx = math.abs(p3_txpkt - p3_txp);
  local p1_rx = math.abs(p1_rxpkt - p1_rxp);
  local p3_rx = math.abs(p3_rxpkt - p3_rxp);

  local p1_loss = 0
  local p3_loss = 0
  if ( p1_tx ~= 0 ) then
    p1_loss = math.abs(p1_tx-p3_rx)/p1_tx*100;
  end
  if ( p3_tx ~= 0 ) then
    p3_loss = math.abs(p3_tx-p1_rx)/p3_tx*100;
  end

  writeFile(lossFile, p1_loss..";"..p3_loss.."\n");
  --file2=io.open(lossFile, "a+");
  --file2:write(p1_loss..";"..p3_loss.."\n");
  --file2:close();
  
  init_p1_rxpkt = p1_rxpkt;
  init_p1_txpkt = p1_txpkt;
  init_p3_rxpkt = p3_rxpkt;
  init_p3_txpkt = p3_txpkt;

  print("loss rate   p1: "..p1_loss..", p3: "..p3_loss);
  writeFile(lossFile, "loss rate   p1: "..p1_loss..", p3: "..p3_loss.."\n");
  if ( (p1_loss > passCri) or (p3_loss > passCri) ) then
    return 1;
  else
    return 0;
  end
  
end


local function doTest(idx)
  
  local initFile1 = io.open(rateFile, "a+");
  local initFile2 = io.open(lossFile, "a+");
  initFile1:write("---loss cri="..lossCri..", rate="..bpsRate..", duration="..period..", idx="..idx.."------\n");
  initFile2:write("---loss cri="..lossCri..", rate="..bpsRate..", duration="..period..", idx="..idx.."------\n");
  initFile1:close();
  initFile2:close();
  
  print("---loss cri="..lossCri..", rate="..bpsRate..", duration="..period..", idx="..idx.."------\n");

  pktgen.pkt_size("all", "start", pktByte+4); 
  pktgen.set("all", "rate", bpsRate);
  pktgen.set("all", "size", pktByte+4);
  
  pktgen.ping4("1,3");
  pktgen.delay( 1.5*1000 );

  pktgen.clr();
  local portStat = pktgen.portStats("1,3", "port");
  init_p1_rxpkt = portStat[1].ipackets;
  fir_p1_rxpkt = init_p1_rxpkt;
  init_p1_txpkt = portStat[1].opackets;
  fir_p1_txpkt = init_p1_txpkt;
  init_p3_rxpkt = portStat[3].ipackets;
  fir_p3_rxpkt = init_p3_rxpkt;
  init_p3_txpkt = portStat[3].opackets;
  fir_p3_txpkt = init_p3_txpkt;
  local ret = 0;
   
  pktgen.start("1,3");
  for i=1, period+1, 1
  do
    pktgen.delay(1 * 1000);
    writeRate();
    chk = i%chkPeriod;
    if ( chk == 0 ) then
      ret = writeLoss(init_p1_rxpkt, init_p1_txpkt, init_p3_rxpkt, init_p3_txpkt);
      if ( ret > 0 ) then
        break;
      end
    end
  end

  pktgen.stop("1,3");
  pktgen.delay( resultWait*1000 );

  local portStat = pktgen.portStats("1,3", "port");
  local last_p1_rxpkt = portStat[1].ipackets;
  local last_p1_txpkt = portStat[1].opackets;
  local last_p3_rxpkt = portStat[3].ipackets;
  local last_p3_txpkt = portStat[3].opackets;
  
  local total_p1_txpkt = last_p1_txpkt - fir_p1_txpkt;
  local total_p1_rxpkt = last_p1_rxpkt - fir_p1_rxpkt;
  local total_p3_txpkt = last_p3_txpkt - fir_p3_txpkt;
  local total_p3_rxpkt = last_p3_rxpkt - fir_p3_rxpkt;
  
  local total_p1_loss_rate = 0;
  local total_p3_loss_rate = 0;
  if ( total_p1_txpkt-total_p3_rxpkt < 0 ) then
    total_p1_loss_rate = 0;
  elseif ( total_p1_txpkt > 0 ) then
    total_p1_loss_rate = math.abs(total_p1_txpkt-total_p3_rxpkt)/total_p1_txpkt*100;
  end
  if ( total_p3_txpkt-total_p1_rxpkt < 0 ) then
    total_p3_loss_rate = 0;
  elseif ( total_p3_txpkt > 0 ) then
    total_p3_loss_rate = math.abs(total_p3_txpkt-total_p1_rxpkt)/total_p3_txpkt*100;
  end
  
  prints("Final P1 Loss Rate",total_p1_loss_rate);
  prints("Final P3 Loss Rate",total_p3_loss_rate);
  
  local resTxt = "SUCC";
  local retVal = 0;
  local chk = math.max(total_p1_loss_rate, total_p3_loss_rate);
  if ( (ret>0) or (chk > 0 and chk >= lossCri) ) then
    resTxt = "FAIL";
    retVal = 1;
  end

  print(resTxt);
  local ffile1 = io.open(rateFile, "a+");
  local ffile2 = io.open(lossFile, "a+");
  ffile1:write(";;;;;;;;;;;;"..last_p1_rxpkt..";"..last_p1_txpkt..";"..last_p3_rxpkt..";"..last_p3_txpkt.."\n");
  ffile1:write(resTxt.."\n"..total_p1_loss_rate..";"..total_p3_loss_rate.."\n");
  ffile2:write(resTxt.."\n"..total_p1_loss_rate..";"..total_p3_loss_rate.."\n");
  ffile1:close();
  ffile2:close();
  
  return retVal;

end

local function setParam()
  bpsRate = 50;
  rateFile = "ohhara/data/rate_"..pktByte.."byte_"..bpsRate.."ratePerc_"..lossCri.."loss.txt";
  lossFile = "ohhara/data/loss_"..pktByte.."byte_"..bpsRate.."ratePerc_"..lossCri.."loss.txt";
end

local function doTestTest()
   return math.random(4)-1;
end


local function findRate()
  
  local prevRate = nil;
  local maxRate = 100;
  local minRate = 1;

  while(true)
  do
    print("----- Loss="..lossCri..", pkt="..pktByte..", rate="..bpsRate.." -----");
    if ( prevRate == nil ) then
      print("prev=null, curr="..bpsRate);
    else
      print("prev="..prevRate..", curr="..bpsRate);
    end

    local ret = 1;
    for i=1, chkRepeat, 1
    do
      if ( DEBUG ) then
        ret = doTestTest();
      else
        ret = doTest(i);
      end
      if ( ret == 0 ) then
        break;
      end
    end
    
    print("ret="..ret);
    if ( ret == 0 ) then
      minRate = bpsRate;
      if ( prevRate == nil or prevRate < bpsRate ) then
        prevRate = maxRate;
      end
      if ( bpsRate == 100 or prevRate == bpsRate or ( maxRate ~= 100 and bpsRate == maxRate-1 )) then
        writeFile(rateFile, "Succ] Find Rate : "..bpsRate.."\n");
        print("Succ] Find Rate : "..bpsRate);
        break;
      end
      local gap = math.floor( (prevRate - bpsRate)/2+0.5 );
      if ( gap == 0 ) then
        writeFile(rateFile, "Succ] Find Rate : "..bpsRate.."\n");
        print("Succ] Find Rate : "..bpsRate);
        break;
      end

      prevRate = bpsRate;
      bpsRate = gap + bpsRate;

    else
      maxRate = bpsRate;
      if ( prevRate == nil or prevRate > bpsRate ) then
        prevRate = minRate;
      end
      if ( bpsRate == 1 ) then
        writeFile(rateFile, "Fail] Not Find Rate : "..bpsRate.."\n");
        print("Fail] Not Find Rate : "..bpsRate);
        break;
      end
      if ( bpsRate == prevRate or ( minRate ~= 1 and bpsRate == minRate+1) ) then
        writeFile(rateFile, "Succ] Find Rate : "..minRate.."\n");
        print("Succ] Find Rate : "..minRate);
        break;
      end
      local gap = math.ceil( (prevRate - bpsRate)/2 -0.5 );
      if ( gap == 0 ) then
        writeFile(rateFile, "Succ] Find Rate : "..minRate.."\n");
        print("Succ] Find Rate : "..minRate);
        break;
      end

      prevRate = bpsRate;
      bpsRate = gap + bpsRate;
      
    end
    
  end
  
end


local function main()
  
  pktgen.load(envFile);
  
  for _, criRate in pairs(lossLevs) 
  do
    lossCri = criRate;
    passCri = criRate + interLossCri;
    
    for _, pktsize in pairs(pktSizes)
    do
      --print("cri="..lossCri..","..passCri..", ps="..pktsize);
      pktByte = pktsize;
      setParam();
      
      findRate();

    end

  end

end

main()


