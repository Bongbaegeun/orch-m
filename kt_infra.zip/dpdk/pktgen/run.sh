#!/bin/bash

cd ..
#./app/app/x86_64-native-linuxapp-gcc/pktgen -c 0x0f -n 2 -- -T -P -m "1.[1], 3.[3]"
./app/app/x86_64-native-linuxapp-gcc/pktgen -c 0x0f -n 2 -- -T -P -m "[1:3].[0-3:0-3]"

