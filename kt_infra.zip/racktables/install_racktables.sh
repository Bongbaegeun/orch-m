#!/bin/bash

install_lamp() {
	tasksel install lamp-server
}

install_php() {
	apt-get -y install php5-snmp php5-ldap php5-gd curl 
}

get_pkg() {
	wget wget --no-check-certificate https://downloads.sourceforge.net/project/racktables/RackTables-0.20.11.tar.gz
	tar -xvzf RackTables-0.20.11.tar.gz
	mkdir -p /var/www/html/racktables
	cp -r RackTables-0.20.11/wwwroot /var/www/html/racktables
}

create_db() {
	DB_PASS="onebox2016!"
	DB_USER="rackuser"
	DB_USER_PASS="onebox2016!"
	DB_NAME="racktables"
	DB_SQL="
GRANT ALL PRIVILEGES ON *.* to 'root'@'%' IDENTIFIED BY '$DB_PASS';
create user '$DB_USER'@'%' identified by '$DB_USER_PASS';
create database $DB_NAME default character set utf8;
grant all privileges on $DB_NAME.* to $DB_USER@'%';
flush privileges;
set password for ${DB_USER}@'%'=password('${{DB_USER_PASS}');
"
	mysql -uroot --password=${DB_PASS} mysql --execute="${DB_SQL}"

	sed -i "s/^bind-address/#bind-address/" /etc/mysql/my.cnf
	service mysql restart
}

setting_etc() {
	sed -i "/^;   extension=msql.so/a extension=snmp.so" /etc/php5/apache2/php.ini
	touch '/var/www/html/racktables/wwwroot/inc/secret.php'
	chmod 666 '/var/www/html/racktables/wwwroot/inc/secret.php'
	chmod 755 -R /var/www/html
	service apache2 restart
}

#install_lamp
#install_php
#get_pkg
#create_db
setting_etc


