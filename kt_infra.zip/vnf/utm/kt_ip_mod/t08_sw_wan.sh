#!/bin/bash


TMP_WAN_TYPE="${1^^}"
if [ "$TMP_WAN_TYPE" != "HOST" -a "$TMP_WAN_TYPE" != "VM" ]
then
	echo "Select [HOST/VM]"
	exit
fi

if [ "$TMP_WAN_TYPE" == "HOST" ]
then
	ip route del default

        ovs-vsctl del-port br-wan eth0
        ovs-vsctl del-port br-wan1 eth1

        brctl addif br-internet eth0
        brctl addif br-internet1 eth1

	ifdown br-internet
	ifup br-internet
else
	ip route del default

	ip route add default via 192.168.254.1
	
	brctl delif br-internet eth0
	brctl delif br-internet1 eth1
	
	ifdown br-internet
	ifdown br-internet1

	ovs-vsctl add-port br-wan eth0
	ovs-vsctl add-port br-wan1 eth1
fi

