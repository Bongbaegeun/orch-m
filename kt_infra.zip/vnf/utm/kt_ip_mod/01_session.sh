#!/bin/bash

source ./config.sh

#ip netns exec `ip netns | grep qrouter` curl --insecure -k -vX GET https://$MGMT_IP/index.dao
 curl --insecure -k -vX GET https://$MGMT_IP/index.dao

