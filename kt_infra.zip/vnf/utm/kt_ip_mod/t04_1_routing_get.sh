#!/bin/bash

source ./config.sh

curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -vX GET https://$MGMT_IP/base/route/table.dao

