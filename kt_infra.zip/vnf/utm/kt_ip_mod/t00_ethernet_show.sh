#!/bin/bash

source ./config.sh

TMP_WAN_TYPE="${1^^}"
if [ "$TMP_WAN_TYPE" != "DHCP" -a "$TMP_WAN_TYPE" != "STATIC" ]
then
	echo "Select [DHCP/STATIC]"
	exit
fi

if [ "$TMP_WAN_TYPE" == "DHCP" ]
then
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -vX GET https://$MGMT_IP/base/xdsl.dao?User=root
else
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -vX GET https://$MGMT_IP/base/ethernet.dao?User=root
fi

