
source ./config.sh
sleep 1
curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -vX POST https://$MGMT_IP/logout.dao
#curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'USER=root&User=root' -vX POST https://$MGMT_IP/html/index.php/Auth/Logout
