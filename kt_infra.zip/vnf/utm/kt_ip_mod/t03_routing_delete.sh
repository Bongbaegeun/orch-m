#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d '_name=main&_value=254&_destAddr=0.0.0.0&_dnetmask=0.0.0.0&_metric=111&_interface=eth1' -vX POST https://$MGMT_IP/base/route/table_delete.dao

