#!/bin/bash

source ./config.sh

# _type: 서버, 관리자..
# _addrType: 서브넷, 호스트,...
ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d '_type=1&_addrType=2&_ipv4Addr=175.213.170.152' -vX POST https://$MGMT_IP/object/network_search.dao

