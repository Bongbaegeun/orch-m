#!/usr/bin/python
#-*- coding: utf-8 -*-
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import os, time, ruamel.yaml, pprint, MySQLdb, urlparse, json, copy






def callAPI( _url, _method, header, reqBody=None, returnHeader=False, cCrt=None, cKey=None ):
    try:
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(header)
        if reqBody == None:
            strBody = None
        elif type(reqBody) == str:
            strBody = reqBody
        else:
            strBody = json.dumps( reqBody )
        
        if cCrt == None or cKey == None :
            req = HTTPRequest( validate_cert=False, url=_url, headers=h, method=_method.upper(), 
                           body=strBody, request_timeout=30 )
        else:
            req = HTTPRequest( validate_cert=False, url=_url, headers=h, method=_method.upper(), 
                            client_cert=cCrt,
                            client_key=cKey,
                            body=strBody, request_timeout=30 )

        response = http_client.fetch( request=req )
        http_client.close()
        
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except :
            pass
        
        if returnHeader :
            return { "header": response.headers, "body": retBody }
        else:
            return retBody
    except Exception, e:
        print e
	print "exception"
        return None


def create():
    _header = {"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"}
    __header = {"content-Type": "application/json", "accept":"*/*"}
    _url = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/KT-VNF/backup"""
    _body = "vnf_name=KT-VNF&local_mgmt_ip=192.168.254.1&type=local_all"
    __body = {"vnf_name":"KT-VNF", "local_mgmt_ip":"192.168.254.1", "type":"local_all"}
    print _url
    print _body
    _cKey = "/var/onebox/key/client.key"
    _cCrt = "/var/onebox/key/client.crt"
    _ret = callAPI(_url, "POST", __header, reqBody=__body, cCrt=_cCrt, cKey=_cKey)
    print _ret




if __name__ == '__main__':
    create()
