#!/usr/bin/python
#-*- coding: utf-8 -*-
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import os, time, ruamel.yaml, pprint, MySQLdb, urlparse, json, copy
from time import sleep







def callAPI( _url, _method, header, reqBody=None, returnHeader=False, _to=10, cCrt=None, cKey=None ):
    try:
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(header)
        if reqBody == None:
            strBody = None
        elif type(reqBody) == str:
            strBody = reqBody
        else:
            strBody = json.dumps( reqBody )
        
        if cCrt == None or cKey == None :
            req = HTTPRequest( validate_cert=False, url=_url, headers=h, method=_method.upper(), 
                           body=strBody, request_timeout=_to )
        else:
            req = HTTPRequest( validate_cert=False, url=_url, headers=h, method=_method.upper(), 
                            client_cert=cCrt,
                            client_key=cKey,
                            body=strBody, request_timeout=_to )
        
        response = http_client.fetch( request=req )
        http_client.close()
        
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except :
            pass
        
        if returnHeader :
            return { "header": response.headers, "body": retBody }
        else:
            return retBody
    except Exception, e:
        print e
        return None

def _restoreKTVNF(vnfLocalIP):
        ## Restore 요청
        _bakFName = "/var/onebox/backup/vnf/170627-1622/KT-VNF__0/duruan-20170627162242-82.tbp"
        
        _header = {"content-Type": "application/json", "accept":"*/*"}
        _url = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/KT-VNF/restore"""
        _body = {"vnf_name": "KT-VNF", "local_mgmt_ip": vnfLocalIP, 
                 "local_location": str(_bakFName), "needWanSwitch": False, "type": "local_all"}
        _cCrt = "/var/onebox/key/client.crt"
        _cKey = "/var/onebox/key/client.key"
        _ret = callAPI(_url, "POST", _header, reqBody=_body, _to=180, cCrt=_cCrt, cKey=_cKey)
        if _ret == None :
            print "Failed to Restore KT-VNF"
            return False
        print " - Restore KT-VNF, ret=%s"%str(_ret)
        

if __name__ == '__main__':
    _restoreKTVNF("192.168.254.1")
