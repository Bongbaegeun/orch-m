#!/bin/bash

#RET=$(nova --insecure list | grep "KT-VNF" | awk -F "global_mgmt_net=" '{print $2}' | awk -F ";" '{print $1}')

MGMT_IP="192.168.254.1"
WAN_IP="DHCP"
WAN_GW="DHCP"
WAN_MASK="DHCP"
#WAN_IP="175.213.170.152"
#WAN_GW="175.213.170.1"
#WAN_MASK="24"
OFFICE_IP="192.168.0.1"
SERVER_IP="192.168.1.1"
ACCESS_IP="211.224.204.130"

# multiwan
MWAN_IP_LIST=( "DHCP" "175.213.170.152" )
MWAN_GW_LIST=( "DHCP" "175.213.170.1" )
MWAN_MASK_LIST=( "DHCP" "24")

