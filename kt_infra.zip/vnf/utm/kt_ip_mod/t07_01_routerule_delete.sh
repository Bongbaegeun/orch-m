#!/bin/bash

source ./config.sh

# _type: 서버, 관리자..
# _addrType: 서브넷, 호스트,...
ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'TableName=aaaaa&PrioID=2' -vX POST https://$MGMT_IP/base/route/rule_delete.dao

