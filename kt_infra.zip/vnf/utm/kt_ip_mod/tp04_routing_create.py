#!/usr/bin/python
#-*- coding: utf-8 -*-
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import os, time, ruamel.yaml, pprint, MySQLdb, urlparse, json, copy






def callAPI( _url, _method, header, reqBody=None, returnHeader=False ):
    try:
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(header)
        if reqBody == None:
            strBody = None
        elif type(reqBody) == str:
            strBody = reqBody
        else:
            strBody = json.dumps( reqBody )
        
        req = HTTPRequest( validate_cert=False,
                           url=_url, headers=h, method=_method.upper(), body=strBody, request_timeout=5 )
        
        response = http_client.fetch( request=req )
        http_client.close()
        
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except :
            pass
        
        if returnHeader :
            return { "header": response.headers, "body": retBody }
        else:
            return retBody
    except Exception, e:
        print e
        return None


def create():
    _header = {"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"}
    _url = """https://%s/base/route/table_create.dao"""%"192.168.254.1"
    _body = "_tablename=%s&_nthop=1&_multitext=%s/%s/1;_dnetmask=0&_value=%s&_monitoring=1&_metric=%s&_destAddr=0.0.0.0&_range=1"%(
            'main', '175.213.170.1', 'eth1', '254', '0')
    print _url
    print _body
    _ret = callAPI(_url, "POST", _header, _body)
    print _ret




if __name__ == '__main__':
    create()
