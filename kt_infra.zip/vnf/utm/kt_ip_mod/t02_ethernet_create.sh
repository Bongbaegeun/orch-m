#!/bin/bash

source ./config.sh

TMP_WAN_TYPE="${1^^}"
if [ "$TMP_WAN_TYPE" != "DHCP" -a "$TMP_WAN_TYPE" != "STATIC" ]
then
	echo "Select [DHCP/STATIC]"
	exit
fi

if [ "$TMP_WAN_TYPE" == "DHCP" ]
then
#	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d '_name=red_dhcp_r1&_interface=eth5&_mode=1&identi=0' -vX POST https://$MGMT_IP/base/xdsl_create.dao
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d '_name=red_dhcp_r1&_interface=eth5&_mode=1&identi=0' -vX POST https://$MGMT_IP/base/xdsl_create.dao
else
#	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'interface=4&_ipAddr=175.213.170.152&_netmask=24' -vX POST https://$MGMT_IP/base/ethernet_create.dao 
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'interface=&_interface=4&_ipAddr=175.213.170.152&_netmask=24' -vX POST https://$MGMT_IP/base/ethernet_create.dao
fi

