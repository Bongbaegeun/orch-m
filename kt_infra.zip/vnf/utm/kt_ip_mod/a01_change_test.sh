#!/bin/bash

source ./config.sh

TMP_WAN_TYPE="${1^^}"
if [ "$TMP_WAN_TYPE" != "CHG" -a "$TMP_WAN_TYPE" != "ORG" ]
then
	echo "Select [CHG/ORG]"
	exit
fi

./t08_sw_wan.sh host
sleep 1

./02_login.sh

# route delete
curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d '_name=main&_value=254&_destAddr=0.0.0.0&_dnetmask=0.0.0.0&_metric=0&_interface=eth1' -vX POST https://$MGMT_IP/base/route/table_delete.dao
sleep 1
curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d '_name=main&_value=254&_destAddr=0.0.0.0&_dnetmask=0.0.0.0&_metric=100&_interface=eth5' -vX POST https://$MGMT_IP/base/route/table_delete.dao
sleep 1

if [ "$TMP_WAN_TYPE" == "ORG" ]
then
	# ip delete
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d 'DeleteID=red_dhcp' -vX POST https://$MGMT_IP/base/xdsl_delete.dao
	sleep 1
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d 'DeleteID=8&IPAddr=211.224.204.234' -vX POST https://$MGMT_IP/base/ethernet_delete.dao 
	sleep 1
	
	# ip create
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d 'interface=4&_ipAddr=175.213.170.152&_netmask=24' -vX POST https://$MGMT_IP/base/ethernet_create.dao
	sleep 1
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d '_name=red_dhcp_r1&_interface=eth5&_mode=1&identi=2' -vX POST https://$MGMT_IP/base/xdsl_create.dao 
	sleep 1
	
	# route create
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d '_tablename=main&_nthop=1&_multitext=175.213.170.1/eth1/1;_dnetmask=0&_value=254&_monitoring=1&_metric=0&_destAddr=0.0.0.0&_range=1' -vX POST https://$MGMT_IP/base/route/table_create.dao
	sleep 1
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d '_tablename=main&_nthop=1&_multitext=0.0.0.0/eth5/1;_dnetmask=0&_value=254&_monitoring=1&_metric=100&_destAddr=0.0.0.0&_range=1' -vX POST https://$MGMT_IP/base/route/table_create.dao
else
	# ip delete
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d 'DeleteID=red_dhcp_r1' -vX POST https://$MGMT_IP/base/xdsl_delete.dao
	sleep 1
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d 'DeleteID=4&IPAddr=175.213.170.152' -vX POST https://$MGMT_IP/base/ethernet_delete.dao 
	sleep 1
	
	# ip create
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d '_name=red_dhcp&_interface=eth1&_mode=1&identi=2' -vX POST https://$MGMT_IP/base/xdsl_create.dao 
	sleep 1
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d 'interface=8&_ipAddr=211.224.204.234&_netmask=25' -vX POST https://$MGMT_IP/base/ethernet_create.dao
	sleep 1
	
	# route create
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d '_tablename=main&_nthop=1&_multitext=0.0.0.0/eth1/1;_dnetmask=0&_value=254&_monitoring=1&_metric=0&_destAddr=0.0.0.0&_range=1' -vX POST https://$MGMT_IP/base/route/table_create.dao
	sleep 1
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'User=root' -d '_tablename=main&_nthop=1&_multitext=211.224.204.129/eth5/1;_dnetmask=0&_value=254&_monitoring=1&_metric=100&_destAddr=0.0.0.0&_range=1' -vX POST https://$MGMT_IP/base/route/table_create.dao
fi

./t08_sw_wan.sh vm
sleep 1

