#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'unitId=20&setId=22&name=test1&type=1&addrType=2&ipv4Addr=175.213.170.234&macType=2&macOnly=0' -vX POST https://$MGMT_IP/object/network_modify.dao

