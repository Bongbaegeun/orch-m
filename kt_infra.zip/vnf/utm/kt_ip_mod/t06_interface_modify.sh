#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'setItemRemoved0=eth5&setLenRemoved=1&id=2&name=uplink_main' -vX POST https://$MGMT_IP/object/interface_modify.dao

