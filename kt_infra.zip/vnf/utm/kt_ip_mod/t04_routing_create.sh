#!/bin/bash

source ./config.sh

TMP_WAN_TYPE="${1^^}"
if [ "$TMP_WAN_TYPE" != "DHCP" -a "$TMP_WAN_TYPE" != "STATIC" ]
then
	echo "Select [DHCP/STATIC]"
	exit
fi

if [ "$TMP_WAN_TYPE" == "DHCP" ]
then
#	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d '_tablename=main&_multitext=0.0.0.0/eth5/1;_dnetmask=0&_value=254&_monitoring=1&_metric=100&_destAddr=0.0.0.0&_range=1' -vX POST https://$MGMT_IP/base/route/table_create.dao
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d '_tablename=main&_multitext=0.0.0.0/eth5/1;_dnetmask=0&_value=254&_monitoring=1&_metric=100&_destAddr=0.0.0.0&_range=1' -vX POST https://$MGMT_IP/base/route/table_create.dao
else
#	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d '_tablename=main&_multitext=175.213.170.1/eth1/1;_dnetmask=0&_value=254&_monitoring=1&_metric=0&_destAddr=0.0.0.0&_range=1' -vX POST https://$MGMT_IP/base/route/table_create.dao
	curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d '_tablename=main&_nthop=1&_multitext=175.213.170.1/eth1/1;_dnetmask=0&_value=254&_monitoring=1&_metric=0&_destAddr=0.0.0.0&_range=1' -vX POST https://$MGMT_IP/base/route/table_create.dao

fi
