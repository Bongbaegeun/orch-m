#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded"  -vX GET https://$MGMT_IP/base/route/rule.dao

