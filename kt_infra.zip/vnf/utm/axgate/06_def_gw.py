#!/usr/bin/python
#-*- coding: utf-8 -*-
import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import traceback
import inspect
from ipaddr import IPv4Network

AX_MOD = __import__("00_axgate_api")
_DBG = False

'''
1
Routing entry for 0.0.0.0/0
  Known via "static", distance 1, metric 0
    175.213.170.1 inactive
'''
def get_data(_pdat):
    "ip, nic, metric"
    _ip = None
    _nic = None
    _metric = None
    for _pline in _pdat :
        _pcom = str(_pline).split()
        if str(_pline).find('metric') > -1 :
            _tidx = 0
            for _pcc in _pcom :
                if str(_pcc).find('metric') > -1 :
                    _metric = str(_pcom[_tidx+1]).strip()
                    break
                _tidx += 1
        else:
            try:
                IPv4Network(_pcom[0])
                _ip = _pcom[0]
                _nic = _pcom[3]
            except :
                continue
    
    return (_ip, _nic, _metric)


def do():
    _TITLE = "DEF-GW INFO"
    _cmd = 'cmd=show ip route 1.2.0.0'
    METHOD = "POST"
    
    return AX_MOD.do(get_data, _TITLE, _cmd, METHOD)


def main(_argv):
    AX_MOD._DBG = True
    do()

if __name__ == "__main__" :
    main(sys.argv)
