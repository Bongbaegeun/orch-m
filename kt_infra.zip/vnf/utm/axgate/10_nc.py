#!/usr/bin/python
#-*- coding: utf-8 -*-
import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import traceback
import inspect
from ipaddr import IPv4Network

AX_MOD = __import__("00_axgate_api")
_DBG = False

'''

'''
def get_data(_pdat):
    for _pline in _pdat :
        
    return False


def do(_ip, _if):
    _TITLE = "NC"
    _cmd = ''
    METHOD = "POST"
    
    return AX_MOD.do(get_data, _TITLE, _cmd, METHOD)


def main(_argv):
    AX_MOD._DBG = True
    do(_argv[1], _argv[2])

if __name__ == "__main__" :
    main(sys.argv)
