#!/usr/bin/python
#-*- coding: utf-8 -*-
import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import traceback
import inspect
from ipaddr import IPv4Network

AX_MOD = __import__("00_axgate_api")
_DBG = False

'''
1
!
interface eth1
 ip address 175.213.170.152/24
 security-zone uplink_main
 shutdown
!
'''
def get_data(_pdat):
    for _pline in _pdat :
        if str(_pline).find('packets transmitted') > -1 and str(_pline).find('received') > -1 :
            _pcom = str(_pline).split()
            _tidx = 0
            for _pcc in _pcom :
                if str(_pcc).startswith('received') :
                    try:
                        if int(_pcom[_tidx-1]) > 0 :
                            return True
                    except Exception, e:
                        print e
                        return False
                _tidx += 1
        
    return False


def do(_ip, _if):
    _TITLE = "PING"
    _cmd = 'cmd=ping %s timeout 3 count 3 source %s'%( _ip, str(_if) )
    METHOD = "POST"
    
    return AX_MOD.do(get_data, _TITLE, _cmd, METHOD)


def main(_argv):
    AX_MOD._DBG = True
    do(_argv[1], _argv[2])

if __name__ == "__main__" :
    main(sys.argv)
