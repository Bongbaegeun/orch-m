#!/usr/bin/python
#-*- coding: utf-8 -*-
import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import traceback
import inspect

AX_MOD = __import__("00_axgate_api")
_DBG = False

'''
1
bridge name    bridge id        STP enabled    interfaces
bridge0         8000.000000000000       no              
'''
def get_data(_pdat):
    _ret = {}
    _brName = None
    for _pline in _pdat :
        if str(_pline).find('enabled') > -1 and str(_pline).find('name') > -1 and str(_pline).find('STP') > -1 :
            continue
        
        _pcom = str(_pline).split()
        if len(_pcom) > 2 :
            _brName = str(_pcom[0])
            _ret[_brName] = []
            if len(_pcom) == 4 :
                _ret[_brName].append(str(_pcom[3]))
    
    if _brName != None :
        for _pline in _pdat :
            if str(_pline).find('enabled') > -1 and str(_pline).find('name') > -1 and str(_pline).find('STP') > -1 :
                continue
            
            _pcom = str(_pline).split()
            if len(_pcom) == 1 :
                _ret[_brName].append(str(_pcom[0]))
    
    return _ret


def do(_if):
    _TITLE = "BR INFO"
    _cmd = 'cmd=show bridge %s'%_if
    METHOD = "POST"
    
    return AX_MOD.do(get_data, _TITLE, _cmd, METHOD)


def main(_argv):
    AX_MOD._DBG = True
    do(_argv[1])

if __name__ == "__main__" :
    main(sys.argv)
