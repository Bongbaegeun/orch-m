'''
Created on 2017. 11. 20.

@author: ohhara
'''
import traceback, json, paramiko, threading, copy, os, ruamel.yaml, sys, tempfile
from time import sleep
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from ipaddr import IPv4Network
from datetime import datetime

_HEADER = {"Content-type":"application/x-www-form-urlencoded; charset=utf-8"}
_HEADER_VNFM = {"content-Type": "application/json", "accept":"*/*"}
_METHOD = "POST"

# _DEF_ID = 'axroot'
# _DEF_PASS = 'Admin12#$'
# _DEF_IP = "192.168.254.1"
_DEF_ID = None
_DEF_PASS = None
_DEF_IP = None

_PORT = "4433"
_DBG_LOGIN = False
_DBG = True
# _DBG = False


_C_Crt = "/var/onebox/key/client.crt"
_C_Key = "/var/onebox/key/client.key"

_P_NICS = ['eth1', 'eth5', 'eth6', 'eth7']
_MAIN_TABLE = "main"
_EXCEPT_TABLE = [ 'local', 'default' ]

_URL_LOGIN = "/login.cgi"
_URL_LOGOUT = "/restrict/logout.cgi"
_URL_DO = "/restrict/exec.cgi"

_URL_VNFM_BACKUP = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/AXGATE-VNF/backup"""
_URL_VNFM_RESTORE = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/AXGATE-VNF/restore"""
_URL_VNFM_STATUS = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/AXGATE-VNF/status"""


_CMD_LOGOUT = """timeout=0"""
_CMD_BR_LIST = """cmd=show bridge"""
_CMD_BR_INFO = """cmd=show bridge %s"""
_CMD_GW_LIST = """cmd=show ip route 0.0.0.0"""
_CMD_IP = """cmd=show interface %s"""
_CMD_LINK = """cmd=show link"""
_CMD_PING = """cmd=ping %s timeout %s count %s"""
_CMD_ARPING = """cmd=arping %s timeout %s count %s source %s"""










def _getLineNo():
    org_f = None
    try:
        raise Exception
    except:
        org_f = sys.exc_info()[2].tb_frame.f_back
    #On some versions of IronPython, currentframe() returns None if
    #IronPython isn't run with -X:Frames.
    if org_f is not None:
        f = org_f.f_back
    else:
        return None
    
    if f == None :
        return None
    
    l_no = f.f_lineno
    return l_no

logger = None
_LOG_T = "[PLG-KTVNF.%-4s]"
def _debug(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.debug(msg)
    else: print msg

def _info(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.info(msg)
    else: print msg

def _warn(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.warning(msg)
    else: print msg

def _error(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.error(msg)
    else: print msg

def _except(exc):
    _SERR = tempfile.TemporaryFile()
    traceback.print_exc(exc, _SERR)
    _SERR.seek(0)
    msg = _SERR.read()
    msg = _LOG_T%str(_getLineNo()) + "\n" + str(msg)
    if logger != None : logger.fatal(msg)
    else: print msg


def init(_vnfIP, _vnfID, _vnfPass, _ccrt, _ckey):
    global _DEF_IP
    global _DEF_ID
    global _DEF_PASS
    global _C_Crt
    global _C_Key
    
    _DEF_IP = _vnfIP
    _DEF_ID = _vnfID
    _DEF_PASS = _vnfPass
    _C_Crt = _ccrt
    _C_Key = _ckey




class _SessionMngr():
    
    TIMEOUT = 600
    RENEW_GAP = 10
    _c_dttm = None
    _ssid = None
    
    def update(self, _ssid=None):
        self._c_dttm = datetime.now()
        if _ssid != None : self._ssid = _ssid
    
    def start(self, _ssid):
        self.update(_ssid)
    
    def stop(self):
        self._c_dttm = None
        self._ssid = None
    
    def is_on(self):
        if self._ssid == None :
            return False
        
        if isinstance(self._c_dttm, datetime) :
            if self.TIMEOUT - (datetime.now() - self._c_dttm).total_seconds() > self.RENEW_GAP :
                return True
            else:
                return False
        else:
            return False
    
    def ssid(self): return self._ssid

_SSID = _SessionMngr()


def _parse_ret(_resp):
    _resp_line = str(_resp).splitlines()
    _res = ( _resp_line[0] == "1")
    
    _data = []
    for _line in _resp_line[1:] :
        _line = str(_line).rstrip("\x00")
        if _line == "!" or str(_line).strip() == '' or _line == None : continue
        _data.append( str(_line).strip() )
    
    if _res :
        return _res, _data
    else:
        return _res, ', '.join(_data)


def _runAPI( _ssid, url, reqBody, _meth ):
    _res, _ret, _relogin = _callAPI(_ssid, url, reqBody, _meth)
    if _relogin :
        login()
        _res, _ret, _relogin = _callAPI(_SSID.ssid(), url, reqBody, _meth)
        return _res, _ret
    else:
        return _res, _ret

def _callAPI( _ssid, url, reqBody, _meth ):
    try:
        _HEADER['Cookie'] = 'SessionID=%s'%str(_ssid)
        
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(_HEADER)
        if _meth == "POST" :
            if type(reqBody) == dict : strBody = json.dumps( reqBody )
            else: strBody = reqBody
        else:
            strBody = None
        if _DBG : _debug( "######################### REQ ######################" )
        if _DBG : _debug( "- URL: [%s] %s"%( str(_meth), str(url) ) )
        if _DBG : _debug( "- BODY: [%s] %s"%( str(type(strBody)), str(strBody) ) )
        if _DBG : _debug( "####################################################" )
        _request = HTTPRequest( url, headers=h, method=_meth.upper(), 
                                client_cert=_C_Crt, client_key=_C_Key,
                                validate_cert=False, body=strBody, request_timeout=10 )
        
        response = http_client.fetch( request=_request )
        http_client.close()
        
        _ret = (lambda x: True if x == 200 else False)(response.code)
        retBody = response.body
        if _DBG : _debug( "######################### RES ######################" )
        if _DBG : _debug( "------------------------ header --------------------" )
        if _DBG : _debug( response.headers )
        try:
            retBody = json.loads(response.body)
        except :
            pass 
        
        if _DBG : _debug( "------------------------ body -----------------------" )
        if _DBG : _debug( retBody )
        if _DBG : _debug( "-----------------------------------------------------" )
        
        return _ret, retBody, False
    except httpclient.HTTPError, e:
        _res = e.response
        if _res.code == 403 :
            _warn("Fail to Call API, Invalid Session, Retry to Login, ssid=%s"%str( _ssid ))
            return False, "Invalid Session, ssid=%s"%str(_ssid), True
        _buf = None
        _body = None
        _ret = None
        if _res != None :
            _buf = (None if _res.buffer == None else _res.buffer.read())
            _ret = _buf
        if _res != None :
            _body = _res._body
            _ret = (_ret if _body == None else _body)
        _txt = "%s, body=%s, buffer=%s"%( e, _body, _buf )
        if _DBG : _debug( "------------------- error txt ------------------------" )
        if _DBG : _debug( _txt )
        if _DBG : _debug( "------------------- http error -----------------------" )
        if _DBG : _except(e)
        if _DBG : _debug( "------------------------------------------------------" )
        try:
            return False, ( json.loads(_ret) if _ret != None else None ), False
        except Exception:
            pass
        return False, _ret, False
    except Exception, e:
        if _DBG : _debug( "------------------- unknown error -----------------------" )
        if _DBG : _except(e)
        if _DBG : _debug( "------------------------------------------------------" )
        return False, "Unknown Error: %s"%str(e), False
    finally:
        http_client.close()
        if _DBG : _debug( "####################################################" )

def _do(_cmd, _vnfIP=None, method=_METHOD, _url_func=_URL_DO):
    _vnfIP = ( _DEF_IP if _vnfIP == None else _vnfIP)
    
    global _SSID
    if _SSID.is_on() :
        _ssid = _SSID.ssid()
    else:
        if not login(_vnfIP) :
            return False, "LOGIN ERROR"
        else:
            _ssid = _SSID.ssid()
    
    _url = "https://%s:%s%s"%(_vnfIP, _PORT, _URL_DO)
    _res, _ret = _runAPI(_ssid, _url, _cmd, method)
    if _res :
        _pret, _pdat = _parse_ret(_ret)
        return _pret, _pdat
    else:
        return False, _ret

def _login(vnfIP=None, vnfID=None, vnfPass=None):
    vnfIP = ( _DEF_IP if vnfIP == None else vnfIP)
    vnfID = ( _DEF_ID if vnfID == None else vnfID)
    vnfPass = ( _DEF_PASS if vnfPass == None else vnfPass)
    try:
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(_HEADER)
        url = "https://%s:%s%s"%(vnfIP, _PORT, _URL_LOGIN)
        strBody = "username=%s&password=%s"%( str(vnfID), str(vnfPass) )
        _request = HTTPRequest( url, headers=h, method=_METHOD, 
                                client_cert=_C_Crt, client_key=_C_Key,
                                validate_cert=False, body=strBody, request_timeout=10 )
        
        if _DBG_LOGIN : _debug( "######################### REQ ######################" )
        if _DBG_LOGIN : _debug( "- URL: [%s] %s"%( str(_METHOD), str(url) ) )
        if _DBG_LOGIN : _debug( "- BODY: [%s] %s"%( str(type(strBody)), str(strBody) ) )
        if _DBG_LOGIN : _debug( "####################################################" )
        
        response = http_client.fetch( request=_request )
        http_client.close()
        
        _ret = (lambda x: True if x == 200 else False)(response.code)
        retBody = response.body
        if _DBG_LOGIN : _debug( "######################### RES ######################" )
        if _DBG_LOGIN : _debug( "------------------------ header --------------------" )
        if _DBG_LOGIN : _debug( response.headers )
        try:
            retBody = json.loads(response.body)
        except :
            pass 
        
        if _DBG_LOGIN : _debug( "------------------------ body -----------------------" )
        if _DBG_LOGIN : _debug( retBody )
        if _DBG_LOGIN : _debug( "-----------------------------------------------------" )
        
        try:
            _resh_dict = dict(response.headers)
            _cookie = _resh_dict['Set-Cookie']
            for _cktxt in _cookie.split(','):
                _name, _value = _cktxt.split('=')
                if _name == "SessionID" :
                    if _DBG_LOGIN : _debug( "######################## SSID ######################" )
                    if _DBG_LOGIN : _debug( "session_id: %s"%str( _value) )
                    if _DBG_LOGIN : _debug( "####################################################" )
                    global _SSID
                    _SSID.start(_value)
                    return True, _value
        except Exception, e:
            _except(e)
            return False, "Invalid Return, ret=%s"%str(retBody)
        return False, "No SessionID, ret=%s"%str(retBody)
    except httpclient.HTTPError, e:
        _res = e.response
        _buf = None
        _body = None
        _ret = None
        if _res != None :
            _buf = (None if _res.buffer == None else _res.buffer.read())
            _ret = _buf
        if _res != None :
            _body = _res._body
            _ret = (_ret if _body == None else _body)
        _txt = "%s, body=%s, buffer=%s"%( e, _body, _buf )
        if _DBG_LOGIN : _debug( "------------------- error txt ------------------------" )
        if _DBG_LOGIN : _debug( _txt )
        if _DBG_LOGIN : _debug( "------------------- http error -----------------------" )
        if _DBG_LOGIN : _except(e)
        if _DBG_LOGIN : _debug( "------------------------------------------------------" )
        try:
            return False, ( json.loads(_ret) if _ret != None else None )
        except :
            return False, str(_ret)
    except Exception, e:
        if _DBG_LOGIN : _debug( "------------------- unknown error -----------------------" )
        if _DBG_LOGIN : _except(e)
        if _DBG_LOGIN : _debug( "------------------------------------------------------" )
        return False, "Unknown Error: %s"%str(e)
    finally:
        http_client.close()
        if _DBG_LOGIN : _debug( "####################################################" )

def login(vnfIP=None, vnfID=None, vnfPass=None, _rNum = 5):
    vnfIP = ( _DEF_IP if vnfIP == None else vnfIP)
    vnfID = ( _DEF_ID if vnfID == None else vnfID)
    vnfPass = ( _DEF_PASS if vnfPass == None else vnfPass)
    
    global _SSID
    if _SSID.is_on() : return True
    
    _title = "AXGATE-VNF Login"
    for _idx in range(_rNum):
        sleep(1)
        _res, _ret = _login(vnfIP, vnfID, vnfPass)
        if not _res :
            _warn("Fail to %s, retry=%s/%s, err=%s"%(_title, str(_idx+1), str(_rNum), str(_ret)))
            continue
        
        _debug("Succ: %s"%_title)
        return True
    
    return False

def logout(vnfIP=None, vnfID=None):
    vnfIP = ( _DEF_IP if vnfIP == None else vnfIP)
    vnfID = ( _DEF_ID if vnfID == None else vnfID)
    _title = "AXGATE-VNF LogOut"
    try:
        _res, _ret = _do(_CMD_LOGOUT, vnfIP, _METHOD, _url_func=_URL_LOGOUT)
        if not _res :
            _warn("Fail to %s, API Run Error, err=%s"%(_title, str(_ret)))
            return False
        
        _debug("Succ: %s"%_title)
        return True
    except Exception, e:
        _warn("Fail to %s, exc=%s"%(_title, str(e)))
        _except(e)
        return False


def get_wan_nic_list():
    return _P_NICS

def get_metric(_name):
    '''
    return : None or metric
    '''
    __n = str(_name).strip()
    if __n == "br-wan" : return 0
    elif __n == "br-wan1" : return 100
    elif __n == "br-wan2" : return 200
    elif __n == "br-wan3" : return 300
    else : return None

def get_nic(_name):
    '''
    return : None or if_name
    '''
    __n = str(_name).strip()
    if __n == "br-wan" : return "eth1"
    elif __n == "br-wan1" : return "eth5"
    elif __n == "br-wan2" : return "eth6"
    elif __n == "br-wan3" : return "eth7"
    elif __n == "br-lan-office" : return "eth2"
    elif __n == "br-lan-server" : return "eth3"
    else : return None

def _get_dhcp_name(_name):
    '''
    return : None or dhcp_name
    '''
    __n = str(_name).strip()
    if __n == "br-wan" or __n == "eth1" : return "red_dhcp"
    elif __n == "br-wan1" or __n == "eth5" : return "red_dhcp_r1"
    elif __n == "br-wan2" or __n == "eth6" : return "red_dhcp_r2"
    elif __n == "br-wan3" or __n == "eth7" : return "red_dhcp_r3"
    else : return None

def get_br(_name):
    '''
    return : None or br_name
    '''
    __n = str(_name).strip()
    if __n == "eth1" : return "br-wan"
    if __n == "eth2" : return "br-lan-office"
    if __n == "eth3" : return "br-lan-server"
    elif __n == "eth5" : return "br-wan1"
    elif __n == "eth6" : return "br-wan2"
    elif __n == "eth7" : return "br-wan3"
    else : return None

def _get_br_list(_vnf_ip=None):
    '''
    return : None or br-name list
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip)
    _cmd = _CMD_BR_LIST
    _res, _ret = _do(_cmd, _vnf_ip)
    if not _res :
        _error("Fail to Get BR-List, API Run Error, cmd=%s, err=%s"%( _cmd, str(_ret) ))
        return None
    
    try:
        _br_list = []
        for _pline in _ret :
            if str(_pline).find('enabled') > -1 and str(_pline).find('name') > -1 and str(_pline).find('STP') > -1 :
                continue
            
            _pcom = str(_pline).split()
            if len(_pcom) > 2 :
                _br_list.append(str(_pcom[0]))
            
        return _br_list
    except Exception, e:
        _error("Fail to Run CMD, cmd=%s, ret=%s, exc=%s"%( _cmd, str(_ret), str(e) ))
        _except(e)
        return None

def get_br_info(_brname=None, _vnf_ip=None):
    '''
    return : None or dict{'br1': ['eth1'], 'br2':[]}
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    if _brname == None :
        _brlist = _get_br_list(_vnf_ip)
    else:
        _brlist = [_brname]
    if not isinstance(_brlist, list) :
        _warn("Fail to Get VNF-BR-IF, Invalid Br-List, br=%s"%str(_brlist))
        return None
    
    _br_info = {}
    for _brname in _brlist :
        _cmd = _CMD_BR_INFO%_brname
        _res, _ret = _do(_cmd, _vnf_ip)
        try:
            if not _res :
                _warn(" - Fail to Get BR-INFO, API Run Error, cmd=%s, err=%s"%( _cmd, str(_ret) ))
                _br_info[_brname] = []
                continue
            
            _br_ifs = []
            for _pline in _ret :
                if str(_pline).find('enabled') > -1 and str(_pline).find('name') > -1 and str(_pline).find('STP') > -1 :
                    continue
                
                _pcom = str(_pline).split()
                if len(_pcom) > 2 :
                    _rBrName = str(_pcom[0])
                    if _rBrName != _brname :
                        _warn(" - Fail to Get BR-INFO, Not Equal BRName, reqBr=%s, cmd=%s, ret=%s"%( _brname, _cmd, str(_ret) ))
                        break
                    _br_info[_brname] = []
                    if len(_pcom) == 4 :
                        _br_info[_brname].append(str(_pcom[3]))
            
            if _br_info.has_key(_brname) :
                for _pline in _ret :
                    if str(_pline).find('enabled') > -1 and str(_pline).find('name') > -1 and str(_pline).find('STP') > -1 :
                        continue
                    
                    _pcom = str(_pline).split()
                    if len(_pcom) == 1 :
                        _br_info[_brname].append(str(_pcom[0]))
            else:
                _br_info[_brname] = []
        except Exception, e:
            _warn(" - Fail to Get VNF-BR-IF, cmd=%s, ret=%, exc=%s"%( _cmd, str(_ret), str(e) ))
            _except(e)
            continue
    
    return _br_info

def _get_route_table(_vnf_ip=None):
    '''
    return : None or List
    '''
    return [_MAIN_TABLE]

def _get_gw_info(_vnf_ip=None):
    '''
    return : [{'dst_net': xx, 'dst_mask': xx, 'distance': xx, 'metric': xx, 'gw': xx, 'dev': xx}]
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _cmd = _CMD_GW_LIST
    _res, _ret = _do(_cmd, _vnf_ip)
    if not _res :
        _error("Fail to Get GW-Info, API Run Error, cmd=%s, err=%s"%( _cmd, str(_ret) ))
        return None
    
    _idx = -1
    _tmp_gw_list = []
    for _pline in _ret :
        try:
            if str(_pline).startswith('Routing entry for') :
                _dst_str = str(_pline).lstrip('Routing entry for')
                try:
                    _dst = IPv4Network(_dst_str)
                    _tmp_gw_list.append({'dst_net': str(_dst.ip), 'dst_mask': str(_dst.netmask),
                                          'distance': None, 'metric': None, 'gw': None, 'dev': None})
                    _idx += 1
                except Exception, e:
                    _warn(" - Fail to Get GW-Info, Invalid Dest Return, cmd=%s, ret=%s"%(_cmd, str(_pline)))
                    _except(e)
            
            ## distance, metric
            elif str(_pline).startswith('Known via') :
                try:
                    for _plcomp in str(_pline).split(',') :
                        _plcs = str(_plcomp).strip().split()
                        if len(_plcs) == 2 :
                            if str(_plcs[0]).strip() == 'distance' : _tmp_gw_list[_idx]['distance'] = str(_plcs[1]).strip()
                            if str(_plcs[0]).strip() == 'metric' : _tmp_gw_list[_idx]['metric'] = str(_plcs[1]).strip()
                except Exception, e:
                    _warn(" - Fail to Get GW-Info, Invalid Distance/Metric Return, cmd=%s, ret=%s"%( _cmd, str(_pline) ))
                    _except(e)
            
            ## gw, dev
            else:
                try :
                    _gw = None
                    _dev = None
                    if str(_pline).startswith('inactive') :
                        _gw = str(_pline).split()[0].strip()
                    elif str(_pline).startswith('directly connected') :
                        _dev = str(_pline).split(',')[1].strip()
                    elif str(_pline).find('via') > -1 :
                        _gwdev = ((str(_pline).replace("*", '')).replace("via", '')).split(',')
                        _gw = str(_gwdev[0]).strip()
                        _dev = str(_gwdev[1]).strip()
                    else:
                        _warn(" - Fail to Get GW-Info, Invalid GW/DEV Return, cmd=%s, ret=%s"%( _cmd, str(_pline) ))
                        continue
                    
                    _tmp_gw_list[_idx]['dev'] = _dev
                    _tmp_gw_list[_idx]['gw'] = ( None if _gw == None else str(IPv4Network(_gw).ip) )
                except Exception, e:
                    _warn(" - Fail to Get GW-Info, Invalid GW/DEV Return, cmd=%s, ret=%s"%( _cmd, str(_pline) ))
                    _except(e)
        except Exception, e:
            _warn("Fail to Get GW-Info, Parsing Error, cmd=%s, ret=%s, exc=%s"%( _cmd, str(_ret), str(e) ))
            _except(e)
    
    return _tmp_gw_list

def get_gw_info(_dev=None, _tname="main", _vnf_ip=None):
    '''
    return : None or [(dev, ip, metric)]
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _gw_list = _get_gw_info(_vnf_ip)
    _ret_gw = []
    for _gw_info in _gw_list : 
        _dst_ip = _gw_info['dst_net']
        _dst_mask = _gw_info['dst_mask']
        if _dst_ip != '0.0.0.0' or _dst_mask != '0.0.0.0' :
            continue
        
        __dev = _gw_info['dev']
        __gw = _gw_info['gw']
        __metric = _gw_info['metric']
#         _metric = _gw_info['distance']
        if __dev == None or __gw == None or __metric == None :
            continue
        
        if _dev != None :
            if _dev == __dev :
                _ret_gw.append(( __dev, __gw, __metric ))
        else:
            _ret_gw.append(( __dev, __gw, __metric ))
    
    def getKey(_item):
        try:
            return int(_item[2])
        except :
            return None
    _ret_gw.sort(key=getKey)
    return _ret_gw

def get_def_gw_info(_vnf_ip=None):
    '''
    return : None, None, None or (dev, ip, metric)
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _gw_list = get_gw_info(_vnf_ip=_vnf_ip)
    if _gw_list == None or len(_gw_list) < 1 :
        return None, None, None
    else:
        return _gw_list[0]

def get_ip(_nic, _vnf_ip=None):
    '''
    return : (IP, MASK) or None, None
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    if _nic == None or str(_nic).strip() == "" :
        _error("Fail to Get IP, No Nic")
        return None, None
    
    _cmd = _CMD_IP%str(_nic)
    _res, _ret = _do(_cmd, _vnf_ip)
    if not _res :
        _warn("Fail to Get IP, API Run Error, cmd=%s, err=%s"%( _cmd, _ret ))
        return None, None
    if str(_ret).find("""Can't find interface""") > -1 :
        return None, None
    
    try:
        for _pline in _ret :
            if str(_pline).startswith('inet') :
                _ip_info = str(_pline).split()[1].strip()
                _ip_obj = IPv4Network(_ip_info)
                return str(_ip_obj.ip), str(_ip_obj.netmask)
        return None, None
    except Exception, e:
        _error("Fail to Get IP, cmd=%s, ret=%s, exc=%s"%( _cmd, str(_ret), str(e) ))
        _except(e)
        return None, None

def _get_public_ip_list(_vnf_ip=None):
    '''
    return : [(NIC, IP, MASK)] or List
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _ip_list = []
    for _nic in _P_NICS :
        _ip, _mask = get_ip(_nic, _vnf_ip)
        if _ip == None :
            continue
        
        _ip_list.append(( _nic, _ip, _mask ))
    
    return _ip_list

def get_main_public_ip(_vnf_ip=None):
    '''
    return : (None, None, None, None) or (nic, ip, mask, gw)
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _ip_list = _get_public_ip_list(_vnf_ip)
    if len(_ip_list) < 1 :
        return None, None, None, None
    
    _def_gw_dev, _def_gw_ip, _def_gw_metric = get_def_gw_info(_vnf_ip)
    if _def_gw_ip == None or _def_gw_dev == None :
        return _ip_list[0][0], _ip_list[0][1], _ip_list[0][2], None
    
    for _ip_info in _ip_list :
        if _ip_info[0] == _def_gw_dev :
            return _ip_info[0], _ip_info[1], _ip_info[2], _def_gw_ip

def _get_link_state(_nic, _vnf_ip=None):
    '''
    return : True/False, True/False/None
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _cmd = _CMD_LINK
    _res, _ret = _do(_cmd, _vnf_ip)
    if not _res :
        _warn("Fail to Get Link-State, API Run Error, cmd=%s, err=%s"%( _cmd, _ret ))
        return False, None
    
    for _pline in _ret :
        if str(_pline).find(str(_nic)) > -1 :
            try:
                _link_line = str(_pline).split(':')[1]
                _link_state_str = str(_link_line).split()[0]
                _link_state = str(_link_state_str).replace(",", "").strip()
                if str(_link_state).upper() == "UP":
                    return True, True
                else:
                    return True, False
            except Exception, e:
                _warn("Fail to Get Link-State, Invalid Return, cmd=%s, ret=%s"%( _cmd, str(_pline) ))
                _except(e)
                return False, None
    
    _warn("Fail to Get Link-State, No Nic Info, cmd=%s, ret=%s"%( _cmd, str(_ret) ))
    return False, None

def ping(_ip, _try=1, _wait=1, _vnf_ip=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _cmd = _CMD_PING%( str(_ip), str(_wait), str(_try) )
    _res, _ret = _do(_cmd, _vnf_ip)
    if not _res :
        _warn("Fail to Ping, API Run Error, cmd=%s, err=%s"%( _cmd, _ret ))
        return False
    
    try:
        for _pline in _ret :
            if str(_pline).find('packets transmitted') > -1 :
                _ping_recv = str(_pline).split(',')[1].strip()
                _rcv_cnt = str(_ping_recv).split()[0]
                if int(_rcv_cnt) > 0 :
                    return True
                else:
                    return False
        _warn("Fail to Ping, Invalid Return, cmd=%s, ret=%s"%( _cmd, str(_ret) ))
        return False
    except Exception, e:
        _error("Fail to Ping, cmd=%s, ret=%s, exc=%s"%( _cmd, str(_ret), str(e) ))
        _except(e)
        return False

def arping(_ip, _dev, _try=1, _wait=3, _vnf_ip=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _cmd = _CMD_ARPING%( str(_ip), str(_wait), str(_try), str(_dev) )
    _res, _ret = _do(_cmd, _vnf_ip)
    if not _res :
        _warn("Fail to ARPing, API Run Error, cmd=%s, err=%s"%( _cmd, _ret ))
        return False
    
    try:
        for _pline in _ret :
            if str(_pline).startswith('Received') :
                _rcv_cnt = str(_pline).split()[1]
                if int(_rcv_cnt) > 0 :
                    return True
                else:
                    return False
        _warn("Fail to ARPing, Invalid Return, cmd=%s, ret=%s"%( _cmd, str(_ret) ))
        return False
    except Exception, e:
        _error("Fail to ARPing, cmd=%s, ret=%s, exc=%s"%( _cmd, str(_ret), str(e) ))
        _except(e)
        return False

def chk_conn_nc(_url, _port, _wait=3, _vnf_ip=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _warn("Fail to Check NC-Conn, Unsupported CMD")
    return False

def chk_conn_curl(_url, _wait=3, _vnf_ip=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _warn("Fail to Check Curl-Conn, Unsupported CMD")
    return False

def chk_conn_nslookup(_url, _wait=3, _vnf_ip=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _warn("Fail to Check NsLookUp-Conn, Unsupported CMD")
    return False

## todo
def to_delinfo_txt(_delInfo):
    if _delInfo == None :
        return True, None
    
    _tab = "     "
    _delInfoTxt = ""
    try:
        ## {"IP": None, "Route": None, "RouteRule": None, "ARP": None}
        
        
        _ip = (_delInfo['IP'] if _delInfo.has_key('IP') else None)
        if _ip != None and len(_ip) > 0 :
            _delInfoTxt += ("## IP :\n")
            for _nic in _ip.keys() :
                _ipInfo = _ip[_nic]
                if _ipInfo.has_key('id') :
                    _delInfoTxt += ( "%s%-5s: DHCP(%s)\n"%(_tab, _nic, _ipInfo['id']) )
                else:
                    _fir = True
                    for _ipAddr in _ipInfo['ip_list'] :
                        if _fir :
                            _delInfoTxt += ( "%s%-5s: %s/%s\n"%(_tab, _nic, _ipAddr['_addr'], _ipAddr['_prefixlen']) )
                            _fir = False
                        else:
                            _delInfoTxt += ( "%s%-5s  %s/%s\n"%(_tab, "", _ipAddr['_addr'], _ipAddr['_prefixlen']) )
        
        _route = (_delInfo['Route'] if _delInfo.has_key('Route') else None)
        if _route != None and len(_route) > 0 :
            _delInfoTxt += ("## Route :\n")
            for _r in _route : 
                _gwInfo = ",".join(_r['_gwList'])
                _delInfoTxt += ( "%stable: %5s, %s/%s >> %s\n"%(_tab, _r['_name'], _r['_destAddr'], _r['_dnetPrefix'], _gwInfo) )
        
        _rule = (_delInfo['RouteRule'] if _delInfo.has_key('RouteRule') else None)
        if _rule != None and len(_rule) > 0 :
            _delInfoTxt += ("## RouteRule :\n")
            for _rr in _rule :
                _delInfoTxt += ( "%stable: %5s, src:%s/%s, dst:%s/%s\n"%(
                                _tab, _rr['_name'], _rr['_addr'], _rr['_fromPrefix'], _rr['_toAddr'], _rr['_toPrefix']) )
        
        _arp = (_delInfo['ARP'] if _delInfo.has_key('ARP') else None)
        if _arp != None and len(_arp) > 0 :
            _delInfoTxt += ("## ARP :\n")
            for _a in _arp :
                _delInfoTxt += ( "%s%s, %s, %s\n"%(_tab, _a['addr'], _a['lladdr'], _a['ifname']) )
        
        if _delInfoTxt.strip() == "" :
            return True, None
        
        return True, _delInfoTxt
    except Exception, e:
        _error("Fail to Convert DelInfo to Text, exc=%s, progTxt=%s"%( str(e), _delInfoTxt ))
        _except(e)
        return False, None

def backup(_backupFile, _vnf_ip=None, _crt=None, _key=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _crt = ( _C_Crt if _crt == None else _crt )
    _key = ( _C_Key if _key == None else _key )
    
    _url = _URL_VNFM_BACKUP
    _body = {"vnf_name":"AXGATE-VNF", "local_mgmt_ip":_vnf_ip, "type":"local_all"}
    try:
        _ret = _callAPI(_url, "POST", header=_HEADER_VNFM, reqBody=_body, _to=60, cCrt=_crt, cKey=_key, sTime=1)
        
        if _ret == None or not _ret.has_key('local_location') :
            _error("Fail to Backup AXGATE-VNF, ret=%s"%str(_ret))
            return False, "Invalid Return"
        with open(_backupFile, 'w') as f:
            f.write(str(_ret['local_location']))
        return True, None
    except Exception, e:
        _error("Fail to Backup AXGATE-VNF, exc=%s"%str(e))
        _except(e)
        return False, "Exception Occur"


def _chk_ip_chg_api(_vnf_ip=None, _vnf_id=None, _vnf_pass=None, _login=True):
    return True

def chk_vnf_bridge(_wnic_list, _lan_nic=None, _vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, if list, error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    
    _ret = get_br_info(_vnf_ip=_vnf_ip)
    if type(_ret) != dict :
        _error("Fail to Chk VNF-Bridge, Invalid Return, ret=%s"%( str(_ret)))
        return False, None, "Invalid Return"
    _debug("SUCC: Get VNF-Bridge, data=%s"%( str(_ret) ))
    try:
        _ifs = []
        for _brName in _ret.keys() :
            ## bridge info
            _br_ifs = _ret[_brName]
            if type(_br_ifs) != list or len(_br_ifs) < 1 :
                _warn(" - No Bridge's Port, br=%s, port=%s"%( str(_brName), str(_br_ifs) ))
                continue
            
            _has_lan = False
            _has_wan = False
            _wan_ifs = []
            for _br_if in _br_ifs :
                if _br_if == None or str(_br_if).strip() == "" :
                    continue
                
                if _lan_nic != None and _br_if == _lan_nic :
                    _has_lan = True
                if _br_if in _wnic_list :
                    _has_wan = True
                    _info(" - Bridge ON, br=%s, port=%s"%( str(_brName), str(_br_if) ))
                    if _lan_nic == None : _ifs.append(_br_if)
                    else: _wan_ifs.append(_br_if)
            
            if _has_lan and _has_wan :
                _ifs += _wan_ifs
        
        return True, _ifs, None
    except Exception, e:
        _error("Fail to Check VNF-Bridge, ret=%s, exc=%s"%( str(_ret), str(e) ))
        _except(e)
        return False, None, str(e)

## todo
def _chk_vnf_openvpn(_wnic_list, _vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, if list/error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    return True, [], None

## todo
def _chk_vnf_qos(_wnic_list, _vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, if list/error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    return True, [], None

## todo
def get_vnf_if_id(_wnic_list, _vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, if-id list, error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    return False, None, 'UnSupported Func'

## todo
def _get_vnf_dhcp_id(_wnic_list, _vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, dhcp-id list/error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    return False, None, 'Unsupported Func'

## todo
def _get_vnf_if_ipinfo(_wnic_list, _vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, if-ip-info list/error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    return False, None, 'Unsupported Func'

## todo
def _get_vnf_route_map(_vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, route-map-id list, error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    return False, None, 'Unsupported Func'

## todo
def _get_vnf_route_info(_mapName, _vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, route-info list/error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    return False, None, 'Unsupported Func'

## todo
def get_vnf_all_route_info(_wan_nic_list, _static_gw_list=None, _chkExist=None, _vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, all-route-info list/error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    try:
        _ret, _rmap, _err = _get_vnf_route_map(_vnf_ip, _vnf_id)
        if not _ret :
            _error("Fail to Get VNF-ALL-ROUTE, RouteMap Get Error, ret=%s"%(str(_err)))
            return False, None, "RouteMap Get Error, err=%s"%str(_err)
        
        _defRouteTable = []
        _usrRouteTable = []
        for _rmName in _rmap.keys():
            _ret, _rList, _err = _get_vnf_route_info(_rmName, _vnf_ip, _vnf_id)
            if not _ret :
                _error("Fail to Get VNF-ALL-ROUTE, Route Get Error, err=%s"%(str(_err)))
                return False, None, "Route Get Error, err=%s"%str(_err)
            
            for _rInfo in _rList :
                _name = str(_rInfo['_name'])
                _destAddr = str(_rInfo['_destAddr'])
                _dnetmask = str(_rInfo['_destPrefix'])
                _dnetPrefix = str(_rInfo['_dstPrefix'])
                _metric = str(_rInfo['_metric'])
                _gwList = str(_rInfo['_gwlist']).split(',')
                _tbNum = str(_rmap[_rmName])
                
                _gwLen = len(_gwList)
                for _gwInfo in _gwList :
                    _gIP, _gIF = str(_gwInfo).split('/')
                    if _gIF in _wan_nic_list :
                        _route = { "_name":_name, "_destAddr": _destAddr, '_gwList':_gwList, "_dnetmask": _dnetmask, 
                                  "_metric": _metric, "_dnetPrefix":_dnetPrefix, "_tbNum": _tbNum }
                        # default GW
                        if _gwLen == 1 and _destAddr == "0.0.0.0" :
                            _staticGW = (lambda x: x[_gIF]['gw'] if _static_gw_list != None and x.has_key(_gIF) else None)(_static_gw_list)
                            # dhcp def GW
                            if _staticGW == None :
                                _defRouteTable.append(_route)
                                if type(_chkExist) == list and _gIF in _chkExist : _chkExist.remove(_gIF)
                                break
                            # static def gw
                            elif str(_gIP) == str(_staticGW) :
                                _defRouteTable.append(_route)
                                if type(_chkExist) == list and _gIF in _chkExist : _chkExist.remove(_gIF)
                                break
                            _warn("     User-Default Route, gIP=%s, prevGIP=%s"%(_gIP, _staticGW) )
                        # user GW
                        _warn("     User Route, _gw=%s, dstAddr=%s"%( str(_gwList), str(_destAddr)) )
                        _usrRouteTable.append(_route)
                        break
        
        return True, {'def':_defRouteTable, 'usr':_usrRouteTable}, None
    except Exception, e:
        _error("Fail to Get VNF-ROUTE-INFO, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

## todo
def _get_vnf_arp(_wnic_list, _vnf_ip=None):
    '''
    return : True/False, arp list/error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    return False, 'Unsupported Func'

## todo
def add_vnf_ip(_is_dhcp, _host_br, _ip=None, _mask=None, _mac=None, _vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    try:
        _utm_nic = get_nic(_host_br)
        if _utm_nic == None :
            _error("Fail to Add VNF-IP, NIC Convert Error, br=%s"%str(_host_br))
            return False, "NIC Convert Error, br=%s"%str(_host_br)
        
        if _is_dhcp :
            _url = _URL_ADD_DHCP%( _vnf_ip )
            _dhcp_name = _get_dhcp_name(_host_br)
            if _dhcp_name == None :
                _error("Fail to Add VNF-IP, DHCP-NAME Convert Error, br=%s"%str(_host_br))
                return False, "DHCP-NAME Convert Error, br=%s"%str(_host_br)
            if _mac == None :
                _body = "_name=%s&_interface=%s&_mode=1&_identi=2&User=%s"%(_dhcp_name, _utm_nic, _vnf_id )
            else:
                _body = "_name=%s&_interface=%s&_mode=1&_identi=1&_inIdenti=%s&User=%s"%(_dhcp_name, _utm_nic, str(_mac), _vnf_id )
        else:
            _ret, _if_ids, _err = _get_vnf_if_id([_utm_nic], _vnf_ip, _vnf_id)
            if not _ret or type(_if_ids) != dict or not _if_ids.has_key(_utm_nic) or _if_ids[_utm_nic] == None or str(_if_ids[_utm_nic]).strip() == "" :
                _error("Fail to Add VNF-IP, VNF-IF-ID Get Error, br=%s, vnf-nic=%s, err=%s, ret=%s"%( str(_host_br), str(_utm_nic), str(_err), str(_if_ids) ))
                return False, "VNF-IF-ID Get Error, br=%s, vnf-nic=%s"%( str(_host_br), str(_utm_nic) )
            _if_id = _if_ids[_utm_nic]
            try:
                _mask = IPv4Network("%s/%s"%( _ip, _mask ))._prefixlen
            except Exception, e:
                _error("Fail to Add VNF-IP, Invalid IP Info, ip=%s, mask=%s"%( str(_ip), str(_mask) ))
                return False, "Invalid IP Info, ip=%s, mask=%s"%( str(_ip), str(_mask) )
            
            _url = _URL_ADD_EHT%( _vnf_ip )
            _body = "interface=%s&_ipAddr=%s&_netmask=%s&User=%s"%( 
                    str(_if_id), str(_ip), str(_mask), _vnf_id )
        
        _ret = _callAPI(_url, "POST", reqBody=_body)
        if _ret == None or not _ret.has_key('success') or not _ret['success'] :
            _error("Fail to Add VNF-IP, Invalid API Return, ret=%s, body=%s"%( str(_ret), str(_body) ))
            return False, "Invalid API Return"
        
        return True, None
    except Exception, e:
        _error("Fail to Add VNF-IP, exc=%s"%str(e))
        _except(e)
        return False, str(e)

## todo
def add_vnf_route(_is_dhcp, _host_br, _gw=None, _table=None, _metric=None, _vnf_ip=None, _vnf_id=None):
    '''
    return : True/False, error-msg
    '''
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    try:
        _table = ( "main" if _table == None else _table )
        _gw = ( "0.0.0.0" if _is_dhcp else _gw)
        _nic = get_nic(_host_br)
        _metric = ( "0" if _metric == None else _metric )
        
        _tbNum = 254
        if _table == None or str(_table).strip() == "" :
            _error("Fail to Add VNF-ROUTE, No Table Name")
            return False, "No Table Name"
        
        _ret, _map, _err = _get_vnf_route_map(_vnf_ip, _vnf_id)
        if not _ret or type(_map) != dict or not _map.has_key(_table) or _map[_table] == None or str(_map[_table]).strip() == "" :
            _error("Fail to Add VNF-ROUTE, Table-ID Get Error, table=%s, err=%s"%( str(_table), _err ))
            return False, "Table-ID Get Error, table=%s"%str(_table)
        _tbNum = _map[_table]
        
        try:
            IPv4Network(_gw)
        except Exception, e:
            _error("Fail to Add VNF-ROUTE, Invalid GW, gw=%s"%( str(_gw) ))
            return False, "Invalid GW, gw=%s"%( str(_gw) )
        
        if _nic == None :
            _error("Fail to Add VNF-ROUTE, NIC Convert Error, br=%s"%str(_host_br))
            return False, "NIC Convert Error, br=%s"%str(_host_br)
        
        _url = _URL_ADD_ROUTE%( _vnf_ip )
        _body = "_tablename=%s&_nthop=1&_multitext=%s/%s/1;_dnetmask=0&_value=%s&_monitoring=1&_metric=%s&_destAddr=0.0.0.0&_range=1&User=%s"%(
                _table, _gw, _nic, str(_tbNum), str(_metric), _vnf_id )
        
        try:
            int(_metric)
        except Exception, e:
            _error("Fail to Add VNF-ROUTE, Invalid Metric, metric=%s"%( str(_metric) ))
            return False, "Invalid Metric, metric=%s"%( str(_metric) )
        
        _ret = _callAPI(_url, "POST", reqBody=_body)
        if _ret == None or not _ret.has_key('success') or not _ret['success'] :
            _error("Fail to Add VNF-ROUTE, Invalid API Return, ret=%s, body=%s"%( str(_ret), str(_body) ))
            return False, "Invalid API Return"
        
        return True, None
    except Exception, e:
        _error("Fail to Add VNF-ROUTE, exc=%s"%str(e))
        _except(e)
        return False, str(e)

## todo
def del_vnf_route(_route, _vnf_ip=None, _vnf_id=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    try:
        _url = _URL_DEL_ROUTE%str(_vnf_ip)
        __ifParam = []
        for __tmp in _route['_gwList'] :
            __ifParam.append(str(__tmp).split('/')[1])
        _ifParam = "<div></div>".join(__ifParam)
        _body = "_name=%s&_value=%s&_destAddr=%s&_dnetmask=%s&_metric=%s&_interface=%s&User=%s"%( 
                str(_route['_name']), str(_route['_tbNum']), str(_route['_destAddr']), 
                str(_route['_dnetmask']), str(_route['_metric']), str(_ifParam), _vnf_id )
        
        _ret = _callAPI(_url, "POST", reqBody=_body)
        if _ret == None or not _ret.has_key('success') or not _ret['success'] :
            _error(" - Fail to Delete VNF-ROUTE, ret=%s, url=%s body=%s"%(str(_ret), _url, _body))
            return False, "Invalid Route-Del Result"
        _debug(" - Route-Del Body=%s"%( _body ))
        return True, None
    except Exception, e:
        _error("Fail to Delete VNF-ROUTE, exc=%s"%str(e))
        _except(e)
        return False, str(e)

## todo
def _mod_vnf_route(_tname, _tnum, _gw_ip, _nic, _metric=None, _vnf_ip=None, _vnf_id=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    _metric = ("0" if _metric == None else _metric)
    return False, 'Unsupported Func'

## todo
def del_dhcp_if(_dhcp_if_list, _vnf_ip=None, _vnf_id=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    _recover = False
    try:
        _ret, _dhcp_id, _err = _get_vnf_dhcp_id(_dhcp_if_list, _vnf_ip, _vnf_id)
        if not _ret or type(_dhcp_id) != dict :
            _error("Fail to Del VNF-DHCP-IFs, IF-ID Get Error, if-list=%s, ret=%s, err=%s"%( str(_dhcp_if_list), str(_dhcp_id), str(_err) ))
            return False, _recover, "IF-ID Get Error, err=%s"%str(_err)
        
        _url = _URL_DEL_DHCP%str(_vnf_ip)
        for _dhcp_if in _dhcp_if_list :
            if not _dhcp_id.has_key(_dhcp_if) :
                _warn(" - Fail to Del VNF-DHCP-IFs, No IF-ID, if=%s, if-id=%s"%( str(_dhcp_if), str(_dhcp_id) ))
                continue
            
            _nid = _dhcp_id[_dhcp_if]
            _body = "DeleteID=%s&User=%s"%(_nid, _vnf_id)
            _recover = True
            _ret = _callAPI(_url, "POST", reqBody=_body)
            if type(_ret) != dict or not _ret.has_key('success') :
                _error("Fail to Del VNF-DHCP-IFs, Invalid DHCP-Del Return, ret=%s, body=%s"%( str(_ret), _body))
                return False, _recover, "Invalid DHCP-Del Result, if=%s"%str(_dhcp_if)
            if not _ret['success'] :
                _warn(" - Fail to Del VNF-DHCP-IFs, IF Del Error, if=%s, ret=%s"%( str(_dhcp_if), str(_ret) ))
            else:
                _debug(" - Del DHCP IP, if=%s, Body=%s"%( str(_dhcp_if), _body ))
        
        _info("SUCC: Del VNF-DHCP-IFs, if-list=%s"%( str(_dhcp_if_list) ))
        return True, _recover, None
    except Exception, e:
        _error("Fail to Del VNF-DHCP-IFs, if-list=%s, exc=%s"%( str(_dhcp_if_list), str(e) ))
        _except(e)
        return False, _recover, str(e)

## todo
def _mod_ip_to_dhcp(_nic, _dhcp_name, _mac=None, _vnf_ip=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    return False, 'Unsupported Func'

## todo
def _mod_ip_to_static(_nic, _ip, _pfx, _vnf_ip=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    return False, 'Unsupported Func'

## todo
def chk_list_for_new_wan_ip(_vnf_ip=None, _vnf_id=None, _vnf_pass=None):
    _vnf_ip = ( _DEF_IP if _vnf_ip == None else _vnf_ip )
    _vnf_id = ( _DEF_ID if _vnf_id == None else _vnf_id )
    _vnf_pass = ( _DEF_PASS if _vnf_pass == None else _vnf_pass )
    if _chk_ip_chg_api(_vnf_ip, _vnf_id, _vnf_pass, True) :
        return _ChkWanIPChg.ITEM_LIST_WITH_API
    else:
        return _ChkWanIPChg.ITEM_LIST_WITHOUT_API






