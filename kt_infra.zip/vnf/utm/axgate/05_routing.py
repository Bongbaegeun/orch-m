#!/usr/bin/python
#-*- coding: utf-8 -*-
import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import traceback
import inspect

AX_MOD = __import__("00_axgate_api")
_DBG = False

'''
show ip route
1
Codes: K - kernel, C - connected, S - static, R - RIP, B - BGP
       O - OSPF, IA - OSPF inter area
       N1 - OSPF NSSA external type 1, N2 - OSPF NSSA external type 2
       E1 - OSPF external type 1, E2 - OSPF external type 2
       i - IS-IS, L1 - IS-IS level-1, L2 - IS-IS level-2, ia - IS-IS inter area
       * - candidate default

Gateway of last resort is not set

C       127.0.0.0/8 is directly connected, lo
C       192.168.0.0/24 is directly connected, eth2
C       192.168.253.0/24 is directly connected, eth0
C       192.168.254.0/24 is directly connected, eth4


*AXGATE_vUTM# show ip route 0.0.0.0
Routing entry for 0.0.0.0/0
  Known via "static", distance 2, metric 0
    directly connected, eth1

Routing entry for 0.0.0.0/0
  Known via "static", distance 2, metric 0
    211.224.204.129 inactive

Routing entry for 0.0.0.0/0
  Known via "static", distance 1, metric 0, best
  * 175.213.170.1, via eth1

'''
def get_data(_pdat):
    "ip, nic, metric"
    _ret = []
    for _pline in _pdat :
        if str(_pline).startswith('K ') or str(_pline).startswith('C ') or \
            str(_pline).startswith('S ') or str(_pline).startswith('R ') or str(_pline).startswith('B ')  :
            _pcom = str(_pline).split()
            _ret.append(( _pcom[1], _pcom[5], None ))
        
    return _ret


def do():
    _TITLE = "ROUTE INFO"
    _cmd = 'cmd=show ip route'
    METHOD = "POST"
    
    return AX_MOD.do(get_data, _TITLE, _cmd, METHOD)


def main(_argv):
    AX_MOD._DBG = True
    do()

if __name__ == "__main__" :
    main(sys.argv)
