#!/usr/bin/python
#-*- coding: utf-8 -*-
import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import traceback
import inspect
from ipaddr import IPv4Network

AX_MOD = __import__("00_axgate_api")
_DBG = False

'''
1
!
interface eth1
 ip address 175.213.170.152/24
 security-zone uplink_main
 shutdown
!
'''
def get_data(_pdat):
    _ret = {}
    for _pline in _pdat :
        if str(_pline).find('interface') > -1 :
            _ret['name'] = str(_pline).split()[1]
        if str(_pline).find('ip address') > -1 :
            _ret['address'] = str(_pline).split()[2]
        if str(_pline).find('shutdown') > -1 :
            if str(_pline).find('no ') > -1 :
                _ret['link_state'] = False
            else:
                _ret['link_state'] = True
    return _ret


def do(_if):
    _TITLE = "IF-IP INFO"
    _cmd = 'cmd=show running-config interface %s'%str(_if)
    METHOD = "POST"
    
    return AX_MOD.do(get_data, _TITLE, _cmd, METHOD)


def main(_argv):
    AX_MOD._DBG = True
    do(_argv[1])

if __name__ == "__main__" :
    main(sys.argv)
