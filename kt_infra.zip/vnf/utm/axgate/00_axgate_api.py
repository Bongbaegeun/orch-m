#!/usr/bin/python
#-*- coding: utf-8 -*-
import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import traceback
import inspect

LOGIN_MOD = __import__("01_create_session")

HEADER={"Content-type":"application/x-www-form-urlencoded; charset=utf-8"}

IP = "192.168.254.1"
# IP = "175.213.170.226"
URL = "/restrict/exec.cgi"
PORT = "4433"
R_URL = "https://%s:%s%s"%(IP, PORT, URL)

_DBG = False

C_Crt = "/var/onebox/key/client.crt"
C_Key = "/var/onebox/key/client.key"

def callAPI( url, reqBody, _meth ):
    try:
        _ssid = LOGIN_MOD.get_ssid()
#         _ssid =1234
        HEADER['Cookie'] = 'SessionID=%s'%str(_ssid)
        
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(HEADER)
        if _meth == "POST" :
            if type(reqBody) == dict : strBody = json.dumps( reqBody )
            else: strBody = reqBody
        else:
            strBody = None
        if _DBG : print "######################### REQ ######################"
        if _DBG : print "- URL: [%s] %s"%( str(_meth), str(url) )
        if _DBG : print "- BODY: [%s] %s"%( str(type(strBody)), str(strBody) )
        if _DBG : print "####################################################"
        if _DBG : print ""
        _request = HTTPRequest( url, headers=h, method=_meth.upper(), 
                                client_cert=C_Crt, client_key=C_Key,
                                validate_cert=False, body=strBody, request_timeout=10 )
        
        response = http_client.fetch( request=_request )
        http_client.close()
        
        _ret = (lambda x: True if x == 200 else False)(response.code)
        retBody = response.body
        if _DBG : print "######################### RES ######################"
        if _DBG : print "------------------------ header --------------------"
        if _DBG : print response.headers
        try:
            retBody = json.loads(response.body)
        except :
            pass 
        
        if _DBG : print "------------------------ body -----------------------"
        if _DBG : print retBody
        if _DBG : print "-----------------------------------------------------"
        return _ret, retBody, response.headers
    except httpclient.HTTPError, e:
        _res = e.response
        _buf = None
        _body = None
        _ret = None
        if _res != None :
            _buf = (None if _res.buffer == None else _res.buffer.read())
            _ret = _buf
        if _res != None :
            _body = _res._body
            _ret = (_ret if _body == None else _body)
        _txt = "%s, code=%s, body=%s, buffer=%s"%( e, str(e.code), _body, _buf )
        if _DBG : print "------------------- error txt ------------------------"
        if _DBG : print _txt
        if _DBG : print "------------------- http error -----------------------"
        if _DBG : traceback.print_exc(e)
        if _DBG : print "------------------------------------------------------"
        try:
            return False, ( json.loads(_ret) if _ret != None else None ), None
        except Exception:
            pass
        return False, _ret, None
    except Exception, e:
        if _DBG : print "------------------- unknown error -----------------------"
        if _DBG : traceback.print_exc(e)
        if _DBG : print "------------------------------------------------------"
        return False, "Unknown Error: %s"%str(e), None
    finally:
        http_client.close()


def parse_ret(_resp):
    _resp_line = str(_resp).splitlines()
    _ret = ( _resp_line[0] == "1")
    
    _data = []
    for _line in _resp_line[1:] :
        _line = str(_line).rstrip("\x00")
        if _line == "!" or str(_line).strip() == '' or _line == None : continue
        _data.append( str(_line).strip() )
    
    if _ret :
        return _ret, _data
    else:
        return _ret, ', '.join(_data)


def do(get_data, title, cmd, method="POST"):
    _ret, _resp, _resh = callAPI(R_URL, cmd, method)
    if _DBG : print "####################################################"
    if _DBG : print ""
    
    _pret, _pdat = parse_ret(_resp)
    if _pret :
        _ret_info = get_data(_pdat)
    else:
        _ret_info = _pdat
    if _DBG : print "######################## %s ######################"%title
    if _DBG : print "----------------------------------------------------"
    if _DBG : print "cmd: %s"%( cmd )
    if _DBG : print "----------------------------------------------------"
    if _DBG : print "%s[%s]: %s"%( title, str(_pret), str(_ret_info) )
    if _DBG : print "----------------------------------------------------"
    if _DBG : print "####################################################"
    return _resp








