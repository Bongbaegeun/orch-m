#!/usr/bin/python
#-*- coding: utf-8 -*-
import json, sys
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
import traceback
import inspect
from ipaddr import IPv4Network

AX_MOD = __import__("00_axgate_api")
_DBG = False

'''
1
ARPING to 192.168.254.254 from 192.168.254.1 via eth4
Unicast reply from 192.168.254.254 [72:a9:ea:5e:3a:46] 0.310ms
Unicast reply from 192.168.254.254 [72:a9:ea:5e:3a:46] 0.271ms
Unicast reply from 192.168.254.254 [72:a9:ea:5e:3a:46] 0.142ms
Sent 3 probe(s) (1 broadcast(s))
Received 3 reply (0 request(s), 0 broadcast(s))
'''
def get_data(_pdat):
    for _pline in _pdat :
        if str(_pline).startswith('Received') :
            _pcom = str(_pline).split()
            try:
                if int(_pcom[1]) > 0 :
                    return True
            except Exception, e:
                print e
                return False
        
    return False


def do(_ip, _if):
    _TITLE = "ARPING"
    _cmd = 'cmd=arping %s timeout 3 count 3 source %s'%( _ip, str(_if) )
    METHOD = "POST"
    
    return AX_MOD.do(get_data, _TITLE, _cmd, METHOD)


def main(_argv):
    AX_MOD._DBG = True
    do(_argv[1], _argv[2])

if __name__ == "__main__" :
    main(sys.argv)
