#!/usr/bin/python
#-*- coding: utf-8 -*-
import importlib, json





def main():
    vnf = importlib.import_module("axgate_utm_plugin")
    vnf.init("192.168.254.1", "axroot", "Admin12#$", "/var/onebox/key/client.crt", "/var/onebox/key/client.key")
    
    vnf.login()
    
#     br_list = str(vnf.get_br_list())
#     br_info = str(vnf.get_br_info())
#     gw_info = str(vnf.get_gw_info())
#     def_gw_info = str(vnf.get_def_gw_info())
#     link_state = str(vnf._get_link_state('eth0'))
#     ip_info = str(vnf.get_ip("eth1"))
#     ip_list = str(vnf._get_public_ip_list())
#     main_public_ip = str(vnf.get_main_public_ip())
#     ping = str(vnf.ping("192.168.254.252", 2, 3))
#     arping = str(vnf.arping("192.168.254.254", 'eth4', 2, 3))
#     nc = str(vnf.chk_conn_nc("211.224.204.203", '5555', 3))
#     curl = str(vnf.chk_conn_curl("kt.com", 3))
#     nslookup = str(vnf.chk_conn_nslookup("kt.com", 3))
    brchk = str(vnf.chk_vnf_bridge(['eth0','eth1'], 'eth2'))
    
#     print ">>>>>>>>>>>>>>>>> ", str(br_list)
#     print ">>>>>>>>>>>>>>>>> ", str(br_info)
#     print ">>>>>>>>>>>>>>>>> ", str(gw_info)
#     print ">>>>>>>>>>>>>>>>> ", str(def_gw_info)
#     print ">>>>>>>>>>>>>>>>> ", str(link_state)
#     print ">>>>>>>>>>>>>>>>> ", str(ip_info)
#     print ">>>>>>>>>>>>>>>>> ", str(ip_list)
#     print ">>>>>>>>>>>>>>>>> ", str(main_public_ip)
#     print ">>>>>>>>>>>>>>>>> ", str(ping)
#     print ">>>>>>>>>>>>>>>>> ", str(arping)
#     print ">>>>>>>>>>>>>>>>> ", str(nc)
#     print ">>>>>>>>>>>>>>>>> ", str(curl)
#     print ">>>>>>>>>>>>>>>>> ", str(nslookup)
    print ">>>>>>>>>>>>>>>>> ", str(brchk)


if __name__ == '__main__':
    main()
