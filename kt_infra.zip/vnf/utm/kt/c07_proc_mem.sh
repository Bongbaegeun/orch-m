#!/bin/bash

IDX_PID=0
IDX_NAME=1
IDX_STATUS=2
IDX_PPID=3
IDX_GID=4
IDX_SID=5
IDX_TERM=6
IDX_FGID=7
IDX_KFLAG=8
IDX_MIN_FLT_MEM=9
IDX_MIN_FLT_CHL=10
IDX_MAJ_FLT_MEM=11
IDX_MAJ_FLT_CHL=12
IDX_TM_USER=13
IDX_TM_KERN=14
IDX_TM_CHL_USER=15
IDX_TM_CHL_KERN=16
IDX_RSCHD_POL=17
IDX_NICE=18
IDX_THREAD=19
IDX_TM_SIGALARM=20
IDX_TM_RUN=21
IDX_VMEM=22
IDX_RMEM=23
IDX_RLIMIT_RSS=24
IDX_ABOVE_ADDR=25
IDX_BELOW_ADDR=26
IDX_START_ADDR=27
IDX_STACK_PNT=28
IDX_INST_PNT=29
IDX_PEND_BITMAP=30
IDX_BLCK_BITMAP=31
IDX_IGNR_BITMAP=32
IDX_CAUGHT_BITMAP=33
IDX_WAIT_CHN=34
IDX_SWAP_PG=35
IDX_CHL_SWAP=36
IDX_DIE_PSIGN=37
IDX_CPU_NUM=38
IDX_RSCHD_PRI=39
IDX_SCHD_POL=40
IDX_BLK_IO_DELAY=41
IDX_TM_GUEST=42
IDX_TM_GUEST_CHL=43


printLog(){
	printf "%20s %2s %8s\n" $@
}


mkdir -p ./data

PROC_STAT_FILE="./data/proc_stats.dat"

cat /proc/[0-9]*/stat > $PROC_STAT_FILE

TOTAL_MEM=$(cat /proc/meminfo | grep "MemTotal:" | awk '{print $2}')
let "TOTAL_MEM=$TOTAL_MEM*1024"

declare -a PROC_STATS
idx=0
while read pstxt
do
	ps=($pstxt)
	exist_idx=""
	tmp_idx=0
	for PROC_STATTXT in "${PROC_STATS[@]}"
	do
		PROC_STAT=($PROC_STATTXT)
		PROC_NAME=${PROC_STAT[0]}
		if [ -z "$PROC_NAME" ]
		then
			let "tmp_idx=$tmp_idx+1"
			continue
		fi

		if [ "$PROC_NAME" == "${ps[$IDX_NAME]}" ]
		then
			exist_idx=$tmp_idx
			#echo "eq:$exist_idx"
			break
		fi
		let "tmp_idx=$tmp_idx+1"
	done

	if [ -z "$exist_idx" ]
	then
		PROC_STATS[$idx]="${ps[$IDX_NAME]} 1 ${ps[$IDX_MIN_FLT_MEM]} ${ps[$IDX_MAJ_FLT_MEM]} ${ps[$IDX_TM_USER]} ${ps[$IDX_TM_KERN]} ${ps[$IDX_TM_GUEST]} ${ps[$IDX_NICE]} ${ps[$IDX_THREAD]} ${ps[$IDX_VMEM]} ${ps[$IDX_RMEM]} ${ps[$IDX_SWAP_PG]}" 
		#echo "new idx="$idx", name="${PROC_STATS[$idx]}
		let "idx=$idx+1"
	else
		#echo "exist:"$exist_idx
		TMP_PROC_STAT=(${PROC_STATS[$exist_idx]})
		#echo "load:"$TMP_PROC_STAT
		tmp_num_proc_prev=${TMP_PROC_STAT[1]}
		tmp_min_flt_mem_prev=${TMP_PROC_STAT[2]}
		tmp_min_flt_mem_now=${ps[$IDX_MIN_FLT_MEM]}
		tmp_vmem_prev=${TMP_PROC_STAT[9]}
		tmp_vmem_now=${ps[$IDX_VMEM]}
		let "tmp_num_proc=$tmp_num_proc_prev+1"
		let "tmp_min_flt_mem=$tmp_min_flt_mem_prev+$tmp_min_flt_mem_now"
		let "tmp_vmem=$tmp_vmem_prev+$tmp_vmem_now"
		TMP_PROC_STAT[1]=$tmp_num_proc
		TMP_PROC_STAT[2]=$tmp_min_flt_mem
		TMP_PROC_STAT[9]=$tmp_vmem
		PROC_STATS[$exist_idx]="${TMP_PROC_STAT[@]}"
	fi

done < "$PROC_STAT_FILE"


printLog "PROC_NAME" "PROC_CNT" "PROC_MEM(M)"
for proctxt in "${PROC_STATS[@]}"
do
	print_proc=($proctxt)
	let "mem=${print_proc[9]}/1024/1024"
	printLog ${print_proc[0]} ${print_proc[1]} $mem
done







