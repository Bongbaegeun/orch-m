#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` ping $MGMT_IP
