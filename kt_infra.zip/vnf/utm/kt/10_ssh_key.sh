#!/bin/bash

source ./config.sh

expect <<EOF
set timeout 1
spawn ip netns exec `ip netns | grep qrouter` scp -oStrictHostKeyChecking=no /root/.ssh/id_rsa.pub root@$MGMT_IP:.ssh/authorized_keys
expect "password:"
send "smflaqh#1\r"
expect eof
EOF
#passwd = smflaqh#1
