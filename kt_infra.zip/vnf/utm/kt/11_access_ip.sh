#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'ipaddr='$ACCESS_IP'&netmask=24&mode=add' -vX POST https://$MGMT_IP/config/manageraddr.dao
