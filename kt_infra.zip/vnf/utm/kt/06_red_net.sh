#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'interface=4&_ipAddr='$WAN_IP'&_netmask='$WAN_MASK -vX POST https://$MGMT_IP/base/ethernet_create.dao
