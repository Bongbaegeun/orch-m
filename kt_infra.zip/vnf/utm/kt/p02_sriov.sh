#!/bin/bash

PARAMS=($@)

if (( "${#PARAMS[@]}" < "2" ))
then
	echo "USAGE] CMD VPORT_NUM IF_NAME"
	exit 1
fi

VPORT_NUM=${PARAMS[0]}
IF_NAME=${PARAMS[1]}

echo "$VPORT_NUM" > /sys/class/net/$IF_NAME/device/sriov_numvfs

lspci | grep "Virtual Function"

