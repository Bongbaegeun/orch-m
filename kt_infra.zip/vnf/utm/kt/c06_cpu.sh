#!/bin/bash

mkdir -p data

CPU_INIT_FILE="./data/cpu_init.dat"
CPU_INTV_FILE="./data/cpu_intv.dat"

cat /proc/stat | grep "cpu[0-9]" > $CPU_INIT_FILE

FUNC_IDX=0
STOP_INPUT="1"
SAVE_YN="0"
SAVE_DIR="./data/"
DEF_SAVE_FILE="log_def_"`date +%Y%m%d-%H%M%S`".dat"
SAVE_FILE=""


printUtil(){
	txt=$(printf "%5s %10s %10s %10s %10s %10s %10s %10s %10s %10s %10s %10s\n" $@)
	echo "$txt"
	
	if [ "$SAVE_YN" != "0" ]
	then
		if [[ "$FUNC_IDX" == "" || "$FUNC_IDX" == "0" ]]
		then
			echo "$txt" >> $SAVE_DIR$DEF_SAVE_FILE
		else
			echo "$txt" >> $SAVE_DIR$SAVE_FILE
		fi

	fi
}

init_data(){
	cat /proc/stat | grep "cpu[0-9]" > $CPU_INIT_FILE
}

timerOn(){
	cat /proc/stat | grep "cpu[0-9]" > $CPU_INTV_FILE
	sleep $1 && kill -s 14 $$ &
}

timeOut(){
	if [ "$STOP_INPUT" != "0" ]
	then
		cpu_util intv
		echo "Interval: $STOP_INPUT sec"
		echo "[[press any key to stop]]"
		echo
		timerOn $STOP_INPUT
	else
		STOP_INPUT="1"
	fi
}

trap timeOut 14

##################
## FUNCTION
#####################

init_data(){
	cat /proc/stat | grep "cpu[0-9]" > $CPU_INIT_FILE
	DEF_SAVE_FILE="log_def_"`date +%Y%m%d-%H%M%S`".dat"
}

save_data(){
	if [ "$SAVE_YN" == "0" ]
	then
		SAVE_YN="1"
		mkdir -p $SAVE_DIR
		echo "SAVE-MODE ON!!"
	else
		SAVE_YN="0"
		echo "SAVE-MODE OFF!!"
	fi
}

intv_cpu_util(){
	SAVE_FILE="log_intv_"`date +%Y%m%d-%H%M%S`".dat"
	cat /proc/stat | grep "cpu[0-9]" > $CPU_INTV_FILE
	echo "press Enter.."
	read intv_end
	
	cpu_util intv
}

continue_cpu_util(){
	while true
	do
		echo -n "   interval(sec): "
		read STOP_INPUT
		input_chk=$(echo "$STOP_INPUT" | grep -c "[^0-9*]")
		if [[ "$input_chk" == "0" && ! -z "$STOP_INPUT" ]]
		then
			break
		else
			echo "!!!! integer input"
		fi
	done
	
	SAVE_FILE="log_conti"`date +%Y%m%d-%H%M%S`".dat"
	timerOn $STOP_INPUT
	read
	STOP_INPUT="0" 
}

cpu_util(){
	READ_FILE=$CPU_INIT_FILE
	if [ "$1" == "intv" ]
	then
		READ_FILE=$CPU_INTV_FILE
	fi

	TMP_CPUS=$(cat /proc/stat | grep "cpu[0-9]")
	printUtil " Core#" "USER,T" "NICE,T" "SYSTEM,T" "IDLE,T" "IOWAIT,T" "IRQ,T" "SIRQ,T" "STEAL" "GUEST,T" "GUESTNICE" "TOTAL"
	while read init_cpu
	do
		CPU_NAME=$(echo $init_cpu | cut -d " " -f 1)
		CPU_USER=$(echo $init_cpu | cut -d " " -f 2)
                CPU_NICE=$(echo $init_cpu | cut -d " " -f 3)
                CPU_SYST=$(echo $init_cpu | cut -d " " -f 4)
                CPU_IDLE=$(echo $init_cpu | cut -d " " -f 5)
                CPU_IOWT=$(echo $init_cpu | cut -d " " -f 6)
                CPU_IRQ=$(echo $init_cpu | cut -d " " -f 7)
                CPU_SIRQ=$(echo $init_cpu | cut -d " " -f 8)
                CPU_STEAL=$(echo $init_cpu | cut -d " " -f 9)
                CPU_GUEST=$(echo $init_cpu | cut -d " " -f 10)
                CPU_GUESTNICE=$(echo $init_cpu | cut -d " " -f 11)
		
		CPU_USER_C=$(echo "$TMP_CPUS" | grep "$CPU_NAME" | cut -d " " -f 2)
                CPU_NICE_C=$(echo "$TMP_CPUS" | grep "$CPU_NAME" | cut -d " " -f 3)
                CPU_SYST_C=$(echo "$TMP_CPUS" | grep "$CPU_NAME" | cut -d " " -f 4)
                CPU_IDLE_C=$(echo "$TMP_CPUS" | grep "$CPU_NAME" | cut -d " " -f 5)
                CPU_IOWT_C=$(echo "$TMP_CPUS" | grep "$CPU_NAME" | cut -d " " -f 6)
                CPU_IRQ_C=$(echo "$TMP_CPUS" | grep "$CPU_NAME" | cut -d " " -f 7)
                CPU_SIRQ_C=$(echo "$TMP_CPUS" | grep "$CPU_NAME" | cut -d " " -f 8)
                CPU_STEAL_C=$(echo "$TMP_CPUS" | grep "$CPU_NAME" | cut -d " " -f 9)
                CPU_GUEST_C=$(echo "$TMP_CPUS" | grep "$CPU_NAME" | cut -d " " -f 10)
                CPU_GUESTNICE_C=$(echo "$TMP_CPUS" | grep "$CPU_NAME" | cut -d " " -f 11)
		
		let "CUR_CPU_USER_G=$CPU_USER_C-$CPU_USER"
                let "CUR_CPU_NICE_G=$CPU_NICE_C-$CPU_NICE"
                let "CUR_CPU_SYST_G=$CPU_SYST_C-$CPU_SYST"
                let "CUR_CPU_IDLE_G=$CPU_IDLE_C-$CPU_IDLE"
                let "CUR_CPU_IOWT_G=$CPU_IOWT_C-$CPU_IOWT"
                let "CUR_CPU_IRQ_G=$CPU_IRQ_C-$CPU_IRQ"
                let "CUR_CPU_SIRQ_G=$CPU_SIRQ_C-$CPU_SIRQ"
                let "CUR_CPU_STEAL_G=$CPU_STEAL_C-$CPU_STEAL"
                let "CUR_CPU_GUEST_G=$CPU_GUEST_C-$CPU_GUEST"
                let "CUR_CPU_GUESTNICE_G=$CPU_GUESTNICE_C-$CPU_GUESTNICE"
		let "CUR_CPU_TOTAL=$CUR_CPU_IDLE_G+$CUR_CPU_USER_G+$CUR_CPU_NICE_G+$CUR_CPU_SYST_G+$CUR_CPU_IOWT_G+$CUR_CPU_IRQ_G+$CUR_CPU_SIRQ_G+$CUR_CPU_STEAL_G"
		let "CUR_CPU_USER=$CUR_CPU_USER_G*100/$CUR_CPU_TOTAL"
		let "CUR_CPU_NICE=$CUR_CPU_NICE_G*100/$CUR_CPU_TOTAL"
                let "CUR_CPU_SYST=$CUR_CPU_SYST_G*100/$CUR_CPU_TOTAL"
                let "CUR_CPU_IDLE=$CUR_CPU_IDLE_G*100/$CUR_CPU_TOTAL"
                let "CUR_CPU_IOWT=$CUR_CPU_IOWT_G*100/$CUR_CPU_TOTAL"
                let "CUR_CPU_IRQ=$CUR_CPU_IRQ_G*100/$CUR_CPU_TOTAL"
                let "CUR_CPU_SIRQ=$CUR_CPU_SIRQ_G*100/$CUR_CPU_TOTAL"
                let "CUR_CPU_STEAL=$CUR_CPU_STEAL_G*100/$CUR_CPU_TOTAL"
                let "CUR_CPU_GUEST=$CUR_CPU_GUEST_G*100/$CUR_CPU_TOTAL"
                let "CUR_CPU_GUESTNICE=$CUR_CPU_GUESTNICE_G*100/$CUR_CPU_TOTAL"
		printUtil "$CPU_NAME" "$CUR_CPU_USER,$CUR_CPU_USER_G" "$CUR_CPU_NICE,$CUR_CPU_NICE_G" "$CUR_CPU_SYST,$CUR_CPU_SYST_G" "$CUR_CPU_IDLE,$CUR_CPU_IDLE_G" "$CUR_CPU_IOWT,$CUR_CPU_IOWT_G" "$CUR_CPU_IRQ,$CUR_CPU_IRQ_G" "$CUR_CPU_SIRQ,$CUR_CPU_SIRQ_G" "$CUR_CPU_STEAL" "$CUR_CPU_GUEST,$CUR_CPU_GUEST_G" "$CUR_CPU_GUESTNICE" "$CUR_CPU_TOTAL"
	done < $READ_FILE
}


HELP="USAGE] 0:cpu util, 1:interval cpu util, 2:continue to show cpu util, 7:init data, 8:save mode, 9:exit"

echo $HELP
while true
do
	echo -n "CMD] "
	read cmd
	
	FUNC_IDX="$cmd"
	case "$cmd" in
		"0"|"")	echo "cpu util"
			cpu_util;;
		"1")	echo "interval cpu util"
			intv_cpu_util;;
		"2")	echo "continue to show cpu util"
			continue_cpu_util;;
		"7")	echo "init data"
			init_data;;
		"8")	echo "save mode"
			save_data;;
		"9")	echo "exit"
			exit 0;;
		 * )	echo $HELP;;
	esac
	echo ""
done


