#!/bin/bash


LEN=${#}
if (( $LEN < 5 ))
then
	echo "USAGE] CMD NAME FLAVOR-ID RAM DISK CORE IS_EPA"
	exit 1 
fi

NAME=$1
F_ID=$2
RAM=$3
DISK=$4
CORE=$5
EPA=$6

nova --insecure flavor-create $NAME $F_ID $RAM $DISK $CORE
if [ -z "$EPA" ] 
then
	echo "NO EPA"
elif [[ "$EPA" == "all" || "$EPA" == "ALL" ]]
then
	nova --insecure flavor-key $F_ID set hw:cpu_policy=dedicated
	nova --insecure flavor-key $F_ID set aggregate_instance_extra_specs:pinned=true
	nova --insecure flavor-key $F_ID set hw:mem_page_size=2048
elif [[ "$EPA" == "pin" || "$EPA" == "PIN" ]]
then
        nova --insecure flavor-key $F_ID set hw:cpu_policy=dedicated
        nova --insecure flavor-key $F_ID set aggregate_instance_extra_specs:pinned=true
elif [[ "$EPA" == "huge" || "$EPA" == "HUGE" ]]
then
        nova --insecure flavor-key $F_ID set hw:mem_page_size=2048
else
	echo "Unknown EPA: "$EPA
fi

nova --insecure flavor-show $F_ID


