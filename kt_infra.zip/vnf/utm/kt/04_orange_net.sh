#!/bin/bash

source ./config.sh

if [ -z "$1" ]
then
	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'interface=7&_ipAddr='$SERVER_IP'&_netmask=24' -vX POST https://$MGMT_IP/base/ethernet_create.dao
	echo "sr-iov orange setting"
else
	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'interface=6&_ipAddr='$SERVER_IP'&_netmask=24' -vX POST https://$MGMT_IP/base/ethernet_create.dao
	echo "normal orange setting"
fi
