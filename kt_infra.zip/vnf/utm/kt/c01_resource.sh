#!/bin/bash

for VM_ID in $(virsh list | grep inst | awk '{print $2}')
do
	virsh dumpxml $VM_ID
	echo "--------------------------------------------------------"
done
