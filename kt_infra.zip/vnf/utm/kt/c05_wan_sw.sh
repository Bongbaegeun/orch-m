#!/bin/bash

watch -d 'brctl show | grep br-internet'

