#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'unitId=2&setId=2&name=kt_network_2&type=1&addrType=2&ipv4Addr='$WAN_IP'&macType=2&macOnly=0' -vX POST https://$MGMT_IP/object/network_modify.dao

