#!/bin/bash


lspci | grep Eth | grep Vir

