#!/bin/bash

source ./config.sh

while true
do
	ping_ret=$(ip netns exec `ip netns | grep qrouter` ping -c 1 -W 1 $MGMT_IP | grep -c "0 recei")
	if [[ ! -z "$ping_ret" && "$ping_ret" == "0" ]]
	then
		break
	fi

	echo "wait..."
	sleep 1
done

./01*.sh 
./02*.sh 
./03*.sh $1
./04*.sh $1
./05*.sh $1
./06*.sh
./07*.sh
./08*.sh
./09*.sh
./10*.sh
./11*.sh

./t01*.sh $1

