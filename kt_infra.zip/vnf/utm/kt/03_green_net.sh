#!/bin/bash

source ./config.sh

if [ -z "$1" ]
then
	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'interface=6&_ipAddr='$OFFICE_IP'&_netmask=24' -vX POST https://$MGMT_IP/base/ethernet_create.dao
	echo "sr-iov green setting"
else
	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'interface=5&_ipAddr='$OFFICE_IP'&_netmask=24' -vX POST https://$MGMT_IP/base/ethernet_create.dao
	echo "normal green setting"
fi
