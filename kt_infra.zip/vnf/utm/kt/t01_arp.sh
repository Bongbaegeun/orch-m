#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` ssh $MGMT_IP arp -s 192.168.0.10 00:26:55:e7:ae:a9
ip netns exec `ip netns | grep qrouter` ssh $MGMT_IP arp -s 192.168.1.10 00:26:55:e7:ae:a8
ip netns exec `ip netns | grep qrouter` ssh $MGMT_IP arp -ne

if [ -z "$1" ]
then
	ip netns exec `ip netns | grep qrouter` ssh $MGMT_IP ifconfig eth3 | grep HW
	ip netns exec `ip netns | grep qrouter` ssh $MGMT_IP ifconfig eth4 | grep HW
else
        ip netns exec `ip netns | grep qrouter` ssh $MGMT_IP ifconfig eth2 | grep HW
        ip netns exec `ip netns | grep qrouter` ssh $MGMT_IP ifconfig eth3 | grep HW
fi

