#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'username=root&passwd=smflaqh#1&force=1' -vX POST https://$MGMT_IP/login.dao

