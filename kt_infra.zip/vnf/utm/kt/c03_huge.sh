#!/bin/bash

echo "----------------------------------"
grep -i huge /proc/meminfo

echo
echo "-----------------------------------"
mount | grep -i huge

echo 
echo "--------------------------------"
tree /mnt/huge/

echo
echo "--------------------------------"
pid=$(ps -ef | grep qemu | grep -v grep | awk '{print $2}')
grep -i huge /proc/$pid/smaps | grep -v " 0 "


