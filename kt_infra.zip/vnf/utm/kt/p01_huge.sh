#!/bin/bash

if [ -z "$1" ]
then
	echo "CMD HUGE_PAGE_SIZE"
	exit
fi

echo $1 > /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages
mkdir -p /dev/hugepages
mount -t hugetlbfs hugetlbfs /dev/hugepages

grep -i huge /proc/meminfo
mount | grep hugepages

