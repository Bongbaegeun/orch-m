#!/bin/bash

nova --insecure flavor-key $1 unset aggregate_instance_extra_specs:pinned
nova --insecure flavor-key $1 unset hw:cpu_policy
nova --insecure flavor-key $1 unset hw:mem_page_size

nova --insecure flavor-show $1

