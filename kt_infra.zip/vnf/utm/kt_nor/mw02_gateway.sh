#!/bin/bash

source ./config.sh

MWAN_NUM=${#MWAN_IP_LIST[@]}
echo "ExtraWAN CNT:$MWAN_NUM"

for ((i=0; i<$MWAN_NUM; i++))
do
	TMP_IDX=$((5+$i))
	TMP_WAN_GW=${MWAN_GW_LIST[$i]}
	TMP_WAN_NIC="eth$TMP_IDX"
	TMP_WAN_METRIC=$((100*(1+$i)))
	
	if [ "$TMP_WAN_GW" == "DHCP" ]
	then
		TMP_WAN_GW="0.0.0.0"
	fi
	
	echo "idx=$TMP_IDX, GW=$TMP_WAN_GW, nic=$TMP_WAN_NIC, metric=$TMP_WAN_METRIC"
	echo "ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d _tablename=main&_nthop=1&_multitext=$TMP_WAN_GW/$TMP_WAN_NIC/1;_dnetmask=0&_value=254&_monitoring=1&_metric=$TMP_WAN_METRIC&_destAddr=0.0.0.0&_range=1 -vX POST https://$MGMT_IP/base/route/table_create.dao"
	sleep 1
	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d "_tablename=main&_nthop=1&_multitext=$TMP_WAN_GW/$TMP_WAN_NIC/1;_dnetmask=0&_value=254&_monitoring=1&_metric=$TMP_WAN_METRIC&_destAddr=0.0.0.0&_range=1" -vX POST https://$MGMT_IP/base/route/table_create.dao
	sleep 3

done



