#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrouter` ping -W 3 $MGMT_IP
