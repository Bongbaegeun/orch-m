#!/bin/bash

source ./config.sh

if [ "$WAN_GW" == "DHCP" ]
then
	WAN_GW="0.0.0.0"
fi
ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d "_tablename=main&_nthop=1&_multitext=$WAN_GW/eth1/1;_dnetmask=0&_value=254&_monitoring=1&_destAddr=0.0.0.0&_range=1" -vX POST https://$MGMT_IP/base/route/table_create.dao

