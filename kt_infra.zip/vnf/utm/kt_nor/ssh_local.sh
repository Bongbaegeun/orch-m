#!/bin/bash

source ./config.sh

ip netns exec `ip netns | grep qrout` ssh $MGMT_IP


