#!/bin/bash

source ./config.sh

MWAN_NUM=${#MWAN_IP_LIST[@]}
echo "ExtraWAN CNT:$MWAN_NUM"

for ((i=0; i<$MWAN_NUM; i++))
do
	TMP_IDX=$((5+$i))
	TMP_WAN_NIC="eth$TMP_IDX"
	
	echo "idx=$TMP_IDX, nic=$TMP_WAN_NIC"

	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'setItemAdded0='$TMP_WAN_NIC'&setLenAdded=1&id=2&name=uplink_main' -vX POST https://$MGMT_IP/object/interface_modify.dao
	sleep 3

done

