#!/bin/bash

source ./config.sh

MWAN_NUM=${#MWAN_IP_LIST[@]}
echo "ExtraWAN CNT:$MWAN_NUM"

for ((i=0; i<$MWAN_NUM; i++))
do
	TMP_IDX=$((6+$i))
	TMP_WAN_IP=${MWAN_IP_LIST[$i]}
	
	echo "idx=$TMP_IDX, ip=$TMP_WAN_IP"
	if [ "$TMP_WAN_IP" == "DHCP" ]
	then
		echo "DHCP"
	else
		ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'unitId='$TMP_IDX'&setId='$TMP_IDX'&name=kt_network_'$TMP_IDX'&type=1&addrType=2&ipv4Addr='$TMP_WAN_IP'&macType=2&macOnly=0' -vX POST https://$MGMT_IP/object/network_modify.dao
	fi
	sleep 3
done

