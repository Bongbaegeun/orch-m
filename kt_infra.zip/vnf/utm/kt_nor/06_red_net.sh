#!/bin/bash

source ./config.sh

if [ "$WAN_IP" == "DHCP" ]
then
	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d '_name=red_dhcp&_interface=eth1&_mode=1&identi=2' -vX POST https://$MGMT_IP/base/xdsl_create.dao
else
	ip netns exec `ip netns | grep qrouter` curl --insecure -k -H "Content-type:application/x-www-form-urlencoded" -d 'interface=4&_ipAddr='$WAN_IP'&_netmask='$WAN_MASK -vX POST https://$MGMT_IP/base/ethernet_create.dao
fi
