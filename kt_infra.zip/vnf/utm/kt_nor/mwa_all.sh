#!/bin/bash

source ./config.sh

./01*.sh > /dev/null
./02*.sh > /dev/null

./mw01*.sh
./mw02*.sh
./mw03*.sh
./mw04*.sh

