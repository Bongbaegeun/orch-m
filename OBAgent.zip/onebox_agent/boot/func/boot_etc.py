#-*- coding: utf-8 -*-
'''
Created on 2017. 10. 19.

@author: ohhara
'''
from time import sleep

from onebox_agent.boot.boot_ctrl import _LinkedMenu
from onebox_agent.boot import boot_constant as bc
from onebox_agent.util import ob_constant as oc
from onebox_agent.boot import boot_view as bv


import logging
logger = logging.getLogger(bc._L_TITLE)








####### OB ID Change
_TAG_OBID = "__tag_ob_id__"



####### VNF Tunnel
_TAG_TUNNEL_ON = 'tunnel_on'
_TAG_WAN_MODE = 'wan_mode'
_TAG_OBA_ON = 'oba_on'
_TAG_TUNNEL_LIST = "tunnel_list"
_TAG_TUN_VNF_TYPE = "tunnel_vnf_type"
_TAG_TUN_VNF_NAME = "tunnel_vnf_name"
_TAG_TUN_VNF_PORT = "tunnel_vnf_port"
_TAG_TUN_VNF_LIP = "tunnel_vnf_local_ip"

_VAL_UTM = "UTM"



####### VNF Tunnel
def _chkOBforVNFTunnel(_ol, _vname, _st, _ob_info):
    '''
    return : 0=error, 1=tunnel off, 2=tunnel on
             None/status(tunnel, wan mode, oba)
    '''
    _sub = ""
    try:
        logger.info("Check OneBox For %s Tunnel Setting"%str(_vname))
        
        ## KT-VNF Tunnel chk
        _sub = "SSHTunnel"
        _res, _isOn = _st.status()
        if not _res :
            bv.alert("Fail to Check %s Tunnel"%str(_vname), _width=200, _colors=True)
            return 0, None
        
        _status = {}
        if _isOn: 
            _ret = 2
            _status[_TAG_TUNNEL_ON] = True
        else: 
            _ret = 1
            _status[_TAG_TUNNEL_ON] = False
        logger.debug(" - Tunnel On: %s"%str(_isOn))
        
        if _ob_info.is_in_band():
            ## WAN SW chk(on In-Band)
            _sub = "WAN_Mode"
            _status[_TAG_WAN_MODE] = _ol.getWanMode(_ob_info)
            logger.debug(" - WanMode : %s"%str(_status[_TAG_WAN_MODE]))
            
            ## OBA chk(on In-Band)
            _sub = "OBAgent"
            _status[_TAG_OBA_ON] = _ol.is_svc_on(oc.VAL_OBA_NAME)
            logger.debug(" - OBAgent On : %s"%str(_status[_TAG_OBA_ON]))
        return _ret, _status
    except Exception, e:
        logger.error("Fail to Check %s, exc=%s"%(_sub, str(e)) )
        logger.exception(e)
        bv.alert("Fail to Check %s, exc=%s"%(_sub, str(e)), _width=200, _colors=True)
        return 0, None

def _comfirm_createVnfTunnel(_status, _vname, _vtype):
    '''
    return : 0=err, 1=ok, 2=back
             None/info(tunnel, oba, wan mode)
    '''
    try:
        _idx = 1
        _cTxt = "Create %s Web Tunnel?\n\n*Step..\n"%str(_vname)
        
        _setInfo = {_TAG_TUNNEL_ON: True}
        if _status.has_key(_TAG_OBA_ON) and _status[_TAG_OBA_ON] and _vtype == _VAL_UTM :
            _cTxt += ( " %s. Onebox-Agent Stop.\n"%str(_idx) )
            _idx += 1
            _setInfo[_TAG_OBA_ON] = False
        
        if _status.has_key(_TAG_WAN_MODE) and _status[_TAG_WAN_MODE] != "HOST" and _vtype == _VAL_UTM :
            _cTxt += ( " %s. WAN-Switch to Host.\n"%str(_idx) )
            _idx += 1
            _setInfo[_TAG_WAN_MODE] = "HOST"
        
        _cTxt += ( " %s. %s Tunnel On.\n"%( str(_idx), str(_vname) ) )
        
        logger.info("SUCC: Confirm %s Tunnel Create, info=%s"%( str(_vname), str(_setInfo) ))
        _ret = bv.confirm_ok(_cTxt)
        if _ret == bv.RET_OK :
            return 1, _setInfo
        elif _ret == bv.RET_NO :
            return 2, None
        else:
            return 1, None
    except Exception, e:
        logger.error("Fail to Confirm %s Tunnel, exc=%s"%( str(_vname), str(e) ))
        logger.exception(e)
        bv.alert("Fail to Confirm %s Tunnel, exc=%s"%( str(_vname), str(e)), _width=200, _colors=True)
        return 0, None

def _comfirm_destroyVnfTunnel(_ol, _status, ob_info, _vname, _vtype):
    '''
    return : 0=err, 1=ok, 2=back
             None/info(tunnel, oba, wan mode)
    '''
    try:
        _ret = bv.confirm_ok("%s Web Tunnel Already Exist.\nDisconnect Tunnel?"%str(_vname))
        if _ret == bv.RET_NO :
            return 2, None
        elif _ret == bv.RET_ERR :
            return 0, None
        
        _setInfo = {_TAG_TUNNEL_ON:False}
        if _ol.hasUtm(ob_info.wan_mac_list()) and _status.has_key(_TAG_WAN_MODE) and _vtype == _VAL_UTM :
            choice = [(oc.VAL_WAN_MD_VNF, "", True), (oc.VAL_WAN_MD_HOST, "", False)]
            _ret = bv.get_one_menu("Select WAN-Mode...\n(Current=%s)"%str(_status[_TAG_WAN_MODE]), choice)
            if _ret == bv.RET_NO :
                return 2, None
            elif _ret == bv.RET_ERR :
                return 0, None
            else:
                _setInfo[_TAG_WAN_MODE] = str(_ret)
        
        if _status.has_key(_TAG_OBA_ON) and _vtype == _VAL_UTM :
            choice = [("RUN", "", True), ("STOP", "", False)]
            _cRun = (lambda x: "RUN" if x else "STOP")(_status[_TAG_OBA_ON])
            _ret = bv.get_one_menu("Select OneBox-Agent Status...\n(Current=%s)"%_cRun, choice)
            if _ret == bv.RET_NO :
                return 2, None
            elif _ret == bv.RET_ERR :
                return 0, None
            else :
                _run = (lambda x: True if x == "RUN" else False)(str(_ret))
                _setInfo[_TAG_OBA_ON] = _run
        
        logger.debug("SUCC: Confirm %s Tunnel Destory, info=%s"%( str(_vname), str(_setInfo) ))
        return 1, _setInfo
    except Exception, e:
        logger.error("Fail to Confirm %s Tunnel, exc=%s"%( str(_vname), str(e) ))
        logger.exception(e)
        bv.alert(text="Fail to Confirm %s Tunnel, exc=%s"%( str(_vname), str(e)), _width=200, _colors=True)
        return 0, None


def _set_VNFTunnel(_ol, _bl, _st, _setInfo, _ob_info, _vnfIP, _vname, _vtype):
    logger.info("Setting %s Tunnel..."%str(_vname))
    bv.start_progBar("Setting %s Tunnel..."%str(_vname), "Setting %s Tunnel..."%str(_vname))
    _ret = __set_VNFTunnel(_ol, _bl, _st, _setInfo, _ob_info, _vnfIP, _vname, _vtype)
    bv.stop_progBar()
    return _ret

def __set_VNFTunnel(_ol, _bl, _st, _setInfo, _ob_info, _vnfIP, _vname, _vtype):
    _hostIP = ""
    try:
        prog_base = bv.ProgBarInfo("Setting %s Tunnel..."%str(_vname))
        
        _wanMode = (lambda x : x[_TAG_WAN_MODE] if x.has_key(_TAG_WAN_MODE) else None)(_setInfo)
        _obaMode = (lambda x : x[_TAG_OBA_ON] if x.has_key(_TAG_OBA_ON) else None)(_setInfo)
        
        if _vtype == _VAL_UTM :
            _uip = _ob_info.utm_local_ip()
            _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
            _wan_mode = _ol.getWanMode(_ob_info)
            _prv_mgmt_ip = _ol.get_mgmt_ip(_has_utm, _wan_mode, _uip)
            
            _ret = _bl.wanSw_obaRun(_ob_info, _wanMode, _obaMode, _vnfIP, prog_base )
            if not _ret :
                return False
        
            _up = bv.UpdateProg(prog_base, 2, 1, "Update VIM-IP")
            _up.start()
            _ol.update_vim_ip( _ob_info, _prv_mgmt_ip, 10, False)
            _up.stop()
        
        ## Tunnel
        prog_base.set_perc(81)
        bv.update_progBar(prog_base, "%s Tunnel setting..."%str(_vname))
        sleep(1)
        if _setInfo[_TAG_TUNNEL_ON] :
            _ret, _err = _st.create()
            if not _ret :
                bv.alert("Fail to Create %s Tunnel, err=%s"%( str(_vname), str(_err) ), _width=200, _colors=True)
                return False
        else:
            _ret = _st.destroy()
            if not _ret :
                bv.alert("Fail to Destroy %s Tunnel"%str(_vname), _width=200, _colors=True)
                return False
        
        prog_base.set_perc(100)
        bv.update_progBar(prog_base, "%s Tunnel setting(isOn=%s), OK!!!"%( str(_vname), str(_setInfo['tunnel_on']) ))
        sleep(1)
        logger.debug(" - %s Tunnel Setting, isOn=%s"%( str(_vname), str(_setInfo['tunnel_on']) ))
        
        logger.info("SUCC: Set %s Tunnel, hostIP=%s, info=%s"%( str(_vname), _hostIP, str(_setInfo) ))
        return True
    except Exception, e:
        logger.error("Fail to Set %s Tunnel, exc=%s"%( str(_vname), str(e) ))
        logger.exception(e)
        bv.alert("Fail to Set %s Tunnel, exc=%s"%( str(_vname), str(e) ), _width=200, _colors=True)
        return False




class Etc(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "ETC", None)
    
    def _select(self, _data):
        _data[bc.FUNC_TITLE] = "etc"
        
        _ret = bv.get_menu("ETC Menu...", [("1", "OB ID Setting"), 
                                           ("2", "VNF Tunnel"),
#                                            ("3", "VI Enhanced Technique"),
                                           ] )
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        else:
            return _ret
    
    def _next(self, _ret, _data):
        if _ret == "1" :
            _data[bc.FUNC_TITLE] = "OB-ID Setting"
            return _OBIDInput(self).get_res(_data)
        elif _ret == "2" :
            _data[bc.FUNC_TITLE] = "VNF Tunnel"
            return _VNFTunnelSetting().get_res(_data)
        elif _ret == "3" :
            _data[bc.FUNC_TITLE] = "VET"
            return _VETSetting().get_res(_data)
        else:
            return self._err_unimpl(_ret)



####### OB ID Change
class _OBIDInput(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBIDInput", _prevMenu)
    
    def _select(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _obid = ("" if _ob_info.ob_id() == None else _ob_info.ob_id())
        if _data.has_key(_TAG_OBID) :
            _obid = _data[_TAG_OBID]
        
        while True :
            _ret = bv.show_form("OB ID Setting", [("OB ID", 1, 1, str(_obid), 1, 8, 30, 30)])
            if _ret == bv.RET_NO :
                return self._RET_BACK
            elif _ret == bv.RET_ERR :
                logger.error("Fail to Set OB-ID, Error Occur")
                bv.alert("Fail to Set OB-ID\n: Error Occur")
                return self._RET_ERR
            else:
                if type(_ret) == list and len(_ret) == 1 :
                    _new_obid = _ret[0]
                    if _ob_info.ob_id() == _new_obid :
                        bv.alert("Same OB-ID, id=%s.\nRetry..."%str(_new_obid))
                        continue
                    _data[_TAG_OBID] = _new_obid
                    return self._RET_OK
                else:
                    logger.warning("Fail to Set OB-ID, Invalid Value, val=%s"%str(_ret))
                    bv.alert("Fail to Set OB-ID, Invalid Value, val=%s\nRetry..."%str(_ret))
                    continue
        
    def _next(self, _ret, _data):
        return _OBIDSetting(self).get_res(_data)

class _OBIDSetting(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBIDSetting", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _ob_id = _data[_TAG_OBID]
        
        __tag_oba_restart = oc.VAL_OBA_NAME + "_restart"
        __tag_oba_cfg_chg = oc.VAL_OBA_NAME + "_cfg_chg"
        __tag_vnfm_restart = oc.VAL_VNFM_NAME + "_restart"
        __tag_vnfm_cfg_chg = oc.VAL_VNFM_NAME + "_cfg_chg"
        __tag_mona_restart = oc.VAL_MONA_NAME + "_restart"
        __tag_mona_cfg_chg = oc.VAL_MONA_NAME + "_cfg_chg"

        __tag_nmsa_restart = oc.VAL_NMSA_NAME + "_restart"
        __tag_nmsa_cfg_chg = oc.VAL_NMSA_NAME + "_cfg_chg"

        __tag_smsa_restart = oc.VAL_SMSA_NAME + "_restart"
        __tag_smsa_cfg_chg = oc.VAL_SMSA_NAME + "_cfg_chg"

        _chg_ret = {
                    __tag_oba_restart:False, __tag_oba_cfg_chg:False,
                    __tag_vnfm_restart:False, __tag_vnfm_cfg_chg:False,
                    __tag_mona_restart:False, __tag_mona_cfg_chg:False,
                    __tag_nmsa_restart:False, __tag_nmsa_cfg_chg:False,
                    __tag_smsa_restart:False, __tag_smsa_cfg_chg:False,
                    }
        
        try:
            ## oba
            _ob_info.m_ob_id = _ob_id
            try:
                _ob_info.saveToCfg()
                _chg_ret[__tag_oba_cfg_chg] = True
                logger.info(" - SUCC: Set OBA's OB-ID, id=%s"%str(_ob_id))
                
                if bv.confirm_ok("Restart Onebox-Agent to Apply OB-ID?") == bv.RET_OK :
                    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False)
                    sleep(1)
                    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True)
                    sleep(3)
                    if not _ret :
                        logger.warning("Fail to Restart Onebox-Agent, err=%s"%str(_err))
                        bv.alert("Fail to Restart Onebox-Agent, err=%s\nTry to Restart Onebox-Agent..."%str(_err))
                    else:
                        _chg_ret[__tag_oba_restart] = True
                else:
                    logger.warning("Skip to Restart Onebox-Agent")
                    bv.notify("Try to Restart Onebox-Agent...")
            except Exception, e:
                logger.warning(" - Fail to Change OBA's OB-ID, id=%s, exc=%s"%( _ob_id, str(e) ))
                logger.exception(e)
            
            ## vnfm
            if _bl.config_vnfm(_ob_id) :
                _chg_ret[__tag_vnfm_cfg_chg] = True
                logger.info(" - SUCC: Set VNFM's OB-ID, id=%s"%str(_ob_id))
            
                _ret, _err = _bl.set_onebox_services([oc.VAL_VNFM_NAME], False)
                sleep(1)
                _ret, _err = _bl.set_onebox_services([oc.VAL_VNFM_NAME], True)
                sleep(3)
                if not _ret :
                    logger.warning("Fail to Restart VNFM, err=%s"%str(_err))
                    bv.alert("Fail to Restart VNFM, err=%s\nTry to Restart VNFM..."%str(_err))
                else:
                    _chg_ret[__tag_vnfm_restart] = True
            
            ## zba
            if _bl.config_mona(_ob_id) :
                _chg_ret[__tag_mona_cfg_chg] = True
                logger.info(" - SUCC: Set MONA's OB-ID, id=%s"%str(_ob_id))
            
                _ret, _err = _bl.set_onebox_services([oc.VAL_MONA_NAME], False)
                sleep(1)
                _ret, _err = _bl.set_onebox_services([oc.VAL_MONA_NAME], True)
                sleep(3)
                if not _ret :
                    logger.warning("Fail to Restart MONA, err=%s"%str(_err))
                    bv.alert("Fail to Restart MONA, err=%s\nTry to Restart MONA..."%str(_err))
                else:
                    _chg_ret[__tag_mona_restart] = True
            
            
            ## nmsa
            _ret, _err = _bl.config_nmsa(_ob_id, True)
            if _ret :
                _chg_ret[__tag_nmsa_cfg_chg] = True
                logger.info(" - SUCC: Set NMSA's OB-ID, id=%s"%str(_ob_id))
            
                _ret, _err = _bl.set_onebox_services([oc.VAL_NMSA_NAME], False)
                sleep(1)
                _ret, _err = _bl.set_onebox_services([oc.VAL_NMSA_NAME], True)
                sleep(3)
                if not _ret :
                    logger.warning("Fail to Restart NMSA, err=%s"%str(_err))
                    bv.alert("Fail to Restart NMSA, err=%s\nTry to Restart NMSA..."%str(_err))
                else:
                    _chg_ret[__tag_nmsa_restart] = True
            
            ## smsa
            _ret, _err = _bl.config_smsa(_ob_id, True)
            if _ret :
                _chg_ret[__tag_smsa_cfg_chg] = True
                logger.info(" - SUCC: Set SMSA's OB-ID, id=%s"%str(_ob_id))
            
                _ret, _err = _bl.set_onebox_services([oc.VAL_SMSA_NAME], False)
                sleep(1)
                _ret, _err = _bl.set_onebox_services([oc.VAL_SMSA_NAME], True)
                sleep(3)
                if not _ret :
                    logger.warning("Fail to Restart SMSA, err=%s"%str(_err))
                    bv.alert("Fail to Restart SMSA, err=%s\nTry to Restart SMSA..."%str(_err))
                else:
                    _chg_ret[__tag_smsa_restart] = True
            
        except Exception, e:
            logger.error("Fail to Set OB-ID, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Set OB-ID, exc=%s"%str(e))
        
        _txt = "Must Do Following Items...\n\n"
        _idx = 1
        _chg_comps = _chg_ret.keys()
        _chg_comps.sort()
        _show_msg = False
        for _chg_key in _chg_comps :
            _chg_comp_res = _chg_ret[_chg_key]
            
            if not _chg_comp_res :
                if _chg_key == __tag_oba_cfg_chg :
                    _show_msg = True
                    _txt += ( "  %2s. %s\n"%( str(_idx), "Change OB-ID of OBA Config" ) )
                    _idx += 1
                if _chg_key == __tag_vnfm_cfg_chg :
                    _show_msg = True
                    _txt += ( "  %2s. %s\n"%( str(_idx), "Change OB-ID of VNFM Config" ) )
                    _idx += 1
                if _chg_key == __tag_mona_cfg_chg :
                    _show_msg = True
                    _txt += ( "  %2s. %s\n"%( str(_idx), "Change OB-ID of MONA Config" ) )
                    _idx += 1
                if _chg_key == __tag_nmsa_cfg_chg :
                    _show_msg = True
                    _txt += ( "  %2s. %s\n"%( str(_idx), "Change OB-ID of NMSA Config" ) )
                    _idx += 1

                if _chg_key == __tag_smsa_cfg_chg :
                    _show_msg = True
                    _txt += ( "  %2s. %s\n"%( str(_idx), "Change OB-ID of SMSA Config" ) )
                    _idx += 1
                
                if _chg_key == __tag_oba_restart :
                    _show_msg = True
                    _txt += ( "  %2s. %s\n"%( str(_idx), "Restart OBA" ) )
                    _idx += 1
                if _chg_key == __tag_vnfm_restart :
                    _show_msg = True
                    _txt += ( "  %2s. %s\n"%( str(_idx), "Restart VNFM" ) )
                    _idx += 1
                if _chg_key == __tag_mona_restart :
                    _show_msg = True
                    _txt += ( "  %2s. %s\n"%( str(_idx), "Restart MONA" ) )
                    _idx += 1
                if _chg_key == __tag_nmsa_restart :
                    _show_msg = True
                    _txt += ( "  %2s. %s\n"%( str(_idx), "Restart NMSA" ) )
                    _idx += 1
                if _chg_key == __tag_smsa_restart :
                    _show_msg = True
                    _txt += ( "  %2s. %s\n"%( str(_idx), "Restart SMSA" ) )
                    _idx += 1
        
        if _show_msg :
            logger.debug(" - - ToDO:\n%s"%str(_txt))
            bv.notify(_txt)
        return self._RET_OK
    
    def _next(self, _ret, _data):
        return self._RET_OK






####### VNF Tunnel
class _VNFTunnelSetting(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "VNFTunnelSetting", None)
    
    def _select(self, _data):
        _data[bc.FUNC_TITLE] = "Setting VNF Tunnel"
        _txt = "VNF Tunnel Setting..."
        
        _t_list = []
        _ol = _data[oc.OTAG_LIB_OB]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        try:
            _utm = _ol.get_vnf_utm()
            _u_port = _utm.get_web_port()
            _u_model = _utm.get_model()
            if int(_u_port) > 0 :
                _t_list.append({_TAG_TUN_VNF_TYPE: _VAL_UTM, _TAG_TUN_VNF_NAME: _u_model, _TAG_TUN_VNF_PORT: _u_port, _TAG_TUN_VNF_LIP: _ob_info.utm_local_ip()})
            else:
                logger.warning("Fail to Get UTM Tunnel Info, Invalid Port=%s"%str(_u_port))
        except Exception, e:
            logger.warning("Fail to Get UTM Tunnel Info, exc=%s"%str(e))
            logger.exception(e)
        
        if type(_ol.get_extra_vnf_list()) == list :
            for _evl in _ol.get_extra_vnf_list():
                try:
                    _ptype = _evl.p_type
                    _pname = _evl.p_model
                    _pport = _evl.p_lib.get_web_port()
                    _plip = _evl.p_local_ip
                    if int(_pport) > 0 and _plip != None :
                        _t_list.append({_TAG_TUN_VNF_TYPE: str(_ptype).upper(), _TAG_TUN_VNF_NAME: _pname, _TAG_TUN_VNF_PORT: _pport, _TAG_TUN_VNF_LIP: _plip})
                    else:
                        logger.warning("Fail to Get Extra-VNF Tunnel Info, Invalid Info, port=%s, local-ip=%s"%( str(_pport), str(_plip) ))
                except Exception, e:
                    logger.error("Fail to Get Extra-VNF Tunnel Info, vnf=%s, exc=%s"%( str(_evl), str(e) ))
                    logger.exception(e)
        
        if len(_t_list) < 1:
            _err = "No Tunnel Info"
            logger.error("No Tunnel Info")
            bv.alert("No Tunnel Info")
            return self._RET_ERR
        
        _data[_TAG_TUNNEL_LIST] = _t_list
        
        _menu = []
        _midx = 1
        for _t in _t_list :
            _menu.append(( str(_midx), str(_t[_TAG_TUN_VNF_NAME])+"[%s]"%str(_t[_TAG_TUN_VNF_TYPE]) ))
            _midx += 1
        _ret = bv.get_menu(_txt, _menu)
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        else:
            return _ret
    
    def _next(self, _ret, _data):
        try:
            _midx = int(_ret)
            _t_list = _data[_TAG_TUNNEL_LIST]
            if _midx > len(_t_list) or _midx < 1 :
                return self._err_unimpl(_ret)
            else:
                _vinfo = _t_list[_midx-1]
                return _VNFWebTunnel(self, _vinfo[_TAG_TUN_VNF_NAME], _vinfo[_TAG_TUN_VNF_TYPE], _vinfo[_TAG_TUN_VNF_PORT], _vinfo[_TAG_TUN_VNF_LIP]).get_res(_data)
                
        except Exception, e:
            logger.error("Fail to Select VNF Tunnel, num=%s, exc=%s"%( str(_ret), str(e) ))
            logger.exception(e)
            return self._RET_ERR
        
        if _ret == "1" :
            return _VNFWebTunnel(self).get_res(_data)
        else:
            return self._err_unimpl(_ret)



class _VNFWebTunnel(_LinkedMenu):
    
    def __init__(self, _prevMenu, _vnf_name, _vnf_type, _vnf_port, _vnf_lip):
        _LinkedMenu.__init__(self, "%s Web Tunnel"%str(_vnf_name), _prevMenu)
        self._vnf_name = _vnf_name
        self._vnf_type = _vnf_type
        self._vnf_port = _vnf_port
        self._vnf_lip = _vnf_lip
    
    def _select(self, _data):
        _data[bc.FUNC_TITLE] = "Setting %s Tunnel"%str(self._vnf_name)
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        
        SshTunnel = _ol.get_tunnel_class()
        _auth = {"key": "/var/onebox/key/id_rsa"}
        _st = SshTunnel(_auth, self._vnf_port, self._vnf_lip, self._vnf_port, _sshPort="9922")
        
        _ret, _status = _chkOBforVNFTunnel(_ol, self._vnf_name, _st, _ob_info)
        
        ## ERROR
        if _ret == 0 :
            return self._RET_ERR
        ## Create Tunnel
        elif _ret == 1 :
            _data[bc.FUNC_TITLE] = "Create %s Tunnel"%str(self._vnf_name)
            _ret, _setInfo = _comfirm_createVnfTunnel(_status, self._vnf_name, self._vnf_type)
            ## OK
            if _ret == 1 :
                _result = _set_VNFTunnel(_ol, _bl, _st, _setInfo, _ob_info, self._vnf_lip, self._vnf_name, self._vnf_type)
                return self._RET_OK
            ## BACK
            elif _ret == 2 :
                return self._RET_BACK
            ## ERR
            else:
                return self._RET_ERR
        ## Destroy Tunnel
        elif _ret == 2 :
            _data[bc.FUNC_TITLE] = "Destory %s Tunnel"%str(self._vnf_name)
            _ret, _setInfo = _comfirm_destroyVnfTunnel(_ol, _status, _ob_info, self._vnf_name, self._vnf_type)
            if _ret == 1 :
                _result = _set_VNFTunnel(_ol, _bl, _st, _setInfo, _ob_info, self._vnf_lip, self._vnf_name, self._vnf_type)
                return self._RET_OK
            ## BACK
            elif _ret == 2 :
                return self._RET_BACK
            ## ERR
            else:
                return self._RET_ERR
        ## Invalid Return
        else:
            logger.error("Invalid %s Chk Return: ret=%s"%( str(self._vnf_name), str(_ret) ))
            bv.alert("Invalid %s Chk Return: ret=%s"%( str(self._vnf_name), str(_ret) ))
            return self._RET_ERR
    
    def _next(self, _ret, _data):
        return _ret
    


####### VET
class _VETSetting(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "VETSetting", None)
    
    def _select(self, _data):
        _txt = "VET Setting..."
        _ret = bv.get_menu(_txt, [ ("1", "Normal OVS"),
                                   ("2", "DPDK OVS"),
                                  ])
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        
        _vet_type = oc.VET_MODE_OVS_NORM
        if _ret == "1":
            _vet_type = oc.VET_MODE_OVS_NORM
        elif _ret == "2" :
            _vet_type = oc.VET_MODE_OVS_DPDK
        else:
            logger.error("Fail to Set VET Mode, Invalid VET Mode, mode=%s"%str(_ret))
            bv.alert("Invalid VET Mode, mode=%s"%str(_ret))
            return self._RET_ERR
        
        _ob_info = _data[oc.OTAG_OBA_INFO]
        try:
            if _vet_type == oc.VET_MODE_OVS_NORM :
                _ob_info.set_vet_mode()
            elif _vet_type == oc.VET_MODE_OVS_DPDK :
                _ob_info.set_vet_mode(_ovs_dpdk={})
            else:
                logger.error("Fail to Set VET Mode, Invalid VET Mode, mode=%s"%str(_vet_type))
                bv.alert("Invalid VET Mode, mode=%s"%str(_vet_type))
                return self._RET_ERR
            try:
                _ob_info.saveToCfg()
            except Exception, e:
                logger.error("Fail to Set VET Mode, OBA-Config Save Error, ob_info=%s"%str(_ob_info))
                logger.exception(e)
                bv.alert("Fail to Set VET Mode, OBA-Config Save Error")
                return self._RET_ERR
            
            _bl = _data[oc.OTAG_LIB_BTA]
            _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False)
            _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True)
            if not _ret :
                if bv.confirm_ok("Fail to Set VET Mode, OBA Restart Error\nContinue?") == bv.RET_OK :
                    logger.warning("Fail to Set VET Mode, OBA Restart Error, err=%s"%str(_err))
                    bv.notify("!!! Restart Onebox-Agent..")
                else:
                    logger.error("Fail to Set VET Mode, OBA Restart Error, err=%s"%str(_err))
                    bv.alert("Fail to Restart Onebox-Agent")
                    return self._RET_ERR
            
            return self._RET_OK
        except Exception, e:
            logger.error("Fail to Set VET Mode, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Set VET Mode, exc=%s"%str(e))
            return self._RET_ERR
        
        
    
    def _next(self, _ret, _data):
        return self._RET_OK











