#-*- coding: utf-8 -*-
'''
Created on 2017. 8. 17.

@author: ohhara
'''

import os, json
from ipaddr import IPv4Network
from time import sleep

from onebox_agent.boot.boot_ctrl import _LinkedMenu
from onebox_agent.boot import boot_constant as bc
from onebox_agent.util import ob_constant as oc, rest_api
from onebox_agent.boot import boot_view as bv
from onebox_agent.data import ob_info
from onebox_agent.data.ob_info import OB_NET

import logging
from __builtin__ import True
logger = logging.getLogger(bc._L_TITLE)



_TAG_OVERWRITE = "__overwrite__"
_TAG_MAC_INFO = "__tag_mac_info__"
_TAG_OBID = "__tag_obid__"
_TAG_IS_IN_BAND = "__tag_is_in_band__"
_TAG_WAN_NIC_LIST = "__tag_wan_nic_list__"
_TAG_LAN_NIC_LIST = "__tag_lan_nic_list__"
_TAG_EVW_NIC_LIST = "__tag_evw_nic_list__"
_TAG_MGMT_LIST = "__tag_mgmt_list__"
_TAG_WAN_LIST = "__tag_wan_list__"
_TAG_LAN_LIST = "__tag_lan_list__"
_TAG_EVW_LIST = "__tag_evw_list__"
_TAG_NO_AVAIL_NIC = "__tag_no_avail_nic__"
_TAG_NEW_OB_INFO = "__tag_new_ob_info__"
_TAG_FAKE_NET = "__tag_fake_net__"
_TAG_DEF_VNF_CREATE = "__tag_def_vnf_create__"
_TAG_AFTER_INSTALL = "__tag_after_install__"
_TAG_VET_OVS_DPDK = "__tag_vet_ovs_dpdk__"

_TAG_DEF_VNF_MODEL = "__tag_def_vnf_model__"
_TAG_DEF_VNF_VER = "__tag_def_vnf_ver__"
_TAG_DEF_VNF_TYPE = "__tag_def_vnf_type__"
_TAG_DEF_VNF_PFILE = "__tag_def_vnf_pfile__"
_TAG_DEF_VNF_CFG = "__tag_def_vnf_cfg__"
_TAG_DEF_VNF_LOC_IP = "__tag_def_vnf_loc_ip__"
_TAG_DEF_VNF_ID = "__tag_def_vnf_id__"
_TAG_DEF_VNF_PW = "__tag_def_vnf_pw__"


_FIELD_LEN = 50
_KEY_OBID = "One-Box ID"
_KEY_MGMT = "Management"
_KEY_WAN = "WAN"
_KEY_LAN = "LAN"
_KEY_EVW = "EVWAN"
_KEY_INF = "Interface"
_KEY_IP_TYPE = "IP Type"
_KEY_ADDR = "Address"
_KEY_MASK = "Netmask"
_KEY_GW = "Gateway"
_VAL_DHCP = "DHCP"
_VAL_STATIC = "STATIC"
_VAL_LAN_DEFAULT = ['office', 'server']


_URL_VNF_SELECT = "/ns/default/candidates"
_URL_VNF_CREATE = "/ns/default/%s"
_URL_VNF_CHK = "/ns/default/progress/%s"
_URL_VNF_NOTI = ""


_VAL_DEF_NS_ID_RSV = "RESERVED"
_VAL_DEF_NS_ID_ERR = "ERROR"

_T_MAX_CREATE_WAIT = 420
_T_RECHARGE_CREATE_WAIT = 60
_CNT_MAX_CREATE_WAIT = 10


# def _chg_key(_org, _param):
#     _key_comp = _org.split('.')
#     _keycomplen = len(_key_comp)
#     if _keycomplen < 2 : return None
#     
#     _key_comp.pop()
#     _key_comp.append(_param)
#     return '.'.join(_key_comp)


def _get_lan_name(_ob_key_value):
    _lanList = []
    for _obkey in _ob_key_value.keys() :
        if str(_obkey).find(_KEY_LAN) < 0 :
            continue
        
        _key = _obkey
        _val = _ob_key_value[_key]
        _keycomp = _key.split('.')
        if len(_keycomp) < 3 :
            return False, _key, _val, "Invalid Field Name"
        
        if _keycomp[1] == None or str(_keycomp[1]).strip() == "" :
            return False, _key, _val, "Invalid LAN Name"
        
        _lan_name = str(_keycomp[1]).strip()
        if not _lan_name in _lanList :
            _lanList.append(_lan_name)
    if _VAL_LAN_DEFAULT[0] in _lanList :
        _lanList.remove(_VAL_LAN_DEFAULT[0])
        _lanList.insert(0, _VAL_LAN_DEFAULT[0])
    if _VAL_LAN_DEFAULT[1] in _lanList :
        _lanList.remove(_VAL_LAN_DEFAULT[1])
        _lanList.insert(1, _VAL_LAN_DEFAULT[1])
    return True, None, None, _lanList

def _chk_external_net_info(_type, _ob_key_value, _used_nic, _is_extra=False):
    _key = ""
    _val = ""
    _max = (oc.VAL_EVWAN_MAX_NUM if _is_extra else oc.VAL_WAN_MAX_NUM)
    try:
        _idx = 0
        while True :
            if _idx >= _max :
                break
            # interface
            _key = _type+"."+str(_idx)+"."+_KEY_INF
            _keyIF = _key
            if not _ob_key_value.has_key(_key) :
                if _idx < 1 :
                    return False, _KEY_MGMT, None, "No %s Network(One or More)"%_type 
                logger.warning("No Chk Data of External Net, net=%s, idx=%s"%( _type, str(_idx) ))
                break
            _val = _ob_key_value[_key]
            _valIF = _val
            
            _key = _type+"."+str(_idx)+"."+_KEY_IP_TYPE
            _keyTp = _key
            _val = _ob_key_value[_key]
            _valTp = _val
            # if == null
            if _valIF == None or str(_valIF).strip() == "" :
                # ip-type != null
                if _valTp != None and str(_valTp).strip() != "" :
                    return False, _keyIF, _valIF, "Null Interface(IP TYPE Selected:%s)"%_valTp
                # ip != null
                _key = _type+"."+str(_idx)+"."+_KEY_ADDR
                _val = _ob_key_value[_key]
                if _val != None and str(_val).strip() != "" :
                    return False, _key, _val, "Null Interface(Address Exist:%s)"%_val
                # mask != null
                _key = _type+"."+str(_idx)+"."+_KEY_MASK
                _val = _ob_key_value[_key]
                if _val != None and str(_val).strip() != "" :
                    return False, _key, _val, "Null Interface(Netmask Exist:%s)"%_val
                # gw != null
                _key = _type+"."+str(_idx)+"."+_KEY_GW
                _val = _ob_key_value[_key]
                if _val != None and str(_val).strip() != "" :
                    return False, _key, _val, "Null Interface(Gateway Exist:%s)"%_val
            # if != null
            else:
                if _valIF in _used_nic :
                    return False, _keyIF, _valIF, "Already Used Interface"
                else:
                    _used_nic.append(_valIF)
                # ip-type == null
                if _valTp == None or str(_valTp).strip() == "" :
                    return False, _keyTp, _valTp, "Null IP-TYPE"
                # ip-type != null
                else:
                    # dhcp
                    if str(_valTp).upper() == _VAL_DHCP :
                        _idx += 1
                        continue
                    # static
                    elif str(_valTp).upper() == _VAL_STATIC :
                        # ip
                        _key = _type+"."+str(_idx)+"."+_KEY_ADDR
                        _val = _ob_key_value[_key]
                        _valip = _val
                        try:
                            IPv4Network(_valip)
                        except Exception :
                            return False, _key, _val, "Invalid IP-Address"
                        # mask
                        _key = _type+"."+str(_idx)+"."+_KEY_MASK
                        _val = _ob_key_value[_key]
                        _valmask = _val
                        try:
                            IPv4Network(_valip+"/"+str(_valmask))
                        except Exception :
                            return False, _key, _val, "Invalid Netmask"
                        # gw
                        _key = _type+"."+str(_idx)+"."+_KEY_GW
                        _val = _ob_key_value[_key]
                        _valgw = _val
                        try:
                            _ret = IPv4Network(_valip+"/"+str(_valmask)).compare_networks(IPv4Network(_valgw+"/"+str(_valmask)))
                            if _ret != 0 :
                                return False, _key, _val, "Invalid Gateway Subnet"
                        except Exception :
                            return False, _key, _val, "Invalid Gateway Address"
                    # invalid
                    else:
                        return False, _keyTp, _valTp, "Invalid IP-TYPE(only DHCP or STATIC)"
            
            _idx += 1
        return True, None, None, None
    except KeyError, e:
        logger.error("Fail to Chk %s Net Info, No Field, field=%s"%( _type, str(_key) ))
        logger.exception(e)
        return False, _key, None, "No Field"
    except Exception, e:
        logger.error("Fail to Chk %s Net Info, exc=%s"%( _type, str(e) ))
        logger.exception(e)
        return False, _key, _val, str(e)

def _chk_lan_net_info(_ob_key_value, _used_nic):
    _key = ""
    _val = ""
    try:
        _ret, _rkey, _rval, _res = _get_lan_name(_ob_key_value)
        if not _ret :
            return False, _rkey, _rval, _res
        
        _lan_list = _res
        if len(_lan_list) < 1 :
            return False, _KEY_LAN, None, "No LAN Network(One or More)"
        
        for _lname in _lan_list :
            _key = _KEY_LAN+"."+_lname+"."+_KEY_INF
            _keyIF = _key
            _val = _ob_key_value[_key]
            _valIF = _val
            
            # if == null
            if _valIF == None or str(_valIF).strip() == "" :
                # gw != null
                _key = _KEY_LAN+"."+_lname+"."+_KEY_GW
                _val = _ob_key_value[_key]
                if _val != None and str(_val).strip() != "" :
                    return False, _keyIF, _valIF, "Null Interface(Address Exist: %s)"%_val
                # mask != null
                _key = _KEY_LAN+"."+_lname+"."+_KEY_MASK
                _val = _ob_key_value[_key]
                if _val != None and str(_val).strip() != "" :
                    return False, _keyIF, _valIF, "Null Interface(Netmask Exist: %s)"%_val
            # if != null
            else:
                for _lnic in str(_valIF).strip().replace(" ", "").split(','):
                    if _lnic in _used_nic :
                        return False, _keyIF, _valIF, "Already Used Interface, if=%s"%str(_lnic)
                    else:
                        _used_nic.append(_lnic)
                
                # gw != ok
                _key = _KEY_LAN+"."+_lname+"."+_KEY_GW
                _val = _ob_key_value[_key]
                _valGW = _val
                try :
                    IPv4Network(_val)
                except Exception :
                    return False, _key, _val, "Invalid GW-Address"
                # mask != ok
                _key = _KEY_LAN+"."+_lname+"."+_KEY_MASK
                _val = _ob_key_value[_key]
                try :
                    IPv4Network(_valGW+"/"+_val)
                except Exception :
                    return False, _key, _val, "Invalid Netmask"
            
        return True, None, None, None
    except KeyError, e:
        logger.error("Fail to Chk LAN Net Info, No Field, field=%s"%( str(_key) ))
        logger.exception(e)
        return False, _key, None, "No Field"
    except Exception, e:
        logger.error("Fail to Chk LAN Net Info, exc=%s"%( str(e) ))
        logger.exception(e)
        return False, _key, _val, str(e)

def _chk_ob_info(_ob_key_value, _in_band, _has_evw=False):
    _key = _KEY_OBID
    _val = _ob_key_value[_key]
    try:
        ## OB ID
        if _val == None or str(_val).strip() == "" :
            return False, _key, _val, 'Null OB-ID'
        
        _used_nic = []
        ## MGMT
        _ret, _key, _val, _err = _chk_external_net_info(_KEY_MGMT, _ob_key_value, _used_nic)
        if not _ret :
            return _ret, _key, _val, _err
        
        ## WAN
        if not _in_band:
            _ret, _key, _val, _err = _chk_external_net_info(_KEY_WAN, _ob_key_value, _used_nic)
            if not _ret :
                return _ret, _key, _val, _err
        
        ## LAN
        _ret, _key, _val, _err = _chk_lan_net_info(_ob_key_value, _used_nic)
        if not _ret :
            return _ret, _key, _val, _err
        
        ## EVWAN
        if _has_evw:
            _ret, _key, _val, _err = _chk_external_net_info(_KEY_EVW, _ob_key_value, _used_nic, True)
            if not _ret :
                return _ret, _key, _val, _err
        
        return True, None, None, None
    except Exception, e:
        logger.error("Fail to Chk OB-INFO, key=%s, val=%s, exc=%s"%( _key, _val, str(e) ))
        logger.exception(e)
        return False, _key, _val, str(e)


def _set_external_net(_type, _ob_key_value, _mac_info, _in_band, _is_extra=False):
    try:
        ## MGMT
        _idx = 0
        _ext_idx = 0
        _ext_list = []
        _name = str(_type).lower()
        if _type == _KEY_MGMT :
            _net_type = oc.VAL_NET_TYPE_MGMT
        elif _type == _KEY_WAN :
            _net_type = oc.VAL_NET_TYPE_WAN
        else:
            _net_type = oc.VAL_NET_TYPE_EVWAN
        
        if _net_type == oc.VAL_NET_TYPE_MGMT :
            _br_list = oc.VAL_DEF_OS_BR_LIST
        elif _net_type == oc.VAL_NET_TYPE_WAN :
            _br_list = oc.VAL_DEF_VI_WAN_BR_LIST
        else:
            _br_list = oc.VAL_DEF_VI_EWAN_BR_LIST
        
        if _type == _KEY_WAN and _in_band :
            _key_type = _KEY_MGMT
        else:
            _key_type = _type
        
        _max = (oc.VAL_EVWAN_MAX_NUM if _is_extra else oc.VAL_WAN_MAX_NUM)
        while True :
            # nic
            if _idx >= _max :
                break
            _key = _key_type+"."+str(_idx)+"."+_KEY_INF
            if not _ob_key_value.has_key(_key) :
                logger.warning("No %s-Net Data, idx=%s"%( _type, str(_idx) ))
                _idx += 1
                continue
            
            _nic = _ob_key_value[_key]
            
            # dhcp
            _key = _key_type+"."+str(_idx)+"."+_KEY_IP_TYPE
            _ip_type = _ob_key_value[_key]
            _is_dhcp = (lambda x: True if str(x).upper() == _VAL_DHCP else False)(_ip_type)
            
            # ip
            _key = _key_type+"."+str(_idx)+"."+_KEY_ADDR
            _addr = (lambda x: None if str(x).strip() == "" else x)(_ob_key_value[_key])
            
            # mask
            _key = _key_type+"."+str(_idx)+"."+_KEY_MASK
            _mask = (lambda x: None if str(x).strip() == "" else x)(_ob_key_value[_key])
            
            # gw
            _key = _key_type+"."+str(_idx)+"."+_KEY_GW
            _gw = (lambda x: None if str(x).strip() == "" else x)(_ob_key_value[_key])
            
            if _is_dhcp :
                _addr = None
                _mask = None
                _gw = None
            
            _oaddr = ob_info.create_addr("%s_%s"%( _name, str(_ext_idx) ), _net_type, _nic, _is_dhcp, 
                                      _addr, _mask, _gw, _br_list[_ext_idx], _mac_info[_nic])
            _ext_list.append(_oaddr)
            
            _idx += 1
            _ext_idx += 1
        return True, _ext_list
    except KeyError, e:
        logger.error("Fail to Set %s Net, No Field, field=%s"%( _type, str(_key) ))
        logger.exception(e)
        return False, "No Field, field=%s"%str(_key)
    except Exception, e:
        logger.error("Fail to Set %s Net, exc=%s"%( _type, str(e) ))
        logger.exception(e)
        return False, str(e)

def _set_ob_info(_ob_info, _ob_key_value, _mac_info, _in_band):
    _key = ""
    try:
        ## OB-ID
        _key = _KEY_OBID
        _ob_id = _ob_key_value[_key]
        
        ## MGMT
        _ret, _res = _set_external_net(_KEY_MGMT, _ob_key_value, _mac_info, _in_band)
        if not _ret :
            return False, _res
        _mgmt_list = _res
        
        ## WAN
        _ret, _res = _set_external_net(_KEY_WAN, _ob_key_value, _mac_info, _in_band)
        if not _ret :
            return False, _res
        _wan_list = _res
        
        ## LAN
        _ret, _rkey, _rval, _res = _get_lan_name(_ob_key_value)
        if not _ret :
            return False, "Invalid LAN Netowrk Data, field=%s, value=%s, error=%s"%( _rkey, _rval, _res )
        _lan_name = _res
        if len(_lan_name) < 1 :
            return False, "No LAN Network(One or More)"
        
        _lan_list = []
        for _lname in _lan_name :
            # nic
            _key = _KEY_LAN+"."+_lname+"."+_KEY_INF
            _val = _ob_key_value[_key]
            
            if _val == None or str(_val).strip() == "" :
                continue
            
            _nics = str(_val).strip().replace(" ", "").split(',')
            
            # gw
            _key = _KEY_LAN+"."+_lname+"."+_KEY_GW
            _gw = _ob_key_value[_key]
            
            # mask
            _key = _KEY_LAN+"."+_lname+"."+_KEY_MASK
            _mask = _ob_key_value[_key]
            
            _net = ob_info.create_net(_lname, oc.VAL_NET_TYPE_LAN, _nics, _gw, _mask)
            _lan_list.append(_net)
        
        ## EVWAN
        _ret, _res = _set_external_net(_KEY_WAN, _ob_key_value, _mac_info, _in_band)
        if not _ret :
            return False, _res
        if type(_res) == list and len(_res) > 0 :
            _ob_info.m_extra_vnf_wan = _res
        
        _ob_info.m_ob_id = _ob_id
        _ob_info.m_mgmt_list = _mgmt_list
        _ob_info.m_wan_list = _wan_list
        _ob_info.m_lan_net_list = _lan_list
        return True, None
    except KeyError, e:
        logger.error("Fail to Set OB-Info, No Field, field=%s"%( str(_key) ))
        logger.exception(e)
        return False, "No Field, field=%s"%str(_key)
    except Exception, e:
        logger.error("Fail to Set OB-Info, exc=%s"%str(e))
        logger.exception(e)
        return False, str(e)

def _edit_external_net_info(_edit_idx, _data_pos, elements, network, item_pos = -1, title = ""):
    nic = ','.join(network.nics())
    ip_dhcp = network.is_dhcp()
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_INF
    itm_nic = (_key, item_pos, 1, nic, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_nic)
    _edit_idx[_key] = _data_pos
    
    if ip_dhcp:
        str_ip_type = _VAL_DHCP
        ip_addr = ""
        ip_subnet = ""
        ip_gateway = ""
    else:
        str_ip_type = _VAL_STATIC
        ip_addr = network.ip()
        ip_subnet = network.mask()
        ip_gateway = network.gw()
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_IP_TYPE
    itm_ip_type = (_key, item_pos, 1, str_ip_type, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_ip_type)
    _edit_idx[_key] = _data_pos
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_ADDR
    itm_ip_addr = (_key, item_pos, 1, ip_addr, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_ip_addr)
    _edit_idx[_key] = _data_pos
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_MASK
    itm_ip_subnet = (_key, item_pos, 1, ip_subnet, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_ip_subnet)
    _edit_idx[_key] = _data_pos
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_GW
    itm_ip_gateway = (_key, item_pos, 1, ip_gateway, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_ip_gateway)
    _edit_idx[_key] = _data_pos
        
    return item_pos, _data_pos

def _edit_internal_net_info(_edit_idx, _data_pos, elements, network, item_pos = -1, title = ""):
    nic = ','.join(network.nics())
    gw_addr = network.gw()
    gw_subnet = network.mask()
    
    str_nic = nic
    if type(nic) is list:
        str_nic = ",".join(nic)  
    else:
        str_nic = nic
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_INF
    itm_nic = (_key, item_pos, 1, str_nic, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_nic)
    _edit_idx[_key] = _data_pos
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_GW
    itm_ip_addr = (_key, item_pos, 1, gw_addr, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_ip_addr)
    _edit_idx[_key] = _data_pos
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_MASK
    itm_ip_subnet = (_key, item_pos, 1, gw_subnet, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_ip_subnet)
    _edit_idx[_key] = _data_pos
    
    return item_pos, _data_pos


def _edit_ob_info(_ob_info, _mac_info):
    try:
        while True :
            _edit_idx = {}
            elements = []
            item_pos = 1
            _data_pos = 0
            
            # onebox_id
            onebox_id = _ob_info.m_ob_id
            itm_onebox_id = (_KEY_OBID, item_pos, 1, onebox_id, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
            elements.append(itm_onebox_id)
            _edit_idx[_KEY_OBID] = _data_pos
            
            # management mode
            in_band = _ob_info.is_in_band()
            if in_band:
                str_mgmt_mode = "In-band"
            else:
                str_mgmt_mode = "Out-of-band"
            item_pos = item_pos + 1
            _data_pos += 1
            itm_mgmt_mode = ("Mode", item_pos, 1, str_mgmt_mode, item_pos, 25, _FIELD_LEN, 0, bv.FORM_ATTR_READONLY)
            elements.append(itm_mgmt_mode)
            
            item_pos += 1
            # mgmt/wan
            _idx = 0
            for emgmt in _ob_info.mgmt_list() :
                _title = _KEY_MGMT+"."+str(_idx)
                item_pos, _data_pos = _edit_external_net_info(_edit_idx, _data_pos, elements, emgmt, item_pos = item_pos, title=_title)
                _idx = _idx + 1
            if not in_band :
                item_pos += 1
                _idx = 0
                for ewan in _ob_info.wan_list() :
                    _title = _KEY_WAN+"."+str(_idx)
                    item_pos, _data_pos = _edit_external_net_info(_edit_idx, _data_pos, elements, ewan, item_pos = item_pos, title=_title)
                    _idx = _idx + 1
            
            # lan
            item_pos += 1
            for _lan in _ob_info.lan_net_list() :
                _title = _KEY_LAN+"."+_lan.name()
                item_pos, _data_pos = _edit_internal_net_info(_edit_idx, _data_pos, elements, _lan, item_pos = item_pos, title=_title)
            
            # evwan
            _evw_list = _ob_info.extra_wan_list()
            _has_evw = False
            if type(_evw_list) == list and len(_evw_list) > 0 :
                _has_evw = True
                item_pos += 1
                _idx = 0
                for _evw in _evw_list :
                    _title = _KEY_EVW+"."+str(_idx)
                    item_pos, _data_pos = _edit_external_net_info(_edit_idx, _data_pos, elements, _evw, item_pos = item_pos, title=_title)
                    _idx = _idx + 1
            
            _ret = bv.show_mixform("Edit One-Box Info", elements)
            if _ret == bv.RET_NO :
                return True
            elif _ret == bv.RET_ERR :
                return False
            else:
                _ob_key_value = {}
                for _iii in range(len(elements)) :
                    for _key in _edit_idx.keys() :
                        if _edit_idx[_key] == _iii :
                            _ob_key_value[_key] = (lambda x: None if x == None else str(x))(_ret[_iii])
                            logger.debug("Edit: %2s-%-22s : %s"%( _iii, _key, _ret[_iii] ))
                            break
                
                _ret, _key, _val, _err = _chk_ob_info(_ob_key_value, in_band, _has_evw)
                if _ret :
                    _ret, _err = _set_ob_info(_ob_info, _ob_key_value, _mac_info, in_band)
                    if _ret :
                        return True
                    else:
                        logger.warning("Fail to Set OB-INFO, err=%s"%_err)
                        bv.alert("Fail to Set OB-INFO, err=%s"%_err)
                else:
                    logger.warning("Fail to Chk OB-INFO, CHK Error, key=%s, val=%s, err=%s"%( _key, _val, _err ))
                    bv.alert("Invalid One-Box Config, field=%s, value=%s, error=%s"%( _key, _val, _err ))
                
                continue
    except Exception, e:
        logger.error("Fail to Edit OB_Info, exc=%s"%str(e))
        logger.exception(e)
        bv.alert("Fail to Edit OB_Info, exc=%s"%str(e))
        return False


def _set_ns_id(ns_id):
    try:
        _file = oc.FILE_STAT_DEF_NS_ID
        if not os.path.exists(os.path.dirname(_file)):
            os.makedirs(os.path.dirname(_file))
        
        _save_data = {oc.STATUS_FLD_DEF_NS_ID: ns_id}
        with open(_file, 'w') as f:
            f.write(json.dumps( _save_data ))
        logger.info("SUCC: Set DEF-NS-ID, file=%s, status=%s"%(_file, str(_save_data)))
        return True
    except Exception, e:
        logger.error("Fail to Set DEF-NS-ID, file=%s, exc=%s"%(_file, str(e)))
        logger.exception(e)
        return False


class OBInstall(_LinkedMenu):
    
    def __init__(self, _prevMenu=None):
        _LinkedMenu.__init__(self, "OBInstall", _prevMenu)
    
    def _select(self, _data):
        _ol = _data[oc.OTAG_LIB_OB]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        if not _data.has_key(_TAG_OVERWRITE) and oc.VAL_DEF_OB_ID != str(_data[oc.OTAG_OBA_INFO].ob_id()) :
#             _ret = bv.confirm_ok("Already First-Installed.\nContinue?")
#             if _ret == bv.RET_OK :
#                 _data[_TAG_OVERWRITE] = True
#             elif _ret == bv.RET_NO :
#                 return self._RET_BACK
#             else:
#                 logger.error("Fail to Confirm Install-Continue")
#                 bv.alert("Fail to Confirm Install-Continue")
#                 return self._RET_ERR
            if _ol.hasUtm(_ob_info.wan_mac_list()) :
                bv.alert("Already First-Installed.\nRetry after Factory-Reset")
                return self._RET_BACK
            else:
                _ret = bv.confirm_ok("Already First-Installed.\nDefault-VNF Create?")
                if _ret == bv.RET_OK :
                    _data[_TAG_AFTER_INSTALL] = True
                    return self._RET_OK
                return self._RET_BACK
        
        _mac_info = _ol.get_host_mac(_nic_model=_ob_info.hw_nic_model())
        if _mac_info == None or len(_mac_info) < 1 :
            logger.error("No Mac Info")
            bv.alert("No Mac Info")
            return self._RET_ERR
        
        _data[_TAG_MAC_INFO] = _mac_info
        _init = (lambda x: x[_TAG_OBID] if x.has_key(_TAG_OBID) else '')(_data)
        while True :
            _ret, _ob_id = bv.input_text("Input One-Box ID", _init)
            if _ret == bv.RET_NO :
                return self._RET_BACK
            elif _ret == bv.RET_ERR :
                return self._RET_ERR
            else:
                if _ob_id == None or str(_ob_id).strip() == "" :
                    logger.warning("Fail to Get OB ID, id=%s"%str(_ob_id))
                    bv.alert("Invalid OB ID, id=%s\nRetry."%str(_ob_id))
                    continue
                _data[_TAG_OBID] = str(_ob_id).strip()
                return self._RET_OK
    
    def _next(self, _ret, _data):
        if self._PREV_CLS.__class__ == _OBNetReview :
            return self._PREV_CLS.get_res(_data)
        
        if _data.has_key(_TAG_AFTER_INSTALL) :
            return _OBDefaultVNFSelect().get_res(_data)
        else:
            return _OBMgmtMode(self).get_res(_data)


class _OBMgmtMode(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBMgmtMode", _prevMenu)
    
    def _select(self, _data):
        _ret = bv.get_menu("Select Management Mode", [("1", "In-Band Management"), ("2", "Out-of-Band Management")])
        if _ret == bv.RET_ERR :
            return self._RET_ERR
        elif _ret == bv.RET_NO :
            return self._RET_BACK
        else:
            return _ret
    
    def _next(self, _ret, _data):
        if _ret == None or str(_ret).strip() == "" :
            logger.error("Fail to Get Management Mode, mode_num=%s"%str(_ret))
            bv.alert("Fail to Get Management Mode, mode_num=%s"%str(_ret))
            return self._RET_ERR
        else:
            _mm = str(_ret).strip()
            if _mm == "1" :
                _data[_TAG_IS_IN_BAND] = True
            elif _mm == "2" :
                _data[_TAG_IS_IN_BAND] = False
            else:
                logger.error("Fail to Get Management Mode, invalid_mode_num=%s"%str(_ret))
                bv.alert("Fail to Get Management Mode, invalid_mode_num=%s"%str(_ret))
                return self._RET_ERR
            
            return _OBWanConfig(self).get_res(_data)


class _OBWanConfig(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBWanConfig", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _selected_nics = []
        _mgmtList = (lambda x: x[_TAG_MGMT_LIST] if x.has_key(_TAG_MGMT_LIST) else [])(_data)
        _wanList = (lambda x: x[_TAG_WAN_LIST] if x.has_key(_TAG_WAN_LIST) else [])(_data)
        _mgmt_idx = 0
        _wan_idx = 0
        try:
            if _data[_TAG_IS_IN_BAND] :
                _title = "Management/Wan"
                while True:
                    ## select nic
                    _ret, _mnic, _mmac, _mconn, _remain = _bl.get_host_nic(_title + "-%s Interface Select"%str(_mgmt_idx), _selected_nics, _nic_model=_ob_info.hw_nic_model())
                    if _ret == self._RET_OK and _mconn == False :
                        _cret = bv.confirm_ok("Interface is not Connected.\nConitnue?")
                        if _cret != bv.RET_OK :
                            continue
                    
                    if _ret == self._RET_BACK :
                        if _mgmt_idx <= 0 :
                            return self._RET_BACK
                        try:
                            _selected_nics.pop()
                        except IndexError:
                            pass
                        _mgmt_idx = max(0, _mgmt_idx-1)
                        continue
                    elif _ret == self._RET_ERR :
                        return self._RET_ERR
                    
                    if _remain < 1 :
                        logger.warning("Fail to Config %s, NO Available Host Interface for LAN"%_title)
                        bv.confirm_ok("NO Available Host Interface for LAN.\nRetry..")
                        if _mgmt_idx <= 0 :
                            return self._RET_BACK
                        try:
                            _selected_nics.pop()
                        except IndexError:
                            pass
                        _mgmt_idx = max(0, _mgmt_idx-1)
                        continue
                    
                    ## config network
                    if len(_mgmtList) > _mgmt_idx :
                        # overwrite ip info...
                        _prvnet = _mgmtList[_mgmt_idx]
                        _maddr = ob_info.create_addr("mgmt_%s"%str(_mgmt_idx), oc.VAL_NET_TYPE_MGMT, _mnic, _prvnet.is_dhcp(), 
                                                   _ip=_prvnet.ip(), _mask=_prvnet.mask(), _gw=_prvnet.gw(), 
                                                   _dev=oc.VAL_DEF_OS_BR_LIST[_mgmt_idx], _mac=_mmac, _vlan=_prvnet.vlan())
                    else:
                        _maddr = ob_info.create_addr("mgmt_%s"%str(_mgmt_idx), oc.VAL_NET_TYPE_MGMT, _mnic, None, 
                                                   _dev=oc.VAL_DEF_OS_BR_LIST[_mgmt_idx], _mac=_mmac)
                    _ret = _bl.set_extern_ip(_title + "-%s IP Config"%str(_mgmt_idx), _maddr)
                    
                    if _ret == self._RET_OK :
                        _waddr = ob_info.create_addr("wan_%s"%str(_mgmt_idx), oc.VAL_NET_TYPE_WAN, _maddr.nic(), _maddr.is_dhcp(),
                                                     _ip=_maddr.ip(), _mask=_maddr.mask(), _gw=_maddr.gw(), 
                                                     _dev=oc.VAL_DEF_VI_WAN_BR_LIST[_mgmt_idx], _mac=_maddr.mac(), _vlan=_maddr.vlan() )
                        if len(_mgmtList) >= (_mgmt_idx + 1) :
                            _mgmtList[_mgmt_idx] = _maddr
                            _wanList[_mgmt_idx] = _waddr
                        else:
                            _mgmtList.append(_maddr)
                            _wanList.append(_waddr)
                        
                        _selected_nics.append(_mnic)
                        
                        if (_mgmt_idx+1) >= oc.VAL_WAN_MAX_NUM :
                            break
                        
                        _ret = bv.confirm_ok("Add Extra-%s Interface?"%_title)
                        if _ret == bv.RET_ERR :
                            return self._RET_ERR
                        elif _ret == bv.RET_NO :
                            break
                        
                        _mgmt_idx += 1
                        continue
                    elif _ret == self._RET_BACK :
                        continue
                    else :
                        return self._RET_ERR
            else:
                _title = "Management"
                _net_mode = oc.VAL_NET_TYPE_MGMT
                while True:
                    ## determine mode
                    if _net_mode == oc.VAL_NET_TYPE_MGMT :
                        _title = "Management"
                        _idx = _mgmt_idx
                        _net_list = _mgmtList
                        _br_list = oc.VAL_DEF_OS_BR_LIST
                    else:
                        _title = "WAN"
                        _idx = _wan_idx
                        _net_list = _wanList
                        _br_list = oc.VAL_DEF_VI_WAN_BR_LIST
                    
                    ## select nic
                    _ret, _nic, _mac, _conn, _remain = _bl.get_host_nic(_title + "-%s Interface Select"%str(_idx), _selected_nics, _nic_model=_ob_info.hw_nic_model())
                    if _ret == self._RET_OK and _conn == False :
                        _cret = bv.confirm_ok("Interface is not Connected.\nConitnue?")
                        if _cret != bv.RET_OK :
                            _ret = self._RET_BACK
                    
                    if _ret == self._RET_BACK :
                        if _net_mode == oc.VAL_NET_TYPE_MGMT :
                            if _idx <= 0 :
                                return self._RET_BACK
                            else:
                                _mgmt_idx = max(0, _mgmt_idx-1)
                        elif _net_mode == oc.VAL_NET_TYPE_WAN :
                            if _idx <= 0 :
                                _net_mode = oc.VAL_NET_TYPE_MGMT
                            _wan_idx = max(0, _wan_idx-1)
                        
                        try:
                            _selected_nics.pop()
                        except IndexError:
                            pass
                        continue
                    elif _ret == self._RET_ERR :
                        return self._RET_ERR
                    
                    if _remain < 1 :
                        if _net_mode == oc.VAL_NET_TYPE_MGMT :
                            logger.warning("Fail to Config %s, NO Available Host Interface for WAN"%_title)
                            bv.confirm_ok("NO Available Host Interface for WAN.\nRetry..")
                        else:
                            logger.warning("Fail to Config %s, NO Available Host Interface for LAN"%_title)
                            bv.confirm_ok("NO Available Host Interface for LAN.\nRetry..")
                        
                        if _net_mode == oc.VAL_NET_TYPE_MGMT :
                            if _idx <= 0 :
                                return self._RET_BACK
                            else:
                                _mgmt_idx = max(0, _mgmt_idx-1)
                        elif _net_mode == oc.VAL_NET_TYPE_WAN :
                            if _idx <= 0 :
                                _net_mode = oc.VAL_NET_TYPE_MGMT
                            _wan_idx = max(0, _wan_idx-1)
                        
                        try:
                            _selected_nics.pop()
                        except IndexError:
                            pass
                        continue
                    
                    ## config network
                    if len(_net_list) > _idx :
                        # overwrite ip
                        _prvnet = _net_list[_idx]
                        _oaddr = ob_info.create_addr("%s_%s"%(_net_mode, str(_idx)), _net_mode, _nic, _prvnet.is_dhcp(), 
                                                   _ip=_prvnet.ip(), _mask=_prvnet.mask(), _gw=_prvnet.gw(), 
                                                   _dev=_br_list[_idx], _mac=_mac, _vlan=_prvnet.vlan())
                    else:
                        _oaddr = ob_info.create_addr("%s_%s"%(_net_mode, str(_idx)), _net_mode, _nic, None, 
                                                   _dev=_br_list[_idx], _mac=_mac)
                    _ret = _bl.set_extern_ip(_title + " IP Config", _oaddr)
                    
                    if _ret == self._RET_OK :
                        if len(_net_list) >= (_idx + 1) :
                            _net_list[_idx] = _oaddr
                        else:
                            _net_list.append(_oaddr)
                        _selected_nics.append(_nic)
                        
                        if _net_mode == oc.VAL_NET_TYPE_WAN and (_idx+1) >= oc.VAL_WAN_MAX_NUM :
                            break
                        if _net_mode == oc.VAL_NET_TYPE_MGMT and (_idx+1) >= oc.VAL_WAN_MAX_NUM :
                            _net_mode = oc.VAL_NET_TYPE_WAN
                            continue
                        
                        _ret = bv.confirm_ok("Add Extra-%s Interface?"%_title)
                        if _ret == bv.RET_ERR :
                            return self._RET_ERR
                        elif _ret == bv.RET_NO :
                            if _net_mode == oc.VAL_NET_TYPE_WAN :
                                break
                            elif _net_mode == oc.VAL_NET_TYPE_MGMT :
                                _net_mode = oc.VAL_NET_TYPE_WAN
                                continue
                        
                        if _net_mode == oc.VAL_NET_TYPE_MGMT : _mgmt_idx += 1
                        elif _net_mode == oc.VAL_NET_TYPE_WAN : _wan_idx += 1
                        continue
                    elif _ret == self._RET_BACK :
                        continue
                    else :
                        return self._RET_ERR
            
            _rm_cnt = len(_mgmtList) - ( 1 + _mgmt_idx )
            for _tmp in range(_rm_cnt) :
                _mgmtList.pop()
            
            if _data[_TAG_IS_IN_BAND] :
                _wan_idx = _mgmt_idx
            
            _rm_cnt = len(_wanList) - ( 1 + _wan_idx )
            for _tmp in range(_rm_cnt) :
                _wanList.pop()
            
            _data[_TAG_WAN_NIC_LIST] = _selected_nics
            _data[_TAG_MGMT_LIST] = _mgmtList
            _data[_TAG_WAN_LIST] = _wanList
            
            logger.info("  - Selected WAN NIC: %s"%str(_selected_nics))
            logger.info("  - Selected Mgmt: %s"%str(_mgmtList))
            logger.info("  - Selected WAN: %s"%str(_wanList))
            
            return self._RET_OK
        except Exception, e:
            logger.error("Fail to Config Mgmt/WAN, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Config Mgmt/WAN, exc=%s"%str(e))
            return self._RET_ERR
    
    def _next(self, _ret, _data):
        # LAN NIC CHECK
        if _data.has_key(_TAG_LAN_NIC_LIST) :
            for _wan_nic in _data[_TAG_WAN_NIC_LIST] :
                if _wan_nic in _data[_TAG_LAN_NIC_LIST] :
                    bv.confirm_ok("[WARNING] %s Interfaces Duplicated\nRe-Configure LAN..."%_wan_nic)
                    return _OBLanConfig(self).get_res(_data)
        
        # EVWAN NIC CHECK
        if _data.has_key(_TAG_EVW_NIC_LIST) :
            for _wan_nic in _data[_TAG_WAN_NIC_LIST] :
                if _wan_nic in _data[_TAG_EVW_NIC_LIST] :
                    bv.confirm_ok("[WARNING] %s Interfaces Duplicated\nRe-Configure EVWan..."%_wan_nic)
                    return _OBEVWanConfig(self).get_res(_data)
        
        if self._PREV_CLS.__class__ == _OBNetReview :
            return self._PREV_CLS.get_res(_data)
        
        return _OBLanConfig(self).get_res(_data)



class _OBLanConfig(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBLanConfig", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        import copy
        _wan_selected_nics = copy.deepcopy(_data[_TAG_WAN_NIC_LIST])
        _selected_nics = []
        _prev_selected_nics = []
        try:
            _lanList = (lambda x: x[_TAG_LAN_LIST] if x.has_key(_TAG_LAN_LIST) else [])(_data)
            _idx = 0
            _title = 'LAN'
            _names = _VAL_LAN_DEFAULT
            _permit_no_nic = False
            _no_evw_avail_nic = False
            while True :
                if _idx < 1 :
                    _permit_no_nic = False
                else:
                    _permit_no_nic = True
                
                ## LAN Name select
                if _idx < 2 :
                    _name = _names[_idx]
                else:
                    if len(_names) > (_idx+1) :
                        _name = _names[_idx]
                    else:
                        _name = ''
                    
                    _ret, _name = bv.input_text("Input LAN Name", _name)
                    if _ret == bv.RET_OK :
                        if _name == None or str(_name).strip() == "" or str(_name).strip() in _names :
                            bv.alert("LAN Name is not valid. Retry")
                            continue
                    elif _ret == bv.RET_NO :
                        _idx = min(0, _idx-1)
                        continue
                    else:
                        bv.alert("LAN Name Error. Retry")
                        continue
                    
                    _name = str(_name).strip()
                    _names.append(_name)
                
                ## select nic
                _ret, _nics, _macs, _conns, _remain = _bl.get_host_nic(_title + "-%s Interface Select"%_name, 
                                                                       (_wan_selected_nics+_selected_nics), True, False, permit_no_nic=_permit_no_nic, _nic_model=_ob_info.hw_nic_model())
                if _remain < 1 :
                    _no_evw_avail_nic = True
                else:
                    _no_evw_avail_nic = False
                
                if _ret == self._RET_BACK :
                    if _idx <= 0 :
                        return self._RET_BACK
                    try:
                        _selected_nics = copy.deepcopy(_prev_selected_nics)
                    except IndexError:
                        pass
                    _idx = max(0, _idx-1)
                    continue
                elif _ret == self._RET_ERR :
                    return self._RET_ERR
                
                
                ## config network
                if len(_lanList) > _idx :
                    # overwrite ip info...
                    _prvnet = _lanList[_idx]
                    _net = ob_info.create_net(_name, oc.VAL_NET_TYPE_LAN, _nics, _gw=_prvnet.gw(), _mask=_prvnet.mask(), 
                                               _dev=_prvnet.bridge(), _mac=_prvnet.mac(), _vlan=_prvnet.vlan())
                else:
                    _net = ob_info.create_net(_name, oc.VAL_NET_TYPE_LAN, _nics, _gw="192.168.%s.1"%str(_idx), _mask="255.255.255.0")
                
                _no_avail_nic = False
                if _remain < 0 :
                    _no_avail_nic = True
                    bv.confirm_ok("No Available Interface\nConfig %s Network.."%str(_name))
                _ret = _bl.set_lan_ip(_title + "-%s Network Config"%_name, _net)
                
                if _ret == self._RET_OK :
                    if len(_lanList) >= (_idx + 1) :
                        _lanList[_idx] = _net
                    else:
                        _lanList.append(_net)
                    
                    _prev_selected_nics = copy.deepcopy(_selected_nics)
                    if _nics != None : _selected_nics += _nics
                    
#                     if _remain < 1 :
#                         if _idx > 1 :
#                             break
#                         else:
#                             _ret = bv.confirm_ok("NO Available Interface.\nDo Next Step?")
#                             if _ret == bv.RET_OK :
#                                 break
#                             elif _ret == bv.RET_NO :
#                                 try:
#                                     _selected_nics = copy.deepcopy(_prev_selected_nics)
#                                 except IndexError:
#                                     pass
#                                 _idx = max(0, _idx-1)
#                                 continue
#                             else:
#                                 return self._RET_ERR
                    
                    ## next version
                    if _idx > 0 :
                        break
                    
#                     _ret = bv.confirm_ok("Add Extra-%s Interface?"%_title)
#                     if _ret == bv.RET_ERR :
#                         return self._RET_ERR
#                     elif _ret == bv.RET_NO :
#                         break
                    
                    _idx += 1
                    continue
                elif _ret == self._RET_BACK :
                    if _no_avail_nic :
                        try:
                            _selected_nics = copy.deepcopy(_prev_selected_nics)
                        except IndexError:
                            pass
                        _idx = max(0, _idx-1)
                    continue
                else :
                    return self._RET_ERR
            
            _rm_cnt = len(_lanList) - ( 1 + _idx )
            for _tmp in range(_rm_cnt) :
                _lanList.pop()
            
            _data[_TAG_LAN_LIST] = _lanList
            _data[_TAG_LAN_NIC_LIST] = _selected_nics
            _data[_TAG_NO_AVAIL_NIC] = _no_evw_avail_nic
            
            logger.info("  - Selected LAN: %s"%str(_lanList))
            return self._RET_OK
        except Exception, e:
            logger.error("Fail to Config LAN, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Config LAN, exc=%s"%str(e))
            return self._RET_ERR
    
    def _next(self, _ret, _data):
        # EVWAN NIC CHECK
        if _data.has_key(_TAG_EVW_NIC_LIST) :
            for _wan_nic in _data[_TAG_WAN_NIC_LIST] :
                if _wan_nic in _data[_TAG_EVW_NIC_LIST] :
                    bv.confirm_ok("[WARNING] %s Interfaces Duplicated\nRe-Configure EVWan..."%_wan_nic)
                    return _OBEVWanConfig(self).get_res(_data)
            
            for _lan_nic in _data[_TAG_LAN_NIC_LIST] :
                if _lan_nic in _data[_TAG_EVW_NIC_LIST] :
                    bv.confirm_ok("[WARNING] %s Interfaces Duplicated\nRe-Configure EVWan..."%_lan_nic)
                    return _OBEVWanConfig(self).get_res(_data)
        
        if self._PREV_CLS.__class__ == _OBNetReview :
            return self._PREV_CLS.get_res(_data)
        
        return _OBEVWanConfig(self).get_res(_data)



class _OBEVWanConfig(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBEVWanConfig", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _ret = bv.confirm_ok("Set Extra-WAN For Extra-VNF?")
        if _ret == bv.RET_NO :
            return self._RET_OK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        
        if _data[_TAG_NO_AVAIL_NIC] :
            _ret = bv.confirm_ok("No Available Interface..\nBack to LAN Config?")
            if _ret == bv.RET_NO :
                return self._RET_OK
            elif _ret == bv.RET_OK :
                return self._RET_BACK
            else:
                return self._RET_ERR
        
        import copy
        _wan_selected_nics = copy.deepcopy(_data[_TAG_WAN_NIC_LIST])
        _lan_selected_nics = copy.deepcopy(_data[_TAG_LAN_NIC_LIST])
        _selected_nics = []
        _prev_selected_nics = []
        try:
            _evwList = (lambda x: x[_TAG_EVW_LIST] if x.has_key(_TAG_EVW_LIST) else [])(_data)
            _idx = 0
            _title = 'Extra-VNF WAN'
            _name_pfx = "evwan-%s"
            while True :
                ## select nic
                _ret, _nic, _mac, _conn, _remain = _bl.get_host_nic(_title + "-%s Interface Select"%str(_idx), (_wan_selected_nics+_lan_selected_nics+_selected_nics), _nic_model=_ob_info.hw_nic_model())
                
                if _ret == self._RET_BACK :
                    if _idx <= 0 :
                        return self._RET_BACK
                    try:
                        _selected_nics = copy.deepcopy(_prev_selected_nics)
                    except IndexError:
                        pass
                    _idx = max(0, _idx-1)
                    continue
                elif _ret == self._RET_ERR :
                    return self._RET_ERR
                
                ## config network
                if len(_evwList) > _idx :
                    # overwrite ip info...
                    _prvnet = _evwList[_idx]
                    _addr = ob_info.create_addr(_name_pfx%str(_idx), oc.VAL_NET_TYPE_EVWAN, _nic, _prvnet.is_dhcp(), 
                                               _ip=_prvnet.ip(), _mask=_prvnet.mask(), _gw=_prvnet.gw(), 
                                               _dev=oc.VAL_DEF_VI_EWAN_BR_LIST[_idx], _mac=_mac, _vlan=_prvnet.vlan())
                else:
                    _addr = ob_info.create_addr(_name_pfx%str(_idx), oc.VAL_NET_TYPE_EVWAN, _nic, None, _dev=oc.VAL_DEF_VI_EWAN_BR_LIST[_idx], _mac=_mac)
                _ret = _bl.set_extern_ip(_title + "-%s IP Config"%str(_idx), _addr)
                
                if _ret == self._RET_OK :
                    if len(_evwList) >= (_idx + 1) :
                        _evwList[_idx] = _addr
                    else:
                        _evwList.append(_addr)
                    
                    _prev_selected_nics = copy.deepcopy(_selected_nics)
                    if _nic != None : _selected_nics.append(_nic)
                    
                    ## next version
                    if _idx >= oc.VAL_EVWAN_MAX_NUM - 1 :
                        break
                    
                    _ret = bv.confirm_ok("Add %s Interface?"%_title)
                    if _ret == bv.RET_ERR :
                        return self._RET_ERR
                    elif _ret == bv.RET_NO :
                        break
                    else:
                        if _remain < 1 :
                            _ret = bv.confirm_ok("No Available Interface..\nBack to LAN Config?")
                            if _ret == bv.RET_OK :
                                return self._RET_BACK
                            elif _ret == bv.RET_NO :
                                break
                            else:
                                return self._RET_ERR
                    _idx += 1
                    continue
                elif _ret == self._RET_BACK :
                    try:
                        _selected_nics = copy.deepcopy(_prev_selected_nics)
                    except IndexError:
                        pass
                    _idx = max(0, _idx-1)
                    continue
                else :
                    return self._RET_ERR
            
            _rm_cnt = len(_evwList) - ( 1 + _idx )
            for _tmp in range(_rm_cnt) :
                _evwList.pop()
            
            _data[_TAG_EVW_LIST] = _evwList
            _data[_TAG_EVW_NIC_LIST] = _selected_nics
            
            logger.info("  - Selected EVWan: %s"%str(_evwList))
            return self._RET_OK
        except Exception, e:
            logger.error("Fail to Config EVWan, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Config EVWan, exc=%s"%str(e))
            return self._RET_ERR
    
    def _next(self, _ret, _data):
        if self._PREV_CLS.__class__ == _OBNetReview :
            return self._PREV_CLS.get_res(_data)
        return _OBVetConfig(self).get_res(_data)



class _OBVetConfig(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBVetConfig", _prevMenu)
    
    def _select(self, _data):
        _ol = _data[oc.OTAG_LIB_OB]
        
        try:
            _ovs_dpdk, _err = _ol.is_enable_ovs_dpdk()
            _data[_TAG_VET_OVS_DPDK] = _ovs_dpdk
            logger.info("SUCC: VET-Config, ovs-dpdk: %s"%str(_ovs_dpdk))
            if _ovs_dpdk :
                bv.notify("VNet Accelerator is Used..\n[Accelerator: OVS-DPDK]")
            
            return self._RET_OK
        except Exception, e:
            logger.error("Fail to Set Vet-Config, exc=%s"%str(e))
            logger.exception(e)
            return self._RET_ERR
    
    def _next(self, _ret, _data):
        return _OBNetReview(self).get_res(_data)


class _OBNetReview(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBNetReview", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        
        _f_ob_info = ob_info.OB_INFO().loadByFile(oc.FILE_OBA_CONF, True)

        _f_ob_info.m_ob_id = _data[_TAG_OBID]
        _f_ob_info.m_in_band = _data[_TAG_IS_IN_BAND]
        _f_ob_info.m_mgmt_list = _data[_TAG_MGMT_LIST]
        _f_ob_info.m_wan_list = _data[_TAG_WAN_LIST]
        _f_ob_info.m_lan_net_list = _data[_TAG_LAN_LIST]
        _f_ob_info.c_wan_info.set_wan_sw( (True if _f_ob_info.m_in_band else False) )
        if _data.has_key(_TAG_VET_OVS_DPDK) and _data[_TAG_VET_OVS_DPDK] == True : _f_ob_info.set_vet_mode(_ovs_dpdk={})
        if _data.has_key(_TAG_EVW_LIST) and len(_data[_TAG_EVW_LIST]) > 0 : _f_ob_info.m_extra_vnf_wan = _data[_TAG_EVW_LIST]
        
        while True:
            if _bl.show_obinfo(_f_ob_info) :
                if bv.confirm_ok("Apply new configuration?") == bv.RET_OK :
                    if _f_ob_info.sync_internet(_logger=logger) :
                        _data[_TAG_NEW_OB_INFO] = _f_ob_info
                        return self._RET_OK
                    else:
                        logger.error("Fail to Sync OB-INFO")
                        bv.alert("Fail to Sync OB-INFO")
                        return self._RET_ERR
                else:
                    continue
            
            _ret = bv.get_menu("Select Point to Go Back ", [("1", "One-Box ID"), 
                                                            ("2", "Internet Config"),
                                                            ("3", "LAN Config"),
                                                            ("4", "EVWan Config"),
                                                            ("0", "Edit Directly")])
            if _ret == bv.RET_NO :
                continue
            elif _ret == bv.RET_ERR :
                return self._RET_ERR
            else:
                if _ret == "1" : return OBInstall(self).get_res(_data)
                elif _ret == "2" : return _OBWanConfig(self).get_res(_data)
                elif _ret == "3" : return _OBLanConfig(self).get_res(_data)
                elif _ret == "4" : return _OBEVWanConfig(self).get_res(_data)
                elif _ret == "0" : 
                    if _edit_ob_info(_f_ob_info, _data[_TAG_MAC_INFO]) :
                        continue
                    else:
                        return self._RET_ERR
                else:
                    return self._RET_ERR
        
    def _next(self, _ret, _data):
        return _OBFirstInstall(self).get_res(_data)

class _OBFirstInstall(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBFirstInstall", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ol = _data[oc.OTAG_LIB_OB]
        _ob_info = _data[_TAG_NEW_OB_INFO]

        _tenant = _ob_info.vim_tenant()
        _tUser = _ob_info.vim_tenant_user()
        _tPass = _ob_info.vim_tenant_pass()

        _in_band = _ob_info.is_in_band()
        _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
        _wan_mode = _ol.getWanMode(_ob_info)
        _net_state_info = OB_NET().init(_in_band, _ob_info.utm_local_ip(), _has_utm, _wan_mode, _ob_info.mgmt_list(), _ob_info.wan_list(), _ob_info.extra_wan_list())
        _m_nic, _m_ip = _net_state_info.get_mgmt_ip()
        if _m_ip == None or str(_m_ip).strip() ==  "" :
            _net_state_info.set_fake_wan(_ob_info.lan_net_list())
            _m_nic, _m_ip = _net_state_info.get_mgmt_ip()
        _fake_ip = _m_ip
        if _fake_ip == None :
            logger.warning("Fail to Get MainIP, net-info=%s"%str(_net_state_info))
        _data[_TAG_FAKE_NET] = _net_state_info

        _ob_info.set_plugin_noutm()

        # update this hw, os, plugin, vim_ver
        _ob_info.m_os = _ol.get_os_info()
        _ob_info.m_hw = _ol.get_hw_info(_ob_info)
        _ob_info.set_vim_version()
        _ob_info.set_plugin_os()

        _ret = _bl.apply_config(_ob_info, _tenant, _tUser, _tPass, _fake_ip, True)

        if not _ret :
            return self._RET_ERR
        else:
            if bv.confirm_ok("Default-VNF Create?") == bv.RET_OK :
                _data[_TAG_DEF_VNF_CREATE] = True
                return self._RET_OK
            else:
                _bl.set_onebox_services([oc.VAL_OBA_NAME], False)
                _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True)
                if not _ret :
                    logger.error("Fail to Restart OneBox-Agent, err=%s"%( _err ))
                    _ret = bv.confirm_ok("OneBox-Agent Restart Error.\nContinue First-Install?")
                    if _ret != bv.RET_OK :
                        return self._RET_ERR
                return self._RET_OK
    
    def _next(self, _ret, _data):
        if _data.has_key(_TAG_DEF_VNF_CREATE) and _data[_TAG_DEF_VNF_CREATE] == True :
            return _OBDefaultVNFSelect().get_res(_data)
        else:
            return self._RET_OK


class _OBDefaultVNFSelect(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "OBDefaultVNFSelect", None)
    
    def _get_vnf_list(self, _head, _url):
        try:
            _ret, _ecode, _res = rest_api.sendReq(_head, _url, "GET", cCrt=oc.KEY_CLI_CRT, cKey=oc.KEY_CLI_KEY, _to=15)
            if _ecode != 200 or not _ret or type(_res) != list :
                _err = "Fail to Get Default-VNF List, ret=%s, ecd=%s, res=%s"%( str(_ret), str(_ecode), str(_res) )
                logger.error(_err)
                return False, _err
            return True, _res
        except Exception, e:
            _err = "Fail to Get Default-VNF List, exc=%s"%str(e)
            logger.error(_err)
            logger.exception(e)
            return False, _err
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        
        _do_ret, _start_oba = self._do(_data)
        if _start_oba :
            _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True)
            if not _ret :
                bv.alert("Fail to Start OneBox-Agent, Execute OneBox-Agent Manually\n[cmd='service onebox-agent start']")
        return _do_ret
            
    def _do(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
#         _bl = _data[oc.OTAG_LIB_BTA]
#         _ol = _data[oc.OTAG_LIB_OB]
        
        try:
            _prog = bv.ProgBarInfo("Get Default-VNF List")
            bv.start_progBar(_prog.title(), _prog.title())
            _prog.set_perc(5)
            
            _head = oc.HEADER
            _url = _ob_info.url_vnfm("127.0.0.1") + _URL_VNF_SELECT
            _idx = 0
            _vnf_list = None
            while True:
                _prog.inc(2)
                bv.update_progBar(_prog, "Get Default-VNF List..., retry=%s"%( str(_idx) ))
                
                _ret, _res = self._get_vnf_list(_head, _url)
                if not _ret :
                    if bv.confirm_ok(_res + "\nRetry the VNF-List?") == bv.RET_OK :
                        _idx += 1
                        sleep(2)
                        continue
                    else:
                        bv.alert(_res)
                        return self._RET_ERR, True
                
                _vnf_list = _res
                break
            _prog.set_perc(100)
            bv.stop_progBar()
            
            _menu = []
            _idx = 0
            for _vnf in _vnf_list :
                _menu.append( (str(_idx), _vnf['display_name'] ))
                _idx += 1
            
            _sidx = 0
            while True :
                _ret = bv.get_menu("Select Default VNF", _menu)
                if _ret in [ bv.RET_NO, bv.RET_ERR ] :
                    if bv.confirm_ok("Exit Default-VNF Install?") == bv.RET_OK :
                        return self._RET_OK, True
                    else:
                        continue
                
                try:
                    _sidx = int(_ret)
                    _vnf_info = _vnf_list[_sidx]
                    _cret = bv.confirm_ok("Install Default-VNF, %s ?"%str(_vnf_info['display_name']))
                    if _cret in [ bv.RET_NO, bv.RET_ERR ] :
                        continue
                    
                    break
                except Exception, e:
                    _err = "Fail to Select Default-VNF, ret=%s, err=%s"%( str(_ret), str(e) )
                    logger.error(_err)
                    bv.alert(_err+"\nRetry...")
            
            logger.info(" - Recv VNF-List, idx=%s, list=%s"%( str(_sidx), str(_vnf_list) ))
            _vnf_info = _vnf_list[_sidx]
            vnf_type = str(_vnf_info['vnf_type'])
            vnf_model = str(_vnf_info['vnf_model'])
            vnf_version = str(_vnf_info['vnf_version'])
            vnf_vendor = (str(_vnf_info['vnf_vendor']) if _vnf_info.has_key('vnf_vendor') else None)
            
            vnf_ip = ( str(_vnf_info['vnf_local_ip']) if _vnf_info.has_key('vnf_local_ip') else None )
            vnf_id = (str(_vnf_info['vnf_id']) if _vnf_info.has_key('vnf_id') else None)
            vnf_pw = (str(_vnf_info['vnf_pwd']) if _vnf_info.has_key('vnf_pwd') else None)
            
            vnf_wan_list = _ob_info.wan_list()
            br_list = []
            for _wan in vnf_wan_list :
                br_list.append(_wan.bridge())
            
            _pcfg = {oc.CFG_PLUGIN_CFG_WAN: br_list, oc.CFG_PLUGIN_CFG_MD: vnf_model, oc.CFG_PLUGIN_CFG_VER: vnf_version}
            if vnf_vendor != None : _pcfg[oc.CFG_PLUGIN_CFG_VD] = vnf_vendor
            if vnf_ip != None : _pcfg[oc.CFG_PLUGIN_CFG_IP] = vnf_ip
            if vnf_id != None : _pcfg[oc.CFG_PLUGIN_CFG_ID] = vnf_id
            if vnf_pw != None : _pcfg[oc.CFG_PLUGIN_CFG_PW] = vnf_pw
            
            _pfile = oc.GET_PFILE(vnf_model)
            if _pfile == None :
                _err = "Unknown VNF Info, model=%s"%str(vnf_model)
                logger.error(_err)
                bv.alert(_err)
                return self._RET_ERR, True
            
            _data[_TAG_DEF_VNF_MODEL] = vnf_model
            _data[_TAG_DEF_VNF_VER] = vnf_version
            _data[_TAG_DEF_VNF_TYPE] = vnf_type
            _data[_TAG_DEF_VNF_PFILE] = _pfile
            _data[_TAG_DEF_VNF_CFG] = _pcfg
            _data[_TAG_DEF_VNF_LOC_IP] = vnf_ip
            _data[_TAG_DEF_VNF_ID] = vnf_id
            _data[_TAG_DEF_VNF_PW] = vnf_pw
            
            return self._RET_OK, False
        except Exception, e:
            logger.error("Fail to Get Default-VNF List, exc=%s"%str(e))
            logger.exception(e)
            return self._RET_ERR, True
        
    def _next(self, _ret, _data):
        return _OBDefaultVNFCreate(self).get_res(_data)


class _OBDefaultVNFCreate(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBDefaultVNFCreate", _prevMenu)
    
    def _select(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ol = _data[oc.OTAG_LIB_OB]
        
        if _ol.hasUtm(_ob_info.wan_mac_list()) :
            bv.alert("VNF Already Exist.")
            return self._RET_ERR
        
        _bl.set_onebox_services([oc.VAL_OBA_NAME], False)
        _c_ret = self._createVNF(_data)
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True)
        if not _ret :
            bv.alert("Fail to Start OneBox-Agent, Execute OneBox-Agent Manually\n[cmd='service onebox-agent start']")
        return _c_ret
    
    def _createVNF(self, _data):
        _data[bc.FUNC_TITLE] = "Default-VNF Create"
        _ol = _data[oc.OTAG_LIB_OB]
        if _data.has_key(_TAG_AFTER_INSTALL) :
            _ob_info = _data[oc.OTAG_OBA_INFO]
        else:
            _ob_info = _data[_TAG_NEW_OB_INFO]
        
        _jid = None
        try:
            ## Dummy-Info Setting
            if _data.has_key(_TAG_FAKE_NET) :
                _net_state_info = _data[_TAG_FAKE_NET]
            else:
                _in_band = _ob_info.is_in_band()
                _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
                _wan_mode = _ol.getWanMode(_ob_info)
                _net_state_info = OB_NET().init(_in_band, _ob_info.utm_local_ip(), _has_utm, _wan_mode, _ob_info.mgmt_list(), _ob_info.wan_list(), _ob_info.extra_wan_list())
            
            _obid = _ob_info.ob_id()
            _fake = None
            while True :
                _remain = _net_state_info.set_fake_wan(_ob_info.lan_net_list(), _fake)
                if _remain < 1:
                    break
                
                logger.wanring("Fail to Request Default-VNF, Dummy Network Setting Error, remain=%s"%str(_remain))
                bv.alert("Fail to Request Default-VNF, Dummy Network Setting Error\nInput WAN-Info")
                
                while True:
                    _wan_set = []
                    for _ii in range(_remain) :
                        _iidx = _ii+1
                        _wan_set.append(('Network', _iidx, 1, "10.10.%s.0"%str(_iidx), _iidx, 20, 20, 15))
                    _ret = bv.show_form("Fake WAN-IP Setting", _wan_set)
                    if _ret == bv.RET_NO :
                        return self._RET_BACK
                    elif _ret == bv.RET_ERR or type(_ret) != list or type(_ret) != tuple :
                        logger.error("Fail to Create Default-VNF, Fake WAN-Info Setting Error, ret=%s"%str(_ret))
                        bv.alert("Fail to Create Default-VNF, Fake WAN-Info Setting Error, \n - ret=%s"%str(_ret))
                        return self._RET_ERR
                    
                    _is_ok = True
                    for _chk in _ret :
                        try:
                            IPv4Network("%s/32"%str(_chk))
                        except Exception :
                            bv.alert("Invalid Address, addr=%s"%str(_chk))
                            _is_ok = False
                            break
                    
                    if not _is_ok :
                        continue
                    
                    _dummy = _ret
                    break
            
            ## Create VNF
            _head = oc.HEADER
            _url = _ob_info.url_vnfm("127.0.0.1") + _URL_VNF_CREATE%(_obid)
            _body = _ol.to_obinfo_for_orchf(_net_state_info, _ob_info)
            # default vnf select
            _body['default_vnf_model'] = _data[_TAG_DEF_VNF_MODEL]
            _body['default_vnf_version'] = _data[_TAG_DEF_VNF_VER]
            _ret, _ecode, _res = rest_api.sendReq(_head, _url, "POST", _body, cCrt=oc.KEY_CLI_CRT, cKey=oc.KEY_CLI_KEY, _to=15)
            if not _ret or type(_res) != dict or _res.has_key('error') or not _res.has_key('status') or _res['status'] == oc.STATUS_FAIL:
                logger.error("Fail to Request Default-VNF Creation, ret=%s, body=%s"%( str(_res), str(_body) ))
                bv.alert("Fail to Request Default-VNF Creation")
                return self._RET_ERR
            
            _jid = _res['job_id']
            if _jid == None :
                logger.error("Fail to Request Default-VNF Creation, No Job-ID, ret=%s"%str(_res))
                bv.alert("No Job-ID for Check VNF Creation")
                return self._RET_ERR
            logger.info("SUCC: Request Default-VNF Creation, res=%s, body=%s"%( str(_res), str(_body) ))
        except Exception, e:
            logger.error("Fail to Request Default-VNF Creation, exc=%s"%str(e))
            logger.exception(e)
            return self._RET_ERR
        
        ## Check VNF Creation
        _def_ns_id = None
        _url = _ob_info.url_vnfm("127.0.0.1") + _URL_VNF_CHK%(_jid)
        _remain = _T_MAX_CREATE_WAIT
        _sleep = 5
        
        progInfo = bv.ProgBarInfo("Start Default-VNF Creation...")
        bv.start_progBar(progInfo.title(), progInfo.title())
        _ret = False
        _err = ""
        _limit_cnt = _CNT_MAX_CREATE_WAIT
        while True :
            sleep(_sleep)
            _remain -= _sleep
            _prog = (_T_MAX_CREATE_WAIT - _remain)*100/_T_MAX_CREATE_WAIT
            if _prog >= 100 :
                _prog = 99
            progInfo.set_perc(_prog)
            bv.update_progBar(progInfo, "Check Default-VNF Creation..., timeout=%s, limit=%s"%( str(_remain), str(_limit_cnt) ))
            try:
                _ret, _ecode, _res = rest_api.sendReq(_head, _url, "GET", cCrt=oc.KEY_CLI_CRT, cKey=oc.KEY_CLI_KEY)
                if not _ecode in (0, 200, 400, 500, 599) and not _ret :
                    logger.error("Fail to Check Default-VNF Creation, err=%s"%str(_res))
                    _ret = False
                    _err = "Fail to Check Default-VNF Creation"
                    break
                elif type(_res) == dict and ((_res.has_key('status') and _res['status'] == oc.STATUS_FAIL ) or (_res.has_key('default_ns_id') and _res['default_ns_id'] == oc.STATUS_ERROR )) :
                    logger.error("Fail to Check Default-VNF Creation, KT-VNFM Operation Error, err=%s"%str(_res))
                    _ret = False
                    _err = "Fail to Check Default-VNF Creation, KT-VNFM Operation Error"
                    break
                
                if type(_res) == dict and _res.has_key('status') and _res['status'] == oc.STATUS_DONE :
                    _def_ns_id = _res['default_ns_id']
                    if _def_ns_id == _VAL_DEF_NS_ID_ERR or _def_ns_id == _VAL_DEF_NS_ID_RSV or _def_ns_id == None :
                        logger.error("Fail to Create Default-VNF, Invalid NS-ID, ns-id=%s"%str(_def_ns_id))
                        bv.alert("Fail to Create Default-VNF, Invalid NS-ID, ns-id=%s"%str(_def_ns_id))
                        _ret = False
                        _err = "Invalid NS-ID, ns-id=%s"%str(_def_ns_id)
                    else:
                        logger.info("SUCC: Create Default-VNF, ns_id=%s"%str(_def_ns_id))
                        _ret = True
                    break
                logger.info(" - Wait for Default-VNF Creation, remain_t=%s, ret=%s"%( str(_remain), str(_res) ))
            except Exception, e:
                logger.error("Fail to Check Default-VNF Creation, url=%s, unknown-exc=%s"%( _url, str(e) ))
                _ret = False
                _err = "Fail to Check  Default-VNF Creation, exc=%s"%str(e)
                break
            
            if _remain < 0 :
                if _limit_cnt > 0 and bv.confirm_ok("Default-VNF Creation Time-Out\nContinue Wait[%s sec]?"%_T_RECHARGE_CREATE_WAIT) == bv.RET_OK :
                    _remain = _T_RECHARGE_CREATE_WAIT
                    _limit_cnt -= 1
                    continue
                
                logger.error("Fail to Create Default-VNF, Time-Out, to=%s"%str(_T_MAX_CREATE_WAIT))
                _ret = False
                _err = "VNF Creation Check Time-Out, to=%s"%str(_T_MAX_CREATE_WAIT)
                break
        
        if not _ret :
            bv.stop_progBar()
            bv.alert(_err)
            return self._RET_ERR
        else:
            progInfo.set_perc(100)
            bv.update_progBar(progInfo, "Complete Default-VNF Creation!!!")
            sleep(1)
            bv.stop_progBar()
        
        ## def-vnf info setting
        vnf_type = _data[_TAG_DEF_VNF_TYPE]
        vnf_pfile = _data[_TAG_DEF_VNF_PFILE]
        vnf_cfg = _data[_TAG_DEF_VNF_CFG]
        vnf_ip = _data[_TAG_DEF_VNF_LOC_IP]
        vnf_id = _data[_TAG_DEF_VNF_ID]
        vnf_pw = _data[_TAG_DEF_VNF_PW]
        if vnf_type in [ oc.VNFM_PLUGIN_TYPE_UTM, oc.CFG_PLUGIN_UTM ] :
            _ob_info.set_plugin_utm(vnf_pfile, vnf_cfg)
            _ob_info.set_utm_info(vnf_ip, None, vnf_id, vnf_pw)
        else:
            _ob_info.add_plugin_evnf(vnf_type, vnf_pfile, vnf_cfg)
        
        try:
            _ob_info.saveToCfg()
            logger.info("SUCC: VNF-Info Setting, pfile=%s, type=%s, cfg=%s"%( str(vnf_pfile), str(vnf_type), str(vnf_cfg) ))
        except Exception, e:
            _err = "OBA-CFG Save Error, err=%s, pfile=%s, type=%s, cfg=%s"%( str(e), str(vnf_pfile), str(vnf_type), str(vnf_cfg) )
            logger.error(_err)
            logger.exception(e)
            bv.alert(_err)
            return self._RET_ERR
        
        if not _set_ns_id(_def_ns_id) :
            logger.error("Fail to Save Default-NS-ID, ns_id=%s"%str(_def_ns_id))
            bv.alert("Fail to Save Default-NS-ID, ns_id=%s"%str(_def_ns_id))
            return self._RET_ERR
        
        return self._RET_OK
        
    
    def _next(self, _ret, _data):
        return _ret








