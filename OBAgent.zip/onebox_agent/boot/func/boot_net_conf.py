#-*- coding: utf-8 -*-
'''
Created on 2017. 7. 31.

@author: ohhara
'''

import os, shutil, ruamel.yaml, datetime
from time import sleep
from ipaddr import IPv4Network

from onebox_agent.boot.boot_ctrl import _LinkedMenu
from onebox_agent.boot import boot_constant as bc
from onebox_agent.util import ob_constant as oc, rest_api
from onebox_agent.boot import boot_view as bv
from onebox_agent.data.ob_info import OB_INFO
from onebox_agent.data import ob_info
from onebox_agent.util.onebox_manager import WANStateManager
from onebox_agent.util import onebox_manager

import logging
logger = logging.getLogger(bc._L_TITLE)
onebox_manager.logger = logger


_TAG_NEW_WAN_IP = "__tag_new_ob_wan_ip_info__"
_TAG_NEW_LAN_IP = "__tag_new_ob_lan_ip_info__"

_TAG_WANSW = "__tag_wan_sw__"
_TAG_WAN_MODE = "__tag_wan_mode__"

_TAG_WAN_LIST = "__tag_wan_list__"
_TAG_EVWAN_LIST = "__tag_evwan_list__"

_TAG_LAN_MOD_NAME = "__tag_lan_mod_name__"
_TAG_LAN_NEW_INFO = "__tag_lan_new_info__"
_TAG_LAN_CHG_HAS_UTM = "__tag_lan_chg_has_utm__"

#################
### IP Config ###
#################
## IP 변경 Restore 레벨
_R_LEV_KAGT =   0b1
_R_LEV_HOST =   0b10
_R_LEV_OBA =    0b100
_R_LEV_OSP =    0b1000
_R_LEV_UTM =    0b10000
_R_LEV_SWV =    0b100000
_R_LEV_RAGT =   0b1000000

_STOP_SVC =  ["onebox-agent", "zabbix-agent", "znmsc", "zsmsc"]

_URL_WAN_PORT_MOD = "/server/%s/action"
_URL_WAN_PORT_PROG = "/server/%s/progress"
_URL_SCHD_PAUSE = "/schd/pause"
_URL_SCHD_RESUME = "/schd/resume"
_URL_OB_STATUS = "/server/%s"

_TO_WAN_PORT_MOD_WAIT = 420
_TO_WAN_SW_PAUSE = 1800

_TAG_RECOVERY_WAN = "___tag_recovery_wan___"
_RCVR_OBA_CONF = "_rcvr_oba_conf"
_RCVR_HOST_NET = "_rcvr_host_net"
_RCVR_VNF_RESTORE = "_rcvr_vnf_restore"
_RCVR_SW_VNF = "_rcvr_sw_vnf"
_RCVR_OBA_RESUME = "_rcvr_oba_resume"
_RCVR_OBA_START = "_rcvr_oba_start"
_RCVR_VWAN_RESTORE = "_rcvr_vwan_restore"
_RCVR_VWAN_PORT_RESTORE = "_rcvr_vwan_port_restore"

_TAG_SKIP_WAN = "___tag_skip_wan___"
_SKWN_VNF_IP_SETTING = "_skwn_vnf_ip_setting"
_SKWN_VNF_ROUTE_SETTING = "_skwn_vnf_route_setting"
_SKWN_VNF_UNUSE_DEL = "_skwn_vnf_unuse_del"
_SKWN_VNF_IP_CHG = "_skwn_vnf_ip_chg"
_SKWN_SW_VNF = "_skwn_sw_vnf"
_SKWN_OBA_WANMON_RESUME = "_skwn_oba_wanmon_resume"
_SKWN_OBA_START = "_skwn_oba_start"

_TAG_RECOVERY_LAN = "___tag_recovery_lan___"
_RCVR_VNET_LAN_NIC = "_rcvr_vnet_lan_nic"
_RCVR_VNET_LAN_NET = "_rcvr_vnet_lan_net"

_TAG_RECOVERY_EVW = "___tag_recovery_evw___"
_RCVR_VNET_EVW_NIC = "_rcvr_vnet_evw_nic"


#### Port CHG
_TAG_CHG_PORT_SRC = "__tag_chg_port_src__"
_TAG_CHG_PORT_SRC_NET = "__tag_chg_port_src_net__"
_TAG_CHG_PORT_DST = "__tag_chg_port_dst__"
_TAG_CHG_PORT_DST_MAC = "__tag_chg_port_dst_mac__"

_TAG_RECOVERY_PORT = "__tag_recovery_port__"
_RCVR_CHG_VNET_PORT = "_rcvr_chg_vnet_port"
_TAG_SKIP_PORT = "__tag_skip_port__"





def _unsupport_to_txt( _unsupportItem ):
    _txt = ""
    for _key in _unsupportItem.keys():
        if _unsupportItem[_key] :
            _txt += " - %s : ON\n"%str(_key)
    return _txt

def _chkForNewIP(_net_type_name, _ol, _bl, ob_info):
    _host_only_chk = False
    _mac_list = ob_info.wan_mac_list()
    if _ol.hasUtm(_mac_list) :
        if _net_type_name == oc.VAL_NET_TYPE_WAN :
            _title = "Check VNF for %s-IP Change"%str(_net_type_name).upper()
        else:
            _title = "Check VNF for LAN-%s-IP Change"%str(_net_type_name)
        _utm_ip = ob_info.utm_local_ip()
        _utm_id = ob_info.utm_id()
        _utm_pass = ob_info.utm_pass()
        
        if _net_type_name == oc.VAL_NET_TYPE_WAN :
            _chkItemList = _bl.get_utm_chk_list_for_new_wan_ip(_utm_ip, _utm_id, _utm_pass)
        else:
            _chkItemList = _bl.get_utm_chk_list_for_new_lan_ip()
        _ele = ["Get WAN NIC"] + _chkItemList
        _mProg = bv.MixedProgBarInfo(_title, _ele)
        bv.update_progBar(_mProg)
        
        _chkItem = _ele[0]
        try:
            ## 1. WAN NIC
            prevStaticWanInfo = {}
            _wanNicList = []
            for _ewan in ob_info.wan_list() :
                _utm_nic = _ol.to_utm_nic(_ewan.bridge())
                if _utm_nic == None :
                    logger.error("Fail to %s, Unknown UTM NicInfo, br=%s"%( _title, str(_ewan.bridge()) ))
                    bv.alert("Fail to %s\n: Unknown UTM NicInfo, br=%s"%( _title, str(_ewan.bridge()) ))
                    return False, None, _host_only_chk
                if not _utm_nic in _wanNicList :
                    _wanNicList.append(_utm_nic)
                if not _ewan.is_dhcp() :
                    prevStaticWanInfo.update({_utm_nic:{'gw':_ewan.gw(), 'ip':_ewan.ip()}})
            _wanNicList.sort()
            
            logger.info(" - %s, nic=%s"%(_mProg.get_item(), str(_wanNicList)))
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            sleep(0.5)
            
            ## 2~
            _mProg.set_index(1)
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            sleep(0.5)
            
            if _net_type_name == oc.VAL_NET_TYPE_WAN :
                _chkThread = _bl.create_chker_utm_new_wan_ip(_utm_ip, _wanNicList, prevStaticWanInfo, _utm_id, _utm_pass)
            else:
                _lan_net = ob_info.lan_xnet(_net_type_name)
                if _lan_net == None : 
                    logger.error("Fail to %s, No Lan-Network Info, lan=%s"%( _title, str(_net_type_name) ))
                    bv.alert("No Lan-Network Info, lan=%s"%( str(_net_type_name) ))
                    return False, None, _host_only_chk
                _vi_br = oc.VAL_DEF_VNF_LAN_BR_PFX+_lan_net.name()
                _utm_nic = _ol.to_utm_nic(_vi_br)
                if _utm_nic == None :
                    logger.error("Fail to %s, UTM NIC Convert Error, br=%s, net=%s"%( _title, str(_vi_br), str(_lan_net) ))
                    bv.alert("UTM NIC Convert Error, br=%s, net=%s"%( str(_vi_br), str(_lan_net) ))
                    return False, None, _host_only_chk
                _chkThread = _bl.create_chker_utm_new_lan_ip(_utm_ip, _utm_nic, _wanNicList, _utm_id, _utm_pass)
            _chkThread.start()
            
            _chkItem = _chkThread.item()
            while True:
                _status, _items, _progs = _chkThread.get_info()
                _idx = 0
                for _item in _items :
                    _mProg.set_item(_item, _progs[_idx])
                    _idx += 1
                bv.update_progBar(_mProg)
                _chkItem = _chkThread.item()
                _chkRate = _chkThread.rate()
                logger.debug(" - Get Prog-Info, item=%s, rate=%s"%( _chkItem, str(_chkRate) ))
                
                if _status != _chkThread.STAT_RUN :
                    break
                
                sleep(1)
            
            sleep(0.5)
            _status, _return, _err = _chkThread.result()
            
            if _status == _chkThread.STAT_COMP :
                if _net_type_name == oc.VAL_NET_TYPE_WAN :
                    if type(_return) == dict :
                        return True, _return, _host_only_chk
                    else:
                        logger.error("Fail to %s, Invalid CheckData=%s"%(_title, str(_return)))
                        bv.alert("Fail to %s\n: Invalid CheckData"%_title)
                        return False, None, _host_only_chk
                else :
                    return True, None, _host_only_chk
            elif _status == _chkThread.STAT_ERR :
                logger.error("Fail to %s, %s Error, err=%s"%( _title, _chkItem, str(_err) ))
                bv.alert("Fail to %s\n: %s Error, err=%s"%( _title, _chkItem, str(_err) ))
                return False, None, _host_only_chk
            ## unsupported
            elif _status == _chkThread.STAT_UNSUPP :
                logger.error("Fail to %s, UnSupported Item\n%s"%( _title, _unsupport_to_txt(_err) ))
                # bv.alert("UnSupported Item...\n%s" % (_unsupport_to_txt(_err)))
                _unsupport_br_api_haskey = False
                for _key in _err.keys():
                    if _key == "Not supported API for Bridge-name":
                        _unsupport_br_api_haskey = True
                        break
                if _net_type_name == oc.VAL_NET_TYPE_WAN and _unsupport_br_api_haskey is True:
                    if _err["Not supported API for Bridge-name"] is True:
                        _ret = bv.confirm_ok("Not supported API for Bridge-name\n"
                                             "Want to change only the host?")
                        if _ret == bv.RET_OK:
                            _host_only_chk = True
                            return True, None, _host_only_chk
                        else:
                            _host_only_chk = False
                            return False, None, _host_only_chk
                    else:
                        bv.alert("UnSupported Item...\n%s" % (_unsupport_to_txt(_err)))
                        return False, None, _host_only_chk
                else:
                    bv.alert("UnSupported Item...\n%s" % (_unsupport_to_txt(_err)))
                    return False, None, _host_only_chk
            else:
                logger.error("Fail to %s, Invalid Check Status, status=%s, return=%s, err=%s"%( _title, str(_status), str(_return), str(_err) ))
                bv.alert("Invalid Check Status...\n%s"%( _unsupport_to_txt(_err) ))
                return False, None, _host_only_chk
        except Exception, e:
            logger.error("Fail to %s-%s, exc=%s"%( _title, _chkItem, str(e) ))
            logger.exception(e)
            bv.alert("Fail to %s-%s\n: exc=%s"%(_title, _chkItem, str(e)))
            return False, None, _host_only_chk
    else:
        return True, None, _host_only_chk


def _confirm_utm_delet_info(_delInfoTxt):
    if _delInfoTxt == None or str(_delInfoTxt).strip() == "" :
        return _LinkedMenu._RET_OK
    
    _txt = """User-Defined IP, Route, Rule, ARP will be deleted.\n\n%s\nContinue?"""%(_delInfoTxt)
    _ret = bv.confirm_ok(_txt)
    if _ret == bv.RET_OK :
        return _LinkedMenu._RET_OK
    elif _ret == bv.RET_NO :
        return _LinkedMenu._RET_BACK
    else:
        return _LinkedMenu._RET_ERR



def _toTxtR(_rLev, _eLev):
    _txt = ""
    
    _res = "[%s] "%( (lambda x: "FAIL" if _R_LEV_KAGT & _eLev else "SUCC" )(_eLev) )
    if (_R_LEV_KAGT & _rLev) or (_R_LEV_KAGT & _eLev) : _txt += "%sAGENT Stop%s\n"%(_res, str( _STOP_SVC ))
    
    _res = "[%s] "%( (lambda x: "FAIL" if _R_LEV_HOST & _eLev else "SUCC" )(_eLev) )
    if (_R_LEV_HOST & _rLev) or (_R_LEV_HOST & _eLev) : _txt += "%sHost IP Change\n"%_res
    
    _res = "[%s] "%( (lambda x: "FAIL" if _R_LEV_OBA & _eLev else "SUCC" )(_eLev) )
    if (_R_LEV_OBA & _rLev) or (_R_LEV_OBA & _eLev) : _txt += "%sOne-Box Agent Config Change\n"%_res
    
    _res = "[%s] "%( (lambda x: "FAIL" if _R_LEV_OSP & _eLev else "SUCC" )(_eLev) )
    if (_R_LEV_OSP & _rLev) or (_R_LEV_OSP & _eLev) : _txt += "%sOpenStack IP Change\n"%_res
    
    _res = "[%s] "%( (lambda x: "FAIL" if _R_LEV_UTM & _eLev else "SUCC" )(_eLev) )
    if (_R_LEV_UTM & _rLev) or (_R_LEV_UTM & _eLev) : _txt += "%sUTM IP Change\n"%_res
    
    _res = "[%s] "%( (lambda x: "FAIL" if _R_LEV_SWV & _eLev else "SUCC" )(_eLev) )
    if (_R_LEV_SWV & _rLev) or (_R_LEV_SWV & _eLev) : _txt += "%sWAN-Switch to VNF\n"%_res
    
    _res = "[%s] "%( (lambda x: "FAIL" if _R_LEV_RAGT & _eLev else "SUCC" )(_eLev) )
    if (_R_LEV_RAGT & _rLev) or (_R_LEV_RAGT & _eLev) : _txt += "%sAGENT Start%s"%(_res, str( _STOP_SVC ))
        
    return _txt


def _restoreVNF(_bl, _vnf_ip, _prog, _bak_file=None):
    try:
        ## Restore 요청
        _bakFName = ""
        _bak_file = ( oc.FILE_BAK_VNF_UTM if _bak_file == None else _bak_file)
        with open(_bak_file, "r") as f:
            _bakFName = f.read()
        
        if _bakFName == None or str(_bakFName).strip() == "" :
            logger.error("Fail to Restore KT-VNF, no backup file, f=%s"%str(_bakFName))
            return False
        
        _runner = _bl.create_runner_restore_utm(_vnf_ip, _bakFName)
        _runner.start()
        while True :
            _res, _items, _progs = _runner.get_info()
            _rate = _runner.rate()
            __rate = int(round(float(_rate)/100*90))
            _prog.set_perc(__rate)
            bv.update_progBar(_prog)
            
            if _res != _runner.STAT_RUN :
                break
            
            sleep(2)
        
        _ret, _item, _err = _runner.result()
        if _ret != _runner.STAT_COMP :
            logger.error("Fail to Restore VNF, err=%s"%str(_err))
            return False
        else:
            return True
    except Exception, e:
        logger.error("Fail to Restore KT-VNF, exc=%s"%str(e))
        logger.exception(e)
        return False

def _restore_wan_config_ip(_ol, _bl, _prev_ob_info, rLevel):
    _failed = []
    
    _title = "Start IP Restore"
    logger.info(_title)
    
    _idx = 0
    _ele = ["OBA CONFIG", "WAN-Switch to Host", "Host Network", "VIM Config", "VNF CONFIG", "AGENT"]
    _mProg = bv.MixedProgBarInfo(_title, _ele)
    
    ## 1. OBA CFG 
    _item = _ele[_idx]
    if rLevel & _R_LEV_OBA :
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        try:
            shutil.copyfile(oc.FILE_BAK_OBA_CONF, oc.FILE_SRC_OBA_CONF)
            _ol.delFile(oc.FILE_BAK_OBA_CONF)
            logger.info(" - SUCC: Restore %s"%_item)
            _mProg.set_perc(100)
        except Exception, e:
            logger.error("Fail to Restore %s, exc=%s"%( _item, str(e) ))
            logger.exception(e)
            _mProg.set_perc(bv.G_STATUS_FAIL)
            _failed.append(_item)
    else:
        logger.info("   SKIP: %s"%_item)
        _mProg.set_perc(bv.G_STATUS_SKIP)
    bv.update_progBar(_mProg)
    
    ## 2. WAN-Switch Host 
    _idx += 1
    _item = _ele[_idx]
    _mProg.set_index(_idx)
    if ( rLevel & _R_LEV_SWV ) and _prev_ob_info.is_in_band() :
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        try:
            _bl.switchToHost(_prev_ob_info.mgmt_list(), _prev_ob_info.wan_list(), _mProg, bv)
            logger.info(" - SUCC: Restore %s"%_item)
            _mProg.set_perc(100)
        except Exception, e:
            logger.error("Fail to Restore %s, exc=%s"%( _item, str(e) ))
            logger.exception(e)
            _mProg.set_perc(bv.G_STATUS_FAIL)
            _failed.append(_item)
    else:
        logger.info("   SKIP: %s"%_item)
        _mProg.set_perc(bv.G_STATUS_SKIP)
    bv.update_progBar(_mProg)
    
    ## 3. Host Network CFG 
    _idx += 1
    _item = _ele[_idx]
    _mProg.set_index(_idx)
    if rLevel & _R_LEV_HOST :
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        try:
            shutil.copyfile(oc.FILE_BAK_HOST_NET, oc.FILE_SRC_HOST_NET)
            
            _ret, _err = _ol.config_mgmt_net(_prev_ob_info.mgmt_list(), _mProg, bv)
            if not _ret:
                logger.error("Fail to Restore %s, err=%s"%( _item, str(_err) ))
                _failed.append(_item)
                _mProg.set_perc(bv.G_STATUS_FAIL)
            else:
                _ol.delFile(oc.FILE_BAK_HOST_NET)
                logger.info(" - SUCC: Restore %s"%_item)
                _mProg.set_perc(100)
        except Exception, e:
            logger.error("Fail to Restore %s, exc=%s"%( _item, str(e) ))
            logger.exception(e)
            _mProg.set_perc(bv.G_STATUS_FAIL)
            _failed.append(_item)
    else:
        logger.info("   SKIP: %s"%_item)
        _mProg.set_perc(bv.G_STATUS_SKIP)
    bv.update_progBar(_mProg)
    
    ## 4. VIM CFG 
    _idx += 1
    _item = _ele[_idx]
    _mProg.set_index(_idx)
    if rLevel & _R_LEV_OSP :
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        try:
            with open(oc.FILE_BAK_VIM_INFO, "r") as f:
                _ospInfo = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)            
            
            _ret, _err = _bl.update_vim(_mProg, _ospInfo['ip'], _ospInfo['db_id'], _ospInfo['db_pass'], _prev_ob_info.ovs_dpdk())
            if not _ret:
                logger.error("Fail to Restore %s, err=%s"%( _item, str(_err) ))
                _failed.append(_item)
                _mProg.set_perc(bv.G_STATUS_FAIL)
            else:
                _ol.delFile(oc.FILE_BAK_VIM_INFO)
                logger.info(" - SUCC: Restore %s"%_item)
                _mProg.set_perc(100)
        except Exception, e:
            logger.error("Fail to Restore %s, exc=%s"%( _item, str(e) ))
            logger.exception(e)
            _mProg.set_perc(bv.G_STATUS_FAIL)
            _failed.append(_item)
    else:
        logger.info("   SKIP: %s"%_item)
        _mProg.set_perc(bv.G_STATUS_SKIP)
    bv.update_progBar(_mProg)
    
    ## 5. UTM 
    _idx += 1
    _item = _ele[_idx]
    _mProg.set_index(_idx)
    if rLevel & _R_LEV_UTM :
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        if not _restoreVNF(_bl, _prev_ob_info.utm_local_ip(), _mProg) :
            logger.error("Fail to Restore %s"%( _item, ))
            _failed.append(_item)
            _mProg.set_perc(bv.G_STATUS_FAIL)
        else:
            _ol.delFile( oc.FILE_TMP_UTM_DR )
            _ol.delFile( oc.FILE_BAK_VNF_UTM )
            _ol.delFile( oc.FILE_TMP_UTM_UR )
            _ol.delFile( oc.FILE_TMP_UTM_RR )
            _ol.delFile( oc.FILE_TMP_UTM_IF )
            _ol.delFile( oc.FILE_TMP_UTM_ARP )
            logger.info(" - SUCC: Restore %s"%_item)
            _mProg.set_perc(100)
    else:
        logger.info("   SKIP: %s"%_item)
        _mProg.set_perc(bv.G_STATUS_SKIP)
    bv.update_progBar(_mProg)
    
    ## 6. AGENT 
    _idx += 1
    _item = _ele[_idx]
    _mProg.set_index(_idx)
    if rLevel & _R_LEV_KAGT :
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        result, _err = _bl.set_onebox_services(_STOP_SVC, True, _mProg)
        if not result:
            logger.error("Fail to Restore %s"%( _item, ))
            _failed.append(_item)
            _mProg.set_perc(bv.G_STATUS_FAIL)
        else:
            logger.info(" - SUCC: Restore %s"%_item)
            _mProg.set_perc(100)
    else:
        logger.info("   SKIP: %s"%_item)
        _mProg.set_perc(bv.G_STATUS_SKIP)
    bv.update_progBar(_mProg)
    
    logger.info("SUCC: Restore IP-CHG, fail-item=%s"%str(_failed))
    _mProg.fin()
    bv.update_progBar(_mProg)
    sleep(0.5)
    
    return _failed

def _change_wan_ip(_ol, _bl, _new_ob_info, _cur_ob_info, _host_only):
    _rLevel = 0
    _eLevel = 0
    _title = "New Public IP Configuration"
    _item_list = ["STOP AGENT%s"%str(_STOP_SVC), "WAN-Switch to Host", "Apply IP to Host",
                  "Update OBA Config", "Update VIM Info", "Apply IP to UTM", "WAN-Switch to VNF",
                  "START AGENT%s"%str(_STOP_SVC)]
    _item = ""
    _idx = 0
    _mProgBar = bv.MixedProgBarInfo(_title, _item_list)
    try:
        logger.info("Start %s"%_title)
        bv.update_progBar(_mProgBar)
        
        in_band = _new_ob_info.is_in_band()
        has_utm = _ol.hasUtm(_cur_ob_info.wan_mac_list())
        vnf_gw_ip = _new_ob_info.utm_local_ip()
        authDbUser = _new_ob_info.vim_auth_user()
        authDbPass = _new_ob_info.vim_auth_pass()
        
        # [OK]1. Stop All Agent
        _rLevel += _R_LEV_KAGT
        _eLevel += _R_LEV_KAGT
        _item = _item_list[_idx]
        logger.info(" - %s"%_item)
        _mProgBar.inc(5)
        bv.update_progBar(_mProgBar)
        
        result, _err = _bl.set_onebox_services(_STOP_SVC, False, _mProgBar)
        if not result:
            logger.error("   Fail to %s"%_item)
            return False, _rLevel, _eLevel, "Fail to %s"%_item
        else:
            logger.info("   SUCC: %s"%_item)
            _mProgBar.set_perc(100)
            bv.update_progBar( _mProgBar )
        
        _eLevel -= _R_LEV_KAGT
        
        # [OK]2. WAN Switch to Host
        _idx += 1
        _item = _item_list[_idx]
        _mProgBar.set_index(_idx)
        _mProgBar.inc(5)
        bv.update_progBar(_mProgBar)
        if in_band:
            logger.info(" - %s"%_item)
            
            result, _err = _bl.switchToHost(_new_ob_info.mgmt_list(), _new_ob_info.wan_list(), _mProgBar)
            if not result:
                logger.error("   Fail to %s"%_item)
                return False, _rLevel, _eLevel, "Fail to %s"%_item
            else:
                logger.info("   SUCC: %s"%_item)
                _mProgBar.set_perc(100)
                bv.update_progBar( _mProgBar )
        else:
            logger.info("   SKIP: %s"%_item)
            _mProgBar.set_perc(bv.G_STATUS_SKIP)
        
        # [OK]3. Apply New Public IP to Host Network
        _idx += 1
        _item = _item_list[_idx]
        _mProgBar.set_index(_idx)
        logger.info(" - %s"%_item)
        _mProgBar.inc(5)
        bv.update_progBar(_mProgBar)
        
        shutil.copyfile( oc.FILE_SRC_HOST_NET, oc.FILE_BAK_HOST_NET)
        _rLevel += _R_LEV_HOST
        _eLevel += _R_LEV_HOST
        
        result, _err = _ol.config_mgmt_net(_new_ob_info.mgmt_list(), _mProgBar, bv)
        if not result:
            logger.error("   Fail to %s"%_item)
            return False, _rLevel, _eLevel, "Fail to %s"%_item
        
        _main_ip_info = _ol.get_host_main_ip()
        new_endpoint_ip = _main_ip_info[1]
        if new_endpoint_ip == None or not _ol.chk_ip(new_endpoint_ip) :
            _has_utm = _ol.hasUtm(_new_ob_info.wan_mac_list())
            _net_info = ob_info.OB_NET()
            _net_info.init(_new_ob_info.is_in_band(), _new_ob_info.utm_local_ip(),
                           _has_utm, _ol.getWanMode(_new_ob_info), 
                           _new_ob_info.mgmt_list(), _new_ob_info.wan_list(), _new_ob_info.extra_wan_list())
            _net_info.set_fake_wan(_new_ob_info.lan_net_list())
            new_endpoint_ip = _net_info.mgmt_list[0].ip
            if bv.confirm_ok("No ManageMent IP Info.\nContinue with Fake-IP[%s]?"%str(new_endpoint_ip)) == bv.RET_OK :
                logger.warning("   Fail to %s, invalid host ip, ip=%s"%( _item, str(new_endpoint_ip) ))
            else:
                logger.error("   Fail to %s, invalid host ip, ip=%s"%( _item, str(new_endpoint_ip) ))
                return False, _rLevel, _eLevel, "Fail to %s\n: Invalid Host IP"%_item
        
        logger.info("   SUCC: %s"%_item)
        _mProgBar.set_perc(100)
        bv.update_progBar( _mProgBar )
        _eLevel -= _R_LEV_HOST
        
        # [OK]4. Modify OBA Config
        _idx += 1
        _item = _item_list[_idx]
        _mProgBar.set_index(_idx)
        logger.info(" - %s"%_item)
        _mProgBar.inc(5)
        bv.update_progBar(_mProgBar)
        
        shutil.copyfile(oc.FILE_SRC_OBA_CONF, oc.FILE_BAK_OBA_CONF)
        _rLevel += _R_LEV_OBA
        _eLevel += _R_LEV_OBA
        
        result = _new_ob_info.saveToCfg()
        if not result:
            logger.error("   Fail to %s"%_item)
            return False, _rLevel, _eLevel, "Fail to %s"%_item
        else:
            logger.info("   SUCC: %s"%_item)
            _mProgBar.set_perc(100)
            bv.update_progBar( _mProgBar )
        _eLevel -= _R_LEV_OBA
        
        # [OK]5. Update VIM Info
        _idx += 1
        _item = _item_list[_idx]
        _mProgBar.set_index(_idx)
        logger.info(" - %s"%_item)
        _mProgBar.inc(5)
        bv.update_progBar(_mProgBar)
        
        _prevOspIP = _ol.get_vim_public_ip()
        if _prevOspIP == None :
            _prevOspIP = "127.0.0.1"
            logger.warning("   Fail to %s, Invalid IP, def_ip=%s"%( _item, str(_prevOspIP) ))
        _mProgBar.inc(5)
        bv.update_progBar(_mProgBar)
        
        _prevOspInfo = {"ip": _prevOspIP, "db_id": authDbUser, "db_pass": authDbPass}
        with open(oc.FILE_BAK_VIM_INFO, 'w') as f:
            f.write(ruamel.yaml.dump(_prevOspInfo, Dumper=ruamel.yaml.RoundTripDumper))
        _rLevel += _R_LEV_OSP
        _eLevel += _R_LEV_OSP
        
        result, _err = _bl.update_vim(_mProgBar, new_endpoint_ip, authDbUser, authDbPass, _new_ob_info.ovs_dpdk())
        if not result:
            logger.error("   Fail to %s, err=%s"%( _item, _err ))
            return False, _rLevel, _eLevel, "Fail to %s\n: %s"%( _item, _err )
        else:
            logger.info("   SUCC: %s"%_item)
            _mProgBar.set_perc(100)
            bv.update_progBar( _mProgBar )
        _eLevel -= _R_LEV_OSP
        
        # 6. Apply New Public IP to KT-VNF
        _idx += 1
        _item = _item_list[_idx]
        _mProgBar.set_index(_idx)
        logger.info("has_utm: %s, _host_only: %s" % (str(has_utm), str(_host_only)))
        if has_utm and _host_only is False:
            logger.info(" - %s"%_item)
            _mProgBar.inc(5)
            bv.update_progBar(_mProgBar)
            
            prevStaticWanInfo = {}
            for _wnet in _cur_ob_info.wan_list() :
                if not _wnet.is_dhcp() :
                    _utm_nic = _ol.to_utm_nic(_wnet.bridge())
                    if _utm_nic == None :
                        logger.error("Fail to %s, Unknown UTM NicInfo, br=%s"%( _item, str(_wnet.bridge()) ))
                        return False, _rLevel, _eLevel, "Fail to %s\n: Unknown UTM NicInfo, br=%s"%( _item, str(_wnet.bridge()) )
                    prevStaticWanInfo.update({_utm_nic:{'gw':_wnet.gw(), 'ip':_wnet.ip()}})
            
            newWanInfo = []
            for _wnet in _new_ob_info.wan_list() :
                _utm_nic = _ol.to_utm_nic(_wnet.bridge())
                newWanInfo.append({"nic":_utm_nic, "is_dhcp":_wnet.is_dhcp(), "ip": _wnet.ip(),
                                   "subnet": _wnet.mask(), "gw": _wnet.gw(), "mac":_wnet.mac()})
            
            utmID = _cur_ob_info.utm_id()
            utmPass = _cur_ob_info.utm_pass()
            result, _err, _rb = _bl.change_utm_wan_ip(vnf_gw_ip, newWanInfo, prevStaticWanInfo, utmID, utmPass)
            sleep(0.5)
            
            if _rb :
                _rLevel += _R_LEV_UTM

            if result != 0:
                logger.error("Fail to %s, err=%s" % (_item, _err))

                bv.alert(_err)
                _ret = bv.confirm_ok("Maintain host config?\n")

                if _ret == bv.RET_OK:
                    _eLevel -= _R_LEV_UTM
                    logger.info("VNF IP config failed, Maintain host config")
                    _mProgBar.set_perc(100)
                    bv.update_progBar(_mProgBar)
                else:
                    _eLevel += _R_LEV_UTM
                    logger.error("Fail to %s, err=%s"%( _item, _err ))
                    # return False, _rLevel, _eLevel, "Fail to %s\n: %s" % (_item, _err)
                    return False, _rLevel, _eLevel, None
            else:
                _eLevel -= _R_LEV_UTM
                logger.info("   SUCC: %s" % _item)
                _mProgBar.set_perc(100)
                bv.update_progBar(_mProgBar)

                # if result != 0 :
            #     bv.alert(_err)
            #     _ret = bv.confirm_ok("Maintain host config?\n")
            #
            #     _eLevel += _R_LEV_UTM
            #     if _ret == bv.RET_OK:
            #         logger.info("VNF IP config failed, Maintain host config" % _title)
            #         # logger.info("Complete %s: VNF IP config failed, Maintain host config" % _title)
            #         # return True, _rLevel, _eLevel, None
            #     else:
            #         logger.error("Fail to %s, err=%s"%( _item, _err ))
            #         # return False, _rLevel, _eLevel, "Fail to %s\n: %s"%( _item, _err )
            #         # return False, _rLevel, _eLevel, None
            # else:
            #     _eLevel -= _R_LEV_UTM
            #     logger.info("   SUCC: %s"%_item)
            #     _mProgBar.set_perc(100)
            #     bv.update_progBar( _mProgBar )
        else:
            logger.info("   SKIP: %s"%_item)
            _mProgBar.set_perc(bv.G_STATUS_SKIP)
            bv.update_progBar(_mProgBar)
        
        # [OK]7. WAN-Switch to VNF
        _idx += 1
        _item = _item_list[_idx]
        _mProgBar.set_index(_idx)
        if in_band and has_utm :
            _rLevel += _R_LEV_SWV
            _eLevel += _R_LEV_SWV
            logger.info(" - %s"%_item)
            _mProgBar.inc(5)
            bv.update_progBar(_mProgBar)
            
            result, _err = _bl.switchToVNF(_new_ob_info.mgmt_list(), _new_ob_info.wan_list(), vnf_gw_ip, _mProgBar, _new_ob_info.ovs_dpdk())
            _mProgBar.set_perc(95)
            if not result:
                ans = bv.confirm_ok("Fail to %s.\nConitnue?"%_item)
                if ans == bv.RET_OK:
                    logger.warning("Fail to %s, err=%s, Continue"%( _item, _err ))
                else:
                    logger.error("Fail to %s, err=%s, Stop"%( _item, _err ))
                    return False, _rLevel, _eLevel, "Fail to %s\n: %s"%( _item, _err )
            else:
                _eLevel -= _R_LEV_SWV
                logger.info("   SUCC: %s"%_item)
                _mProgBar.set_perc(100)
                bv.update_progBar( _mProgBar )
        else:
            logger.info("   SKIP: %s"%_item)
            _mProgBar.set_perc(bv.G_STATUS_SKIP)
            bv.update_progBar(_mProgBar)
        
        # [OK]8. Start All Agent
        _rLevel += _R_LEV_RAGT
        _eLevel += _R_LEV_RAGT
        _idx += 1
        _item = _item_list[_idx]
        _mProgBar.set_index(_idx)
        logger.info(" - %s"%_item)
        _mProgBar.inc(5)
        bv.update_progBar(_mProgBar)
        
        result, _err = _bl.set_onebox_services(_STOP_SVC, True, _mProgBar)
        if not result:
            ans = bv.confirm_ok("Fail to %s.\nConitnue?"%_item)
            if ans == bv.RET_OK:
                logger.warning("Fail to %s, err=%s, Continue"%( _item, _err ))
            else:
                logger.error("Fail to %s, err=%s, Stop"%( _item, _err ))
                return False, _rLevel, _eLevel, "Fail to %s\n: %s"%( _item, _err )
        else:
            _eLevel -= _R_LEV_RAGT
            logger.info("   SUCC: %s"%_item)
            _mProgBar.set_perc(100)
            bv.update_progBar( _mProgBar )
        
        _mProgBar.fin()
        bv.update_progBar( _mProgBar )
        sleep(0.5)
        
        logger.info("Complete %s"%_title)
        return True, _rLevel, 0, None
    except Exception, e:
        logger.error("   Fail to %s"%_item)
        logger.exception(e)
        return False, _rLevel, _eLevel, "Fail to %s\n: %s"%( _item, str(e) )

def _wan_config_ip(_ol, _bl, _new_ob_info, _cur_ob_info, _host_only):
    if not os.path.exists( oc.DIR_TMP ) :
        os.makedirs( oc.DIR_TMP )
    
    _ret, _rLev, _eLev, _err = _change_wan_ip(_ol, _bl, _new_ob_info, _cur_ob_info, _host_only)
    if not _ret :
        if not (_rLev & _R_LEV_UTM) : 
            _ol.delFile( oc.FILE_TMP_UTM_DR )
            _ol.delFile( oc.FILE_BAK_VNF_UTM )
            _ol.delFile( oc.FILE_TMP_UTM_UR )
            _ol.delFile( oc.FILE_TMP_UTM_RR )
            _ol.delFile( oc.FILE_TMP_UTM_IF )
            _ol.delFile( oc.FILE_TMP_UTM_ARP )

        if _err is not None:
            bv.alert(_err)

        _ret = bv.confirm_ok("Restore?")
        if _ret == bv.RET_OK :
            _ret = _restore_wan_config_ip(_ol, _bl, _cur_ob_info, _rLev)
            if len(_ret) > 0 :
                bv.alert("Fail to Restore, item=%s"%','.join(_ret))
        elif _ret == bv.RET_NO:
            _r_txt = _toTxtR(_rLev, _eLev)
            logger.debug(" - - IP-CHG Error Result:\n%s"%str(_r_txt))
            bv.alert(_r_txt)
        else:
            bv.alert("Fail to Confirm Restore, Occur Error")
        
        return False
    else:
        _ol.delFile( oc.FILE_BAK_HOST_NET )
        _ol.delFile( oc.FILE_BAK_OBA_CONF )
        _ol.delFile( oc.FILE_BAK_VIM_INFO )
        _ol.delFile( oc.FILE_BAK_VNF_UTM )
        if os.path.isfile( oc.FILE_TMP_UTM_UR ) : shutil.move( oc.FILE_TMP_UTM_UR, oc.FILE_NOTI_UTM_UR )
        if os.path.isfile( oc.FILE_TMP_UTM_RR ) : shutil.move( oc.FILE_TMP_UTM_RR, oc.FILE_NOTI_UTM_RR )
        if os.path.isfile( oc.FILE_TMP_UTM_IF ) : shutil.move( oc.FILE_TMP_UTM_IF, oc.FILE_NOTI_UTM_IF )
        if os.path.isfile( oc.FILE_TMP_UTM_ARP ) : shutil.move( oc.FILE_TMP_UTM_ARP, oc.FILE_NOTI_UTM_ARP )
        return True


def _restore_lan_config_ip(_data, _mode='Change'):
    _ol = _data[oc.OTAG_LIB_OB]
    _bl = _data[oc.OTAG_LIB_BTA]
    _recovery_list_tmp = _data[_TAG_RECOVERY_LAN]
    _recovery_list = []
    _recovery_txt_list = []
    if _RCVR_OBA_CONF in _recovery_list_tmp :
        _recovery_list.append(_RCVR_OBA_CONF)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_OBA_CONF))
    if _RCVR_VNET_LAN_NET in _recovery_list_tmp :
        _recovery_list.append(_RCVR_VNET_LAN_NET)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_VNET_LAN_NET))
    if _RCVR_VNF_RESTORE in _recovery_list_tmp :
        _recovery_list.append(_RCVR_VNF_RESTORE)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_VNF_RESTORE))
    
    _data[_TAG_RECOVERY_LAN] = _recovery_list
    
    _mProg = bv.MixedProgBarInfo("Start Recovery...", _recovery_txt_list)
    _idx = -1
    
    _rb_list = []
    _up = None
    
    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, None)
    if not _ret :
        logger.warning("   - Fail to Stop OBA, err=%s"%str(_err))
    
    try:
        if _RCVR_OBA_CONF in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            if _ol.copyFile(_data[_RCVR_OBA_CONF], oc.FILE_OBA_CONF) :
                _rb_list.append(_RCVR_OBA_CONF)
            else:
                logger.error("Fail to Recovery, OBA-Config Rollback Error, bak=%s"%str(_data[_RCVR_OBA_CONF]))
                bv.alert("Fail to Recovery, OBA-Config Rollback Error\n - bak=%s"%str(_data[_RCVR_OBA_CONF]))
                return _rb_list
            logger.info(" - SUCC: %s For Recovery LAN-Port-%s"%(_item, _mode))
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
        
        with open(oc.FILE_OBA_CONF, "r") as f:
            _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
        _ob_info = OB_INFO().loadByCfg(_oba_cfg, True)
        
        if _RCVR_VNET_LAN_NET in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            
            _up = bv.UpdateProg(_mProg, 2, 1, "Restore VNET...")
            _up.start()
            _lan_name = _data[_RCVR_VNET_LAN_NET]
            _lan = _ob_info.lan_xnet(_lan_name)
            if _lan == None :
                logger.warning(" - Fail to Recovery, VNET Restore Error, No LAN Info, name=%s, net=%s"%( str(_lan_name), str(_lan) ))
                _mProg.set_perc(bv.G_STATUS_FAIL)
            else:
                if not __lan_change_vnet(_bl, _data, _lan, True) :
                    logger.warning(" - Fail to Recovery, VNET Restore Error")
                    _mProg.set_perc(bv.G_STATUS_FAIL)
                else:
                    logger.info(" - SUCC: %s For Recovery LAN-Port-%s"%(_item, _mode))
                    _mProg.set_perc(100)
                    _rb_list.append(_RCVR_VNET_LAN_NET)
            _up.stop()
            bv.update_progBar(_mProg)
        
        if _RCVR_VNF_RESTORE in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            
            _up = bv.UpdateProg(_mProg, 2, 1, "Restore VNF...")
            _up.start()
            if not _restoreVNF(_bl, _ob_info.utm_local_ip(), _mProg) :
                logger.warning(" - Fail to Recovery, VNF Restore Error")
                _mProg.set_perc(bv.G_STATUS_FAIL)
            else:
                _ol.delFile( oc.FILE_BAK_VNF_UTM )
                logger.info(" - SUCC: %s For Recovery LAN-Port-%s"%(_item, _mode))
                _mProg.set_perc(100)
                _rb_list.append(_RCVR_VNF_RESTORE)
            _up.stop()
            bv.update_progBar(_mProg)
    except Exception, e:
        logger.error("Fail to Recovery Lan-Port-%s, exc=%s"%(_mode, str(e)))
        logger.exception(e)
        if _up != None : _up.stop()
        bv.alert("Fail to Recovery Lan-Port-%s, exc=%s"%(_mode, str(e)))
    
    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, None)
    if not _ret :
        logger.warning("   - Fail to Start OBA, err=%s"%str(_err))
    return _rb_list

def _change_lan_ip(_ol, _bl, utm_ip, utmID, utmPass, _lan_info):
    _title = "VNF LAN-IP Change"
    _utmProg = bv.MixedProgBarInfo(_title, _bl.get_utm_run_list_for_new_lan_ip())
    
    _vi_br = oc.VAL_DEF_VNF_LAN_BR_PFX+_lan_info.name()
    _utm_nic = _ol.to_utm_nic(_vi_br)
    if _utm_nic == None :
        logger.error("Fail to %s, UTM NIC Convert Error, br=%s, net=%s"%( _title, str(_vi_br), str(_lan_info) ))
        bv.alert("UTM NIC Convert Error, br=%s, net=%s"%( str(_vi_br), str(_lan_info) ))
        return False, None
    _lan_net = {'nic':_utm_nic, 'ip':_lan_info.gw(), 'mask':_lan_info.mask()}
    _runner = _bl.create_runer_utm_new_lan_ip(utm_ip, oc.FILE_BAK_VNF_UTM, _lan_net, utmID, utmPass)
    _runner.start()
    logger.info(" - Start UTM LAN-IP Change, newip=%s"%( str(_lan_net) ))
    
    _res = _runner.STAT_ERR
    _now_item = _runner.item()
    _rollback = False
    try:
        while True :
            _res, _items, _progs = _runner.get_info()
            if _res == _runner.STAT_ROLLBACK :
                _rollback = True
            _idx = 0
            for _item in _items :
                _utmProg.set_item(_item, _progs[_idx])
                _idx += 1
            bv.update_progBar(_utmProg)
            _now_item = _runner.item()
            _now_rate = _runner.rate()
            logger.debug(" - %s, rate=%s"%( _now_item, str(_now_rate) ))
            
            if _res != _runner.STAT_RUN :
                break
            
            sleep(2)
        
        _res, _return, _err = _runner.result()
        if _res == _runner.STAT_ROLLBACK :
            _rollback = True
        if _res != _runner.STAT_COMP :
            logger.error(" - Fail to %s[%s], status=%s, ret=%s, err=%s"%( _title, _now_item, str(_res), str(_return), str(_err) ))
            return False, _err, _rollback
        else:
            return True, None, _rollback
    except Exception, e:
        logger.error(" - Fail to %s[%s], exc=%s"%( _title, str(_now_item), str(e) ))
        logger.exception(e)
        return _res, str(e), _rollback

def _lan_config_ip(_ol, _bl, _data, _new_ob_info, _lan_info, _has_utm):
    _idx = -1
    _ele = ["Stop OBA", "Save OBA-Config", "Change LAN-IP", "Restart OBA"]
    _item = None
    _mProg = bv.MixedProgBarInfo("LAN-IP Configure", _ele)
    
    logger.info("Start LAN-IP Configure...")
    _up = None
    try:
        ### 1. stop OBA
        _idx += 1
        _item = _ele[_idx]
        _mProg.inc(10)
        bv.update_progBar(_mProg, _item)
        _up = bv.UpdateProg(_mProg, 1, 1)
        _up.start()
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False)
        if not _ret :
            logger.warning(" - Fail to %s For LAN-IP Change"%_item)
        else:
            logger.info(" - SUCC: %s For LAN-IP Change"%_item)
        _up.stop()
        
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        ### 2. Save OBA-Config
        _idx += 1
        _item = _ele[_idx]
        _mProg.inc(10)
        bv.update_progBar(_mProg, _item)
        
        today = datetime.datetime.now()
        _bid = today.strftime('%y%m%d%H%M')
        _bname = oc.DIR_TMP + oc.VAL_OBA_NAME + ".conf.bak.%s"%str(_bid)
        if not _ol.copyFile(oc.FILE_OBA_CONF, _bname) :
            if bv.confirm_ok("Fail to Backup OBA-Config.\nContinue?") != bv.RET_OK :
                logger.error("Fail to Change Lan-IP, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                bv.alert("Fail to Change Lan-IP, OBA-Config Backup Error\n - src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                return False
            else:
                logger.warning(" - Fail to Change Lan-IP, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
        try:
            _new_ob_info.saveToCfg()
        except Exception, e:
            logger.error("Fail to Change Lan-IP, OBA-Config Save Error, ob_info=%s"%str(_new_ob_info))
            logger.exception(e)
            bv.alert("Fail to Change Lan-IP, OBA-Config Save Error")
            return False
        
        _data[_TAG_RECOVERY_LAN].append(_RCVR_OBA_CONF)
        _data[_RCVR_OBA_CONF] = _bname
        
        logger.info(" - SUCC: %s For LAN-IP Change"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        ### 3. Change LAN-IP
        _idx += 1
        _item = _ele[_idx]
        _mProg.inc(10)
        bv.update_progBar(_mProg, _item)
        
        _subtitle = None
        if _has_utm :
            _ret_chg, _err = __lan_change_vnf_ip(_ol, _bl, _data, _new_ob_info, _lan_info)
            _subtitle = "Change VNF-IP"
        else:
            _up = bv.UpdateProg(_mProg, 2, 1)
            _up.start()
            _ret_chg, _err = __lan_change_vnet(_bl, _data, _lan_info)
            _up.stop()
            _subtitle = "Change VNET-IP"
        
        if not _ret_chg :
            logger.error("Fail to Change Lan-IP, err=%s"%( str(_err) ))
            bv.alert("Fail to Change Lan-IP, err=%s"%( str(_err) ))
            return False
        
        logger.info(" - SUCC: %s For LAN-IP Change"%_subtitle)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        ### 4. restart OBA
        _idx += 1
        _item = _ele[_idx]
        _mProg.inc(10)
        bv.update_progBar(_mProg, _item)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False)
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True)
        if not _ret :
            if bv.confirm_ok("Fail to Start Onebox-Agent.\nContinue?") == bv.RET_OK :
                _data[_TAG_SKIP_WAN].append(_SKWN_SW_VNF)
                logger.warning(" - Fail to Start OBA, Continue...")
            else:
                _data[_TAG_RECOVERY_WAN].append(_RCVR_OBA_START)
                logger.error("Fail to Change LAN-IP, OBA Start Error, err=%s"%str(_err))
                bv.alert("Fail to Start Onebox-Agent")
                return False
        
        logger.info(" - SUCC: %s For LAN-IP Change"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        return True
    except Exception, e:
        if _up != None : _up.stop()
        logger.error("Fail to Change LAN-IP, %s Error, exc=%s"%( str(_item), str(e) ))
        logger.exception(e)
        bv.alert("Fail to %s, exc=%s"%( str(_item), str(e) ))
        return False

def __lan_change_vnf_ip(_ol, _bl, _data, _new_ob_info, _lan_info):
    utm_ip = _new_ob_info.utm_local_ip()
    utmID = _new_ob_info.utm_id()
    utmPass = _new_ob_info.utm_pass()
    _ret, _err, _rb = _change_lan_ip(_ol, _bl, utm_ip, utmID, utmPass, _lan_info)
    if _rb :
        _data[_TAG_RECOVERY_LAN].append(_RCVR_VNF_RESTORE)
        _data[_RCVR_VNF_RESTORE] = oc.FILE_BAK_VNF_UTM
    
    if not _ret :
        return False, _err
    else:
        return True, None

def __lan_change_vnet(_bl, _data, _lan, _is_rollback=False):
    _ob_info = _data[oc.OTAG_OBA_INFO]
    _tenant = _ob_info.vim_tenant()
    _tUser = _ob_info.vim_tenant_user()
    _tPass = _ob_info.vim_tenant_pass()
    
    # LAN Remove
    if not _is_rollback :
        _data[_TAG_RECOVERY_LAN].append(_RCVR_VNET_LAN_NET)
        _data[_RCVR_VNET_LAN_NET] = str(_lan.name())
    _ret, _err = _bl.remove_lan_vnet(_lan, _tenant, _tUser, _tPass)
    if not _ret :
        return False, "VNet Remove Error, err=%s"%str(_err)
    
    # LAN Create
    _ret, _err = _bl.create_lan_vnet(_lan, _tenant, _tUser, _tPass)
    if not _ret :
        return False, "VNet Create Error, err=%s"%str(_err)
    
    return True, None

def _restore_evw_config_ip(_data):
    _ol = _data[oc.OTAG_LIB_OB]
    _bl = _data[oc.OTAG_LIB_BTA]
    _recovery_list_tmp = _data[_TAG_RECOVERY_EVW]
    _recovery_list = []
    _recovery_txt_list = []
    if _RCVR_OBA_CONF in _recovery_list_tmp :
        _recovery_list.append(_RCVR_OBA_CONF)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_OBA_CONF))
    
    _data[_TAG_RECOVERY_EVW] = _recovery_list
    
    _mProg = bv.MixedProgBarInfo("Start Recovery...", _recovery_txt_list)
    _idx = -1
    
    _rb_list = []
    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, None)
    if not _ret :
        logger.warning("   - Fail to Stop OBA, err=%s"%str(_err))
    
    try:
        if _RCVR_OBA_CONF in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            if _ol.copyFile(_data[_RCVR_OBA_CONF], oc.FILE_OBA_CONF) :
                _rb_list.append(_RCVR_OBA_CONF)
            else:
                logger.error("Fail to Recovery, OBA-Config Rollback Error, bak=%s"%str(_data[_RCVR_OBA_CONF]))
                bv.alert("Fail to Recovery, OBA-Config Rollback Error\n - bak=%s"%str(_data[_RCVR_OBA_CONF]))
                return _rb_list
            logger.info(" - SUCC: %s For Recovery Extra-WAN-IP-CHG"%(_item))
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            
            bv.update_progBar(_mProg)
    except Exception, e:
        logger.error("Fail to Recovery Extra-WAN-IP-CHG, exc=%s"%( str(e)))
        logger.exception(e)
        bv.alert("Fail to Recovery Extra-WAN-IP-CHG, exc=%s"%( str(e)))
    
    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, None)
    if not _ret :
        logger.warning("   - Fail to Start OBA, err=%s"%str(_err))
    return _rb_list

def _evwan_config_ip(_ol, _bl, _data, _ob_info):
    _idx = -1
    _ele = ["Save OBA-Config", "Restart OBA"]
    _item = None
    _mProg = bv.MixedProgBarInfo("Extra-WAN-IP Configure", _ele)
    
    logger.info("Start Extra-WAN-IP Configure...")
    try:
        ### 1. Save OBA-Config
        _idx += 1
        _item = _ele[_idx]
        _mProg.inc(10)
        bv.update_progBar(_mProg, _item)
        
        today = datetime.datetime.now()
        _bid = today.strftime('%y%m%d%H%M')
        _bname = oc.DIR_TMP + oc.VAL_OBA_NAME + ".conf.bak.%s"%str(_bid)
        if not _ol.copyFile(oc.FILE_OBA_CONF, _bname) :
            if bv.confirm_ok("Fail to Backup OBA-Config.\nContinue?") != bv.RET_OK :
                logger.error("Fail to Change Extra-WAN-IP, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                bv.alert("Fail to Change Extra-WAN-IP, OBA-Config Backup Error\n - src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                return False
            else:
                logger.warning(" - Fail to Change Extra-WAN-IP, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
        try:
            _ob_info.saveToCfg()
        except Exception, e:
            logger.error("Fail to Change Extra-WAN-IP, OBA-Config Save Error, ob_info=%s"%str(_ob_info))
            logger.exception(e)
            bv.alert("Fail to Change Extra-WAN-IP, OBA-Config Save Error")
            return False
        
        _data[_TAG_RECOVERY_EVW].append(_RCVR_OBA_CONF)
        _data[_RCVR_OBA_CONF] = _bname
        
        logger.info(" - SUCC: %s For Extra-WAN-IP Change"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 2. restart OBA
        _idx += 1
        _item = _ele[_idx]
        _mProg.inc(10)
        bv.update_progBar(_mProg, _item)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False)
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True)
        if not _ret :
            if bv.confirm_ok("Fail to Start Onebox-Agent.\nContinue?") == bv.RET_OK :
                _data[_TAG_SKIP_WAN].append(_SKWN_SW_VNF)
                logger.warning(" - Fail to Start OBA, Continue...")
            else:
                _data[_TAG_RECOVERY_EVW].append(_RCVR_OBA_START)
                logger.error("Fail to Change Extra-WAN-IP, OBA Start Error, err=%s"%str(_err))
                bv.alert("Fail to Start Onebox-Agent")
                return False
        
        logger.info(" - SUCC: %s For Extra-WAN-IP Change"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        return True
    except Exception, e:
        logger.error("Fail to Change Extra-WAN-IP, %s Error, exc=%s"%( str(_item), str(e) ))
        logger.exception(e)
        bv.alert("Fail to %s, exc=%s"%( str(_item), str(e) ))
        return False

def _chk_wan_mod_api(_ofIP, _ofPort, _ob_id):
    _retry = 5
    _url = oc.URL_ORCHF_BASE(_ofIP, _ofPort) + _URL_OB_STATUS%_ob_id
    _last_err = None
    _last_res = False
    for _ii in range(_retry):
        try:
            _ret, _ecode, _res = rest_api.sendReq(oc.HEADER, _url, "GET")
            if not _ret :
                _last_err = "API Call Error, err=%s"%str(_res)
                logger.warning("   Fail to Check Wan-Mod API, API Call Error, retry=%s/%s, h-code=%s, res=%s"%( str(_ii+1), str(_retry), str(_ecode), str(_res) ))
            else:
                if type(_res) == list and len(_res) > 0 and type(_res[0]) == dict \
                    and _res[0].has_key('status') and str(_res[0]['status']).find(oc.STATUS_ORCHF_NORMAL) > -1 :
                    logger.info("   SUCC: Chk Wan-Mod API")
                    _last_res = True
                    _last_err = None
                    break
                else:
                    _last_err = "Invalid API Return, ret=%s"%str(_res)
                    logger.warning("   Fail to Check Wan-Mod API, Invalid API Return, retry=%s/%s, h-code=%s, res=%s"%( str(_ii+1), str(_retry), str(_ecode), str(_res) ))
        except Exception, e:
            logger.error("   Fail to Check Wan-Mod API, exc=%s"%( str(e) ))
            logger.exception(e)
            return False, "Check Error, exc=%s"%str(e)
        sleep(3)
    
    return _last_res, _last_err
    


def _reqWanPortMod(_ol, _ofIP, _ofPort, _ob_id, _mode, _ob_info, progInfo, _net_info=None):
    _retry = 5
    if _net_info == None :
        _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
        _net_info = ob_info.OB_NET()
        _net_info.init(_ob_info.is_in_band(), _ob_info.utm_local_ip(),
                       _has_utm, _ol.getWanMode(_ob_info), 
                       _ob_info.mgmt_list(), _ob_info.wan_list(), _ob_info.extra_wan_list())
        
        for _ii in range(_retry) :
            _ret, _net_info = _ol.refresh_wan(_net_info, _ob_info, _caller="BTA-WanPort%s"%str(_mode))
            if not _ret :
                logger.warning(" - - Fail to Request Wan-Port %s, Refresh Wan Error, retry=%s/%s"%( str(_mode), str(_ii+1), str(_retry) ))
            else:
                logger.info(" - - SUCC: Refresh WAN for Request Wan-Port %s"%str(_mode))
                break
            sleep(3)
    
    _req_body = _ol.to_obinfo_for_orchf(_net_info, _ob_info)
    _url = oc.URL_ORCHF_BASE(_ofIP, _ofPort) + _URL_WAN_PORT_MOD%_ob_id
    _body = {'nic_mod':_req_body}
    _up = None
    try:
        _up = bv.UpdateProg(progInfo, 2, 1, "Request Wan-Port %s"%_mode)
        _up.start()
        while True:
            _ret, _ecode, _res = rest_api.sendReq(oc.HEADER, _url, "POST", _body, _to=60)
            if not _ecode in (0, 200, 400, 500, 599) and not _ret :
                _up.stop()
                logger.error("   Fail to Request Wan-Port %s, HTTP Error, ret=%s, body=%s, err=%s"%( _mode, str(_res), str(_body), str(_res) ))
                bv.alert("Fail to Request Wan-Port %s, HTTP Error, err=%s"%( _mode, str(_res) ))
                return False
            elif type(_res) == dict and (not _res.has_key('status') or _res['status'] == oc.STATUS_ERROR) :
                _up.stop()
                logger.error("   Fail to Request Wan-Port %s, API Return Error, ret=%s, body=%s"%( _mode, str(_res), str(_body) ))
                bv.alert("Fail to Request Wan-Port %s, API Return Error"%( _mode ))
                return False
            
            if _ret and type(_res) == dict and _res.has_key('status') and _res['status'] != oc.STATUS_ERROR :
                break
            
            logger.info(" - - SUCC: Wait to Response of WAN-MOD-REQ, code=%s, res=%s, ret=%s"%( str(_ecode), str(_res), str(_ret) ))
            sleep(5)
        
        _up.stop()
        logger.info("   SUCC: Request Wan-Port %s, res=%s"%( _mode, str(_res) ))
        return True
    except Exception, e:
        if _up != None : _up.stop()
        logger.error("   Fail to Request Wan-Port %s, exc=%s"%( _mode, str(e) ))
        logger.exception(e)
        bv.alert("Fail to Request Wan-Port %s\n - exc=%s"%( _mode, str(e) ))
        return False

def _progWanPortMod(_ofIP, _ofPort, _ob_id, _mode, progInfo):
    _url = oc.URL_ORCHF_BASE(_ofIP, _ofPort) + _URL_WAN_PORT_PROG%_ob_id
    _remain = _TO_WAN_PORT_MOD_WAIT
    _tot_wt = _TO_WAN_PORT_MOD_WAIT
    _sleep = 5
    _waste_t = 0
    _init_prog = progInfo.perc_item()
    while True :
        sleep(_sleep)
        _remain -= _sleep
        _waste_t += _sleep
        if _remain < 0 :
            if bv.confirm_ok("Continue Waiting for WAN-Port %s?\n(Additional Wait=1m)"%_mode) == bv.RET_OK :
                _remain = 60
                _tot_wt += 60
            else:
                break
        
        _prog = _init_prog + ( (100-((_tot_wt - _waste_t)*100/_tot_wt))*(100-_init_prog)/100 )
        if _prog >= 100 :
            _prog = 99
        progInfo.set_perc(_prog)
        bv.update_progBar(progInfo, "Check Wan-Port %s..., timeout=%s"%( _mode, str(_remain) ))
        try:
            _ret, _ecode, _res = rest_api.sendReq(oc.HEADER, _url, "GET")
            if not _ecode in (0, 200, 400, 500, 599) and not _ret :
                logger.error("   Fail to Check Wan-Port %s, HTTP Error, err=%s"%( _mode, str(_res) ))
                bv.alert("Fail to Check Wan-Port %s, HTTP Error, err=%s"%( _mode, str(_res) ))
                return False
            elif type(_res) == dict and _res.has_key('status') and _res['status'] == oc.STATUS_ERROR :
                logger.error("   Fail to Check Wan-Port %s, API Return Error, ret=%s"%( _mode, str(_res) ))
                bv.alert("Fail to Check Wan-Port %s, API Return Error"%( _mode ))
                return False
            
            if _ret and type(_res) == dict and _res.has_key('status') and _res['status'] == oc.STATUS_DONE :
                logger.info("   SUCC: Wan-Port %s, res=%s"%( _mode, str(_res) ))
                return True
            
            logger.info("   Wait for Check Wan-Port %s, timeout=%s, res=%s"%( _mode, str(_remain), str(_res) ))
        except Exception, e:
            logger.error("   Fail to Request Wan-Port %s, exc=%s"%( _mode, str(e) ))
            logger.exception(e)
            bv.alert("Fail to Request Wan-Port %s\n - exc=%s"%( _mode, str(e) ))
            return False
    
    logger.error("   Fail to Check Wan-Port %s, TimeOut, to=%s"%( _mode, str(_tot_wt) ))
    bv.alert("Fail to Check Wan-Port %s, TimeOut"%( _mode ))
    return False

def _rb_txt(_rtarget, _rfinish):
    _txt = "Recovery Status\n\n"
    
    for _rr in _rtarget :
        _txt = _txt + " - %-20s: %s\n"%( _rcvr_to_txt(_rr), str(("SUCC" if _rr in _rfinish else "FAIL")) )
    
    return _txt

def _rcvr_to_txt(_rcvr):
    if _rcvr == _RCVR_OBA_CONF :       return "Onebox-Agent Config"
    if _rcvr == _RCVR_HOST_NET :       return "Host Network"
    if _rcvr == _RCVR_VNF_RESTORE :    return "VNF Restore"
    if _rcvr == _RCVR_VWAN_RESTORE :   return "V-WAN Restore"
    if _rcvr == _RCVR_VWAN_PORT_RESTORE : return "V-WAN Port Restore"
    if _rcvr == _RCVR_SW_VNF :         return "WAN-Switch to VNF"
    if _rcvr == _RCVR_OBA_RESUME :     return "OBA WAN-Mon Resume"
    if _rcvr == _RCVR_OBA_START :      return "OBA Start"
    if _rcvr == _RCVR_VNET_LAN_NIC :   return "VNET LAN NIC Restore"
    if _rcvr == _RCVR_VNET_LAN_NET :   return "VNET LAN Network Restore"
    if _rcvr == _RCVR_CHG_VNET_PORT :  return "VNET Port Restore"
    if _rcvr == _RCVR_VNET_EVW_NIC :   return "VNET Extra-Wan Restore"


def _recovery_wan_port(_mode, _data):
    _ol = _data[oc.OTAG_LIB_OB]
    _bl = _data[oc.OTAG_LIB_BTA]
    _uip = _data[oc.OTAG_OBA_INFO].utm_local_ip()
    _recovery_list_tmp = _data[_TAG_RECOVERY_WAN]
    _recovery_list = []
    _recovery_txt_list = []
    _same_state = _bl.is_same_state_for_utm_restore()
    if _RCVR_OBA_CONF in _recovery_list_tmp :
        _recovery_list.append(_RCVR_OBA_CONF)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_OBA_CONF))
    if _RCVR_HOST_NET in _recovery_list_tmp :
        _recovery_list.append(_RCVR_HOST_NET)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_HOST_NET))
    if _RCVR_VWAN_PORT_RESTORE in _recovery_list_tmp :
        _recovery_list.append(_RCVR_VWAN_PORT_RESTORE)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_VWAN_PORT_RESTORE))
    if _mode == "ADD" and not _same_state :
        if _RCVR_VNF_RESTORE in _recovery_list_tmp :
            _recovery_list.append(_RCVR_VNF_RESTORE)
            _recovery_txt_list.append(_rcvr_to_txt(_RCVR_VNF_RESTORE))
        if _RCVR_VWAN_RESTORE in _recovery_list_tmp :
            _recovery_list.append(_RCVR_VWAN_RESTORE)
            _recovery_txt_list.append(_rcvr_to_txt(_RCVR_VWAN_RESTORE))
    else:
        if _RCVR_VWAN_RESTORE in _recovery_list_tmp :
            _recovery_list.append(_RCVR_VWAN_RESTORE)
            _recovery_txt_list.append(_rcvr_to_txt(_RCVR_VWAN_RESTORE))
        if _RCVR_VNF_RESTORE in _recovery_list_tmp :
            _recovery_list.append(_RCVR_VNF_RESTORE)
            _recovery_txt_list.append(_rcvr_to_txt(_RCVR_VNF_RESTORE))
    if _RCVR_SW_VNF in _recovery_list_tmp :
        _recovery_list.append(_RCVR_SW_VNF)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_SW_VNF))

    _data[_TAG_RECOVERY_WAN] = _recovery_list
    _mProg = bv.MixedProgBarInfo("Start Recovery...", _recovery_txt_list)
    _idx = -1
    _up = None
    _rb_list = []
    
    try:
        ### oba config
        if _RCVR_OBA_CONF in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            if _ol.copyFile(_data[_RCVR_OBA_CONF], oc.FILE_OBA_CONF) :
                _rb_list.append(_RCVR_OBA_CONF)
            else:
                logger.error("Fail to Recovery, OBA-Config Rollback Error, bak=%s"%str(_data[_RCVR_OBA_CONF]))
                bv.alert("Fail to Rollback OBA-Config\n - bak=%s"%str(_data[_RCVR_OBA_CONF]))
                return _rb_list
            logger.info(" - SUCC: %s For Recovery WAN-Port-%s"%(_item, _mode))
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
        
        with open(oc.FILE_OBA_CONF, "r") as f:
            _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
        _ob_info = OB_INFO().loadByCfg(_oba_cfg, True)
        
        ### host network
        if _RCVR_HOST_NET in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            try:
                _data[oc.OTAG_OBA_INFO] = _ob_info
                _mProg.inc(12)
                bv.update_progBar(_mProg)
                
                _up = bv.UpdateProg(_mProg, 2, 1, "Reset Host-Net...")
                _up.start()
                _ret, _err = _bl.reset_os_br()
                if not _ret :
                    logger.warning(" - Fail to Recovery, Host-Net Reset Error, err=%s"%str(_err))
                _ret, _err = _bl.reset_vim_br(oc.VAL_DEF_VI_WAN_BR_LIST)
                if not _ret :
                    logger.warning(" - Fail to Recovery, VIM-Net Reset Error, err=%s"%str(_err))
                _up.set_msg("Delete Default-GW...")
                if not _ol.del_host_def_route() :
                    logger.warning(" - Fail to Recovery, Host Default Route Delete Error")
                _up.stop()
                
                _mgmt_list = _ob_info.mgmt_list()
                _ret, _err = _ol.config_mgmt_net(_mgmt_list, _mProg, bv)
                if not _ret :
                    logger.warning(" - Fail to Recovery, Host-Net Rollback Error, err=%s"%str(_err))
                    _mProg.set_perc(bv.G_STATUS_FAIL)
                else:
                    logger.info(" - SUCC: %s For Recovery WAN-Port-%s"%(_item, _mode))
                    _mProg.set_perc(70)
                    _rb_list.append(_RCVR_HOST_NET)
                
                _mProg.set_perc(100)
            except Exception, e:
                logger.warning(" - Fail to Recovery, Host-Net Rollback Error, exc=%s"%str(e))
                logger.error(e)
                _mProg.set_perc(bv.G_STATUS_FAIL)
            bv.update_progBar(_mProg)
        
        ### vim wan port restore
        if _RCVR_VWAN_PORT_RESTORE in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            
            # reset VIM-net
            _up = bv.UpdateProg(_mProg, 2, 1, "Reset VWAN-Port...")
            _up.start()
            _ret, _err = _bl.reset_vim_br(oc.VAL_DEF_VI_WAN_BR_LIST)
            if not _ret :
                _up.stop()
                logger.warning(" - Fail to Recovery, VWAN-Port Reset Error, err=%s"%( _err ))
                _mProg.set_perc(bv.G_STATUS_FAIL)
            else:
                logger.info(" - SUCC: %s For Recovery WAN-Port-%s"%(_item, _mode))
                _mProg.set_perc(100)
                _rb_list.append(_RCVR_VWAN_PORT_RESTORE)
            _up.stop()
            bv.update_progBar(_mProg)
        
        ### vnf restore
        _vnf_bak_retry = False
        _vnf_r_idx = -1
        for _ii in range(2) :
            ## vnf-config restore
            if _idx+1 < len(_recovery_list) and _RCVR_VNF_RESTORE == _recovery_list[_idx+1] :
                _idx += 1
                _item = _recovery_txt_list[_idx]
                _mProg.set_index(_idx)
                _mProg.inc(5)
                bv.update_progBar(_mProg)
                
                _up = bv.UpdateProg(_mProg, 2, 1, "Restore VNF...")
                _up.start()
                if not _restoreVNF(_bl, _ob_info.utm_local_ip(), _mProg) :
                    _vnf_bak_retry = True
                    _vnf_r_idx = _idx
                    logger.warning(" - Fail to Recovery, VNF Restore Error")
                    _mProg.set_perc(bv.G_STATUS_FAIL)
                else:
                    _ol.delFile( oc.FILE_TMP_UTM_DR )
                    _ol.delFile( oc.FILE_BAK_VNF_UTM )
                    _ol.delFile( oc.FILE_TMP_UTM_UR )
                    _ol.delFile( oc.FILE_TMP_UTM_RR )
                    _ol.delFile( oc.FILE_TMP_UTM_IF )
                    _ol.delFile( oc.FILE_TMP_UTM_ARP )
                    logger.info(" - SUCC: %s For Recovery WAN-Port-%s"%(_item, _mode))
                    _mProg.set_perc(100)
                    _rb_list.append(_RCVR_VNF_RESTORE)
                _up.stop()
                bv.update_progBar(_mProg)
            
            ## v-port restore
            if _idx+1 < len(_recovery_list) and _RCVR_VWAN_RESTORE == _recovery_list[_idx+1] :
                _idx += 1
                _item = _recovery_txt_list[_idx]
                _mProg.set_index(_idx)
                _mProg.inc(5)
                bv.update_progBar(_mProg)
                
                _wan_list = []
                for _wan in _ob_info.wan_list() :
                    _wdhcp = _wan.is_dhcp()
                    _wmac = _wan.mac()
                    _wmode = 'host'
                    if not _ob_info.is_in_band() :
                        _wmode = oc.VAL_WAN_MD_OUTBAND
                    _wnic = _wan.nic()
                    
                    _wip = _wan.ip()
                    _wgw = _wan.gw()
                    try:
                        _wpfx = IPv4Network("0.0.0.0/%s"%str(_wan.mask()))._prefixlen
                    except Exception, e :
                        logger.warning(" - Fail to Recovery, Invalid Wan Mask, mask=%s, err=%s"%( str(_wan.mask()), str(e) ))
                        _wpfx = 0
                    
                    _wan_list.append({'mac':_wmac, 'mode':_wmode, 'nic':_wnic,
                                      'public_cidr_prefix': _wpfx, 'public_gw_ip': _wgw,
                                      'public_ip': _wip, 'public_ip_dhcp': _wdhcp})
                
                _ofIP, _ofPort = _ob_info.orchf_site()
                _ob_id = _ob_info.ob_id()
                _rmode = "RECOVERY(%s)"%str(_mode)
                ## Request
                _ret = _reqWanPortMod(_ol, _ofIP, _ofPort, _ob_id, _rmode, _ob_info, _mProg)
                if not _ret :
                    logger.warning(" - Fail to Recovery, V-WAN Restore Request Error")
                    _mProg.set_perc(bv.G_STATUS_FAIL)
                else:
                    ## Progress
                    _ret = _progWanPortMod(_ofIP, _ofPort, _ob_id, _rmode, _mProg)
                    if not _ret :
                        logger.warning(" - Fail to Recovery, V-WAN Restore Result Error")
                        _mProg.set_perc(bv.G_STATUS_FAIL)
                    else:
                        logger.info(" - SUCC: %s For Recovery WAN-Port-%s"%(_item, _mode))
                        _mProg.set_perc(100)
                        _rb_list.append(_RCVR_VWAN_RESTORE)
                
                bv.update_progBar(_mProg)
        
        if _vnf_bak_retry and _vnf_r_idx > -1 :
            _item = _recovery_txt_list[_vnf_r_idx]
            _mProg.set_index(_vnf_r_idx)
            _mProg.set_perc(5)
            bv.update_progBar(_mProg)
            
            _up = bv.UpdateProg(_mProg, 2, 1, "Retry Restore VNF...")
            _up.start()
            if not _restoreVNF(_bl, _ob_info.utm_local_ip(), _mProg) :
                logger.warning(" - Fail to Recovery, VNF Restore Error")
                _mProg.set_perc(bv.G_STATUS_FAIL)
            else:
                _ol.delFile( oc.FILE_TMP_UTM_DR )
                _ol.delFile( oc.FILE_BAK_VNF_UTM )
                _ol.delFile( oc.FILE_TMP_UTM_UR )
                _ol.delFile( oc.FILE_TMP_UTM_RR )
                _ol.delFile( oc.FILE_TMP_UTM_IF )
                _ol.delFile( oc.FILE_TMP_UTM_ARP )
                logger.info(" - SUCC: %s For Recovery WAN-Port-%s"%(_item, _mode))
                _mProg.set_perc(100)
                _rb_list.append(_RCVR_VNF_RESTORE)
            _up.stop()
            bv.update_progBar(_mProg)
        
        ## wan-switch to vnf
        if _RCVR_SW_VNF in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            
            _ret = _bl.wanSw_obaRun(_data[oc.OTAG_OBA_INFO], oc.VAL_WAN_MD_VNF, False, _uip, _mProg)
            if not _ret :
                logger.warning(" - Fail to Recovery, WAN-Switch to VNF Error")
                _mProg.set_perc(bv.G_STATUS_FAIL)
            else:
                logger.info(" - SUCC: %s For Recovery WAN-Port-%s"%(_item, _mode))
                _mProg.set_perc(100)
                _rb_list.append(_RCVR_SW_VNF)
            
            bv.update_progBar(_mProg)
        
        
        ## oba wanmon resume
        if _RCVR_OBA_RESUME in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
             
            _url_resume = _ob_info.url_oba("127.0.0.1") + _URL_SCHD_RESUME
            _ret, _ecode, _res = rest_api.sendReq(oc.HEADER, _url_resume, "GET", cCrt=oc.KEY_CLI_CRT, cKey=oc.KEY_CLI_KEY)
            if not _ret or type(_res) != dict or not _res.has_key('result') or _res['result'] != "OK" :
                logger.warning(" - Fail to Recovery, OBA Wan-Mon Resume Error, res=%s"%str(_res))
                _mProg.set_perc(bv.G_STATUS_FAIL)
            else:
                logger.info(" - SUCC: %s For Recovery WAN-Port-%s"%(_item, _mode))
                _rb_list.append(_RCVR_OBA_RESUME)
                _mProg.set_perc(100)
            bv.update_progBar(_mProg)
        
        
        ## oba restart
        if _RCVR_OBA_START in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, None)
            _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, _mProg)
            if not _ret :
                logger.warning(" - Fail to Recovery, OBA Start Error, err=%s"%str(_err))
                _mProg.set_perc(bv.G_STATUS_FAIL)
            else:
                logger.info(" - SUCC: %s For Recovery WAN-Port-%s"%(_item, _mode))
                _rb_list.append(_RCVR_OBA_START)
                _mProg.set_perc(100)
            bv.update_progBar(_mProg)
        
    except Exception, e:
        logger.error("Fail to Recovery Wan-Port-%s, exc=%s"%(_mode, str(e)))
        logger.exception(e)
        if _up != None : _up.stop()
        bv.alert("Fail to Recovery Wan-Port-%s, exc=%s"%(_mode, str(e)))
    
    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, None)
    if not _ret :
        logger.warning("   - Fail to Start OBA, err=%s"%str(_err))
    return _rb_list


def _recovery_lan_port(_mode, _data):
    _ol = _data[oc.OTAG_LIB_OB]
    _bl = _data[oc.OTAG_LIB_BTA]
    _recovery_list_tmp = _data[_TAG_RECOVERY_LAN]
    _recovery_list = []
    _recovery_txt_list = []
    if _RCVR_OBA_CONF in _recovery_list_tmp :
        _recovery_list.append(_RCVR_OBA_CONF)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_OBA_CONF))
    if _RCVR_VNET_LAN_NIC in _recovery_list_tmp :
        _recovery_list.append(_RCVR_VNET_LAN_NIC)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_VNET_LAN_NIC))
    
    _data[_TAG_RECOVERY_LAN] = _recovery_list
    
    _mProg = bv.MixedProgBarInfo("Start Recovery...", _recovery_txt_list)
    _idx = -1
    
    _rb_list = []
    _up = None
    
    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, None)
    if not _ret :
        logger.warning("   - Fail to Stop OBA, err=%s"%str(_err))
    
    try:
        if _RCVR_OBA_CONF in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            if _ol.copyFile(_data[_RCVR_OBA_CONF], oc.FILE_OBA_CONF) :
                _rb_list.append(_RCVR_OBA_CONF)
            else:
                logger.error("Fail to Recovery, OBA-Config Rollback Error, bak=%s"%str(_data[_RCVR_OBA_CONF]))
                bv.alert("Fail to Recovery, OBA-Config Rollback Error\n - bak=%s"%str(_data[_RCVR_OBA_CONF]))
                return _rb_list
            logger.info(" - SUCC: %s For Recovery LAN-Port-%s"%(_item, _mode))
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
        
        with open(oc.FILE_OBA_CONF, "r") as f:
            _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
        _ob_info = OB_INFO().loadByCfg(_oba_cfg, True)
        
        if _RCVR_VNET_LAN_NIC in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            
            _up = bv.UpdateProg(_mProg, 2, 1, "Reset VIM Network...")
            _up.start()
            _net_name = _data[_RCVR_VNET_LAN_NIC]
            _brname = oc.VAL_DEF_VNF_LAN_BR_PFX + _net_name
            _ret, _err = _bl.reset_vim_br([_brname])
            if not _ret :
                _up.stop()
                logger.error("Fail to Recovery, VIM-Port reset Error, br=%s"%str(_brname))
                bv.alert("Fail to Recovery, VIM-Port reset Error, br=%s"%( str(_brname) ))
                return _rb_list
            
            _up.set_msg("Recovery VIM Port...")
            _lan_info = _ob_info.lan_xnet(_net_name)
            for _lnic in _lan_info.nics() :
                if not _ol.get_vim().add_br_port(_brname, _lnic, _ob_info.ovs_dpdk()) :
                    logger.error("Fail to Recovery, VIM Port Add Error, br=%s, port=%s"%( str(_brname), str(_lnic) ))
                    _up.stop()
                    bv.alert("Fail to Recovery, VIM Port Add Error")
                    return _rb_list
            _up.stop()
            
            _rb_list.append(_RCVR_VNET_LAN_NIC)
            logger.info(" - SUCC: %s For Recovery LAN-Port-%s"%(_item, _mode))
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
    except Exception, e:
        logger.error("Fail to Recovery Lan-Port-%s, exc=%s"%(_mode, str(e)))
        logger.exception(e)
        if _up != None : _up.stop()
        bv.alert("Fail to Recovery Lan-Port-%s, exc=%s"%(_mode, str(e)))
    
    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, None)
    if not _ret :
        logger.warning("   - Fail to Start OBA, err=%s"%str(_err))
    return _rb_list

def _recovery_evw_port(_data, _mode):
    _ol = _data[oc.OTAG_LIB_OB]
    _bl = _data[oc.OTAG_LIB_BTA]
    _recovery_list_tmp = _data[_TAG_RECOVERY_EVW]
    _recovery_list = []
    _recovery_txt_list = []
    if _RCVR_OBA_CONF in _recovery_list_tmp :
        _recovery_list.append(_RCVR_OBA_CONF)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_OBA_CONF))
    if _RCVR_VNET_EVW_NIC in _recovery_list_tmp :
        _recovery_list.append(_RCVR_VNET_EVW_NIC)
        _recovery_txt_list.append(_rcvr_to_txt(_RCVR_VNET_EVW_NIC))
    
    _data[_TAG_RECOVERY_EVW] = _recovery_list
    
    _mProg = bv.MixedProgBarInfo("Start Recovery...", _recovery_txt_list)
    _idx = -1
    
    _rb_list = []
    _up = None
    
    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, None)
    if not _ret :
        logger.warning("   - Fail to Stop OBA, err=%s"%str(_err))
    
    try:
        if _RCVR_OBA_CONF in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            if _ol.copyFile(_data[_RCVR_OBA_CONF], oc.FILE_OBA_CONF) :
                _rb_list.append(_RCVR_OBA_CONF)
            else:
                logger.error("Fail to Recovery, OBA-Config Rollback Error, bak=%s"%str(_data[_RCVR_OBA_CONF]))
                bv.alert("Fail to Recovery, OBA-Config Rollback Error\n - bak=%s"%str(_data[_RCVR_OBA_CONF]))
                return _rb_list
            logger.info(" - SUCC: %s For Recovery Extra-WAN-Port-%s"%(_item, _mode))
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
        
        if _RCVR_VNET_EVW_NIC in _recovery_list :
            _idx += 1
            _item = _recovery_txt_list[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            
            _up = bv.UpdateProg(_mProg, 2, 1, "Recovery VIM Network...")
            _up.start()
            _net_list = _data[_RCVR_VNET_EVW_NIC]
            if _mode == "ADD" :
                for _evw in _net_list :
                    _brname = _evw.bridge()
                    _ret, _err = _bl.reset_vim_br([_brname])
                    if not _ret :
                        _up.stop()
                        logger.error("Fail to Recovery, VIM-Port reset Error, br=%s"%str(_brname))
                        bv.alert("Fail to Recovery, VIM-Port reset Error, br=%s"%( str(_brname) ))
                        return _rb_list
            else:
                for _evw in _net_list :
                    _brname = _evw.bridge()
                    _nic = _evw.nic()
                    _ifs = _ol.get_vim().get_br_ifs(_brname)
                    if type(_ifs) == list and not _nic in _ifs :
                        _ob_info = _data[oc.OTAG_OBA_INFO]
                        _rret = _ol.get_vim().add_br_port(_brname, _nic, _ob_info.ovs_dpdk())
                        if not _rret :
                            _up.stop()
                            logger.error("Fail to Recovery, VIM-Port reset Error, br=%s, nic=%s"%( str(_brname), str(_nic) ))
                            bv.alert("Fail to Recovery, VIM-Port reset Error, br=%s, nic=%s"%( str(_brname), str(_nic) ))
                            return _rb_list
            _up.stop()
            
            _rb_list.append(_RCVR_VNET_EVW_NIC)
            logger.info(" - SUCC: %s For Recovery Extra-WAN-Port-%s"%(_item, _mode))
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
    except Exception, e:
        logger.error("Fail to Recovery Extra-WAN-Port-%s, exc=%s"%( _mode, str(e)))
        logger.exception(e)
        if _up != None : _up.stop()
        bv.alert("Fail to Recovery Extra-WAN-Port-%s, exc=%s"%( _mode, str(e) ))
    
    _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, None)
    if not _ret :
        logger.warning("   - Fail to Start OBA, err=%s"%str(_err))
    return _rb_list

def _show_fail_skip_item(_skip_list) :
    if len(_skip_list) < 1:
        return
    
    _show_list = []
    
    if _SKWN_VNF_UNUSE_DEL in _skip_list :
        _show_list.append(_SKWN_VNF_UNUSE_DEL)
    if _SKWN_VNF_IP_CHG in _skip_list :
        _show_list.append(_SKWN_VNF_IP_CHG)
    if _SKWN_VNF_IP_SETTING in _skip_list :
        _show_list.append(_SKWN_VNF_IP_SETTING)
    if _SKWN_VNF_ROUTE_SETTING in _skip_list :
        _show_list.append(_SKWN_VNF_ROUTE_SETTING)
    if _SKWN_SW_VNF in _skip_list :
        _show_list.append(_SKWN_SW_VNF)
    if _SKWN_OBA_START in _skip_list :
        _show_list.append(_SKWN_OBA_START)
    else:
        if _SKWN_OBA_WANMON_RESUME in _skip_list :
            _show_list.append(_SKWN_OBA_WANMON_RESUME)

    
    _txt = "Must Do Following Items...\n\n"
    _idx = 1
    for _s_item in _show_list :
        if _SKWN_VNF_UNUSE_DEL == _s_item :
            _txt += ( "  %2s. %s\n"%( str(_idx), "Delete VNF's UnUse-Interfaces" ) )
        if _SKWN_VNF_IP_CHG == _s_item :
            _txt += ( "  %2s. %s\n"%( str(_idx), "Change VNF's IPs" ) )
        if _SKWN_VNF_IP_SETTING == _s_item :
            _txt += ( "  %2s. %s\n"%( str(_idx), "Configure VNF's IPs" ) )
        if _SKWN_VNF_ROUTE_SETTING == _s_item :
            _txt += ( "  %2s. %s\n"%( str(_idx), "Configure VNF's Routes" ) )
        if _SKWN_SW_VNF == _s_item :
            _txt += ( "  %2s. %s\n"%( str(_idx), "WAN-Switch to VNF" ) )
        if _SKWN_OBA_WANMON_RESUME == _s_item :
            _txt += ( "  %2s. %s\n"%( str(_idx), "Resume OneBox-Agent's WAN-Monitor" ) )
        if _SKWN_OBA_START == _s_item :
            _txt += ( "  %2s. %s\n"%( str(_idx), "Start/Restart OneBox-Agent" ) )
        
        _idx += 1
    
    logger.debug(" - - ToDO:\n%s"%str(_txt))
    bv.notify(_txt)
    return
    




class OBNetConf(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "OBNetConf", None)
    
    def _select(self, _data):
        _data[bc.FUNC_TITLE] = "Config OB Network"
        
        _ret = bv.get_menu("OB Network Config...", [("1", "IP Configuration"), 
                                                    ("2", "Port Add"), 
                                                    ("3", "Port Delete"), 
                                                    ("4", "Port Change"), 
                                                    ("5", "WAN Switch")])
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        else:
            return _ret
    
    def _next(self, _ret, _data):
        if _ret == "1" :
            return _OBNetIP(self).get_res(_data)
        elif _ret == "2" :
            return _OBNetPortAdd(self).get_res(_data)
        elif _ret == "3" :
            return _OBNetPortDel(self).get_res(_data)
        elif _ret == "4" :
            _data[bc.FUNC_TITLE] = "Port Change"
            return _OBNetPortChgSetting(self).get_res(_data)
        elif _ret == "5" :
            return _OBWanSwitch(self).get_res(_data)
        else:
            return self._err_unimpl(_ret)



class _OBNetIP(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObIp", _prevMenu)
    
    def _select(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _evw_list = _ob_info.extra_wan_list()
        _menu = []
        if type(_evw_list) == list and len(_evw_list) > 0 :
            _menu = [("1", "WAN"), ("2", "LAN"), ("3", "Extra-WAN")]
        else:
            _menu = [("1", "WAN"), ("2", "LAN")]
        
        _ret = bv.get_menu("OB IP Configure...", _menu)
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        else:
            return _ret
        
        
    def _next(self, _ret, _data):
        if _ret == '1':
            _data[bc.FUNC_TITLE] = "WAN-IP Configuration"
            return _OBNetIPConfInternetChk(self).get_res(_data)
        elif _ret == '2' :
            _data[bc.FUNC_TITLE] = "LAN-IP Configuration"
            return _OBNetLANNetworkMod(self, "CHG").get_res(_data)
        elif _ret == '3' :
            _data[bc.FUNC_TITLE] = "Extra-WAN-IP Configuration"
            return _OBNetIPConfigEVWan(self).get_res(_data)
        else:
            bv.alert("Unknown Menu")
            return self._RET_BACK



class _OBNetIPConfInternetChk(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObIpConfigInternetChk", _prevMenu)
        self._host_only = False
    
    def _select(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        
        _ret, _delInfo, self._host_only = _chkForNewIP(oc.VAL_NET_TYPE_WAN, _ol, _bl, _ob_info)
        if not _ret :
            return self._RET_ERR
         
        _ret, _delInfoTxt = _bl.to_txt_utm_delinfo(_delInfo)
        if not _ret :
            import json
            _delInfoTxt = json.dumps(_delInfo, indent=2)
            logger.warning(" - Fail to Convert VNF Deleted Info to Text, info=%s"%str(_delInfo))
        
        if _delInfoTxt != None :
            _ret = _confirm_utm_delet_info(_delInfoTxt)
            if _ret == self._RET_BACK :
                return self._RET_BACK
            elif _ret == self._RET_ERR :
                return self._RET_ERR
            logger.debug(" - Deleted Route Info:\n%s"%str(_delInfoTxt))
        
        if _bl.show_obinfo(_ob_info) and bv.confirm_ok("Set New Public IP?") == bv.RET_OK:
            return self._RET_OK
        else:
            return self._RET_BACK
    
    def _next(self, _ret, _data):
        return _OBNetIPConfInternet(self, self._host_only).get_res(_data)



class _OBNetIPConfInternet(_LinkedMenu):

    def __init__(self, _prevMenu, _host_only):
        _LinkedMenu.__init__(self, "ObIpConfigInternet", _prevMenu)
        self._host_only = _host_only
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        
        if _data.has_key(_TAG_NEW_WAN_IP) :
            _new_ob_info = _data[_TAG_NEW_WAN_IP]
        else:
            _new_ob_info = OB_INFO().loadByFile(_data[oc.OTAG_CFG_FILE], True)
            _data[_TAG_NEW_WAN_IP] = _new_ob_info
        _in_band = _new_ob_info.is_in_band()
        _mgmtnet = _new_ob_info.mgmt_list()
        _mgmtMax = len(_mgmtnet)
        
        _wannet = []
        if not _in_band :
            _wannet = _new_ob_info.wan_list()
            if len(_wannet) < 1 :
                logger.error("Fail to Get Previous WAN Network List, Nothing")
                bv.alert("Fail to Get Previous WAN Network List, Nothing")
                return self._RET_ERR
        _wanMax = len(_wannet)
        
        if _mgmtMax < 1:
            logger.error("Fail to Get Previous Mgmt Network List, Nothing")
            bv.alert("Fail to Get Previous Mgmt Network List, Nothing")
            return self._RET_ERR
        
        _mTitle = (lambda x: "Management/Wan" if x else "Management")(_in_band)
        mgmtIdx = 0
        wanIdx = 0
        __idx = 0
        __Title = ""
        __mode = "mgmt"
        while True:
            if mgmtIdx >= _mgmtMax :
                if wanIdx >= _wanMax :
                    break
                else:
                    __net = _wannet[wanIdx]
                    __idx = wanIdx
                    __Title = "WAN"
                    __mode = "wan"
            else:
                __net = _mgmtnet[mgmtIdx]
                __idx = mgmtIdx
                __Title = _mTitle
                __mode = "mgmt"
            
            _title = "%s-%s IP Config(%s)"%(str(__Title), str(__idx), str(__net.nic()))
            _ret = _bl.set_extern_ip(_title, __net)
            if _ret == self._RET_OK :
                if __mode == "mgmt" :
                    mgmtIdx += 1
                else:
                    wanIdx += 1
            elif _ret == self._RET_BACK :
                if __mode == "mgmt" :
                    mgmtIdx -= 1
                    if mgmtIdx < 0 :
                        return self._RET_BACK
                else :
                    wanIdx -= 1
                    if wanIdx < 0 :
                        wanIdx = 0
                        mgmtIdx -= 1
            else:
                return self._RET_ERR
        
        if not _new_ob_info.sync_internet(logger):
            bv.alert("Fail to Sync Internet Info")
            return self._RET_ERR
        
        _data[_TAG_NEW_WAN_IP] = _new_ob_info
        return self._RET_OK
    
    def _next(self, _ret, _data):
        return _OBNetIPConfInternetModify(self, self._host_only).get_res(_data)


class _OBNetIPConfInternetModify(_LinkedMenu):
    
    def __init__(self, _prevMenu, _host_only):
        _LinkedMenu.__init__(self, "ObIpConfigInternetModify", _prevMenu)
        self._host_only = _host_only
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ol = _data[oc.OTAG_LIB_OB]
        _cur_ob_info = _data[oc.OTAG_OBA_INFO]
        _new_ob_info = _data[_TAG_NEW_WAN_IP]
        
        if _bl.show_obinfo(_new_ob_info) and bv.confirm_ok("Apply New Public IP?") == bv.RET_OK:
            if not _wan_config_ip(_ol, _bl, _new_ob_info, _cur_ob_info, self._host_only) :
                return self._RET_ERR
            else:
                return self._RET_OK
        else:
            return self._RET_BACK

    def _next(self, _ret, _data):
        return _ret


class _OBNetIPConfLanChk(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObIpConfigLanChk", _prevMenu)
    
    def _select(self, _data):
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _lan_name = _data[_TAG_LAN_MOD_NAME]
        if _data.has_key(_TAG_NEW_LAN_IP+_lan_name) :
            _new_ob_info = _data[_TAG_NEW_LAN_IP+_lan_name]
        else:
            _new_ob_info = OB_INFO().loadByFile(_data[oc.OTAG_CFG_FILE], True)
            _data[_TAG_NEW_LAN_IP+_lan_name] = _new_ob_info
        
        _lan_info = _new_ob_info.lan_xnet(_lan_name)
        if _lan_info == None :
            logger.error("Fail to Change Lan IP, Invalid LAN-NET Name, name=%s"%str(_lan_name))
            bv.alert("Invalid LAN-NET Name, name=%s\nRetry to Select LAN-NET"%str(_lan_name))
            return self._RET_BACK
        
        ## check ip chg api, bridge-interfaces : wan+lan
        _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
        _data[_TAG_LAN_CHG_HAS_UTM+_lan_name] = _has_utm
        if _has_utm :
            _ret, _delInfo, _ = _chkForNewIP(_lan_name, _ol, _bl, _new_ob_info)
            if not _ret :
                return self._RET_ERR
        
        return self._RET_OK
    
    def _next(self, _ret, _data):
        return _OBNetIPConfLan(self).get_res(_data)
    
        
class _OBNetIPConfLan(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObIpConfigLan", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _lan_name = _data[_TAG_LAN_MOD_NAME]
        _new_ob_info = _data[_TAG_NEW_LAN_IP+_lan_name]
        _lan_info = _new_ob_info.lan_xnet(_lan_name)
        _has_utm = _data[_TAG_LAN_CHG_HAS_UTM+_lan_name]
        
        _prv_lan_gw = _lan_info.gw()
        _prv_lan_mask = _lan_info.mask()
        _prv_lan_addr = None
        try:
            _prv_lan_addr = IPv4Network("%s/%s"%( str(_prv_lan_gw), str(_prv_lan_mask) ))
        except Exception, e:
            logger.error("Fail to Config LAN Network, Invalid Previous LAN Address, addr=%s/%s"%( str(_prv_lan_gw), str(_prv_lan_mask) ))
            logger.exception(e)
            bv.alert("Fail to Config LAN Netowrk, Invalid Previous LAN Address, addr=%s/%s"%( str(_prv_lan_gw), str(_prv_lan_mask) ))
            return self._RET_ERR
        
        ## config lan network info
        while True:
            _ret = _bl.set_lan_ip("LAN-%s Network Config"%_lan_name, _lan_info, _has_utm)
            if _ret == self._RET_OK :
                if _has_utm :
                    _new_lan_gw = _lan_info.gw()
                    try:
                        _cmp_ret = _prv_lan_addr.compare_networks(IPv4Network("%s/%s"%( str(_new_lan_gw), str(_prv_lan_mask) )))
                        if _cmp_ret != 0 :
                            import inspect
                            inspect.getmembers(_prv_lan_addr)
                            _prv_lan_addr_start = None
                            _prv_lan_addr_end = None
                            if _prv_lan_addr._cache.has_key("network") :
                                _prv_lan_addr_start = str(_prv_lan_addr._cache['network']+1)
                            if _prv_lan_addr._cache.has_key("broadcast") :
                                _prv_lan_addr_end = str(_prv_lan_addr._cache['broadcast']-1)
                            if _prv_lan_addr_start != None and _prv_lan_addr_end != None :
                                bv.alert("Fail to Config LAN Network, Different Network Address, addr=%s\n - range: %s ~ %s"%( 
                                                                                str(_new_lan_gw), str(_prv_lan_addr_start), str(_prv_lan_addr_end) ))
                            else:
                                bv.alert("Fail to Config LAN Network, Different Network Address, addr=%s"%str(_new_lan_gw))
                            _lan_info.change(_prv_lan_gw)
                            continue
                        else:
                            break
                    except Exception, e:
                        logger.warning("Fail to Config LAN Network, Invalid New LAN Address, ip=%s"%( str(_new_lan_gw) ))
                        logger.exception(e)
                        bv.alert("Fail to Config LAN Netowrk, Invalid New LAN Address, ip=%s"%( str(_new_lan_gw) ))
                        continue
                else:
                    break
            elif _ret == self._RET_ERR :
                if bv.confirm_ok("Fail to Config LAN-Network Info.\nRetry?") == bv.RET_OK :
                    continue
                else:
                    logger.error("Fail to Config LAN Network Info, net=%s"%str(_lan_info))
                    bv.alert("Fail to Config LAN Network Info")
                    return self._RET_ERR
        _data[_TAG_LAN_NEW_INFO+_lan_name] = _lan_info
        _data[_TAG_NEW_LAN_IP+_lan_name] = _new_ob_info
        return self._RET_OK
    
    def _next(self, _ret, _data):
        return _OBNetIPConfLanModify(self).get_res(_data)


class _OBNetIPConfLanModify(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObIpConfigLanModify", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ol = _data[oc.OTAG_LIB_OB]
        _lan_name = _data[_TAG_LAN_MOD_NAME]
        _new_ob_info = _data[_TAG_NEW_LAN_IP+_lan_name]
        _lan_info = _data[_TAG_LAN_NEW_INFO+_lan_name]
        _has_utm = _data[_TAG_LAN_CHG_HAS_UTM+_lan_name]
        
        _data[_TAG_RECOVERY_LAN] = []
        if _bl.show_obinfo(_new_ob_info) and bv.confirm_ok("Apply New LAN-IP?") == bv.RET_OK:
            _ret = self._RET_ERR
            if _lan_config_ip(_ol, _bl, _data, _new_ob_info, _lan_info, _has_utm) :
                _ret = self._RET_OK
            else:
                _ret_rst = bv.confirm_ok("Restore?")
                if _ret_rst == bv.RET_OK :
                    _rb_list = _restore_lan_config_ip(_data)
                    _rb_result_txt = _rb_txt(_data[_TAG_RECOVERY_LAN], _rb_list)
                    logger.debug(" - - Recovery[LAN-IP] Result:\n%s"%str(_rb_result_txt))
                    bv.confirm_ok(_rb_result_txt)
            
            if _data.has_key(_RCVR_OBA_CONF) :
                _ol = _data[oc.OTAG_LIB_OB]
                _ol.delFile(_data[_RCVR_OBA_CONF])
            if _data.has_key(_RCVR_VNF_RESTORE) :
                _ol = _data[oc.OTAG_LIB_OB]
                _ol.delFile(_data[_RCVR_VNF_RESTORE])
            return _ret
        else:
            return self._RET_BACK

    def _next(self, _ret, _data):
        return _ret


class _OBNetIPConfigEVWan(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObIpConfigEVWannModify", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _evw_list = _ob_info.extra_wan_list()
        if type(_evw_list) != list or len(_evw_list) < 1 :
            logger.error("Fail to Config Extra-Wan IP, No Extra-Wan, evwan=%s"%str(_evw_list))
            bv.alert("No Extra-Wan, evwan=%s"%str(_evw_list))
            return self._RET_ERR
        
        _idx = 0
        _max_len = len(_evw_list)
        _title = 'Extra-VNF WAN'
        while True :
            __net = _evw_list[_idx]
            _tt = "%s(%s) IP Config(%s)"%(str(_title), str(__net.bridge()), str(__net.nic()))
            _ret = _bl.set_extern_ip(_tt, __net)
            if _ret == self._RET_OK :
                if _idx >= _max_len -1 :
                    break
                _idx += 1
            elif _ret == self._RET_BACK :
                _idx -= 1
                if _idx < 0 :
                    return self._RET_BACK
            else:
                return self._RET_ERR
        
        return self._RET_OK
        
    def _next(self, _ret, _data):
        return _OBNetIPConfEVWanModify(self).get_res(_data)


class _OBNetIPConfEVWanModify(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObIpConfigEVWanModify", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ol = _data[oc.OTAG_LIB_OB]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _data[_TAG_RECOVERY_EVW] = []
        if _bl.show_obinfo(_ob_info) and bv.confirm_ok("Apply Extra-WAN IP?") == bv.RET_OK:
            if _evwan_config_ip(_ol, _bl, _data, _ob_info) :
                return self._RET_OK
            else:
                _ret_rst = bv.confirm_ok("Restore?")
                if _ret_rst == bv.RET_OK :
                    _rb_list = _restore_evw_config_ip(_data)
                    _rb_result_txt = _rb_txt(_data[_TAG_RECOVERY_EVW], _rb_list)
                    logger.debug(" - - Recovery[Extra-WAN-IP] Result:\n%s"%str(_rb_result_txt))
                    bv.confirm_ok(_rb_result_txt)
            
            if _data.has_key(_RCVR_OBA_CONF) :
                _ol = _data[oc.OTAG_LIB_OB]
                _ol.delFile(_data[_RCVR_OBA_CONF])
            return self._RET_ERR
        else:
            return self._RET_BACK

    def _next(self, _ret, _data):
        return _ret




###################
### Port Config ###
###################

class _OBNetPortAdd(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObPortAdd", _prevMenu)
    
    def _select(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _evw_list = _ob_info.extra_wan_list()
        _menu = []
        if type(_evw_list) == list and len(_evw_list) >= oc.VAL_EVWAN_MAX_NUM :
            _menu = [("1", "WAN"), ("2", "LAN")]
        else:
            _menu = [("1", "WAN"), ("2", "LAN"), ("3", "Extra-WAN")]
        _ret = bv.get_menu("OB Port Add...", _menu)
        
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        else:
            return _ret
    
    def _next(self, _ret, _data):
        if _ret == '1':
            _data[bc.FUNC_TITLE] = "WAN-Port ADD"
            return _OBNetWANPortAdd(self).get_res(_data)
        elif _ret == '2' :
            _data[bc.FUNC_TITLE] = "LAN-Port ADD"
            return _OBNetLANNetworkMod(self, "ADD").get_res(_data)
        elif _ret == '3' :
            _data[bc.FUNC_TITLE] = "Extra-WAN-Port ADD"
            return _OBNetEVWPortAdd(self).get_res(_data)
        else:
            bv.alert("Unknown Menu")
            return self._RET_BACK


class _OBNetPortDel(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObPortDel", _prevMenu)
    
    def _select(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _evw_list = _ob_info.extra_wan_list()
        _menu = []
        if type(_evw_list) == list and len(_evw_list) > 0 :
            _menu = [("1", "WAN"), ("2", "LAN"), ("3", "Extra-WAN")]
        else:
            _menu = [("1", "WAN"), ("2", "LAN")]
        
        _ret = bv.get_menu("OB Port Del...", _menu)
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        else:
            return _ret
    
    def _next(self, _ret, _data):
        if _ret == '1':
            _data[bc.FUNC_TITLE] = "WAN-Port Del"
            return _OBNetWANPortDel(self).get_res(_data)
        elif _ret == '2' :
            _data[bc.FUNC_TITLE] = "LAN-Port Del"
            return _OBNetLANNetworkMod(self, "DEL").get_res(_data)
        elif _ret == '3' :
            _data[bc.FUNC_TITLE] = "Extra-WAN-Port Del"
            return _OBNetEVWPortDel(self).get_res(_data)
        else:
            bv.alert("Unknown Menu")
            return self._RET_BACK


class _OBNetWANPortAdd(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObWanPortAdd", _prevMenu)
        
        self._up = None
    
    def _do(self, _data):
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _uip = _ob_info.utm_local_ip()
        _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
        
        _idx = 0
        _ele = ["Check Onebox", "Input Wan-Info", "Pause OBA-Scheduler", "WAN-SW to Host", "Apply WAN-IP", 
                "Apply Host-Network", "Save OBA-Config", 
                "Refresh WAN-IP", "Add VNF-WAN-Port", "Setting VNF-WAN",
                "WAN-SW to VNF", "Restart OBA"]
        _mProg = bv.MixedProgBarInfo("Wan Port Add", _ele)
        
        logger.info("Start WAN-Port Add...")
        ### 1. check condition
        _item = _ele[_idx]
        _mProg.inc(10)
        
        ## Orch-F API
        if _has_utm :
            bv.update_progBar(_mProg, "Check Orch-F API")
            _ofIP, _ofPort = _ob_info.orchf_site()
            if _has_utm :
                self._up = bv.UpdateProg(_mProg, 3, 1)
                self._up.start()
                _ret, _err = _chk_wan_mod_api(_ofIP, _ofPort, _ob_info.ob_id())
                self._up.stop()
                if not _ret :
                    logger.error("Fail to Add Wan-Port, Orch-F API Check Error, err=%s"%str(_err))
                    bv.alert("Orch-F API Check Error, err=%s"%str(_err))
                    return self._RET_ERR
            _mProg.set_perc(30)
        bv.update_progBar(_mProg, "Check Wan-Port Limit")
        
        ## port > 3 and host nic
        _wan_port_num = len(_ob_info.wan_list())
        if _wan_port_num >= oc.VAL_WAN_MAX_NUM :
            logger.error("Fail to Add Wan-Port, Max Wan-Port")
            bv.alert("Wan-Port(Max=%s) Exceed"%str(oc.VAL_WAN_MAX_NUM))
            return self._RET_ERR
        _mProg.set_perc(50)
        bv.update_progBar(_mProg, "Check Physical-Port")
        
        ## phy nic
        _usable_nics, _selected_nics = _bl.get_usable_nics(_ob_info)
        if len(_usable_nics) < 1 :
            logger.error("Fail to Add Wan-Port, No Physical Interface")
            bv.alert("No Available Interface")
            return self._RET_ERR
        _mProg.set_perc(90)
        bv.update_progBar(_mProg, "Check VNF & Wan Mode")
        
        logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 2. Input Wan-Info
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        _PREV_WAN_LEN = len(_ob_info.wan_list())
        _MIN_IDX = _PREV_WAN_LEN
        _widx = 0
        _net_list = (_data[_TAG_WAN_LIST] if _data.has_key(_TAG_WAN_LIST) else [])
        _br_list = oc.VAL_DEF_VI_WAN_BR_LIST
        while True:
            ## select nic
            _ret, _nic, _mac, _conn, _limit = _bl.get_host_nic("WAN-%s Interface Select"%str(_widx), _selected_nics, _nic_model=_ob_info.hw_nic_model())
            if _ret == self._RET_OK and _conn == False :
                _cret = bv.confirm_ok("Interface is not Connected.\nConitnue?")
                if _cret != bv.RET_OK :
                    _ret = self._RET_BACK
            
            if _ret == self._RET_BACK :
                if _widx <= 0 :
                    return self._RET_BACK
                else:
                    _widx = max(0, _widx-1)
                
                try:
                    _selected_nics.pop()
                except IndexError:
                    pass
                continue
            elif _ret == self._RET_ERR :
                return self._RET_ERR
            
            ## config network
            if len(_net_list) > _widx :
                # overwrite ip
                _prvnet = _net_list[_widx]
                _oaddr = ob_info.create_addr("WAN_%s"%(str(_widx+_MIN_IDX)), oc.VAL_NET_TYPE_WAN, _nic, _prvnet.is_dhcp(), 
                                           _ip=_prvnet.ip(), _mask=_prvnet.mask(), _gw=_prvnet.gw(), 
                                           _dev=_br_list[_widx+_MIN_IDX], _mac=_mac, _vlan=_prvnet.vlan())
            else:
                _oaddr = ob_info.create_addr("WAN_%s"%(str(_widx+_MIN_IDX)), oc.VAL_NET_TYPE_WAN, _nic, None, 
                                           _dev=_br_list[_widx+_MIN_IDX], _mac=_mac)
            
            _ret = _bl.set_extern_ip("WAN IP Config", _oaddr)
            if _ret == self._RET_OK :
                if len(_net_list) >= (_widx + 1) :
                    _net_list[_widx] = _oaddr
                else:
                    _net_list.append(_oaddr)
                _selected_nics.append(_nic)
                
                if (_widx+1) >= (oc.VAL_WAN_MAX_NUM - _PREV_WAN_LEN) :
                    break
                if _limit < 1 :
                    break
                
                _ret = bv.confirm_ok("Add Extra-WAN Interface?")
                if _ret == bv.RET_ERR :
                    return self._RET_ERR
                elif _ret == bv.RET_NO :
                    break
                
                _widx += 1
                continue
            elif _ret == self._RET_BACK :
                continue
            else :
                return self._RET_ERR
        _data[_TAG_WAN_LIST] = _net_list
        
        logger.info(" - SUCC: %s For WAN-Port ADD, info=%s"%( _item, str(_net_list) ))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 3. Pause oba
        ## pause for recving mon-info
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        self._up = bv.UpdateProg(_mProg, 2, 1)
        self._up.start()
        _data[_TAG_RECOVERY_WAN].append(_RCVR_OBA_RESUME)
        _url_pause = _ob_info.url_oba("127.0.0.1") + _URL_SCHD_PAUSE
        _ret, _ecode, _res = rest_api.sendReq(oc.HEADER, _url_pause, "POST", _body={'timeout':_TO_WAN_SW_PAUSE}, cCrt=oc.KEY_CLI_CRT, cKey=oc.KEY_CLI_KEY)
        if not _ret or type(_res) != dict or not _res.has_key('result') or _res['result'] != "OK" :
            self._up.stop()
            logger.error("Fail to Add Wan-Port, OBA Wan-Mon Pause Error, res=%s"%str(_res))
            bv.alert("OBA Wan-Mon Pause Error")
            return self._RET_ERR
        
        # chk WAN-Status
        self._up.set_msg("Check Wan-Status...")
        _to = 120
        while True :
            sleep(2)
            _to -= 2
            if _to < 0 :
                logger.warning(" - Fail to Check OBA Wan Working, TimeOut, to=%s"%str(_to))
                break
            
            wanState = WANStateManager().get_state()
            if wanState['status'] in onebox_manager.STAT_WAN_PREVENT_DUPL :
                logger.warning("   - Wait for Add Wan-Port, OBA Wan Working, status=%s"%str(wanState))
                continue
            else:
                logger.info(" - - SUCC: Check OBA Wan IDLE")
                break
        self._up.stop()
        
        logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 4. wan-sw to host(update vim ip)
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        ## check modified range(if has vnf)
        _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
        _wan_mode = _ol.getWanMode(_ob_info)
        if _ob_info.is_in_band() and _wan_mode in ( None, oc.VAL_WAN_MD_VNF ) :
            if _wan_mode == oc.VAL_WAN_MD_VNF : 
                _data[_TAG_RECOVERY_WAN].append(_RCVR_SW_VNF)
            _prv_mgmt_ip = _ol.get_mgmt_ip(_has_utm, _wan_mode, _uip)
            _ret = _bl.wanSw_obaRun(_ob_info, oc.VAL_WAN_MD_HOST, True, _uip, _mProg)
            if not _ret :
                logger.error("Fail to Add Wan-Port, WAN-Switch-Host Error")
                bv.alert("Fail to Add Wan-Port, WAN-Switch-Host Error")
                return self._RET_ERR
            
            self._up = bv.UpdateProg(_mProg, 2, 1)
            self._up.start()
            _ol.update_vim_ip( _ob_info, _prv_mgmt_ip, 10, False)
            self._up.stop()
            logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
            _mProg.set_perc(100)
        else:
            logger.info(" - SKIP: %s For WAN-Port ADD"%_item)
            _mProg.set_perc(bv.G_STATUS_SKIP)
        bv.update_progBar(_mProg)
        
        
        ### 5. apply ob-info
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        _widx = 0
        for _wnet in _net_list :
            if _ob_info.is_in_band() :
                _maddr = ob_info.create_addr("mgmt_%s"%str(_widx+_MIN_IDX), oc.VAL_NET_TYPE_MGMT, _wnet.nic(), _wnet.is_dhcp(), 
                                           _ip=_wnet.ip(), _mask=_wnet.mask(), _gw=_wnet.gw(), 
                                           _dev=oc.VAL_DEF_OS_BR_LIST[_widx+_MIN_IDX], _mac=_wnet.mac(), _vlan=_wnet.vlan())
                _ob_info.add_mgmt(_maddr)
                _ob_info.add_wan(_wnet)
            else:
                _ob_info.add_wan(_wnet)
            _widx += 1
        logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 6. host modify(add port/net)
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        if _ob_info.is_in_band() :
            _wan_mode = _ol.getWanMode(_ob_info)
            _prv_mgmt_ip = _ol.get_mgmt_ip(_has_utm, _wan_mode, _uip)
            
            _mgmt_list = _ob_info.mgmt_list()
            _data[_TAG_RECOVERY_WAN].append(_RCVR_HOST_NET)
            _ret, _err = _ol.config_mgmt_net(_mgmt_list, _mProg, bv)
            if not _ret :
                logger.error("Fail to  Add Wan-Port, Mgmt-Net Config Error, err=%s"%( _err ))
                bv.alert("Fail to  Add Wan-Port, Mgmt-Net Config Error\n - err=%s"%( _err ))
                return self._RET_ERR
            
            _wan_mode = _ol.getWanMode(_ob_info)
            _nxt_mgmt_ip = _ol.get_mgmt_ip(_has_utm, _wan_mode, _uip)
            if _nxt_mgmt_ip != None and str(_nxt_mgmt_ip).strip() != "" and _prv_mgmt_ip != _nxt_mgmt_ip :
                sleep(10)
                _vret, _err = _bl.update_vim(_mProg, _nxt_mgmt_ip, _ob_info.vim_auth_user(), _ob_info.vim_auth_pass(), _ob_info.ovs_dpdk())
                if not _vret : 
                    logger.warning(" - Fail to Update VIM-IP, ip=%s->%s, err=%s"%( str(_prv_mgmt_ip), str(_nxt_mgmt_ip), str(_err) ))
            
        else:
            _data[_TAG_RECOVERY_WAN].append(_RCVR_VWAN_PORT_RESTORE)
            for _nwan in _net_list :
                if not _ol.get_vim().add_br_port(_nwan.bridge(), _nwan.nic(), _ob_info.ovs_dpdk()) :
                    logger.error("Fail to  Add Wan-Port, VIM-WAN Port Add Error, wan=%s"%( _nwan ))
                    bv.alert("Fail to  Add Wan-Port, VIM-WAN Port Add Error\n - wan=%s"%( _nwan ))
                    return self._RET_ERR
        
        logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 7. Save OBA-Config
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        today = datetime.datetime.now()
        _bid = today.strftime('%y%m%d%H%M')
        _bname = oc.DIR_TMP + oc.VAL_OBA_NAME + ".conf.bak.%s"%str(_bid)
        _data[_TAG_RECOVERY_WAN].append(_RCVR_OBA_CONF)
        _data[_RCVR_OBA_CONF] = _bname
        if not _ol.copyFile(oc.FILE_OBA_CONF, _bname) :
            if bv.confirm_ok("Fail to Backup OBA-Config.\nContinue?") != bv.RET_OK :
                logger.error("Fail to Add Wan-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                bv.alert("Fail to Add Wan-Port, OBA-Config Backup Error\n - src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Add Wan-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
        try:
            _ob_info.saveToCfg()
        except Exception, e:
            logger.error("Fail to Add Wan-Port, OBA-Config Save Error, ob_info=%s"%str(_ob_info))
            logger.exception(e)
            bv.alert("Fail to Add Wan-Port, OBA-Config Save Error")
            return self._RET_ERR
        
        logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 8-10
        if _has_utm :
            ### 8. Refresh WAN-IP
            _idx += 1
            _item = _ele[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            
            self._up = bv.UpdateProg(_mProg, 2, 1)
            self._up.start()
            _net_info = ob_info.OB_NET()
            _net_info.init(_ob_info.is_in_band(), _ob_info.utm_local_ip(),
                           _has_utm, _ol.getWanMode(_ob_info), 
                           _ob_info.mgmt_list(), _ob_info.wan_list(), _ob_info.extra_wan_list())
            _ret, _net_info = _ol.refresh_wan(_net_info, _ob_info, "BTA-WanPortAdd")
            self._up.stop()
            
            
            _ob_id = _ob_info.ob_id()
            _mode = "ADD"
            _wan_list = []
            
            _chk_idx = min(max(0, _MIN_IDX), len(_net_info.wan_list))
            for _wan in _net_info.wan_list[_chk_idx:] :
                if _wan.is_dhcp and (_wan.ip in (None, "") or _wan.gw in (None, "") ) :
                    _net_info.set_fake_wan(_ob_info.lan_net_list())
                    if bv.confirm_ok("No Wan IP Info[br=%s].\nContinue with Fake-IP[%s]?"%( str(_wan.dev), str(_wan.ip) )) == bv.RET_OK :
                        logger.warning("Fail to Add Wan-Port, No Wan IP, wan=%s"%str(_wan))
                        break
                    else:
                        logger.error("Fail to Add Wan-Port, No Wan IP, wan=%s"%str(_wan))
                        bv.alert("Fail to Add Wan-Port, No Wan IP")
                        return self._RET_ERR
            
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            
            _add_idx = 0
            for _wan in _net_info.wan_list :
                _wdhcp = _wan.is_dhcp
                _wmac = _wan.mac
                _wmode = 'host'
                if not _ob_info.is_in_band() :
                    _wmode = oc.VAL_WAN_MD_OUTBAND
                _wnic = _wan.nic
                
                _wip = _wan.ip
                _wgw = _wan.gw
                _wpfx = _wan.prefixlen
                
                if _add_idx >= _chk_idx and (_wip == None or _wpfx == None or _wgw == None) :
                    logger.error("Fail to Add Wan-Port, No Wan IP, wan=%s"%str(_wan))
                    bv.alert("Fail to Add Wan-Port, No Wan IP, br=%s"%str(_wan.dev))
                    return self._RET_ERR
                
                _wan_list.append({'mac':_wmac, 'mode':_wmode, 'nic':_wnic,
                                  'public_cidr_prefix': _wpfx, 'public_gw_ip': _wgw,
                                  'public_ip': _wip, 'public_ip_dhcp': _wdhcp})
                _add_idx += 1
            
            logger.info(" - SUCC: %s For WAN-Port ADD, info=%s"%( _item, str(_net_info) ))
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            
            
            ### 9. VNF modify(add port/net)
            _idx += 1
            _item = _ele[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(1)
            bv.update_progBar(_mProg)
            
            _uid = _ob_info.utm_id()
            _upass = _ob_info.utm_pass()
            ## login
            logger.debug("   - Login VNF...")
            self._up = bv.UpdateProg(_mProg, 3, 1, "Login VNF...")
            self._up.start()
            if not _ol.login_utm(_uip, _uid, _upass) :
                logger.warning(" - Fail to Add Wan-Port, UTM Login Error")
            
            ## vnf backup
            logger.debug("   - Backup VNF...")
            self._up.set_msg("Backup VNF...")
            _ret, _err = _ol.backup_utm(oc.FILE_BAK_VNF_UTM, _uip)
            _data[_RCVR_VNF_RESTORE] = oc.FILE_BAK_VNF_UTM
            if not _ret :
                self._up.stop()
                logger.error("Fail to Add Wan-Port, UTM Backup Error, err=%s"%str(_err))
                bv.alert("UTM Backup Error\n - err=%s"%str(_err))
                return self._RET_ERR
            self._up.stop()
            
            ## route delete
            logger.debug("   - Check & Del VNF Route...")
            self._up.set_msg("Check & Delete VNF Route...")
            self._up.start()
            
            _wan_num = len(_wan_list)
            _not_used_br = oc.VAL_DEF_VI_WAN_BR_LIST[_wan_num:]
            _not_used_utm_nic = []
            for _nu_br in _not_used_br :
                _unic = _ol.to_utm_nic(_nu_br)
                if _unic != None and not _unic in _not_used_utm_nic :
                    _not_used_utm_nic.append(_unic)
            
            if len(_not_used_utm_nic) > 0 :
                _ret, _rInfo, _err = _ol.get_utm_all_route(_uip, _not_used_utm_nic, None, _uid)
                if not _ret :
                    logger.warning(" - Fail to Add Wan-Port, UnUsed UTM Route Get Error, err=%s"%str(_err))
                else:
                    if len(_rInfo['def']) > 0 or len(_rInfo['usr']) > 0 :
                        _del_route = _rInfo['def'] + _rInfo['usr']
                        _ret, _del_txt = _bl.to_txt_utm_delinfo({'Route': _del_route})
                        if not _ret :
                            import json
                            _del_txt = json.dumps(_del_route, indent=2)
                        self._up.stop()
                        if bv.confirm_ok("Delete UnUsed VNF Routes, Continue?\n\n%s"%_del_txt) == bv.RET_OK :
                            logger.debug(" - - Deleted Route:\n%s"%str(_del_txt))
                            self._up.start()
                            _data[_TAG_RECOVERY_WAN].append(_RCVR_VNF_RESTORE)
                            _ret, _err = _ol.del_utm_all_route(_uip, _del_route, _uid)
                            if not _ret :
                                logger.warning(" - Fail to Add Wan-Port, UnUsed UTM Route Delete Error, err=%s"%str(_err))
                            sleep(1)
            self._up.stop()
            
            ## Request
            _ret = _reqWanPortMod(_ol, _ofIP, _ofPort, _ob_id, _mode, _ob_info, _mProg, _net_info)
            if not _ret :
                return self._RET_ERR
            
            ## Progress
            _ret = _progWanPortMod(_ofIP, _ofPort, _ob_id, _mode, _mProg)
            if not _ret :
                return self._RET_ERR
            
            _data[_TAG_RECOVERY_WAN].append(_RCVR_VWAN_RESTORE)
            logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            
            
            ### 10. setting vnf-wan
            _idx += 1
            _item = _ele[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(1)
            bv.update_progBar(_mProg)
            
            ## login
            logger.debug("   - Login VNF...")
            self._up = bv.UpdateProg(_mProg, 3, 1, "Login VNF...")
            self._up.start()
            if not _ol.login_utm(_uip, _uid, _upass) :
                logger.warning(" - Fail to Add Wan-Port, UTM Login Error")
            
            ## add ip
            _data[_TAG_RECOVERY_WAN].append(_RCVR_VNF_RESTORE)
            self._up.set_msg("Setting VNF IP...")
            for _wan in _net_list :
                if _wan.is_dhcp() :
                    _ret, _err = _ol.add_utm_ip(_uip, True, _wan.bridge(), _utm_mac=_wan.mac(), _utm_id=_uid)
                else:
                    _ret, _err = _ol.add_utm_ip(_uip, False, _wan.bridge(), _utm_nic_ip=_wan.ip(), _utm_mask=_wan.mask(), _utm_id=_uid)

                if not _ret :
                    self._up.stop()
                    if bv.confirm_ok("Fail to Set VNF-IP.\nContinue?\n\n - wan=%s"%str(_wan)) == bv.RET_OK :
                        self._up.start()
                        _data[_TAG_SKIP_WAN].append(_SKWN_VNF_IP_SETTING)
                        logger.warning(" - Fail to Add Wan-Port, VNF-IP Setting Error, Continue..., err=%s, info=%s"%( str(_err), str(_wan) ))
                    else:
                        logger.error("Fail to Add Wan-Port, VNF-IP Setting Error, err=%s, info=%s"%( str(_err), str(_wan) ))
                        bv.alert("VNF-IP Setting Error, err=%s\n - info=%s"%( str(_err), str(_wan) ))
                        return self._RET_ERR
                    
            logger.debug(" - SUCC: Add VNF-IP, info=%s"%str(_net_list))
            
            ## add def route
            self._up.set_msg("Setting VNF Default Route...")
            self._up.stop()
            self._up.start()
            for _wan in _net_list :
                _metric = _ol.get_utm_metric(_wan.bridge())
                if _wan.is_dhcp() :
                    _ret, _err = _ol.add_utm_route(_uip, True, _wan.bridge(), _utm_metric=_metric, _utm_id=_uid)
                else:
                    _ret, _err = _ol.add_utm_route(_uip, False, _wan.bridge(), _wan.gw(), _utm_metric=_metric, _utm_id=_uid)
                
                if not _ret :
                    self._up.stop()
                    if bv.confirm_ok("Fail to Set VNF-Route.\nContinue?\n\n - wan=%s"%str(_wan)) == bv.RET_OK :
                        self._up.start()
                        _data[_TAG_SKIP_WAN].append(_SKWN_VNF_ROUTE_SETTING)
                        logger.warning(" - Fail to Add Wan-Port, VNF-Route Setting Error, Continue..., err=%s, info=%s"%( str(_err), str(_wan) ))
                    else:
                        logger.error("Fail to Add Wan-Port, VNF-Route Setting Error, err=%s, info=%s"%( str(_err), str(_wan) ))
                        bv.alert("VNF-Route Setting Error, err=%s\n - info=%s"%( str(_err), str(_wan) ))
                        return self._RET_ERR
                    
            self._up.stop()
            logger.debug(" - SUCC: Add VNF-Route, info=%s"%str(_net_list))
            
            logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
            _mProg.set_perc(100)
        else:
            _idx += 1
            _mProg.set_index(_idx)
            _mProg.set_perc(bv.G_STATUS_SKIP)
            _item = _ele[_idx]
            logger.info(" - SKIP: %s For WAN-Port ADD"%_item)
            _idx += 1
            _mProg.set_index(_idx)
            _mProg.set_perc(bv.G_STATUS_SKIP)
            _item = _ele[_idx]
            logger.info(" - SKIP: %s For WAN-Port ADD"%_item)
            _idx += 1
            _mProg.set_index(_idx)
            _mProg.set_perc(bv.G_STATUS_SKIP)
            _item = _ele[_idx]
            logger.info(" - SKIP: %s For WAN-Port ADD"%_item)
        bv.update_progBar(_mProg)
        
        
        ### 11. wan-sw to vnf
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        if _has_utm and _ob_info.is_in_band() and _RCVR_SW_VNF in _data[_TAG_RECOVERY_WAN] :
            _ret = _bl.wanSw_obaRun(_ob_info, oc.VAL_WAN_MD_VNF, True, _uip, _mProg)
            if not _ret :
                if bv.confirm_ok("Fail to WAN-Switch to VNF.\nContinue?") == bv.RET_OK :
                    _data[_TAG_SKIP_WAN].append(_SKWN_SW_VNF)
                    logger.warning(" - Fail to Add Wan-Port, WAN-Switch-VNF Error, Continue...")
                else:
                    logger.error("Fail to Add Wan-Port, WAN-Switch-VNF Error")
                    bv.alert("Fail to Add Wan-Port, WAN-Switch-VNF Error")
                    return self._RET_ERR
            _data[_TAG_RECOVERY_WAN].remove(_RCVR_SW_VNF)
            
            logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
            _mProg.set_perc(100)
        else:
            logger.info(" - SKIP: %s For WAN-Port ADD"%_item)
            _mProg.set_perc(bv.G_STATUS_SKIP)
        bv.update_progBar(_mProg)
        
        
        ### 12. restart oba
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, _mProg)
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, _mProg)
        if not _ret :
            if bv.confirm_ok("Fail to Start Onebox-Agent.\nContinue?") == bv.RET_OK :
                _data[_TAG_SKIP_WAN].append(_SKWN_OBA_START)
                logger.warning(" - Fail to Start OBA, Continue...")
            else:
                _data[_TAG_RECOVERY_WAN].append(_RCVR_OBA_START)
                logger.error("Fail to Add Wan-Port, OBA Start Error, err=%s"%str(_err))
                bv.alert("Fail to Start Onebox-Agent")
                return self._RET_ERR
        
        logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        return self._RET_OK
    
    
    def _select(self, _data):
        _data[_TAG_RECOVERY_WAN] = []
        _data[_TAG_SKIP_WAN] = []
        try:
            _ret = self._do(_data)
        except Exception, e:
            _ret = self._RET_ERR
            if self._up != None : self._up.stop()
            logger.error("Fail to Add Wan-Port, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Add Wan-Port, exc=%s"%str(e))
        
        if _ret == self._RET_ERR :
            if len(_data[_TAG_RECOVERY_WAN]) > 0 and bv.confirm_ok("Rollback WAN?") == bv.RET_OK :
                _rb_list = _recovery_wan_port("ADD", _data)
                _rb_result_txt = _rb_txt(_data[_TAG_RECOVERY_WAN], _rb_list)
                logger.debug(" - - Recovery[WAN-ADD] Result:\n%s"%str(_rb_result_txt))
                bv.confirm_ok(_rb_result_txt)
        elif _ret == self._RET_OK :
            _show_fail_skip_item(_data[_TAG_SKIP_WAN])
        
        if _data.has_key(_RCVR_OBA_CONF) :
            _ol = _data[oc.OTAG_LIB_OB]
            _ol.delFile(_data[_RCVR_OBA_CONF])
        if _data.has_key(_RCVR_VNF_RESTORE) :
            _ol = _data[oc.OTAG_LIB_OB]
            _ol.delFile(_data[_RCVR_VNF_RESTORE])
        return _ret
    
    def _next(self, _ret, _data):
        return self._RET_OK


class _OBNetWANPortDel(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObWanPortDel", _prevMenu)
        
        self._up = None
    
    def _do(self, _data):
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _uip = _ob_info.utm_local_ip()
        _uid = _ob_info.utm_id()
        _upass = _ob_info.utm_pass()
        _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
        _wan_mode = _ol.getWanMode(_ob_info)
        _prv_mgmt_ip = _ol.get_mgmt_ip(_has_utm, _wan_mode, _uip)
        
        _TAG_ROUTE = "___tag_route"
        
        _idx = -1
        _ele = ["Check Orch-F API", "Select WAN", "Check VNF", "Pause WAN-MON & Stop OBA", 
                "Apply & Save WAN-INFO", "Apply Host & VIM Network", "Start OBA", "WAN-SW to Host", 
                "Delete VNF WAN", "WAN-SW to VNF", "Resume WAN-MON"]
        _mProg = bv.MixedProgBarInfo("Wan Port Delete", _ele)
        _mod_utm_ip = False
        
        logger.info("Start WAN-Port DEL...")
        
        ### 1. Orch-F API 
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        _ofIP, _ofPort = _ob_info.orchf_site()
        if _has_utm :
            self._up = bv.UpdateProg(_mProg, 3, 1)
            self._up.start()
            _ret, _err = _chk_wan_mod_api(_ofIP, _ofPort, _ob_info.ob_id())
            self._up.stop()
            if not _ret :
                logger.error("Fail to Del Wan-Port, Orch-F API Check Error, err=%s"%str(_err))
                bv.alert("Orch-F API Check Error, err=%s"%str(_err))
                return self._RET_ERR
            logger.info(" - SUCC: %s For WAN-Port DEL"%( _item ))
            _mProg.set_perc(100)
        else:
            logger.info(" - SKIP: %s For WAN-Port DEL"%( _item ))
            _mProg.set_perc(bv.G_STATUS_SKIP)

        bv.update_progBar(_mProg)
        
        ### 2. select wan
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        _prev_wlist = _ob_info.wan_list()
        if len(_prev_wlist) < 2 :
            logger.error("Fail to Del Wan-Port, Not Availalbe WAN, WAN CNT=1")
            bv.alert("Fail to Del Wan-Port, Not Availalbe WAN, WAN CNT=1")
            return self._RET_ERR
        
        _del_nic_list = []
        while True:
            _choice = []
            try:
                for _wnet in _prev_wlist :
                    _wnic = _wnet.nic()
                    _wtxt = "%-7s, %s"%(str(_wnet.bridge()), (oc.VAL_IP_TYPE_DHCP if _wnet.is_dhcp() else oc.VAL_IP_TYPE_STAT) )
                    if not _wnet.is_dhcp() :
                        _to_ip = IPv4Network("%s/%s"%( str(_wnet.ip()), str(_wnet.mask()) ))
                        _wtxt += ( ", %s"%( str(_to_ip) ) )
                    _choice.append(( _wnic, _wtxt, False ))
            except Exception, e:
                logger.error("Fail to Del Wan-Port, Invalid WAN Info, wan=%s"%str(_wnet))
                logger.exception(e)
                bv.alert("Fail to Del Wan-Port, Invalid WAN Info, wan=%s"%str(_wnet))
                return self._RET_ERR
            
            _ret = bv.get_multi_choice_menu("Select WANs to Remove..", _choice)
            if _ret == bv.RET_NO :
                return self._RET_BACK
            elif _ret == bv.RET_ERR :
                return self._RET_ERR
            
            if len(_ret) >= len(_choice) :
                bv.alert("Fail to Del Wan-Port, Need At Least One")
                continue
            if len(_ret) < 1 :
                bv.alert("Fail to Del Wan-Port, Select At Least One")
                continue
            
            _del_nic_list = _ret
            break
        
        logger.info(" - SUCC: %s For WAN-Port DEL, nic=%s"%( _item, str(_del_nic_list)) )
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        ### 3. check modified range
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        _utm_is_on = False
        if _has_utm :
            ## if has vnf :
            if _ol.get_utm_status(_uip) :
                _utm_is_on = True
                self._up = bv.UpdateProg(_mProg, 3, 1, "Login VNF...")
                self._up.start()
                if not _ol.login_utm(_uip, _uid, _upass) :
                    self._up.stop()
                    logger.error("Fail to Del Wan-Port, UTM Login Error")
                    bv.alert("UTM Login Error")
                    return self._RET_ERR
                
                ## bridge on -> disable
                self._up.set_msg("Check VNF Bridge...")
                
                _first_mod_wnic_idx = 0
                _tmp_idx = 0
                for _wan in _ob_info.wan_list() :
                    _prev_nic = _wan.nic()
                    if _prev_nic in _del_nic_list :
                        _first_mod_wnic_idx = _tmp_idx
                        break
                    _tmp_idx += 1
                
                logger.debug("----------- ob_info wan list: %s"%str(_ob_info.wan_list()))
                logger.debug("----------- selected nic: %s"%str(_del_nic_list))
                logger.debug("----------- br chk idx: %s"%str(_first_mod_wnic_idx))
                
                _utm_mod_wnic = []
                for _chk_wan in _ob_info.wan_list()[_first_mod_wnic_idx:] :
                    _chk_wbr = _chk_wan.bridge()
                    _uwnic = _ol.to_utm_nic(_chk_wbr)
                    if _uwnic != None:
                        if not _uwnic in _utm_mod_wnic :
                            _utm_mod_wnic.append(_uwnic)
                    else:
                        logger.warning(" - - Fail to Del Wan-Port, UTM Nic Convert Error, vim-br=%s"%str(_chk_wbr))
                
                logger.debug("----------- utm br chk nic: %s"%str(_utm_mod_wnic))
                _ret, _br_ifs, _err = _ol.get_utm_bridge(_uip, _utm_mod_wnic, _uid)
                if not _ret :
                    self._up.stop()
                    logger.error("Fail to Del Wan-Port, UTM Bridge Check Error, nic=%s, err=%s"%( str(_utm_mod_wnic), str(_err) ))
                    bv.alert("UTM Bridge Check Error\n - err=%s"%str(_err))
                    return self._RET_ERR
                if len(_br_ifs) > 0 :
                    self._up.stop()
                    logger.error("Fail to Del Wan-Port, UTM Bridge On, if=%s"%str(_br_ifs))
                    bv.alert("UTM Bridge On, if=%s"%str(_br_ifs))
                    return self._RET_ERR
                
                ## route exist -> route delete
                self._up.set_msg("Check VNF Route...")
                
                _delete_wnet = _ob_info.wan_list()[(len(_ob_info.wan_list()) - len(_del_nic_list)):]
                _utm_del_wnic = _ol.get_utm_wan_list()[(len(_ob_info.wan_list()) - len(_del_nic_list)):]
                _utm_static_gw = {}
                for _dwnet in _delete_wnet :
                    _dwbr = _dwnet.bridge()
                    _uwnic = _ol.to_utm_nic(_dwbr)
                    if _uwnic != None:
                        if not _dwnet.is_dhcp() :
                            _utm_static_gw[_uwnic] = {'gw': _dwnet.gw()}
                    else:
                        logger.warning(" - - Fail to Del Wan-Port, UTM Nic Convert Error, vim-br=%s"%str(_dwbr))

                
                logger.debug("----------- vim del nic: %s"%str(_delete_wnet))
                logger.debug("----------- utm del route nic: %s"%str(_utm_del_wnic))
                logger.debug("----------- utm static gw: %s"%str(_utm_static_gw))
                _ret, _rInfo, _err = _ol.get_utm_all_route(_uip, _utm_del_wnic, _utm_static_gw, _uid)
                if not _ret :
                    self._up.stop()
                    logger.error("Fail to Del Wan-Port, UTM Route Get Error, err=%s"%str(_err))
                    bv.alert("UTM Route Get Error\n - err=%s"%str(_err))
                    return self._RET_ERR
                self._up.stop()
                
                logger.debug("----------- utm route info: %s"%str(_rInfo))
                if len(_rInfo['def']) > 0 or len(_rInfo['usr']) > 0 :
                    _data[_TAG_ROUTE] = _rInfo['def'] + _rInfo['usr']
                    _ret, _del_txt = _bl.to_txt_utm_delinfo({'Route': _data[_TAG_ROUTE]})
                    if not _ret :
                        import json
                        _del_txt = json.dumps(_data[_TAG_ROUTE], indent=2)
                    if bv.confirm_ok("Delete VNF Routes, Continue?\n\n - %s"%_del_txt) != bv.RET_OK :
                        return self._RET_BACK
                    logger.debug(" - - Deleted Route Info:\n%s"%str(_del_txt))
                
                logger.info(" - SUCC: %s For WAN-Port Del, route=%s"%( _item, str(_rInfo) ))
                _mProg.set_perc(100)
            else:
                logger.error("Fail to Del Wan-Port, UTM Connection Error")
                bv.alert("UTM Connection Error")
                return self._RET_ERR
        else:
            logger.info(" - SKIP: %s For WAN-Port Del"%_item)
            _mProg.set_perc(bv.G_STATUS_SKIP)
        bv.update_progBar(_mProg)
        
        
        ### 4. pause WAN and stop OBA
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        # pause WAN-MON
        if _ob_info.is_in_band() :
            self._up = bv.UpdateProg(_mProg, 3, 1, "Request Pause WAN-MON...")
            self._up.start()
            _paused = False
            for _ii in range(10) :
                sleep(2)
                _url_pause = _ob_info.url_oba("127.0.0.1") + _URL_SCHD_PAUSE
                _ret, _ecode, _res = rest_api.sendReq(oc.HEADER, _url_pause, "POST", _body={'timeout':_TO_WAN_SW_PAUSE}, cCrt=oc.KEY_CLI_CRT, cKey=oc.KEY_CLI_KEY)
                if not _ret or type(_res) != dict or not _res.has_key('result') or _res['result'] != "OK" :
                    logger.warning("   - Wait for Del Wan-Port, OBA Wan-Mon Pause Error, res=%s"%str(_res))
                    continue
                else:
                    _data[_TAG_RECOVERY_WAN].append(_RCVR_OBA_RESUME)
                    _paused = True
                    break
            
            self._up.stop()
            if not _paused :
                logger.error("Fail to Del Wan-Port, OBA Wan-Mon Pause Error")
                bv.alert("Fail to Del Wan-Port, OBA Wan-Mon Pause Error")
                return self._RET_ERR
        
        from onebox_agent.util.onebox_manager import OBAStatusManager
        OBAStatusManager().keep_wsw_on(True)
        OBAStatusManager().keep_ntf_on(True)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, _mProg)
        if not _ret :
            if bv.confirm_ok("Fail to Stop Onebox-Agent.\nContinue?") != bv.RET_OK :
                _data[_TAG_RECOVERY_WAN].append(_RCVR_OBA_START)
                logger.error("Fail to Del Wan-Port, OBA Stop Error, err=%s"%str(_err))
                bv.alert("Fail to Stop Onebox-Agent")
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Stop OBA, Continue...")
        
        logger.info(" - SUCC: %s For WAN-Port DEL"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 5. apply wan-info & Save OBA-Config
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        # apply wan-info
        _tmp_wlist = []
        import copy
        _tmp_prev_list = copy.deepcopy(_prev_wlist)
        for _wnet in _tmp_prev_list :
            if not _wnet.nic() in _del_nic_list :
                _tmp_wlist.append(_wnet)
        _w_idx = 0
        _new_wlist = []
        for _nwan in _tmp_wlist :
            if _nwan.bridge() != oc.VAL_DEF_VI_WAN_BR_LIST[_w_idx] :
                _mod_utm_ip = True
            _nwan.set_dev(oc.VAL_DEF_VI_WAN_BR_LIST[_w_idx])
            _new_wlist.append(_nwan)
            _w_idx += 1
        
        _ob_info.set_wan_list(_new_wlist)
        
        logger.debug("----------- prv net info: %s"%str(_prev_wlist))
        logger.debug("   - Apply Wan-Info, sel_wan=%s, ob_wan=%s, ip-chg=%s"%( str(_new_wlist), str(_ob_info.m_wan_list), str(_mod_utm_ip) ))
        _mProg.set_perc(50)
        bv.update_progBar(_mProg)
        
        # save oba-config
        today = datetime.datetime.now()
        _bid = today.strftime('%y%m%d%H%M')
        _bname = oc.DIR_TMP + oc.VAL_OBA_NAME + ".conf.bak.%s"%str(_bid)
        _data[_TAG_RECOVERY_WAN].append(_RCVR_OBA_CONF)
        _data[_RCVR_OBA_CONF] = _bname
        if not _ol.copyFile(oc.FILE_OBA_CONF, _bname) :
            if bv.confirm_ok("Fail to Backup OBA-Config.\nContinue?") != bv.RET_OK :
                logger.error("Fail to Del Wan-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                bv.alert("Fail to Del Wan-Port, OBA-Config Backup Error\n - src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Del Wan-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
        try:
            _ob_info.saveToCfg()
        except Exception, e:
            logger.error("Fail to Del Wan-Port, OBA-Config Save Error, ob_info=%s"%str(_ob_info))
            logger.exception(e)
            bv.alert("Fail to Del Wan-Port, OBA-Config Save Error")
            return self._RET_ERR
        
        logger.debug("   - Save OBA-Config, bak_file=%s"%str(_bname))
        logger.info(" - SUCC: %s For WAN-Port DEL"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 6. apply host & vim network(del port/net)
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        # reset VIM-net
        self._up = bv.UpdateProg(_mProg, 2, 1, "Reset VIM WAN-Port...")
        self._up.start()
        _data[_TAG_RECOVERY_WAN].append(_RCVR_VWAN_PORT_RESTORE)
        _ret, _err = _bl.reset_vim_br(oc.VAL_DEF_VI_WAN_BR_LIST)
        if not _ret :
            self._up.stop()
            logger.error("Fail to Del Wan-Port, VIM WAN-Port Reset Error, err=%s"%( _err ))
            bv.alert("Fail to Del Wan-Port, VIM WAN-Port Reset Error\n - err=%s"%( _err ))
            return self._RET_ERR
        
        # reset os-net
        if _ob_info.is_in_band() :
            _data[_TAG_RECOVERY_WAN].append(_RCVR_HOST_NET)
            if _has_utm and _wan_mode in (None, oc.VAL_WAN_MD_VNF) : 
                _data[_TAG_RECOVERY_WAN].append(_RCVR_SW_VNF)
            self._up.set_msg("Reset OS Bridge...")
            _ret, _err = _bl.reset_os_br()
            if not _ret :
                self._up.stop()
                logger.error("Fail to Del Wan-Port, Reset OS Bridge Error, err=%s"%( _err ))
                bv.alert("Fail to Del Wan-Port, Reset OS Bridge Error\n - err=%s"%( _err ))
                return self._RET_ERR
            self._up.stop()
            
            # set mgmt-net
            if not _ol.del_host_def_route() :
                logger.warning("   - Fail to Del Wan-Port, OS Default Route Del Error")
            _mgmt_list = _ob_info.mgmt_list()
            _ret, _err = _ol.config_mgmt_net(_mgmt_list, _mProg, bv)
            if not _ret :
                logger.error("Fail to  Del Wan-Port, Mgmt-Net Config Error, err=%s"%( _err ))
                bv.alert("Fail to  Del Wan-Port, Mgmt-Net Config Error\n - err=%s"%( _err ))
                return self._RET_ERR
            
            # vim-ip update
            self._up = bv.UpdateProg(_mProg, 2, 1, "Udpate VIM-IP...")
            self._up.start()
            _new_m_ip = _ol.update_vim_ip( _ob_info, _prv_mgmt_ip, 10, False)
            self._up.stop()
        else:
            self._up.set_msg("Set VIM WAN-Port...")
            for _winfo in _ob_info.wan_list() :
                if not _ol.get_vim().add_br_port(_winfo.bridge(), _winfo.nic(), _ob_info.ovs_dpdk()) :
                    logger.error("Fail to  Del Wan-Port, VIM WAN-Port Setting Error, wan=%s"%( _winfo ))
                    bv.alert("Fail to  Del Wan-Port, VIM WAN-Port Setting Error\n - wan=%s"%( _winfo ))
                    return self._RET_ERR
        
        self._up.stop()
        
        logger.info(" - SUCC: %s For WAN-Port DEL"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 7. start OBA 
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        # start OBA
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, _mProg)
        if not _ret :
            logger.error("Fail to Del Wan-Port, OBA Start Error, err=%s"%str(_err))
            bv.alert("Fail to Start Onebox-Agent")
            return self._RET_ERR
        else:
            if _RCVR_OBA_START in _data[_TAG_RECOVERY_WAN] :
                _data[_TAG_RECOVERY_WAN].remove(_RCVR_OBA_START)
        
        logger.info(" - SUCC: %s For WAN-Port DEL"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 8. wan-sw to host & check wan-sw by oba
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        # sw to host
        _wan_mode = _ol.getWanMode(_ob_info)
        if _ob_info.is_in_band() and _wan_mode in ( None, oc.VAL_WAN_MD_VNF ) :
            # chk WAN-Status
            self._up = bv.UpdateProg(_mProg, 3, 1, "Check Wan-Status...")
            self._up.start()
            _to = 120
            _chk_ok = False
            while True :
                sleep(2)
                _to -= 2
                if _to < 0 :
                    break
                
                wanState = WANStateManager().get_state()
                if wanState['status'] in onebox_manager.STAT_WAN_PREVENT_DUPL :
                    logger.warning("   - Wait for Del Wan-Port, OBA Wan Working, status=%s"%str(wanState))
                    continue
                else:
                    _chk_ok = True
                    break
            self._up.stop()
            if not _chk_ok :
                logger.error("Fail to Del Wan-Port, WAN Status Check Error")
                bv.alert("Fail to Del Wan-Port, WAN Status Check Error")
                return self._RET_ERR
            if _has_utm and not _RCVR_SW_VNF in _data[_TAG_RECOVERY_WAN]:
                _data[_TAG_RECOVERY_WAN].append(_RCVR_SW_VNF)
            _ret = _bl.wanSw_obaRun(_ob_info, oc.VAL_WAN_MD_HOST, True, _uip, _mProg)
            if not _ret :
                logger.error("Fail to Del Wan-Port, WAN-Switch-Host Error")
                bv.alert("Fail to Del Wan-Port, WAN-Switch-Host Error")
                return self._RET_ERR
            
            # vim-ip update
            self._up = bv.UpdateProg(_mProg, 2, 1, "Udpate VIM-IP...")
            self._up.start()
            _new_m_ip = _ol.update_vim_ip( _ob_info, _new_m_ip, 10, False)
            self._up.stop()
            
            logger.info(" - SUCC: %s For WAN-Port DEL"%_item)
            _mProg.set_perc(100)
        else:
            logger.info(" - SKIP: %s For WAN-Port DEL"%_item)
            _mProg.set_perc(bv.G_STATUS_SKIP)
        bv.update_progBar(_mProg)
        
        
        ### 9. VNF modify(del port/net)
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        if _has_utm :
            if _data.has_key(_TAG_ROUTE) :
                logger.debug("   - Login VNF...")
                self._up = bv.UpdateProg(_mProg, 3, 1, "Login VNF...")
                self._up.start()
                if not _ol.login_utm(_uip, _uid, _upass) :
                    self._up.stop()
                    logger.error("Fail to Del Wan-Port, UTM Login Error")
                    bv.alert("UTM Login Error")
                    return self._RET_ERR
                
                ### vnf backup
                logger.debug("   - Backup VNF...")
                self._up.set_msg("Backup VNF...")
                _ret, _err = _ol.backup_utm(oc.FILE_BAK_VNF_UTM, _uip)
                if not _ret :
                    self._up.stop()
                    logger.error("Fail to Del Wan-Port, UTM Backup Error, err=%s"%str(_err))
                    bv.alert("UTM Backup Error\n - err=%s"%str(_err))
                    return self._RET_ERR
                
                ### route delete
                logger.debug("   - Del VNF Route...")
                sleep(3)
                _data[_TAG_RECOVERY_WAN].append(_RCVR_VNF_RESTORE)
                _data[_RCVR_VNF_RESTORE] = oc.FILE_BAK_VNF_UTM
                self._up.set_msg("Check VNF Route Delete...")
                for _rr in _data[_TAG_ROUTE]:
                    while True:
                        _ret, _err = _ol.del_utm_route(_uip, _rr, _uid)
                        if not _ret :
                            self._up.stop()
                            if bv.confirm_ok("Fail to Delete VNF-Route, Retry?\n - route=%s"%str(_rr)) == bv.RET_OK :
                                bv.update_progBar(_mProg)
                                self._up.start()
                                sleep(3)
                                _ol.logout_utm(_uip, _uid)
                                _ol.login_utm(_uip, _uid, _upass)
                                continue
                            else:
                                logger.error("Fail to Del Wan-Port, UTM Route Delete Error, err=%s"%str(_err))
                                bv.alert("UTM Route Delete Error\n - err=%s"%str(_err))
                                return self._RET_ERR
                        else:
                            break
                self._up.stop()
                _ol.logout_utm(_uip, _uid)
                
                sleep(1)
            
            ### wan port delete
            ## refresh wan
            self._up = bv.UpdateProg(_mProg, 2, 5, "Refresh WAN...")
            self._up.start()
            _net_info = ob_info.OB_NET()
            _net_info.init(_ob_info.is_in_band(), _ob_info.utm_local_ip(),
                           _has_utm, _ol.getWanMode(_ob_info), 
                           _ob_info.mgmt_list(), _ob_info.wan_list(), _ob_info.extra_wan_list())
            _ret, _net_info = _ol.refresh_wan(_net_info, _ob_info, "BTA-WanPortDel")
            self._up.stop()
            
            
            _ofIP, _ofPort = _ob_info.orchf_site()
            _ob_id = _ob_info.ob_id()
            _mode = "DEL"
            _wan_list = []
            for _wan in _net_info.wan_list :
                _wdhcp = _wan.is_dhcp
                _wmac = _wan.mac
                _wmode = 'host'
                if not _ob_info.is_in_band() :
                    _wmode = oc.VAL_WAN_MD_OUTBAND
                _wnic = _wan.nic
                
                _wip = _wan.ip
                _wgw = _wan.gw
                _wpfx = _wan.prefixlen
                
                _wan_list.append({'mac':_wmac, 'mode':_wmode, 'nic':_wnic,
                                  'public_cidr_prefix': _wpfx, 'public_gw_ip': _wgw,
                                  'public_ip': _wip, 'public_ip_dhcp': _wdhcp})
            
            ## Request
            _ret = _reqWanPortMod(_ol, _ofIP, _ofPort, _ob_id, _mode, _ob_info, _mProg, _net_info)
            if not _ret :
                return self._RET_ERR
            
            ## Progress
            _ret = _progWanPortMod(_ofIP, _ofPort, _ob_id, _mode, _mProg)
            if not _ret :
                return self._RET_ERR
            
            _data[_TAG_RECOVERY_WAN].append(_RCVR_VWAN_RESTORE)
            
            ### delete unuse-if and wan ip change
            ## delete unuse-if
            self._up.set_msg("Delete UnUse-IF...")
            self._up.start()
            
            _del_unuse_uif = _ol.get_utm_wan_list()[len(_new_wlist):]
            logger.debug("----------- utm del unuse: %s"%str(_del_unuse_uif))
            if len(_del_unuse_uif) > 0 :
                while True:
                    _ol.login_utm(_uip, _uid, _upass)
                    _ret, _recovery, _err = _ol.del_utm_unuse_if(_uip, _del_unuse_uif, _uid)
                    _ol.logout_utm(_uip, _uid)
                    if _recovery :
                        if not _RCVR_VNF_RESTORE in _data[_TAG_RECOVERY_WAN] :
                            _data[_RCVR_VNF_RESTORE] = oc.FILE_BAK_VNF_UTM
                            _data[_TAG_RECOVERY_WAN].append(_RCVR_VNF_RESTORE)
                    if not _ret :
                        self._up.stop()
                        if bv.confirm_ok("Fail to Delete VNF-UnUse-IP.\nRetry?") == bv.RET_OK :
                            self._up.start()
                            continue
                        else:
                            if bv.confirm_ok("Fail to Delete VNF-UnUse-IP.\nContinue?") == bv.RET_OK :
                                _data[_TAG_SKIP_WAN].append(_SKWN_VNF_UNUSE_DEL)
                                logger.warning(" - Fail to Del Wan-Port, UnUse-IF Del Error, utm-if-list=%s, err=%s"%( str( _del_unuse_uif ), str(_err) ))
                                break
                            else:
                                logger.error("Fail to Del Wan-Port, UnUse-IF Del Error, utm-if-list=%s, err=%s"%( str( _del_unuse_uif ), str(_err) ))
                                bv.alert("Fail to Del UTM's UnUse-IF, utm-if-list=%s\nDelete UTM UnUse-IF!!!"%str(_del_unuse_uif))
                                return self._RET_ERR
                    else:
                        break
            self._up.stop()
            
            #3 wan-ip change
            if _mod_utm_ip :
                self._up.set_msg("Change WAN-IP...")
                self._up.start()
                
                
                _first_mod_wnic_idx = 0
                _tmp_idx = 0
                for _wan in _prev_wlist :
                    _prev_nic = _wan.nic()
                    if _prev_nic in _del_nic_list :
                        _first_mod_wnic_idx = _tmp_idx
                        break
                    _tmp_idx += 1
                    
                _prv_chg_wnet = _prev_wlist[_first_mod_wnic_idx:len(_new_wlist)]
                _prvStaticWan = {}
                for _c_wnet in _prv_chg_wnet :
                    _uwnic = _ol.to_utm_nic(_c_wnet.bridge())
                    if _uwnic != None:
                        if not _c_wnet.is_dhcp() :
                            _prvStaticWan.update({_uwnic:{'gw':_c_wnet.gw(), 'ip':_c_wnet.ip()}})
                    else:
                        logger.warning(" - Fail to Del Wan-Port, Unknown UTM NicInfo, br=%s"%( str(_c_wnet.bridge()) ))
                
                _chg_unet = []
                _chg_wnet = _new_wlist[_first_mod_wnic_idx:]
                for _nwnet in _chg_wnet :
                    _uwnic = _ol.to_utm_nic(_nwnet.bridge())
                    if _uwnic != None:
                        _chg_unet.append({"nic":_uwnic, "is_dhcp":_nwnet.is_dhcp(), "ip": _nwnet.ip(),
                                           "subnet": _nwnet.mask(), "gw": _nwnet.gw(), "mac":_nwnet.mac()})
                    else:
                        self._up.stop()
                        if bv.confirm_ok("Fail to Get VNF-NIC, br=%s.\nContinue?"%str(_nwnet.bridge())) == bv.RET_OK :
                            self._up.start()
                            _data[_TAG_SKIP_WAN].append(_SKWN_VNF_IP_CHG)
                            logger.warning(" - Fail to Del Wan-Port, Unknown UTM NicInfo, br=%s"%( str(_nwnet.bridge()) ))
                        else:
                            logger.error("Fail to Del Wan-Port, Unknown UTM NicInfo, br=%s"%( str(_nwnet.bridge()) ))
                            bv.alert("Unknown UTM NicInfo, br=%s"%( str(_nwnet.bridge()) ))
                            return self._RET_ERR
                
                logger.debug("----------- chg prv net info: %s"%str(_prv_chg_wnet))
                logger.debug("----------- chg new net info: %s"%str(_chg_wnet))
                logger.debug("----------- chg utm net info: %s"%str(_chg_unet))
                logger.debug("----------- chg utm prv static gw: %s"%str(_prvStaticWan))
                _ret, _err, _rb = _bl.change_utm_wan_ip(_uip, _chg_unet, _prvStaticWan, _uid, _upass)
                sleep(0.5)
                if _rb :
                    if not _RCVR_VNF_RESTORE in _data[_TAG_RECOVERY_WAN] :
                        _data[_RCVR_VNF_RESTORE] = oc.FILE_BAK_VNF_UTM
                        _data[_TAG_RECOVERY_WAN].append(_RCVR_VNF_RESTORE)
                
                if _ret != 0 :
                    self._up.stop()
                    if bv.confirm_ok("Fail to Change VNF-IP.\nContinue?") == bv.RET_OK :
                        _data[_TAG_SKIP_WAN].append(_SKWN_VNF_IP_CHG)
                        logger.warning(" - Fail to Del Wan-Port, UTM IP Change Error, err=%s"%( str(_err) ))
                    else:
                        logger.error("Fail to Del Wan-Port, UTM IP Change Error, err=%s"%( str(_err) ))
                        bv.alert("UTM IP Change Error, err=%s"%( str(_err) ))
                        return self._RET_ERR
                self._up.stop()
            
            logger.info(" - SUCC: %s For WAN-Port DEL"%_item)
            _mProg.set_perc(100)
        else:
            logger.info(" - SKIP: %s For WAN-Port DEL"%_item)
            _mProg.set_perc(bv.G_STATUS_SKIP)
        bv.update_progBar(_mProg)
        
        
        ### 10. wan-sw to vnf
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        if _has_utm and _ob_info.is_in_band() and _RCVR_SW_VNF in _data[_TAG_RECOVERY_WAN] :
            _ret = _bl.wanSw_obaRun(_ob_info, oc.VAL_WAN_MD_VNF, True, _uip, _mProg)
            if not _ret :
                if bv.confirm_ok("Fail to WAN-Switch VNF.\nContinue?") == bv.RET_OK :
                    _data[_TAG_SKIP_WAN].append(_SKWN_SW_VNF)
                    logger.warning(" - Fail to Del Wan-Port, WAN-Switch-VNF Error")
                else:
                    logger.error("Fail to Del Wan-Port, WAN-Switch-VNF Error")
                    bv.alert("Fail to Del Wan-Port, WAN-Switch-VNF Error")
                    return self._RET_ERR
            
            logger.info(" - SUCC: %s For WAN-Port DEL"%_item)
            _mProg.set_perc(100)
        else:
            logger.info(" - SKIP: %s For WAN-Port DEL"%_item)
            _mProg.set_perc(bv.G_STATUS_SKIP)
        bv.update_progBar(_mProg)
        sleep(3)
        
        
        ### 11. resume wan-mon
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        if _ob_info.is_in_band() :
            _url_resume = _ob_info.url_oba("127.0.0.1") + _URL_SCHD_RESUME
            while True:
                _ret, _ecode, _res = rest_api.sendReq(oc.HEADER, _url_resume, "GET", cCrt=oc.KEY_CLI_CRT, cKey=oc.KEY_CLI_KEY)
                if not _ret or type(_res) != dict or not _res.has_key('result') or _res['result'] != "OK" :
                    if bv.confirm_ok("Fail to Resume OBA Wan-Mon, Retry?") == bv.RET_OK :
                        logger.warning(" - Fail to Del Wan-Port, OBA Wan-Mon Resume Error, res=%s, Retry..."%str(_res))
                        sleep(3)
                        continue
                    else:
                        if bv.confirm_ok("Fail to Resume OBA Wan-Mon.\nContinue?") == bv.RET_OK :
                            _data[_TAG_SKIP_WAN].append(_SKWN_OBA_WANMON_RESUME)
                            logger.warning(" - Fail to Del Wan-Port, OBA Wan-Mon Resume Error, res=%s, Continue..."%str(_res))
                            logger.info(" - SKIP: %s For WAN-Port DEL"%_item)
                            _mProg.set_perc(bv.G_STATUS_SKIP)
                            break
                        else:
                            logger.error("Fail to Del Wan-Port, OBA Wan-Mon Resume Error, res=%s"%str(_res))
                            bv.alert("OBA Wan-Mon Resume Error, res=%s"%str(_res))
                            return self._RET_ERR
                else:
                    logger.info(" - SUCC: %s For WAN-Port DEL"%_item)
                    _mProg.set_perc(100)
                    break
        else:
            logger.info(" - SKIP: %s For WAN-Port DEL"%_item)
            _mProg.set_perc(bv.G_STATUS_SKIP)
        bv.update_progBar(_mProg)
        
        return self._RET_OK
    
    
    def _select(self, _data):
        _data[_TAG_RECOVERY_WAN] = []
        _data[_TAG_SKIP_WAN] = []
        try:
            _ret = self._do(_data)
        except Exception, e:
            _ret = self._RET_ERR
            if self._up != None : self._up.stop()
            logger.error("Fail to Del Wan-Port, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Del Wan-Port, exc=%s"%str(e))
        
        if _ret == self._RET_ERR :
            if len(_data[_TAG_RECOVERY_WAN]) > 0 and bv.confirm_ok("Rollback WAN?") == bv.RET_OK :
                _rb_list = _recovery_wan_port("DEL", _data)
                _rb_result_txt = _rb_txt(_data[_TAG_RECOVERY_WAN], _rb_list)
                logger.debug(" - - Recovery[WAN-DEL] Result\n%s"%str(_rb_result_txt))
                bv.confirm_ok(_rb_result_txt)
        elif _ret == self._RET_OK :
            _show_fail_skip_item(_data[_TAG_SKIP_WAN])
        
        if _data.has_key(_RCVR_OBA_CONF) :
            _ol = _data[oc.OTAG_LIB_OB]
            _ol.delFile(_data[_RCVR_OBA_CONF])
        if _data.has_key(_RCVR_VNF_RESTORE) :
            _ol = _data[oc.OTAG_LIB_OB]
            _ol.delFile(_data[_RCVR_VNF_RESTORE])
        return _ret
    
    def _next(self, _ret, _data):
        return self._RET_OK


class _OBNetLANNetworkMod(_LinkedMenu):
    
    def __init__(self, _prevMenu, _mode):
        _LinkedMenu.__init__(self, "ObLanPort%s"%_mode, _prevMenu)
        self._mode = _mode
    
    def _select(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _lan_list = _ob_info.lan_net_list()
        _lan_menu = []
        for _lan in _lan_list :
            _lan_menu.append((_lan.name(),""))
        
        _ret = bv.get_menu("Select LAN-Network...", _lan_menu)
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        else:
            _data[_TAG_LAN_MOD_NAME] = _ret
            return _ret
    
    def _next(self, _ret, _data):
        if self._mode == "ADD":
            return _OBNetLAN_X_PortAdd(self).get_res(_data)
        elif self._mode == "DEL":
            return _OBNetLAN_X_PortDel(self).get_res(_data)
        elif self._mode == "CHG":
            return _OBNetIPConfLanChk(self).get_res(_data)
        else:
            logger.error("Fail to Modify LAN-Port, Unkown Operation, mode=%s"%str(self._mode))
            bv.alert("Unkown Operation, mode=%s"%str(self._mode))
            return self._RET_UNIMPL


class _OBNetLAN_X_PortAdd(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObLanXPortAdd", _prevMenu)
    
    def _do(self, _data, _lan_name):
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _idx = -1
        _ele = ["Select Port", "Stop OBA", "Add Lan-Port", "Save OBA-Config", "Start OBA"]
        _mProg = bv.MixedProgBarInfo("Lan Port Add", _ele)
        _mod_utm_ip = False
        
        logger.info("Start LAN-Port Add...")
        
        _usable_nics, _selected_nics = _bl.get_usable_nics(_ob_info)
        if len(_usable_nics) < 1 :
            logger.error("Fail to Add Lan-Port, No Physical Port")
            bv.alert("No Available Port")
            return self._RET_ERR
        
        ### 1. select if
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        _new_nic_list = None
        while True :
            _ret, _nics, _macs, _conns, _limit = _bl.get_host_nic("LAN-%s Port Select"%str(_lan_name), _selected_nics, True, _nic_model=_ob_info.hw_nic_model())
            if _ret != self._RET_OK :
                return _ret
            
            if len(_nics) < 1:
                bv.alert("No Selected Port")
                continue
            
            _new_nic_list = _nics
            break
        
        logger.info(" - SUCC: %s For LAN-Port ADD, nic=%s"%( _item, str(_new_nic_list) ))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 2. oba stop
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, _mProg)
        if not _ret :
            if bv.confirm_ok("Fail to Stop Onebox-Agent.\nContinue?") != bv.RET_OK :
                _data[_TAG_RECOVERY_LAN].append(_RCVR_OBA_START)
                logger.error("Fail to Add Lan-Port, OBA Stop Error, err=%s"%str(_err))
                bv.alert("Fail to Stop Onebox-Agent")
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Stop OBA, Continue...")
        
        logger.info(" - SUCC: %s For LAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 3. add port to ovs
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _brname = oc.VAL_DEF_VNF_LAN_BR_PFX + _lan_name
        _data[_TAG_RECOVERY_LAN].append(_RCVR_VNET_LAN_NIC)
        _data[_RCVR_VNET_LAN_NIC] = _lan_name
        for _lan_nic in _new_nic_list :
            if not _ol.get_vim().add_br_port(_brname, _lan_nic, _ob_info.ovs_dpdk()) :
                logger.error("Fail to Add Lan-Port, VIM Port Add Error, br=%s, port=%s"%( str(_brname), str(_lan_nic) ))
                bv.alert("VIM Port Add Error, br=%s, port=%s"%( str(_brname), str(_lan_nic) ))
                return self._RET_ERR
        
        logger.info(" - SUCC: %s For LAN-Port ADD, brname=%s"%(_item, _brname))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 4. save oba-config
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _lan_info = _ob_info.lan_xnet(_lan_name)
        _lan_info.add_nics(_new_nic_list)
        
        today = datetime.datetime.now()
        _bid = today.strftime('%y%m%d%H%M')
        _bname = oc.DIR_TMP + oc.VAL_OBA_NAME + ".conf.bak.%s"%str(_bid)
        _data[_TAG_RECOVERY_LAN].append(_RCVR_OBA_CONF)
        _data[_RCVR_OBA_CONF] = _bname
        if not _ol.copyFile(oc.FILE_OBA_CONF, _bname) :
            if bv.confirm_ok("Fail to Backup OBA-Config.\nContinue?") != bv.RET_OK :
                logger.error("Fail to Add LAN-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                bv.alert("Fail to Add LAN-Port, OBA-Config Backup Error\n - src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Add Lan-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
        try:
            _ob_info.saveToCfg()
        except Exception, e:
            logger.error("Fail to Add Lan-Port, OBA-Config Save Error, ob_info=%s"%str(_ob_info))
            logger.exception(e)
            bv.alert("Fail to Add Lan-Port, OBA-Config Save Error")
            return self._RET_ERR
        
        logger.info(" - SUCC: %s For LAN-Port ADD"%(_item))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 5. oba start
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, _mProg)
        if not _ret :
            if bv.confirm_ok("Fail to Start Onebox-Agent.\nContinue?") != bv.RET_OK :
                _data[_TAG_RECOVERY_LAN].append(_RCVR_OBA_START)
                logger.error("Fail to Add Lan-Port, OBA Start Error, err=%s"%str(_err))
                bv.alert("Fail to Start Onebox-Agent")
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Start OBA, Continue...")
        
        logger.info(" - SUCC: %s For LAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        return self._RET_OK
    
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _lan_name = _data[_TAG_LAN_MOD_NAME]
        _lan_info = _ob_info.lan_xnet(_lan_name)
        if _lan_info == None :
            logger.error("Fail to Add Lan-Port, Invalid LAN-NET Name, name=%s"%str(_lan_name))
            bv.alert("Invalid LAN-NET Name, name=%s\nRetry to Select LAN-NET"%str(_lan_name))
            return self._RET_BACK
        
        _data[_TAG_RECOVERY_LAN] = []
        try:
            _ret = self._do(_data, _lan_name)
        except Exception, e:
            _ret = self._RET_ERR
            logger.error("Fail to Add Lan-Port, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Add Lan-Port, exc=%s"%str(e))
        
        if _ret == self._RET_ERR :
            if len(_data[_TAG_RECOVERY_LAN]) > 0 and bv.confirm_ok("Rollback LAN?") == bv.RET_OK :
                _rb_list = _recovery_lan_port("ADD", _data)
                _rb_result_txt = _rb_txt(_data[_TAG_RECOVERY_LAN], _rb_list)
                logger.debug(" - - Recovery[LAN-ADD] Result:\n%s"%str(_rb_result_txt))
                bv.confirm_ok(_rb_result_txt)
                
        if _data.has_key(_RCVR_OBA_CONF) :
            _ol = _data[oc.OTAG_LIB_OB]
            _ol.delFile(_data[_RCVR_OBA_CONF])
        return _ret
    
    def _next(self, _ret, _data):
        return self._RET_OK


class _OBNetLAN_X_PortDel(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObLanXPortDel", _prevMenu)
    
    def _do(self, _data, _lan_name):
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _idx = -1
        _ele = ["Select Port", "Stop OBA", "Del Lan-Port", "Save OBA-Config", "Start OBA"]
        _mProg = bv.MixedProgBarInfo("Lan Port Del", _ele)
        _mod_utm_ip = False
        
        logger.info("Start LAN-Port Del...")
        
        _lan_info = _ob_info.lan_xnet(_lan_name)
        
        ### 1. select if
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        _prev_nics = _lan_info.nics()
        if len(_prev_nics) < 1 :
            logger.error("Fail to Del LAN-Port, No Port, net=%s"%str(_lan_name))
            bv.alert("Fail to Del LAN-Port, No Port, net=%s"%str(_lan_name))
            return self._RET_ERR
        
        _del_nic_list = []
        while True:
            _choice = []
            for _wnic in _prev_nics :
                _choice.append(( _wnic, "", False ))
            
            _ret = bv.get_multi_choice_menu("Select LAN-%s Port to Remove.."%str(_lan_name), _choice)
            if _ret == bv.RET_NO :
                return self._RET_BACK
            elif _ret == bv.RET_ERR :
                return self._RET_ERR
            
            if len(_ret) < 1 :
                bv.alert("Fail to Del LAN-Port, Select At Least One")
                continue
            
            _del_nic_list = _ret
            break
        
        logger.info(" - SUCC: %s For LAN-Port DEL, nics=%s"%( _item, str(_del_nic_list) ))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 2. oba stop
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, _mProg)
        if not _ret :
            if bv.confirm_ok("Fail to Stop Onebox-Agent.\nContinue?") != bv.RET_OK :
                _data[_TAG_RECOVERY_LAN].append(_RCVR_OBA_START)
                logger.error("Fail to Del Lan-Port, OBA Stop Error, err=%s"%str(_err))
                bv.alert("Fail to Stop Onebox-Agent")
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Stop OBA, Continue...")
        
        logger.info(" - SUCC: %s For LAN-Port DEL"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 3. del port to ovs
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _brname = oc.VAL_DEF_VNF_LAN_BR_PFX + _lan_name
        _data[_TAG_RECOVERY_LAN].append(_RCVR_VNET_LAN_NIC)
        _data[_RCVR_VNET_LAN_NIC] = _lan_name
        for _lan_nic in _del_nic_list :
            if not _ol.get_vim().del_br_port(_lan_nic, _brname) :
                logger.warning(" - Fail to Del Lan-Port, VIM Port Del Error, br=%s, port=%s"%( str(_brname), str(_lan_nic) ))
        
        logger.info(" - SUCC: %s For LAN-Port DEL, brname=%s"%(_item, _brname))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 4. save oba-config
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _lan_info = _ob_info.lan_xnet(_lan_name)
        _lan_info.del_nics(_del_nic_list)
        
        today = datetime.datetime.now()
        _bid = today.strftime('%y%m%d%H%M')
        _bname = oc.DIR_TMP + oc.VAL_OBA_NAME + ".conf.bak.%s"%str(_bid)
        _data[_TAG_RECOVERY_LAN].append(_RCVR_OBA_CONF)
        _data[_RCVR_OBA_CONF] = _bname
        if not _ol.copyFile(oc.FILE_OBA_CONF, _bname) :
            if bv.confirm_ok("Fail to Backup OBA-Config.\nContinue?") != bv.RET_OK :
                logger.error("Fail to Del LAN-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                bv.alert("Fail to Del LAN-Port, OBA-Config Backup Error\n - src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Del Lan-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
        try:
            _ob_info.saveToCfg()
        except Exception, e:
            logger.error("Fail to Del Lan-Port, OBA-Config Save Error, ob_info=%s"%str(_ob_info))
            logger.exception(e)
            bv.alert("Fail to Del Lan-Port, OBA-Config Save Error")
            return self._RET_ERR
        
        logger.info(" - SUCC: %s For LAN-Port DEL"%(_item))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 5. oba start
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, _mProg)
        if not _ret :
            if bv.confirm_ok("Fail to Start Onebox-Agent.\nContinue?") != bv.RET_OK :
                _data[_TAG_RECOVERY_LAN].append(_RCVR_OBA_START)
                logger.error("Fail to Del Lan-Port, OBA Start Error, err=%s"%str(_err))
                bv.alert("Fail to Start Onebox-Agent")
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Start OBA, Continue...")
        
        logger.info(" - SUCC: %s For LAN-Port DEL"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        return self._RET_OK
    
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _lan_name = _data[_TAG_LAN_MOD_NAME]
        _lan_info = _ob_info.lan_xnet(_lan_name)
        if _lan_info == None :
            logger.error("Fail to Del Lan-Port, Invalid LAN-NET Name, name=%s"%str(_lan_name))
            bv.alert("Invalid LAN-NET Name, name=%s\nRetry to Select LAN-NET"%str(_lan_name))
            return self._RET_BACK
        
        _data[_TAG_RECOVERY_LAN] = []
        try:
            _ret = self._do(_data, _lan_name)
        except Exception, e:
            _ret = self._RET_ERR
            logger.error("Fail to Del Lan-Port, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Del Lan-Port, exc=%s"%str(e))
        
        if _ret == self._RET_ERR :
            if len(_data[_TAG_RECOVERY_LAN]) > 0 and bv.confirm_ok("Rollback LAN?") == bv.RET_OK :
                _rb_list = _recovery_lan_port("DEL", _data)
                _rb_result_txt = _rb_txt(_data[_TAG_RECOVERY_LAN], _rb_list)
                logger.debug(" - - Recovery[LAN-DEL] Result:\n%s"%str(_rb_result_txt))
                bv.confirm_ok(_rb_result_txt)
                
        if _data.has_key(_RCVR_OBA_CONF) :
            _ol = _data[oc.OTAG_LIB_OB]
            _ol.delFile(_data[_RCVR_OBA_CONF])
        return _ret
    
    def _next(self, _ret, _data):
        return self._RET_OK


class _OBNetEVWPortAdd(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObEVWPortAdd", _prevMenu)
    
    def _do(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ol = _data[oc.OTAG_LIB_OB]
        
        _idx = 0
        _ele = ["Check Onebox", "Input ExtraWan-Info", "Stop OBA", "Apply VI-Net", "Save OBA-Config", "Start OBA"]
        _mProg = bv.MixedProgBarInfo("Extra-Wan Port Add", _ele)
        
        logger.info("Start Extra-WAN-Port Add...")
        ### 1. check condition
        _item = _ele[_idx]
        _mProg.inc(10)
        
        ## check count
        _evw_list = _ob_info.extra_wan_list()
        _evw_len = 0
        if type(_evw_list) == list :
            _evw_len = len(_evw_list)
        else:
            _evw_list = []
        
        _br_list = oc.VAL_DEF_VI_EWAN_BR_LIST
        for _evw in _evw_list :
            if _evw.bridge() in _br_list :
                _br_list.remove(_evw.bridge())
        if len(_br_list) < 1 :
            logger.error("Fail to Add Extra-Wan-Port, Max Extra-Wan")
            bv.alert("Extra-Wan(Max=%s) Exceed"%str(oc.VAL_EVWAN_MAX_NUM))
            return self._RET_ERR
        _mProg.set_perc(25)
        bv.update_progBar(_mProg, "Check Extra-Wan-Port")
        
        ## 
        if _evw_len >= oc.VAL_EVWAN_MAX_NUM :
            logger.error("Fail to Add Extra-Wan-Port, Max Extra-Wan-Port")
            bv.alert("Extra-Wan-Port(Max=%s) Exceed"%str(oc.VAL_EVWAN_MAX_NUM))
            return self._RET_ERR
        _mProg.set_perc(50)
        bv.update_progBar(_mProg, "Check Physical-Port")
        
        ## phy nic
        _usable_nics, _selected_nics = _bl.get_usable_nics(_ob_info)
        if len(_usable_nics) < 1 :
            logger.error("Fail to Add Extra-Wan-Port, No Physical Interface")
            bv.alert("No Available Interface")
            return self._RET_ERR
        _mProg.set_perc(90)
        bv.update_progBar(_mProg, "Input Extra-Wan Info")
        
        logger.info(" - SUCC: %s For WAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 2. Input ExtraWan-Info
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(10)
        bv.update_progBar(_mProg)
        
        _net_list = (_data[_TAG_EVWAN_LIST] if _data.has_key(_TAG_EVWAN_LIST) else [])
        _idx = 0
        _MAX_LEN = len(_br_list)
        while True:
            ## select nic
            _ret, _nic, _mac, _conn, _limit = _bl.get_host_nic("ExtraWAN(%s) Select"%str(_br_list[_idx]), _selected_nics, _nic_model=_ob_info.hw_nic_model())
            
            if _ret == self._RET_BACK :
                if _idx <= 0 :
                    return self._RET_BACK
                else:
                    _idx = max(0, _idx-1)
                
                try:
                    _selected_nics.pop()
                except IndexError:
                    pass
                continue
            elif _ret == self._RET_ERR :
                return self._RET_ERR
            
            ## config network
            if len(_net_list) > _idx :
                # overwrite ip
                _prvnet = _net_list[_idx]
                _oaddr = ob_info.create_addr("evwan-add-%s"%(str(_idx)), oc.VAL_NET_TYPE_EVWAN, _nic, _prvnet.is_dhcp(), 
                                           _ip=_prvnet.ip(), _mask=_prvnet.mask(), _gw=_prvnet.gw(), 
                                           _dev=_br_list[_idx], _mac=_mac, _vlan=_prvnet.vlan())
            else:
                _oaddr = ob_info.create_addr("evwan-add-%s"%(str(_idx)), oc.VAL_NET_TYPE_EVWAN, _nic, None, 
                                           _dev=_br_list[_idx], _mac=_mac)
            
            _ret = _bl.set_extern_ip("Extra-WAN IP Config", _oaddr)
            if _ret == self._RET_OK :
                if len(_net_list) >= (_idx + 1) :
                    _net_list[_idx] = _oaddr
                else:
                    _net_list.append(_oaddr)
                _selected_nics.append(_nic)
                
                if (_idx+1) >= (_MAX_LEN) :
                    break
                if _limit < 1 :
                    break
                
                _ret = bv.confirm_ok("Add Extra-WAN Interface?")
                if _ret == bv.RET_ERR :
                    return self._RET_ERR
                elif _ret == bv.RET_NO :
                    break
                
                _idx += 1
                continue
            elif _ret == self._RET_BACK :
                continue
            else :
                return self._RET_ERR
        _data[_TAG_EVWAN_LIST] = _net_list
        
        logger.info(" - SUCC: %s For Extra-WAN-Port ADD, info=%s"%( _item, str(_net_list) ))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 3. oba stop
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, _mProg)
        if not _ret :
            if bv.confirm_ok("Fail to Stop Onebox-Agent.\nContinue?") != bv.RET_OK :
                _data[_TAG_RECOVERY_EVW].append(_RCVR_OBA_START)
                logger.error("Fail to Add Extra-WAN-Port, OBA Stop Error, err=%s"%str(_err))
                bv.alert("Fail to Stop Onebox-Agent")
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Stop OBA, Continue...")
        
        logger.info(" - SUCC: %s For Extra-WAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 4. apply vi-net
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _data[_TAG_RECOVERY_EVW].append(_RCVR_VNET_EVW_NIC)
        _data[_RCVR_VNET_EVW_NIC] = _net_list
        for _evw in _net_list :
            _brname =_evw.bridge()
            _nic = _evw.nic()
            if not _ol.get_vim().add_br_port(_brname, _nic, _ob_info.ovs_dpdk()) :
                logger.error("Fail to Add Extra-WAN-Port, VIM Port Add Error, br=%s, port=%s"%( str(_brname), str(_nic) ))
                bv.alert("VIM Port Add Error, br=%s, port=%s"%( str(_brname), str(_nic) ))
                return self._RET_ERR
        
        logger.info(" - SUCC: %s For Extra-Wan-Port ADD, evw=%s"%(_item, str(_net_list)))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 5. save oba-config
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _ob_info.add_extra_wan(_net_list)
        
        today = datetime.datetime.now()
        _bid = today.strftime('%y%m%d%H%M')
        _bname = oc.DIR_TMP + oc.VAL_OBA_NAME + ".conf.bak.%s"%str(_bid)
        _data[_TAG_RECOVERY_EVW].append(_RCVR_OBA_CONF)
        _data[_RCVR_OBA_CONF] = _bname
        if not _ol.copyFile(oc.FILE_OBA_CONF, _bname) :
            if bv.confirm_ok("Fail to Backup OBA-Config.\nContinue?") != bv.RET_OK :
                logger.error("Fail to Add Extra-WAN-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                bv.alert("Fail to Add Extra-WAN-Port, OBA-Config Backup Error\n - src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Add Extra-WAN-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
        try:
            _ob_info.saveToCfg()
        except Exception, e:
            logger.error("Fail to Add Extra-WAN-Port, OBA-Config Save Error, ob_info=%s"%str(_ob_info))
            logger.exception(e)
            bv.alert("Fail to Add Extra-WAN-Port, OBA-Config Save Error")
            return self._RET_ERR
        
        logger.info(" - SUCC: %s For Extra-WAN-Port ADD"%(_item))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 6. oba start
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, _mProg)
        if not _ret :
            if bv.confirm_ok("Fail to Start Onebox-Agent.\nContinue?") != bv.RET_OK :
                _data[_TAG_RECOVERY_EVW].append(_RCVR_OBA_START)
                logger.error("Fail to Add Extra-WAN-Port, OBA Start Error, err=%s"%str(_err))
                bv.alert("Fail to Start Onebox-Agent")
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Start OBA, Continue...")
        
        logger.info(" - SUCC: %s For Extra-WAN-Port ADD"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        return self._RET_OK
    
    
    def _select(self, _data):
        _data[_TAG_RECOVERY_EVW] = []
        try:
            _ret = self._do(_data)
        except Exception, e:
            _ret = self._RET_ERR
            logger.error("Fail to Add Extra-Wan-Port, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Add Extra-Wan-Port, exc=%s"%str(e))
        
        if _ret == self._RET_ERR :
            if len(_data[_TAG_RECOVERY_EVW]) > 0 and bv.confirm_ok("Rollback Extra-Wan?") == bv.RET_OK :
                _rb_list = _recovery_evw_port(_data, "ADD")
                _rb_result_txt = _rb_txt(_data[_TAG_RECOVERY_EVW], _rb_list)
                logger.debug(" - - Recovery[Extra-WAN-ADD] Result:\n%s"%str(_rb_result_txt))
                bv.notify(_rb_result_txt)
                
        if _data.has_key(_RCVR_OBA_CONF) :
            _ol = _data[oc.OTAG_LIB_OB]
            _ol.delFile(_data[_RCVR_OBA_CONF])
        return _ret
    
    def _next(self, _ret, _data):
        return self._RET_OK


class _OBNetEVWPortDel(_LinkedMenu):

    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObEVWPortDel", _prevMenu)
    
    def _do(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ol = _data[oc.OTAG_LIB_OB]
        
        _idx = 0
        _ele = ["Select Port", "Stop OBA", "Apply VI-Net", "Save OBA-Config", "Start OBA"]
        _mProg = bv.MixedProgBarInfo("Extra-Wan Port Del", _ele)
        
        logger.info("Start Extra-WAN-Port Del...")
        _item = _ele[_idx]
        _mProg.inc(10)
        
        _evw_list = _ob_info.extra_wan_list()
        _evw_len = 0
        if type(_evw_list) == list :
            _evw_len = len(_evw_list)
        
        if _evw_len < 1 or type(_evw_list) != list :
            logger.error("Fail to Del Extra-Wan-Port, No Extra-Wan, evw_list=%s"%str(_evw_list))
            bv.alert("No Extra-Wan, info=%s"%str(_evw_list))
            return self._RET_ERR
        
        ### 1. select wan
        _del_net_list = []
        while True:
            _choice = []
            for _evw in _evw_list :
                _choice.append(( _evw.bridge(), "", False ))
            
            _ret = bv.get_multi_choice_menu("Select Extra-WAN-Port to Remove..", _choice)
            if _ret == bv.RET_NO :
                return self._RET_BACK
            elif _ret == bv.RET_ERR :
                return self._RET_ERR
            
            if len(_ret) < 1 :
                bv.alert("Fail to Del Extra-Wan-Port, Select At Least One")
                continue
            
            _extra_p = _ol.get_extra_vnf_list()
            if type(_extra_p) == list :
                _retry_sel = False
                for _del_br in _ret:
                    for _ep in _extra_p :
                        if _del_br in _ep.p_wan_list :
                            if bv.confirm_ok("Extra-WAN[%s-%s] Used..\nConitnue?"%( str(_del_br), str(_ep.p_type) )) != bv.RET_OK :
                                _retry_sel = True
                        if _retry_sel:
                            break
                    if _retry_sel :
                        break
                if _retry_sel :
                    continue
            
            _del_net_list = _ret
            break
        
        logger.info(" - SUCC: %s For Extra-WAN-Port DEL, net=%s"%( _item, str(_del_net_list) ))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 2. oba stop
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, _mProg)
        if not _ret :
            if bv.confirm_ok("Fail to Stop Onebox-Agent.\nContinue?") != bv.RET_OK :
                _data[_TAG_RECOVERY_EVW].append(_RCVR_OBA_START)
                logger.error("Fail to Del Extra-WAN-Port, OBA Stop Error, err=%s"%str(_err))
                bv.alert("Fail to Stop Onebox-Agent")
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Stop OBA, Continue...")
        
        logger.info(" - SUCC: %s For Extra-WAN-Port Del"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 3. del vi-net
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _data[_TAG_RECOVERY_EVW].append(_RCVR_VNET_EVW_NIC)
        _data[_RCVR_VNET_EVW_NIC] = _evw_list
        if not _bl.reset_vim_br(_del_net_list) :
            logger.error("Fail to Del Extra-WAN-Port, VIM Port Del Error, br=%s"%( str(_del_net_list) ))
            bv.alert("VIM Port Del Error, br=%s"%( str(_del_net_list) ))
            return self._RET_ERR
        
        logger.info(" - SUCC: %s For Extra-Wan-Port DEL, br=%s"%(_item, str(_del_net_list)))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 4. save oba-config
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _ob_info.del_extra_wan(_del_net_list)
        
        today = datetime.datetime.now()
        _bid = today.strftime('%y%m%d%H%M')
        _bname = oc.DIR_TMP + oc.VAL_OBA_NAME + ".conf.bak.%s"%str(_bid)
        _data[_TAG_RECOVERY_EVW].append(_RCVR_OBA_CONF)
        _data[_RCVR_OBA_CONF] = _bname
        if not _ol.copyFile(oc.FILE_OBA_CONF, _bname) :
            if bv.confirm_ok("Fail to Backup OBA-Config.\nContinue?") != bv.RET_OK :
                logger.error("Fail to Del Extra-WAN-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                bv.alert("Fail to Del Extra-WAN-Port, OBA-Config Backup Error\n - src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Del Extra-WAN-Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
        try:
            _ob_info.saveToCfg()
        except Exception, e:
            logger.error("Fail to Del Extra-WAN-Port, OBA-Config Save Error, ob_info=%s"%str(_ob_info))
            logger.exception(e)
            bv.alert("Fail to Del Extra-WAN-Port, OBA-Config Save Error")
            return self._RET_ERR
        
        logger.info(" - SUCC: %s For Extra-WAN-Port DEL"%(_item))
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        
        ### 5. oba start
        _idx += 1
        _item = _ele[_idx]
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, _mProg)
        if not _ret :
            if bv.confirm_ok("Fail to Start Onebox-Agent.\nContinue?") != bv.RET_OK :
                _data[_TAG_RECOVERY_EVW].append(_RCVR_OBA_START)
                logger.error("Fail to Del Extra-WAN-Port, OBA Start Error, err=%s"%str(_err))
                bv.alert("Fail to Start Onebox-Agent")
                return self._RET_ERR
            else:
                logger.warning(" - Fail to Start OBA, Continue...")
        
        logger.info(" - SUCC: %s For Extra-WAN-Port DEL"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        return self._RET_OK
    
    
    def _select(self, _data):
        _data[_TAG_RECOVERY_EVW] = []
        try:
            _ret = self._do(_data)
        except Exception, e:
            _ret = self._RET_ERR
            logger.error("Fail to Del Extra-Wan-Port, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Del Extra-Wan-Port, exc=%s"%str(e))
        
        if _ret == self._RET_ERR :
            if len(_data[_TAG_RECOVERY_EVW]) > 0 and bv.confirm_ok("Rollback Extra-Wan?") == bv.RET_OK :
                _rb_list = _recovery_evw_port(_data, "DEL")
                _rb_result_txt = _rb_txt(_data[_TAG_RECOVERY_EVW], _rb_list)
                logger.debug(" - - Recovery[Extra-WAN-DEL] Result:\n%s"%str(_rb_result_txt))
                bv.confirm_ok(_rb_result_txt)
                
        if _data.has_key(_RCVR_OBA_CONF) :
            _ol = _data[oc.OTAG_LIB_OB]
            _ol.delFile(_data[_RCVR_OBA_CONF])
        return _ret
    
    def _next(self, _ret, _data):
        return self._RET_OK



class _OBNetPortChgSetting(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "ObPortChgSet", _prevMenu)
    
    def _select(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ol = _data[oc.OTAG_LIB_OB]
        
        _prog = bv.ProgBarInfo("Getting Port Info...")
        _prog.inc(5)
        bv.start_progBar("Getting Port Info...", "Getting Port Info...")
        bv.update_progBar(_prog)
        _up = bv.UpdateProg(_prog, 2, 1)
        _up.start()
        
        try:
            _av_nics, _sel_nics = _bl.get_usable_nics(_ob_info)
            if len(_av_nics) < 1 :
                _up.stop()
                logger.error("Fail to Change Port, No Available NIC")
                bv.alert("Fail to Change Port, No Available NIC")
                return self._RET_ERR
            
            _is_inband = _ob_info.is_in_band()
            _ext_net_list = _ob_info.mgmt_list() + _ob_info.wan_list()
            if type(_ob_info.extra_wan_list()) == list : _ext_net_list += _ob_info.extra_wan_list()
            _int_net_list = _ob_info.lan_net_list()
            
            _port_info = {}
            for _ext_net in _ext_net_list :
                _ext_nic = _ext_net.nic()
                if _ext_nic == None or str(_ext_nic).strip() == "" :
                    continue
                if _port_info.has_key(_ext_nic) :
                    _port_info[_ext_nic].append(_ext_net)
                else:
                    _port_info[_ext_nic] = [_ext_net]
            
            for _lan_net in _int_net_list :
                _lan_nics = _lan_net.nics()
                for _lan_nic in _lan_nics :
                    if _lan_nic == None or str(_lan_nic).strip() == "" :
                        continue
                    if _port_info.has_key(_lan_nic) :
                        _port_info[_lan_nic].append(_lan_net)
                    else:
                        _port_info[_lan_nic] = [_lan_net]
            
            _nic_list = _port_info.keys()
            _nic_list.sort()
            _port_chc = []
            for _nic in _nic_list :
                _net_list = _port_info[_nic]
                _br_list = []
                for _net in _net_list :
                    if _net.type() == oc.VAL_NET_TYPE_LAN :
                        _br_list.append(oc.VAL_NET_TYPE_LAN + "-" + _net.name())
                    else:
                        _br_list.append(_net.bridge())
                _port_chc.append( (_nic, ",".join(_br_list)) )
            
            if len(_port_chc) < 1 :
                _up.stop()
                logger.error("Fail to Change Port, No Used Nic, nics=%s, menu=%s"%( str(_port_info), str(_port_chc) ))
                bv.alert("Fail to Change Port, No Used Nic\n - nics=%s, menu=%s"%( str(_port_info), str(_port_chc) ))
                return self._RET_ERR
            
            _tport_chc = []
            for _tnic in _av_nics :
                _tport_chc.append( (str(_tnic), "") )
            _up.stop()
            bv.stop_progBar()
        except Exception, e:
            _up.stop()
            bv.stop_progBar()
            logger.error("Fail to Chang Port, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Chang Port, exc=%s"%str(e))
            return self._RET_ERR
        
        try:
            _src_nic = None
            _dst_nic = None
            while True:
                _sret = bv.get_menu("Select Interface to Change...", _port_chc)
                if _sret == bv.RET_NO :
                    return self._RET_BACK
                elif _sret == bv.RET_ERR :
                    logger.error("Fail to Change Port, Source-Inteface Select Error")
                    bv.alert("Fail to Change Port, Source-Inteface Select Error")
                    return self._RET_ERR
                _src_nic = str(_sret)
                
                _dret = bv.get_menu("Select Target Interface...", _tport_chc)
                if _dret == bv.RET_NO :
                    continue
                elif _dret == bv.RET_ERR:
                    logger.error("Fail to Change Port, Dst-Inteface Select Error, src=%s"%str(_src_nic))
                    bv.alert("Fail to Change Port, Dst-Inteface Select Error")
                    return self._RET_ERR
                
                _dst_nic = str(_dret)
                break
            
            if _src_nic in (None, "") or _dst_nic in (None, "") :
                logger.error("Fail to Change Port, Invalid Selected Nic, src=%s, dst=%s"%( str(_src_nic), str(_dst_nic) ))
                bv.alert("Fail to Change Port, Invalid Selected Nic\n - src=%s, dst=%s"%( str(_src_nic), str(_dst_nic) ))
                return self._RET_ERR
            
            _mac = _ol.get_host_mac(_dst_nic, _nic_model=_ob_info.hw_nic_model())
            if type(_mac) != dict or not _mac.has_key(_dst_nic) :
                logger.error("Fail to Change Port, NIC MAC Error, src=%s, dst=%s, dst-mac=%s"%( str(_src_nic), str(_dst_nic), str(_mac) ))
                bv.alert("Fail to Change Port, NIC MAC Error\n - src=%s, dst=%s, dst-mac=%s"%( str(_src_nic), str(_dst_nic), str(_mac) ))
                return self._RET_ERR
            
            _data[_TAG_CHG_PORT_SRC] = _src_nic
            _data[_TAG_CHG_PORT_SRC_NET] = _port_info[_src_nic]
            _data[_TAG_CHG_PORT_DST] = _dst_nic
            _data[_TAG_CHG_PORT_DST_MAC] = _mac[_dst_nic]
            logger.info(" - Selected Port, src=%s, dst=%s, src_net=%s"%( str(_src_nic), str(_dst_nic), str(_data[_TAG_CHG_PORT_SRC_NET]) ))
            
            return self._RET_OK
        except Exception, e:
            logger.error("Fail to Select Change Port, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Change Port, exc=%s"%str(e))
            return self._RET_ERR
        
    
    def _next(self, _ret, _data):
        return _OBNetPortChg().get_res(_data)


class _OBNetPortChg(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "ObPortChg", None)
    
    def _do(self, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        
        _dst_nic = _data[_TAG_CHG_PORT_DST]
        _dst_mac = _data[_TAG_CHG_PORT_DST_MAC]
        _src_nic = _data[_TAG_CHG_PORT_SRC]
        _src_nets = _data[_TAG_CHG_PORT_SRC_NET]
        
        _idx = -1
        _ele = ["Stop OBA", "Change OBA-CFG", "Change VI", "WAN-Switch to Host",  
                "Change Host-Net", "WAN-Switch to VNF", "Start OBA"]
        _mProg = bv.MixedProgBarInfo("Port Change...", _ele)
        bv.update_progBar(_mProg)
        _up = None
        try:
            ### 1. stop oba
            _idx += 1
            _item = _ele[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(1)
            bv.update_progBar(_mProg)
            _up = bv.UpdateProg(_mProg, 2, 1)
            _up.start()
            
            _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, _mProg)
            if not _ret :
                _up.stop()
                logger.error("Fail to Change Port, OBA Stop Error, err=%s"%str(_err))
                bv.alert("Fail to Stop Onebox-Agent")
                return False
            
            _data[_TAG_RECOVERY_PORT].append(_RCVR_OBA_START)
            _up.stop()
            logger.info(" - SUCC: %s For Port Change"%_item)
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            
            
            ### 2. chg oba-cfg
            _idx += 1
            _item = _ele[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(1)
            bv.update_progBar(_mProg)
            _up.start()
            
            _wan_mode = _ol.getWanMode(_ob_info)
            for _src_net in _src_nets :
                _src_net.change_nic(_src_nic, _dst_nic, _dst_mac)
            
            today = datetime.datetime.now()
            _bid = today.strftime('%y%m%d%H%M')
            _bname = oc.DIR_TMP + oc.VAL_OBA_NAME + ".conf.bak.%s"%str(_bid)
            _data[_TAG_RECOVERY_PORT].append(_RCVR_OBA_CONF)
            _data[_RCVR_OBA_CONF] = _bname
            if not _ol.copyFile(oc.FILE_OBA_CONF, _bname) :
                if bv.confirm_ok("Fail to Backup OBA-Config.\nContinue?") != bv.RET_OK :
                    logger.error("Fail to Change Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                    bv.alert("Fail to Change Port, OBA-Config Backup Error\n - src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
                    return self._RET_ERR
                else:
                    logger.warning(" - Fail to Change Port, OBA-Config Backup Error, src=%s, dst=%s"%(oc.FILE_OBA_CONF, _bname))
            try:
                _ob_info.saveToCfg()
            except Exception, e:
                logger.error("Fail to Change Port, OBA-Config Save Error, ob_info=%s"%str(_ob_info))
                logger.exception(e)
                bv.alert("Fail to Change Port, OBA-Config Save Error")
                return self._RET_ERR
            
            _up.stop()
            logger.info(" - SUCC: %s For Port Change, nets=%s"%( _item, str(_src_nets) ))
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            
            
            ### 3. chg vi
            _idx += 1
            _item = _ele[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(10)
            bv.update_progBar(_mProg)
            _up.start()
            
            _mod_host = False
            for _src_net in _src_nets :
                ## LAN
                if _src_net.type() == oc.VAL_NET_TYPE_LAN :
                    _brname = oc.VAL_DEF_VNF_LAN_BR_PFX + _src_net.name()
                    if not _RCVR_CHG_VNET_PORT in _data[_TAG_RECOVERY_PORT] :
                        _data[_TAG_RECOVERY_PORT].append(_RCVR_CHG_VNET_PORT)
                    _ol.get_vim().del_br_port(_src_nic, _brname)
                    _ret = _ol.get_vim().add_br_port(_brname, _dst_nic, _ob_info.ovs_dpdk())
                    if not _ret :
                        _up.stop()
                        logger.error("Fail to Change Port, VIM Port Change Error, src=%s, dst=%s"%(str(_src_net), str(_dst_nic)))
                        bv.alert("Fail to Change Port, VIM Port Change Error, src=%s, dst=%s"%(str(_src_nic), str(_dst_nic)))
                        return False
                ## OutBand Wan
                elif not _ob_info.is_in_band() and _src_net.type() == oc.VAL_NET_TYPE_WAN :
                    _brname = _src_net.bridge()
                    if not _RCVR_CHG_VNET_PORT in _data[_TAG_RECOVERY_PORT] :
                        _data[_TAG_RECOVERY_PORT].append(_RCVR_CHG_VNET_PORT)
                    _ol.get_vim().del_br_port(_src_nic, _brname)
                    _ret = _ol.get_vim().add_br_port(_brname, _dst_nic, _ob_info.ovs_dpdk())
                    if not _ret :
                        _up.stop()
                        logger.error("Fail to Change Port, VIM Port Change Error, src=%s, dst=%s"%(str(_src_net), str(_dst_nic)))
                        bv.alert("Fail to Change Port, VIM Port Change Error, src=%s, dst=%s"%(str(_src_nic), str(_dst_nic)))
                        return False
                ## evwan
                elif _src_net.type() == oc.VAL_NET_TYPE_EVWAN :
                    _brname = _src_net.bridge()
                    if not _RCVR_CHG_VNET_PORT in _data[_TAG_RECOVERY_PORT] :
                        _data[_TAG_RECOVERY_PORT].append(_RCVR_CHG_VNET_PORT)
                    _ol.get_vim().del_br_port(_src_nic, _brname)
                    _ret = _ol.get_vim().add_br_port(_brname, _dst_nic, _ob_info.ovs_dpdk())
                    if not _ret :
                        _up.stop()
                        logger.error("Fail to Change Port, VIM Port Change Error, src=%s, dst=%s"%(str(_src_net), str(_dst_nic)))
                        bv.alert("Fail to Change Port, VIM Port Change Error, src=%s, dst=%s"%(str(_src_nic), str(_dst_nic)))
                        return False
                
                ## WAN
                else:
                    _mod_host = True
            _up.stop()
            
            logger.info(" - SUCC: %s For Port Change"%_item)
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            
            
            ### 4. wan-sw to host
            _idx += 1
            _item = _ele[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(1)
            bv.update_progBar(_mProg)
            
            _uip = _ob_info.utm_local_ip()
            if _mod_host and _wan_mode == oc.VAL_WAN_MD_VNF:
                _data[_TAG_RECOVERY_PORT].append(_RCVR_SW_VNF)
                _ret = _bl.wanSw_obaRun(_ob_info, oc.VAL_WAN_MD_HOST, False, _uip, _mProg)
                if not _ret :
                    if bv.confirm_ok("Fail to WAN-Switch Host.\nContinue?") == bv.RET_OK :
                        logger.warning(" - Fail to Change Port, WAN-Switch-Host Error")
                    else:
                        logger.error("Fail to Change Port, WAN-Switch-Host Error")
                        bv.alert("Fail to Change Port, WAN-Switch-Host Error")
                        return self._RET_ERR
                
                logger.info(" - SUCC: %s For Port Change"%_item)
                _mProg.set_perc(100)
            else:
                logger.info(" - SKIP: %s For Port Change"%_item)
                _mProg.set_perc(bv.G_STATUS_SKIP)
            
            bv.update_progBar(_mProg)
            
            
            ### 5. chg host
            _idx += 1
            _item = _ele[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(1)
            bv.update_progBar(_mProg)
            
            if _mod_host :
                _up.start()
                _data[_TAG_RECOVERY_PORT].append(_RCVR_HOST_NET)
                _ret, _err = _bl.reset_os_br()
                if not _ret :
                    logger.warning(" - Fail to Change Port, Host-Net Reset Error, err=%s"%str(_err))
                _ret, _err = _bl.reset_vim_br(oc.VAL_DEF_VI_WAN_BR_LIST)
                if not _ret :
                    logger.warning(" - Fail to Change Port, VWAN-Port Reset Error, err=%s"%str(_err))
                if not _ol.del_host_def_route() :
                    logger.warning(" - Fail to Change Port, Host Default Route Delete Error")
                _up.stop()
                
                _ret, _err = _ol.config_mgmt_net(_ob_info.mgmt_list(), _mProg, bv)
                if not _ret :
                    logger.error("Fail to Change Port, Host Net Change Error, err=%s"%(str(_err)))
                    bv.alert("Fail to Change Port, Host Net Change Error\n - err=%s"%(str(_err)))
                    return False
                
                logger.info(" - SUCC: %s For Port Change, src_nets=%s, dst=%s"%( _item, str(_src_nets), str(_dst_nic) ))
                _mProg.set_perc(100)
            else:
                logger.info(" - SKIP: %s For Port Change"%_item)
                _mProg.set_perc(bv.G_STATUS_SKIP)
            
            bv.update_progBar(_mProg)
            sleep(1)
            
            
            ### 6. wan-sw to vnf
            _idx += 1
            _item = _ele[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(1)
            bv.update_progBar(_mProg)
            
            _wan_mode = _ol.getWanMode(_ob_info)
            if _RCVR_SW_VNF in _data[_TAG_RECOVERY_PORT] :
                _ret = _bl.wanSw_obaRun(_ob_info, oc.VAL_WAN_MD_VNF, False, _uip, _mProg)
                if not _ret :
                    if bv.confirm_ok("Fail to WAN-Switch VNF.\nContinue?") == bv.RET_OK :
                        _data[_TAG_RECOVERY_PORT].remove(_RCVR_SW_VNF)
                        _data[_TAG_SKIP_PORT].append(_SKWN_SW_VNF)
                        logger.warning(" - Fail to Change Port, WAN-Switch-VNF Error")
                    else:
                        logger.error("Fail to Change Port, WAN-Switch-VNF Error")
                        bv.alert("Fail to Change Port, WAN-Switch-VNF Error")
                        return self._RET_ERR
                else:
                    _data[_TAG_RECOVERY_PORT].remove(_RCVR_SW_VNF)
                
                logger.info(" - SUCC: %s For Port Change"%_item)
                _mProg.set_perc(100)
            else:
                logger.info(" - SKIP: %s For Port Change"%_item)
                _mProg.set_perc(bv.G_STATUS_SKIP)
            
            bv.update_progBar(_mProg)
            sleep(1)
            
            
            ### 7. start oba
            _idx += 1
            _item = _ele[_idx]
            _mProg.set_index(_idx)
            _mProg.inc(1)
            bv.update_progBar(_mProg)
            _up.start()
            
            _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, _mProg)
            if not _ret :
                _up.stop()
                if bv.confirm_ok("Fail to Change Port, OBA Start Error\nContinue?") == bv.RET_OK :
                    _data[_TAG_SKIP_PORT].append(_RCVR_OBA_START)
                    logger.warning("Fail to Change Port, OBA Start Error, err=%s"%str(_err))
                else:
                    logger.error("Fail to Change Port, OBA Start Error, err=%s"%str(_err))
                    bv.alert("Fail to Start Onebox-Agent")
                    return False
            
            _up.stop()
            logger.info(" - SUCC: %s For Port Change"%_item)
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            sleep(1)
            
            return True
        except Exception, e:
            _up.stop()
            logger.error("Fail to Change Port, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Change Port, exc=%s"%str(e))
            return False
    
    def _rollback(self, _data):
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        _recovery_list_tmp = _data[_TAG_RECOVERY_PORT]
        _recovery_list = []
        _recovery_txt_list = []
        if _RCVR_OBA_CONF in _recovery_list_tmp :
            _recovery_list.append(_RCVR_OBA_CONF)
            _recovery_txt_list.append(_rcvr_to_txt(_RCVR_OBA_CONF))
        if _RCVR_HOST_NET in _recovery_list_tmp :
            _recovery_list.append(_RCVR_HOST_NET)
            _recovery_txt_list.append(_rcvr_to_txt(_RCVR_HOST_NET))
        if _RCVR_CHG_VNET_PORT in _recovery_list_tmp :
            _recovery_list.append(_RCVR_CHG_VNET_PORT)
            _recovery_txt_list.append(_rcvr_to_txt(_RCVR_CHG_VNET_PORT))
        if _RCVR_SW_VNF in _recovery_list_tmp :
            _recovery_list.append(_RCVR_SW_VNF)
            _recovery_txt_list.append(_rcvr_to_txt(_RCVR_SW_VNF))
        
        
        _data[_TAG_RECOVERY_LAN] = _recovery_list
        
        _mProg = bv.MixedProgBarInfo("Start Recovery...", _recovery_txt_list)
        _idx = -1
        
        _rb_list = []
        _up = None
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], False, None)
        if not _ret :
            logger.warning("   - Fail to Stop OBA, err=%s"%str(_err))
        
        try:
            ### oba config
            if _RCVR_OBA_CONF in _recovery_list :
                _idx += 1
                _item = _recovery_txt_list[_idx]
                _mProg.set_index(_idx)
                _mProg.inc(10)
                bv.update_progBar(_mProg)
                if _ol.copyFile(_data[_RCVR_OBA_CONF], oc.FILE_OBA_CONF) :
                    _rb_list.append(_RCVR_OBA_CONF)
                else:
                    logger.error("Fail to Recovery, OBA-Config Rollback Error, bak=%s"%str(_data[_RCVR_OBA_CONF]))
                    bv.alert("Fail to Rollback OBA-Config\n - bak=%s"%str(_data[_RCVR_OBA_CONF]))
                    return _rb_list
                logger.info(" - SUCC: %s For Recovery Port-CHG"%(_item))
                _mProg.set_perc(100)
                bv.update_progBar(_mProg)
            
            with open(oc.FILE_OBA_CONF, "r") as f:
                _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
            _ob_info = OB_INFO().loadByCfg(_oba_cfg, True)
            
            ### host network
            if _RCVR_HOST_NET in _recovery_list :
                _idx += 1
                _item = _recovery_txt_list[_idx]
                _mProg.set_index(_idx)
                _mProg.inc(10)
                bv.update_progBar(_mProg)
                try:
                    _data[oc.OTAG_OBA_INFO] = _ob_info
                    _mProg.inc(12)
                    bv.update_progBar(_mProg)
                    
                    _up = bv.UpdateProg(_mProg, 2, 1, "Reset Host-Net...")
                    _up.start()
                    _ret, _err = _bl.reset_os_br()
                    if not _ret :
                        logger.warning(" - Fail to Recovery, Host-Net Reset Error, err=%s"%str(_err))
                    _up.set_msg("Reset VIM-NET...")
                    _ret, _err = _bl.reset_vim_br(oc.VAL_DEF_VI_WAN_BR_LIST)
                    if not _ret :
                        logger.warning(" - Fail to Recovery, VIM-Net Reset Error, err=%s"%str(_err))
                    _up.set_msg("Delete Default-GW...")
                    if not _ol.del_host_def_route() :
                        logger.warning(" - Fail to Recovery, Host Default Route Delete Error")
                    _up.stop()
                    
                    _mgmt_list = _ob_info.mgmt_list()
                    _ret, _err = _ol.config_mgmt_net(_mgmt_list, _mProg, bv)
                    if not _ret :
                        logger.warning(" - Fail to Recovery, Host-Net Rollback Error, err=%s"%str(_err))
                        _mProg.set_perc(bv.G_STATUS_FAIL)
                    else:
                        logger.info(" - SUCC: %s For Recovery Port-CHG"%(_item))
                        _mProg.set_perc(70)
                        _rb_list.append(_RCVR_HOST_NET)
                    
                    _mProg.set_perc(100)
                except Exception, e:
                    logger.warning(" - Fail to Recovery, Host-Net Rollback Error, exc=%s"%str(e))
                    logger.error(e)
                    _mProg.set_perc(bv.G_STATUS_FAIL)
                bv.update_progBar(_mProg)
            
            ### vnet port 
            if _RCVR_CHG_VNET_PORT in _recovery_list :
                _idx += 1
                _item = _recovery_txt_list[_idx]
                _mProg.set_index(_idx)
                _mProg.inc(10)
                bv.update_progBar(_mProg)
                
                _up = bv.UpdateProg(_mProg, 2, 1)
                _up.start()
                _dst_nic = _data[_TAG_CHG_PORT_DST]
                _src_nic = _data[_TAG_CHG_PORT_SRC]
                _src_nets = _data[_TAG_CHG_PORT_SRC_NET]
                _all_pass = True
                for _src_net in _src_nets :
                    ## LAN
                    if _src_net.type() == oc.VAL_NET_TYPE_LAN :
                        _brname = oc.VAL_DEF_VNF_LAN_BR_PFX + _src_net.name()
                        _ol.get_vim().del_br_port(_dst_nic, _brname)
                        _ret = _ol.get_vim().add_br_port(_brname, _src_nic, _ob_info.ovs_dpdk())
                        if not _ret :
                            logger.warning(" - Fail to Recovery, VIM Port Change Error, src=%s, dst=%s"%(str(_src_net), str(_src_nic)))
                            _all_pass = False
                    ## OutBand Wan
                    elif not _ob_info.is_in_band() and _src_net.type() == oc.VAL_NET_TYPE_WAN :
                        _brname = _src_net.bridge()
                        _ol.get_vim().del_br_port(_dst_nic, _brname)
                        _ret = _ol.get_vim().add_br_port(_brname, _src_nic, _ob_info.ovs_dpdk())
                        if not _ret :
                            logger.warning(" - Fail to Recovery, VIM Port Change Error, src=%s, dst=%s"%(str(_src_net), str(_src_nic)))
                            _all_pass = False
                    ## evwan
                    elif _src_net.type() == oc.VAL_NET_TYPE_EVWAN :
                        _brname = _src_net.bridge()
                        _ol.get_vim().del_br_port(_dst_nic, _brname)
                        _ret = _ol.get_vim().add_br_port(_brname, _src_nic, _ob_info.ovs_dpdk())
                        if not _ret :
                            logger.warning(" - Fail to Recovery, VIM Port Change Error, src=%s, dst=%s"%(str(_src_net), str(_src_nic)))
                            _all_pass = False
                    ## WAN
                    else:
                        continue
                    
                _up.stop()
                if _all_pass :
                    _mProg.set_perc(100)
                    _rb_list.append(_RCVR_CHG_VNET_PORT)
                else:
                    _mProg.set_perc(bv.G_STATUS_FAIL)
                bv.update_progBar(_mProg)
            
            ## wan-switch to vnf
            if _RCVR_SW_VNF in _recovery_list :
                _idx += 1
                _item = _recovery_txt_list[_idx]
                _mProg.set_index(_idx)
                _mProg.inc(10)
                bv.update_progBar(_mProg)
                
                _uip = _ob_info.utm_local_ip()
                _ret = _bl.wanSw_obaRun(_ob_info, oc.VAL_WAN_MD_VNF, False, _uip, _mProg)
                if not _ret :
                    logger.warning(" - Fail to Recovery, WAN-Switch to VNF Error")
                    _mProg.set_perc(bv.G_STATUS_FAIL)
                else:
                    logger.info(" - SUCC: %s For Recovery Port-CHG"%(_item))
                    _mProg.set_perc(100)
                    _rb_list.append(_RCVR_SW_VNF)
                
                bv.update_progBar(_mProg)
            
        except Exception, e:
            logger.error("Fail to Recovery Port-Chg, exc=%s"%(str(e)))
            logger.exception(e)
            if _up != None : _up.stop()
            bv.alert("Fail to Recovery Port-Chg, exc=%s"%(str(e)))
        
        _ret, _err = _bl.set_onebox_services([oc.VAL_OBA_NAME], True, None)
        if not _ret :
            logger.warning("   - Fail to Start OBA, err=%s"%str(_err))
        return _rb_list
    
    def _select(self, _data):
        _data[_TAG_RECOVERY_PORT] = []
        _data[_TAG_SKIP_PORT] = []
        _ret = self._do(_data)
        
        _fin_ret = self._RET_ERR
        if not _ret :
            if len(_data[_TAG_RECOVERY_PORT]) > 0 and bv.confirm_ok("Rollback Port?") == bv.RET_OK :
                _rb_list = self._rollback(_data)
                _rb_result_txt = _rb_txt(_data[_TAG_RECOVERY_PORT], _rb_list)
                logger.debug(" - - Recovery[Port-Chg] Result:\n%s"%str(_rb_result_txt))
                bv.confirm_ok(_rb_result_txt)
        else :
            _fin_ret = self._RET_OK
            _show_fail_skip_item(_data[_TAG_SKIP_PORT])
        
        if _data.has_key(_RCVR_OBA_CONF) :
            _ol = _data[oc.OTAG_LIB_OB]
            _ol.delFile(_data[_RCVR_OBA_CONF])
        
        return _fin_ret
    
    def _next(self, _ret, _data):
        return self._RET_OK














##################
### WAN SWITCH ###
##################




class _OBWanSwitch(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBWanSwitch", _prevMenu)
    
    def _select(self, _data):
        _data[bc.FUNC_TITLE] = "WAN-Switch"
        _obInfo = _data[oc.OTAG_OBA_INFO]
        if not _obInfo.is_in_band() :
            logger.warning("Not Possible in Out-of-Band")
            bv.alert("Not Possible in Out-of-Band")
            return self._RET_ERR
        
        _ol = _data[oc.OTAG_LIB_OB]
        _has_utm = _ol.hasUtm(_obInfo.wan_mac_list())
        _wmode = _ol.getWanMode(_obInfo)
        
        _sel_list = []
        if _wmode == oc.VAL_WAN_MD_HOST :
            _sel_list.append((oc.VAL_WAN_MD_VNF, ""))
        elif _wmode == oc.VAL_WAN_MD_VNF :
            _sel_list.append((oc.VAL_WAN_MD_HOST, ""))
        else:
            if _has_utm : 
                _sel_list.append((oc.VAL_WAN_MD_VNF, ""))
            _sel_list.append((oc.VAL_WAN_MD_HOST, ""))
        _ret = bv.get_menu("Select WAN Mode[now=%s]..."%str(_wmode), _sel_list)
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        else:
            return _ret
        
    def _next(self, _ret, _data):
        if not _ret in (oc.VAL_WAN_MD_HOST, oc.VAL_WAN_MD_VNF):
            logger.error("Invalid WAN Mode, mode=%s ..."%str(_ret))
            bv.alert("Invalid WAN Mode, mode=%s ..."%str(_ret))
            return self._RET_ERR
        
        if _ret == oc.VAL_WAN_MD_HOST:
            _data[bc.FUNC_TITLE] = "WAN-Switch to Host"
        else:
            _data[bc.FUNC_TITLE] = "WAN-Switch to VNF"
        
        _data[_TAG_WANSW] = {_TAG_WAN_MODE: _ret}
        return _OBWanSwitchAgt(self).get_res(_data)



class _OBWanSwitchAgt(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBWanSwitchAgt", _prevMenu)
    
    def _select(self, _data):
        _wan_mode = _data[_TAG_WANSW][_TAG_WAN_MODE]
        _start_txt = "Start"
        _stop_txt = "Stop"
        if _wan_mode == oc.VAL_WAN_MD_HOST :
            _stop_txt += "(Recommand)"
        else:
            _start_txt += "(Recommand)"
        _ret = bv.get_menu("Select One-Box Agent Status...", [("1", _start_txt), ("2", _stop_txt)])
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        else:
            return _ret
        
    def _next(self, _ret, _data):
        if _ret != "1" and _ret != "2" :
            logger.error("Invalid OBAgetn Status Return, status=%s ..."%str(_ret))
            bv.alert("Invalid OBAgetn Status Return, status=%s ..."%str(_ret))
            return self._RET_ERR
        
        _obaMode = (lambda x: True if x == "1" else False)(_ret)
        
        _wan = _data[_TAG_WANSW][_TAG_WAN_MODE]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        
        if not _ol.hasUtm(_ob_info.wan_mac_list()) and _wan == oc.VAL_WAN_MD_VNF :
            _conf = bv.confirm_ok("No VNF..\nConitnue?")
            if _conf == bv.RET_NO :
                return self._RET_BACK
            elif _conf == bv.RET_ERR :
                return self._RET_ERR
        
        progInfo = bv.ProgBarInfo("Start WAN-Switching...")
        bv.start_progBar(progInfo.title(), progInfo.title())
        
        try:
            _uip = _ob_info.utm_local_ip()
            _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
            _wan_mode = _ol.getWanMode(_ob_info)
            _prv_mgmt_ip = _ol.get_mgmt_ip(_has_utm, _wan_mode, _uip)
            
            _ret = _bl.wanSw_obaRun(_ob_info, _wan, _obaMode, _ob_info.utm_local_ip(), progInfo)
            
            _up = bv.UpdateProg(progInfo, 2, 1, "Update VIM-IP...")
            _up.start()
            _ol.update_vim_ip( _ob_info, _prv_mgmt_ip, 10, False)
            _up.stop()
            
            bv.stop_progBar()
            
            if _ret :
                logger.info("Succ: WAN-Switching -> %s[1:host, 2:vnf]"%str(_wan))
                return self._RET_OK
            else:
                logger.info("Fail: WAN-Switching -> %s[1:host, 2:vnf]"%str(_wan))
                return self._RET_ERR
        except Exception, e:
            logger.error()
            logger.exception(e)
            return self._RET_ERR
        






