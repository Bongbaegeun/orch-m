#-*- coding: utf-8 -*-
'''
Created on 2017. 8. 14.

@author: ohhara
'''
from time import sleep

from onebox_agent.boot.boot_ctrl import _LinkedMenu
from onebox_agent.boot import boot_constant as bc
from onebox_agent.util import ob_constant as oc
from onebox_agent.boot import boot_view as bv
from onebox_agent.data import ob_info

import logging
logger = logging.getLogger(bc._L_TITLE)


_STOP_SVC = ["onebox-agent", "onebox-vnfm", "zabbix-agent", "znmsc", "zsmsc"]


def _reset_oba(_ol, _oba_cfg_file=oc.FILE_OBA_CONF, _obinfo=None):
    '''
    return : True/False
    '''
    try:
        import ruamel.yaml
        with open(_oba_cfg_file, "r") as f:
            _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
        
        _oba_cfg['onebox_id'] = oc.VAL_DEF_OB_ID
        _oba_cfg['gVar'] = oc.VAL_DEF_GVAR
        _oba_cfg['out_of_band_mgmt'] = None
        
        _oba_cfg["vnfm_base_url"] = 'https://%s:9014/ktvnfm/v1'%oc.VAL_DEF_HOST_MGMT_IP
        _oba_port = (str(_oba_cfg["port"]) if _oba_cfg.has_key("port") else "5556")
        _oba_cfg["obagent_base_url"] = 'https://%s:%s/v1'%(oc.VAL_DEF_HOST_MGMT_IP, _oba_port)

        _hw = _ol.get_hw_info(_obinfo)
        _hw.set_hw_cfg(_oba_cfg)
        _oba_cfg['operating_system'] = _ol.get_os_info()

        if str(_ol.get_os_info()).lower().find('ubuntu 18.') > -1:
            _oba_cfg["vim_authurl"] = 'https://%s:35357/v3' % oc.VAL_DEF_HOST_MGMT_IP
        else:
            _oba_cfg["vim_authurl"] = 'https://%s:35357/v2.0' % oc.VAL_DEF_HOST_MGMT_IP

        _oba_cfg["wan_switch"] = None
        
        _oba_cfg['mgmt_nic'] = None
        _oba_cfg['mgmt_ip_dhcp'] = None
        _oba_cfg['mgmt_ip'] = None
        _oba_cfg['mgmt_subnet'] = None
        _oba_cfg['mgmt_gateway'] = None
        _oba_cfg['mgmt_dev'] = oc.VAL_DEF_HOST_MGMT_BR
        
        _oba_cfg['br_host'] = oc.VAL_DEF_HOST_MGMT_BR
        
        _oba_cfg['public_ip'] = None
        _oba_cfg['br_vm'] = oc.VAL_DEF_VNF_WAN_BR
        _oba_cfg['svc_nic'] = None
        _oba_cfg['svc_nic_mac'] = None
        
        _oba_cfg['wan_nic'] = None
        _oba_cfg['wan_ip_dhcp'] = None
        _oba_cfg['wan_ip'] = None
        _oba_cfg['wan_subnet'] = None
        _oba_cfg['wan_gateway'] = None
        
        _oba_cfg['extra_mgmt'] = []
        _oba_cfg['extra_wan'] = []

        for _lanKey in _oba_cfg.keys():
            if _lanKey.find(oc.VAL_NET_TYPE_LAN+"_") == 0 :
                _oba_cfg[_lanKey] = None
        
        if _oba_cfg.has_key(oc.CFG_VET) :
            _oba_cfg.pop(oc.CFG_VET)
        
        if _oba_cfg.has_key(oc.CFG_EXTRA_VNF_WAN) :
            _oba_cfg.pop(oc.CFG_EXTRA_VNF_WAN)
        
        if _oba_cfg.has_key(oc.CFG_PLUGIN) :
            _oba_cfg.pop(oc.CFG_PLUGIN)
        
        with open(_oba_cfg_file, 'w') as f:
            f.write(ruamel.yaml.dump(_oba_cfg, Dumper=ruamel.yaml.RoundTripDumper))
        
        return True
    except Exception, e:
        logger.error("Fail to Reset OBA-Config, exc=%s"%str(e))
        logger.exception(e)
        return False

def _reset(_ol, _bl, _ob_info):
    logger.info("Start Factory Reset")
    _ele = ['Agent Stop', 'VIM Reset', 'VM Delete', 'VNet Delete', 'Brideg Delete',
            'Host-Network Reset', 'Agent-Config Reset', 'File Delete', 'OBA-Log Delete']
    _idx = 0
    _item = _ele[_idx]
    try:
        
        _mProg = bv.MixedProgBarInfo("Factory Reset", _ele)
        bv.update_progBar(_mProg)
        sleep(0.5)
        
        ## 1. stop services
        logger.info(" - %s"%_item)
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        _res, _err = _bl.set_onebox_services(_STOP_SVC, False, _mProg)
        if not _res:
            logger.error(" - Fail to %s, err=%s"%( _item, _err ))
            bv.alert("Fail to %s\n: err=%s"%( _item, _err ))
            return False
        
        logger.info(" - SUCC: %s"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        sleep(0.5)
        
        
        ## 2. Init VIM
        # update openstack public endpoint url to 127.0.0.1
        # factory reset 후에도 nova, neutron등의 openstackl 명령을 이용하기 위함 
        _idx += 1
        _item = _ele[_idx]
        logger.info(" - %s"%_item)
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        _ret, _err = _bl.update_vim(_mProg, "127.0.0.1", _ob_info.vim_auth_user(), _ob_info.vim_auth_pass())
        if not _ret :
            logger.error(" - Fail to %s, err=%s"%( _item, _err ))
            bv.alert("Fail to %s\n: err=%s"%( _item, _err ))
            return False
        
        logger.info(" - SUCC: %s"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        sleep(0.5)
        
        
        ## 3. Delete Stack
        _idx += 1
        _item = _ele[_idx]
        logger.info(" - %s"%_item)
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        _runner = _ol.get_del_vm_runner(_ob_info.vim_tenant(), 
                                        _ob_info.vim_tenant_user(), 
                                        _ob_info.vim_tenant_pass())
        _runner.start()
        while True :
            sleep(0.5)
            if _runner.is_fin():
                break
            else:
                _prg = _runner.prog()
                _rr = min(99, int(float(_prg)/100*95))
                _mProg.set_perc(_rr)
                bv.update_progBar(_mProg)
        
        _res, _err = _runner.result()
        if not _res:
            logger.error(" - Fail to %s, err=%s"%( _item, _err ))
            bv.alert("Fail to %s\n: err=%s"%( _item, _err ))
            return False
        
        logger.info(" - SUCC: %s"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        sleep(0.5)
        
        
        ## 4. Delete Virtual Network
        _idx += 1
        _item = _ele[_idx]
        logger.info(" - %s"%_item)
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        _runner = _ol.get_del_vnet_runner(_ob_info.vim_tenant(), 
                                        _ob_info.vim_tenant_user(), 
                                        _ob_info.vim_tenant_pass())
        _runner.start()
        while True :
            sleep(0.5)
            if _runner.is_fin():
                break
            else:
                _prg = _runner.prog()
                _rr = min(99, int(float(_prg)/100*95))
                _mProg.set_perc(_rr)
                bv.update_progBar(_mProg)
        
        _res, _err = _runner.result()
        if not _res:
            logger.error(" - Fail to %s, err=%s"%( _item, _err ))
            bv.alert("Fail to %s\n: err=%s"%( _item, _err ))
            return False
        
        logger.info(" - SUCC: %s"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        sleep(0.5)
        
        
        ## 5. Clear BR
        _idx += 1
        _item = _ele[_idx]
        logger.info(" - %s"%_item)
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        # reset vim br
        _res, _err = _bl.reset_vim_br(oc.VAL_DEF_VI_WAN_BR_LIST+oc.VAL_DEF_VI_LAN_BR_LIST+oc.VAL_DEF_VI_EWAN_BR_LIST)
        if not _res:
            logger.error(" - Fail to %s, err=%s"%( _item, _err ))
            bv.alert("Fail to %s\n: err=%s"%( _item, _err ))
            return False
        logger.info("   Reset VIM Bridge")
        _mProg.set_perc(50)
        bv.update_progBar(_mProg)
        sleep(0.2)
        
        # reset os br
        _res, _err = _bl.reset_os_br()
        if not _res:
            logger.error(" - Fail to %s, err=%s"%( _item, _err ))
            bv.alert("Fail to %s\n: err=%s"%( _item, _err ))
            return False
        logger.info("   Reset OS Bridge")
        
        logger.info(" - SUCC: %s"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        sleep(0.2)
        
        
        ## 6. Host Network Reset (dhcp)
        _idx += 1
        _item = _ele[_idx]
        logger.info(" - %s"%_item)
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        # dpdk nic -> kern nic
        _nics = _ol.get_host_nic_info()
        if type(_nics) != dict :
            logger.error(" - Fail to %s, NIC-Driver Get Error"%_item)
            bv.alert("Fail to %s, NIC-Driver Reset Error"%_item)
        else:
            for _pci_id in _nics.keys() :
                _ol.init_vi_nic(_pci_id)
                
                _nic_i = _nics[_pci_id]
                _nif = _nic_i['Interface']
                _n_org_drv = _nic_i['Driver_org']
                if _nif == None and _n_org_drv != None :
                    _ret, _err = _ol.bind_host_nic(_nic_i, _n_org_drv)
                    if not _ret :
                        logger.error(" - Fail to %s, NIC Kern-Bind Error, pci=%s, drv=%s"%( _item, _pci_id, _n_org_drv ))
                        bv.alert("Fail to %s, NIC Kern-Bind Error, pci=%s, drv=%s"%( _item, _pci_id, _n_org_drv ))
                    else:
                        logger.info(" - %s, NIC Kern-Bind, pci=%s, drv=%s"%( _item, _pci_id, _n_org_drv ))
        
        # Init Host Interface
        _def_m_addr = ob_info.create_addr("main_mgmt", oc.VAL_NET_TYPE_MGMT, oc.VAL_DEF_HOST_MGMT_NIC, False, 
                           oc.VAL_DEF_HOST_MGMT_IP, oc.VAL_DEF_HOST_MGMT_MASK, None, oc.VAL_DEF_HOST_MGMT_BR)
        _ret = _bl.config_init_interfaces(_def_m_addr, _mProg, _ob_info.hw_nic_model())
        if not _ret:
            logger.error(" - Fail to %s, err=%s"%( _item, "Interface Reset Error" ))
            bv.alert("Fail to %s\n: err=%s"%( _item, "Interface Reset Error" ))
            return False
        logger.info("   Reset Interface")
        _mProg.set_perc(40)
        bv.update_progBar(_mProg)
        sleep(0.2)
        
        # Delete Default Route
        _ret = _ol.del_host_def_route()
        if not _ret:
            logger.error(" - Fail to %s, err=%s"%( _item, "Default-Route Delete Error" ))
            bv.alert("Fail to %s\n: err=%s"%( _item, "Default-Route Delete Error" ))
            return False
        logger.info("   Delete Default-Route")
        _mProg.set_perc(60)
        bv.update_progBar(_mProg)
        sleep(0.2)
        
        
        # Init Local Net
        _ret = _ol.del_host_route(oc.VAL_DEF_HOST_LOCAL_BR, oc.VAL_DEF_HOST_LOCAL_IP)
        if not _ret :
            logger.warning(" - Fail to %s, err=%s"%( _item, "Local-Route Init Error" ))
        
        _ret = _bl.config_init_local_net(oc.VAL_DEF_HOST_LOCAL_BR, oc.VAL_DEF_HOST_LOCAL_IP, oc.VAL_DEF_HOST_LOCAL_MASK)
        if not _ret :
            logger.error(" - Fail to %s, err=%s"%( _item, "Local-Net Init Error" ))
            bv.alert("Fail to %s\n: err=%s"%( _item, "Local-Net Init Error" ))
        logger.info("   Init Local-Net")
        
        logger.info(" - SUCC: %s"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        sleep(0.5)
        
        
        ## 7. Agent Config Reset
        _idx += 1
        _item = _ele[_idx]
        logger.info(" - %s"%_item)
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        # VNFM Config
        if not _bl.config_vnfm(oc.VAL_DEF_OB_ID) :
            logger.error(" - Fail to %s, err=%s"%( _item, "VNFM-Config Error" ))
            bv.alert("Fail to %s\n: err=%s"%( _item, "VNFM-Config Error" ))
            return False
        logger.info("   Reset VNFM-Config")
        _mProg.set_perc(30)
        bv.update_progBar(_mProg)
        sleep(0.2)
        
        # MON Config
        if not _bl.config_mona(oc.VAL_DEF_OB_ID) :
            logger.error(" - Fail to %s, err=%s"%( _item, "MON-Config Error" ))
            bv.alert("Fail to %s\n: err=%s"%( _item, "MON-Config Error" ))
            return False
        logger.info("   Reset MON-Config")
        _mProg.set_perc(50)
        bv.update_progBar(_mProg)
        sleep(0.2)
        
        # NMS Config
        if not _bl.reset_nmsa() :
            logger.error(" - Fail to %s, err=%s" % (_item, "NMSA-Config Error"))
            bv.alert("Fail to %s\n: err=%s" % (_item, "NMSA-Config Error"))
            return False
        logger.info("   Reset NMSA-Config")
        _mProg.set_perc(60)
        bv.update_progBar(_mProg)
        sleep(0.2)

        # SMS Config
        if not _bl.reset_smsa() :
            logger.error(" - Fail to %s, err=%s" % (_item, "SMSA-Config Error"))
            bv.alert("Fail to %s\n: err=%s" % (_item, "SMSA-Config Error"))
            return False
        logger.info("   Reset SMSA-Config")
        _mProg.set_perc(70)
        bv.update_progBar(_mProg)
        sleep(0.2)


        # OBA Config
        if not _reset_oba(_ol, _obinfo=_ob_info):
            logger.error(" - Fail to %s, err=%s" % (_item, "OBA-Config Error"))
            bv.alert("Fail to %s\n: err=%s" % (_item, "OBA-Config Error"))
            return False
        logger.info("   Reset OBA-Config")
        
        logger.info(" - SUCC: %s"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        sleep(0.2)
        
        
        ## 8. Delete Files
        _idx += 1
        _item = _ele[_idx]
        logger.info(" - %s"%_item)
        _mProg.set_index(_idx)
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        
        # Delete Log Dir
        dir_to_clear = [ "/var/log/upstart", 
                            "/var/log/nova", 
                            "/var/log/neutron", 
                            "/var/log/keystone",
                            "/var/log/apache2",
                            "/var/log/heat",
                            "/var/log/openvswitch",
                            "/var/log/glance",
                            "/var/log/rabbitmq",
                            "/var/lib/dhcp",
                            "/var/log/libvirt/qemu",
                            "/var/onebox/logs/conntrack",
                            "/var/onebox/logs/cpu-mem",
                        ]
        
        for _dir in dir_to_clear:
            files_in_dir = _ol.files_in_a_dir(_dir)
            _ret = _ol.delete_files(files_in_dir)
            if not _ret:
                logger.warning(" - Fail to Delete Log Dir, dir=%s"%str(_dir))
            _mProg.inc(1)
            bv.update_progBar(_mProg)
        logger.info("  Delete Log Dir")
        
        # Delete Old Log
        file_ext_to_clear = [ ".0", ".1", ".gz"]
        for ext in file_ext_to_clear:
            files = _ol.files_with_an_extension("/var/log", ext)
            _ret = _ol.delete_files(files)
            if not _ret:
                logger.warning(" - Fail to Delete Old Log Files, files=%s"%str(files))
            _mProg.inc(1)
            bv.update_progBar(_mProg)
        logger.info("  Delete Old Log Files")
        
        # Delete Sys Log
        files_to_clear = [ "/var/log/syslog",
                            "/var/log/auth.log"
                            ]
        # _ret = _ol.delete_files(files_to_clear)
        _ret = _ol.truncate_files(files_to_clear)
        if not _ret:
            logger.warning(" - Fail to Delete Sys Log Files, files=%s"%str(files_to_clear))
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        logger.info("  Delete Sys Log Files")
        
        # Delete Mon Files
        delete_mon_locations = ["/etc/zabbix/zabbix_agentd.conf.d",
                                "/var/log/zabbix-agent"
                                ]
        for loc in delete_mon_locations :
            _ret = _ol.delete_file_recursively(loc)
            if not _ret:
                logger.warning(" - Fail to Mon Files, file=%s"%str(loc))
            _mProg.inc(1)
            bv.update_progBar(_mProg)
        logger.info("  Delete Mon Files")
        
        # Delete Mon-Plugin Files
        delete_plugin_loc = "/usr/plugin"
        _ret = _ol.delete_all_recursively(delete_plugin_loc)
        if not _ret:
            logger.warning(" - Fail to Mon-Plugin Dir, Dir=%s"%str(delete_plugin_loc))
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        logger.info("  Delete Mon-Plugin Dir")
        
        # Delete Backup Files
        backup_dir = "/var/onebox/backup"
        _ret = _ol.delete_all_recursively(backup_dir)
        if not _ret:
            logger.warning(" - Fail to Backup Dir, Dir=%s"%str(backup_dir))
        _mProg.inc(1)
        bv.update_progBar(_mProg)
        logger.info("  Delete Backup Dir")
        
        # Delete OBA Dir
        import os
        for _dir in (oc.DIR_TMP, oc.DIR_STAT_DIR) :
            try:
                if os.path.isdir(_dir):
                    _ol.delete_all_recursively(_dir)
                    _mProg.inc(1)
                    bv.update_progBar(_mProg)
                    logger.info("  Delete OBA Dir, dir=%s"%str(_dir))
            except Exception, e:
                logger.warning(" - Fail to Delete OBA Dir, dir=%s"%str(_dir))
        
        logger.info(" - SUCC: %s"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        sleep(0.5)
        
        
        ## 9. Delete OBA Log
        _idx += 1
        _item = _ele[_idx]
        logger.info(" - %s"%_item)
        _mProg.set_index(_idx)
        _mProg.inc(5)
        bv.update_progBar(_mProg)
        
        dir_to_clear = [ "/var/log/onebox" ]
        for _dir in dir_to_clear:
            files_in_dir = _ol.files_in_a_dir(_dir)
            _ret = _ol.delete_files(files_in_dir)
            if not _ret:
                logger.warning(" - Fail to %s, files=%s"%str(files_in_dir))
        
        logger.info(" - SUCC: %s"%_item)
        _mProg.set_perc(100)
        bv.update_progBar(_mProg)
        
        _mProg.fin()
        bv.update_progBar(_mProg)
        sleep(0.5)
        
        logger.info("Complete Factory Reset")
        return True
    except Exception, e:
        logger.error("Fail to %s, exc=%s"%( _item, str(e) ))
        logger.exception(e)
        bv.alert("Fail to %s, exc=%s"%( _item, str(e) ))
        return False



class FactoryReset(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "FactoryReset", None)
    
    def _select(self, _data):
        _data[bc.FUNC_TITLE] = "Factory Reset"
        _txt = "Reset One-Box?"
        _ret = bv.confirm_ok(_txt)
        if _ret == bv.RET_NO :
            return self._RET_BACK
        elif _ret == bv.RET_ERR :
            return self._RET_ERR
        else:
            return _ret
    
    def _next(self, _ret, _data):
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        if _reset(_ol, _bl, _ob_info) :
            return self._RET_OK
        else:
            return self._RET_ERR
    












