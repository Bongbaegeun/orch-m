#-*- coding: utf-8 -*-
'''
Created on 2017. 8. 25.

@author: ohhara
'''

from time import sleep
from ipaddr import IPv4Network

from onebox_agent.boot.boot_ctrl import _LinkedMenu
from onebox_agent.boot import boot_constant as bc
from onebox_agent.util import ob_constant as oc
from onebox_agent.boot import boot_view as bv
from onebox_agent.data import ob_info
from onebox_agent.util import rest_api
from onebox_agent.util import onebox_manager
from onebox_agent.data.ob_info import OB_NET


import logging
logger = logging.getLogger(bc._L_TITLE)
onebox_manager.logger = logger


_TAG_MAC_INFO = "__tag_mac_info__"
_TAG_OBID = "__tag_ob_id__"
_TAG_MGMT_NET = "__tag_mgmt_net__"
_TAG_BACK_OB_INFO = "__tag_back_ob_info__"
_TAG_BACK_INFO = "__tag_back_info__"


_FIELD_LEN = 50
_KEY_OBID = "One-Box ID"
_KEY_MGMT = "Management"
_KEY_INF = "Interface"
_KEY_IP_TYPE = "IP Type"
_KEY_ADDR = "Address"
_KEY_MASK = "Netmask"
_KEY_GW = "Gateway"
_VAL_DHCP = "DHCP"
_VAL_STATIC = "STATIC"

_URL_BINFO = "%s/server/%s/backup"%( oc.URL_ORCHF_BASE("%s", "%d"), "%s" )
_URL_RECOVERY = "%s/server/%s/action"%( oc.URL_ORCHF_BASE("%s", "%d"), "%s" )
_URL_PROG = "%s/server/%s/progress"%( oc.URL_ORCHF_BASE("%s", "%d"), "%s" )


def _chk_ob_info(_ob_key_value):
    _key = _KEY_OBID
    _val = _ob_key_value[_key]
    try:
        ## OB ID
        if _val == None or str(_val).strip() == "" :
            return False, _key, _val, 'Null OB-ID'
        
        ## MGMT
        _key = _KEY_MGMT+"."+_KEY_INF
        _val = _ob_key_value[_key]
        if _val == None or str(_val).strip() == "" :
            return False, _key, _val, "Null Interface"
        
        _key = _KEY_MGMT+"."+_KEY_IP_TYPE
        _keyTP = _key
        _valTP = _ob_key_value[_keyTP]
        _key = _KEY_MGMT+"."+_KEY_ADDR
        _keyAd = _key
        _valAd = _ob_key_value[_keyAd]
        _key = _KEY_MGMT+"."+_KEY_MASK
        _keyMS = _key
        _valMS = _ob_key_value[_keyMS]
        _key = _KEY_MGMT+"."+_KEY_GW
        _keyGW = _key
        _valGW = _ob_key_value[_keyGW]
        # dhcp
        if str(_valTP).upper() == _VAL_DHCP :
            pass
        elif str(_valTP).upper() == _VAL_STATIC :
            # ip
            try:
                IPv4Network(_valAd)
            except Exception :
                return False, _keyAd, _valAd, "Invalid IP-Address"
            # mask
            try:
                IPv4Network(_valAd+"/"+str(_valMS))
            except Exception :
                return False, _keyMS, _valMS, "Invalid Netmask"
            # gw
            try:
                _ret = IPv4Network(_valAd+"/"+str(_valMS)).compare_networks(IPv4Network(_valGW+"/"+str(_valMS)))
                if _ret != 0 :
                    return False, _keyGW, _valGW, "Invalid Gateway Subnet"
            except Exception :
                return False, _keyGW, _valGW, "Invalid Gateway Address"
        else:
            return False, _keyTP, _valTP, "Invalid IP-TYPE"
        
        return True, None, None, None
    except KeyError, e:
        logger.error("Fail to Chk Mgmt-IP Info, No Field, field=%s"%( str(_key) ))
        logger.exception(e)
        return False, _key, None, "No Field"
    except Exception, e:
        logger.error("Fail to Chk Mgmt-IP Info, exc=%s"%( str(e) ))
        logger.exception(e)
        return False, _key, _val, str(e)

def _set_recovery_info(_ob_key_value, _mdata):
    _key = ""
    try:
        ## OB-ID
        _key = _KEY_OBID
        _ob_id = _ob_key_value[_key]
        
        ## MGMT
        # nic
        _key = _KEY_MGMT+"."+_KEY_INF
        _nic = _ob_key_value[_key]
        # dhcp
        _key = _KEY_MGMT+"."+_KEY_IP_TYPE
        _ip_type = _ob_key_value[_key]
        _is_dhcp = (lambda x: True if str(x).upper() == _VAL_DHCP else False)(_ip_type)
        
        # ip
        _key = _KEY_MGMT+"."+_KEY_ADDR
        _addr = (lambda x: None if str(x).strip() == "" else x)(_ob_key_value[_key])
        
        # mask
        _key = _KEY_MGMT+"."+_KEY_MASK
        _mask = (lambda x: None if str(x).strip() == "" else x)(_ob_key_value[_key])
        
        # gw
        _key = _KEY_MGMT+"."+_KEY_GW
        _gw = (lambda x: None if str(x).strip() == "" else x)(_ob_key_value[_key])
        
        if _is_dhcp :
            _addr = None
            _mask = None
            _gw = None
        
        _oaddr = ob_info.create_addr("mgmt-main", oc.VAL_NET_TYPE_MGMT, _nic, _is_dhcp, 
                                  _addr, _mask, _gw, oc.VAL_DEF_OS_BR_LIST[0], _mdata[_TAG_MAC_INFO][_nic])
        
        _mdata[_TAG_OBID] = _ob_id
        _mdata[_TAG_MGMT_NET] = _oaddr
        return True, None
    except KeyError, e:
        logger.error("Fail to Set OB-Mgmt-Info, No Field, field=%s"%( str(_key) ))
        logger.exception(e)
        return False, "No Field, field=%s"%str(_key)
    except Exception, e:
        logger.error("Fail to Set OB-Mgmt-Info, exc=%s"%str(e))
        logger.exception(e)
        return False, str(e)

def _edit_external_net_info(_edit_idx, _data_pos, elements, network, item_pos = -1, title = ""):
    nic = ','.join(network.nics())
    ip_dhcp = network.is_dhcp()
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_INF
    itm_nic = (_key, item_pos, 1, nic, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_nic)
    _edit_idx[_key] = _data_pos
    
    if ip_dhcp:
        str_ip_type = _VAL_DHCP
        ip_addr = ""
        ip_subnet = ""
        ip_gateway = ""
    else:
        str_ip_type = _VAL_STATIC
        ip_addr = network.ip()
        ip_subnet = network.mask()
        ip_gateway = network.gw()
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_IP_TYPE
    itm_ip_type = (_key, item_pos, 1, str_ip_type, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_ip_type)
    _edit_idx[_key] = _data_pos
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_ADDR
    itm_ip_addr = (_key, item_pos, 1, ip_addr, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_ip_addr)
    _edit_idx[_key] = _data_pos
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_MASK
    itm_ip_subnet = (_key, item_pos, 1, ip_subnet, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_ip_subnet)
    _edit_idx[_key] = _data_pos
    
    item_pos = item_pos + 1
    _data_pos += 1
    _key = title+"."+_KEY_GW
    itm_ip_gateway = (_key, item_pos, 1, ip_gateway, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
    elements.append(itm_ip_gateway)
    _edit_idx[_key] = _data_pos
        
    return item_pos, _data_pos

def _edit_recovery_info(_mdata):
    try:
        while True :
            _edit_idx = {}
            elements = []
            item_pos = 1
            _data_pos = 0
            
            # onebox_id
            onebox_id = _mdata[_TAG_OBID]
            itm_onebox_id = (_KEY_OBID, item_pos, 1, onebox_id, item_pos, 25, _FIELD_LEN, _FIELD_LEN, bv.FORM_ATTR_EDITABLE)
            elements.append(itm_onebox_id)
            _edit_idx[_KEY_OBID] = _data_pos
            
            # mgmt
            mnet = _mdata[_TAG_MGMT_NET]
            item_pos, _data_pos = _edit_external_net_info(_edit_idx, _data_pos, elements, mnet, item_pos = item_pos, title=_KEY_MGMT)
            
            _ret = bv.show_mixform("Edit One-Box Mgmt-Net Info", elements)
            if _ret == bv.RET_NO :
                return True
            elif _ret == bv.RET_ERR :
                return False
            else:
                _ob_key_value = {}
                for _iii in range(len(elements)) :
                    for _key in _edit_idx.keys() :
                        if _edit_idx[_key] == _iii :
                            _ob_key_value[_key] = (lambda x: None if x == None else str(x))(_ret[_iii])
                            logger.debug("Edit: %2s-%-22s : %s"%( _iii, _key, _ret[_iii] ))
                            break
                
                _ret, _key, _val, _err = _chk_ob_info(_ob_key_value)
                if _ret :
                    _ret, _err = _set_recovery_info(_ob_key_value, _mdata)
                    if _ret :
                        return True
                    else:
                        logger.warning("Fail to Set OB-Mgmt-INFO, err=%s"%_err)
                        bv.alert("Fail to Set OB-INFO, err=%s"%_err)
                else:
                    logger.warning("Fail to Chk OB-Mgmt-INFO, CHK Error, key=%s, val=%s, err=%s"%( _key, _val, _err ))
                    bv.alert("Invalid One-Box Config, field=%s, value=%s, error=%s"%( _key, _val, _err ))
                
                continue

    except Exception, e:
        logger.error("Fail to Edit OB_Mgmt_Info, exc=%s"%str(e))
        logger.exception(e)
        bv.alert("Fail to Edit OB_Mgmt_Info, exc=%s"%str(e))
        return False



def _mgmt_install(_ol, _bl, _mnet, _prog):
    try:
        _prog.set_perc(5)
        bv.update_progBar(_prog, "VI-Net Clear")
        
        _ret, _err = _bl.reset_vim_br(oc.VAL_DEF_VI_WAN_BR_LIST)
        if not _ret :
            logger.error(" - Fail to Install Mgmt-IP, VI-Net Reset Error, err=%s"%_err)
            bv.alert("Fail to Install Mgmt-IP, VI-Net Reset Error\n : err=%s"%_err)
            return False
        logger.info("   Reset VI-Net")
        
        _prog.set_perc(50)
        bv.update_progBar(_prog, "Mgmt-IP Setting")
        sleep(0.5)
        _ret, _err = _ol.config_mgmt_net([_mnet], _prog, bv)
        if not _ret :
            logger.error(" - Fail to Install Mgmt-IP, IP Setting Error, err=%s"%_err)
            bv.alert("Fail to Install Mgmt-IP, IP Setting Error\n : err=%s"%_err)
            return False
        logger.info("   Set Mgmt-IP")
        
        logger.info(" - SUCC: Install Mgmt-IP")
        _prog.set_perc(100)
        bv.update_progBar(_prog, "Mgmt-IP Install, OK!!!")
        sleep(0.5)
        return True
    except Exception, e:
        logger.error(" - Fail to Install Mgmt-IP, Unknown Error, err=%s"%str(e))
        logger.exception(e)
        bv.alert("Fail to Install Mgmt-IP, Unknown Error\n : err=%s"%str(e))
        return False

def _callBackupInfo(_ol, _orchIP, _orchPort, _ob_id, _data):
    try:
        _url = _URL_BINFO%( _orchIP, _orchPort, _ob_id )
        
        _retry_max = 3
        _retry_cnt = 0
        
        _ele = []
        for _ii in range(_retry_max) :
            _ele.append("Retry %s/%s"%( str(_ii+1), str(_retry_max) ))
        _mProg = bv.MixedProgBarInfo("Call Backup Info...", _ele)
        
        _body = None
        while _retry_cnt < _retry_max :
            _mProg.set_index(_retry_cnt)
            _mProg.set_perc(5)
            bv.update_progBar(_mProg)
            
            _ret, _ecode, _body = rest_api.sendReq(oc.HEADER, _url, "GET", _to=15)
            _mProg.set_perc(90)
            bv.update_progBar(_mProg)
            if _ret == True :
                if type(_body) == dict :
                    # create _b_ob_info
                    _data[_TAG_BACK_INFO] = _body
                    _ret = _restore_oba_cfg_from_backup(_ol, _data[_TAG_BACK_INFO])
                    if not _ret :
                        return False, None
                    
                    import ruamel.yaml
                    with open(oc.FILE_OBA_CONF, "r") as f:
                        _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
                    _restore_ob_info = ob_info.OB_INFO().loadByCfg(_oba_cfg, True)

                    # update hw, os, plugin, vim_ver in this new onebox
                    _restore_ob_info.m_os = _ol.get_os_info()
                    _restore_ob_info.m_hw = _ol.get_hw_info(_restore_ob_info)
                    _restore_ob_info.set_vim_version()
                    _restore_ob_info.set_plugin_os()

                    _ret, _info = _ol.convert_backinfo_to_obinfo(_body['backup_data'], _restore_ob_info)
                    logger.debug(" - Get BackupInfo, ret=%s, convt=%s"%( str(_body), str(_info) ))
                    if _ret == True :
                        return True, _info
                    else:
                        logger.error("Fail to Call BackupAPI, Return Convert Error, err=%s"%str(_info))
                        bv.alert("Fail to Call BackupAPI, Return Convert Error\n : err=%s"%str(_info))
                        return False, None
                else:
                    logger.error("Fail to Call BackupAPI, Invalid Return, url=%s, return=%s"%(_url, str(_body)))
                    bv.alert("Fail to Call BackupAPI, Invalid Return\n : return=%s"%str(_body))
                    return False, None
            else:
                logger.warning("Fail to Call BackupAPI, Call Error, url=%s, err=%s"%(_url, str(_body)))
            
            _mProg.set_perc(bv.G_STATUS_FAIL)
            bv.update_progBar(_mProg)
            
            _retry_cnt += 1
            sleep(1)
        
        logger.error("Fail to Call BackupAPI, Call Error, err=%s"%str(_body))
        bv.alert("Fail to Call BackupAPI\n : Call Error, err=%s"%str(_body))
        return False, None
    except Exception, e :
        logger.error("Fail to Call BackupAPI, Unknown Error, exc=%s"%str(e))
        logger.exception(e)
        bv.alert("Fail to Call BackupAPI, Unknown Error\n : exc=%s"%str(e))
        return False, None

def _restore_oba_cfg_from_backup(_ol, _back_info):
    try:
        import os, shutil
        local_location = str(_back_info['local_location'])
        remote_location = str(_back_info['remote_location'])
        backup_server_ip = str(_back_info['backup_server_ip'])
        backup_server_port = str(_back_info['backup_server_port'])
        
        if not os.path.exists(local_location) :
            _ret = _ol.scp_get(backup_server_ip, backup_server_port, remote_location, local_location)
            if not _ret :
                logger.error("Fail to Restore OBA-CFG, Remote Backup Files Get Error, ip=%s, port=%s, remote=%s, local=%s"%(
                            backup_server_ip, backup_server_port, remote_location, local_location))
                bv.alert("Fail to Restore OBA-CFG, Remote Backup Files Get Error")
                return False
        
        _extract_root="/tmp/restore-in-bootagent"
        if os.path.exists(_extract_root): 
            shutil.rmtree(_extract_root)
        
        if not _ol.untar(local_location, _extract_root) :
            logger.error("Fail to Restore OBA-CFG, Backup File Extract Error, file=%s, dst_dir=%s"%( local_location, _extract_root ))
            bv.alert("Fail to Restore OBA-CFG, Backup File Extract Error")
            return False
        
        _ret = _ol.restore_service(_extract_root, [oc.FILE_OBA_CONF], [oc.VAL_OBA_NAME], restart=False)
        _ol.correct_mac()
        if not _ret :
            logger.error("Fail to Restore OBA-CFG, OBA-CFG Restore Error")
            bv.alert("Fail to Restore OBA-CFG, OBA-CFG Restore Error")
            return False
        
#         # config onebox-agent
#         if not _ob_info.saveToCfg() :
#             logger.error("Fail to Restore OBA, OBA Config Error")
#             bv.alert("Fail to Restore OBA, OBA Config Error")
#             return False
        
#         _bl.set_onebox_services([oc.VAL_OBA_NAME], False)
#         _ret = _bl.set_onebox_services([oc.VAL_OBA_NAME], True)
#         if not _ret :
#             _ret = bv.confirm_ok("Fail to Restart OneBox-Agent.\nContinue?")
#             if _ret == bv.RET_OK :
#                 logger.warning("Fail to Restore OBA, OBA Svc Restart Error")
#             else:
#                 logger.error("Fail to Restore OBA, OBA Svc Restart Error")
#                 bv.alert("Fail to Restore OBA, OBA Svc Restart Error")
#                 return False
        
        logger.info("SUCC: Restore OBA-CFG")
        return True
    except Exception, e:
        logger.error("Fail to Restore OBA-CFG, Unknown Error, exc=%s"%str(e))
        logger.exception(e)
        bv.alert("Fail to Restore OBA-CFG, Unknown Error, exc=%s"%str(e))
        return False


# def _restore_onebox_agent_from_backup(_ol, _bl, _back_info, _ob_info):
#     from onebox_agent.util import ob_worker
#     try:
#         local_location = str(_back_info['local_location'])
#         remote_location = str(_back_info['remote_location'])
#         backup_server_ip = str(_back_info['backup_server_ip'])
#         backup_server_port = str(_back_info['backup_server_port'])
#         
#         
#         _rwrk = ob_worker.ObWork_Recovery(_ol, logger, local_location, "/tmp/restore-in-bootagent", 
#                                           backup_server_ip, backup_server_port, remote_location, True)
#         
#         _mProc = bv.MixedProgBarInfo("Restore OB", _rwrk.item_list())
#         bv.update_progBar(_mProc)
#         
#         _rwrk.start()
#         while True :
#             _res, _items, _progs = _rwrk.get_info()
#             _idx = 0
#             for _item in _items :
#                 _mProc.set_item(_item, _progs[_idx])
#                 _idx += 1
#             bv.update_progBar(_mProc)
#             
#             if _res != _rwrk.STAT_RUN :
#                 break
#             
#             sleep(2)
#         
#         _res, _ret, _err = _rwrk.result()
#         _item = _rwrk.item()
#         if _res != _rwrk.STAT_COMP :
#             bv.alert("Fail to Restore OBA, %s Error, err=%s"%( str(_item), str(_err) ))
#             return False
#         else:
#             logger.info("SUCC: Restore OBA")
#             return True
#         
#     except Exception, e:
#         logger.error("Fail to Restore OBA, Unknown Error, exc=%s"%str(e))
#         logger.exception(e)
#         bv.alert("Fail to Restore OBA, Unknown Error, exc=%s"%str(e))
#         return False


def _do_onebox_recover(_orch_ip, _orch_port, _ob_id, _mgmt_ip, _wan_mac):
    try:
        _prog = bv.ProgBarInfo("Start One-Box Recovery...")
        bv.start_progBar(_prog.title(), _prog.title())
        
        _prog.set_perc(5)
        bv.update_progBar(_prog, "Request One-Box Recover to Orchestrator...")
        
        _url = _URL_RECOVERY%( _orch_ip, _orch_port, _ob_id )
        
        # MEMO: One-Box 구성에서는 in-band나 out-of-band 모두에 br-internet을 이용하므로 mgmt_nic은 br-internet으로 고정
        ## Not Used
        # public_ip, public_gw_ip, public_ip_dhcp, public_cidr_prefix
        # backup_id, force_restore
        _recovery_info = {'requester': "BOOTAGT", "mgmt_ip": _mgmt_ip, "wan_mac": _wan_mac}
        _body = {'tid': "", 'tpath': "", 'requester': "BOOTAGT", 
                 'restore': _recovery_info}
        
        for _ii in range(10) :
            sleep(1)
            _prog.inc(1)
            
        _ret, _ecode, _res = rest_api.sendReq(oc.HEADER, _url, "POST", _body, _to=30)
        if not _ret :
            logger.error("Fail to Call Recovery-API, url=%s, body=%s, res=%s"%( _url, str(_body), str(_res) ))
            bv.alert("Fail to Call Recovery-API")
            return False
        
        logger.info(" - Call Recovery API, res=%s"%str(_res))
        _prog.set_perc(20)
        bv.update_progBar(_prog, "Request One-Box Recover to Orchestrator: OK!!!")
        sleep(0.5)
        
        _url = _URL_PROG%( _orch_ip, _orch_port, _ob_id )
        while True :
            _prog.inc(1)
            bv.update_progBar(_prog, "Working on One-Box Recovery...")
            sleep(15)
            try:
                _ret, _ecode, _res = rest_api.sendReq(oc.HEADER, _url, "GET")
                if not _ecode in (0, 200, 400, 500, 599) and not _ret :
                    logger.error("Fail to Call RecoveryProgress-API, HTTP Error, url=%s, err=%s"%( _url, str(_res) ))
                    bv.stop_progBar()
                    bv.alert("Fail to Call RecoveryProgress-API, HTTP Error, err=%s"%(str(_res)))
                    return False
                elif type(_res) == dict and _res.has_key('status') :
                    if str(_res['status']).strip().upper() == 'ERROR' :
                        logger.error("Fail to Recovery OneBox, res=%s"%str(_res))
                        bv.stop_progBar()
                        bv.alert("Fail to Recovery OneBox")
                        return False
                    elif str(_res['status']).strip().upper() == 'DONE':
                        logger.debug(" - SUCC: Recover Prog Chk, res=%s"%str(_res))
                        break
                
                logger.info(" - Doing Recovery OneBox, res=%s"%str(_res))
            except Exception, e:
                logger.error("Fail to Call RecoveryProgress-API, url=%s, exc=%s"%( _url, str(e) ))
                bv.stop_progBar()
                bv.alert("Fail to Recovery OneBox, exc=%s"%str(e))
                return False
        
        logger.info("SUCC: Recovery OneBox")
        _prog.set_perc(100)
        bv.update_progBar(_prog, "One-Box Recovery Complete!!!")
        bv.stop_progBar()
        sleep(0.5)
        
        return True
    except Exception, e:
        logger.error("Fail to Recovery OneBox, Unknown Error, exc=%s"%str(e))
        logger.exception(e)
        bv.stop_progBar()
        bv.alert("Fail to Recovery OneBox, Unknown Error, exc=%s"%str(e))
        return False







class OBRecovery(_LinkedMenu):
    
    def __init__(self, _prevMenu=None):
        _LinkedMenu.__init__(self, "OBRecovery", _prevMenu)
    
    def _select(self, _data):
        _ol = _data[oc.OTAG_LIB_OB]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        if _ol.hasUtm(_ob_info.wan_mac_list()) :
            bv.alert("VNF Already Exist.\nRetry after Factory-Reset")
            return self._RET_BACK
        
        _mac_info = _ol.get_host_mac(_nic_model=_ob_info.hw_nic_model())
        if _mac_info == None or len(_mac_info) < 1 :
            logger.error("No Mac Info")
            bv.alert("No Mac Info")
            return self._RET_ERR
        
        _data[_TAG_MAC_INFO] = _mac_info
        
        _init = (lambda x: x[_TAG_OBID] if x.has_key(_TAG_OBID) else '')(_data)
        while True :
            _ret, _ob_id = bv.input_text("Input One-Box ID", _init)
            if _ret == bv.RET_NO :
                return self._RET_BACK
            elif _ret == bv.RET_ERR :
                return self._RET_ERR
            else:
                if _ob_id == None or str(_ob_id).strip() == "" :
                    logger.warning("Fail to Get OB ID, id=%s"%str(_ob_id))
                    bv.alert("Invalid OB ID, id=%s\nRetry."%str(_ob_id))
                    continue
                _data[_TAG_OBID] = str(_ob_id).strip()
                return self._RET_OK
    
    def _next(self, _ret, _data):
        if self._PREV_CLS.__class__ == _OBMgmtReview :
            return self._PREV_CLS.get_res(_data)
        
        return _OBMgmtConfig(self).get_res(_data)


class _OBMgmtConfig(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBMgmtConfig", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _selected_nics = []
        _maddr = None
        try:
            while True:
                ## select nic
                _ret, _mnic, _mmac, _mconn, _remain = _bl.get_host_nic("Management Interface Select", _selected_nics, _conn_filter=True, _nic_model=_ob_info.hw_nic_model())
                if _ret == self._RET_BACK :
                    return self._RET_BACK
                # no connected nic
                elif _remain == -1 :
                    bv.alert("No Active Interface.\nRetry After Connect Cable to Interface.")
                    continue
                # select Inactive nic
                elif _mconn != True :
                    bv.alert("Inactive Interface Selected.\nRe-Select Active Interface.")
                    continue
                # None Nic
                elif _mnic == None or str(_mnic).strip() == "" :
                    bv.alert("Interface Name is Null.\nRetry.")
                    continue
                # error
                elif _ret == self._RET_ERR :
                    return self._RET_ERR
                
                
                ## config network
                if _data.has_key(_TAG_MGMT_NET) and _data[_TAG_MGMT_NET] != None :
                    # overwrite ip info...
                    _prvnet = _data[_TAG_MGMT_NET]
                    _maddr = ob_info.create_addr("mgmt_main", oc.VAL_NET_TYPE_MGMT, _mnic, _prvnet.is_dhcp(), 
                                               _ip=_prvnet.ip(), _mask=_prvnet.mask(), _gw=_prvnet.gw(), 
                                               _dev=oc.VAL_DEF_OS_BR_LIST[0], _mac=_mmac, _vlan=_prvnet.vlan())
                else:
                    _maddr = ob_info.create_addr("mgmt_main", oc.VAL_NET_TYPE_MGMT, _mnic, None, 
                                               _dev=oc.VAL_DEF_OS_BR_LIST[0], _mac=_mmac)
                
                _ret = _bl.set_extern_ip("Management IP Config", _maddr)
                if _ret == self._RET_OK :
                    break
                elif _ret == self._RET_BACK :
                    continue
                else :
                    return self._RET_ERR
            
            _data[_TAG_MGMT_NET] = _maddr
            
            logger.info("  - Selected Mgmt: %s"%str(_maddr))
            return self._RET_OK
        except Exception, e:
            logger.error("Fail to Config MainMgmt, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Config MainMgmt, exc=%s"%str(e))
            return self._RET_ERR
    
    def _next(self, _ret, _data):
        if self._PREV_CLS.__class__ == _OBMgmtReview :
            return self._PREV_CLS.get_res(_data)
        
        return _OBMgmtReview(self).get_res(_data)


class _OBMgmtReview(_LinkedMenu):
    
    def __init__(self, _prevMenu):
        _LinkedMenu.__init__(self, "OBMgmtReview", _prevMenu)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        
        while True:
            if _bl.show_main_mgmt(_data[_TAG_OBID], _data[_TAG_MGMT_NET]) :
                if bv.confirm_ok("Apply Management IP Configuration?") == bv.RET_OK :
                    return self._RET_OK
                else:
                    continue
            
            _ret = bv.get_menu("Select Point to Go Back ", [("1", "One-Box ID"), 
                                                            ("2", "Mgmt IP Config"),
                                                            ("0", "Edit Directly")])
            if _ret == bv.RET_NO :
                continue
            elif _ret == bv.RET_ERR :
                return self._RET_ERR
            else:
                if _ret == "1" : return OBRecovery(self).get_res(_data)
                elif _ret == "2" : return _OBMgmtConfig(self).get_res(_data)
                elif _ret == "0" : 
                    if _edit_recovery_info(_data) :
                        continue
                    else:
                        return self._RET_ERR
                else:
                    return self._RET_ERR
    
    def _next(self, _ret, _data):
        return _OBMgmtInstall().get_res(_data)


class _OBMgmtInstall(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "OBMgmtInstall", None)
    
    def _select(self, _data):
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        _prog = bv.ProgBarInfo("Start Mgmt-Net Install...")
        bv.start_progBar(_prog.title(), _prog.title())
        
        _ret = _mgmt_install(_ol, _bl, _data[_TAG_MGMT_NET], _prog)
        bv.stop_progBar()
        if _ret == True:
            return self._RET_OK
        else:
            return self._RET_ERR
    
    def _next(self, _ret, _data):
        return _OBBackupInfoCall().get_res(_data)


class _OBBackupInfoCall(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "OBBackupInfoCall", None)
    
    def _select(self, _data):
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        _orchIP = _ob_info.c_orchf_svr.ip()
        _orchPort = _ob_info.c_orchf_svr.port()
        
        _ret, _b_ob_info = _callBackupInfo(_ol, _orchIP, _orchPort, _data[_TAG_OBID], _data)

        if _ret == False:
            return self._RET_ERR
        
        while True :
            if _bl.show_obinfo(_b_ob_info) :
                if bv.confirm_ok("Apply Configuration?") == bv.RET_OK :
                    _data[_TAG_BACK_OB_INFO] = _b_ob_info
                    return self._RET_OK
            
            if bv.confirm_ok("Stop Recovery?") == bv.RET_OK :
                return self._RET_ERR
    
    def _next(self, _ret, _data):
        return _OBFirstInstall().get_res(_data)


class _OBFirstInstall(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "OBFirstInstall", None)
    
    def _select(self, _data):
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_info = _data[oc.OTAG_OBA_INFO]
        
        _tenant = _ob_info.vim_tenant()
        _tUser = _ob_info.vim_tenant_user()
        _tPass = _ob_info.vim_tenant_pass()
        _ret = _bl.apply_config(_data[_TAG_BACK_OB_INFO], _tenant, _tUser, _tPass)
        if not _ret :
            return self._RET_ERR
        else:
            return self._RET_OK
    
    def _next(self, _ret, _data):
        return _OBRecoveryRun().get_res(_data)


class _OBRecoveryRun(_LinkedMenu):
    
    def __init__(self):
        _LinkedMenu.__init__(self, "OBRecoveryRun", None)
    
    def _select(self, _data):
        _ol = _data[oc.OTAG_LIB_OB]
        _bl = _data[oc.OTAG_LIB_BTA]
        _ob_r_info = _data[_TAG_BACK_OB_INFO]
        
        
        _prog = bv.ProgBarInfo("Waiting for OneBox-Agent On...")
        bv.start_progBar(_prog.title(), _prog.title())
        _url = "https://localhost:%s/v1/onebox_info"%str(_ob_r_info.oba_port())
        _on_oba = False
        while True:
            _ret, _ecode, _res = rest_api.sendReq(oc.HEADER, _url, "GET", cCrt=oc.KEY_CLI_CRT, cKey=oc.KEY_CLI_KEY, _to=20)
            if _ret :
                _prog.set_perc(100)
                bv.update_progBar(_prog)
                sleep(1)
                break
            
            logger.warning("  Fail to Check OBA-API, url=%s, ret=%s, ecode=%s, res=%s"%( _url, str(_ret), str(_ecode), str(_res) ))
            _prog.inc(2)
            bv.update_progBar(_prog)
            sleep(5)
        bv.stop_progBar()
        
        _ret = bv.confirm_ok("Request Recovery to Orchestrator?")
        if _ret == bv.RET_ERR :
            return self._RET_ERR
        elif _ret == bv.RET_OK :
            _set_pip = False
            _prog = bv.ProgBarInfo("Setting Management IP by OneBox-Agent...")
            bv.start_progBar(_prog.title(), _prog.title())
            
            _retry = 20
            for _i in range(_retry) :
                _prog.set_perc(100/_retry*(_i+1))
                bv.update_progBar(_prog)
                sleep(3)
                try:
                    _net_state_json = onebox_manager.NetStateManager().get_state()
                    if _net_state_json.has_key("status") :
                        continue
                except Exception, e:
                    logger.warning("  Fail to Get Network Status, err=%s"%str(e))
                    logger.exception(e)
                    continue
                _net_state_info = OB_NET().load(_net_state_json)
                _ob_noti = _ol.to_obinfo_for_orchf(_net_state_info, _ob_r_info)
                if _ob_noti.has_key('public_ip') and _ob_noti['public_ip'] != None and str(_ob_noti['public_ip']).strip() != "" :
                    _set_pip = True
                    logger.error("  SUCC: Set Management IP by Onebox-Agent, ip=%s"%str(_ob_noti['public_ip']))
                    break
            bv.stop_progBar()
            
            if not _set_pip :
                logger.error("Fail to Set Host Main IP by OBA")
                bv.alert("Not Set Management IP by Onebox-Agent")
                return self._RET_ERR
            
            _ob_info = _data[oc.OTAG_OBA_INFO]
            _orch_ip = _ob_info.c_orchf_svr.ip()
            _orch_port = _ob_info.c_orchf_svr.port()
            _ob_id = _data[_TAG_OBID]
            _mgmt_ip = _ol.get_host_main_ip()[1]
            if _mgmt_ip == None :
                logger.error("Fail to Get Host Main IP, NO IP Info")
                bv.alert("No Management IP-Info")
                return self._RET_ERR
            _wan_mac = _ob_r_info.m_wan_list[0].mac()
            _ret = _do_onebox_recover(_orch_ip, _orch_port, _ob_id, _mgmt_ip, _wan_mac)
            if not _ret :
                return self._RET_ERR
        
        return self._RET_OK
    
    def _next(self, _ret, _data):
        return self._RET_OK







