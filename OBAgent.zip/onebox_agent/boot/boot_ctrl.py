#-*- coding: utf-8 -*-
'''
Created on 2017. 7. 25.

@author: ohhara
'''

import boot_view as bv
import boot_constant as bc

import logging
logger = logging.getLogger(bc._L_TITLE)




class _LinkedMenu():
    
    _PREV_CLS = None
    _NAME = None
    
    _RET_OK = "__ok__"
    _RET_UNIMPL = "__unimpl__"
    _RET_ERR = "__error__"
    _RET_BACK = "__back__"
    
    def __init__(self, _name, _prevCls):
        self._NAME = _name
        self._PREV_CLS = _prevCls
    
    def _select(self, _data):
        '''
        Widget Maker.
        Return : _RET_BACK, _RET_OK, _RET_UNIMPL, _RET_ERR, selected Code
        '''
        return self._RET_UNIMPL
    
    def _next(self, _ret, _data):
        '''
        if last and result is succ, _next func returns _RET_OK,
        elif last ans result fail, _RET_ERR
        else, (Next _LinkedMenu Class).get(_data)
        return : _RET_OK, _RET_ERR(_RET_UNIMPL), _RET_BACK(_RET_NO)
        '''
        return self._RET_UNIMPL
    
    def _err_unimpl(self, _ret):
        logger.error("Fail to Run Next Cls, UnImple_Menu, name=%s, ret=%s"%( str(self._NAME), str(_ret) ))
        return self._RET_UNIMPL
    
    def get_res(self, _data):
        '''
        return : _RET_OK, _RET_ERR(<- _RET_UNIMPL), _RET_BACK(or _RET_NO)
        '''
        _ret = self._select(_data)
        if _ret == self._RET_BACK :
            if self._PREV_CLS == None:
                return self._RET_BACK
            elif issubclass(self._PREV_CLS.__class__, _LinkedMenu) :
                return self._PREV_CLS.get_res(_data)
            else:
                logger.error("Fail to get LinkMenu, unknown Prev LinkMenu, name=%s, prevCls=%s"%( 
                                                                        self._NAME, self._PREV_CLS ))
                return self._RET_ERR
        elif _ret == self._RET_ERR :
            return self._RET_ERR
        elif _ret == self._RET_UNIMPL :
            logger.warning("UnImplement LinkMenu, name=%s"%str(self._NAME))
            return self._RET_ERR
        else:
            return self._next(_ret, _data)




def get_main_menu(_choices):
    '''
    return BTA_M_EXIT, selected TAG
    '''
    _txt = "Select Operation..."
    _ret = bv.get_menu(_txt, _choices, _showAlert=True)
    if _ret == bv.RET_NO or _ret == bv.RET_ERR :
        return bc.BTA_M_EXIT
    else:
        return _ret

def _c_main_return(_ret, _txt):
    '''
    return : BTA_M_EXIT, BTA_M_BACK
    '''
    if _ret == _LinkedMenu._RET_OK :
        bv.complete(True, _txt)
        return bc.BTA_M_EXIT
    elif _ret == _LinkedMenu._RET_BACK :
        return bc.BTA_M_BACK
    else:
        bv.complete(False, _txt)
        return bc.BTA_M_EXIT

def first_install(bta_data):
    bta_data[bc.FUNC_TITLE] = "First Install"
    
    from onebox_agent.boot.func.boot_install import OBInstall
    fInstall = OBInstall()
    _ret = fInstall.get_res(bta_data)
    return _c_main_return(_ret, bta_data[bc.FUNC_TITLE])


def recovery(bta_data, _opt):
    bta_data[bc.FUNC_TITLE] = "OneBox Recovery"
    
    from onebox_agent.boot.func.boot_recovery import OBRecovery
    obRec = OBRecovery()
    _ret = obRec.get_res(bta_data)
    return _c_main_return(_ret, bta_data[bc.FUNC_TITLE])


def factory_reset(bta_data):
    bta_data[bc.FUNC_TITLE] = "Factory Reset"
    
    from onebox_agent.boot.func.boot_reset import FactoryReset
    fReset = FactoryReset()
    _ret = fReset.get_res(bta_data)
    return _c_main_return(_ret, bta_data[bc.FUNC_TITLE])


def network_config(bta_data):
    bta_data[bc.FUNC_TITLE] = "Network Configuration"
    
    from onebox_agent.boot.func.boot_net_conf import OBNetConf
    obNetConf = OBNetConf()
    _ret = obNetConf.get_res(bta_data)
    return _c_main_return(_ret, bta_data[bc.FUNC_TITLE])


def etc(bta_data):
    bta_data[bc.FUNC_TITLE] = "ETC"
    
    from onebox_agent.boot.func.boot_etc import Etc
    etc = Etc()
    _ret = etc.get_res(bta_data)
    return _c_main_return(_ret, bta_data[bc.FUNC_TITLE])








