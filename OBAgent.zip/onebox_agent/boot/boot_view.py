#-*- coding: utf-8 -*-
'''
Created on 2017. 7. 25.

@author: ohhara
'''


from dialog import Dialog

from onebox_agent.util.ob_constant import VAL_OB_VER
from onebox_agent.boot import boot_constant as bc

import logging
import threading
from time import sleep
logger = logging.getLogger(bc._L_TITLE)



_TITLE = "One-Box BootAgent v%s"%str(VAL_OB_VER)
_D = Dialog(dialog='dialog', autowidgetsize=True)
_D.set_background_title(_TITLE)


_D_TXT_OK = Dialog.OK
_D_TXT_CANCEL = Dialog.CANCEL
_D_TXT_ESC = Dialog.ESC
_D_TXT_EXTRA = Dialog.EXTRA
_D_TXT_HELP = Dialog.HELP
# Dialog.DIALOG_OK
# Dialog.DIALOG_CANCEL
# Dialog.DIALOG_ESC
# Dialog.DIALOG_EXTRA
# Dialog.DIALOG_HELP
# Dialog.DIALOG_ITEM_HELP

_MIN_WIDTH = 30


RET_OK = "__ok__"
RET_NO = "__no__"
RET_ERR = "__err__"


G_STATUS_SUCC = "SUCC"
G_STATUS_FAIL = "FAIL"
G_STATUS_SKIP = "SKIP"

FORM_ATTR_EDITABLE = 0x00
FORM_ATTR_HIDDEN = 0x01
FORM_ATTR_READONLY = 0x02


class ProgBarInfo():
    
    def __init__(self, _title, _start=0):
        self._title = _title
        self._gauge = _start

    def perc(self):
        return self._gauge
    
    def perc_item(self):
        return self._gauge
    
    def get_item(self):
        return self._title
    
    def title(self):
        return self._title
    
    def inc(self, inc_num):
        inc_num = max(0, inc_num)
        inc_num = min(inc_num, 100)
        
        _tot = self._gauge + inc_num
        if _tot > 100 :
            _tot = 99
        self._gauge = _tot
    
    def set_perc(self, _perc):
        if self._gauge > _perc :
            return
        _perc = max(0, _perc)
        _perc = min(_perc, 100)
        self._gauge = _perc

class MixedProgBarInfo():
    '''
    _ele : [ITEM, ...]
        STATUS: text or int(+)
    '''
#     0: Succeeded
#     1: Failed
#     2: Passed
#     3: Completed
#     4: Checked
#     5: Done
#     6: Skipped
#     7: In Progress
#     8: (blank)
#     9: N/A

    def __init__(self, _title, __ele):
        self._title = "[ "+_title+" ]"
        self._subTitle = ""
        self._subIdx = -1
        
        self._eTot = 0
        self._eCnt = len(__ele)
        _ele = []
        for _e in __ele :
            _ele.append((_e, 0))
        self._ele = _ele
        self._idx = 0
        
        self._hei = _mgauge_height(self._title, _ele)
        self._wid = _mgauge_width(self._title, _ele)
        self._is_fin = False
    
    def height(self): 
        if self._subTitle == None or str(self._subTitle).strip() == "" :
            return self._hei
        else:
            return self._hei + _t_height(self._subTitle)
    
    def width(self): 
        return max(self._wid, (len(self._subTitle) + 8))
    
    def title(self): 
        if self._subTitle == None or str(self._subTitle).strip() == "" :
            return self._title
        else:
            return self._title + "\n  # " + self._subTitle
    
    def ele(self): 
        _elements = []
        for _e in self._ele :
            _eProg = _e[1]
            if type(_e[1]) == int :
                _eProg = "-" + str(_e[1])
            
            _elements.append((_e[0], _eProg))
        return _elements
    
    def perc(self):
        if self._is_fin : return 100
        
        _tPert = int(round(float(self._eTot)/float(self._eCnt)))
        if _tPert >= 100 :
            _tPert = 99
        return _tPert
    
    def perc_item(self):
        return (self._ele[self._idx][1] if type(self._ele[self._idx][1]) == int else 100)
    
    def fin(self):
        self._is_fin = True
    
    def set_index(self, _idx):
        self._reset_subTitle()
        if self._eCnt > _idx :
            self._idx = _idx
        else:
            self._idx = self._eCnt - 1
    
    def inc(self, inc_num):
        inc_num = int(inc_num)
        self.inc_item(self._ele[self._idx][0], inc_num)
    
    def set_perc(self, _perc):
        if type(_perc) == float :
            _perc = int(_perc)
        self.set_item(self._ele[self._idx][0], _perc)
    
    def _refresh_total(self):
        self._eTot = 0
        for _gEle in self._ele :
            if type(_gEle[1]) == int :
                self._eTot += _gEle[1]
            elif _gEle[1] == G_STATUS_SKIP or _gEle[1] == G_STATUS_SUCC :
                self._eTot += 100
    
    def inc_item(self, _item, inc_num):
        '''
        inc_num : only int(0<=x<=100)
        '''
        inc_num = int(inc_num)
        inc_num = max(0, inc_num)
        inc_num = min(inc_num, 100)
        
        _idx = 0
        for _gEle in self._ele :
            if _gEle[0] == str(_item) and type(_gEle[1]) == int:
                _etot = min(99, _gEle[1]+inc_num)
                self._ele[_idx] = (_gEle[0], _etot)
                
                if self._subIdx >= 0 and self._subIdx != _idx :
                    self._reset_subTitle()
                break
            _idx += 1
        self._refresh_total()
    
    def get_item(self, _idx=None):
        if _idx == None :
            _idx = self._idx
        
        return self._ele[_idx][0]
    
    def set_item(self, _item, _prog):
        '''
        _prog : int or boot_view.G_STATUS_XXXX
        '''
        if type(_prog) == float :
            _prog = int(_prog)
        _idx = 0
        if type(_prog) == int :
            _prog = min(100, _prog)
            _prog = max(0, _prog)
        for _gEle in self._ele :
            if _gEle[0] == str(_item) :
                if type(_gEle[1]) == int and _gEle[1] < _prog :
                    self._ele[_idx] = (_gEle[0], _prog)
                elif type(_gEle[1]) != int :
                    self._ele[_idx] = (_gEle[0], _prog)
                if self._subIdx >= 0 and self._subIdx != _idx :
                    self._reset_subTitle()
                break
            _idx += 1
        self._refresh_total()
        
    def _reset_subTitle(self):
        self._subIdx = -1
        self._subTitle = ""
    
    def set_subTitle(self, _subTitle):
        self._subTitle =  _subTitle
        self._subIdx = self._idx
        
    def get_ele(self, _idx=None):
        if _idx == None :
            _idx = self._idx
        
        return self._ele[_idx]
    

class UpdateProg(threading.Thread):
    
    def __init__(self, _prog, _period=2, _inc=1, _msg=None):
        threading.Thread.__init__(self)
        self._run = True
        
        self._prog = _prog
        self._period = _period
        self._inc = _inc
        self._msg = _msg
        self._dbg_title = _prog.title()
        self._dbg_ele = None
        if isinstance(_prog, MixedProgBarInfo) :
            self._dbg_ele = _prog.get_ele()
    
    def set_msg(self, _msg):
        self._msg = _msg
        update_progBar(self._prog, self._msg)
    
    def stop(self):
        if not self._run :
            return
        self._run = False
        sleep(self._period+0.2)
    
    def start(self):
        sleep(0.5)
        if not self.isAlive() :
            try:
                threading.Thread.start(self)
            except RuntimeError :
                pass
    
    def run(self):
        while self._run :
            if not self._run or self._prog.perc_item() >= 100 :
                break
            
            sleep(self._period)
            
            if not self._run or self._prog.perc_item() >= 100 :
                break
            self._prog.inc(self._inc)
            update_progBar(self._prog, self._msg)
#             logger.debug("-------------%s------%s---------"%( str(self._dbg_title), str(self._dbg_ele) ))
            


def _t_width(_txt, _sep="\n"):
    _prv = 0
    for _t in str(_txt).split(_sep):
        if _prv < len(_t) :
            _prv = len(_t)
    return max(_MIN_WIDTH, _prv)

def _t_height(_txt, _sep="\n"):
    return len(str(_txt).split(_sep))

def _form_height(_txt, _ele, _sep="\n"):
    _ht = 6
    
    _txtLen = len(str(_txt).split(_sep))
    _eleLen = len(_ele)
    
    return _ht + _txtLen + _eleLen

# ('Address', 1, 1, "192.168.1.10", 1, 20, 20, 15)
def _form_width(_txt, _ele, _sep="\n"):
    _prv = 0
    for _t in str(_txt).split(_sep):
        if _prv < len(_t) :
            _prv = len(_t) + 2
    
    for _e in _ele:
        _elen = _e[5] + max(_e[6], _e[7]) + 2
        if _prv < _elen :
            _prv = _elen
    
    return max(_MIN_WIDTH, _prv)

def _mgauge_height(_txt, _ele, _sep="\n"):
    _ht = 8
    
    _txtLen = len(str(_txt).split(_sep))
    _eleLen = len(_ele)
    
    return _ht + _txtLen + _eleLen

def _mgauge_width(_txt, _ele, _sep="\n"):
    _def_gauge_wid = 14
    _def_intermid_wid = 2
    _prv = 0
    for _t in str(_txt).split(_sep):
        if _prv < (len(_t) + 4) :
            _prv = len(_t) + 4
    
    for _e in _ele:
        _elen = len(_e[0]) + _def_gauge_wid + _def_intermid_wid + 4
        if _prv < _elen :
            _prv = _elen
    
    return max(_MIN_WIDTH, _prv)


def get_menu(_title, _list, _height=None, _width=None, _menu_height=None, _showAlert=True):
    '''
    return : RET_ERR, RET_NO, selected menu
    '''
    try:
        (_code, _tag) = _D.menu(_title, height=_height, width=_width, menu_height=_menu_height, choices=_list)
        if _code == _D_TXT_OK:
            return _tag
        else:
            return RET_NO
    except Exception, e:
        logger.error("Fail to Show Menu, title=%s, menu=%s, exc=%s"%( str(_title), str(_list), str(e) ))
        logger.exception(e)
        if _showAlert :
            try:
                _D.msgbox(text="Exception Occur!!!, exc=%s"%str(e))
            except Exception, e:
                logger.error("Fail to Show Menu, exc=%s"%str(e))
                logger.exception(e)
                
        return RET_ERR

def complete(result, _txt):
    try:
        if result: 
            _msg = "[SUCC] %s"%str(_txt)
        else:
            _msg = "[FAIL] %s"%str(_txt)
        logger.info(_msg)
        _D.msgbox(text=_msg, width=_t_width(_msg)+11, height=_t_height(_msg)+4)
    except Exception, e:
        logger.error("Fail to Show CompleteMsg, exc=%s"%str(e))
        logger.exception(e)

def notify(_msg):
    try:
        _D.msgbox(text=_msg, width=_t_width(_msg)+4, height=_t_height(_msg)+4)
    except Exception, e:
        logger.error("Fail to Show NotifyMsg, exc=%s"%str(e))
        logger.exception(e)

def confirm_ok(_msg, _isAutoSize=True, _width=None, _height=None, _showAlert=True):
    '''
    return : RET_OK, RET_NO, RET_ERR
    '''
    try:
        if _isAutoSize:
            _code = _D.yesno(_msg, width=_t_width(_msg)+4, height=_t_height(_msg)+4)
        else:
            _code = _D.yesno(_msg, width=_width, height=_height)
        
        if _code == _D_TXT_OK:
            return RET_OK
        else:
            return RET_NO
    except Exception, e:
        logger.error("Fail to Show ConfirmMsg, msg=%s, exc=%s"%( str(_msg), str(e) ))
        logger.exception(e)
        if _showAlert :
            try:
                _D.msgbox(text="Exception Occur!!!, exc=%s"%str(e))
            except Exception, e:
                logger.error("Fail to Show Confirm Box, exc=%s"%str(e))
                logger.exception(e)
        return RET_ERR

def input_text(_msg, _init='', _width=None, _height=None, _showAlert=True):
    '''
    return : Code[RET_OK, RET_NO, RET_ERR], input_text
    '''
    try:
        _code, _input = _D.inputbox(_msg, _height, _width, _init)
        if _code == _D_TXT_OK :
            return RET_OK, _input
        else:
            return RET_NO, None
    except Exception, e:
        if _showAlert :
            try:
                _D.msgbox(text="Exception Occur!!!, exc=%s"%str(e))
            except Exception, e:
                logger.error("Fail to Show Input Box, exc=%s"%str(e))
                logger.exception(e)
        return RET_ERR, None

def alert(_msg, _isAutoSize=True, _width=None, _height=None, _colors=None):
    try:
        if _isAutoSize :
            _D.msgbox(text="[ERROR] %s"%str(_msg), width=_t_width(_msg)+12, height=_t_height(_msg)+4, colors=_colors)
        else:
            _D.msgbox(text="[ERROR] %s"%str(_msg), width=_width, height=_height, colors=_colors)
    except Exception, e:
        logger.error("Fail to Show Alert, exc=%s"%str(e))
        logger.exception(e)

def get_one_menu(_title, choice, _showAlert=True):
    '''
    return : RET_NO, RET_ERR, selected Tag
    '''
    try: 
        _code, _tag = _D.radiolist(_title, choices=choice)
        if _code == _D_TXT_OK:
            return _tag
        else:
            return RET_NO
    except Exception, e:
        logger.exception(e)
        if _showAlert :
            try:
                _D.msgbox(text="Exception Occur!!!, exc=%s"%str(e))
            except Exception, e:
                logger.error("Fail to Show One-Menu, exc=%s"%str(e))
                logger.exception(e)
        return RET_ERR

def get_multi_choice_menu(_title, choice, _showAlert=True):
    '''
    return : RET_NO, RET_ERR, selected TagList
    '''
    try: 
        _code, _tags = _D.checklist(_title, choices=choice)
        if _code == _D_TXT_OK:
            _ret = []
            for _t in _tags :
                _ret.append(str(_t))
            return _ret
        else:
            return RET_NO
    except Exception, e:
        logger.exception(e)
        if _showAlert :
            try:
                _D.msgbox(text="Exception Occur!!!, exc=%s"%str(e))
            except Exception, e:
                logger.error("Fail to Show Multi-Choice-Menu, exc=%s"%str(e))
                logger.exception(e)
        return RET_ERR

# ('Address', 1, 1, "192.168.1.10", 1, 10, 20, 35)
# 5th: item 시작 위치(10)
# 6th: 입력 받는 입력창 크기(20)
# 7th: 입력 받을 수 있는 길이(35)
def show_form(_title, _ele, _showAlert=True):
    '''
    return : RET_NO, RET_ERR, list
    '''
    try:
        _code, _items = _D.form(_title, _ele, height=_form_height(_title, _ele), width=_form_width(_title, _ele))
        if _code == _D_TXT_OK:
            return _items
        else:
            return RET_NO
    except Exception, e:
        logger.exception(e)
        if _showAlert :
            try:
                _D.msgbox(text="Exception Occur!!!, exc=%s"%str(e))
            except Exception, e:
                logger.error("Fail to Show Form, exc=%s"%str(e))
                logger.exception(e)
        return RET_ERR

# ("Mode", item_pos, 1, str_mgmt_mode, item_pos, 20, FIELD_LEN, INPUT_LEN, DEFAULT)
# 8th: 0->editable, 1->hidden, 2->read-only
def show_mixform(_title, _ele, _showAlert=True):
    '''
    return : RET_NO, RET_ERR, list
    '''
    try:
        _code, _items = _D.mixedform(_title, _ele, form_height=_form_height(_title, _ele), width=_form_width(_title, _ele))
        if _code == _D_TXT_OK:
            return _items
        else:
            return RET_NO
    except Exception, e:
        logger.exception(e)
        if _showAlert :
            try:
                _D.msgbox(text="Exception Occur!!!, exc=%s"%str(e))
            except Exception, e:
                logger.error("Fail to Show Mix-Form, exc=%s"%str(e))
                logger.exception(e)
        return RET_ERR

def start_progBar(_msg, _title, _height=None, _width=100, _percent=0):
    _D.gauge_start(text=_msg, title=_title, height=_height, width=_width, percent=_percent)

def stop_progBar():
    try:
        _D.gauge_stop()
    except Exception, e:
        logger.exception(e)

def update_progBar(_progInfo, _msg=None):
    if isinstance(_progInfo, ProgBarInfo) :
        if _msg == None : _msg = ""
        _D.gauge_update(percent=_progInfo.perc(), text=_msg, update_text=True)
    elif isinstance(_progInfo, MixedProgBarInfo) :
        if _msg != None : _progInfo.set_subTitle(_msg)
        show_mixedProgBar_MPB( _progInfo )
    else:
        logger.error("Fail to Update ProgBar, UnknownParamType, param=%s"%str(_progInfo))


def show_mixedProgBar(_title, _ele, _total_rate=None, ):
    '''
    _ele : [(ITEM, STATUS), (), ...]
        STATUS: text or int(+)
    '''
    _tPert = _total_rate
    _elements = []
    
    _eTot = 0
    _eCnt = len(_ele)
    for _e in _ele :
        _eProg = _e[1]
        if type(_e[1]) == int :
            _eTot += _e[1]
            _eProg = "-" + str(_e[1])
        elif str(_e[1]) == G_STATUS_SUCC or str(_e[1]) == G_STATUS_FAIL or str(_e[1]) == G_STATUS_SKIP :
            _eTot += 100
        
        _elements.append((_e[0], _eProg))
    
    if _total_rate == None :
        _tPert = int(round(float(_eTot)/float(_eCnt)))
        if _tPert >= 100 :
            _tPert = 99
    
    _D.mixedgauge(_title, percent=_tPert, elements=_elements, 
                  height=_mgauge_height(_title, _elements),
                  width=_mgauge_width(_title, _elements))

def show_mixedProgBar_MPB( _mixedProgBar ):
    '''
    _mixedProgBar : boot_view.MixedProgBarInfo
    '''
    _D.mixedgauge(_mixedProgBar.title(), percent=_mixedProgBar.perc(), elements=_mixedProgBar.ele(), 
                  height=_mixedProgBar.height(), width=_mixedProgBar.width())






