#-*- coding: utf-8 -*-
'''
Created on 2017. 7. 26.

@author: ohhara
'''

from time import sleep
from ipaddr import IPv4Network
import ruamel.yaml

from onebox_agent.boot import boot_constant as bc
from onebox_agent.util import ob_constant as oc
from onebox_agent.boot import boot_view as bv
from onebox_agent.boot.boot_ctrl import _LinkedMenu

import logging
logger = logging.getLogger(bc._L_TITLE)


FIELD_LEN = 40
INPUT_LEN = 0




def external_network_info(elements, network, item_pos = -1, title = "", _attr=bv.FORM_ATTR_READONLY):
    nic = ','.join(network.nics())
    ip_dhcp = network.is_dhcp()
    
    item_pos = item_pos + 1
    itm_nic = (title, item_pos, 1, "interface\t %s" % nic, item_pos, 20, FIELD_LEN, INPUT_LEN, _attr)
    elements.append(itm_nic)
    
    if ip_dhcp:
        str_ip_type = "DHCP"
        item_pos = item_pos + 1
        itm_ip_type = ("", item_pos, 1, "IP type\t\t %s" % str_ip_type, item_pos, 20, FIELD_LEN, INPUT_LEN, _attr)
        elements.append(itm_ip_type)
    else:
        str_ip_type = "STATIC"
        ip_addr = network.ip()
        ip_subnet = network.mask()
        ip_gateway = network.gw()
        
#         logger.debug("ip= %s subnet= %s gateway= %s" % (ip_addr, ip_subnet, ip_gateway))
        
        item_pos = item_pos + 1
        itm_ip_type = ("", item_pos, 1, "IP type\t\t %s" % str_ip_type, item_pos, 20, FIELD_LEN, INPUT_LEN, _attr)
        elements.append(itm_ip_type)
        
        item_pos = item_pos + 1
        itm_ip_addr = ("", item_pos, 1, "address\t\t %s" % ip_addr, item_pos, 20, FIELD_LEN, INPUT_LEN, _attr)
        elements.append(itm_ip_addr)
        
        item_pos = item_pos + 1
        itm_ip_subnet = ("", item_pos, 1, "netmask\t\t %s" % ip_subnet, item_pos, 20, FIELD_LEN, INPUT_LEN, _attr)
        elements.append(itm_ip_subnet)
        
        item_pos = item_pos + 1
        itm_ip_gateway = ("", item_pos, 2, "gateway\t\t %s" % ip_gateway, item_pos, 20, FIELD_LEN, INPUT_LEN, _attr)
        elements.append(itm_ip_gateway)
        
    return item_pos

def internal_network_info(elements, network, item_pos = -1, title = "", _attr=bv.FORM_ATTR_READONLY):
    nic = ','.join(network.nics())
    gw_addr = network.gw()
    gw_subnet = network.mask()
    
    item_pos = item_pos + 1
    str_nic = nic
    if type(nic) is list:
        str_nic = ",".join(nic)  
    else:
        str_nic = nic
    itm_nic = (title, item_pos, 1, "interface\t %s" % str_nic, item_pos, 20, FIELD_LEN, INPUT_LEN, _attr)
    elements.append(itm_nic)
    
#     logger.debug("gateway= %s subnet= %s" % (ip_addr, ip_subnet))
    
    item_pos = item_pos + 1
    itm_ip_addr = ("", item_pos, 1, "gateway\t\t %s" % gw_addr, item_pos, 20, FIELD_LEN, INPUT_LEN, _attr)
    elements.append(itm_ip_addr)
    
    item_pos = item_pos + 1
    itm_ip_subnet = ("", item_pos, 1, "netmask\t\t %s" % gw_subnet, item_pos, 20, FIELD_LEN, INPUT_LEN, _attr)
    elements.append(itm_ip_subnet)
    
    return item_pos


class BTA_LIB:
    
    def __init__(self, _obLib):
        self._ob = _obLib
        self._os = _obLib.get_os()
        self._vim = _obLib.get_vim()
        self._vnf_utm = _obLib.get_vnf_utm()
        self._extra_vnf_list = _obLib.get_extra_vnf_list()
    
    def config_vnfm(self, ob_id):
        try:
            vnf_config = oc.FILE_VNFM_CONF
            
            # read configuration
            with open(vnf_config, "r") as f:
                cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
            
            # update configuration
            cfg['onebox_id'] = ob_id
            
            with open(vnf_config, 'w') as f:
                f.write(ruamel.yaml.dump(cfg, Dumper=ruamel.yaml.RoundTripDumper))
            
            return True
        except Exception, e:
            logger.error("Fail to Config VNFM-Config, exc=%s"%str(e))
            logger.exception(e)
            return False
    
    def config_mona(self, ob_id):
        try:
            mon_config = oc.FILE_MONA_CONF
            
            from configobj import ConfigObj
            config = ConfigObj(mon_config)
            
            config['Hostname'] = ob_id
            
            # TODO: Server와 ServerActive도 설정 필요 
            config.write()
            
            return True
        except Exception, e:
            logger.error("Fail to Config Mon-Config, exc=%s"%str(e))
            logger.exception(e)
            return False
    
    def config_nmsa(self, _ob_id, _only_id_chg=False):
        try:
            _cmd = self._os.Command()
            cmd_set_obid = """ /var/onebox/softwares/onebox-znmsc/bin/znmsc -uid %s """%str(_ob_id)
            _c, _o, _e = _cmd.execute_command(cmd_set_obid)
            if _c != 0 or str(_o).find(_ob_id) < 0 :
                logger.error("Fail to Set NMSA OBID, cmd=%s, code=%s, out=%s, err=%s"%(str(cmd_set_obid), str(_c), str(_o), str(_e)))
                return False, "UID Setting Error"
            
            if not _only_id_chg :
                with open(oc.FILE_OBA_CONF, "r") as f:
                    ob_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
                
                if not 'nms_ip' in ob_cfg or not 'nms_port' in ob_cfg :
                    logger.warning("No NMS Info")
                    return True, None
                
                znms_ip = ob_cfg['nms_ip']
                znms_ports = ob_cfg['nms_port']
                
                cmd_set_addr = """ /var/onebox/softwares/onebox-znmsc/bin/znmsc -mgr1 %s """%str(znms_ip)
                for znms_port in znms_ports :
                    cmd_set_addr += """ %s """%str(znms_port)
                
                _c, _o, _e = _cmd.execute_command(cmd_set_addr)
                if _c != 0 or str(_o).find(znms_ip) < 0 :
                    logger.error("Fail to Set NMSA IP, cmd=%s, code=%s, out=%s, err=%s"%(str(cmd_set_addr), str(_c), str(_o), str(_e)))
                    return False, "NMS-INFO Setting Error"
            
            return True, None
        except Exception, e:
            logger.error("Fail to Config NMS Agent")
            logger.exception(e)
            return False, "Unknown Error, exc=%s"%str(e)


    def config_smsa(self, _ob_id, _only_id_chg=False):
        try:
            _cmd = self._os.Command()
            cmd_set_obid = """ /var/onebox/softwares/onebox-zsmsc/bin/zsmsc -uid %s """%str(_ob_id)
            _c, _o, _e = _cmd.execute_command(cmd_set_obid)
            if _c != 0 or str(_o).find(_ob_id) < 0 :
                logger.error("Fail to Set SMSA OBID, cmd=%s, code=%s, out=%s, err=%s"%(str(cmd_set_obid), str(_c), str(_o), str(_e)))
                return False, "UID Setting Error"
            
            if not _only_id_chg :
                with open(oc.FILE_OBA_CONF, "r") as f:
                    ob_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
                
                if not 'sms_ip' in ob_cfg or not 'sms_port' in ob_cfg :
                    logger.warning("No SMS Info")
                    return True, None
                
                zsms_ip = ob_cfg['sms_ip']
                zsms_ports = ob_cfg['sms_port']
                
                cmd_set_addr = """ /var/onebox/softwares/onebox-zsmsc/bin/zsmsc -mgr %s """%str(zsms_ip)
                for zsms_port in zsms_ports :
                    cmd_set_addr += """ %s """%str(zsms_port)
                
                _c, _o, _e = _cmd.execute_command(cmd_set_addr)
                if _c != 0 or str(_o).find(zsms_ip) < 0 :
                    logger.error("Fail to Set SMSA IP, cmd=%s, code=%s, out=%s, err=%s"%(str(cmd_set_addr), str(_c), str(_o), str(_e)))
                    return False, "SMS-INFO Setting Error"
            
            return True, None
        except Exception, e:
            logger.error("Fail to Config SMS Agent")
            logger.exception(e)
            return False, "Unknown Error, exc=%s"%str(e)


    def reset_nmsa(self):
        try:
            _cmd = self._os.Command()
            cmd_reset = """ service %s reset """%str("znmsc")
            _c, _o, _e = _cmd.execute_command(cmd_reset)
            if _c != 0 or str(_o).find("Success") < 0 :
                logger.error("Fail to Reset NMSA, cmd=%s, code=%s, out=%s, err=%s"%(str(cmd_reset), str(_c), str(_o), str(_e)))
                return False
            return True
        except Exception, e:
            logger.error("Fail to Reset NMSA-Config, exc=%s"%str(e))
            logger.exception(e)
            return False

    def reset_smsa(self):
        try:
            _cmd = self._os.Command()
            cmd_reset = """ service %s reset """%str("zsmsc")
            _c, _o, _e = _cmd.execute_command(cmd_reset)
            if _c != 0 or str(_o).find("Success") < 0 :
                logger.error("Fail to Reset SMSA, cmd=%s, code=%s, out=%s, err=%s"%(str(cmd_reset), str(_c), str(_o), str(_e)))
                return False
            return True
        except Exception, e:
            logger.error("Fail to Reset SMSA-Config, exc=%s"%str(e))
            logger.exception(e)
            return False


    def wanSw_obaRun(self, _ob_info, _wanMode, _obaMode, _vnfIP, _prog=None):
        """
        _ob_info : class ob_info.OB_INFO
        _wanMode : HOST(WAN_MD_HOST)/VNF(WAN_MD_VNF)
        _obaMode : True/False
        
        return : True/False
            if False, should restart gauge
        """
        try:
            if _obaMode == False :
                sleep(1)
                _ret, _err = self.set_onebox_services([oc.VAL_OBA_NAME], False, _prog)
                if not _ret :
                    logger.error("Failed to Stop One-Box Agent")
                    if bv.confirm_ok("Failed to Stop One-Box Agent...\nConitnue?", _showAlert=False) == bv.RET_NO :
                        return False
                    else:
                        if _prog != None and isinstance(_prog, bv.ProgBarInfo) :
                            bv.stop_progBar()
                            bv.start_progBar(_prog.title(), _prog.title())
            
            
            if _prog != None :
                _prog.set_perc(51)
            
            if _ob_info.is_in_band():
                if _wanMode == oc.VAL_WAN_MD_HOST :
                    sleep(1)
                    _res, _err = self.switchToHost(_ob_info.mgmt_list(), _ob_info.wan_list(), _prog)
                    if not _res :
                        logger.error("Failed to WAN-Switch, err=%s"%str(_err))
                        bv.alert("Failed to WAN-Switch, err=%s"%str(_err), _width=200, _colors=True)
                        return False
                    
                    sleep(1)
                    _res, _err = self._ob.config_mgmt_net(_ob_info.mgmt_list(), _prog, bv)
                    if not _res:
                        logger.error("Fail to Refresh Host Network, err=%s"%str(_err))
                        bv.alert("Fail to Refresh Host Network, err=%s"%str(_err), _width=200, _colors=True)
                        return False
                elif _wanMode == oc.VAL_WAN_MD_VNF :
                    sleep(1)
                    _res, _err = self.switchToVNF(_ob_info.mgmt_list(), _ob_info.wan_list(), _vnfIP, _prog, _ob_info.ovs_dpdk())
                    if not _res :
                        logger.error("Fail to WAN-Switch, err=%s"%str(_err))
                        bv.alert("Fail to WAN-Switch, err=%s"%str(_err), _width=200, _colors=True)
                        return False
            
            if _obaMode == True :
                sleep(1)
                _ret, _err = self.set_onebox_services(["onebox-agent"], True, _prog)
                if not _ret :
                    logger.error("Fail to Start One-Box Agent")
                    if bv.confirm_ok("Fail to Start One-Box Agent...\nConitnue?", _showAlert=False) == bv.RET_NO :
                        return False
                    else:
                        if _prog != None and isinstance(_prog, bv.ProgBarInfo) :
                            bv.stop_progBar()
                            bv.start_progBar(_prog.title(), _prog.title())
            
            return True
        except Exception, e:
            logger.error("Fail to Set OBA & WAN Mode, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Set OBA & WAN Mode, exc=%s"%str(e), _width=200, _colors=True)
            return False
    
    def config_init_interfaces(self, internet, _prog=None, _nic_model=None):
        # /etc/network/interfaces 파일에 딱 한 번만 접근하도록 하기 위해 이 함수를 생성
        # 여러 번 접근 시 설정 파일에 오류 발생 가능성이 있음
        # management interface 설정 시에 호출되어 모든 인터페이스에 대한 up/down 설정 수행
        try:
            net_conf = self._os.NetworkConfig()
            
            ## Internet
            result = net_conf.config_bridge_internet(
                        internet.bridge(), internet.nics(), internet.is_dhcp(), 
                        internet.ip(), internet.mask(), internet.gw())
            if not result:
                logger.error("Fail to Config LX-BR Network, net=%s"%str(internet))
                return False
            if _prog != None :
                _prog.inc(5)
                bv.update_progBar(_prog)
            
            ## ETC
            nic_list = self._os.get_phy_if_list(_nic_model)
            if nic_list == None :
                logger.error("Fail to Get Phy IF")
                return False
            if _prog != None :
                _prog.inc(5)
                bv.update_progBar(_prog)
            
            for nic in nic_list: 
                if not net_conf.config_manual_updown(nic) :
                    return False
                if _prog != None :
                    _prog.inc(5)
                    bv.update_progBar(_prog)
            
            ## save
            if not net_conf.write() :
                logger.error("Fail to Write ETC Network Info")
                return False
            if _prog != None :
                _prog.inc(5)
                bv.update_progBar(_prog)
            
            self._os.delete_dhclient_config()
            self._os.dhclient_down()
            
            return True
        except Exception, e:
            logger.exception(e)
            return False
    
    def config_init_local_net(self, _name, _ip, _mask):
        net_conf = self._os.NetworkConfig()
        _ret = net_conf.config_default_local_network(_name, _ip, _mask)
        
        if not _ret :
            logger.error("Fail to Config Init Local Network, net=%s"%_name)
            return False
        else:
            sleep(1)
            if not net_conf.write():
                logger.error("Fail to Write Init Local Network Config, net=%s"%_name)
                return False
            else:
                sleep(1)
                if not self._os.refresh_route(_name) :
                    logger.error("Fail to Refresh Init Local Net, net=%s"%_name)
                    return False
        return True
    
    def config_local_net(self, _name, _ip, _mask, _init_route_list, _prog=None):
        '''
        _del_route_list : [ "192.168.0.0/24", ... ]
        '''
        net_conf = self._os.NetworkConfig()
        _ret = net_conf.config_local_network(_name, _ip, _mask, _init_route_list)
        if _prog :
            _prog.inc(10)
            bv.update_progBar(_prog)
        if not _ret :
            logger.error("Fail to Config Local Network, net=%s"%_name)
            return False, "Local-Net Config Error"
        else:
            sleep(1)
            _ret = net_conf.write()
            if _prog :
                _prog.inc(10)
                bv.update_progBar(_prog)
            if not _ret :
                logger.error("Fail to Write Local Network Config, net=%s"%_name)
                return False, "Local-Net Config Save Error"
            else:
                sleep(1)
                if _prog :
                    _prog.inc(10)
                    bv.update_progBar(_prog)
                if not self._os.refresh_route(_name) :
                    logger.error("Fail to Refresh Local Net, net=%s"%_name)
                    return False, "Local-Net Fresh Error"
        return True, None
    
    def config_vi_net(self, _net, _prog=None, __ovs_dpdk=False):
        try:
            if _net.type() == oc.VAL_NET_TYPE_LAN :
                _net_name = oc.VAL_DEF_VNF_LAN_BR_PFX + _net.name()
            else:
                _net_name = _net.bridge()
            _net_if_list = _net.nics()
            _ret, _err = self._vim.config_vi_network(_net_name, _net_if_list, __ovs_dpdk)
            if _prog :
                _prog.inc(5)
                bv.update_progBar(_prog)
            
            if not _ret :
                logger.error("Fail to Config vNetwork, _net=%s, err=%s"%( _net_name, str(_err) ))
                return False, _err
            
            if not __ovs_dpdk :
                for _ifname in _net_if_list :
                    _ret = self._os.down_and_up_interface(_ifname)
                    if _prog :
                        _prog.inc(2)
                        bv.update_progBar(_prog)
                    
                    if not _ret: 
                        return False, "Refresh Host Nic Error, nic=%s"%str(_ifname)
            
            return True, None
        except Exception, e:
            logger.error("Fail to Config vNetwork, exc=%s"%str(e))
            logger.exception(e)
            return False, "Unknow Error, exc=%s"%str(e)
    
    def create_lan_vnet(self, _lan, _tenant, _tUser, _tPass, _prog=None):
        try:
            _gw = _lan.gw()
            _mask = _lan.mask()
            _name = _lan.name()
            _ret, _err = self._vim.create_lan_vnetwork(_gw, _mask, _name, _tenant, _tUser, _tPass)
            if _prog :
                _prog.inc(10)
                bv.update_progBar(_prog)
            return _ret, _err
        except Exception, e:
            logger.error("Fail to Create LAN-vNetwork, exc=%s"%str(e))
            logger.exception(e)
            return False, "Unknow Error, exc=%s"%str(e)
    
    def remove_lan_vnet(self, _lan, _tenant, _tUser, _tPass):
        return self._vim.remove_lan_vnetwork(_lan.name(), _tenant, _tUser, _tPass)
        
    
    def apply_config(self, _ob_info, _tenant, _tUser, _tPass, _fake_ip=None, _skip_oba_run=False):
        _title = "Start First-Install"
        logger.info(_title)
        
        _idx = 0
        _ele = ["Stop OneBox-Agent", "Clear Network", "Config Mgmt/Wan-Network", "Config LAN-Network",
                "Config Local-Network", "Config VIM", "Config Agent"]
        _mProg = bv.MixedProgBarInfo(_title, _ele)
        _item = _ele[_idx]
        try:
            ## 0. Stop Agent
            logger.info(" - %s"%_item)
            _mProg.set_index(_idx)
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            
            _ret, _err = self.set_onebox_services([oc.VAL_OBA_NAME], False, _mProg)
            if not _ret :
                logger.warning(" - Fail to %s"%_item)
            else:
                logger.info(" - SUCC: %s"%_item)
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            sleep(0.5)
            
            
            ## 1. Clear vNetwork
            _idx += 1
            _item = _ele[_idx]
            logger.info(" - %s"%_item)
            _mProg.set_index(_idx)
            _mProg.inc(5)
            bv.update_progBar(_mProg, "VI Bridge Clear")
            
            _ret, _err = self.reset_vim_br(oc.VAL_DEF_VI_WAN_BR_LIST+oc.VAL_DEF_VI_LAN_BR_LIST+oc.VAL_DEF_VI_EWAN_BR_LIST)
            if not _ret :
                logger.error(" - Fail to %s, VI-BR Reset Error, err=%s"%( _item, _err ))
                bv.alert("Fail to %s, VI-BR Reset Error\n : err=%s"%( _item, _err ))
                return False
            logger.info("   Clear VI-BR")
            _mProg.set_perc(50)
            bv.update_progBar(_mProg, "OS Bridge Clear")
            
            _ret, _err = self.reset_os_br()
            if not _ret :
                logger.error(" - Fail to %s, OS-BR Reset Error\n : err=%s"%( _item, _err ))
                bv.alert("Fail to %s, OS-BR Reset Error\n : err=%s"%( _item, _err ))
                return False
            logger.info("   Clear OS-BR")
            _mProg.set_perc(95)
            
            logger.info(" - SUCC: %s"%_item)
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            sleep(0.5)
            
            ## 2. Config Mgmt/Wan Net
            _idx += 1
            _item = _ele[_idx]
            logger.info(" - %s"%_item)
            _mProg.set_index(_idx)
            _mProg.inc(5)
            bv.update_progBar(_mProg, "Management Network Config")
            
            # mgmt
            _mgmt_list = _ob_info.mgmt_list()
            _ret, _err = self._ob.config_mgmt_net(_mgmt_list, _mProg, bv)
            if not _ret :
                logger.error(" - Fail to %s[Mgmt], err=%s"%( _item, _err ))
                bv.alert("Fail to %s[Mgmt]\n : err=%s"%( _item, _err ))
                return False
            logger.info("   Config Mgmt-Net")
            _mProg.set_perc(40)
            bv.update_progBar(_mProg)
            
            # wan
            _in_band = _ob_info.is_in_band()
            _ovs_dpdk = _ob_info.ovs_dpdk()
            if not _in_band :
                bv.update_progBar(_mProg, "WAN Network Config")
                _wan_list = _ob_info.wan_list()
                for _wan in _wan_list :
                    _ret, _err = self.config_vi_net(_wan, _mProg, _ovs_dpdk)
                    if not _ret :
                        logger.error(" - Fail to %s[WAN], err=%s"%( _item, _err ))
                        bv.alert("Fail to %s[WAN]\n : err=%s"%( _item, _err ))
                        return False
                    else:
                        logger.info("     config wan-vnet, wan=%s"%str(_wan.bridge()))
                logger.info("   Config WAN-vNet")
                _mProg.set_perc(80)
                bv.update_progBar(_mProg)
            
            # ev-wan
            _evwan_list = _ob_info.extra_wan_list()
            if type(_evwan_list) == list :
                bv.update_progBar(_mProg, "EVWAN Network Config")
                for _evwan in _evwan_list :
                    _ret, _err = self.config_vi_net(_evwan, _mProg, _ovs_dpdk)
                    if not _ret :
                        logger.error(" - Fail to %s[EVWAN], err=%s"%( _item, _err ))
                        bv.alert("Fail to %s[EVWAN]\n : err=%s"%( _item, _err ))
                        return False
                    else:
                        logger.info("     config evwan-vnet, wan=%s"%str(_evwan.bridge()))
                
                logger.info("   Config EVWAN-vNet")
                _mProg.set_perc(95)
                bv.update_progBar(_mProg)
            
            logger.info(" - SUCC: %s"%_item)
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            sleep(0.5)
            
            ## 3. Config LAN-Net
            _idx += 1
            _item = _ele[_idx]
            logger.info(" - %s"%_item)
            _mProg.set_index(_idx)
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            
            # for LAN-net
            _init_route_list = []
            _lan_list = _ob_info.lan_net_list()
            for _lan in _lan_list :
                # VI Config
                bv.update_progBar(_mProg, "LAN-%s vNetwork Config"%_lan.name())
                _ret, _err = self.config_vi_net(_lan, _mProg, _ovs_dpdk)
                if not _ret :
                    logger.error(" - Fail to %s, Config Error, err=%s"%( _item, _err ))
                    bv.alert("Fail to %s, Config Error\n : err=%s"%( _item, _err ))
                    return False
                else:
                    logger.info("   Config lan-vnet, lan=%s"%str(_lan.name()))
                
                # VI Create
                bv.update_progBar(_mProg, "LAN-%s vNetwork Create"%_lan.name())
                _ret, _err = self.create_lan_vnet(_lan, _tenant, _tUser, _tPass, _mProg)
                if not _ret :
                    logger.error(" - Fail to %s, Create Error, err=%s"%( _item, _err ))
                    bv.alert("Fail to %s, Create Error\n : err=%s"%( _item, _err ))
                    return False
                else:
                    logger.info("   Create lan-vnet, lan=%s"%str(_lan.name()))
                
                # for LAN-net
                try :
                    _ipnet = IPv4Network("%s/%s"%( _lan.gw(), _lan.mask() ))
                    _lnet = "%s/%s"%(_ipnet.network, _ipnet.prefixlen)
                    _init_route_list.append(_lnet)
                except Exception :
                    logger.error(" - Fail to Set LAN CIDR for Local-Network, net=%s"%_lan.name())
                    bv.alert("Fail to Set LAN CIDR for Local-Network, net=%s"%_lan.name())
                    return False
            
            logger.info(" - SUCC: %s"%_item)
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            sleep(0.5)
            
            
            ## 4. Local Network Config
            _idx += 1
            _item = _ele[_idx]
            logger.info(" - %s"%_item)
            _mProg.set_index(_idx)
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            
            if not _in_band :
                _ret, _err = self.config_local_net(oc.VAL_DEF_HOST_LOCAL_BR, oc.VAL_DEF_HOST_LOCAL_IP, oc.VAL_DEF_HOST_LOCAL_MASK, _init_route_list)
                if not _ret :
                    logger.error(" - Fail to %s, err=%s"%( _item, _err ))
                    bv.alert("Fail to %s\n : err=%s"%( _item, _err ))
                    return False
                
                logger.info(" - SUCC: %s"%_item)
                _mProg.set_perc(100)
            else:
                logger.info(" - SKIP: %s"%_item)
                _mProg.set_perc(bv.G_STATUS_SKIP)
            
            bv.update_progBar(_mProg)
            sleep(0.5)
            
            
            ## 5. VIM Config
            _idx += 1
            _item = _ele[_idx]
            logger.info(" - %s"%_item)
            _mProg.set_index(_idx)
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            
            _n_dev, _n_ip, _n_mask, _n_gw = self._ob.get_host_main_ip()
            if _n_ip == None or str(_n_ip).strip() == "" :
                if _fake_ip == None :
                    logger.error(" - Fail to %s, No Public IP"%_item)
                    bv.alert("Fail to %s, No Public IP"%_item)
                    return False
                else:
                    _ret = bv.confirm_ok("No Public IP, Continue with Fake-IP[%s]?"%str(_fake_ip))
                    if _ret != bv.RET_OK:
                        logger.error(" - Fail to %s, No Public IP"%_item)
                        bv.alert("Fail to %s, No Public IP"%_item)
                        return False
                    else:
                        logger.warning(" - Fail to %s, No Public IP"%_item)
                        _host_ip = "127.0.0.1"
            else:
                _host_ip = _n_ip
            
            _ret, _err = self.update_vim(_mProg, _host_ip, _ob_info.vim_auth_user(), _ob_info.vim_auth_pass(), _ob_info.ovs_dpdk())
            if not _ret :
                logger.error(" - Fail to %s, err=%s"%( _item, _err ))
                bv.alert("Fail to %s\n : err=%s"%( _item, _err ))
                return False
            logger.info(" - SUCC: %s"%_item)
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            sleep(0.5)
            
            ## 6. Agent Config
            _idx += 1
            _item = _ele[_idx]
            logger.info(" - %s"%_item)
            _mProg.set_index(_idx)
            _mProg.inc(5)
            bv.update_progBar(_mProg, "VNFM Config")
            
            # VNFM
            _ret = self.config_vnfm(_ob_info.ob_id())
            if not _ret :
                logger.error(" - Fail to %s, VNFM Config Error"%_item)
                bv.alert("Fail to %s, VNFM Config Error"%_item)
                return False
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            
            self.set_onebox_services([oc.VAL_VNFM_NAME], False, _mProg)
            _ret, _err = self.set_onebox_services([oc.VAL_VNFM_NAME], True, _mProg)
            if not _ret :
                logger.error(" - Fail to %s, VNFM Restart Error, err=%s"%( _item, _err ))
                _ret = bv.confirm_ok("VNFM Restart Error.\nContinue First-Install?")
                if _ret != bv.RET_OK :
                    return False
            logger.info("   Config VNFM")
            _mProg.inc(5)
            bv.update_progBar(_mProg, "Mon-Agent Config")
            
            # ZBA
            _ret = self.config_mona(_ob_info.ob_id())
            if not _ret :
                logger.error(" - Fail to %s, MonAgent Config Error"%_item) 
                bv.alert("Fail to %s, MonAgent Config Error"%_item) 
                return False
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            
            self.set_onebox_services([oc.VAL_MONA_NAME], False, _mProg)
            _ret, _err = self.set_onebox_services([oc.VAL_MONA_NAME], True, _mProg)
            if not _ret :
                logger.error(" - Fail to %s, MonAgent Restart Error, err=%s"%( _item, _err ))
                _ret = bv.confirm_ok("MonAgent Restart Error.\nContinue First-Install?")
                if _ret != bv.RET_OK :
                    return False
            logger.info("   Config MonAgent")
            _mProg.inc(5)


            bv.update_progBar(_mProg, "NMSA Config")
            # NMSA
            _ret, _err = self.config_nmsa(_ob_info.ob_id())
            if not _ret :
                logger.warning(" - Fail to %s, NMSA Config Error, err=%s"%( _item, _err ))
                bv.alert("Fail to %s, NMSA Config Error\n : err=%s"%( _item, _err ))
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            
            self.set_onebox_services([oc.VAL_NMSA_NAME], False, _mProg)
            _ret, _err = self.set_onebox_services([oc.VAL_NMSA_NAME], True, _mProg)
            if not _ret :
                logger.error(" - Fail to %s, NMSA Restart Error, err=%s"%( _item, _err ))
                _ret = bv.confirm_ok("NMSA Restart Error.\nContinue First-Install?")
                if _ret != bv.RET_OK :
                    return False
            logger.info("   Config NMSA")
            _mProg.inc(5)


            bv.update_progBar(_mProg, "SMSA Config")
            # SMSA
            _ret, _err = self.config_smsa(_ob_info.ob_id())
            if not _ret :
                logger.warning(" - Fail to %s, SMSA Config Error, err=%s"%( _item, _err ))
                bv.alert("Fail to %s, SMSA Config Error\n : err=%s"%( _item, _err ))
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            
            self.set_onebox_services([oc.VAL_SMSA_NAME], False, _mProg)
            _ret, _err = self.set_onebox_services([oc.VAL_SMSA_NAME], True, _mProg)
            if not _ret :
                logger.error(" - Fail to %s, SMSA Restart Error, err=%s"%( _item, _err ))
                _ret = bv.confirm_ok("SMSA Restart Error.\nContinue First-Install?")
                if _ret != bv.RET_OK :
                    return False
            logger.info("   Config SMSA")
            _mProg.inc(5)



            bv.update_progBar(_mProg, "OneBox-Agent Config")
            
            # OBAgent
            _ret = _ob_info.saveToCfg()
            if not _ret :
                logger.error(" - Fail to %s, OneBox-Agent Config Error"%_item) 
                bv.alert("Fail to %s, OneBox-Agent Config Error"%_item) 
                return False
            _mProg.inc(5)
            bv.update_progBar(_mProg)
            
            if not _skip_oba_run:
                self.set_onebox_services([oc.VAL_OBA_NAME], False, _mProg)
                _ret, _err = self.set_onebox_services([oc.VAL_OBA_NAME], True, _mProg)
                if not _ret :
                    logger.error(" - Fail to %s, OneBox-Agent Restart Error, err=%s"%( _item, _err ))
                    _ret = bv.confirm_ok("OneBox-Agent Restart Error.\nContinue First-Install?")
                    if _ret != bv.RET_OK :
                        return False
            logger.info("   Config OneBox-Agent")
            
            ## finish
            logger.info(" - SUCC: %s"%_item)
            _mProg.set_perc(100)
            bv.update_progBar(_mProg)
            sleep(0.5)
            
            _mProg.fin()
            bv.update_progBar( _mProg )
            sleep(0.5)
            return True
        except Exception, e:
            logger.error(" - Fail to First-Install, item=%s, exc=%s"%( _item, str(e) ))
            logger.exception(e)
            bv.alert("Fail to First-Install, Unknown Error, item=%s\n : err=%s"%( _item, str(e) ))
            return False
    
    def update_vim(self, prog_base, new_endpoint_ip, vimUser, vimPass, _ovs_dpdk=False):
        ## IP Check
        if not self._ob.chk_ip(new_endpoint_ip) :
            logger.error("Fail to Update VIM IP, Invalid Public Endpoint IP, ip=%s"%str(new_endpoint_ip))
            return False, "Invalid Public Endpoint IP, ip=%s"%str(new_endpoint_ip)
        
        ## Update VIM IP 
        _updateHandler = self._vim.get_public_ip_changer(new_endpoint_ip, vimUser, vimPass, not _ovs_dpdk)
        _updateHandler.start()
        _init_prog = int(prog_base.perc())
        _msg = None
        if isinstance(prog_base, bv.ProgBarInfo) :
            _msg = "Update VIM-IP"
        while True :
            sleep(0.5)
            if not _updateHandler.is_fin() :
                _prg = _updateHandler.prog()
                _set_prg = _init_prog + int(round(float(_prg)/100*(100-_init_prog)))
                prog_base.set_perc(_set_prg)
                bv.update_progBar(prog_base, _msg)
            else:
                break
        
        return _updateHandler.result()
    
    def reset_vim_br(self, _br_list):
        return self._vim.reset_vim_bridge(_br_list)
    
    def reset_os_br(self):
        return self._os.reset_os_bridge()
    
    
    def switchToHost(self, mgmtList, wanList, prog_base=None):
        try:
            for _wan in wanList :
                _wanBr = _wan.bridge()
                _wanNic = _wan.nic()
                self._vim.del_br_port(_wanNic)
            
            ## VIM INIT & Bind Dev Kern
            self._ob.correct_nic_drv()
            
            for _mgmt in mgmtList :
                _mgmtBr = _mgmt.bridge()
                _mgmtNic = _mgmt.nic()
                self._os.del_br_if(_mgmtBr, _mgmtNic)
                self._os.if_down(_mgmtBr)
                if prog_base != None :
                    prog_base.inc(1)
                    bv.update_progBar(prog_base, "Reset OS-Bridge: br=%s, if=%s" % (str(_mgmtBr), str(_mgmtNic)))
            
            self._os.dhclient_down()
            
            _ret = self._os.del_def_route()
            if not _ret :
                logger.warning("Failed to Del Host-Def-Router")
            else:
                logger.debug("Succ: Del Host-Def-Router")
            
        except Exception, e:
            logger.exception(e)
            return False, "Exception to WAN-Switch to Host, exc=%s"%str(e)
            
        return True, None
    
    def switchToVNF(self, mgmtList, wanList, vnf_gw_ip, prog_base=None, _ovs_dpdk=False):
        _hostBr = self._ob.get_host_bridge()
        if _hostBr == None:
            return False, "Fail to Get Host Br"
        
        ## VIM INIT & Bind Dev Kern
        self._ob.correct_nic_drv()
        
        for brName in _hostBr :
            self._os.ifconfig_down(brName)
        
        self._os.dhclient_down()
        
        self._os.del_def_route()
        
        _ret = self._os.add_def_route(vnf_gw_ip)
        if not _ret :
            return False, "Fail to Add Host-Def-Router, gw=%s"%( vnf_gw_ip)
        else:
            logger.debug("Succ: Add Host-Def-Router, gw=%s"%(vnf_gw_ip))
        
        try:
            for _mgmt in mgmtList:
                _mgmtNic = _mgmt.nic()
                _mgmtBr = _mgmt.bridge()
                
                _wanBr = None
                for _wan in wanList :
                    if _mgmtNic == _wan.nic():
                        _wanBr = _wan.bridge()
                        break
                
                logger.debug("Wan-Switch %s to VNF(%s)" % (str(_mgmtNic), str(_wanBr)))
                _ret = self._os.del_br_if(str(_mgmtBr), str(_mgmtNic))
                if not _ret :
                    logger.warning("Fail to Del-BrLx-If, br=%s, nic=%s"%( str(_mgmtBr), str(_mgmtNic) ))
                else:
                    logger.debug("Succ to Del-BrLx-If, br=%s, nic=%s"%(str(_mgmtBr), str(_mgmtNic)))
                if prog_base != None :
                    prog_base.inc(1)
            sleep(10)
            
            for _wan in wanList :
                _wanBr = _wan.bridge()
                _wanNic = _wan.nic()
                _prev_ifs = self._vim.get_br_ifs(str(_wanBr))
                if type(_prev_ifs) == list and str(_wanNic) in _prev_ifs :
                    logger.debug("SKIP to Add-Ovs-Port, Already Exist, br=%s, nic=%s"%( str(_wanBr), str(_wanNic) ))
                    continue
                
                _ret = self._vim.add_br_port(str(_wanBr), str(_wanNic), _ovs_dpdk)
                if not _ret :
                    logger.warning("Fail to Add-Ovs-Port, br=%s, nic=%s"%( str(_wanBr), str(_wanNic) ))
                    return False, "Fail to Add-Ovs-Port, br=%s, nic=%s"%( str(_wanBr), str(_wanNic) )
                else:
                    logger.debug("Succ to Add-Ovs-Port, br=%s, nic=%s"%( str(_wanBr), str(_wanNic) ))
                
                if prog_base != None :
                    prog_base.inc(1)
                    bv.update_progBar(prog_base, "Wan-Switch %s to VNF(%s): OK!!!" % (str(_mgmtNic), str(_mgmtBr)))
        except Exception, e:
            logger.exception(e)
            return False, "Exception to WAN-Switch to VNF, exc=%s"%str(e)
            
        return True, None
    
    def set_onebox_services(self, services, start=True, prog_base=None):
        _mode = (lambda x: "start" if x else "stop")(start)
        
        try:
            for service in services:
                if prog_base != None :
                    prog_base.inc(1)
                    bv.update_progBar(prog_base, "%s service %s..." %( service, _mode ))
                svc = self._os.Service(service)
                if start :
                    if not svc.status() :
                        svc.start()
                else:
                    svc.stop()
                
                sleep(0.5)
                
                if svc.status() != start :
                    logger.warning("Fail to %s %s service" % (_mode, service)) 
                    return False, "Fail to %s %s service" % (_mode, service)
                else:
                    if prog_base != None :
                        prog_base.inc(1)
                        bv.update_progBar(prog_base, "%s service %s: OK!!!" % (service, _mode))
        except Exception, e:
            logger.exception(e)
            return False, "ERROR!!! Fail to Set OB Service, exc=%s"%str(e)
            
        return True, None

    def show_obinfo(self, ob_info):
        elements = []
        item_pos = 1
        
        # onebox_id
        onebox_id = ob_info.m_ob_id
        itm_onebox_id = ("One-Box ID", item_pos, 1, onebox_id, item_pos, 20, FIELD_LEN, INPUT_LEN, bv.FORM_ATTR_READONLY)
        elements.append(itm_onebox_id)
        
        # management mode
        in_band = ob_info.is_in_band()
        if in_band:
            str_mgmt_mode = "In-band"
        else:
            str_mgmt_mode = "Out-of-band"
        item_pos = item_pos + 1
        itm_mgmt_mode = ("Mode", item_pos, 1, str_mgmt_mode, item_pos, 20, FIELD_LEN, INPUT_LEN, bv.FORM_ATTR_READONLY)
        elements.append(itm_mgmt_mode)
        
        # mgmt/wan
        _idx = 0
        for emgmt in ob_info.mgmt_list() :
            _tail = (lambda x : "" if x == 0 else str(x))(_idx)
            item_pos = external_network_info(elements, emgmt, item_pos = item_pos, title="Management"+_tail)
            _idx = _idx + 1
        if not in_band :
            _idx = 0
            for ewan in ob_info.wan_list() :
                _tail = (lambda x : "" if x == 0 else str(x))(_idx)
                item_pos = external_network_info(elements, ewan, item_pos = item_pos, title="WAN"+_tail)
                _idx = _idx + 1
        
        # lan
        for _lan in ob_info.lan_net_list() :
            _lan_type = str(_lan.name()).upper()
            item_pos = internal_network_info(elements, _lan, item_pos = item_pos, title="%s LAN"%_lan_type)
        
        # extra-wan
        _evw_list = ob_info.extra_wan_list()
        if type(_evw_list) == list and len(_evw_list) > 0 :
            _idx = 0
            for _evw in _evw_list :
                item_pos = external_network_info(elements, _evw, item_pos = item_pos, title="EVWAN"+str(_idx))
                _idx = _idx + 1
        
        # vet
        str_vet_mode = "Normal"
        if ob_info.ovs_dpdk() :
            str_vet_mode = "OVS-DPDK"
        item_pos = item_pos + 1
        itm_vet_mode = ("VET Mode", item_pos, 1, str_vet_mode, item_pos, 20, FIELD_LEN, INPUT_LEN, bv.FORM_ATTR_READONLY)
        elements.append(itm_vet_mode)
        
        _ret = bv.show_mixform("Review", elements)
        if _ret == bv.RET_NO or _ret == bv.RET_ERR :
            return False
        else:
            return True
    
    def show_main_mgmt(self, _ob_id, _mnet):
        elements = []
        item_pos = 1
        
        # onebox_id
        itm_onebox_id = ("One-Box ID", item_pos, 1, _ob_id, item_pos, 20, FIELD_LEN, INPUT_LEN, bv.FORM_ATTR_READONLY)
        elements.append(itm_onebox_id)
        
        # management network info
        item_pos = external_network_info(elements, _mnet, item_pos = item_pos, title="Management")
            
        _ret = bv.show_mixform("Review", elements)
        if _ret == bv.RET_NO or _ret == bv.RET_ERR :
            return False
        else:
            return True
    
    def ip_type(self, title):
        '''
        return : oc.VAL_IP_TYPE_DHCP/VAL_IP_TYPE_STAT
        '''
        return bv.get_menu(title, [(oc.VAL_IP_TYPE_DHCP, 'Dynamic IP'), (oc.VAL_IP_TYPE_STAT, 'Static IP') ], _width=40)
    
    def ip_address(self, title, default_address="0.0.0.0", default_netmask="255.255.255.0", default_gateway="0.0.0.0"):
        _ret = bv.show_form(title, [
                                    ('Address', 1, 1, default_address, 1, 20, 20, 15),
                                    ('Netmask', 2, 1, default_netmask, 2, 20, 20, 15),
                                    ('Gateway', 3, 1, default_gateway, 3, 20, 20, 15)
                                ])
        if _ret == bv.RET_NO or _ret == bv.RET_ERR :
            return _ret
        try:
            _ip = str(_ret[0])
            _mask = str(_ret[1])
            _gw = str(_ret[2])
            IPv4Network("%s/%s"%(_ip, _mask))
            IPv4Network("%s/%s"%(_gw, _mask))
            return [_ip, _mask, _gw]
        except Exception, e:
            logger.error("Fail to Set IP Address, exc=%s"%str(e))
            logger.exception(e)
            return bv.RET_ERR
    
    def lan_ip_address(self, title, default_ip = "0.0.0.0", default_netmask = "255.255.255.0", _only_set_ip=False):
        _chs = [('Address', 1, 1, default_ip, 1, 20, 20, 15)]
        if not _only_set_ip :
            _chs.append(('Netmask', 2, 1, default_netmask, 2, 20, 20, 15))
        return bv.show_form(title, _chs)
    
    def set_extern_ip(self, _title, _net):
        '''
        return : _LinkedMenu._RET_BACK/_RET_OK/_RET_ERR
        '''
        _ret = self.ip_type(_title)
        if _ret == bv.RET_NO :
            return _LinkedMenu._RET_BACK
        elif _ret == bv.RET_ERR :
            logger.error("Fail to Select IP Type, Error Occur")
            bv.alert("Fail to Select IP Type\n: Error Occur")
            return _LinkedMenu._RET_ERR
        else :
            if _ret == oc.VAL_IP_TYPE_DHCP :
                _net.dhcp_on()
                return _LinkedMenu._RET_OK
            elif _ret == oc.VAL_IP_TYPE_STAT :
                while True:
                    if _net.ip() == None :
                        _ret = self.ip_address(_title+" : STATIC ")
                    else:
                        _ret = self.ip_address(_title + " : STATIC ", _net.ip(), _net.mask(), _net.gw())
                    
                    if _ret == bv.RET_NO :
                        return _LinkedMenu._RET_BACK
                    elif _ret == bv.RET_ERR :
                        logger.warning("Fail to Set IP Address, Error Occur")
                        bv.alert("Fail to Set IP Address\n: Error Occur")
                        continue
                
                    if type(_ret) == list and len(_ret) == 3 :
                        _net.dhcp_off(_ret[0], _ret[1], _ret[2])
                        return _LinkedMenu._RET_OK
                    else:
                        logger.warning("Fail to Set IP Address, Invalid IP Info, ip=%s"%str(_ret))
                        bv.alert("Fail to Set IP Address\n: Invalid IP Info, ip=%s"%str(_ret))
                        continue
            else:
                logger.error("Fail to Select IP Type, Unknown Type, type=%s"%str(_ret))
                bv.alert("Fail to Select IP Type\n: Unknown Type, type=%s"%str(_ret))
                return _LinkedMenu._RET_ERR
    
    def set_lan_ip(self, _title, _net, _only_ip=False):
        '''
        return : _LinkedMenu._RET_BACK/_RET_OK/_RET_ERR
        '''
        if _net.gw() == None :
            _ret = self.lan_ip_address(_title+" : STATIC ", _only_set_ip=_only_ip)
        else:
            _ret = self.lan_ip_address(_title + " : STATIC ", _net.gw(), _net.mask(), _only_set_ip=_only_ip)
        
        if _ret == bv.RET_NO :
            return _LinkedMenu._RET_BACK
        elif _ret == bv.RET_ERR :
            logger.error("Fail to Set LAN-IP Address, Error Occur")
            bv.alert("Fail to Set LAN-IP Address\n: Error Occur")
            return _LinkedMenu._RET_ERR
        
        if not _only_ip and type(_ret) == list and len(_ret) == 2 :
            try:
                IPv4Network(str(_ret[0])+"/"+str(_ret[1]))
                _net.change(_ret[0], _ret[1])
                return _LinkedMenu._RET_OK
            except Exception:
                logger.warning("Fail to Set LAN-IP Address, Invalid Address, addr=%s/%s"%( str(_ret[0]), str(_ret[1]) ))
                bv.alert("Invalid IP Address, Retry...")
                return _LinkedMenu._RET_BACK
        elif _only_ip and type(_ret) == list and len(_ret) == 1 :
            try:
                IPv4Network(str(_ret[0]))
                _net.change(_ret[0])
                return _LinkedMenu._RET_OK
            except Exception:
                logger.warning("Fail to Set LAN-IP Address, Invalid Address, ip=%s"%( str(_ret[0]) ))
                bv.alert("Invalid IP Address, Retry...")
                return _LinkedMenu._RET_BACK
        else:
            logger.error("Fail to Set LAN-IP Address, Invalid IP Info, ip=%s"%str(_ret))
            bv.alert("Fail to Set LAN-IP Address\n: Invalid IP Info, ip=%s"%str(_ret))
            return _LinkedMenu._RET_ERR
    
    def get_host_nic(self, _title, _used_nics, _multi_select=False, _link_chk=True, _conn_filter=False, permit_no_nic=False, _nic_model=None):
        '''
        return : _LinkedMenu._RET_XXX, nic name or list, mac or mac list, is_conn or conn list
        '''
        _avail_cnt = 0
        try:
            _available_nics = self._os.get_phy_if_list(_nic_model)
            _anics = {}
            _choice = []
            _isFirst = True
            for _anic in _available_nics :
                if _anic in _used_nics or _anic == None :
                    continue
                
                _mac = self._os.get_mac_address(_anic)
                if _mac == None :
                    logger.warning("Fail to Get MacAddress, nic=%s"%str(_anic))
                    continue
                
                _is_conn = None
                if _link_chk or _conn_filter : 
                    _is_conn = self._os.chk_link_conn(_anic)
                
                _anics[_anic] = ( _mac, _is_conn )
                _conn = (lambda x: "Connected" if x else 'Released')(_is_conn)
                _item = (lambda x: "%s [%s]"%(_mac, _conn) if x else _mac)(_link_chk)
                if _conn_filter :
                    if _is_conn == True :
                        if _multi_select :
                            _choice.append(( _anic, _item, _isFirst ))
                            _isFirst = False
                        else:
                            _choice.append(( _anic, _item ))
                            _isFirst = False
                        _avail_cnt += 1
                    else:
                        continue
                else:
                    if _multi_select :
                        _choice.append(( _anic, _item, _isFirst ))
                        _isFirst = False
                    else:
                        _choice.append(( _anic, _item ))
                        _isFirst = False
                    _avail_cnt += 1
            
            if not permit_no_nic and len(_choice) < 1:
                logger.error("Fail to Get Host Nics, No Available Nic")
                bv.alert("Fail to Get Host Nics, No Available Nic")
                return _LinkedMenu._RET_ERR, None, None, None, -1
            elif permit_no_nic and len(_choice) < 1 :
                logger.warning("Fail to Get Host Nics, No Available Nic")
                return _LinkedMenu._RET_OK, None, None, None, -1
            
            if _multi_select :
                _ret = bv.get_multi_choice_menu(_title, _choice)
            else:
                _ret = bv.get_menu(_title, _choice)
            
            if _ret == bv.RET_NO :
                return _LinkedMenu._RET_BACK, None, None, None, _avail_cnt
            elif _ret == bv.RET_ERR :
                return _LinkedMenu._RET_ERR, None, None, None, _avail_cnt
            else :
                _snic = _ret
                _smac = None
                _sconn = None
                
                if _multi_select :
                    _smac = []
                    _sconn = []
                    for _sn in _snic :
                        _smac.append(_anics[_sn][0])
                        _sconn.append(_anics[_sn][1])
                        _avail_cnt -= 1
                else:
                    _smac = _anics[_snic][0]
                    _sconn = _anics[_snic][1]
                    _avail_cnt -= 1
                
                return _LinkedMenu._RET_OK, _snic, _smac, _sconn, _avail_cnt
        except Exception, e:
            logger.error("Fail to Select Nic, exc=%s"%str(e))
            logger.exception(e)
            bv.alert("Fail to Get Host Nics, Unknown Error, exc=%s"%str(e))
            return _LinkedMenu._RET_ERR, None, None, None, _avail_cnt

    def get_usable_nics(self, _ob_info):
        import copy
        ## phy nic
        _available_nics = self._os.get_phy_if_list(_ob_info.hw_nic_model())
        _physical_nics = copy.deepcopy(_available_nics)
        _selected_nics = []
        # wan
        for _net in ( _ob_info.mgmt_list() + _ob_info.wan_list()) :
            _n_nic = _net.nic()
            if _n_nic != None and not _n_nic in _selected_nics :
                _selected_nics.append(_n_nic)
            if _n_nic in _available_nics :
                _available_nics.remove(_n_nic)
        
        # lan
        for _net in _ob_info.lan_net_list() :
            for _n_nic in _net.nics() :
                if _n_nic != None and not _n_nic in _selected_nics :
                    _selected_nics.append(_n_nic)
                if _n_nic in _available_nics :
                    _available_nics.remove(_n_nic)
        
        # evwan
        if type(_ob_info.extra_wan_list()) == list :
            for _evw in _ob_info.extra_wan_list() :
                _n_nic = _evw.nic()
                if _n_nic != None and not _n_nic in _selected_nics :
                    _selected_nics.append(_n_nic)
                if _n_nic in _available_nics :
                    _available_nics.remove(_n_nic)
        
        try:
            for _brName in self._os.get_br() :
                if _brName == None : continue
                
                _os_br_ifs = self._os.get_br_ifs(_brName)
                if _os_br_ifs == None : continue
                
                for _os_br_if in _os_br_ifs :
                    if _os_br_if == None or not _os_br_if in _physical_nics : continue
                    if not _os_br_if in _selected_nics :
                        _selected_nics.append(_os_br_if)
                        logger.warning(" - Add %s to Used-Nic, OS-BR Own, br=%s"%( str(_os_br_if), _brName ))
                    if _os_br_if in _available_nics :
                        _available_nics.remove(_os_br_if)
        except Exception, e:
            logger.warning(" - Fail to Get Nics, OS BR-IF Get Error, exc=%s"%str(e))
        
        try:
            for _brName in self._vim.get_br() :
                if _brName == None : continue
                
                _vim_br_ifs = self._vim.get_br_ifs(_brName)
                if _vim_br_ifs == None : continue
                
                for _vim_br_if in _vim_br_ifs :
                    if _vim_br_if == None or not _vim_br_if in _physical_nics : continue
                    if not _vim_br_if in _selected_nics :
                        _selected_nics.append(_vim_br_if)
                        logger.warning(" - Add %s to Used-Nic, VIM-BR Own, br=%s"%( str(_vim_br_if), _brName ))
                    if _vim_br_if in _available_nics :
                        _available_nics.remove(_vim_br_if)
        except Exception, e:
            logger.warning(" - Fail to Get Nics, VIM BR-IF Get Error, exc=%s"%str(e))
        
        return _available_nics, _selected_nics
    
    def to_txt_utm_delinfo(self, _delInfo):
        return self._vnf_utm.to_delinfo_txt(_delInfo)
    
    def get_utm_chk_list_for_new_wan_ip(self, _uip, _uid=None, _upass=None):
        return self._vnf_utm.chk_list_for_new_wan_ip(_uip, _uid, _upass)
    
    def create_chker_utm_new_wan_ip(self, _utm_ip, _wanNicList, prevStaticWanInfo, _uid=None, _upass=None):
        return self._vnf_utm.create_chk_new_wan_ip(_utm_ip, _wanNicList, prevStaticWanInfo, _uid, _upass)
    
    def get_utm_run_list_for_new_wan_ip(self, _uip, _uid=None, _upass=None):
        return self._vnf_utm.run_list_for_new_wan_ip(_uip, _uid, _upass)
    
    def create_runer_utm_new_wan_ip(self, utm_ip, 
                 _bak_file, _tmp_if_file, _tmp_dr_file, _tmp_ur_file, _tmp_rr_file, _tmp_arp_file,
                 newWanInfo, prevStaticWanInfo, utmID=None, utmPass=None):
        return self._vnf_utm.create_run_new_wan_ip(utm_ip, 
                 _bak_file, _tmp_if_file, _tmp_dr_file, _tmp_ur_file, _tmp_rr_file, _tmp_arp_file,
                 newWanInfo, prevStaticWanInfo, utmID, utmPass)
    
    def get_utm_chk_list_for_new_lan_ip(self):
        return self._vnf_utm.chk_list_for_new_lan_ip()
    
    def create_chker_utm_new_lan_ip(self, _utm_ip, _lan_nic, _wanNicList=None, _uid=None, _upass=None):
        return self._vnf_utm.create_chk_new_lan_ip(_utm_ip, _lan_nic, _wanNicList, _uid, _upass)
    
    def get_utm_run_list_for_new_lan_ip(self):
        return self._vnf_utm.run_list_for_new_lan_ip()
    
    def create_runer_utm_new_lan_ip(self, utm_ip, _bak_file, _new_lan_info, utmID=None, utmPass=None):
        return self._vnf_utm.create_run_new_lan_ip(utm_ip, _bak_file, _new_lan_info, utmID, utmPass)
    
    def is_same_state_for_utm_restore(self):
        return self._vnf_utm.is_same_state_for_restore()
    
    def create_runner_restore_utm(self, _vnf_ip, _bak_file):
        return self._vnf_utm.create_vnf_restore(_vnf_ip, _bak_file)

    def change_utm_wan_ip(self, utm_ip, newWanInfo, prevStaticWanInfo, utmID=None, utmPass=None):
        _title = "VNF WAN-IP Change"
        _utmProg = bv.MixedProgBarInfo(_title, self.get_utm_run_list_for_new_wan_ip(utm_ip, utmID, utmPass))
        
        _runner = self.create_runer_utm_new_wan_ip(utm_ip, 
                     oc.FILE_BAK_VNF_UTM, oc.FILE_TMP_UTM_IF, oc.FILE_TMP_UTM_DR, 
                     oc.FILE_TMP_UTM_UR, oc.FILE_TMP_UTM_RR, oc.FILE_TMP_UTM_ARP,
                     newWanInfo, prevStaticWanInfo, utmID, utmPass)
        _runner.start()
        logger.info(" - Start UTM WAN-IP Change, newip=%s, prevStaticWan=%s"%( str(newWanInfo), str(prevStaticWanInfo) ))
        
        _res = _runner.STAT_ERR
        _now_item = _runner.item()
        _rollback = False
        try:
            while True :
                _res, _items, _progs = _runner.get_info()
                if _res == _runner.STAT_ROLLBACK :
                    _rollback = True
                _idx = 0
                for _item in _items :
                    _utmProg.set_item(_item, _progs[_idx])
                    _idx += 1
                bv.update_progBar(_utmProg)
                _now_item = _runner.item()
                _now_rate = _runner.rate()
                logger.debug(" - %s, rate=%s"%( _now_item, str(_now_rate) ))
                
                if _res != _runner.STAT_RUN :
                    break
                
                sleep(2)
            
            _res, _return, _err = _runner.result()
            if _res == _runner.STAT_ROLLBACK :
                _rollback = True
            if _res != _runner.STAT_COMP :
                logger.error(" - Fail to %s[%s], status=%s, ret=%s, err=%s"%( _title, _now_item, str(_res), str(_return), str(_err) ))
            return _res, _err, _rollback
        except Exception, e:
            logger.error(" - Fail to %s[%s], exc=%s"%( _title, str(_now_item), str(e) ))
            logger.exception(e)
            return _res, str(e), _rollback


def create_lib(_obLib):
    return BTA_LIB(_obLib)
    





