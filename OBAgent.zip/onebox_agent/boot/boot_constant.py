#-*- coding: utf-8 -*-
'''
Created on 2017. 7. 25.

@author: ohhara
'''


_L_TITLE = "boot-agent"


BTA_M_BACK = "__back__"
BTA_M_EXIT = "__exit__"

BTA_C_OK = "__ok__"
BTA_C_NO = "__no__"
BTA_C_BACK = "__back__"
BTA_C_ERR = "__error__"

FUNC_TITLE = "__func_title__"

