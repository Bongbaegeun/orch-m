#-*- coding: utf-8 -*-
'''
Created on 2017. 7. 26.

@author: ohhara
'''

from ipaddr import IPv4Network
import ruamel.yaml, json

from onebox_agent.util import ob_constant as oc

def create_hw(_model, _cpu_info, _cpu_sock, _cpu_core_per_sock, _cpu_logical_core, _mem_size):
    _hw = _OB_HW()
    _hw.h_config(_model, _cpu_info, _cpu_sock, _cpu_core_per_sock, _cpu_logical_core, _mem_size)
    return _hw

def create_addr(_name, _type, _nic, _dhcp, _ip=None, _mask=None, _gw=None, _dev=None, _mac=None, _vlan=None):
    _addr = _Address(_name, _type)
    _addr.a_config(_nic, _dhcp, _ip, _mask, _gw, _dev, _mac, _vlan)
    return _addr

def create_net(_name, _type, _nic, _gw, _mask, _dev=None, _mac=None, _vlan=None):
    _net = _Network(_name, _type)
    _net.n_config(_nic, _gw, _mask, _dev, _mac, _vlan)
    return _net


def _getPass(_pass):
    return (lambda x: "None" if x == None else "exist")(_pass)



class _OB_SVR():
    
    def __init__(self, _name):
        self.__ip = None
        self.__port = None
        self.__name = _name
    
    def s_setting(self, _ip, _ports):
        '''
        _ports : list, tuple, int -> list or int
        '''
        IPv4Network("%s/32"%_ip)
        self.__ip = _ip
        self.__port = _ports
    
    def s_setting_cfg(self, svr_cfg):
        self.s_setting(str(svr_cfg['%s_ip'%self.__name]), svr_cfg['%s_port'%self.__name])
    
    def set_svr_cfg(self, _cfg):
        if self.__name != None and self.__ip != None and self.__port != None :
            _cfg['%s_ip'%self.__name] = self.__ip
            _cfg['%s_port'%self.__name] = self.__port
    
    def ip(self):
        return self.__ip
    
    def port(self):
        return self.__port
    
    def name(self):
        return self.__name
    
    def __str__(self):
        return "<name=%s, ip=%s, port=%s>"%( str(self.__name), str(self.__ip), str(self.__port) )
    def __repr__(self):
        return self.__str__()


class _VIM():
    
    def __init__(self, _vim_type):
        self.__tenant_name = None
        self.__tenant_user = None
        self.__tenant_pass = None
        
        self.__auth_user = None
        self.__auth_pass = None
        self.__vim_type = _vim_type

        # vim_version: kilo | queens
        self.__vim_version = None

    def v_setting(self, _tenant_name, _tenant_user, _tenant_pass, _auth_user, _auth_pass, _vim_version):
        self.__tenant_name = _tenant_name
        self.__tenant_user = _tenant_user
        self.__tenant_pass = _tenant_pass
        self.__auth_user = _auth_user
        self.__auth_pass = _auth_pass
        self.__vim_version = _vim_version
    
    def v_setting_cfg(self, vim_cfg):
        self.v_setting(
            str(vim_cfg['vim_tenant_name']),
            str(vim_cfg['vim_tenant_username']),
            str(vim_cfg['vim_tenant_passwd']),
            str(vim_cfg['keystone_user']),
            str(vim_cfg['keystone_pass']),
            str(vim_cfg['vim_version'])
        )
    
    def set_vim_cfg(self, _cfg):
        if self.__tenant_name != None and self.__tenant_user != None and self.__tenant_pass != None :
            _cfg['vim_tenant_name'] = self.__tenant_name
            _cfg['vim_tenant_username'] = self.__tenant_user
            _cfg['vim_tenant_passwd'] = self.__tenant_pass
        
        if self.__auth_user != None and self.__auth_pass != None :
            _cfg['keystone_user'] = self.__auth_user
            _cfg['keystone_pass'] = self.__auth_pass
        
    
    def tenant(self):       return self.__tenant_name
    def tenant_user(self):  return self.__tenant_user
    def tenant_pass(self):  return self.__tenant_pass
    def auth_user(self):    return self.__auth_user
    def auth_pass(self):    return self.__auth_pass
    def vim_type(self):     return self.__vim_type
    def vim_version(self):  return self.__vim_version
    
    def __str__(self):
        _tpass = _getPass(self.__tenant_pass)
        _apass = _getPass(self.__auth_pass)
        return "<type=%s, tenant_name=%s, tenant_user=%s, tenant_pass=%s, auth_user=%s, auth_pass=%s>"%(
                 str(self.__vim_type), str(self.__tenant_name), str(self.__tenant_user), str(_tpass),
                 str(self.__auth_user), str(_apass) )
    def __repr__(self):
        return self.__str__()


class _OB_HW():
    
    def __init__(self):
        self.__model = None
        self.__cpu_info = None
        self.__cpu_sock = None
        self.__cpu_core = None
        self.__cpu_thread = None
        self.__mem_size = None
        self.__nic_model = None
    
    def h_config(self, _model, _cpu_info, _cpu_sock, _cpu_core_per_sock, _cpu_logical_core, _mem_size, _nic_model=None):
        self.__model = _model
        self.__cpu_info = _cpu_info
        self.__cpu_sock = _cpu_sock
        self.__cpu_core = _cpu_core_per_sock
        self.__cpu_thread = _cpu_logical_core/(_cpu_core_per_sock*_cpu_sock)
        self.__mem_size = _mem_size
        self.__nic_model = _nic_model
    
    def h_config_cfg(self, hw_cfg):
        _nic_model = None
        if hw_cfg.has_key('nic_model'):
            if isinstance(hw_cfg['nic_model'], list) or isinstance(hw_cfg['nic_model'], tuple) :
                _nic_model = []
                for _tmp_nic_m in hw_cfg['nic_model'] :
                    _tmp_nic_mm = str(_tmp_nic_m).strip()
                    if _tmp_nic_mm != "" and not _tmp_nic_mm in _nic_model:
                        _nic_model.append(_tmp_nic_mm)
            else :
                _tmp_nic_m = str(hw_cfg['nic_model']).strip()
                if _tmp_nic_m != "" :
                    _nic_model = [_tmp_nic_m]
        self.h_config(str(hw_cfg['model']),
                     str(hw_cfg['cpu']), int(hw_cfg['num_cpus']), int(hw_cfg['num_cores_per_cpu']), int(hw_cfg['num_logical_cores']), 
                     int(hw_cfg['mem_size']), _nic_model)

    def hw_model(self):
        return self.__model

    def set_hw_cfg(self, _cfg):
        if self.__model != None :       _cfg['model'] = self.__model
        if self.__mem_size != None :    _cfg['mem_size'] = self.__mem_size
        if self.__cpu_info != None :    _cfg['cpu'] = self.__cpu_info
        if self.__cpu_sock != None and self.__cpu_core != None and self.__cpu_thread != None :
            _cfg['num_cpus'] = self.__cpu_sock
            _cfg['num_cores_per_cpu'] = self.__cpu_core
            _cfg['num_logical_cores'] = self.__cpu_thread*self.__cpu_core*self.__cpu_sock
        if type(self.__nic_model) == list:
            _cfg['nic_model'] = self.__nic_model
    
    def for_orchf(self):
        _logic_cores = self.__cpu_thread * self.__cpu_core * self.__cpu_sock
        return {'model':self.__model, 'cpu':self.__cpu_info, 'num_cpus':self.__cpu_sock, 
                'num_cores_per_cpu':self.__cpu_core, 'num_logical_cores':_logic_cores, 'mem_size':self.__mem_size}
    
    def nic_model_list(self):
        return self.__nic_model
    
    def __str__(self):
        return "<model=%s, cpu[info:%s, sock:%s, core:%s, thread:%s, mem_size=%s, nic_model=%s>"%(
                str(self.__model), str(self.__cpu_info), str(self.__cpu_sock), str(self.__cpu_core),
                str(self.__cpu_thread), str(self.__mem_size), str(self.__nic_model)  )
    def __repr__(self):
        return self.__str__()


class _UTM_INFO():
    
    def __init__(self):
        self.__local_ip = None
        self.__external_nic = None
        self.__id = None
        self.__pass = None
        self.__type = 'utm'
    
    def u_config(self, _local_ip, _external_nic, _id=None, _pass=None):
        IPv4Network("%s/32"%_local_ip)
        self.__local_ip = _local_ip
        self.__external_nic = _external_nic
        self.__id = _id
        self.__pass = _pass
    
    def u_config_cfg(self, vnf_cfg):
        _id = (lambda x: x['utm_id'] if x.has_key('utm_id') else None)(vnf_cfg)
        _pass = (lambda x: x['utm_pass'] if x.has_key('utm_pass') else None)(vnf_cfg)
        self.u_config(str(vnf_cfg['utm_local_mgmt_ip']), str(vnf_cfg['utm_external_nic']),
                      _id, _pass)
    
    def set_utm_cfg(self, _cfg):
        if self.__type != None :
            if self.__local_ip != None : _cfg['utm_local_mgmt_ip'] = self.__local_ip
            if self.__external_nic != None : _cfg['utm_external_nic'] = self.__external_nic
            # if self.__id != None : _cfg['utm_id'] = self.__id
            # if self.__pass != None : _cfg['utm_pass'] = self.__pass
    
    def set_utm(self, _vip, _vnic=None, _vid=None, _vpw=None):
        self.__local_ip = _vip
        if _vnic != None : self.__external_nic = _vnic
        if _vid != None : self.__id = _vid
        if _vpw != None : self.__pass = _vpw
    
    def local_ip(self):
        return self.__local_ip
    
    def vnf_id(self): return self.__id
    def vnf_pass(self): return self.__pass
    
    def __str__(self):
        _pass = _getPass(self.__pass)
        return "<type=%s, local_ip=%s, external_nic=%s, id=%s, pass=%s>"%( 
                str(self.__type), str(self.__local_ip), str(self.__external_nic), str(self.__id), str(_pass) )
    def __repr__(self):
        return self.__str__()


class _MON_AGENT():
    
    def __init__(self, _name):
        self.__daemon_name = None
        self.__chk_proc = None
        self.__name = _name
    
    def m_setting(self, _daemon_name, _chk_proc):
        self.__daemon_name = _daemon_name
        self.__chk_proc = _chk_proc
    
    def m_setting_cfg(self, mon_cfg):
        self.m_setting( str(mon_cfg['zba_name']), mon_cfg['zba_chk_proc'] )
    
    def set_mon_cfg(self, _cfg):
        if self.__daemon_name != None and self.__chk_proc != None :
            _cfg['zba_name'] = self.__daemon_name
            _cfg['zba_chk_proc'] = self.__chk_proc
    
    def daemon(self):
        return self.__daemon_name
    
    def chk_proc(self):
        return self.__chk_proc
    
    def __str__(self):
        return "<name=%s, daemon_name=%s, chk_proc=%s>"%( 
                str(self.__name), str(self.__daemon_name), str(self.__chk_proc) )
    def __repr__(self):
        return self.__str__()


class _Address():
    
    def __init__(self, _name, _type):
        self.__ip = None
        self.__mask = None
        self.__dhcp = None
        self.__gw = None
        # bridge
        self.__dev = None
        self.__mac = None
        # phy if
        self.__nic = None
        # todo
        # 1 or more or range
        self.__vlan = None
        
        self.__name = _name
        self.__type = _type
    
    def _get_val(self, _dict, _key):
        if _dict.has_key(_key) : return _dict[_key]
        else: return None
    
    def a_config(self, _nic, _dhcp, _ip=None, _mask=None, _gw=None, _dev=None, _mac=None, _vlan=None):
        if _ip == None or _ip == "" : self.__ip = None
        else:
            IPv4Network("%s/%s"%( _ip, _mask ))
            self.__ip = _ip
        self.__mask = _mask
        self.__dhcp = _dhcp
        if _gw != None and _gw != "" :
            IPv4Network("%s/%s"%( _gw, _mask ))
            self.__gw = _gw
        self.__dev = _dev
        self.__mac = _mac
        self.__nic = _nic
        self.__vlan = _vlan
        return self
    
    def a_config_cfg(self, net_cfg):
        self.a_config(net_cfg['%s_nic'%self.__type], bool(net_cfg['%s_ip_dhcp'%self.__type]),
                      self._get_val(net_cfg, '%s_ip'%self.__type), 
                      self._get_val(net_cfg, '%s_subnet'%self.__type), 
                      self._get_val(net_cfg, '%s_gateway'%self.__type), 
                      self._get_val(net_cfg, '%s_dev'%self.__type), 
                      self._get_val(net_cfg, '%s_mac'%self.__type), 
                      self._get_val(net_cfg, '%s_vlan'%self.__type))
        
        return self
    
    def set_addr_cfg(self, _cfg):
        _cfg['%s_dev'%self.__type] = self.__dev
        _cfg['%s_nic'%self.__type] = self.__nic
        _cfg['%s_ip_dhcp'%self.__type] = self.__dhcp
        _cfg['%s_mac'%self.__type] = self.__mac
        if self.__ip != None : _cfg['%s_ip'%self.__type] = self.__ip
        if self.__mask != None : _cfg['%s_subnet'%self.__type] = self.__mask
        if self.__gw != None : _cfg['%s_gateway'%self.__type] = self.__gw
        if self.__vlan != None : _cfg['%s_vlan'%self.__type] = self.__vlan
    
    def dhcp_on(self, _vlan=None):
        self.__dhcp = True
        self.__ip = None
        self.__mask = None
        self.__gw = None
        if _vlan != None : self.__vlan = _vlan
    
    def dhcp_off(self, _ip, _mask, _gw, _vlan=None):
        self.__dhcp = False
        self.__ip = _ip
        self.__mask = _mask
        self.__gw = _gw
        if _vlan != None : self.__vlan = _vlan
    
    def change(self, _dhcp, _ip, _mask, _gw, _vlan=None):
        self.__dhcp = _dhcp
        self.__ip = _ip
        self.__mask = _mask
        self.__gw = _gw
        if _vlan != None : self.__vlan = _vlan
        
    def change_nic(self, _src, _dst, _dst_mac=None):
        if type(self.__nic) == list :
            if _src in self.__nic :
                self.__nic.remove(_src)
            self.__nic.append(_dst)
        else:
            self.__nic = _dst
        
        if _dst_mac != None :
            self.__mac = _dst_mac
    
    def set_dev(self, _dev):
        self.__dev = _dev
    
    def set_mac(self, _mac):
        self.__mac = _mac
    
    def type(self): return self.__type
    def name(self): return self.__name
    
    def ip(self): return self.__ip
    def bridge(self): return self.__dev
    def is_dhcp(self): return self.__dhcp
    def mask(self): return self.__mask
    def gw(self): return self.__gw
    def mac(self): return self.__mac
    def vlan(self): return self.__vlan
    
    def nic(self): 
        if type(self.__nic) == list or type(self.__nic) == tuple : 
            if len(self.__nic) > 0 :
                return self.__nic[0]
            else:
                return None
        else: return self.__nic
    def nics(self):
        if type(self.__nic) == list or type(self.__nic) == tuple : return self.__nic
        elif type(self.__nic) == None : return []
        else: return [self.__nic]
    
    def __str__(self):
        return "<type=%s, name=%s, ip=%s, mask=%s, dhcp_on=%s, gw=%s, dev=%s, mac=%s, nic=%s, vlan=%s>"%( 
                str(self.__type), str(self.__name), str(self.__ip), str(self.__mask), str(self.__dhcp),
                str(self.__gw), str(self.__dev), str(self.__mac), str(self.__nic), str(self.__vlan) )
    def __repr__(self):
        return self.__str__()

class _Network(object):
    
    def __init__(self, _name, _type):
        self.__mask = None
        self.__gw = None
        # bridge
        self.__dev = None
        # phy if
        self.__nic = None
        # todo
        # 1 or more or range
        self.__vlan = None
        
        self.__name = _name
        self.__type = _type
    
    def _get_val(self, _dict, _key):
        if _dict.has_key(_key) : return _dict[_key]
        else: return None
    
    def n_config(self, _nic, _gw, _mask, _dev=None, _mac=None, _vlan=None):
        if _gw == None or str(_gw).strip() == '' :
            _gw = None
        else:
            IPv4Network("%s/%s"%( _gw, _mask ))
        self.__gw = _gw
        self.__mask = _mask
        self.__dev = _dev
        self.__mac = _mac
        self.__nic = ( None if _nic == None or _nic == '' else _nic)
        self.__vlan = _vlan
        return self
    
    def n_config_cfg(self, net_cfg):
        _gw = self._get_val(net_cfg, '%s_%s_gateway'%(self.__type, self.__name))
        _nics = net_cfg['%s_%s_nic'%(self.__type, self.__name)]
        if _nics == None :
            _niclist = None
        elif type(_nics) == str :
            if _nics.strip() == '':
                _niclist = []
            else:
                _niclist = _nics.replace(' ', '').split(',')
        else:
            _niclist = _nics
        self.n_config( _niclist, 
                      _gw,
                      self._get_val(net_cfg, '%s_%s_subnet'%(self.__type, self.__name)), 
                      self._get_val(net_cfg, '%s_%s_dev'%(self.__type, self.__name)), 
                      self._get_val(net_cfg, '%s_%s_mac'%(self.__type, self.__name)), 
                      self._get_val(net_cfg, '%s_%s_vlan'%(self.__type, self.__name)))
        return self
    
    def set_net_cfg(self, _cfg):
        if type(self.__nic) == tuple or type(self.__nic) == list :
            _cfg['%s_%s_nic'%(self.__type, self.__name)] = ','.join(self.__nic)
        else:
            _cfg['%s_%s_nic'%(self.__type, self.__name)] = ( "" if self.__nic == None else self.__nic)
        
        _cfg['%s_%s_gateway'%(self.__type, self.__name)] = self.__gw
        _cfg['%s_%s_subnet'%(self.__type, self.__name)] = self.__mask
        if self.__vlan != None : _cfg['%s_%s_vlan'%(self.__type, self.__name)] = self.__vlan
    
    def change(self, _gw, _mask=None, _vlan=None):
        self.__gw = _gw
        if _mask != None : self.__mask = _mask
        if _vlan != None : self.__vlan = _vlan
    
    def change_nic(self, _src, _dst, _dst_mac=None):
        if type(self.__nic) == list :
            if _src in self.__nic :
                self.__nic.remove(_src)
            self.__nic.append(_dst)
        else:
            self.__nic = _dst
    
    def type(self): return self.__type
    def name(self): return self.__name
    
    def bridge(self): return self.__dev
    def mask(self): return self.__mask
    def gw(self): return self.__gw
    def mac(self): return self.__mac
    def vlan(self): return self.__vlan
    
    def nic(self): 
        if type(self.__nic) == list or type(self.__nic) == tuple : 
            if len(self.__nic) > 0 :
                return self.__nic[0]
            else:
                return None
        else: return self.__nic
    def nics(self):
        if type(self.__nic) == list or type(self.__nic) == tuple : return list(self.__nic)
        elif self.__nic == None : return []
        else: return [self.__nic]
    
    def add_nics(self, _nic_list):
        if type(self.__nic) == list or type(self.__nic) == tuple :
            self.__nic = list(self.__nic) + _nic_list
        elif self.__nic == None : self.__nic = _nic_list
        else: 
            self.__nic = [self.__nic] + _nic_list
    
    def del_nics(self, _nic_list):
        self.__nic = self.nics()
        for _nn in _nic_list :
            try:
                if _nn in self.__nic :
                    self.__nic.remove(_nn)
            except Exception :
                continue
    
    def __str__(self):
        return "<type=%s, name=%s, gw=%s, mask=%s, dev=%s, mac=%s, nic=%s, vlan=%s>"%( 
                str(self.__type), str(self.__name), str(self.__gw), str(self.__mask),
                str(self.__dev), str(self.__mac), str(self.__nic), str(self.__vlan) )
    def __repr__(self):
        return self.__str__()



class _WAN_INFO():
    
    
    def __init__(self):
        self.__wan_switch = None
        
        self.__wan_mon_intv = None
        ## after sw-vnf, total timeout for chk init-vnf-conn
        self.__wan_sw_utm_wait_time = None
        ## after sw-vnf, retry-cnt per 1 cycle  for chk vnf-conn
        self.__wan_gw_chk_limit = None
        ## retry for wan-sw
        self.__wan_mon_retry_conn_vm_limit = None
        self.__wan_auto_fix = True
        
        self.__wan_conn_site = "kt.com"
        self.__wan_conn_site_port = 80
    
    def w_setting(self, _switch, _mon_intv, _sw_utm_wait_time, _gw_chk_limit, 
                  _mon_retry_conn_vm_limit, _wan_auto_fix=None, _conn_site=None, _conn_port=None):
        if _switch.lower() == "yes": self.__wan_switch = True
        else: self.__wan_switch = False
        self.__wan_mon_intv = _mon_intv
        self.__wan_sw_utm_wait_time = _sw_utm_wait_time
        self.__wan_gw_chk_limit = _gw_chk_limit
        self.__wan_mon_retry_conn_vm_limit = _mon_retry_conn_vm_limit
        if _wan_auto_fix != None :
            self.__wan_auto_fix = _wan_auto_fix
        if _conn_site != None :
            self.__wan_conn_site = _conn_site
        if _conn_port != None :
            self.__wan_conn_site_port = _conn_port
    
    def w_setting_cfg(self, _wan_cfg):
        _wan_auto_fix = (_wan_cfg['wan_auto_fix']) if _wan_cfg.has_key('wan_auto_fix') else None
        _conn_site = (str(_wan_cfg['wan_conn_site']) if _wan_cfg.has_key('wan_conn_site') else None)
        _conn_port = (int(_wan_cfg['wan_conn_site_port']) if _wan_cfg.has_key('wan_conn_site_port') else None)
        self.w_setting(str(_wan_cfg['wan_switch']), int(_wan_cfg['wan_monitor_interval']), 
                      int(_wan_cfg['wan_sw_utm_wait_time']), int(_wan_cfg['wan_gw_chk_count']), 
                      int(_wan_cfg['wan_monitor_retry_conn_vm_count']), _wan_auto_fix=_wan_auto_fix, _conn_site=_conn_site, _conn_port=_conn_port)
    
    def set_wan_cfg(self, _cfg):
        if self.__wan_switch != None and type(self.__wan_switch) == bool :
            _cfg['wan_switch'] = (lambda x: 'yes' if self.__wan_switch else "no")(self.__wan_switch)
        if self.__wan_mon_intv != None and type(self.__wan_mon_intv) == int :
            _cfg['wan_monitor_interval'] = int(self.__wan_mon_intv)
        if self.__wan_sw_utm_wait_time != None and type(self.__wan_sw_utm_wait_time) == int :
            _cfg['wan_sw_utm_wait_time'] = int(self.__wan_sw_utm_wait_time)
        if self.__wan_gw_chk_limit != None and type(self.__wan_gw_chk_limit) == int :
            _cfg['wan_gw_chk_count'] = int(self.__wan_gw_chk_limit)
        if self.__wan_mon_retry_conn_vm_limit != None and type(self.__wan_mon_retry_conn_vm_limit) == int :
            _cfg['wan_monitor_retry_conn_vm_count'] = int(self.__wan_mon_retry_conn_vm_limit)
        if self.__wan_auto_fix == False :
            _cfg['wan_auto_fix'] = self.__wan_auto_fix
        if self.__wan_conn_site != None and type(self.__wan_conn_site) == str :
            _cfg['wan_conn_site'] = self.__wan_conn_site
        if self.__wan_conn_site_port != None and type(self.__wan_conn_site_port) == int :
            _cfg['wan_conn_site_port'] = self.__wan_conn_site_port
    
    def conn_site(self):        return self.__wan_conn_site, self.__wan_conn_site_port
    def wan_mon_intv(self):     return self.__wan_mon_intv
    def wan_sw(self):           return self.__wan_switch
    def wait_time_for_init_vnf(self):return self.__wan_sw_utm_wait_time
    def retry_for_vnf(self):    return self.__wan_gw_chk_limit
    def wan_sw_retry(self):     return self.__wan_mon_retry_conn_vm_limit
    def wan_auto_fix(self):     return self.__wan_auto_fix
    
    def set_wan_sw(self, _sw):  self.__wan_switch = _sw
    
    def __str__(self):
        return "<wan_switch_on=%s, mon_intv=%s, sw_utm_wait_time=%s, gw_chk_limit=%s, mon_retry_conn_vm_limit=%s, wan_auto_fix=%s, conn_site=%s:%s>"%( 
                    str(self.__wan_switch), str(self.__wan_mon_intv), str(self.__wan_sw_utm_wait_time), str(self.__wan_gw_chk_limit), 
                    str(self.__wan_mon_retry_conn_vm_limit), str(self.__wan_auto_fix), str(self.__wan_conn_site), str(self.__wan_conn_site_port) )
    def __repr__(self):
        return self.__str__()


class _VET():
    
    
    def __init__(self):
        self.__vet_info = {}
    
    def vet_setting(self, _ovs_dpdk=None, _sriov=None):
        if isinstance(_ovs_dpdk, dict) :
            self.__vet_info[oc.VET_NAME_NET_OVS_DPDK] = _ovs_dpdk
        if isinstance(_sriov, dict) :
            self.__vet_info[oc.VET_NAME_NET_SRIOV] = _sriov
    
    def vet_setting_cfg(self, _cfg):
        _ovs_dpdk = None
        _sriov = None
        if _cfg.has_key(oc.VET_NAME_NET_OVS_DPDK) :
            _ovs_dpdk = _cfg[oc.VET_NAME_NET_OVS_DPDK]
        if _cfg.has_key(oc.VET_NAME_NET_SRIOV) :
            _sriov = _cfg[oc.VET_NAME_NET_SRIOV]
        
        self.vet_setting(_ovs_dpdk, _sriov)
    
    def set_vet_cfg(self, _cfg):
        if len(self.__vet_info.keys()) < 1 :
            if _cfg.has_key(oc.CFG_VET) : _cfg.pop(oc.CFG_VET)
        else:
            _cfg[oc.CFG_VET] = self.__vet_info
    
    def __str__(self):
        return "<%s>"%str(self.__vet_info)
    
    def __repr__(self):
        return self.__str__()
    
    def _set_vet(self, _ovs_dpdk=None, _sriov=None):
        if type(_ovs_dpdk) == dict :
            self.__vet_info[oc.VET_NAME_NET_OVS_DPDK] = _ovs_dpdk
        if type(_sriov) == dict :
            self.__vet_info[oc.VET_NAME_NET_SRIOV] = _sriov
    
    def _vet(self, _vet_type):
        return self.__vet_info.has_key(_vet_type)

class _PLUGIN():
    
    def __init__(self):
        self.__p_type = None
        # onebox_agent.plugin.vnf.axgate_utm_plugin
        self.__p_file = None
        self.__p_cfg = None
    
    def plugin_setting(self, _p_type, _p_file, _p_cfg=None):
        self.__p_type = _p_type
        self.__p_file = _p_file
        self.__p_cfg = json.loads(json.dumps(_p_cfg))
    
    def plugin_setting_cfg(self, _plugin_cfg):
        _p_type = _plugin_cfg[oc.CFG_PLUGIN_TYPE]
        _p_file = _plugin_cfg[oc.CFG_PLUGIN_FILE]
        _p_cfg = _plugin_cfg[oc.CFG_PLUGIN_CFG] if isinstance(_plugin_cfg, dict) and _plugin_cfg.has_key(oc.CFG_PLUGIN_CFG) else None
        
        self.plugin_setting(_p_type, _p_file, _p_cfg)
    
    def set_plugin_cfg(self, _plugin_cfg):
        _plugin_cfg[oc.CFG_PLUGIN_TYPE] = self.__p_type
        _plugin_cfg[oc.CFG_PLUGIN_FILE] = self.__p_file
        if isinstance(self.__p_cfg, dict) :
            _plugin_cfg[oc.CFG_PLUGIN_CFG] = self.__p_cfg
    
    def ptype(self):    return self.__p_type
    def file(self):     return self.__p_file
    def cfg(self):      return self.__p_cfg
    
    def __str__(self):
        return "<type=%s, file=%s, cfg=%s>"%( str(self.__p_type), str(self.__p_file), str(self.__p_cfg) )
    
    def __repr__(self):
        return self.__str__()


class OB_INFO():
    '''
    network : main_xxx를 m_xxx_net_list에 넣었기 때문에 main_xxx를 변경하면 m_xxx_net_list의 객체도 변경됨
    '''
    
    def __init__(self):
        self.c_version = oc.VAL_OB_VER
        
        self.m_ob_id = oc.VAL_DEF_OB_ID
        self.c_gVar = oc.VAL_DEF_GVAR
        self.m_in_band = None
        
        self.c_oba_port = 5556
        self.c_oba_proc_num = 1
        
        self.c_orchf_svr = _OB_SVR("orchf")
        self.c_orchm_svr = _OB_SVR("orchm")
        self.c_nms_svr = _OB_SVR("nms")
        
        self.c_zba_info =_MON_AGENT("zabbix-agent")
        
        self.c_url_vnfm_temp = None
        self.c_url_oba_temp = None
        self.c_url_vim_auth_temp = None
        
        self.m_url_vnfm = None
        self.m_url_oba = None
        self.m_url_vim_auth = None
        
        self.c_vim = _VIM(oc.VAL_VIM_TYPE_OSP)
        
        self.m_hw = _OB_HW()
        self.m_os = None
        self.m_utm = _UTM_INFO()
        self.m_vim_version = None
        
        self.c_noti_interval = None
        self.c_wan_info = _WAN_INFO()
        
        self.m_mgmt_idx = 0
        self.m_wan_idx = 0
        
        self.m_mgmt_list = []
        self.m_wan_list = []
        
        self.m_lan_net_list = []
        
        self.m_vet = None
        
        self.m_extra_vnf_wan = None
        
        self.m_plugin_list = None

        self.m_wan_host_connectivity_duration_time = None

        self.m_hw_models = []

    
    def loadByCfg(self, _oba_cfg, _boota=False):
        self.m_ob_id = str(_oba_cfg['onebox_id'])
        self.c_gVar = str(_oba_cfg['gVar'])
        self.m_in_band = not bool(_oba_cfg['out_of_band_mgmt'])

        self.m_hw.h_config_cfg(_oba_cfg)
        self.m_os = str(_oba_cfg['operating_system'])

        if not _oba_cfg.get('vim_version', ''):
            self.set_vim_version()
            _oba_cfg['vim_version'] = self.m_vim_version


        self.c_vim.v_setting_cfg(_oba_cfg)
        self.m_utm.u_config_cfg(_oba_cfg)

        self.c_oba_port = int(_oba_cfg['port'])
        self.c_oba_proc_num = int(_oba_cfg['procNum'])
        
        self.c_orchf_svr.s_setting_cfg(_oba_cfg)
        self.c_orchm_svr.s_setting_cfg(_oba_cfg)
        self.c_nms_svr.s_setting_cfg(_oba_cfg)
        
        self.c_zba_info.m_setting_cfg(_oba_cfg)
        
        self.c_url_vnfm_temp = str(_oba_cfg['vnfm_base_url_tmpl'])
        self.c_url_oba_temp = str(_oba_cfg['obagent_base_url_tmpl'])
        self.c_url_vim_auth_temp = str(_oba_cfg['vim_authurl_tmpl'])
        
        self.m_url_vnfm = str(_oba_cfg['vnfm_base_url'])
        self.m_url_oba = str(_oba_cfg['obagent_base_url'])
        self.m_url_vim_auth = str(_oba_cfg['vim_authurl'])

        try:
            self.c_noti_interval = int(_oba_cfg['refresh_interval'])
        except Exception:
            pass
        self.c_wan_info.w_setting_cfg(_oba_cfg)
        
        # Main Mgmt
        try:
            import importlib
            _os = importlib.import_module(_oba_cfg[oc.CFG_PLUGIN][oc.CFG_PLUGIN_OS])
        except Exception:
            from onebox_agent.plugin.obos import linux_plugin as _os

        _chk_mgmt_nic = _oba_cfg['mgmt_nic']
        mgmt_mac = None
        if _chk_mgmt_nic != None :
            mgmt_mac = _os.get_mac_address(_oba_cfg['mgmt_nic'])
        if mgmt_mac == None and not _boota :
            raise Exception("No Iterface Mac, nic=%s"%str(_oba_cfg['mgmt_nic']))
        _mmaddr = _Address("main_mgmt", oc.VAL_NET_TYPE_MGMT)
        _mmaddr.a_config(_oba_cfg['mgmt_nic'], bool(_oba_cfg['mgmt_ip_dhcp']),
                        _oba_cfg['mgmt_ip'], _oba_cfg['mgmt_subnet'], 
                        _oba_cfg['mgmt_gateway'], _oba_cfg['mgmt_dev'], 
                        mgmt_mac, None)
        
        # Main Wan
        if self.m_in_band :
            _mwanaddr = _Address("main_wan", oc.VAL_NET_TYPE_WAN)
            _mwanaddr.a_config(_oba_cfg['mgmt_nic'], bool(_oba_cfg['mgmt_ip_dhcp']),
                               _oba_cfg['mgmt_ip'], _oba_cfg['mgmt_subnet'], 
                               _oba_cfg['mgmt_gateway'], _oba_cfg['br_vm'], 
                               mgmt_mac, None)
        else:
            _mwanaddr = _Address("main_wan", oc.VAL_NET_TYPE_WAN)
            _mwanaddr.a_config(_oba_cfg['wan_nic'], bool(_oba_cfg['wan_ip_dhcp']),
                               _oba_cfg['wan_ip'], _oba_cfg['wan_subnet'], 
                               _oba_cfg['wan_gateway'], _oba_cfg['br_vm'], 
                               _oba_cfg['svc_nic_mac'], None)
        
        # Extra Mgmt
        self.m_mgmt_list.append(_mmaddr)
        if _oba_cfg.has_key('extra_mgmt') :
            for _eMgmt in _oba_cfg['extra_mgmt'] :
                _emNic = _eMgmt['mgmt_nic']
                if _emNic == _mmaddr.nic() :
                    continue
                _emNet = _Address("extra_mgmt", oc.VAL_NET_TYPE_MGMT).a_config_cfg(_eMgmt)
                self.m_mgmt_list.append(_emNet)
        
        # Extra Wan
        self.m_wan_list.append(_mwanaddr)
        if _oba_cfg.has_key('extra_wan') :
            for _eWan in _oba_cfg['extra_wan'] :
                _ewNic = _eWan['wan_nic']
                if _ewNic == _mwanaddr.nic() :
                    continue
                _ewNet = _Address("extra_wan", oc.VAL_NET_TYPE_WAN).a_config_cfg(_eWan)
                self.m_wan_list.append(_ewNet)
        
        # LAN
        _lan_list = []
        for _lanKey in _oba_cfg.keys():
            if _lanKey.find(oc.VAL_NET_TYPE_LAN+"_") == 0 :
                lan_name = _lanKey.split('_')[1]
                if not lan_name in _lan_list :
                    _lan_list.append(lan_name)
        
        for _lan_name in _lan_list :
            _lNet = _Network(_lan_name, oc.VAL_NET_TYPE_LAN).n_config_cfg(_oba_cfg)
#             if _lNet.nics() == None or len(_lNet.nics()) == 0 :
#                 continue
            self.m_lan_net_list.append(_lNet)
        
        # VET
        if _oba_cfg.has_key(oc.CFG_VET) and isinstance(_oba_cfg[oc.CFG_VET], dict) and len(_oba_cfg[oc.CFG_VET].keys()) > 0 :
            self.m_vet = _VET()
            _str_json = json.dumps(_oba_cfg[oc.CFG_VET])
            self.m_vet.vet_setting_cfg(json.loads(_str_json))
        
        # extra vnf wan
        if _oba_cfg.has_key(oc.CFG_EXTRA_VNF_WAN) and isinstance(_oba_cfg[oc.CFG_EXTRA_VNF_WAN], list) and len(_oba_cfg[oc.CFG_EXTRA_VNF_WAN]) > 0 :
            self.m_extra_vnf_wan = []
            for _evwan in _oba_cfg[oc.CFG_EXTRA_VNF_WAN] :
                _addr = _Address("extra_vnf_wan", oc.VAL_NET_TYPE_EVWAN).a_config_cfg(_evwan)
                self.m_extra_vnf_wan.append(_addr)
        
        # plugin
        _os_p_cfg = None
        if _oba_cfg.has_key(oc.CFG_PLUGIN) and isinstance(_oba_cfg[oc.CFG_PLUGIN], list) :
            for _pinfo in _oba_cfg[oc.CFG_PLUGIN] :
                try:
                    _mplugin = _PLUGIN()
                    _mplugin.plugin_setting_cfg(_pinfo)
                    if type(self.m_plugin_list) != list :
                        self.m_plugin_list = []
                    self.m_plugin_list.append(_mplugin)
                except Exception, e :
                    print "Fail to Load Plugin, info=%s, exc=%s"%(str(_pinfo), str(e))
                    pass

        if ("wan_host_connectivity_duration_time" in _oba_cfg) is True:
            self.m_wan_host_connectivity_duration_time = int(_oba_cfg["wan_host_connectivity_duration_time"])
        else:
            self.m_wan_host_connectivity_duration_time = int(oc.DEFAULT_WAN_HOST_CONNECTIVITY_DURATION_TIME)

        # HW models(supported models)
        if _oba_cfg.has_key('hw_models'):
            for _offset in range(0, len(_oba_cfg['hw_models'])):
                self.m_hw_models.append(_oba_cfg['hw_models'][_offset])

        return self
    
    def loadByFile(self, fName, _boota=False):
        with open(fName, "r") as f:
            _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
        self.loadByCfg(_oba_cfg, _boota)
        return self
    
    def sync_internet(self, mgmtToWan=True, _logger=None):
        '''
        main_mgmt와 main_wan 설정,
        IN-BAND일 경우, MGMT와 WAN 동기화
        mgmtToWan : 동기화 기준이 mgmt 일 경우 True, wan 일 경우, False
        return : True/False
        '''
        try:
            if self.m_in_band:
                if mgmtToWan :
                    _main_list = self.m_mgmt_list
                    _target_list = self.m_wan_list
                    self.m_wan_idx = self.m_mgmt_idx
                    _pfx_name = "wan"
                    _net_type = oc.VAL_NET_TYPE_WAN
                else:
                    _main_list = self.m_wan_list
                    _target_list = self.m_mgmt_list
                    self.m_mgmt_idx = self.m_wan_idx
                    _pfx_name = "mgmt"
                    _net_type = oc.VAL_NET_TYPE_MGMT
                
                _new_list = []
                _m_idx = 0
                for _mnet in _main_list :
                    
                    _synced = False
                    for _tnet in _target_list :
                        if _mnet.mac() == _tnet.mac() :
                            _tnet.change(_mnet.is_dhcp(), _mnet.ip(), _mnet.mask(), _mnet.gw(), _mnet.vlan())
                            _new_list.append(_tnet)
                            _synced = True
                            break
                    
                    if not _synced :
                        if _logger != None : _logger.warning("Fail to Sync Internet, net=%s"%str(_mnet))
                        _ntnet = create_addr("%s-%s"%(_pfx_name, str(_m_idx)), _net_type, _mnet.nic(), _mnet.is_dhcp(), _mnet.ip(), _mnet.mask(), _mnet.gw(), oc.VAL_DEF_VI_WAN_BR_LIST[_m_idx], _mnet.mac(), _mnet.vlan())
                        _new_list.append(_ntnet)
                    
                    _m_idx += 1
                
                if mgmtToWan :
                    self.m_wan_list = _new_list
                else:
                    self.m_mgmt_list = _new_list
                return True
            else:
                return True
        except Exception, e:
            if _logger != None : _logger.error("Fail to Sync Internet, exc=%s"%str(e))
            if _logger != None : _logger.exception(e)
            return False
    
    def _set_str_val(self, _cfg, _key, _val):
        if _val != None and str(_val).strip() != "" :
            _cfg[_key] = _val
    
    def saveToCfg(self, _oba_cfg_file=oc.FILE_OBA_CONF):
        '''
        return : True/False
        '''
        
        with open(_oba_cfg_file, "r") as f:
            _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
        
        if _oba_cfg.has_key('version') :
            _oba_cfg['version'] = self.c_version
        
        self._set_str_val(_oba_cfg, 'onebox_id', self.m_ob_id)
#         self._set_str_val(_oba_cfg, 'gVar', self.c_gVar)
        if self.m_in_band == None :
            _oba_cfg['out_of_band_mgmt'] = None
        else:
            _oba_cfg['out_of_band_mgmt'] = (lambda x: 0 if x else 1)(self.m_in_band)
        
        
#         if self.c_oba_port != None :_oba_cfg['port'] = self.c_oba_port
#         if self.c_oba_proc_num != None :_oba_cfg['procNum'] = self.c_oba_proc_num
        
#         self.c_orchf_svr.set_svr_cfg(_oba_cfg)
#         self.c_orchm_svr.set_svr_cfg(_oba_cfg)
#         self.c_nms_svr.set_svr_cfg(_oba_cfg)
        
#         self.c_zba_info.set_mon_cfg(_oba_cfg)
        
#         self._set_str_val(_oba_cfg, "vnfm_base_url_tmpl", self.c_url_vnfm_temp)
#         self._set_str_val(_oba_cfg, "obagent_base_url_tmpl", self.c_url_oba_temp)
#         self._set_str_val(_oba_cfg, "vim_authurl_tmpl", self.c_url_vim_auth_temp)
        
        self._set_str_val(_oba_cfg, "vnfm_base_url", self.m_url_vnfm)
        self._set_str_val(_oba_cfg, "obagent_base_url", self.m_url_oba)
        self._set_str_val(_oba_cfg, "vim_authurl", self.m_url_vim_auth)
        self._set_str_val(_oba_cfg, oc.CFG_VIM_VERSION, self.m_vim_version)

#         self.c_vim.set_vim_cfg(_oba_cfg)
        
        self.m_hw.set_hw_cfg(_oba_cfg)
        self._set_str_val(_oba_cfg, 'operating_system', self.m_os)
        self.m_utm.set_utm_cfg(_oba_cfg)
        
#         self.c_wan_info.set_wan_cfg(_oba_cfg)
        if self.m_in_band :
            _oba_cfg['wan_switch'] = ("yes" if self.c_wan_info.wan_sw() else "no")
        else:
            _oba_cfg['wan_switch'] = "no"
        
        _oba_cfg['mgmt_nic'] = self.m_mgmt_list[self.m_mgmt_idx].nic()
        _oba_cfg['mgmt_ip_dhcp'] = self.m_mgmt_list[self.m_mgmt_idx].is_dhcp()
        _oba_cfg['mgmt_ip'] = self.m_mgmt_list[self.m_mgmt_idx].ip()
        _oba_cfg['mgmt_subnet'] = self.m_mgmt_list[self.m_mgmt_idx].mask()
        _oba_cfg['mgmt_gateway'] = self.m_mgmt_list[self.m_mgmt_idx].gw()
        _oba_cfg['mgmt_dev'] = self.m_mgmt_list[self.m_mgmt_idx].bridge()
        
        _oba_cfg['br_host'] = self.m_mgmt_list[self.m_mgmt_idx].bridge()
        
        _oba_cfg['public_ip'] = self.m_wan_list[self.m_wan_idx].ip()
        _oba_cfg['br_vm'] = self.m_wan_list[self.m_wan_idx].bridge()
        _oba_cfg['svc_nic'] = self.m_wan_list[self.m_wan_idx].nic()
        _oba_cfg['svc_nic_mac'] = self.m_wan_list[self.m_wan_idx].mac()
        
        if not self.m_in_band :
            _oba_cfg['wan_nic'] = self.m_wan_list[self.m_wan_idx].nic()
            _oba_cfg['wan_ip_dhcp'] = self.m_wan_list[self.m_wan_idx].is_dhcp()
            _oba_cfg['wan_ip'] = self.m_wan_list[self.m_wan_idx].ip()
            _oba_cfg['wan_subnet'] = self.m_wan_list[self.m_wan_idx].mask()
            _oba_cfg['wan_gateway'] = self.m_wan_list[self.m_wan_idx].gw()
        
        _oba_cfg[oc.CFG_EXTRA_MGMT] = []
        for _em in self.m_mgmt_list :
            _emcfg = {}
            _em.set_addr_cfg(_emcfg)
            _oba_cfg[oc.CFG_EXTRA_MGMT].append(_emcfg)
        
        _oba_cfg[oc.CFG_EXTRA_WAN] = []
        for _ew in self.m_wan_list :
            _ewcfg = {}
            _ew.set_addr_cfg(_ewcfg)
            _oba_cfg[oc.CFG_EXTRA_WAN].append(_ewcfg)
        
        for _lan in self.m_lan_net_list :
            _lan.set_net_cfg(_oba_cfg)
        
        # VET
        if self.m_vet == None :
            if _oba_cfg.has_key(oc.CFG_VET) : _oba_cfg.pop(oc.CFG_VET)
        else:
            self.m_vet.set_vet_cfg(_oba_cfg)
        
        # extra vnf wan
        if type(self.m_extra_vnf_wan) == list and len(self.m_extra_vnf_wan) > 0 :
            _oba_cfg[oc.CFG_EXTRA_VNF_WAN] = []
            for _evwan in self.m_extra_vnf_wan :
                _evwcfg = {}
                _evwan.set_addr_cfg(_evwcfg)
                _oba_cfg[oc.CFG_EXTRA_VNF_WAN].append(_evwcfg)
        else:
            if _oba_cfg.has_key(oc.CFG_EXTRA_VNF_WAN):
                _oba_cfg.pop(oc.CFG_EXTRA_VNF_WAN)
        
        # PLUGIN
        if type(self.m_plugin_list) == list and len(self.m_plugin_list) > 0:
            _plist = []
            for _pinfo in self.m_plugin_list:
                _pcfg = {}
                _pinfo.set_plugin_cfg(_pcfg)
                _plist.append(_pcfg)
            _oba_cfg[oc.CFG_PLUGIN] = _plist
        else:
            if _oba_cfg.has_key(oc.CFG_PLUGIN):
                _oba_cfg.pop(oc.CFG_PLUGIN)

        ## save
        with open(_oba_cfg_file, 'w') as f:
            f.write(ruamel.yaml.dump(_oba_cfg, Dumper=ruamel.yaml.RoundTripDumper))

        # update FILE_HW_MODEL
        with open(oc.FILE_HW_MODEL, 'w') as fm:
            fm.write(_oba_cfg[oc.CFG_PLUGIN_CFG_MD])
        
        return True
    
    
    def ob_id(self):            return self.m_ob_id
    def is_in_band(self):       return self.m_in_band
    def mgmt_list(self):        return self.m_mgmt_list
    def add_mgmt(self, _mgmt):  self.m_mgmt_list.append(_mgmt)
    def wan_list(self):         return self.m_wan_list
    def wan_mac_list(self):
        _mac = []
        for _net in ( self.m_mgmt_list + self.m_wan_list ) :
            _nmac = _net.mac()
            if _nmac == None : continue
            if str(_nmac).strip() == "" : continue
            if _nmac in _mac : continue
            else:
                _mac.append(_nmac)
        return _mac
    def wan_idx(self):          return self.m_wan_idx
    def add_wan(self, _wan):    self.m_wan_list.append(_wan)
    def set_wan_list(self, _wan_list):
        _prev_m_wan = self.m_wan_list[self.m_wan_idx]
        _set_main = False
        _m_wan_idx = 0
        for _nwan in _wan_list :
            if _nwan.nic() == _prev_m_wan.nic() :
                self.m_wan_idx = _m_wan_idx
                _set_main = True
                break
            _m_wan_idx += 1
        if not _set_main :
            self.m_wan_idx = 0
        
        self.m_wan_list = _wan_list
        if self.m_in_band :
            _n_mgmt_list = []
            _m_idx = 0
            for _w_net in _wan_list :
                _m_net = create_addr("mgmt-%s"%str(_m_idx), oc.VAL_NET_TYPE_MGMT, _w_net.nic(), _w_net.is_dhcp(), 
                            _w_net.ip(), _w_net.mask(), _w_net.gw(), oc.VAL_DEF_OS_BR_LIST[_m_idx], 
                            _w_net.mac(), _w_net.vlan())
                _n_mgmt_list.append(_m_net)
                _m_idx += 1
            self.m_mgmt_idx = self.m_wan_idx
            self.m_mgmt_list = _n_mgmt_list
    
    def extra_wan_list(self):   return self.m_extra_vnf_wan
    def add_extra_wan(self, _evw_list):
        if type(self.m_extra_vnf_wan) != list :
            self.m_extra_vnf_wan = []
        if type(_evw_list) == list :
            self.m_extra_vnf_wan += _evw_list
    def del_extra_wan(self, _br_list):
        if type(self.m_extra_vnf_wan) == list and type(_br_list) == list :
            _del_wan = []
            for _evw in self.m_extra_vnf_wan:
                if _evw.bridge() in _br_list :
                    _del_wan.append(_evw)
            for _dwan in _del_wan :
                self.m_extra_vnf_wan.remove(_dwan)
        
        if type(self.m_extra_vnf_wan) != list or len(self.m_extra_vnf_wan) < 1 :
            self.m_extra_vnf_wan = None
    
    def lan_net_list(self):     return self.m_lan_net_list
    def lan_name_list(self):
        _lan_name = []
        for _lan in self.m_lan_net_list :
            if not _lan.name() in _lan_name :
                _lan_name.append(_lan.name())
        return _lan_name
    
    def lan_xnet(self, _name):
        for _lan in self.m_lan_net_list :
            if _lan.name() == _name :
                return _lan
        return None
    
    def hw_nic_model(self):
        return self.m_hw.nic_model_list()
    
    def utm_local_ip(self):     return self.m_utm.local_ip()
    def utm_id(self):           return self.m_utm.vnf_id()
    def utm_pass(self):         return self.m_utm.vnf_pass()
    def set_utm_info(self, _ip, _ext_nic=None, _id=None, _pw=None):
        self.m_utm.set_utm(_ip, _ext_nic, _id, _pw)
    
    def vim_tenant(self):       return self.c_vim.tenant()
    def vim_tenant_user(self):  return self.c_vim.tenant_user()
    def vim_tenant_pass(self):  return self.c_vim.tenant_pass()
    def vim_auth_user(self):    return self.c_vim.auth_user()
    def vim_auth_pass(self):    return self.c_vim.auth_pass()
    def url_vim_auth(self, _mip):
        _mip = ( "" if _mip == None else _mip)
        return self.c_url_vim_auth_temp.replace("mgmt_ip", _mip)
    
    def oba_port(self):         return self.c_oba_port
    
    def noti_intv(self):        return self.c_noti_interval
    def wan_conn_site(self):    return self.c_wan_info.conn_site()
    
    def orchm_site(self):        return self.c_orchm_svr.ip(), self.c_orchm_svr.port()
    def orchf_site(self):        return self.c_orchf_svr.ip(), self.c_orchf_svr.port()
    
    def vim_for_orchf(self, _mip):
        _auth_url = self.url_vim_auth(_mip)
        _vim_type = ( oc.VAL_VIM_TYPE_OSP_PREV  if self.c_vim.vim_type() == oc.VAL_VIM_TYPE_OSP else self.c_vim.vim_type() )
        _tname = self.c_vim.tenant()
        _tuser = self.c_vim.tenant_user()
        _tpass = self.c_vim.tenant_pass()
        _tver = self.c_vim.vim_version()
        return {'vim_type': _vim_type,
                'vim_authurl':_auth_url,
                'vim_tenant_name':_tname,
                'vim_tenant_username':_tuser,
                'vim_tenant_passwd':_tpass,
                'vim_version':_tver
                }
    
    def url_vnfm(self, _mip):
        _mip = ( "" if _mip == None else _mip)
        return self.c_url_vnfm_temp.replace("mgmt_ip", _mip)
    def vnfm_for_orchf(self, _mip): return {'base_url': self.url_vnfm(_mip)}
    
    def url_oba(self, _mip):
        _mip = ( "" if _mip == None else _mip)
        return self.c_url_oba_temp.replace("mgmt_ip", _mip)
    def oba_for_orchf(self, _mip):  return {'base_url':self.url_oba(_mip), 'version':oc.VAL_OB_VER}
    
    def set_vet_mode(self, _ovs_dpdk=None, _sriov=None):
        if type(_ovs_dpdk) != dict and type(_sriov) != dict :
            self.m_vet = None
        else:
            if self.m_vet == None :
                self.m_vet = _VET()
            self.m_vet._set_vet(_ovs_dpdk, _sriov)
    
    def ovs_dpdk(self):
        if self.m_vet == None : return False
        else:
            return self.m_vet._vet(oc.VET_NAME_NET_OVS_DPDK)
    
    def plugin_list(self):      return self.m_plugin_list
    def plugin_list_extra(self):
        _plist = None
        if type(self.m_plugin_list) == list :
            _plist = []
            for _pinfo in self.m_plugin_list:
                if not str(_pinfo.ptype()).lower() in [oc.CFG_PLUGIN_OS, oc.CFG_PLUGIN_VIM, oc.CFG_PLUGIN_UTM] :
                    _plist.append(_pinfo)
        return _plist
    
    def plugin_file_os(self):       return self._plugin_file(oc.CFG_PLUGIN_OS)
    def plugin_file_vim(self):      return self._plugin_file(oc.CFG_PLUGIN_VIM)
    def plugin_file_utm(self):      return self._plugin_file(oc.CFG_PLUGIN_UTM)
    def plugin_file_evnf(self):     return self._plugin_file("extra")
    def _plugin_file(self, _ptype):
        _plist = None
        if type(self.m_plugin_list) == list : 
            for _pinfo in self.m_plugin_list:
                if _ptype == "extra":
                    if not str(_pinfo.ptype()).lower() in [oc.CFG_PLUGIN_OS, oc.CFG_PLUGIN_VIM, oc.CFG_PLUGIN_UTM] :
                        if type(_plist) != list : 
                            _plist = []
                        _plist.append(_pinfo.file())
                else:
                    if str(_pinfo.ptype()).lower() == str(_ptype).lower() :
                        return _pinfo.file()
        if _ptype == "extra":
            return _plist
        else:
            return None
    
    def has_plugin(self, _pfile):
        if type(self.m_plugin_list) == list : 
            for _evp in self.m_plugin_list :
                if _evp.file() == _pfile:
                    return True
        
        return False
    
    def get_plugin_type(self, _pfile):
        if _pfile == None : return None
        if type(self.m_plugin_list) == list : 
            for _evp in self.m_plugin_list :
                if _evp.file() == _pfile:
                    return _evp.ptype()
        return None
    
    def get_plugin_cfg(self, _pfile):
        if _pfile == None : return None
        if type(self.m_plugin_list) == list : 
            for _evp in self.m_plugin_list :
                if _evp.file() == _pfile:
                    return _evp.cfg()
        return None
    
    def set_plugin_utm(self, _pfile, _pcfg):
        if type(self.m_plugin_list) != list :
            self.m_plugin_list = []
        
        _del_utm = []
        for _evp in self.m_plugin_list :
            if str(_evp.ptype()).lower() == oc.CFG_PLUGIN_UTM :
                _del_utm.append(_evp)
        
        for _du in _del_utm :
            self.m_plugin_list.remove(_du)
        
        _upl = _PLUGIN()
        _upl.plugin_setting(oc.CFG_PLUGIN_UTM, _pfile, _pcfg)
        self.m_plugin_list.append(_upl)
    
    def set_plugin_noutm(self):
        if type(self.m_plugin_list) != list :
            self.m_plugin_list = []

        _del_utm = []
        for _evp in self.m_plugin_list :
            if str(_evp.ptype()).lower() == oc.CFG_PLUGIN_UTM :
                _del_utm.append(_evp)

        for _du in _del_utm :
            self.m_plugin_list.remove(_du)

        _upl = _PLUGIN()
        _upl.plugin_setting(oc.CFG_PLUGIN_UTM, oc.PLUGIN_NO_UTM)
        self.m_plugin_list.append(_upl)
    
    def add_plugin_evnf(self, _ptype, _pfile, _pcfg):
        if type(self.m_plugin_list) != list :
            self.m_plugin_list = []
        
        for _evp in self.m_plugin_list :
            if _pfile == _evp.file() :
                return False
        _ep = _PLUGIN()
        _ep.plugin_setting(_ptype, _pfile, _pcfg)
        self.m_plugin_list.append(_ep)
        return True
    
    def del_plugin_evnf(self, _pfile):
        if _pfile != None and type(self.m_plugin_list) == list and len(self.m_plugin_list) > 0 :
            _del_evp = []
            for _evp in self.m_plugin_list :
                if _evp.file() == _pfile :
                    _del_evp.append(_evp)
            
            for _de in _del_evp :
                self.m_plugin_list.remove(_de)
            if len(self.m_plugin_list) < 1 :
                self.m_plugin_list = None
            return _del_evp
        else:
            return []
    
    
    def to_ob_net_info(self, logger=None):
        try:
            _net_info = {'onebox_id': self.m_ob_id}
            _net_info['out_of_band_mgmt'] = (0 if self.m_in_band else 1)
            
            # mgmt
            _mmgmt = self.m_mgmt_list[self.m_mgmt_idx]
            _mgmt = {'interface': _mmgmt.nic(), 'bridge': _mmgmt.bridge()}
            _mgmt['ipaddress'] = {'dhcp':_mmgmt.is_dhcp()}
            if not _mmgmt.is_dhcp() :
                _mgmt['ipaddress']['address'] = _mmgmt.ip()
                _mgmt['ipaddress']['subnet'] = _mmgmt.mask()
                _mgmt['ipaddress']['gateway'] = _mmgmt.gw()
            _net_info['mgmt'] = _mgmt
            
            # wan
            if not self.m_in_band :
                _mwan = self.m_wan_list[self.m_wan_idx]
                _wan = {'interface': _mwan.nic(), 'bridge': _mwan.bridge()}
                _wan['ipaddress'] = {'dhcp':_mwan.is_dhcp()}
                if not _mwan.is_dhcp() :
                    _wan['ipaddress']['address'] = _mwan.ip()
                    _wan['ipaddress']['subnet'] = _mwan.mask()
                    _wan['ipaddress']['gateway'] = _mwan.gw()
                _net_info['wan'] = _wan
            
            # lan
            _def_lan = ["office", "server"]
            for _lan in self.m_lan_net_list :
                _nm = str(_lan.name()).lower()
                _tag_net = 'lan_%s'%_nm
                _net_info[_tag_net] = {'interface': ','.join(_lan.nics()), 
                                       'bridge': oc.VAL_DEF_VNF_LAN_BR_PFX+_nm}
                _net_info[_tag_net]['ipaddress'] = {'dhcp':False}
                _net_info[_tag_net]['ipaddress']['address'] = _lan.gw()
                _net_info[_tag_net]['ipaddress']['subnet'] = _lan.mask()
                _net_info[_tag_net]['ipaddress']['gateway'] = None
            
            for _def in _def_lan :
                _tag_net = 'lan_%s'%_def
                if not _net_info.has_key(_tag_net) :
                    _net_info[_tag_net] = {'interface': None, 'bridge': oc.VAL_DEF_VNF_LAN_BR_PFX+_def,
                                           'ipaddress': {'dhcp':False, 'address': None, 
                                                         'subnet':None, 'gateway': None}}
            
            # extra mgmt
            _emgmt_list = []
            for _mgmt_info in self.m_mgmt_list :
                _mipaddr = {'dhcp': _mgmt_info.is_dhcp()}
                if not _mgmt_info.is_dhcp() :
                    _mipaddr['address'] = _mgmt_info.ip()
                    _mipaddr['subnet'] = _mgmt_info.mask()
                    _mipaddr['gateway'] = _mgmt_info.gw()
                    
                _minfo = {'interface': _mgmt_info.nic(), 'bridge': _mgmt_info.bridge(),
                          'ipaddress': _mipaddr}
                _emgmt_list.append(_minfo)
                
            _net_info['extra_mgmt'] = _emgmt_list
            
            # extra wan
            _ewan_list = []
            for _wan_info in self.m_wan_list :
                _wipaddr = {'dhcp': _wan_info.is_dhcp()}
                if not _wan_info.is_dhcp() :
                    _wipaddr['address'] = _wan_info.ip()
                    _wipaddr['subnet'] = _wan_info.mask()
                    _wipaddr['gateway'] = _wan_info.gw()
                    
                _winfo = {'interface': _wan_info.nic(), 'bridge': _wan_info.bridge(),
                          'ipaddress': _wipaddr}
                _ewan_list.append(_winfo)
            _net_info['extra_wan'] = _ewan_list
            
            return _net_info
        except Exception, e:
            if logger != None :
                logger.error("Fail to Convert Onebox-Network-Info, exc=%s"%str(e))
                logger.exception(e)
            return None

    def wan_host_connectivity_duration_time(self):
        return self.m_wan_host_connectivity_duration_time

    def hw_models(self):
        return self.m_hw_models

    def set_vim_version(self):
        if self.m_os == oc.VAL_OB_OS_BIG:
            self.m_vim_version = oc.VAL_VIM_VERSION_BIG
        else:
            self.m_vim_version = oc.VAL_VIM_VERSION_DEF

    def set_plugin_os(self):
        if type(self.m_plugin_list) != list:
            self.m_plugin_list = []

        _del_plugin = []
        for _evp in self.m_plugin_list:
            if str(_evp.ptype()).lower() == oc.CFG_PLUGIN_OS or str(_evp.ptype()).lower() == oc.CFG_PLUGIN_VIM:
                _del_plugin.append(_evp)

        for _du in _del_plugin:
            self.m_plugin_list.remove(_du)

        _upl_os = _PLUGIN()
        _upl_vim = _PLUGIN()
        if self.m_os == oc.VAL_OB_OS_BIG:
            _upl_os.plugin_setting(oc.CFG_PLUGIN_OS, oc.PLUGIN_OS_BIG)
            _upl_vim.plugin_setting(oc.CFG_PLUGIN_VIM, oc.PLUGIN_VIM_BIG)
        else:
            _upl_os.plugin_setting(oc.CFG_PLUGIN_OS, oc.PLUGIN_OS_DEF)
            _upl_vim.plugin_setting(oc.CFG_PLUGIN_VIM, oc.PLUGIN_VIM_DEF)

        self.m_plugin_list.append(_upl_os)
        self.m_plugin_list.append(_upl_vim)

    def __str_mgmtnet(self):
        _mgmtnet = "["
        for _mnet in self.m_mgmt_list :
            _mgmtnet += str(_mnet)+","
        _mgmtnet += "]"
        return _mgmtnet
    
    def __str_wannet(self):
        _net = "["
        for _wnet in self.m_wan_list :
            _net += "{"+str(_wnet)+"},"
        _net += "]"
        return _net
    
    def __str_evnf_wannet(self):
        _net = "["
        if self.m_extra_vnf_wan is not None:
            for _wnet in self.m_extra_vnf_wan :
                _net += "{"+str(_wnet)+"},"
        _net += "]"
        return _net
    
    def __str_plugininfo(self):
        _ptxt = None
        if type(self.m_plugin_list) == list :
            _ptxt = ""
            for _pinfo in self.m_plugin_list :
                _ptxt = _ptxt + "%s, "%str(_pinfo)
        return _ptxt
    
    def __str__(self):
        _txt = "<OBID:%s, "%self.m_ob_id
        _txt += ("MGMT_ADDR: %s, "%self.__str_mgmtnet())
        _txt += ("WAN_ADDR: %s, "%self.__str_wannet())
        _txt += ("EXTRA_WAN_ADDR: %s, "%self.__str_evnf_wannet())
        _txt += ("VET_INFO: %s, "%self.m_vet)
        _txt += ("PLUGIN_INFO: %s"%( str(self.__str_plugininfo()) ))
        _txt += ">"
        return _txt
    
    def __repr__(self):
        return self.__str__()








class OB_NET_PUBLIC():
    
    def init(self, _dev, _dhcp, _nic, _mac, _ip, _gw, _mask, _brname=None, _vlan=None, metric=0):
        self.dev = _dev
        self.is_dhcp = _dhcp
        self.nic = _nic
        self.mac = _mac
        
        self.ip = _ip
        self.mask = _mask
        self.gw = _gw
        try:
            self.prefixlen = IPv4Network("0.0.0.0/%s"%str(_mask))._prefixlen
        except Exception:
            self.prefixlen = -1
        
        self.br = _brname
        self.vlan = _vlan
        self.metric = 0
        
        return self
    
    def load(self, _json_info):
        self.dev = _json_info['dev']
        self.is_dhcp = _json_info['is_dhcp']
        self.nic = _json_info['nic']
        self.mac = _json_info['mac']
        
        self.ip = _json_info['ip']
        self.gw = _json_info['gw']
        self.mask = _json_info['mask']
        self.prefixlen = _json_info['prefixlen']
        
        self.br = _json_info['br']
        self.vlan = _json_info['vlan']
        self.metric = _json_info['metric']
        return self
    
    def diff_info(self, _target):
        if _target == None :
            return True
        
        if self.dev != _target.dev : return True
        if self.is_dhcp != _target.is_dhcp : return True
        if self.nic != _target.nic : return True
        if self.mac != _target.mac : return True
        if self.ip != _target.ip : return True
        if self.mask != _target.mask : return True
        if self.gw != _target.gw : return True
        if self.br != _target.br : return True
        
#         if self.vlan != _target.vlan : return True
#         if self.metric != _target.metric : return True
        
        return False
        
    
    def to_JSON_STR(self):
        return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True)
    
    def to_dict(self):
        return ruamel.yaml.safe_load(self.to_JSON_STR())
    
    def __str__(self):
        return "<dev=%s, nic=%s, mac=%s, dhcp=%s, ip=%s, mask=%s, gw=%s, pfx=%s, br=%s>"%(
                str(self.dev), str(self.nic), str(self.mac), str(self.is_dhcp), 
                str(self.ip), str(self.mask), str(self.gw), str(self.prefixlen),
                str(self.br))
    
    def __repr__(self):
        return self.__str__()
    
    def set_ip(self, _ip):
        if _ip != None and str(_ip).strip() != "" :
            try:
                IPv4Network("%s"%_ip)
                self.ip = _ip
            except Exception:
                pass
    
    def set_mask(self, _mask):
        if _mask != None and str(_mask).strip() != "" :
            try:
                self.prefixlen = IPv4Network("0.0.0.0/%s"%_mask)._prefixlen
                self.mask = _mask
            except Exception:
                pass
    
    def set_gw(self, _gw):
        if _gw != None and str(_gw).strip() != "" :
            try:
                IPv4Network("%s"%_gw)
                self.gw = _gw
            except Exception:
                pass
    

class OB_NET():
    
    def init(self, in_band, utm_local_ip, has_utm, wan_mode, _m_list, _w_list, _evw_list=None):
        self.is_notified = False
        self.in_band = in_band
        
        self.utm_local_ip = utm_local_ip
        self.has_utm = has_utm
        ## for only Wan-SW to UTM
        self.is_utm_ok = False
        ## When UTM run at first 
        self.is_first_run_utm = False
        
        self.wan_mode = wan_mode
        
        self.mgmt_list = []
        self.wan_list = []
        
        self.m_mgmt_idx = (-1 if len(_m_list) < 1 else 0)
        self.m_wan_idx = (-1 if len(_w_list) < 1 else 0)
        
        self.extra_vnf_wan_list = None
        
        for _m_info in _m_list :
            _dev = _m_info.bridge()
            _dhcp = _m_info.is_dhcp()
            _nic = _m_info.nic()
            _mac = _m_info.mac()
            _ip = _m_info.ip()
            _gw = _m_info.gw()
            _mask = _m_info.mask()
            self.mgmt_list.append(OB_NET_PUBLIC().init(_dev, _dhcp, _nic, _mac, _ip, _gw, _mask))
        
        for _w_info in _w_list :
            _dev = _w_info.bridge()
            _dhcp = _w_info.is_dhcp()
            _nic = _w_info.nic()
            _mac = _w_info.mac()
            _ip = _w_info.ip()
            _gw = _w_info.gw()
            _mask = _w_info.mask()
            self.wan_list.append(OB_NET_PUBLIC().init(_dev, _dhcp, _nic, _mac, _ip, _gw, _mask))
        
        if type(_evw_list) == list and len(_evw_list) > 0 :
            self.extra_vnf_wan_list = []
            for _evw in _evw_list :
                _dev = _evw.bridge()
                _dhcp = _evw.is_dhcp()
                _nic = _evw.nic()
                _mac = _evw.mac()
                _ip = _evw.ip()
                _gw = _evw.gw()
                _mask = _evw.mask()
                self.extra_vnf_wan_list.append(OB_NET_PUBLIC().init(_dev, _dhcp, _nic, _mac, _ip, _gw, _mask))
        
        return self
    
    def load(self, _json_info):
        self.is_notified = _json_info['is_notified']
        self.in_band = _json_info['in_band']
        
        self.utm_local_ip = _json_info['utm_local_ip']
        self.has_utm = _json_info['has_utm']
        self.is_utm_ok = _json_info['is_utm_ok']
        self.is_first_run_utm = _json_info['is_first_run_utm']
        
        self.wan_mode = _json_info['wan_mode']
        
        self.mgmt_list = []
        for _m_info in _json_info['mgmt_list'] :
            self.mgmt_list.append(OB_NET_PUBLIC().load(_m_info))
        
        self.wan_list = []
        for _w_info in _json_info['wan_list'] :
            self.wan_list.append(OB_NET_PUBLIC().load(_w_info))
        
        self.m_mgmt_idx = _json_info['m_mgmt_idx']
        self.m_wan_idx = _json_info['m_wan_idx']
        
        self.extra_vnf_wan_list = None
        if _json_info.has_key('extra_vnf_wan_list') and isinstance(_json_info['extra_vnf_wan_list'], list) :
            self.extra_vnf_wan_list = []
            for _evw in _json_info['extra_vnf_wan_list']:
                self.extra_vnf_wan_list.append(OB_NET_PUBLIC().load(_evw))
        
        return self
    
    def set_fake_wan(self, _lan_list, _fake=None):
        _fake_wan_list = ["10.15.123.0", "10.55.123.0", "10.105.123.0", "10.155.123.0", 
                           "10.35.123.0", "10.85.123.0", "10.135.123.0", "10.185.123.0"]
        if _fake != None :
            _fake_wan_list = _fake
        
        import copy
        _fake_wan_list_copy = copy.deepcopy(_fake_wan_list)
        
        _remain = 0
        ## used network check
        # external
        for _dum in _fake_wan_list_copy :
            try:
                for _net in (self.mgmt_list + self.wan_list) :
                    _subnet = IPv4Network("%s/%s"%( str(_net.ip), str(_net.mask) )).network
                    _dumnet = IPv4Network("%s/%s"%( _dum, str(_net.mask) )).network
                    if _subnet == _dumnet :
                        _fake_wan_list.remove(_dum)
            except Exception :
                continue
        # lan
        for _dum in _fake_wan_list_copy :
            try:
                for _net in (_lan_list) :
                    _subnet = IPv4Network("%s/%s"%( str(_net.gw()), str(_net.mask()) )).network
                    _dumnet = IPv4Network("%s/%s"%( _dum, str(_net.mask()) )).network
                    if _subnet == _dumnet :
                        _fake_wan_list.remove(_dum)
            except Exception :
                continue
        
        # extra-vnf-wan
        if type(self.extra_vnf_wan_list) == list : 
            for _dum in _fake_wan_list_copy :
                try:
                    for _net in (self.extra_vnf_wan_list) :
                        _subnet = IPv4Network("%s/%s"%( str(_net.ip), str(_net.mask) )).network
                        _dumnet = IPv4Network("%s/%s"%( _dum, str(_net.mask) )).network
                        if _subnet == _dumnet :
                            _fake_wan_list.remove(_dum)
                except Exception :
                    continue
        
        import random
        _off_ip = random.randint(10, 250)
        _used_idx = 0
        if self.in_band :
            _idx = 0
            for _mgmt in self.mgmt_list :
                _wan = self.wan_list[_idx]
                if _mgmt.is_dhcp and ( _mgmt.ip in (None, "") or _mgmt.gw in (None, "") ) :
                    if len(_fake_wan_list) > _used_idx :
                        _dum = _fake_wan_list[_used_idx]
                        _mask = "255.255.255.0"
                        _ipnet = IPv4Network("%s/%s"%( _dum, _mask) ).network
                        _ip = str(_ipnet + _off_ip)
                        _gw = str(_ipnet + 1)
                        
                        _mgmt.set_ip(_ip)
                        _mgmt.set_gw(_gw)
                        _mgmt.set_mask(_mask)
                        _wan.set_ip(_ip)
                        _wan.set_gw(_gw)
                        _wan.set_mask(_mask)
                        _used_idx += 1
                    else:
                        _remain += 1
                _idx += 1
        else:
            for _mgmt in self.mgmt_list :
                if _mgmt.is_dhcp and ( _mgmt.ip in (None, "") or _mgmt.gw in (None, "") ) :
                    if len(_fake_wan_list) > _used_idx :
                        _dum = _fake_wan_list[_used_idx]
                        _mask = "255.255.255.0"
                        _ipnet = IPv4Network("%s/%s"%( _dum, _mask) ).network
                        _ip = str(_ipnet + _off_ip)
                        _gw = str(_ipnet + 1)
                        
                        _mgmt.set_ip(_ip)
                        _mgmt.set_gw(_gw)
                        _mgmt.set_mask(_mask)
                        _used_idx += 1
                    else:
                        _remain += 1
            
            for _wan in self.wan_list :
                if _wan.is_dhcp and ( _wan.ip in (None, "") or _wan.gw in (None, "") ) :
                    if len(_fake_wan_list) > _used_idx :
                        _dum = _fake_wan_list[_used_idx]
                        _mask = "255.255.255.0"
                        _ipnet = IPv4Network("%s/%s"%( _dum, _mask) ).network
                        _ip = str(_ipnet + _off_ip)
                        _gw = str(_ipnet + 1)
                        
                        _wan.set_ip(_ip)
                        _wan.set_gw(_gw)
                        _wan.set_mask(_mask)
                        _used_idx += 1
                    else:
                        _remain += 1
        
#         if type(self.extra_vnf_wan_list) == list :
#             for _evwan in self.extra_vnf_wan_list :
#                 if _evwan.is_dhcp and ( _evwan.ip in (None, "") or _evwan.gw in (None, "") ) :
#                     if len(_fake_wan_list) > _used_idx :
#                         _dum = _fake_wan_list[_used_idx]
#                         _mask = "255.255.255.0"
#                         _ipnet = IPv4Network("%s/%s"%( _dum, _mask) ).network
#                         _ip = str(_ipnet + _off_ip)
#                         _gw = str(_ipnet + 1)
#                         
#                         _evwan.set_ip(_ip)
#                         _evwan.set_gw(_gw)
#                         _evwan.set_mask(_mask)
#                         _used_idx += 1
#                     else:
#                         _remain += 1
        
        self.m_mgmt_idx = 0
        self.m_wan_idx = 0
        return _remain
        
    
    def diff_mgmt_ip(self, _target):
        if _target == None :
            return True
        
        _nic, _ip = self.get_mgmt_ip()
        _tnic, _tip = _target.get_mgmt_ip()
        if _ip == _tip :
            return False
        else:
            return True
    
    def diff_extra_ip(self, _target):
        if _target == None :
            return True
        
        try:
            _idx = 0
            for _ninfo in self.mgmt_list :
                _tinfo = _target.mgmt_list[_idx]
                if _ninfo.diff_info(_tinfo):
                    return True
                _idx += 1
            
            _idx = 0
            for _ninfo in self.wan_list :
                _tinfo = _target.wan_list[_idx]
                if _ninfo.diff_info(_tinfo):
                    return True
                _idx += 1
            
            return False
        except Exception:
            return True
    
    def diff_wan_mode(self, _target):
        if _target == None :
            return True
        
        if self.wan_mode == _target.wan_mode :
            return False
        else:
            return True
    
    def to_JSON_STR(self):
        return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True)
    
    def to_dict(self):
        return ruamel.yaml.safe_load(self.to_JSON_STR())
    
    def __str__(self):
        return "<notified=%s, in_band=%s, utm_local_ip=%s, has_utm=%s, is_utm_ok=%s, is_first_run_utm=%s, wan_mode=%s, mgmt_list=%s, wan_list=%s, m_mgmt_idx=%s, m_wan_idx=%s, extra_vnf_wan_list=%s>"%(
                str(self.is_notified), str(self.in_band), str(self.utm_local_ip), str(self.has_utm), str(self.is_utm_ok), str(self.is_first_run_utm), 
                str(self.wan_mode), str(self.mgmt_list), str(self.wan_list), str(self.m_mgmt_idx), str(self.m_wan_idx), str(self.extra_vnf_wan_list))
    
    def __repr__(self):
        return self.__str__()
    
    def main_mgmt(self):
        return self.mgmt_list[self.m_mgmt_idx]

    def main_wan(self):
        return self.wan_list[self.m_wan_idx]
    
    def wan_mac_list(self):
        _mac = []
        for _net in ( self.mgmt_list + self.wan_list ) :
            _nmac = _net.mac
            if _nmac == None : continue
            if str(_nmac).strip() == "" : continue
            if _nmac in _mac : continue
            else:
                _mac.append(_nmac)
        return _mac
    
    def set_notify(self, is_notified):
        self.is_notified = is_notified
    
    def set_main_mgmt(self, _def_br):
        if type(_def_br) == int :
            self.m_mgmt_idx = _def_br
            if self.in_band : self.m_wan_idx = _def_br
            return True
        else:
            if type(_def_br) != str :
                return False
        
        _m_idx = 0
        for _minfo in self.mgmt_list :
            if _minfo.dev == _def_br :
                self.m_mgmt_idx = _m_idx
                if self.in_band : self.m_wan_idx = _m_idx
                return True
            _m_idx += 1
        return False
    
    def set_main_wan(self, _def_br):
        if type(_def_br) == int :
            self.m_wan_idx = _def_br
            if self.in_band : self.m_mgmt_idx = _def_br
            return True
        else:
            if type(_def_br) != str :
                return False
        
        _m_idx = 0
        for _winfo in self.wan_list :
            if _winfo.dev == _def_br :
                self.m_wan_idx = _m_idx
                if self.in_band : self.m_mgmt_idx = _m_idx
                return True
            _m_idx += 1
        return False
        
    
    def get_mgmt_ip(self):
        try:
            _m_mgmt = self.mgmt_list[self.m_mgmt_idx]
            return _m_mgmt.nic, _m_mgmt.ip
        except Exception:
            return None, None
    
    def get_wan_ip(self):
        try:
            _m_wan = self.wan_list[self.m_wan_idx]
            return _m_wan.is_dhcp, _m_wan.nic, _m_wan.ip, _m_wan.gw, _m_wan.prefixlen
        except Exception:
            return None, None, None, None, None


            
    








