#-*- coding: utf-8 -*-
'''
Created on 2017. 8. 2.

@author: ohhara
'''


OTAG_VER = "version"
OTAG_CFG_FILE = "oba_cfg_file"
OTAG_OBA_INFO = "oba_info"

OTAG_LIB_OB = "lib_ob"
OTAG_LIB_BTA = "lib_bta"
OTAG_LIB_OBA = "lib_oba"

# VAL_OB_VER = "1.3.6"
VAL_OB_VER = "1.4.0"

VAL_OBA_NAME = "onebox-agent"
VAL_VNFM_NAME = "onebox-vnfm"
VAL_MONA_NAME = "zabbix-agent"
VAL_NMSA_NAME = "znmsc"
VAL_SMSA_NAME = "zsmsc"

VAL_IP_TYPE_DHCP = "DHCP"
VAL_IP_TYPE_STAT = "STATIC"

# VIM TYPE
VAL_VIM_TYPE_OSP = "openstack"
VAL_VIM_TYPE_OSP_PREV = "OpenStack-ANode"
VAL_VIM_VERSION_DEF = "Kilo"
VAL_VIM_VERSION_BIG = "Queens"

# WAN Mode
VAL_WAN_MD_HOST = "HOST"
VAL_WAN_MD_VNF = "VNF"
VAL_WAN_MD_OUTBAND = "separate"

# OS INFO
VAL_OB_OS_BIG = "Ubuntu 18.04.1 LTS"
VAL_OB_OS_DEF = "Ubuntu 14.04.5 LTS"

T_DEF_WAIT_WAN_SW_PAUSE = 600

## MAX WAN
VAL_WAN_MAX_NUM = 4
VAL_EVWAN_MAX_NUM = 2

DEFAULT_WAN_HOST_CONNECTIVITY_DURATION_TIME = 300

## config txt와 동일해야 함
VAL_NET_TYPE_MGMT = "mgmt"
VAL_NET_TYPE_WAN = "wan"
VAL_NET_TYPE_EVWAN = "ewan"
VAL_NET_TYPE_LAN = "lan"

VAL_DEF_DNS_1 = "168.126.63.1"
VAL_DEF_DNS_2 = "168.126.63.2"

VAL_DEF_GVAR = "oba_shared.var"
VAL_DEF_OB_ID = "UNDEFINED.OB1"
VAL_DEF_HOST_MGMT_IP = "10.0.101.254"
VAL_DEF_HOST_MGMT_MASK = "255.255.255.0"
VAL_DEF_HOST_MGMT_NIC = "eth0"
VAL_DEF_HOST_LOCAL_IP = "192.168.254.254"
VAL_DEF_HOST_LOCAL_GW = "192.168.254.1"
VAL_DEF_HOST_LOCAL_MASK = "255.255.255.0"
VAL_DEF_HOST_MGMT_BR = "br-internet"
VAL_DEF_HOST_LOCAL_BR = "br-local"
VAL_DEF_VNF_WAN_BR = "br-wan"
VAL_DEF_VNF_LAN_BR_PFX = "br-lan-"
VAL_DEF_VI_WAN_BR_LIST = ['br-wan', 'br-wan1', 'br-wan2', 'br-wan3']
VAL_DEF_VI_LAN_BR_LIST = ['br-lan-office', 'br-lan-server']
VAL_DEF_VI_EWAN_BR_LIST = ['br-extrawan1', 'br-extrawan2']
VAL_DEF_OS_BR_LIST = ['br-internet', 'br-internet1', 'br-internet2', 'br-internet3']

VAL_DEF_LOCAL_IP_UTM = "192.168.254.1"
VAL_DEF_LOCAL_IP_PBX = "192.168.254.2"

CFG_EXTRA_MGMT = "extra_mgmt"
CFG_EXTRA_WAN = "extra_wan"

CFG_VET = "vet"

CFG_EXTRA_VNF_WAN = "extra_vnf_wan"

CFG_PLUGIN = "plugin"
CFG_PLUGIN_OS = "os"
CFG_PLUGIN_VIM = "vim"
CFG_PLUGIN_UTM = "utm"
CFG_PLUGIN_FILE = "file"
CFG_PLUGIN_CFG = "cfg"
CFG_PLUGIN_TYPE = "ptype"
CFG_PLUGIN_CFG_WAN = "wan"
CFG_PLUGIN_CFG_MD = "model"
CFG_PLUGIN_CFG_VD = "vendor"
CFG_PLUGIN_CFG_VER = "version"
CFG_PLUGIN_CFG_IP = "local_ip"
CFG_PLUGIN_CFG_ID = "id"
CFG_PLUGIN_CFG_PW = "pw"
CFG_VIM_VERSION = "vim_version"


## Agent Config
FILE_OBA_CONF = "/etc/onebox/onebox-agent.conf"
FILE_VNFM_CONF = "/etc/onebox/onebox-vnfm.conf"
FILE_MONA_CONF = "/etc/zabbix/zabbix_agentd.conf"

DIR_MONA_KEY = "/etc/zabbix/zabbix_agentd.conf.d/"
DIR_MONA_PLUG = "/usr/plugin/"

## HW Model
FILE_HW_MODEL = "/var/onebox/hardware/model"

## Tmp File
DIR_TMP = "/var/onebox/tmp/"
FILE_TMP_UTM_DR = "%skt_vnf_def_route.tmp"%DIR_TMP
FILE_TMP_UTM_UR = "%skt_vnf_usr_route.tmp"%DIR_TMP
FILE_TMP_UTM_RR = "%skt_vnf_prev_rule.tmp"%DIR_TMP
FILE_TMP_UTM_IF = "%skt_vnf_wan_if_ip.tmp"%DIR_TMP
FILE_TMP_UTM_ARP = "%skt_vnf_wan_arp.tmp"%DIR_TMP

## Noti File
FILE_NOTI_UTM_UR = "%skt_vnf_usr_route.noti"%DIR_TMP
FILE_NOTI_UTM_RR = "%skt_vnf_prev_rule.noti"%DIR_TMP
FILE_NOTI_UTM_IF = "%skt_vnf_wan_if_ip.noti"%DIR_TMP
FILE_NOTI_UTM_ARP = "%skt_vnf_wan_arp.noti"%DIR_TMP

## Backup File
FILE_SRC_HOST_NET = "/etc/network/interfaces"
FILE_BAK_HOST_NET = "%sinterfaces.bak"%DIR_TMP
FILE_SRC_OBA_CONF = FILE_OBA_CONF
FILE_BAK_OBA_CONF = "%sonebox-agent.conf.bak"%DIR_TMP
FILE_BAK_VIM_INFO = "%svim_info.bak"%DIR_TMP
FILE_BAK_VNF_UTM = "%svnf_utm_def_backup.bak"%DIR_TMP

## backup
DIR_RESTORE_VNFM = ["/var/onebox/vnf_configs"]
DIR_RESTORE_MONA = ["/etc/zabbix/zabbix_agentd.conf.d", "/usr/plugin"]

FILE_BACKUP_SRC_NOVA = ["/etc/nova/nova.conf", "/etc/nova/nova-compute.conf"]
FILE_RESTORE_SRC_NEUTRON = ["/etc/neutron/neutron.conf", "/etc/neutron/plugins/ml2/ml2_conf.ini"]
FILE_BACKUP_SRC_VNFM = ["/etc/onebox/onebox-vnfm.conf"]
FILE_BACKUP_SRC_MONA = ["/etc/zabbix/zabbix_agentd.conf"]
FILE_BACKUP_SRC_NMSA = ["/var/onebox/softwares/onebox-znmsc/znmsc.ini", 
                        "/var/onebox/softwares/onebox-znmsc/znmsc.pkey",
                        "/var/onebox/softwares/onebox-znmsc/bin/znmsc"]

FILE_BACKUP_SRC_SMSA = ["/var/onebox/softwares/onebox-zsmsc/zsmsc.eini", 
                        "/var/onebox/softwares/onebox-zsmsc/zsmsc.pkey",
                        "/var/onebox/softwares/onebox-zsmsc/bin/zsmsc"]

FILE_BACKUP_SRC_OBA = ["/etc/onebox/onebox-agent.conf"]

SVC_RESTORE_NOVA = ["nova-api", "nova-cert", "nova-consoleauth", "nova-scheduler", "nova-conductor", 
                    "nova-novncproxy", "nova-compute" ]
SVC_RESTORE_NEUTRON = ["nova-api", "nova-compute", "neutron-server", "neutron-l3-agent", "neutron-dhcp-agent", 
                       "neutron-metadata-agent", "neutron-plugin-openvswitch-agent"]
SVC_RESTORE_VNFM = ["onebox-vnfm"]
SVC_RESTORE_MONA = ["zabbix-agent"]
SVC_RESTORE_NMSA = ["znmsc"]
SVC_RESTORE_SMSA = ["zsmsc"]
SVC_RESTORE_OBA = ["onebox-agent"]


## Status 
DIR_STAT_DIR = "/var/onebox/.stat"
FILE_STAT_BAK = "%s/onebox_status"%DIR_STAT_DIR
FILE_STAT_WAN = "%s/onebox_wan_status"%DIR_STAT_DIR
FILE_STAT_VNF = "%s/onebox_vnf_status"%DIR_STAT_DIR
FILE_STAT_ETC = "%s/onebox_etc_status"%DIR_STAT_DIR
FILE_STAT_NET = "%s/onebox_net_sta`tus"%DIR_STAT_DIR
FILE_STAT_OBA = "%s/onebox_agt_status"%DIR_STAT_DIR
FILE_STAT_DEF_NS_ID = "%s/onebox_def_ns_status"%DIR_STAT_DIR

STATUS_FLD_DEF_NS_ID = "default_ns_id"

STATUS_DOING = "DOING"
STATUS_DONE = "DONE"
STATUS_ERROR = "ERROR"
STATUS_FAIL = "FAIL"

STATUS_ORCHF_NORMAL = "N__"

KEY_CLI_CRT = "/var/onebox/key/client.crt"
KEY_CLI_KEY = "/var/onebox/key/client.key"

HEADER = {'Accept': 'application/json', 'content-type': 'application/json'}

def URL_ORCHF_BASE(_ip, _port):
    if type(_port) == int : return "https://%s:%d/orch"%(str(_ip), _port)
    else: return "https://%s:%s/orch"%(str(_ip), str(_port))



ECD_CHK_CONN_WRONG_ENV = "__ecd_chk_conn_wrong_env__" 
ECD_CHK_CONN_LOCAL_UTM = "__ecd_chk_conn_local_utm__" 
ECD_CHK_CONN_EXCP = "__ecd_chk_conn_excp__" 
ECD_CHK_CONN_VNF_DNS_PING   = "__ecd_chk_conn_vnf_dns_ping__"
ECD_CHK_CONN_VNF_NO_GW      = "__ecd_chk_conn_vnf_no_gw__"
ECD_CHK_CONN_VNF_GW_ARPING  = "__ecd_chk_conn_vnf_gw_arping__"
ECD_CHK_CONN_VNF_GW_PING    = "__ecd_chk_conn_vnf_gw_ping__"
ECD_CHK_CONN_VNF_NC_SITE    = "__ecd_chk_conn_vnf_nc_site__"
ECD_CHK_CONN_VNF_CURL_MON   = "__ecd_chk_conn_vnf_curl_mon__"
ECD_CHK_CONN_VNF_NS_SITE    = "__ecd_chk_conn_vnf_ns_site__"
ECD_CHK_CONN_HOST_DNS_PING  = "__ecd_chk_conn_host_dns_ping__"
ECD_CHK_CONN_HOST_NO_GW     = "__ecd_chk_conn_host_no_gw__"
ECD_CHK_CONN_HOST_GW_ARPING = "__ecd_chk_conn_host_gw_arping__"
ECD_CHK_CONN_HOST_GW_PING   = "__ecd_chk_conn_host_gw_ping__"
ECD_CHK_CONN_HOST_NC_SITE   = "__ecd_chk_conn_host_nc_site__"
ECD_CHK_CONN_HOST_CURL_MON  = "__ecd_chk_conn_host_curl_mon__"
ECD_CHK_CONN_HOST_NS_SITE   = "__ecd_chk_conn_host_ns_site__"


VET_MODE_OVS_NORM = "__vet_mode_ovs_norm__"
VET_MODE_OVS_DPDK = "__vet_mode_ovs_dpdk__"
VET_NAME_NET_OVS_DPDK = "ovs_dpdk"
VET_NAME_NET_SRIOV = "sriov"

# VET_DEF_DPDK_DRV = "uio_pci_generic"
VET_DEF_DPDK_DRV = "igb_uio"

PLUGIN_OS_BIG = "onebox_agent.plugin.obos.ubuntu_bionic_plugin"
PLUGIN_VIM_BIG = "onebox_agent.plugin.vim.big_osp_plugin"

## Multi VNF
PLUGIN_OS_DEF = """onebox_agent.plugin.obos.linux_plugin"""
PLUGIN_VIM_DEF = """onebox_agent.plugin.vim.osp_plugin"""
PLUGIN_DEF_UTM = """onebox_agent.plugin.vnf.kt_vnf_plugin"""
PLUGIN_NO_UTM = """onebox_agent.plugin.vnf.no_utm"""

PLUGIN_UTM_KT_VNF = """onebox_agent.plugin.vnf.kt_vnf_plugin"""
PLUGIN_UTM_AXGATE_UTM = """onebox_agent.plugin.vnf.axgate_utm_plugin"""
PLUGIN_UTM_ACROMATE_PBX = """onebox_agent.plugin.vnf.acromate_pbx_plugin"""

VNFM_PLUGIN_TYPE_UTM = "UTM"
VNFM_PLUGIN_TYPE_PBX = "PBX"

VNFM_VNF_NAME_KT_VNF = "KT-VNF"
VNFM_VNF_NAME_AXGATE_UTM = "AXGATE-UTM"
VNFM_VNF_NAME_ACROMATE_PBX = "ACROMATE-CALLBOX"

def GET_PFILE(vnf_model):
    if vnf_model == VNFM_VNF_NAME_KT_VNF :
        return PLUGIN_UTM_KT_VNF
    elif vnf_model == VNFM_VNF_NAME_AXGATE_UTM :
        return PLUGIN_UTM_AXGATE_UTM
    elif vnf_model == VNFM_VNF_NAME_ACROMATE_PBX :
        return PLUGIN_UTM_ACROMATE_PBX
    else:
        return None


def GET_PHYSNET(_ovs_br):
    _name = str(_ovs_br).lstrip('br-')
    if _name == None or _name == "" :
        return None
    
    return "physnet_" + _name
    
def GET_OVSBR(_physnet):
    _name = str(_physnet).replace('physnet_', '')
    if _name == None or _name == "" :
        return None
    
    return "br-" + _name

# def GET_PLUGIN(_ptype, _type, _vendor, _version, _model):
#     if _ptype == PLUGIN_TYPE_OS:
#         return """onebox_agent.plugin.obos.linux_plugin"""
#     elif _ptype == PLUGIN_TYPE_VIM :
#         return """onebox_agent.plugin.vim.osp_plugin"""
#     elif _ptype == PLUGIN_TYPE_VNF :
#         if _type == VAL_VNF_TYPE_UTM :
#             if _model == VNF_UTM_NO :
#                 return """onebox_agent.plugin.vnf.no_utm"""
#             elif _model == VNF_UTM_AXGATE :
#                 return """onebox_agent.plugin.vnf.axgate_utm_plugin"""
#             return """onebox_agent.plugin.vnf.kt_vnf_plugin"""
#         elif _type == VAL_VNF_TYPE_PBX :
#             return """onebox_agent.plugin.vnf.acromate_pbx_plugin"""
#     
#     return None







