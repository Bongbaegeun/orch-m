#-*- coding: utf-8 -*-
'''
Created on 2017. 7. 26.

@author: ohhara
'''

import importlib, os, dircache, shutil, paramiko, tarfile, ruamel.yaml, sys, tempfile, traceback
from scp import SCPClient
from socket import error as socket_error
from ipaddr import IPv4Network
from time import sleep
import threading

from onebox_agent.util import ob_constant as oc, rest_api
from onebox_agent.data import ob_info


_LOG_T = "[LIB-OB.%-4s]"
def _getLineNo():
    org_f = None
    try:
        raise Exception
    except:
        org_f = sys.exc_info()[2].tb_frame.f_back
    #On some versions of IronPython, currentframe() returns None if
    #IronPython isn't run with -X:Frames.
    if org_f is not None:
        f = org_f.f_back
    else:
        return None
    
    if f == None :
        return None
    
    l_no = f.f_lineno
    return l_no


class EVPlugin():
    
    def __init__(self, _p_lib, _p_model, _p_local_ip, _p_file, _p_type, _p_wan_list, _p_cfg, _p_id=None, _p_pw=None):
        self.p_lib = _p_lib
        self.p_model = _p_model
        self.p_local_ip = _p_local_ip
        self.p_file = _p_file
        self.p_type = _p_type
        self.p_wan_list = _p_wan_list
        self.p_cfg = _p_cfg
        
        self.p_id = _p_id
        self.p_pw = _p_pw
        
        if _p_id != None : self.p_lib.DEF_ID = _p_id
        if _p_pw != None : self.p_lib.DEF_PASS = _p_pw
        
    def set_logger(self, _logger):
        self.p_lib.logger = _logger
        
    def __str__(self):
        return "lib=%s, model=%s, local_ip=%s, id=%s, pw=%s, type=%s, file=%s, wan=%s, cfg=%s"%( str(self.p_lib), str(self.p_model), str(self.p_local_ip), str(self.p_id), str(self.p_pw), 
                                                                                       str(self.p_type), str(self.p_file), str(self.p_wan_list), str(self.p_cfg) )
    
    def __repr__(self):
        return self.__str__()


class OB_LIB:
    
    def __init__(self, _os, _vim, _vnf_utm, _extra_vnf_list,_logger=None):
        self._os = _os
        self._vim = _vim
        self._vnf_utm = _vnf_utm
        self._extra_vnf_list = _extra_vnf_list
        self.logger = _logger
        
        self._os.logger = _logger
        self._vim.logger = _logger
        self._vnf_utm.logger = _logger
        if type(self._extra_vnf_list) == list : 
            for _evnf in self._extra_vnf_list:
                _evnf.set_logger(_logger)
    
    def _debug(self, msg):
        msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
        if self.logger != None : self.logger.debug(msg)
    
    def _info(self, msg):
        msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
        if self.logger != None : self.logger.info(msg)
    
    def _warn(self, msg):
        msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
        if self.logger != None : self.logger.warning(msg)
    
    def _err(self, msg):
        msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
        if self.logger != None : self.logger.error(msg)
    
    def _exc(self, exc):
        _SERR = tempfile.TemporaryFile()
        traceback.print_exc(exc, _SERR)
        _SERR.seek(0)
        msg = _SERR.read()
        msg = _LOG_T%str(_getLineNo()) + "\n" + str(msg)
        if self.logger != None : self.logger.fatal(msg)

    def get_os(self):
        return self._os

    def get_vim(self):
        return self._vim

    def get_vnf_utm(self):
        return self._vnf_utm

    def get_extra_vnf_list(self):
        return self._extra_vnf_list

    '''
    return Valid current hw info(model, cpu, mem..) or None
    '''
    def get_hw_info(self, _ob_info):
        try:
            _hw_model = self._get_hw_model(_ob_info)
            _cpu_info = self._os.get_cpu_model()
            _cpu_sock, _cpu_core_per_sock, _cpu_logical_core = self._os.get_cpu_core()
            _mem_size = self._os.get_mem_size()

            return ob_info.create_hw(_hw_model, _cpu_info, _cpu_sock, _cpu_core_per_sock, _cpu_logical_core, _mem_size)

        except Exception, e:
            self._err("Fail to get_hw_info, exc=%s" % str(e))
            return None

    def _get_hw_model(self, _ob_info):
        try:
            if _ob_info.m_hw_models is None or len(_ob_info.m_hw_models) < 1:
                # raise Exception("check hw_models= %s  in /etc/onebox/onebox-agent.conf " % str(_ob_info.m_hw_models))
                file_hw_model = None
                if os.path.exists(oc.FILE_HW_MODEL):
                    f = open(oc.FILE_HW_MODEL, 'r')
                    _file_hw_model = str(f.read()).strip()
                    f.close()
                    self._debug("file hw model = %s" % _file_hw_model)

                    if _file_hw_model is not None and len(_file_hw_model) > 1:
                        return _file_hw_model
                    else:
                        raise Exception("/var/onebox/hardware/model is empty!!!")
            else:
                _hw_model = None
                # 1. get dmidecode hw model
                _hw_model = self._check_valid_hw_model(_product_name=None, _hw_models=_ob_info.m_hw_models)
                self._debug("dmidecode hw model = %s" % _hw_model)
                if _hw_model is not None:
                    return _hw_model
                else:  # _hw_model is None:
                    # 2. get file hw model  /var/onebox/hardware/model
                    _file_hw_model = None
                    if os.path.exists(oc.FILE_HW_MODEL):
                        f = open(oc.FILE_HW_MODEL, 'r')
                        _file_hw_model = str(f.read()).strip()
                        f.close()
                        self._debug("file hw model = %s" % _file_hw_model)

                        # 3. check FILE_HW_MODEL info
                        if _file_hw_model is None or len(_file_hw_model) < 1:
                            raise Exception("/var/onebox/hardware/model is empty!!!")
                        else:
                            _hw_model = self._check_valid_hw_model(_product_name=_file_hw_model,
                                                                   _hw_models=_ob_info.m_hw_models)
                            if _hw_model is None:
                                raise Exception("/var/onebox/hardware/model is invalid!!! [%s]" % _file_hw_model)
                            else:
                                return _hw_model

        except Exception, e:
            self._err("Fail to get_hw_info, exc=%s" % str(e))
            return None

    def _check_valid_hw_model(self, _product_name=None, _hw_models=[]):
        try:
            if _product_name is None:
                # get dmidecode info and check substr
                # _vendor = self._os.get_dmidecode_keyword("system-manufacturer")
                _product_name = self._os.get_dmidecode_keyword("system-product-name")
                self._debug("dmidecode product name = %s " % _product_name)

                if _product_name is not None:
                    for _offset in range(0, len(_hw_models)):
                        if str(_product_name).lower().find(str(_hw_models[_offset]).split(' ')[1].lower()) > -1:
                            self._debug("hw model = %s " % str(_hw_models[_offset]).upper())
                            return str(_hw_models[_offset]).upper()

            else:
                # read model file info and check =
                self._debug("hw model file info = %s " % _product_name)
                for _offset in range(0, len(_hw_models)):
                    if _product_name.upper() == str(_hw_models[_offset]).upper():
                        return _product_name.upper()
                return None
        except Exception, e:
            self._err("Fail to check_valid_hw_model, exc=%s" % str(e))
            return None

    def get_os_info(self):
        return self._os.get_os_name()
    
    def convert_backinfo_to_obinfo(self, _orchf_info, _ob_info):
        try:
            _back_ob_info = _ob_info
            
            _back_ob_info.m_ob_id = str(_orchf_info['onebox_id'])
            _back_ob_info.m_in_band = (True if _orchf_info['out_of_band_mgmt'] == 0 else False)
            
            ## hw/os
            _back_ob_info.m_hw = self.get_hw_info(_ob_info)
            _back_ob_info.m_os = self.get_os_info()
            
            ## mgmt
            if _orchf_info.has_key('extra_mgmt') :
                _mgmtList = _orchf_info['extra_mgmt']
            else:
                _mgmtList = [_orchf_info['mgmt']]
            
            _mmnic = str(_orchf_info['mgmt']['interface'])
            
            _idx = 0
            _midx = 0
            _maddrList = []
            for _mgmt in _mgmtList :
                _nic = str(_mgmt['interface'])
                _dev = str(_mgmt['bridge'])
                _dhcp = _mgmt['ipaddress']['dhcp']
                _ip = (str(_mgmt['ipaddress']['address']) if _mgmt['ipaddress'].has_key('address') else None)
                _mask = (str(_mgmt['ipaddress']['subnet']) if _mgmt['ipaddress'].has_key('subnet') else None)
                _gw = (str(_mgmt['ipaddress']['gateway']) if _mgmt['ipaddress'].has_key('gateway') else None)
                _mac = self.get_host_mac(_nic, _nic_model=_ob_info.hw_nic_model())[_nic]
                _vlan = (str(_mgmt['vlan']) if _mgmt.has_key('vlan') else None)
                _maddr = ob_info.create_addr(oc.VAL_NET_TYPE_MGMT+"-%s"%str(_idx), oc.VAL_NET_TYPE_MGMT, 
                                             _nic, _dhcp, _ip, _mask, _gw, _dev, _mac, _vlan)
                _maddrList.append(_maddr)
                if _mmnic == _nic :
                    _midx = _idx
                
                _idx += 1
            
            _back_ob_info.m_mgmt_idx = _midx
            _back_ob_info.m_mgmt_list = _maddrList
            
            # wan
            if not _back_ob_info.m_in_band :
                _mwnic = str(_orchf_info['wan']['interface'])
                if _orchf_info.has_key('extra_wan') :
                    _wanList = _orchf_info['extra_wan']
                else:
                    _wanList = [_orchf_info['wan']]
                
                _idx = 0
                _widx = 0
                _waddrList = []
                for _wan in _wanList :
                    _nic = str(_wan['interface'])
                    _dev = str(_wan['bridge'])
                    _dhcp = _wan['ipaddress']['dhcp']
                    _ip = (str(_wan['ipaddress']['address']) if _wan['ipaddress'].has_key('address') else None)
                    _mask = (str(_wan['ipaddress']['subnet']) if _wan['ipaddress'].has_key('subnet') else None)
                    _gw = (str(_wan['ipaddress']['gateway']) if _wan['ipaddress'].has_key('gateway') else None)
                    _mac = self.get_host_mac(_nic, _nic_model=_ob_info.hw_nic_model())[_nic]
                    _vlan = (str(_wan['vlan']) if _wan.has_key('vlan') else None)
                    _waddr = ob_info.create_addr(oc.VAL_NET_TYPE_WAN+"-%s"%str(_idx), oc.VAL_NET_TYPE_WAN, 
                                                 _nic, _dhcp, _ip, _mask, _gw, _dev, _mac, _vlan)
                    _waddrList.append(_waddr)
                    if _mwnic == _nic :
                        _widx = _idx
                    
                    _idx += 1
                
                _back_ob_info.m_wan_idx = _widx
                _back_ob_info.m_wan_list = _waddrList
            else:
                _ret = _back_ob_info.sync_internet(_logger=self.logger)
                if not _ret :
                    self._err("Fail to Sync Mgmt-Wan Info, info=%s"%str(_back_ob_info))
                    return False, "Mgmt-Wan Sync Error"
            
            # evwan
            _evwan_list = _back_ob_info.extra_wan_list()
            if type(_evwan_list) == list :
                for _evw in _evwan_list :
                    _evw_nic = _evw.nic()
                    _evw_mac = self.get_host_mac(_evw_nic, _nic_model=_ob_info.hw_nic_model())[_evw_nic]
                    _evw.set_mac(_evw_mac)
            
            # LAN
            _lanList = []
            for _kkk in _orchf_info.keys() :
                if str(_kkk).startswith("lan_") :
                    _lanname = str(_kkk).split("_")[1]
                    _laninfo = _orchf_info[_kkk]
                    
                    _nicinfo = _laninfo['interface']
                    if not type(_nicinfo) in (list, tuple) :
                        _nicinfo = str(_nicinfo).split(',')
                    _nics = []
                    for _nn in _nicinfo :
                        if _nn != None and str(_nn).strip() != "" :
                            _nics.append(str(_nn).strip())
                    _gw = _laninfo['ipaddress']['address']
                    _mask = _laninfo['ipaddress']['subnet']
                    _lannet = ob_info.create_net(_lanname, oc.VAL_NET_TYPE_LAN, _nics, _gw, _mask)
                    _lanList.append(_lannet)
            _back_ob_info.m_lan_net_list = _lanList
            
            # VET
            _ovs_dpdk, _err = self.is_enable_ovs_dpdk()
            if not _ovs_dpdk :
                _back_ob_info.m_vet = None
            else:
                _back_ob_info.set_vet_mode(_ovs_dpdk={})
            
            # Plugin
            _back_ob_info.m_plugin_list = None
            
            try:
                _back_ob_info.saveToCfg()
            except Exception, e:
                self._err("Fail to Backup Data, OBA-Config Save Error, exc=%s"%str(e))
                self._exc(e)
                return False, "OBA-Config Save Error, exc=%s"%str(e)
            
            return True, _back_ob_info
        except KeyError, e:
            self._err("Fail to Convert Backup Data, No Parameter, key=%s, data=%s"%( str(e), str(_orchf_info) ))
            return False, "No Backup Parameter, key=%s"%str(e)
        except Exception, e:
            self._err("Fail to Backup Data, exc=%s"%str(e))
            self._exc(e)
            return False, "Unknown Error, exc=%s"%str(e)
    
    def to_obinfo_for_orchf(self, _net_state_info, _ob_info, _note=None, _first_noti=False):
        # m: mgmt_ip, public_ip(""), public_ip_dhcp(True/False), public_gw_ip(,""), public_cidr_prefix(int,0), public_nic
        #    hardware: model, cpu, num_cpus(int), num_cores_per_cpu(int), num_logical_cores(int), mem_size(int)
        #    software: operating_system
        #    vim: vim_type("OpenStack-ANode"), vim_authurl, vim_tenant_name, vim_tenant_username, vim_tenant_passwd
        #    vnfm: base_url
        #    obagent: base_url, version
        #    wan: nic, mode(vm/host/separate/error), mac
        #    lan_office: nic('eth1,eth2')
        #    lan_server: nic('eth1,eth2')
        #    vnet: [ (name(net_office/net_server), ip, subnet, cidr_prefix, metadata) ]
        # o: mgmt_nic
        #    wan_list: [ (--m: public_ip_dhcp(True/False), mode(vm/host), nic, mac
        #                 --o: public_ip, public_cidr_prefix(int), public_gw_ip) ]
        #    note: [ (noteCode, XXX) ]
        wan_mode = _net_state_info.wan_mode
        is_in_band = _net_state_info.in_band
        if wan_mode == oc.VAL_WAN_MD_HOST :
            _wan_mode = "host"
        elif wan_mode == oc.VAL_WAN_MD_VNF :
            _wan_mode = "vm"
        else:
            _wan_mode = "error"
        
        if not is_in_band :
            _wan_mode = "separate"
        
        _uip = _net_state_info.utm_local_ip
        
        ## mgmt_ip/nic
        _mgmt_nic, _mgmt_ip = _net_state_info.get_mgmt_ip()
        _mgmt_ip = (None if _mgmt_ip == None else _mgmt_ip)
        _mgmt_nic = (None if _mgmt_nic == None else _mgmt_nic)
        
        ## public
        _p_dhcp, _p_nic, _p_ip, _p_gw, _p_prefix = _net_state_info.get_wan_ip()
        _p_dhcp = (None if _p_dhcp == None else _p_dhcp)
        _p_nic = (None if _p_nic == None else _p_nic)
        _p_ip = (None if _p_ip == None else _p_ip)
        _p_gw = (None if _p_gw == None else _p_gw)
        _p_prefix = (-1 if _p_prefix == None else _p_prefix)
        
        ## hw
        _hw_info = self.get_hw_info(_ob_info)
        _hw = _hw_info.for_orchf()
        
        ## sw
        _sw_info = self.get_os_info()
        _sw = {'operating_system': _sw_info}
        
        ## vim
        _vim = _ob_info.vim_for_orchf(_mgmt_ip)
        
        ## vnfm
        _vnfm = _ob_info.vnfm_for_orchf(_mgmt_ip)
        
        ## oba
        _oba = _ob_info.oba_for_orchf(_mgmt_ip)
        
        ## wan
        _wmac = self.get_host_mac(_p_nic, _nic_model=_ob_info.hw_nic_model())
        _wmac = (None if _wmac == None or not _wmac.has_key(_p_nic) else _wmac[_p_nic])
        if _wmac == None :
            for _wan_info in _ob_info.wan_list() :
                if _p_nic == _wan_info.nic() :
                    _wmac = _wan_info.mac()
                    break
                
        _wan = {'nic':_p_nic, 'mode':_wan_mode, 'mac':_wmac}
        
        _for_orchf = {'mgmt_ip': _mgmt_ip,
                      'mgmt_nic': _mgmt_nic,
                      'public_ip': _p_ip,
                      'public_ip_dhcp': _p_dhcp,
                      'public_gw_ip': _p_gw,
                      'public_cidr_prefix': _p_prefix,
                      'public_nic': _p_nic,
                      'hardware': _hw,
                      'software': _sw,
                      'vim': _vim,
                      'vnfm': _vnfm,
                      'obagent': _oba,
                      'wan': _wan}
        
        
        ## lan_XXX
        _lan_name = _ob_info.lan_name_list()
        _vnet = []
        for _lname in _lan_name :
            _lnet = _ob_info.lan_xnet(_lname)
            _lnic = None
            _vip = None
            _vsubnet = None
            _vmask = None
            if _lnet != None :
                _lnic = ( None if len(_lnet.nics()) < 1 else ','.join(_lnet.nics()) )
                _vip = _lnet.gw()
                _vsubnet = _lnet.mask()
                try:
                    _vmask = IPv4Network("0.0.0.0/%s"%_vsubnet)._prefixlen
                except Exception:
                    self._warn("Fail to Get Lan Prefix, net=%s"%str(_lnet))
                    _vsubnet = None
            
            _lkey = "lan_%s"%_lname
            _for_orchf[_lkey] = {'nic':_lnic}
            
            # (name(net_office/net_server), ip, subnet, cidr_prefix, metadata)
            _vnet_name = self._vim.get_net_name(_lname)
            _vip = (None if _vip == None else _vip)
            _vsubnet = (None if _vsubnet == None else _vsubnet)
            _vmask = (-1 if _vmask == None else _vmask)
            _vnet.append({'name':_vnet_name, 'ip': _vip, 'subnet': _vsubnet, 'cidr_prefix': _vmask})
        
        ## vnet
        _for_orchf['vnet'] = _vnet
        
        ## wan_list
        #    wan_list: [ (--m: public_ip_dhcp(True/False), mode(vm/host), nic, mac
        #                 --o: public_ip, public_cidr_prefix(int), public_gw_ip) ]
        _wlist = _net_state_info.wan_list
        if len(_wlist) > 0 :
            _wan_list = []
            for _winfo in _wlist :
                _wan_dhcp = _winfo.is_dhcp
                _wan_nic = _winfo.nic
                _wan_br = _winfo.dev
                _wan_mac = _winfo.mac
                _wan_pnet = oc.GET_PHYSNET(_wan_br)
                _wan_info = {'public_ip_dhcp': _wan_dhcp, 'mode': _wan_mode, 'nic': _wan_nic, 'mac': _wan_mac, 'physnet_name': _wan_pnet}
                
                if _winfo.ip != None and _winfo.ip != "" :
                    _wan_info['public_ip'] = _winfo.ip
                if _winfo.gw != None and _winfo.gw != "" :
                    _wan_info['public_gw_ip'] = _winfo.gw
                if _winfo.prefixlen != None and _winfo.prefixlen != 0 :
                    _wan_info['public_cidr_prefix'] = _winfo.prefixlen
                _wan_list.append(_wan_info)
                
            _for_orchf['wan_list'] = _wan_list
        
        ## note
        if _note != None and len(_note) > 0 :
            _for_orchf['note'] = _note
        
        ## default nsid
        if os.path.isfile(oc.FILE_STAT_DEF_NS_ID) :
            with open(oc.FILE_STAT_DEF_NS_ID, "r") as f:
                _ns_info = ruamel.yaml.safe_load(f)
            if type(_ns_info) == dict and _ns_info.has_key(oc.STATUS_FLD_DEF_NS_ID) :
                _for_orchf['default_ns_id'] = _ns_info[oc.STATUS_FLD_DEF_NS_ID]
        
        ## When OBA first start
        _for_orchf['first_notify'] = _first_noti
        
        ## extra-vnf-wan
        _evwlist = _net_state_info.extra_vnf_wan_list
        if type(_evwlist) == list and len(_evwlist) > 0 :
            _evwan_list = []
            for _evwinfo in _evwlist :
                _evw_dhcp = _evwinfo.is_dhcp
                _evw_nic = _evwinfo.nic
                _evw_br = _evwinfo.dev
                _evw_mac = _evwinfo.mac
                _evw_pnet = oc.GET_PHYSNET(_evw_br)
                _evw_info = {'public_ip_dhcp': _evw_dhcp, 'mode': 'vm', 'nic': _evw_nic, 'mac': _evw_mac, 'physnet_name': _evw_pnet}
                
                if _evwinfo.ip != None and _evwinfo.ip != "" :
                    _evw_info['public_ip'] = _evwinfo.ip
                if _evwinfo.gw != None and _evwinfo.gw != "" :
                    _evw_info['public_gw_ip'] = _evwinfo.gw
                if _evwinfo.prefixlen != None and _evwinfo.prefixlen != 0 :
                    _evw_info['public_cidr_prefix'] = _evwinfo.prefixlen
                _evwan_list.append(_evw_info)
                
            _for_orchf['extra_wan_list'] = _evwan_list
        
        
        return _for_orchf
    
    def noti_ob_info(self, _net_state_info, _ob_info, _first_noti=False):
        try:
            _ip, _port = _ob_info.orchf_site()
            _ob_id = _ob_info.ob_id()
            
            ## NOTE Code : 001_001 : deleted User Route
            _note = None
            if os.path.isfile(oc.FILE_NOTI_UTM_UR) :
                _usrRoute = []
                with open(oc.FILE_NOTI_UTM_UR, "r") as f:
                    _usrRoute = ruamel.yaml.safe_load(f)
                
                if len(_usrRoute) > 0 :
                    if _note == None : _note = []
                    
                    ## {"_name": "main", "_destAddr": "222.123.123.0", "_destPrefix": "255.255.255.0", "_metric": "0", "_gateway": "222.123.123.1", "_outputIf": "eth5"}
                    _webUR = []
                    for _ur in _usrRoute :
                        _webUR.append( {"_name": _ur['_name'], "_destAddr": _ur['_destAddr'], 
                                    "_destPrefix": _ur['_dnetmask'], "_metric": _ur['_metric'], "_gwList": _ur['_gwList']} )
            
                    _note.append({ "noteCode": "001_001", "route":_webUR })
            
            ## NOTE Code : 001_002 : deleted Route Rule
            if os.path.isfile(oc.FILE_NOTI_UTM_RR) :
                _routeRule = []
                with open(oc.FILE_NOTI_UTM_RR, "r") as f:
                    _routeRule = ruamel.yaml.safe_load(f)
                
                if len(_routeRule) > 0 :
                    if _note == None : _note = []
                    
                    ##  {"_priority": 0, "_inputIf": "eth5", "_addr": "10.1.1.0", "_fromPrefix": 24, "_toAddr": "", "_toPrefix": 0}
                    ## "_name": "aaaaa", "_priority": 7, "_addr": "10.2.2.0", "_fromPrefix": 24, "_inputIf": "eth5", "_toAddr": "", "_toPrefix": 0
                    _webRR = []
                    for _rr in _routeRule :
                        _webRR.append( { "_priority": _rr['_priority'], "_inputIf": _rr['_inputIf'], "_addr": _rr['_addr'],
                                "_fromPrefix": _rr['_fromPrefix'], "_toAddr": _rr['_toAddr'], "_toPrefix": _rr['_toPrefix'] } )
                    
                    _note.append({ "noteCode": "001_002", "rule":_webRR })
            
            ## NOTE Code : 001_003 : deleted WAN IP
            if os.path.isfile(oc.FILE_NOTI_UTM_IF) :
                _ifInfo = {}
                with open(oc.FILE_NOTI_UTM_IF, "r") as f:
                    _ifInfo = ruamel.yaml.safe_load(f)
                
                if len(_ifInfo) > 0 :
                    if _note == None : _note = []
                    
                    ## STATIC -> { "type":"static", "_ifname": "eth1", "ip_list":[{"_addr": "175.213.170.152", "_prefixlen": "24"}] },
                    ## DHCP -> { "type":"dhcp", "_name":"red_dhcp_r1", "_interface": "eth5" }
                    _webIF = []
                    for _ifi in _ifInfo.keys() :
                        _if = _ifInfo[_ifi]
                        ## DHCP
                        if _if.has_key('id') :
                            _webIF.append({"type": "dhcp", "_name": _if['id'], "_interface": _ifi})
                        ## STATIC
                        else:
                            _webIF.append({"type": "static", "_ifname": _ifi, "ip_list":_if['ip_list']})
                    
                    _note.append({ "noteCode": "001_003", "ip_addr":_webIF })
            
            ## NOTE Code : 001_004 : deleted ARP
            if os.path.isfile(oc.FILE_NOTI_UTM_ARP) :
                _arp = []
                with open(oc.FILE_NOTI_UTM_ARP, "r") as f:
                    _arp = ruamel.yaml.safe_load(f)
                
                if len(_arp) > 0 :
                    if _note == None : _note = []
                    
                    _webRR = []
                    for _a in _arp :
                        _webRR.append( {"ifname": _a['ifname'], "addr": _a['addr'], "mac_addr": _a['lladdr']} )
                    
                    _note.append({ "noteCode": "001_004", "arp":_webRR })
            
            header = oc.HEADER
            url = "%s/server/%s" % ( oc.URL_ORCHF_BASE(_ip, _port), _ob_id )
            _body = self.to_obinfo_for_orchf(_net_state_info, _ob_info, _note, _first_noti)
            self._info("### OB-INFO, info=%s"%str(_body))
            
            _ret, _ecode, _res = rest_api.sendReq(header, url, "POST", _body)
            if not _ret :
                if type(_res) == dict :
                    self._err("Fail to Notify OBNet-Info, res=%s"%(str(_res)))
                else:
                    self._err("Fail to Notify OBNet-Info, API Return Error, url=%s, res=%s"%( url, str(_res) ))
                return False
            
            if _note != None and len(_note) > 0 and _ret :
                try:
                    if os.path.isfile( oc.FILE_NOTI_UTM_UR ) :
                        self._debug(" - Succ: Delete Notification File, f=%s"%(oc.FILE_NOTI_UTM_UR))
                        os.remove( oc.FILE_NOTI_UTM_UR )
                    if os.path.isfile( oc.FILE_NOTI_UTM_RR ) :
                        self._debug(" - Succ: Delete Notification File, f=%s"%(oc.FILE_NOTI_UTM_RR))
                        os.remove( oc.FILE_NOTI_UTM_RR )
                    if os.path.isfile( oc.FILE_NOTI_UTM_IF ) :
                        self._debug(" - Succ: Delete Notification File, f=%s"%(oc.FILE_NOTI_UTM_IF))
                        os.remove( oc.FILE_NOTI_UTM_IF )
                    if os.path.isfile( oc.FILE_NOTI_UTM_ARP ) :
                        self._debug(" - Succ: Delete Notification File, f=%s"%(oc.FILE_NOTI_UTM_ARP))
                        os.remove( oc.FILE_NOTI_UTM_ARP )
                except Exception, e:
                    self._err("Fail to Delete Notification File")
                    self._exc(e)
            
            self._info("SUCC: Notify OB-INFO")
            return True
        except Exception, e:
            self._err("Fail to Notify OB-INFO, exc=%s"%str(e))
            self._exc(e)
            return False
    
    def restart_service(self, _svc_list):
        _ret = True
        for _svc in _svc_list :
            if _svc != None and str(_svc).strip() != "" :
                _code, _out, _err = self._os.Service(_svc).restart()
                if _code != 0 or str(_err).strip() != "" :
                    _ret = False
                    self._warn("   Fail to Restart %s, code=%s, out=%s, err=%s"%( str(_svc), str(_code), str(_out), str(_err) ))
        return _ret
    
    def correct_mac(self, oba_file=oc.FILE_OBA_CONF):
        try:
            with open(oba_file, "r") as f:
                _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
            _ob_info = ob_info.OB_INFO().loadByCfg(_oba_cfg, True)
            
            for _mgmt in _ob_info.mgmt_list() :
                _mnic = _mgmt.nic()
                _mmac = self._os.get_mac_address(_mnic)
                _mgmt.set_mac(_mmac)
            
            for _wan in _ob_info.wan_list() :
                _wnic = _wan.nic()
                _wmac = self._os.get_mac_address(_wnic)
                _wan.set_mac(_wmac)
            
            _ob_info.saveToCfg(oba_file)
            self._info("SUCC: Correct MAC in OB-INFO")
        except Exception, e:
            self._err("Fail to Correct MAC in OB-INFO, exc=%s"%str(e))
            self._exc(e)
            return False
    
    def restore_service(self, _root_dir, service_files, services, service_dirs = [], restart=True):
        try:
            if restart:
                for service in services:
                    self._os.Service(service).stop()
                self._info("   Stop Service, svc=%s"%str(services))
            
            sleep(0.5)
            for _file in service_files:
                src = os.path.normpath(_root_dir+"/"+_file)
                self.copyFile(src, _file)
            self._info("   Copy Service File, file=%s"%str(service_files))
            
            for _dir in service_dirs:
                if os.path.exists(_dir) :
                    shutil.rmtree(_dir)
                src = os.path.normpath(_root_dir+"/"+_dir)
                self.copyDir(src, _dir)
            self._info("   Copy Service Dir, dir=%s"%str(service_dirs))
            
            if restart:
                for service in services:
                    self._os.Service(service).start()
                self._info("   Start Service, svc=%s"%str(services))
            
            self._info("SUCC: Restore Service, svc=%s"%str(services))
            return True, None
        except Exception, e:
            self._err("Fail to Restore Service, svc=%s, exc=%s"%( str(services), str(e) ))
            self._exc(e)
            return False
    
    
    def is_in_band(self, _obaCfg):
        _outBand = str(_obaCfg["out_of_band_mgmt"])
        if _outBand == "0" :
            return False
        else:
            return True
    
    def getWanMode(self, _ob_info):
        '''
        return : None, oc.VAL_WAN_MD_XXX
        '''
        is_in_band = _ob_info.is_in_band()
        has_utm = self.hasUtm(_ob_info.wan_mac_list())
        _wan_list = _ob_info.wan_list()
        if not is_in_band :
            return oc.VAL_WAN_MD_OUTBAND
        
        ## default GW chk
        _gw_dev, _gw_ip, _gw_metric = self._os.get_def_gw_info()
        if _gw_dev == None or _gw_ip == None :
            self._warn(" - Fail to Get Wan-Mode, Default GW-Info Error, info=%s/%s/%s"%( str(_gw_dev), str(_gw_ip), str(_gw_metric) ))
        
        _gwMode = None
        _gwBR = None
        if str(_gw_dev).find(oc.VAL_DEF_HOST_MGMT_BR) > -1 :
            _gwMode = oc.VAL_WAN_MD_HOST
            _gwBR = _gw_dev
        elif str(_gw_dev).find(oc.VAL_DEF_HOST_LOCAL_BR) > -1 :
            _gwMode = oc.VAL_WAN_MD_VNF
            _gwBR = _gw_dev
        elif _gw_dev != None :
            self._err("Fail to Get Wan-Mode, Default Gateway Error, gw_if=%s"%( str(_gw_dev) ))
            return None
        
        ## br chk
        _wan_nic_os = []
        _wan_nic_vi = []
        for _mgmt in _ob_info.mgmt_list():
            _nic = _mgmt.nic()
            _brd = _mgmt.bridge()
            if _nic == None or str(_nic).strip() == "" or _brd == None or str(_brd).strip() == "" :
                self._warn(" - Fail to Get Wan-Mode, No OS-BR-Info, br=%s, nic=%s"%( str(_brd), str(_nic) ))
                continue
            _brIFs = self._os.get_br_ifs(_brd)
            if type(_brIFs) in (list, tuple) and _nic in _brIFs :
                if self._os.is_master(_brd, [_nic]) :
                    if not _nic in _wan_nic_os : _wan_nic_os.append(_nic)
                else:
                    self._err("Fail to Get Wan-Mode, Wrong OS-IF's Owner, br=%s, if=%s"%( str(_brd), str(_nic) ))
                    return None
        for _wan in _ob_info.wan_list():
            _nic = _wan.nic()
            _brd = _wan.bridge()
            if _nic == None or str(_nic).strip() == "" or _brd == None or str(_brd).strip() == "" :
                self._warn(" - Fail to Get Wan-Mode, No VI-BR-Info, br=%s, nic=%s"%( str(_brd), str(_nic) ))
                continue
            _brIFs = self._vim.get_br_ifs(_brd)
            if type(_brIFs) in (list, tuple) and _nic in _brIFs :
                if self._vim.is_master(_brd, [_nic]) :
                    if not _nic in _wan_nic_vi : _wan_nic_vi.append(_nic)
                else:
                    self._err("Fail to Get Wan-Mode, Wrong VI-IF's Owner, br=%s, if=%s"%( str(_brd), str(_nic) ))
                    return None
        
        # decide
        if len(_wan_nic_os) < 1 and len(_wan_nic_vi) < 1 :
            self._err("Fail to Get Wan-Mode, No Both(os&vi)-IF")
            return None
        
        if len(_wan_nic_os) > 0 and len(_wan_nic_vi) > 0 :
            self._err("Fail to Get Wan-Mode, Both(os&vi)-IF Exist, os=%s, vi=%s"%( str(_wan_nic_os), str(_wan_nic_vi) ))
            return None
        
        if _gwMode in (None, oc.VAL_WAN_MD_HOST) :
            if len(_wan_nic_os) > 0 :
                return oc.VAL_WAN_MD_HOST
        elif _gwMode == oc.VAL_WAN_MD_VNF :
            if not has_utm :
                self._err("Fail to Get Wan-Mode, Wrong Environment, No UTM & WAN=VNF, vi=%s"%str(_wan_nic_vi))
                return None
            if len(_wan_nic_vi) > 0 :
                return oc.VAL_WAN_MD_VNF
        
        self._err("Fail to Get Wan-Mode, Invalid Infra, gw=%s, utm-on=%s os=%s, vi=%s"%( str(_gwMode), str(has_utm), str(_wan_nic_os), str(_wan_nic_vi) ))
        return None
    
    def is_enable_ovs_dpdk(self):
        return self.get_vim().is_ok_ovs_dpdk()
    
    def get_utm_status(self, _uip, _retry=5, _period=5):
        for _i in range(_retry) :
            try:
                _ret = self.get_os().ping(_uip, 3, 3)
                if _ret :
                    return True
                else:
                    self._warn(" - Fail to Ping UTM, ip=%s, retry=%s/%s"%( str(_uip), str(_i+1), str(_retry) ))
            except Exception, e:
                self._warn("Fail to Get UTM Status, exc=%s"%( str(e) ))
                self._exc(e)
            sleep(_period)
        return False
    
    def hasUtm(self, mac_list):
        if self._vim.has_utm(mac_list):
            return True
        else:
            return self.get_os().ping(oc.VAL_DEF_HOST_LOCAL_GW, 3, 3)
    
    def login_utm(self, _utm_ip, _utm_id=None, _utm_pass=None):
        return self._vnf_utm.login(_utm_ip, _utm_id, _utm_pass)
    
    def logout_utm(self, _utm_ip, _utm_id=None):
        return self._vnf_utm.logout(_utm_ip, _utm_id)
    
    def get_utm_metric(self, brname):
        return self._vnf_utm.get_metric(brname)
    
    def get_utm_wan_list(self):
        return self._vnf_utm.get_wan_nic_list()
    
    def get_utm_bridge(self, _utm_ip, _wnic_list, _utm_id=None):
        return self._vnf_utm.chk_vnf_bridge(_utm_ip, _wnic_list, _vnf_id=_utm_id)
    
    def get_utm_all_route(self, _utm_ip, _wnic_list, _static_gw_list=None, _utm_id=None):
        return self._vnf_utm.get_vnf_all_route_info(_utm_ip, _wnic_list, _static_gw_list, _utm_id)
    
    def add_utm_ip(self, _utm_ip, _utm_is_dhcp, _host_br, _utm_nic_ip=None, _utm_mask=None, _utm_mac=None, _utm_id=None):
        return self._vnf_utm.add_vnf_ip(_utm_ip, _utm_is_dhcp, _host_br, _utm_nic_ip, _utm_mask, _utm_mac, _utm_id)
    
    def add_utm_route(self, _utm_ip, _utm_is_dhcp, _host_br, _utm_gw=None, _utm_table=None, _utm_metric=None, _utm_id=None):
        return self._vnf_utm.add_vnf_route(_utm_ip, _utm_is_dhcp, _host_br, _utm_gw, _utm_table, _utm_metric, _utm_id)
    
    def del_utm_route(self, _utm_ip, _route, _utm_id=None):
        return self._vnf_utm.del_vnf_route(_utm_ip, _route, _utm_id)
    
    def del_utm_all_route(self, _utm_ip, _route, _utm_id=None):
        return self._vnf_utm.del_vnf_all_route(_utm_ip, _route, _utm_id)
    
    def del_utm_unuse_if(self, _utm_ip, _dhcp_if_list, _utm_id=None):
        return self._vnf_utm.del_unuse_if(_utm_ip, _dhcp_if_list, _utm_id)
    
    def backup_utm(self, _bak_file, _utm_ip):
        return self._vnf_utm.backup(_bak_file, _utm_ip)
    
    def to_utm_nic(self, _brname):
        '''
        return : None or if_name
        '''
        return self._vnf_utm.get_nic(_brname)
    
    def to_vim_br(self, _utm_nic):
        return self._vnf_utm.get_br(_utm_nic)
    
    def is_svc_on(self, _svcName):
        return self._os.Service(_svcName).status()
    
    def get_tunnel_class(self):
        return self._os.SshTunnel
    
    def get_host_nic_info(self):
        return self._os.get_nic_info()
    
    def init_vi_nic(self, _pci_no):
        return self._vim.init_ovs_port(_pci_no)
    
    def correct_nic_drv(self):
        try:
            _nic_dict = self.get_host_nic_info()
            for _pci_num in _nic_dict.keys() :
                _nic_i = _nic_dict[_pci_num]
                _n_org_drv = _nic_i['Driver_org']
                _nic_name = _nic_i['Interface']
                if _nic_name == None :
                    if _n_org_drv != None :
                        # chk vim port
                        # ovsdpdk-unused nic -> kern
                        if not self._vim.is_in_used(_pci_num) :
                            self._debug(" - Bind NIC to Kern, pci=%s, drv=%s"%( str(_pci_num), str(_n_org_drv )))
                            self.init_vi_nic(_pci_num)
                            self.bind_host_nic(_nic_i, _n_org_drv)
                    else:
                        self._err("Fail to Correct NIC-Driver, No Driver, nic=%s"%str(_nic_i))
                else:
                    # ovsdpdk-used nic -> dpdk
                    if self._vim.is_in_used(_pci_num) :
                        self._debug(" - Bind NIC to DPDK, nic=%s, pci=%s, drv=%s"%( str(_nic_name), str(_pci_num), oc.VET_DEF_DPDK_DRV ))
                        self.set_host_if_status(_nic_name, False)
                        self.bind_host_nic(_nic_i, oc.VET_DEF_DPDK_DRV)
        except Exception, e:
            self._err("Fail to Init Nic Driver, exc=%s"%( str(e) ))
            self._exc(e)
    
    def bind_host_nic(self, _nic_info, _org_drv):
        return self._os.bind_dev(_nic_info, _org_drv)
    
    def get_host_mac(self, _nic=None, _nic_model=None):
        '''
        return : {NIC_NAME: MAC_ADDR} or None
        '''
        try:
            _mac_info = {}
            # _available_nics = self._os.get_phy_if_list(_nic_model)
            _available_nics = self._os.get_ethernets(_nic_model)
            if _nic != None :
                if type(_nic) == list or type(_nic) == tuple :
                    _available_nics = _nic
                else:
                    _available_nics = [_nic]
            
            for _anic in _available_nics :
                if _anic == None :
                    continue
                _mac = self._os.get_mac_address(_anic)
                if _mac == None or str(_mac).strip() == "" :
                    self._warn("Fail to Get MacAddress, nic=%s"%str(_anic))
                    continue
                _mac_info[_anic] = _mac
            
            return _mac_info
        except Exception, e:
            self._err("Fail to Get Mac Addr, nic=%s, exc=%s"%( str(_nic), str(e) ))
            self._exc(e)
            return None
    
    def get_host_bridge(self):
        '''
        return : br list or None
        '''
        return self._os.get_br()
    
    def add_host_bridge(self, _brname):
        return self._os.add_br(_brname)
    
    def get_host_main_ip(self):
        '''
        return : (NIC, IP, MASK, GW) or None
        '''
        return self._os.get_main_ip()
    
    def config_internetwork(self, internet):
        # /etc/network/interfaces 파일에 딱 한 번만 접근하도록 하기 위해 이 함수를 생성
        # 여러 번 접근 시 설정 파일에 오류 발생 가능성이 있음
        # management interface 설정 시에 호출되어 모든 인터페이스에 대한 up/down 설정 수행
        try:
            net_conf = self._os.NetworkConfig()
            
            ## Internet
            result = net_conf.config_bridge_internet(
                        internet.bridge(), internet.nics(), internet.is_dhcp(), 
                        internet.ip(), internet.mask(), internet.gw())
            if not result:
                self._err("Fail to Config LX-BR Network, net=%s"%str(internet))
                return False
            
            if not net_conf.config_manual_updown(internet.nic()) :
                self._err("Fail to Config Internet Nic=%s"%str(internet.nic()))
                return False
            
            ## save
            if not net_conf.write() :
                self._err("Fail to Write Internet Info")
                return False
            
            return True
        except Exception, e:
            self._exc(e)
            return False
    
    def config_mgmt_net(self, networks, progress=None, bv=None):
        _up = None
        try:
            if progress != None :
                progress.inc(1)
                bv.update_progBar(progress, "Management network configuration: write configuration")
            
            if not self._os.update_dhclient_config() :
                self._err("Fail to Set DHClient Config")
                return False, "Fail to Set DHClient Config"
            
            _wait = max(3, min(5, len(networks)*2))
            for network in networks :
                br_ext = network.bridge()
                nic = network.nic()
                
                if not self.config_internetwork(network) :
                    self._err("Fail to Config Internet, net=%s"%str(br_ext))
                    return False, "Fail to Config Internet, net=%s"%str(br_ext)
                
                if progress != None :
                    _up = bv.UpdateProg(progress, _wait, 1, "Management network configuration: interface %s restart" % nic)
                    _up.start()
                _ret = self._os.down_and_up_interface(nic, 10)
                if _up != None : _up.stop()
                if not _ret :
                    self._err("Fail to Refresh Interface, nic=%s"%str(nic))
                    return False, "Fail to Refresh Interface, nic=%s"%str(nic)
                
                _up = None
                if progress != None :
                    _up = bv.UpdateProg(progress, _wait, 1, "Management network configuration: interface %s restart" % br_ext)
                    _up.start()
                _ret = self._os.down_and_up_interface(br_ext, 30)
                if _up != None : _up.stop()
                if not _ret :
                    self._err("Fail to Refresh Interface, br=%s"%str(br_ext))
                    return False, "Fail to Refresh Interface, br=%s"%str(br_ext)
                
                _gdev, _gip, _gm = self._os.get_def_gw_info()
                if _gdev == None or _gdev != br_ext :
                    _down_if = threading.Thread(target=self._os.ifconfig_down, 
                                                args=(br_ext, True))
                    _down_if.start()
                    self._info(" - Start Interface Down: %s"%str(br_ext))
            
            return True, None
        except Exception, e:
            self._err("Fail to Config Mgmt-Net, exc=%s"%str(e))
            self._exc(e)
            if _up != None : _up.stop()
            return False, "Occur Exception, exp=%s"%str(e)
    
    def get_mgmt_ip(self, _has_utm, _wan_mode, _vnf_ip=None):
        try:
            if _has_utm :
                _vnf_ip = ( oc.VAL_DEF_HOST_LOCAL_GW if _vnf_ip == None else _vnf_ip)
                if not self._os.ping(_vnf_ip, 3, 3):
                    self._err("Fail to Get MGMT-IP, UTM-Conn Error, ip=%s"%str(_vnf_ip))
                    return None
                _vip = self._vnf_utm.get_main_public_ip(_vnf_ip)[1]
                _hip = self.get_host_main_ip()[1]
                
                if _vip == _hip : return _vip
                
                if _wan_mode in ( oc.VAL_WAN_MD_HOST, oc.VAL_WAN_MD_OUTBAND ) :
                    return _hip
                elif _wan_mode == oc.VAL_WAN_MD_VNF :
                    return _vip
                else:
                    return None
            else:
                return self.get_host_main_ip()[1]
        except Exception, e:
            self._err("Fail to Get MGMT-IP, exc=%s"%str(e))
            self._exc(e)
            return None
    
    def get_vim_public_ip(self):
        '''
        return : IP or None
        '''
        return self._vim.get_public_ip()
    
    def del_host_def_route(self):
        return self._os.del_def_route()
    
    def set_host_ip(self, _nic, _ip, _mask):
        return self._os.set_ip_address(_nic, _ip, _mask)
    
    def set_host_if_status(self, _nic, _up):
        if _up :
            return self._os.ifconfig_up(_nic)
        else:
            return self._os.ifconfig_down(_nic)
    
    def del_host_route(self, _nic, _ip):
        return self._os.delete_route(_nic, _ip)
    
    
    def get_update_vim_public_ip_handler(self, _public_ip, vimUser, vimPass, _ovs_dpdk=False):
        return self._vim.get_public_ip_changer(_public_ip, vimUser, vimPass, not _ovs_dpdk)
    
    def get_del_vm_runner(self, _tenant, _tUser, _tPass):
        return self._vim.get_delete_vm_runner(_tenant, _tUser, _tPass)
    
    def get_del_vnet_runner(self, _tenant, _tUser, _tPass):
        return self._vim.get_delete_vnet_runner(_tenant, _tUser, _tPass)
    
    def _update_vim_ip(self, _to, _prv_mgmt_ip, _uip, _has_utm, _wan_mode, vimUser, vimPass, _ovs_dpdk=False):
        self._info(" Start VIM-IP Update, to=%s"%str(_to))
        _remain = _to
        _sleep = 2
        while True:
            sleep(_sleep)
            _remain -= _sleep
            
            if _remain < 0 :
                self._err("Fail to Update VIM-IP, Time-Out, to=%s"%str(_to))
                return None
            
            _nxt_mgmt_ip = self.get_mgmt_ip(_has_utm, _wan_mode, _uip)
            if _nxt_mgmt_ip == None or str(_nxt_mgmt_ip).strip() == "" :
                self._warn(" - Fail to Update VIM-IP, No IP Info, to=%s"%str(_remain))
                continue
            
            if _prv_mgmt_ip != _nxt_mgmt_ip :
                if not self.chk_ip(_nxt_mgmt_ip) :
                    self._warn("Fail to Update VIM-IP, Invalid IP, ip=%s, to=%s"%( str(_nxt_mgmt_ip), str(_remain) ))
                    continue
                
                _updateHandler = self.get_update_vim_public_ip_handler(_nxt_mgmt_ip, vimUser, vimPass, _ovs_dpdk)
                _updateHandler.start()
                while True :
                    sleep(0.5)
                    if _updateHandler.is_fin() :
                        break
                
                _ret, _err = _updateHandler.result()
                if not _ret :
                    self._err("Fail to Update VIM-IP, ip=%s->%s, err=%s"%( str(_prv_mgmt_ip), str(_nxt_mgmt_ip), str(_err) ))
                else:
                    self._info("SUCC: Update VIM-IP, ip=%s->%s"%( str(_prv_mgmt_ip), str(_nxt_mgmt_ip) ))
                return _nxt_mgmt_ip
            else:
                self._info("SKIP: Update VIM-IP, Same IP")
                return None
            
        return None

    
    def update_vim_ip(self, _ob_info, _prv_mgmt_ip, _to=10, _is_thrd=False):
        _uip = _ob_info.utm_local_ip()
        _has_utm = self.hasUtm(_ob_info.wan_mac_list())
        _wan_mode = self.getWanMode(_ob_info)
        _ovs_dpdk = _ob_info.ovs_dpdk()
        
        if _is_thrd == True :
            _upd = threading.Thread( target=self._update_vim_ip,
                                       args=(_to, _prv_mgmt_ip, _uip, _has_utm, _wan_mode, _ob_info.vim_auth_user(), _ob_info.vim_auth_pass(), _ovs_dpdk) )
            _upd.start()
            return None
        else:
            return self._update_vim_ip(_to, _prv_mgmt_ip, _uip, _has_utm, _wan_mode, _ob_info.vim_auth_user(), _ob_info.vim_auth_pass(), _ovs_dpdk)

    def refresh_wan(self, _net_info, _ob_info, _caller, _dhcp_up=True):
        '''
        func: refresh internet, store
        return: True/False, OB_NET
        '''
        try:
            has_utm = self.hasUtm(_ob_info.wan_mac_list())
            wan_mode = self.getWanMode(_ob_info)
            
            uip = _ob_info.utm_local_ip()
            _mgmt_list = _net_info.mgmt_list
            _wan_list = _net_info.wan_list
            
            if has_utm :
                _retry = ( 10 if wan_mode == oc.VAL_WAN_MD_VNF else 5)
                is_utm_ok = self.get_utm_status(uip, _retry)
            else:
                is_utm_ok = False
            
            _net_info.has_utm = has_utm
            _net_info.wan_mode = wan_mode
            _net_info.is_utm_ok = is_utm_ok
            
            ## In-Band
            # WAN == Host
            if wan_mode == oc.VAL_WAN_MD_HOST :
                # mgmt
                _def_dev, _dev_ip, _dev_metric = self.get_os().get_def_gw_info()
                if not _net_info.set_main_mgmt(_def_dev) :
                    self._err("[%s] - Fail to Refresh Wan, Default-Mgmt-IDX Set Error, gw=%s/%s/%s"%( _caller, str(_def_dev), str(_dev_ip), str(_dev_metric) ))
                _idx = 0
                for _minfo in _mgmt_list :
#                     if _minfo.is_dhcp :
                    _dev = _minfo.dev
                    _nic = _minfo.nic
                    _ip, _mask = self.get_os().get_ip(_dev)
                    _gw = None
                    if _def_dev != None and _dev == _def_dev :
                        _gw = _dev_ip
                    
                    _minfo.set_ip(_ip)
                    _minfo.set_mask(_mask)
                    _minfo.set_gw(_gw)
                    if _minfo.is_dhcp and _dhcp_up and ( _minfo.ip == None or _minfo.mask == None or _minfo.gw == None ) :
                        self.get_os().runDHClient(_nic)
                        _dip, _dmask, _dgw = self.get_os().parseDhclientLease(True, _nic)
                        self.get_os().stopDHClient(_nic)
                        if _minfo.ip == None : _minfo.set_ip(_dip)
                        if _minfo.mask == None : _minfo.set_mask(_dmask)
                        if _minfo.gw == None : _minfo.set_gw(_dgw)
                    
                    _w_info = _wan_list[_idx]
                    _w_info.set_ip(_minfo.ip)
                    _w_info.set_mask(_minfo.mask)
                    _w_info.set_gw(_minfo.gw)
                    _idx += 1
            
            # WAN == VNF
            elif wan_mode == oc.VAL_WAN_MD_VNF and is_utm_ok :
                _wdef_inner_dev, _wdef_ip, _wdef_metric = self.get_vnf_utm().get_def_gw_info(uip)
                _wdef_dev = self.get_vnf_utm().get_br(_wdef_inner_dev)
                _vnf_br_info = self.get_vnf_utm().get_br_info(uip)
                
                ## main nic setting
                # common nic
                _set_main_wan = False
                if _wdef_dev != None :
                    _set_main_wan = True
                    if not _net_info.set_main_wan(_wdef_dev):
                        self._warn("[%s] - Fail to Refresh Wan, Main-WAN-IDX Set Error, gw=%s/%s/%s/%s"%( _caller, str(_wdef_inner_dev), str(_wdef_dev), str(_wdef_ip), str(_wdef_metric) ))
                        _net_info.set_main_wan(0)
                # bridge nic
                else:
                    if type(_vnf_br_info) == dict and _vnf_br_info.has_key(_wdef_inner_dev) :
                        for _winfo in _wan_list :
                            _w_inner_nic = self.to_utm_nic(_winfo.dev)
                            if _w_inner_nic in _vnf_br_info[_wdef_inner_dev] :
                                _set_main_wan = True
                                if not _net_info.set_main_wan(_winfo.dev) :
                                    self._warn("[%s] - Fail to Refresh Wan, Main-WAN-IDX Set Error, gw=%s/%s/%s/%s"%( _caller, str(_wdef_inner_dev), str(_wdef_dev), str(_wdef_ip), str(_wdef_metric) ))
                                    _net_info.set_main_wan(0)
                                break
                
                if not _set_main_wan :
                    self._warn("[%s] - Fail to Refresh Wan, Main-WAN-IDX Set Error, gw=%s/%s/%s/%s"%( _caller, str(_wdef_inner_dev), str(_wdef_dev), str(_wdef_ip), str(_wdef_metric) ))
                    _net_info.set_main_wan(0)
                
                _idx = 0
                for _winfo in _wan_list :
                    ## if bridge on
                    _is_set_br = False
                    if type(_vnf_br_info) == dict and len(_vnf_br_info.keys()) > 0 :
                        for _brname in _vnf_br_info.keys() :
                            if _brname == None or str(_brname).strip() == "":
                                continue
                            _w_inner_nic = self.to_utm_nic(_winfo.dev)
                            if _w_inner_nic in _vnf_br_info[_brname] :
                                _winfo.br = str(_brname).strip()
                                _wip, _wmask = self.get_vnf_utm().get_ip(uip, _winfo.br)
                                _wgwInfo = self.get_vnf_utm().get_gw_info(uip, _dev=_winfo.br)
                                _wgw = None
                                if type(_wgwInfo) in ( list, tuple ) and len(_wgwInfo) > 0 :
                                    _wgw = _wgwInfo[0][1]
                                
                                _winfo.set_ip(_wip)
                                _winfo.set_mask(_wmask)
                                _winfo.set_gw(_wgw)
                                
                                _m_info = _mgmt_list[_idx]
                                _m_info.set_ip(_wip)
                                _m_info.set_mask(_wmask)
                                _m_info.set_gw(_wgw)
                                
                                _is_set_br = True
                                break
                    
#                     if not _is_set_br and _winfo.is_dhcp :
                    if not _is_set_br :
                        _wdev = _winfo.dev
                        _inner_nic = self.get_vnf_utm().get_nic(_wdev)
                        _wip, _wmask = self.get_vnf_utm().get_ip(uip, _inner_nic)
                        _wgwInfo = self.get_vnf_utm().get_gw_info(uip, _dev=_inner_nic)
                        _wgw = None
                        if type(_wgwInfo) in ( list, tuple ) and len(_wgwInfo) > 0 :
                            _wgw = _wgwInfo[0][1]
                        
                        _winfo.br = None
                        _winfo.set_ip(_wip)
                        _winfo.set_mask(_wmask)
                        _winfo.set_gw(_wgw)
                        
                        _m_info = _mgmt_list[_idx]
                        _m_info.set_ip(_wip)
                        _m_info.set_mask(_wmask)
                        _m_info.set_gw(_wgw)
                    
                    _idx += 1
                
            ## Out-Band
            elif wan_mode == oc.VAL_WAN_MD_OUTBAND :
                # mgmt
                _def_dev, _dev_ip, _dev_metric = self.get_os().get_def_gw_info()
                if not _net_info.set_main_mgmt(_def_dev) :
                    self._err("[%s] - Fail to Refresh Wan, Main-WAN-IDX Set Error, gw=%s/%s/%s"%( _caller, str(_def_dev), str(_dev_ip), str(_dev_metric) ))
                for _minfo in _mgmt_list :
#                     if _minfo.is_dhcp :
                    _dev = _minfo.dev
                    _nic = _minfo.nic
                    _ip, _mask = self.get_os().get_ip(_dev)
                    _gw = None
                    if _def_dev != None and _dev == _def_dev :
                        _gw = _dev_ip
                    
                    _minfo.set_ip(_ip)
                    _minfo.set_mask(_mask)
                    _minfo.set_gw(_gw)
                    if _minfo.is_dhcp and _minfo.ip == None or _minfo.mask == None or _minfo.gw == None :
                        self.get_os().runDHClient(_nic)
                        _dip, _dmask, _dgw = self.get_os().parseDhclientLease(True, _nic)
                        self.get_os().stopDHClient(_nic)
                        if _minfo.ip == None : _minfo.set_ip(_dip)
                        if _minfo.mask == None : _minfo.set_mask(_dmask)
                        if _minfo.gw == None : _minfo.set_gw(_dgw)
                
                # if host == dhcp, get gw
                # wan
                if has_utm and is_utm_ok :
                    _wdef_inner_dev, _wdef_ip, _wdef_metric = self.get_vnf_utm().get_def_gw_info(uip)
                    _wdef_dev = self.get_vnf_utm().get_br(_wdef_inner_dev)
                    _vnf_br_info = self.get_vnf_utm().get_br_info(uip)
                    
                    ## main nic setting
                    # common nic
                    _set_main_wan = False
                    if _wdef_dev != None :
                        _set_main_wan = True
                        if not _net_info.set_main_wan(_wdef_dev):
                            self._warn("[%s] - Fail to Refresh Wan, Main-WAN-IDX Set Error, gw=%s/%s/%s/%s"%( _caller, str(_wdef_inner_dev), str(_wdef_dev), str(_wdef_ip), str(_wdef_metric) ))
                            _net_info.set_main_wan(0)
                    # bridge nic
                    else:
                        if type(_vnf_br_info) == dict and _vnf_br_info.has_key(_wdef_inner_dev) :
                            for _winfo in _wan_list :
                                _w_inner_nic = self.to_utm_nic(_winfo.dev)
                                if _w_inner_nic in _vnf_br_info[_wdef_inner_dev] :
                                    _set_main_wan = True
                                    if not _net_info.set_main_wan(_winfo.dev) :
                                        self._warn("[%s] - Fail to Refresh Wan, Main-WAN-IDX Set Error, gw=%s/%s/%s/%s"%( _caller, str(_wdef_inner_dev), str(_wdef_dev), str(_wdef_ip), str(_wdef_metric) ))
                                        _net_info.set_main_wan(0)
                                    break
                    
                    if not _set_main_wan :
                        self._warn("[%s] - Fail to Refresh Wan, Main-WAN-IDX Set Error, gw=%s/%s/%s/%s"%( _caller, str(_wdef_inner_dev), str(_wdef_dev), str(_wdef_ip), str(_wdef_metric) ))

                    _idx = 0
                    for _winfo in _wan_list :
                        ## if bridge on
                        _is_set_br = False
                        if type(_vnf_br_info) == dict and len(_vnf_br_info.keys()) > 0 :
                            for _brname in _vnf_br_info.keys() :
                                if _brname == None or str(_brname).strip() == "":
                                    continue
                                _w_inner_nic = self.to_utm_nic(_winfo.dev)
                                if _w_inner_nic in _vnf_br_info[_brname] :
                                    _winfo.br = str(_brname).strip()
                                    _wip, _wmask = self.get_vnf_utm().get_ip(uip, _winfo.br)
                                    _wgwInfo = self.get_vnf_utm().get_gw_info(uip, _dev=_winfo.br)
                                    _wgw = None
                                    if type(_wgwInfo) in ( list, tuple ) and len(_wgwInfo) > 0 :
                                        _wgw = _wgwInfo[0][1]
                                    
                                    _winfo.set_ip(_wip)
                                    _winfo.set_mask(_wmask)
                                    _winfo.set_gw(_wgw)
                                    
                                    # _m_info = _mgmt_list[_idx]
                                    # _m_info.set_ip(_wip)
                                    # _m_info.set_mask(_wmask)
                                    # _m_info.set_gw(_wgw)
                                    
                                    _is_set_br = True
                                    break
                        
#                         if not _is_set_br and _winfo.is_dhcp :
                        if not _is_set_br :
                            _wdev = _winfo.dev
                            _inner_nic = self.get_vnf_utm().get_nic(_wdev)
                            _wip, _wmask = self.get_vnf_utm().get_ip(uip, _inner_nic)
                            _wgwInfo = self.get_vnf_utm().get_gw_info(uip, _dev=_inner_nic)
                            _wgw = None
                            if type(_wgwInfo) in ( list, tuple ) and len(_wgwInfo) > 0 :
                                _wgw = _wgwInfo[0][1]
                            
                            _winfo.set_ip(_wip)
                            _winfo.set_mask(_wmask)
                            _winfo.set_gw(_wgw)

                        _idx += 1
                elif not has_utm :
                    for _winfo in _wan_list :
                        if _winfo.is_dhcp and (_winfo.ip in (None, "") or _winfo.gw in (None, "")) :
                            self.get_os().runDHClient(_winfo.nic)
                            _dip, _dmask, _dgw = self.get_os().parseDhclientLease(True, _winfo.nic)
                            self.get_os().stopDHClient(_winfo.nic)
                            if _dip != None : _winfo.set_ip(_dip)
                            if _dmask != None : _winfo.set_mask(_dmask)
                            if _dgw != None : _winfo.set_gw(_dgw)
            else:
                self._warn("[%s] - Fail to Refresh Wan, Unknown WanMode, mode=%s"%( _caller, str(wan_mode) ))
            
            _evwan_list = _net_info.extra_vnf_wan_list
            if type(_evwan_list) == list and len(_evwan_list) > 0 :
                # extra vnf wan info
                for _evwan in _evwan_list:
                    _get_ip = False
                    _evw_nic = _evwan.nic
                    if type(self._extra_vnf_list) == list and len(self._extra_vnf_list) > 0 :
                        # plugin info
                        for _evp in self._extra_vnf_list :
                            if type(_evp.p_wan_list) == list and len(_evp.p_wan_list) > 0 :
                                if _evwan.dev in _evp.p_wan_list :
                                    if not _evp.p_lib.login(_evp.p_local_ip, _evp.p_id, _evp.p_pw, 2) :
                                        self._err("[%s] - Fail to Refresh Wan, EVPlugin Login Error, plugin=%s"%( _caller, str(_evp) ))
                                        continue
                                    _evp_inner_nic = _evp.p_lib.to_inner_nic(_evwan.dev)
                                    if _evp_inner_nic == None or str(_evp_inner_nic).strip() == "":
                                        self._err("[%s] - Fail to Refresh Wan, Invalid Inner-Nic, br=%s, inner-nic=%s, plugin=%s"%( _caller, str(_evwan.dev), str(_evp_inner_nic), str(_evp) ))
                                        continue
                                    _m_pub_ip, _m_pub_mask = _evp.p_lib.get_ip(_evp.p_local_ip, _evp_inner_nic)
                                    _m_def_gw_dev, _m_def_gw_ip, _m_def_gw_metric = _evp.p_lib.get_def_gw_info(_evp.p_local_ip)
                                    
                                    _evwan.set_ip(_m_pub_ip)
                                    _evwan.set_mask(_m_pub_mask)
                                    _evwan.set_gw(_m_def_gw_ip)
                                    _get_ip = True
                                    break
                                else:
                                    continue
                            else:
                                self._warn("[%s] - Fail to Refresh Wan, EVPlugin WAN-Info Error, wan=%s"%( _caller, str(_evp.p_wan_list) ))
                    else:
                        self._warn("[%s] - Fail to Refresh Wan, EVPlugin Info Error, plugin-list=%s"%( _caller, str(self._extra_vnf_list) ))
                        break
                    if not _get_ip:
                        self._warn("[%s] - Fail to Refresh Wan, No EVPlugin Info, ewan=%s, plugin-list=%s"%( _caller, str(_evwan), str(self._extra_vnf_list) ))
                    
            return True, _net_info
        except Exception, e:
            self._err("[%s] - Fail to Refresh Wan, exc=%s"%( _caller, str(e) ))
            self._exc(e)
        return False, _net_info
    
    def chk_ip(self, _ip, _mask=None):
        try:
            if _mask == None :
                IPv4Network(_ip)
            else:
                IPv4Network("%s/%s"%( str(_ip), str(_mask) ))
            return True
        except Exception:
            return False
    
    def chk_conn(self, _ob_info, _wan_mode):
        self._debug("chk_conn try...")
        _ecode_list = []
        try:
            _uip = _ob_info.utm_local_ip()
            has_utm = self.hasUtm(_ob_info.wan_mac_list())
            self._debug("[chk_conn try] _uip=%s, has_utm: %s" % (_uip, str(has_utm)))
            if _wan_mode == oc.VAL_WAN_MD_VNF and not has_utm :
                _err = "Wrong Environment, wan_mode=%s, has_utm=%s"%( str(_wan_mode), str(has_utm) )
                self._err("[chk_conn] Fail to Get Chk-Conn, %s"%_err)
                _ecode_list.append(oc.ECD_CHK_CONN_WRONG_ENV)
                return False, _err, _ecode_list
            
            # VNF
            if _wan_mode == oc.VAL_WAN_MD_VNF :
                if not self._os.ping(_uip, 5, 5) :
                    _err = "VNF-Ping Error, ip=%s"%str(_uip)
                    self._err("[chk_conn] Fail to Check-Conn, %s"%_err)
                    _ecode_list.append(oc.ECD_CHK_CONN_LOCAL_UTM)
                    return False, _err, _ecode_list
            
            
            _url, _port = _ob_info.wan_conn_site()
            _mip, _mport = _ob_info.orchm_site()
            _murl = "https://%s:%s"%(str(_mip), str(_mport))
            
            # for VNF Conn
            if _wan_mode == oc.VAL_WAN_MD_VNF :
                _ERR_RET_LIST = {"DNS_PING": oc.ECD_CHK_CONN_VNF_DNS_PING, 
                                 "NO_GW": oc.ECD_CHK_CONN_VNF_NO_GW,
                                 "GW_PING": oc.ECD_CHK_CONN_VNF_GW_PING,
                                 "GW_ARPING": oc.ECD_CHK_CONN_VNF_GW_ARPING,
                                 "NC_SITE": oc.ECD_CHK_CONN_VNF_NC_SITE,
                                 "CURL_MON": oc.ECD_CHK_CONN_VNF_CURL_MON,
                                 "NS_SITE": oc.ECD_CHK_CONN_VNF_NS_SITE}
                _ret, _err, _fail_list = self._vnf_utm.check_conn(_uip, oc.VAL_DEF_DNS_1, oc.VAL_DEF_DNS_2, _url, _port, _murl, _ERR_RET_LIST)
                
                _ecode_list += _fail_list
                if _ret :
                    return True, None, _ecode_list
                
                if _err != None :
                    return False, _err, _ecode_list
            
            # for Host Conn
            else:
                # DNS Ping
                if self._os.ping(oc.VAL_DEF_DNS_1) or self._os.ping(oc.VAL_DEF_DNS_2) :
                    self._info("[chk_conn] SUCC: Chk-Conn, Host-DNS-Ping")
                    return True, None, _ecode_list
                else:
                    self._warn("[chk_conn]  - Fail to Chk-Conn, Host-DNS-Ping")
                    _ecode_list.append(oc.ECD_CHK_CONN_HOST_DNS_PING)
                
                # GW: arping, ping
                _def_gw_dev, _def_gw_ip, _def_gw_metric = self._os.get_def_gw_info()
                if _def_gw_dev == None or _def_gw_ip == None :
                    _err = "Default Host-GW-Info Error, info=%s/%s/%s"%( str(_def_gw_dev), str(_def_gw_ip), str(_def_gw_metric) )
                    self._err("[chk_conn] Fail to Get Check-Conn, %s"%_err)
                    _ecode_list.append(oc.ECD_CHK_CONN_HOST_NO_GW)
                    return False, _err, _ecode_list
                
                _def_dev = _def_gw_dev
                _gw_ip = _def_gw_ip
                if self._os.ping(_gw_ip, 3) :
                    self._info("[chk_conn] SUCC: Chk-Conn, Host-GW-Ping, ip=%s"%(_gw_ip))
                    return True, None, _ecode_list
                else:
                    self._warn("[chk_conn]  - Fail to Chk-Conn, Host-GW-Ping, ip=%s"%(_gw_ip))
                    _ecode_list.append(oc.ECD_CHK_CONN_HOST_GW_PING)
                
                if self._os.arping(_def_dev, _gw_ip, 3) :
                    self._info("[chk_conn] SUCC: Chk-Conn, Host-GW-Arp, dev=%s, ip=%s"%(_def_dev, _gw_ip))
                    return True, None, _ecode_list
                else:
                    self._warn("[chk_conn]  - Fail to Chk-Conn, Host-GW-Arp, dev=%s, ip=%s"%(_def_dev, _gw_ip))
                    _ecode_list.append(oc.ECD_CHK_CONN_HOST_GW_ARPING)
                
                # NC
                if self._os.chk_conn_nc(_url, _port) :
                    self._info("[chk_conn] SUCC: Chk-Conn, Host-NC, site=%s"%str(_url))
                    return True, None, _ecode_list
                else:
                    self._warn("[chk_conn]  - Fail to Chk-Conn, Host-NC, site=%s"%str(_url))
                    _ecode_list.append(oc.ECD_CHK_CONN_HOST_NC_SITE)
                
                # Curl ORCH-M
                if self._os.chk_conn_curl(_murl):
                    self._info("[chk_conn] SUCC: Chk-Conn, Host-Curl, site=Orch-M")
                    return True, None, _ecode_list
                else:
                    self._warn("[chk_conn]  - Fail to Chk-Conn, Host-Curl, site=Orch-M")
                    _ecode_list.append(oc.ECD_CHK_CONN_HOST_CURL_MON)
                
                # NsLookup
                if self._os.chk_conn_nslookup(_url) :
                    self._info("[chk_conn] SUCC: Chk-Conn, Host-NsLookup, site=%s"%str(_url))
                    return True, None, _ecode_list
                else:
                    self._warn("[chk_conn]  - Fail to Chk-Conn, Host-NsLookup, site=%s"%str(_url))
                    _ecode_list.append(oc.ECD_CHK_CONN_HOST_NS_SITE)
            
            return False, "All Connection Chk Error", _ecode_list
        except Exception, e:
            self._err("[chk_conn] Fail to Check OB-Connection, exc=%s"%str(e))
            self._exc(e)
            _ecode_list.append(oc.ECD_CHK_CONN_EXCP)
            return False, str(e), _ecode_list
    
    def chk_mon_file(self):
        try:
            _flist = self.files_in_a_dir(oc.DIR_MONA_KEY)
            _os_mon_key = False
            _vim_mon_key = False
            for _fname in _flist :
                if str(_fname).find("os") > -1 :
                    _os_mon_key = True
                if str(_fname).find("vim") > -1 :
                    _vim_mon_key = True
            
            if not _os_mon_key :
                self._warn("Fail to Check Mon-File, No OS Mon-Key, files=%s"%str(_flist))
                return False
            if not _vim_mon_key :
                self._warn("Fail to Check Mon-File, No VIM Mon-Key, files=%s"%str(_flist))
                return False
            
            return True
        except Exception, e:
            self._err("Fail to Check Mon-File, exc=%s"%str(e))
            self._exc(e)
            return False
    
    def scp_get(self, _host, _port, _src, _dst=None, permission="644"):
        ssh = paramiko.SSHClient()
        scp = None
        try:
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.load_system_host_keys()
            
            _port = int(_port)
            try:
                ssh.connect(_host, _port)
            except Exception:
                import Crypto.Cipher.AES
                orig_new = Crypto.Cipher.AES.new
                def fixed_AES_new(key, *ls):
                    if Crypto.Cipher.AES.MODE_CTR == ls[0] :
                        ls = list(ls)
                        ls[1] = ''
                    return orig_new(key, *ls)
                Crypto.Cipher.AES.new = fixed_AES_new
            scp = SCPClient(ssh.get_transport())
            
            #scp.put('test.txt', 'test2.txt')
            _src = _src.rstrip('\n')
            _getfile = os.path.basename(_src)
            if _dst == None or str(_dst).strip() == "" :
                scp.get(_src)
            else:
                if not os.path.exists(os.path.dirname(_dst)) :
                    os.makedirs(os.path.dirname(_dst))
                
                scp.get(_src, _dst)
                _getfile = _dst
            self._info("SUCC: Run SCP-GET, host=%s, src=%s, dst=%s"%( _host, _src, _dst ))
            
            if permission != None :
                _ret = self._os.set_file_permission(_getfile, str(permission))
                if not _ret :
                    self._warn("Fail to Set File Permission")
            
            return True
        except socket_error, e:
            self._err("Fail to Run SCP-GET, Connection Error, host=%s, err=%s"%( _host, str(e) ))
            self._exc(e)
        except Exception, e :
            self._err("Fail to Run SCP-GET, Unknown Error, host=%s, src=%s, dst=%s, exc=%s"%( _host, _src, _dst, str(e) ))
            self._exc(e)
        finally:
            if scp is not None:
                scp.close()            
            if ssh is not None:
                ssh.close()
            
        return False
    
    def scp_put(self, _host, _port, _src, _dst, permission=None):
        ssh = paramiko.SSHClient()
        scp = None
        try:
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.load_system_host_keys()
            
            _port = int(_port)
            try:
                ssh.connect(_host, _port)
            except Exception:
                import Crypto.Cipher.AES
                orig_new = Crypto.Cipher.AES.new
                def fixed_AES_new(key, *ls):
                    if Crypto.Cipher.AES.MODE_CTR == ls[0] :
                        ls = list(ls)
                        ls[1] = ''
                    return orig_new(key, *ls)
                Crypto.Cipher.AES.new = fixed_AES_new
            
            #scp.put('test.txt', 'test2.txt')
            _remote_cmd = """ mkdir -p %s """%str(_dst)
            try:
                _ret = ssh.exec_command(_remote_cmd, timeout=60)
            except paramiko.SSHException:
                _cmd = self._os.Command()
                cmd_set_known_host = """ ssh -p %s -o StrictHostKeyChecking=no %s echo "A" """%( str(_port), str(_host) )
                _c, _o, _e = _cmd.execute_command(cmd_set_known_host)
                self._warn(" - Set SSH Known_hosts, ip=%s, port=%s, ret=%s, out=%s, err=%s"%( str(_host), str(_port), str(_c), str(_o), str(_e) ))
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.load_system_host_keys()
                ssh.connect(_host, _port)
                _ret = ssh.exec_command(_remote_cmd, timeout=60)
            
            _err = _ret[2].read()
            if _err != None and str(_err).strip() != "" :
                self._err("Fail to Run SCP-PUT, Remote-DIR MAKE ERROR, r-dir=%s, ret=%s"%( str(_dst), str(_err) ))
                return False
            
            _src = _src.rstrip('\n')
            scp = SCPClient(ssh.get_transport())
            scp.put(_src, _dst)
            self._info("SUCC: Run SCP-PUT, host=%s, src=%s, dst=%s" % (_host, _src, _dst))
            if permission != None :
                _ret = self._os.set_remote_file_permission(ssh, str(permission), _dst)
                if not _ret :
                    self._warn("Fail to Set Remote File Permission")
            
            return True
        except socket_error, e:
            self._err("Fail to Run SCP-PUT, Connection Error, host=%s, err=%s"%( _host, str(e) ))
            self._exc(e)
        except Exception, e :
            self._err("Fail to Run SCP-PUT, Unknown Error, host=%s, src=%s, dst=%s, exc=%s"%( _host, _src, _dst, str(e) ))
            self._exc(e)
        finally:
            if scp is not None:
                scp.close()            
            if ssh is not None:
                ssh.close()
            
        return False
    
    def tar(self, output_filename, source_dir, dirs_to_archive):
        try:
            if not os.path.exists(os.path.dirname(output_filename)): 
                os.makedirs(os.path.dirname(output_filename))
            
            with tarfile.open(output_filename, "w:gz") as tar:
                for _dir in dirs_to_archive:
                    src = "%s/%s" % (source_dir, _dir)
                    if os.path.exists(src):
                        tar.add(src, arcname=os.path.basename(src))
            
            return True
        except Exception, e:
            self._err("Fail to Tar File, Unknown Error, out_file=%s, src_dir=%s, recursive_dir=%s, exc=%s"%( output_filename, source_dir, dirs_to_archive, str(e) ))
            self._exc(e)
            return False
    
    def untar(self, _tar_file, _dst_dir):
        try:
            if os.path.exists(_dst_dir): 
                shutil.rmtree(_dst_dir)
            
            if not os.path.exists(_tar_file): 
                self._err("Fail to UnTar File, No File, file=%s"%str(_tar_file))
                return False
            else:
                tar = tarfile.open(_tar_file)
                tar.extractall(path=_dst_dir)
                tar.close()
                self._info("SUCC: UnTar File, file=%s, dst_dir=%s"%( _tar_file, _dst_dir ))
                return True
        except Exception, e:
            self._err("Fail to UnTar File, Unknown Error, file=%s, dst_dir=%s, exc=%s"%( _tar_file, _dst_dir, str(e) ))
            self._exc(e)
            return False
    
    
    def copyFile(self, _src, _dst):
        try:
            if not os.path.exists(_src) :
                self._err("Fail to Copy File, No Source, src=%s, dst=%s"%( _src, _dst ))
                return False
            
            if not os.path.exists(os.path.dirname(_dst)) :
                os.makedirs(os.path.dirname(_dst))
            
            shutil.copy2(_src, _dst)
            
            return True
        except Exception, e:
            self._err("Fail to Copy File, src=%s, dst=%s, exc=%s"%( _src, _dst, str(e) ))
            self._exc(e)
            return False
    
    def copyDir(self, _src, _dst):
        try:
            if not os.path.exists(_src):
                self._err("Fail to Copy Dir, No Source, src=%s, dst=%s"%( _src, _dst ))
                return False
            
            shutil.copytree(_src, _dst)
            
            return True
        except Exception, e:
            self._err("Fail to Copy Dir, src=%s, dst=%s, exc=%s"%( _src, _dst, str(e) ))
            self._exc(e)
            return False
    
    def delFile(self, absPath):
        try:
            if os.path.isfile( absPath ) and os.path.isabs( absPath ):
                os.remove( absPath )
                self._debug("Delete File, f=%s"%str(absPath))
        except Exception, e:
            self._exc(e)
    
    def files_in_a_dir(self, location):
        file_list = []
        for (path, _dir, files) in os.walk(location):
            for filename in files:
                _file = "%s/%s" % (path, filename)
                file_list.append(_file)
        
        return file_list
    
    def files_with_an_extension(self, location, extension):
        file_list = []
        for (path, _dir, files) in os.walk(location):
            for filename in files:
                ext = os.path.splitext(filename)[-1]
                if ext == extension:
                    _file = "%s/%s" % (path, filename)
                    file_list.append(_file)
        
        return file_list
    
    def delete_files(self, file_list):
        try:
            for _file in file_list:
                if os.path.isfile(_file):
                    os.remove(_file)
            return True
        except Exception, e:
            self._err("Fail to Delete Files, exc=%s"%str(e))
            self._exc(e)
            return False

    def truncate_files(self, file_list):
        try:
            for _file in file_list:
                _fd = open(_file, "w+")
                if _fd is not None:
                    _fd.truncate()
                    _fd.close()
            return True
        except Exception, e:
            self._err("Fail to Truncate Files, exc=%s"%str(e))
            self._exc(e)
            return False
    
    def delete_file_recursively(self, location):
        try:
            if not os.path.isabs(location):
                self._err("Fail to Delete File(recursive), Not Abstract Dir, path=%s"%str(location))
                return False
            
            fList = dircache.listdir(location)
            for fName in fList :
                absFName = os.path.join(location, fName)
                if os.path.isfile(absFName):
                    os.remove(absFName)
                elif os.path.isdir(absFName) :
                    self.delete_file_recursively(absFName)
                else:
                    self._warn( "Fail to Delete File(recursive), Unknown File Type, file=%s" % str(absFName) )
                    continue
            
            return True
        except Exception, e:
            self._err("Fail to Delete File(recursive), exc=%s"%str(e))
            self._exc(e)
            return False
    
    def delete_all_recursively(self, location):
        try:
            if not os.path.isabs(location):
                self._err("Fail to Delete All(recursive), Not Abstract Dir, path=%s"%str(location))
                return False
            
            fList = dircache.listdir(location)
            for fName in fList :
                absFName = os.path.join(location, fName)
                if os.path.isfile(absFName):
                    os.remove(absFName)
                elif os.path.isdir(absFName) :
                    shutil.rmtree(absFName)
                else:
                    self._warn( "Fail to Delete All(recursive), Unknown File Type, file=%s" % str(absFName) )
                    continue
            
            return True
        except Exception, e:
            self._err("Fail to Delete All(recursive), exc=%s"%str(e))
            self._exc(e)
            return False
    

def create_lib(_ob_info, _logger=None):
    # TODO check conf file or os info....
    if _ob_info.m_os == oc.VAL_OB_OS_BIG:
        _pfile_os = oc.PLUGIN_OS_BIG
        _pfile_vim = oc.PLUGIN_VIM_BIG
    elif _ob_info.m_os == oc.VAL_OB_OS_DEF:
        _pfile_os = oc.PLUGIN_OS_DEF
        _pfile_vim = oc.PLUGIN_VIM_DEF
    else:
        _logger.error("Fail to Load OS-Lib Plugin, Invalid OS = %s" % _ob_info.m_os)
        return None

    # _pfile = _ob_info.plugin_file_os()
    try:
        _os = importlib.import_module(_pfile_os)
        _logger.debug("OS-Plugin: %s" % str(_os))
    except Exception, e:
        _logger.error("Fail to Load OS-Lib Plugin, plugin=%s, exc=%s"%(str(_pfile_os), str(e)))
        return None
        # from onebox_agent.plugin.obos import linux_plugin as _os
        # if _logger != None : _logger.debug("Load DEF-OS-Lib Plugin, plugin=%s"%(str(_os)))
    
    # _pfile = _ob_info.plugin_file_vim()
    try:
        _vim = importlib.import_module(_pfile_vim)
        _logger.debug("VIM-Plugin: %s"%str(_vim))
    except Exception, e:
        _logger.error("Fail to Load VIM-Lib Plugin, plugin=%s, exc=%s"%(str(_pfile_vim), str(e)))
        return None
        # from onebox_agent.plugin.vim import osp_plugin as _vim
        # if _logger != None : _logger.debug("Load DEF-VIM-Lib Plugin, plugin=%s"%(str(_vim)))
    
    _pfile = _ob_info.plugin_file_utm()
    try:
        _vnf_utm = importlib.import_module(_pfile)
        _pcfg = _ob_info.get_plugin_cfg(_pfile)
        if isinstance(_pcfg, dict) and _pcfg.has_key(oc.CFG_PLUGIN_CFG_MD) and _pcfg[oc.CFG_PLUGIN_CFG_MD] != None and str(_pcfg[oc.CFG_PLUGIN_CFG_MD]).strip() != "" :
            _vnf_utm.load_cfg(str(_pcfg[oc.CFG_PLUGIN_CFG_MD]))
        _logger.debug("UTM-Plugin: %s"%str(_vnf_utm))
    except Exception, e:
        _logger.error("Fail to Load VNF_UTM-Lib Plugin, plugin=%s, exc=%s"%(str(_pfile), str(e)))
        from onebox_agent.plugin.vnf import kt_vnf_plugin as _vnf_utm
        _logger.debug("Load DEF-UTM-Lib Plugin, plugin=%s"%(str(_vnf_utm)))
    
    _evps = _ob_info.plugin_list_extra()
    _extra_vnf_list = None
    if type(_evps) == list and len(_evps) > 0 :
        _extra_vnf_list = []
        for _evp in _evps:
            try:
                _evpf = _evp.file()
                _evpt = _evp.ptype()
                _evpc = _evp.cfg()
                _evpw = _evpc[oc.CFG_PLUGIN_CFG_WAN]
                _evpl = importlib.import_module(_evpf)
                
                _evpm = ( _evpc[oc.CFG_PLUGIN_CFG_MD] if _evpc.has_key(oc.CFG_PLUGIN_CFG_MD) else None)
                _evpi = ( _evpc[oc.CFG_PLUGIN_CFG_IP] if _evpc.has_key(oc.CFG_PLUGIN_CFG_IP) else None)
                if _evpi == None and str(_evpt).upper() == oc.VNFM_PLUGIN_TYPE_PBX :
                    _evpi = oc.VAL_DEF_LOCAL_IP_PBX
                _evpid = ( _evpc[oc.CFG_PLUGIN_CFG_ID] if _evpc.has_key(oc.CFG_PLUGIN_CFG_ID) else None)
                _evppw = ( _evpc[oc.CFG_PLUGIN_CFG_PW] if _evpc.has_key(oc.CFG_PLUGIN_CFG_PW) else None)
                
                _extra_vnf = EVPlugin(_evpl, _evpm, _evpi, _evpf, _evpt, _evpw, _evpc, _evpid, _evppw)
                _extra_vnf_list.append(_extra_vnf)
                _logger.debug("Extra-VNF-Plugin: %s" % str(_evp))
            except Exception, e:
                _logger.error("Fail to Load Extra_VNF-Lib, Plugin=%s, exc=%s" % (str(_evp), str(e)))
    
    return OB_LIB(_os, _vim, _vnf_utm, _extra_vnf_list, _logger)


