#-*- coding: utf-8 -*-

import os, json, ruamel.yaml, datetime
from enum import Enum


from onebox_agent.oba import oba_constant as oac
from onebox_agent.util import ob_constant as oc
from onebox_agent.data import ob_info

import logging
logger = logging.getLogger(oac._L_TITLE)


STATUS_TYPE_BACKUP = "backup"
STATUS_TYPE_RESTORE = "restore"
STATUS_TYPE_WAN = "wan"
STATUS_TYPE_VNF = "vnf_set"

WORK_FAIL = "FAIL"
WORK_DONE = "DONE"
WORK_DOING = "DOING"



def new_tid():
    today = datetime.datetime.now()
    return today.strftime('%y%m%d%H%M')

class OneBoxState(Enum):
    
    STARTING = 1                    # ONEBOX-AGENT가 실행된 상태
    RUNNING = 2                     # ONEBOX-AGENT가 실행되어 ORCHESTRATOR에 접속된 상태
    
    PREPARE_TO_GO_RECOVER = 3       # RECOVER 모드로 이동 준비 (커널 조정)
    
    PREPARE_TO_GO_MAIN = 4          # MAIN 모드로 이동 준비 (커널 조정)
    REQUEST_TO_GO_MAIN = 5          # MAIN 모드로 이동을 위한 재부팅
    
    STARTING_IN_RECOVER = 11         # 재부팅후 ONEBOX-AGENT가 실행된 상태
    RUNNING_IN_RECOVER = 12         # 재부팅후 ONEBOX-AGENT가 실행되어 ORCHESTRATOR에 접속된 상태
    
    RESET_REQUESTED = 13             # RESET 요청을 받은 상태 (FACTORY RESET)
    REQUEST_TO_GO_RESET = 14         # RESET을 위한 재부팅
    RESET_IN_PROGRESS = 15           # ONEBOX-AGENT가 RESET 명령을 시작하여 RESET이 진행되는 상태
    RESET_DONE = 16                  # RESET이 완료된 상태
    RESET_ERROR = 17                 # RESET 오류
    
    RECOVER_REQUESTED = 17           # RECOVER 요청을 받은 상태
    REQUEST_TO_GO_RECOVER = 18       # RESET을 위한 재부팅
    RECOVER_IN_PROGRESS = 19         # ONEBOX-AGENT가 RESET 명령을 시작하여 RESET이 진행되는 상태
    RECOVER_DONE = 20                # RESET이 완료된 상태 
    
    BACKUP_REQUESTED = 31           # BACKUP 요청을 수신한 상태
    BACKUP_IN_PROGRESS = 32         # BACKUP 명령을 수행하고 진행 상태를 확인 중
    BACKUP_DONE = 33                # BACKUP이 완료된 상태
    BACKUP_ERROR = 34                # BACKUP 오류
    
    RESTORE_REQUESTED = 41           # RESTORE 요청을 받은 상태
    RESTORE_IN_PROGRESS = 42         # RESTORE 진행되는 상태
    RESTORE_DONE = 43                # RESTORE가 완료된 상태
    RESTORE_ERROR = 44               # RESTORE중 에러발생
    
    WAN_SW_REQUESTED = 101
    WAN_SW_IN_PROGRESS = 102
    WAN_SW_ERROR = 103
    
    WAN_TEST_REQUESTED = 111
    WAN_TEST_IN_PROGRESS = 112
    WAN_TEST_ERROR = 113
    
    VNF_SET_REQUESTED = 121
    VNF_SET_IN_PROGRESS = 122
    VNF_SET_ERROR = 123
    
    VNF_UNSET_REQUESTED = 131
    VNF_UNSET_IN_PROGRESS = 132
    VNF_UNSET_ERROR = 133
    
    
    UNDEFINED = 999                 # STATE가 지정되지 않은 상태





STAT_BR_PREVENT_DUPL = [OneBoxState.BACKUP_IN_PROGRESS.name, OneBoxState.BACKUP_REQUESTED.name, 
                        OneBoxState.RESTORE_REQUESTED.name, OneBoxState.RESTORE_IN_PROGRESS.name]

STAT_WAN_PREVENT_DUPL = [OneBoxState.WAN_SW_REQUESTED.name, OneBoxState.WAN_SW_IN_PROGRESS.name,
                         OneBoxState.WAN_TEST_REQUESTED.name, OneBoxState.WAN_TEST_IN_PROGRESS.name]

STAT_VNF_PREVENT_DUPL = [OneBoxState.VNF_SET_REQUESTED.name, OneBoxState.VNF_SET_IN_PROGRESS.name,
                         OneBoxState.VNF_UNSET_REQUESTED.name, OneBoxState.VNF_UNSET_IN_PROGRESS.name]

def chk_br_inprogress():
    obstate = StateManager().get_state()
    if obstate['status'] in STAT_BR_PREVENT_DUPL :
        return obstate['status']
    return None

def chk_wan_inprogress():
    wanState = WANStateManager().get_state()
    if wanState['status'] in STAT_WAN_PREVENT_DUPL :
        return wanState['status']
    return None

def chk_vnf_inprogress():
    vnfState = VNFStateManager().get_state()
    if vnfState['status'] in STAT_VNF_PREVENT_DUPL :
        return vnfState['status']
    return None

def chk_all_inprogress():
    _ret = chk_br_inprogress()
    if _ret != None :
        return _ret
    _ret = chk_wan_inprogress()
    if _ret != None :
        return _ret
    _ret = chk_vnf_inprogress()
    if _ret != None :
        return _ret
    
    return None


class _StateManager():
    
    STATE_STORE = None
    
    def get_state(self):
        try:
            with open(self.STATE_STORE, "r") as f:
                obstate = ruamel.yaml.safe_load(f)
        except Exception, e:
            logger.error("Fail to Get State, file=%s, exc=%s"%(self.STATE_STORE, str(e)))
            logger.exception(e)
            obstate = {"status": OneBoxState.UNDEFINED.name}

        return obstate
        
    # OneBox 상태관리시에는 total step과 current step값이 의미가 없으므로 -1을 이용 
    # /status 시에도 상태값만 반환하고, step으 반환안함
    def set_state(self, status, _log=True):
        try:
            if not os.path.exists(os.path.dirname(self.STATE_STORE)):
                os.makedirs(os.path.dirname(self.STATE_STORE))
            
            _save_data = None
            if type(status) == dict :
                _save_data = status
            elif type(status) == OneBoxState :
                _save_data = { 'status': status.name }
            else :
                _save_data = { 'status': status }
            
            with open(self.STATE_STORE, 'w') as f:
                f.write(json.dumps( _save_data ))
            if _log :
                logger.info("SUCC: Set State, file=%s, status=%s"%(self.STATE_STORE, str(_save_data)))
        except Exception, e:
            logger.error("Fail to Set State, file=%s, exc=%s"%(self.STATE_STORE, str(e)))
            logger.exception(e)


class StateManager(_StateManager):
    '''
    For Backup/Restore
    state = {"status": "RUNNING"}
    '''
    STATE_STORE = oc.FILE_STAT_BAK


class WANStateManager(_StateManager):
    '''
    For WAN Switch/Test
    state = {"status": "RUNNING"}
    '''
    STATE_STORE = oc.FILE_STAT_WAN
    

class VNFStateManager(_StateManager):
    '''
    For VNF Set/Unset
    state = {"status": "RUNNING"}
    '''
    STATE_STORE = oc.FILE_STAT_VNF
    

class NetStateManager(_StateManager):
    '''
    For Network Info
    '''
    STATE_STORE = oc.FILE_STAT_NET
    
    def init(self, _ob_info, _ol):
        _net_info = ob_info.OB_NET()
        in_band =_ob_info.is_in_band()
        _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
        _net_info.init(in_band, _ob_info.utm_local_ip(), 
                       _has_utm, _ol.getWanMode(_ob_info), 
                       _ob_info.mgmt_list(), _ob_info.wan_list(), _ob_info.extra_wan_list())
        self.set_state(_net_info.to_dict())
    
    def set_state(self, status, _log=False):
        _StateManager.set_state(self, status, _log=_log)
        
    

class EtcStateManager(_StateManager):
    '''
    For Etc(Scheduler, ...)
    '''
    STATE_STORE = oc.FILE_STAT_ETC
    
    FLD_NOTI_OB_ON = 'noti_ob_on'
    FLD_WAN_SW_ON = 'wan_sw_on'
    FLD_WAN_SW_PAUSE_LIMIT = 'wan_sw_pause_limit'
    
    TP_ALL = "__tp_all__"
    TP_NTF = "__tp_notify__"
    TP_WSW = "__tp_wan_swtich__"
    
    def init(self, _type=TP_ALL):
        _st = {self.FLD_NOTI_OB_ON:True, self.FLD_WAN_SW_ON:True,
               self.FLD_WAN_SW_PAUSE_LIMIT:oc.T_DEF_WAIT_WAN_SW_PAUSE}
        _pst = self.get_state()
        ## INIT NOTI
        if _type == self.TP_NTF :
            if type(_pst) == dict :
                if _pst.has_key(self.FLD_WAN_SW_ON):
                    _st[self.FLD_WAN_SW_ON] = _pst[self.FLD_WAN_SW_ON]
                if _pst.has_key(self.FLD_WAN_SW_PAUSE_LIMIT) :
                    _st[self.FLD_WAN_SW_PAUSE_LIMIT] = _pst[self.FLD_WAN_SW_PAUSE_LIMIT]
        ## INIT WAN SW
        elif _type == self.TP_WSW :
            if type(_pst) == dict :
                if _pst.has_key(self.FLD_NOTI_OB_ON):
                    _st[self.FLD_NOTI_OB_ON] = _pst[self.FLD_NOTI_OB_ON]
        
        self.set_state(_st)
    
    def run_noti_ob_schd(self, doRun):
        '''
        doRun : True/False
        '''
        _stat = self.get_state()
        if type(_stat) != dict :
            _stat = {}
        _stat[self.FLD_NOTI_OB_ON] = doRun
        self.set_state(_stat)
    
    def run_wan_sw_schd(self, doRun, _wait=None):
        '''
        doRun : True/False
        '''
        _stat = self.get_state()
        if type(_stat) != dict :
            _stat = {}
        
        _stat[self.FLD_WAN_SW_ON] = doRun
        _stat[self.FLD_WAN_SW_PAUSE_LIMIT] = oc.T_DEF_WAIT_WAN_SW_PAUSE
        if not doRun and type(_wait) == int :
            _stat[self.FLD_WAN_SW_PAUSE_LIMIT] = _wait
        self.set_state(_stat)
    
    def is_noti_ob_off(self, _cur_is_off):
        _stat = self.get_state()
        if type(_stat) != dict or not _stat.has_key(self.FLD_NOTI_OB_ON):
            logger.warning("Fail to Get Noti-OB-Schd Status, stat=%s"%str(_stat))
            return _cur_is_off
        
        if type(_stat[self.FLD_NOTI_OB_ON]) != bool :
            return _cur_is_off
        
        return not _stat[self.FLD_NOTI_OB_ON]
    
    def is_wan_sw_off(self, _cur_is_off):
        _stat = self.get_state()
        if type(_stat) != dict or not _stat.has_key(self.FLD_WAN_SW_ON):
            logger.warning("Fail to Get Wan-SW-Schd Status, No Data, stat=%s"%str(_stat))
            return _cur_is_off
        
        if type(_stat[self.FLD_WAN_SW_ON]) != bool :
            logger.warning("Fail to Get Wan-SW-Schd Status, Invalid Value, stat=%s"%str(_stat))
            return _cur_is_off
        
        return not _stat[self.FLD_WAN_SW_ON]
    
    def wan_sw_pause_timeout(self):
        _stat = self.get_state()
        if type(_stat) != dict or not _stat.has_key(self.FLD_WAN_SW_PAUSE_LIMIT):
            logger.warning("Fail to Get Wan-SW-Pause TimeOut, stat=%s"%str(_stat))
            return oc.T_DEF_WAIT_WAN_SW_PAUSE
        
        if type(_stat[self.FLD_WAN_SW_PAUSE_LIMIT]) != int :
            logger.warning("Fail to Get Wan-SW-Pause TimeOut, Invalid Value, stat=%s"%str(_stat))
            return oc.T_DEF_WAIT_WAN_SW_PAUSE
        
        return _stat[self.FLD_WAN_SW_PAUSE_LIMIT]


class OBAStatusManager(_StateManager):
    '''
    For WAN Switch/Test
    state = {"status": "RUNNING"}
    '''
    STATE_STORE = oc.FILE_STAT_OBA
    
    FLD_KEEP_BAK = 'keep_backup_stat'
    FLD_KEEP_WAN = 'keep_wan_stat'
    FLD_KEEP_NET = 'keep_net_stat'
    FLD_KEEP_NTF = 'keep_notify_on'
    FLD_KEEP_WSW = 'keep_wansw_on'
    FLD_KEEP_VNF = 'keep_vnf_on'
    
    def init(self):
        self.set_state({self.FLD_KEEP_BAK:False, self.FLD_KEEP_WAN:False, self.FLD_KEEP_NET:False, 
                        self.FLD_KEEP_NTF:False, self.FLD_KEEP_WSW:False, self.FLD_KEEP_VNF:False})
    
    def _set_val(self, _fld, _val):
        _gstat = self.get_state()
        if type(_gstat) != dict :
            _gstat = {_fld:_val}
        else:
            _gstat[_fld] = _val
        self.set_state(_gstat)
    
    def _get_val(self, _fld, _def):
        _gstat = self.get_state()
        if type(_gstat) != dict or not _gstat.has_key(_fld) :
            self._set_val(_fld, _def)
            return _def
        else:
            return _gstat[_fld]
    
    def keep_backup_stat(self, _is_keep): self._set_val(self.FLD_KEEP_BAK, _is_keep)
    def keep_wan_stat(self, _is_keep): self._set_val(self.FLD_KEEP_WAN, _is_keep)
    def keep_net_stat(self, _is_keep): self._set_val(self.FLD_KEEP_NET, _is_keep)
    def keep_ntf_on(self, _is_keep): self._set_val(self.FLD_KEEP_NTF, _is_keep)
    def keep_wsw_on(self, _is_keep): self._set_val(self.FLD_KEEP_WSW, _is_keep)
    def keep_vnf_set(self, _is_keep): self._set_val(self.FLD_KEEP_VNF, _is_keep)
    
    def is_keep_backup_stat(self, _def=False): return self._get_val(self.FLD_KEEP_BAK, _def)
    def is_keep_wan_stat(self, _def=False): return self._get_val(self.FLD_KEEP_WAN, _def)
    def is_keep_net_stat(self, _def=False): return self._get_val(self.FLD_KEEP_NET, _def)
    def is_keep_ntf_on(self, _def=False): return self._get_val(self.FLD_KEEP_NTF, _def)
    def is_keep_wsw_on(self, _def=False): return self._get_val(self.FLD_KEEP_WSW, _def)
    def is_keep_vnf_set(self, _def=False): return self._get_val(self.FLD_KEEP_VNF, _def)
    


class _WorkerStateManager():
    '''
    OneBox State와는 별도로 Worker State를 관리 
    '''
    
    _INIT_STATE_STORE = oc.DIR_STAT_DIR
    
    def __init__(self, _wname, _id):
        self._id = _id            
        self.STATE_STORE = os.path.join(self._INIT_STATE_STORE, ("%s.%s"%( _wname, self._id )))
        self._wname = str(_wname).upper()
    
    def _get_err_state(self, _desc=None):
        pass
    
    def get_state(self):
        try:
            with open(self.STATE_STORE, "r") as f:
                _state = ruamel.yaml.safe_load(f)
        except IOError, e:
            if e.errno == 2 :
                logger.error("Fail to Get %s-State, No File, file=%s"%( self._wname, str(self.STATE_STORE) ))
                logger.exception(e)
                return None
            else:
                logger.error("Fail to Get %s-State, exc=%s"%( self._wname, str(e) ))
                logger.exception(e)
                _state = self._get_err_state(str(e))
        except Exception, e:
            logger.error("Fail to Get %s-State, exc=%s"%( self._wname, str(e) ))
            logger.exception(e)
            _state = self._get_err_state(str(e))
        
        return _state
    
    def _set_state(self, _state):
        try:
            with open(self.STATE_STORE, 'w') as f:
                f.write(json.dumps( _state ))
        except Exception, e:
            logger.error("Fail to Set %s-State, exc=%s"%( self._wname, str(e) ))
            logger.exception(e)
    


class BRStateManager(_WorkerStateManager):
    '''
    OneBox State와는 별도로 BackupState를 관리 
    '''
    def __init__(self, _type, transaction_id):
        _WorkerStateManager.__init__(self, _type, transaction_id)
    
    def _get_err_state(self, _desc=None):
        return {"status": "ERROR", "current_step": -1, "total_step": -1, "progress": "ERROR__%d__%d"%(-1, -1)}
    
    def set_state(self, status, cur_step = -1 , tot_step = -1):
        str_progress = "%s__%d__%d" % (status.name, cur_step, tot_step)
        obstate = {"status": status.name, "current_step": cur_step, "total_step": tot_step, "progress": str_progress}
        self._set_state(obstate)



class WanWorkManager(_WorkerStateManager):
    
    def __init__(self, wid):
        _WorkerStateManager.__init__(self, STATUS_TYPE_WAN, wid)
    
    def _get_err_state(self, _desc=None):
        return {"status": WORK_FAIL, "desc": _desc}
    
    def set_state(self, status, desc):
        _state = {"status": status, 'desc': desc}
        self._set_state(_state)



class VnfWorkManager(_WorkerStateManager):
    
    def __init__(self, wid):
        _WorkerStateManager.__init__(self, STATUS_TYPE_VNF, wid)
    
    def _get_err_state(self, _desc=None):
        return {"status": WORK_FAIL, "desc": _desc}
    
    def set_state(self, status, desc):
        _state = {"status": status, 'desc': desc}
        self._set_state(_state)



