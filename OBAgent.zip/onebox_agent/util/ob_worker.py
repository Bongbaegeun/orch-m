#-*- coding: utf-8 -*-
'''
Created on 2017. 10. 24.

@author: ohhara
'''


import sys, threading, tempfile, traceback, os
from time import sleep

from onebox_agent.util import ob_constant as oc
from onebox_agent.data.ob_info import OB_INFO





_LOG_T = "[OB_WRK:%s.%-4s]"
def _getLineNo():
    org_f = None
    try:
        raise Exception
    except:
        org_f = sys.exc_info()[2].tb_frame.f_back
    #On some versions of IronPython, currentframe() returns None if
    #IronPython isn't run with -X:Frames.
    if org_f is not None:
        f = org_f.f_back
    else:
        return None
    
    if f == None :
        return None
    
    l_no = f.f_lineno
    return l_no










class _IncProg(threading.Thread):
    
    def __init__(self, _progMng, _period, _inc, _max=None):
        threading.Thread.__init__(self)
        
        self._prog = _progMng
        self._run = True
        self._period = _period
        self._inc = _inc
        self._max = _max
    
    def stop(self):
        if not self._run :
            return
        self._run = False
        sleep(self._period+0.2)
    
    def start(self):
        sleep(0.5)
        if not self.isAlive() :
            try:
                threading.Thread.start(self)
            except RuntimeError :
                pass
    
    def run(self):
        while self._run :
            sleep(self._period)
            if not self._run or self._prog.rate() >= 100 :
                break
            try:
                self._prog.inc(self._inc, self._max)
            except Exception:
                pass


class _ObWorker(threading.Thread):
    
    ITEM_LIST = []
    PROG_LIST = []
    
    STAT_COMP = 0
    STAT_RUN = 1
    STAT_UNSUPP = 2
    STAT_ROLLBACK = 2
    STAT_ERR = -1
    
    def __init__(self, _name, _logger=None):
        threading.Thread.__init__(self)
        
        self.name = _name
        self.logger = _logger
        
        self._index = 0
        self._status = self.STAT_RUN
        self._err = None
        self._return = None
        
        self._incprog = None
        self._rollback = False
        self._subtitle = None
    
    def _debug(self, msg):
        msg = _LOG_T%(self.name, str(_getLineNo())) + " " + str(msg)
        if self.logger != None : self.logger.debug(msg)
    
    def _info(self, msg):
        msg = _LOG_T%(self.name, str(_getLineNo())) + " " + str(msg)
        if self.logger != None : self.logger.info(msg)
    
    def _warn(self, msg):
        msg = _LOG_T%(self.name, str(_getLineNo())) + " " + str(msg)
        if self.logger != None : self.logger.warning(msg)
    
    def _error(self, msg):
        msg = _LOG_T%(self.name, str(_getLineNo())) + " " + str(msg)
        if self.logger != None : self.logger.error(msg)
    
    def _excp(self, exc):
        _SERR = tempfile.TemporaryFile()
        traceback.print_exc(exc, _SERR)
        _SERR.seek(0)
        msg = _SERR.read()
        msg = _LOG_T%(self.name, str(_getLineNo())) + "\n" + str(msg)
        if self.logger != None : self.logger.fatal(msg)
    
    def _complete(self):
        if self._incprog != None : self._incprog.stop()
        
        if len(self.PROG_LIST) > self._index :
            self.PROG_LIST[self._index] = 100
        else:
            self._warn("  - Invalid Prog Index, prog=%s, idx=%s"%( str(self.PROG_LIST), str(self._index) ))
        
        if len(self.ITEM_LIST) > self._index :
            if len(self.ITEM_LIST) > self._index + 1 :
                self._index += 1
            self._subtitle = self.ITEM_LIST[self._index]
            self._itemprog = self.PROG_LIST[self._index]
        else:
            self._subtitle = "No Item"
            self._itemprog = 0
    
    def _fin_err(self, _err):
        if self._incprog != None : self._incprog.stop()
        if self._rollback :
            self._status = self.STAT_ROLLBACK
        else:
            self._status = self.STAT_ERR
        self._err = str(_err)
        self._return = None
    
    def _fin_ok(self, _return=None):
        if self._incprog != None : self._incprog.stop()
        self._status = self.STAT_COMP
        self._err = None
        self._return = _return
    
    def inc(self, _inc, _max=None):
        if len(self.PROG_LIST) > self._index :
            _now_rate = self.PROG_LIST[self._index]
            if _max == None :
                self.PROG_LIST[self._index] = max(0, min(99, _inc + _now_rate))
            else:
                self.PROG_LIST[self._index] = max(0, min(min(_max, (_now_rate+_inc)), 99))
        else:
            self._warn("  - Invalid Prog Index, prog=%s, idx=%s"%( str(self.PROG_LIST), str(self._index) ))
    
    def set_rate(self, _rate):
        if len(self.PROG_LIST) > self._index :
            self.PROG_LIST[self._index] = max(0, min(100, _rate))
        else:
            self._warn("  - Invalid Prog Index, prog=%s, idx=%s"%( str(self.PROG_LIST), str(self._index) ))
        
    def rate(self):
        if len(self.PROG_LIST) > self._index :
            return self.PROG_LIST[self._index]
        else:
            self._warn("  - Invalid Prog Index, prog=%s, idx=%s"%( str(self.PROG_LIST), str(self._index) ))
            return -1
    
    def get_idx(self):
        return self._index
    
    def item(self):
        if len(self.ITEM_LIST) > self._index :
            return self.ITEM_LIST[self._index]
        else:
            self._warn("  - Invalid Prog Index, prog=%s, idx=%s"%( str(self.PROG_LIST), str(self._index) ))
            return "No Item"
    
    def item_list(self):
        return self.ITEM_LIST
    
    def get_info(self):
        return self._status, self.ITEM_LIST, self.PROG_LIST
    
    def result(self):
        return self._status, self._return, self._err
    
    def start_inc(self, _period, _inc, _max=None):
        self._incprog = _IncProg(self, _period, _inc, _max)
        self._incprog.start()
    
    def stop_inc(self):
        if self._incprog != None :
            self._incprog.stop()
            self._incprog = None
    
    


class ObWork_Recovery(_ObWorker):
    
    def __init__(self, _ol, _logger, local_location, _untar_loc, backup_server_ip, backup_server_port, remote_location, _oba_restart, _ovs_dpdk=False):
        _ObWorker.__init__(self, "RECOVERY", _logger)
        
        self._ol = _ol
        self.local_loc = local_location
        self.untar_loc = _untar_loc
        self.backup_ip = backup_server_ip
        self.backup_port = backup_server_port
        self.remote_loc = remote_location
        self.oba_restart = _oba_restart
        self.ovs_dpdk = _ovs_dpdk
        
        self.ITEM_LIST = ["Get OB-Info", "Get Backup-Files", "Restore VIM", "Restore Agents", 
                          "Get New OB-Info", "Restore VNet", "Restore VI-BR", "Restore Host-BR"]
        if self.oba_restart :
            self.ITEM_LIST.append("Restart OBA")
        self.PROG_LIST = [0]*len(self.ITEM_LIST)
    
    def run(self):
        self._info("Start OB-Recovery Worker")
        try:
            ### 1. get OB-INFO
            self.set_rate(5)
            self.start_inc(2, 1)
            
            import ruamel.yaml
            with open(oc.FILE_OBA_CONF, "r") as f:
                _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
            _prev_ob_info = OB_INFO().loadByCfg(_oba_cfg, True)
            
            self.stop_inc()
            self._info(" - Succ: %s, ob-info=%s"%( self._subtitle, str(_prev_ob_info) ))
            self._complete()
            
            
            ### 2. get backup files
            # location backup 파일 존재 확인.
            # 있을 시 파일 압축 해제 (/tmp)
            # 없을 시 remote backup 파일 존재 확인
            #     있을 시 파일 복사 및 압축 해제 
            #     없을 시 error 반환
            self.set_rate(5)
            self.start_inc(2, 1)
            
            if not os.path.exists(self.local_loc):
                _ret = self._ol.scp_get(self.backup_ip, self.backup_port, self.remote_loc, self.local_loc)
                if not _ret: 
                    self._error("Fail to Recovery, No Backup File, local=%s, remote=%s, backup_svr=%s:%s"%( self.local_loc, self.remote_loc, self.backup_ip, str(self.backup_port) ))
                    self._fin_err("No Backup File, local=%s, remote=%s, backup_svr=%s:%s"%( self.local_loc, self.remote_loc, self.backup_ip, str(self.backup_port) ))
                    return
            
            if not self._ol.untar(self.local_loc, self.untar_loc) :
                self._error("Fail to Recovery, Backup File UnTar Error, tarfile=%s, dst=%s"%(
                                                self.local_loc, self.untar_loc))
                self._fin_err("Backup File UnTar Error, tarfile=%s, dst=%s"%( self.local_loc, self.untar_loc ))
                return
            
            self.stop_inc()
            self._info(" - Succ: %s, file=%s, dir=%s"%( self._subtitle, self.local_loc, self.untar_loc ))
            self._complete()
            
            
            ### 3. OpenStack Services
            self.set_rate(5)
            self.start_inc(2, 1)
            # NOVA
            # for dpdk vs normal
#             if not self._ol.restore_service(self.untar_loc, oc.FILE_BACKUP_SRC_NOVA, oc.SVC_RESTORE_NOVA) :
            if not self._ol.restart_service(oc.SVC_RESTORE_NOVA) :
                self._warn(" - Fail to Recovery, NOVA Restore Error")
            # Neutron
            # for dpdk vs normal
#             if not self._ol.restore_service(self.untar_loc, oc.FILE_RESTORE_SRC_NEUTRON, oc.SVC_RESTORE_NEUTRON) :
            if not self._ol.restart_service(oc.SVC_RESTORE_NEUTRON) :
                self._warn(" - Fail to Recovery, NEUTRON Restore Error")
            
            self.stop_inc()
            self._info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 4. OB Agents
            self.set_rate(5)
            self.start_inc(2, 1)
            # VNFM
            if not self._ol.restore_service(self.untar_loc, oc.FILE_BACKUP_SRC_VNFM, oc.SVC_RESTORE_VNFM, oc.DIR_RESTORE_VNFM) :
                self._warn(" - Fail to Recovery, VNFM Restore Error")
            
            # MON Agent
            if not self._ol.restore_service(self.untar_loc, oc.FILE_BACKUP_SRC_MONA, oc.SVC_RESTORE_MONA, oc.DIR_RESTORE_MONA) :
                self._warn(" - Fail to Recovery, MON-Agent Restore Error")
            
            # NMS Agent
            if not self._ol.restore_service(self.untar_loc, oc.FILE_BACKUP_SRC_NMSA, oc.SVC_RESTORE_NMSA) :
                self._warn(" - Fail to Recovery, NMS-Agent Restore Error")

            # SMS Agent
            if not self._ol.restore_service(self.untar_loc, oc.FILE_BACKUP_SRC_SMSA, oc.SVC_RESTORE_SMSA) :
                self._warn(" - Fail to Recovery, SMS-Agent Restore Error")

            # OneBox Agent
            if not self._ol.restore_service(self.untar_loc, oc.FILE_BACKUP_SRC_OBA, oc.SVC_RESTORE_OBA, restart=False) :
                self._warn(" - Fail to Recovery, Onebox-Agent Restore Error")
            self._ol.correct_mac()
            
            self.stop_inc()
            self._info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 5. Load new ob-info
            self.set_rate(5)
            self.start_inc(2, 1)
            
            with open(oc.FILE_OBA_CONF, "r") as f:
                _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
            _new_ob_info = OB_INFO().loadByCfg(_oba_cfg, True)
            
            ## hw/os
            _new_ob_info.m_hw = self._ol.get_hw_info(_new_ob_info)
            _new_ob_info.m_os = self._ol.get_os_info()
            
            ## mgmt
            for _mgmt in _new_ob_info.mgmt_list() :
                _mac = self._ol.get_host_mac(_mgmt.nic(), _nic_model=_new_ob_info.hw_nic_model())[_mgmt.nic()]
                _mgmt.set_mac(_mac)
            
            # wan
            for _wan in _new_ob_info.wan_list() :
                _mac = self._ol.get_host_mac(_wan.nic(), _nic_model=_new_ob_info.hw_nic_model())[_wan.nic()]
                _wan.set_mac(_mac)
            
            # evwan
            _evwan_list = _new_ob_info.extra_wan_list()
            if type(_evwan_list) == list :
                for _evw in _evwan_list :
                    _evw_nic = _evw.nic()
                    _evw_mac = self._ol.get_host_mac(_evw_nic, _nic_model=_new_ob_info.hw_nic_model())[_evw_nic]
                    _evw.set_mac(_evw_mac)
            
            # VET
            _ovs_dpdk, _err = self._ol.is_enable_ovs_dpdk()
            if not _ovs_dpdk :
                _new_ob_info.m_vet = None
            else:
                _new_ob_info.set_vet_mode(_ovs_dpdk={})
            
            # Plugin
            _new_ob_info.m_plugin_list = None
            
            try:
                _new_ob_info.saveToCfg()
            except Exception, e:
                self._error("Fail to Recovery, OBA-Config Save Error, exc=%s, ob_info=%s"%( str(e), str(_new_ob_info) ))
                self._excp(e)
                self._fin_err("OBA-Config Save Error, exc=%s"%( str(e) ))
                return 
            
            self.stop_inc()
            self._info(" - Succ: %s, new ob-info=%s"%( self._subtitle, str(_new_ob_info) ))
            self._complete()
            
            
            ### 6. VNet
            self.set_rate(5)
            self.start_inc(2, 1)
            
            ## delete lan
            _runner = self._ol.get_del_vnet_runner(_prev_ob_info.vim_tenant(), 
                                                    _prev_ob_info.vim_tenant_user(), 
                                                    _prev_ob_info.vim_tenant_pass())
            _runner.start()
            while True :
                sleep(0.5)
                if _runner.is_fin():
                    break
            
            _res, _err = _runner.result()
            if not _res:
                self._error("Fail to Recovery, VNet Delete Error, err=%s"%( str(_err) ))
                self._fin_err("VNet Delete Error, err=%s"%( str(_err )))
                return
            
            ## create lan
            _tenant = _new_ob_info.vim_tenant()
            _tUser = _new_ob_info.vim_tenant_user()
            _tPass = _new_ob_info.vim_tenant_pass()
            _lan_list = _new_ob_info.lan_net_list()
            for _lan in _lan_list :
                _ret, _err = self._ol.get_vim().create_lan_vnetwork(_lan.gw(), _lan.mask(), _lan.name(), _tenant, _tUser, _tPass)
                if not _ret :
                    self._error("Fail to Recovery, VNet Create Error, err=%s, vnet=%s"%( str(_err), str(_lan) ))
                    self._fin_err("VNet Create Error, err=%s, vnet=%s"%( str(_err), str(_lan) ))
                    return
            
            self.stop_inc()
            self._info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 7. VI-BR
            self.set_rate(5)
            self.start_inc(2, 1)
            
            ## reset all v-port
            _ret, _err = self._ol.get_vim().reset_vim_bridge(oc.VAL_DEF_VI_WAN_BR_LIST+oc.VAL_DEF_VI_LAN_BR_LIST+oc.VAL_DEF_VI_EWAN_BR_LIST)
            if not _ret :
                self._error("Fail to Recovery, VI-BR Reset Error, err=%s"%( str(_err) ))
                self._fin_err("VI-BR Reset Error, err=%s"%( str(_err) ))
                return
            
            ## set only-v-port
            # LAN
            for _lan in _lan_list :
                _vbr_name = oc.VAL_DEF_VNF_LAN_BR_PFX + _lan.name()
                for _lnic in _lan.nics() :
                    _ret = self._ol.get_vim().add_br_port(_vbr_name, _lnic, self.ovs_dpdk)
                    if not _ret :
                        self._error("Fail to Recovery, VPort Setting Error, vport=%s:%s"%( str(_vbr_name), str(_lnic) ))
                        self._fin_err("VPort Setting Error, vport=%s:%s"%( str(_vbr_name), str(_lnic) ))
                        return
            # OUT-BAND's WAN
            if not _new_ob_info.is_in_band() :
                for _wan in _new_ob_info.wan_list() :
                    _vbr_name = _wan.bridge()
                    _wnic = _wan.nic()
                    _ret = self._ol.get_vim().add_br_port(_vbr_name, _wnic, self.ovs_dpdk)
                    if not _ret :
                        self._error("Fail to Recovery, VPort Setting Error, vport=%s:%s"%( str(_vbr_name), str(_wnic) ))
                        self._fin_err("VPort Setting Error, vport=%s:%s"%( str(_vbr_name), str(_wnic) ))
                        return
            
            self.stop_inc()
            self._info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 8. Host-Net
            self.set_rate(5)
            self.start_inc(2, 1)
            
            ## delete default-gw
            if not self._ol.del_host_def_route() :
                self._warn(" - Fail to Delete Host Def-GW")
            
            ## reset all host-br
            _ret, _err = self._ol.get_os().reset_os_bridge()
            if not _ret :
                self._error("Fail to Recovery, OS-BR Reset Error, err=%s"%( str(_err) ))
                self._fin_err("OS-BR Reset Error, err=%s"%( str(_err) ))
                return
            
            ## set host i/f
            _mgmt_list = _new_ob_info.mgmt_list()
            _ret, _err = self._ol.config_mgmt_net(_mgmt_list)
            if not _ret :
                self._error("Fail to  Recovery, Host-Net Config Error, err=%s"%( _err ))
                self._fin_err("Host-Net Config Error, err=%s"%( _err ))
                return
            
            self.stop_inc()
            self._info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 9. OBA
            if self.oba_restart :
                self.set_rate(5)
                self.start_inc(2, 1)
                
                self._info("-------- OBA Restart !!!!! --------")
                self._ol.restart_service([oc.VAL_OBA_NAME])
                
                self.stop_inc()
                self._info(" - Succ: %s"%( self._subtitle ))
                self._complete()
            
            self._fin_ok()
        except Exception, e:
            self._error("Fail to Recovery, Unknown Error, exc=%s"%( str(e) ))
            self._excp(e)
            self._fin_err(str(e))
        
        












