#-*- coding: utf-8 -*-
'''
Created on 2017. 8. 2.

@author: ohhara
'''


import traceback, threading, iniparse, ConfigParser, urlparse, MySQLdb, sys, tempfile
import heatclient.exc as heatException
from time import sleep
from ipaddr import IPv4Network


def _getLineNo():
    org_f = None
    try:
        raise Exception
    except:
        org_f = sys.exc_info()[2].tb_frame.f_back
    #On some versions of IronPython, currentframe() returns None if
    #IronPython isn't run with -X:Frames.
    if org_f is not None:
        f = org_f.f_back
    else:
        return None
    
    if f == None :
        return None
    
    l_no = f.f_lineno
    return l_no

logger = None
_LOG_T = "[PLG-OSP.%-4s]"
def _debug(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.debug(msg)
    else: print msg

def _info(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.info(msg)
    else: print msg

def _warn(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.warning(msg)
    else: print msg

def _error(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.error(msg)
    else: print msg

def _except(exc):
    _SERR = tempfile.TemporaryFile()
    traceback.print_exc(exc, _SERR)
    _SERR.seek(0)
    msg = _SERR.read()
    msg = _LOG_T%str(_getLineNo()) + "\n" + str(msg)
    if logger != None : logger.fatal(msg)
    else: print msg





from onebox_agent.plugin.obos import linux_plugin as lp
lp.logger = logger
_command = lp.Command()


_DEF_OVS_BR = ["br-wan", "br-wan1", "br-wan2", "br-wan3", "br-lan-office", "br-lan-server"]

_NIC_TYPE_NORM = "_nic_norm_"
_NIC_TYPE_DPDK = "_nic_dpdk_"

_VET_DPDK = "dpdk"
# _VET_DPDK_CMD = "/usr/local/sbin/dpdk-devbind"
_VET_DPDK_CMD = "/sbin/dpdk-devbind"
#_VET_DPDK_DRV = "uio_pci_generic"
_VET_DPDK_DRV = "igb_uio"

_OVS_BR_DP_TYPE_NETDEV = "netdev"
_OVS_TAG_DPDK_VAR = "dpdk-devargs"
_OVS_NET_DRV_PRX = "net_"
_OVS_DPDK_PROC = "networking-ovs-dpdk-agent"
_OVS_NORM_PROC = "neutron-plugin-openvswitch-agent"

_VIM_RESTART_PROC = ["nova-novncproxy", "nova-compute", _OVS_NORM_PROC, _OVS_DPDK_PROC]


def get_net_name(_name):
    return "net_%s"%str(_name)

def is_ok_ovs_dpdk():
    try:
        for _brname in _DEF_OVS_BR :
            _cmd = """ ovs-vsctl get bridge %s datapath_type """%str(_brname)
            _s, _o, _e = _command.execute_command(_cmd)
            if str(_e).find("no row") > -1  :
                continue
            
            if str(_e).strip() != "" :
                _error("Fail to Get OVS-DPDK Status, VI-BR Info Get Error, err=%s"%str(_e))
                return False, "VI-BR Info Get Error, err=%s"%str(_e)
            
            if str(_o).find(_OVS_BR_DP_TYPE_NETDEV) > -1 :
                continue
            else:
                _warn(" - Fail to Get OVS-DPDK Status, Wrong BR-TYPE, type=%s"%str(_o))
                return False, "Wrong VI-BR TYPE, type=%s"%str(_o)
            
        _s, _o, _e = _command.execute_command(_VET_DPDK_CMD)
        if _s != 0 :
            _warn(" - Fail to Get OVS-DPDK Status, No DPDK-EXEC, exec=%s"%str(_VET_DPDK_CMD))
            return False, "No DPDK-EXEC, exec=%s"%str(_VET_DPDK_CMD)
        
        _cmd = """ ps -ef | grep -v grep | grep -c "python.*%s" """ % _OVS_DPDK_PROC
        _s, _o, _e = _command.execute_command(_cmd)
        try:
            if int(_o) < 1 :
                _warn(" - Fail to Get OVS-DPDK Status, No OVS-DPDK Proc, proc=%s"%str(_OVS_DPDK_PROC))
                _info(" Retry find OVS-DPDK Status in other_config ")
                _cmd_select = "ovs-vsctl list Open_vSwitch"
                _s, _o, _e = _command.execute_command(_cmd_select)
                _result = ''.join(_o.split())
                if _result.find('other_config') < 0 or _result.find('dpdk-init="true"') < 0:
                    _warn(" - Fail to Get OVS-DPDK Status, No OVS-DPDK Config, %s"%_cmd_select)
                    return False, ""

        except Exception, e :
            _warn(" - Fail to Get OVS-DPDK Status, OVS-DPDK Proc Get Error, proc=%s, exc=%s"%(_OVS_DPDK_PROC, str(e)))
            return False, "OVS-DPDK Proc Get Error, proc=%s, exc=%s"%(_OVS_DPDK_PROC, str(e))
        
        return True, None
    except Exception, e:
        _error("Fail to Get OVS-DPDK Status, exc=%s"%str(e))
        _except(e)
        return False, str(e)

def init_ovs_port(_nic_pci):
    try:
        _cmd = """ ovs-appctl netdev-dpdk/detach %s """%str(_nic_pci)
        _status, _output, _e = _command.execute_command(_cmd)
        if str(_e).strip() != "" :
            if str(_e).find("not found") > -1 :
                _debug(" - SKIP to Detach NIC, pci=%s"%( _nic_pci ))
            else:
                _warn(" - Fail to Detach NIC, NIC Detach Error, pci=%s, err=%s"%(_nic_pci, str(_e)))
                return False, "NIC Detach Error, err=%s"%str(_e)
        return True, None
    except Exception, e:
        _error("Fail to Detach ovs-nic, pci=%s, exc=%s"%(str(_nic_pci), str(e) ))
        _except(e)
        return False, str(e)


def get_br():
    '''
    return : br list list or None
    '''
    try:
        _cmd = """ ovs-vsctl list-br """
        _status, _output, _e = _command.execute_command(_cmd)
        if _status != 0 or str(_e).strip() != "" :
            _error("Fail to Get OVS-BR List, ret=%s, output=%s, err=%s"%( str(_status), str(_output), str(_e) ))
            return None
        
        return str(_output).split()
    except Exception, e:
        _error("Fail to Get OVS-BR List, Occur Error, exc=%s"%str(e))
        _except(e)
        return None

def get_br_ifs(_brName):
    '''
    return : br if list or None
    '''
    try:
        _cmd = """ ovs-vsctl list-ports %s | grep -v "phy-br" """%( str(_brName) )
        _status, _output, _e = _command.execute_command(_cmd)
        if str(_e).strip() != "" :
            _error("Fail to Check OVS-BR, br=%s, ret=%s, output=%s, err=%s"%( str(_brName), str(_status), str(_output), str(_e) ))
            return None
        
        return str(_output).split()
    except Exception, e:
        _error("Fail to Get ovs-br if, Occur Error, exc=%s"%str(e))
        _except(e)
        return None

def del_br_port(_brIF, _brName=None):
    try:
        _cmd = """ ovs-vsctl get Interface %s status:pci-device_id status:pci-vendor_id type option type option """%str(_brIF)
        _status, _output, _e = _command.execute_command(_cmd)
        
        if str(_e).strip().find("no row") > -1 :
            _info("SKIP: Delete OVS-BR Port, No Port, br=%s, port=%s"%( str(_brName), str(_brIF)))
            return True
        
        _nic_type = _NIC_TYPE_NORM
        _nic_pci = None
        _nic_drv = None
        if _e != None and str(_e).strip() != "" and len(str(_output).strip().split()) != 3 :
            _warn(" - Fail to Delete OVS-BR Port, Port Get Error, ret=%s, out=%s, err=%s"%( str(_status), str(_output), str(_e) ))
        else:
            __nic_info = str(_output).strip().split()
            __nic_type = str(__nic_info[2]).replace('"', '').strip().lower()
            __nic_pci = str(__nic_info[3]).replace('"', "").replace("{", "").replace("}", "")
            __nic_pci = (None if __nic_pci.find(_OVS_TAG_DPDK_VAR) < 0 else (
                                __nic_pci.split("=")[1]) )
            
            # driver
            __nic_dvc = str(__nic_info[0]).replace('"', '').strip().lstrip("0x")
            __nic_vnd = str(__nic_info[1]).replace('"', '').strip().lstrip("0x")
            __nic_vnd = format(int(__nic_vnd), "#04x").lstrip("0x")
            _cmd = """ cat /lib/modules/$(uname -r)/modules.alias | grep -i "%s.*%s" | tail -n 1 | awk '{print $3}' """%(__nic_vnd, __nic_dvc)
            _ret, _out, _e = _command.execute_command(_cmd)
            if str(_out).strip() == "" :
                _warn(" - Fail to Delete OVS-BR Port, PCI Init-Driver Get Error, pci=%s, vendor=%s, device=%s"%( __nic_pci, str(__nic_vnd), str(__nic_dvc) ))
            
            __nic_drv = (None if str(_out).strip() == "" else str(_out).strip() )
            if __nic_type == _VET_DPDK :
                if __nic_pci != None and __nic_drv != None :
                    _nic_type = _NIC_TYPE_DPDK
                    _nic_pci = __nic_pci
                    _nic_drv = __nic_drv
                    _info(" - Get OVS-DKDP, nic=%s, type=%s, pci=%s, driver=%s"%( _brIF, _nic_type, _nic_pci, _nic_drv ))
                else:
                    _warn(" - Fail to Delete OVS-BR Port, DPDK-NIC Parsing Error, info=%s"%str( __nic_info ))
            else:
                _debug(" - Delete OVS-BR Port, Get OVS_NORM, nic=%s, nic_info=%s"%( _brIF, str(__nic_info) ))
        
        
        _brName = ("" if _brName == None else _brName)
        _cmd = """ timeout -s 9 60 ovs-vsctl del-port %s %s """%( str(_brName), str(_brIF) )
        _status, _output, _e = _command.execute_command(_cmd)
        if _status != 0 and str(_e).find("no port") < 0 and str(_e).find("does not have") < 0 :
            _error("Fail to Delete OVS-BR Port, ret=%s, output=%s, err=%s"%( str(_status), str(_output), str(_e) ))
            
            # for dpdk bug
            _cmd = """ killall ovs-vsctl """
            _ret, _out, _e = _command.execute_command(_cmd)
            return False
        else:
            if _nic_type == _NIC_TYPE_DPDK :
                _ret, _err = init_ovs_port(_nic_pci)
                if _ret :
                    _info(" - Delete OVS-BR Port, Detach NIC, nic=%s, pci=%s, out=%s"%( _brIF, _nic_pci, str(_output) ))
                else:
                    _error("Fail to Delete OVS-BR Port, NIC Detach Error, nic=%s, pci=%s, err=%s"%(
                                                    _brIF, _nic_pci, str(_e)))
                    return False
                
                _cmd = """ %s -b %s %s """%( _VET_DPDK_CMD, _nic_drv, _nic_pci )
                _status, _output, _e = _command.execute_command(_cmd)
                if str(_output).strip() != "" and str(_output).find("already bound") > -1 :
                    _error("Fail to Delete OVS-BR Port, NIC Bind Error, nic=%s, driver=%s, pci=%s, err=%s"%(
                                                    _brIF, _nic_drv, _nic_pci, str(_output)))
                    return False
                else:
                    _info(" - Delete OVS-BR Port, Bind NIC, nic=%s, driver=%s, pci=%s"%( _brIF, _nic_drv, _nic_pci ))
            return True
    except Exception, e:
        _error("Fail to Delete OVS-BR Port, Occur Except, exc=%s"%str(e))
        _except(e)
        return False

def del_br_port_all(_brPort):
    try:
        _cmd = """ ovs-vsctl port-to-br %s """%str(_brPort)
        _status, _output, _e = _command.execute_command(_cmd)
        if str(_e).find("no port") > -1 :
            _warn("Skip to Delete OVS-BR Port, No Port's Owner, cmd=%s"%_cmd)
            return True
        if str(_e) != "" :
            _error("Fail to Delete OVS-BR Port, BR Get Error, ret=%s, output=%s, err=%s"%( str(_status), str(_output), str(_e) ))
            return False
        
        _br_list = str(_output).split()
        for _br in _br_list :
            del_br_port(_brPort, _br)
            sleep(3)
        
        return True
    except Exception, e:
        _error("Fail to Delete OVS-BR Port, Occur Except, exc=%s"%str(e))
        _except(e)
        return False

def add_br_port(_brName, _brIF, _ovs_dpdk=False):
    try:
        _nic_pci = None
        if _ovs_dpdk :
            _cmd_down = """ ifconfig %s down """%(str(_brIF))
            _ret, _out, _e = _command.execute_command(_cmd_down)
            _debug(" - Add-OVS-PORT: ifconfig down, cmd=%s, ret=%s, out=%s, err=%s"%(_cmd_down, str(_ret), str(_out), str(_e) ))
            
            # _cmd_pci = """ %s -s | grep %s | awk '{print $1}' """%( _VET_DPDK_CMD, str(_brIF) )
            _cmd_pci = """ %s -s | grep -w '%s' | awk '{print $1}' """%( _VET_DPDK_CMD, str(_brIF) )
            _ret, _out, _e = _command.execute_command(_cmd_pci)
            if str(_out).strip() == "" or str(_out).find(":") < 0 :
                _error("Fail to Add OVS-BR Port, NIC PCI-No Get Error, cmd=%s, out=%s, err=%s"%( _cmd_pci, _out, _e ))
                return False
            
            _nic_pci = str(_out).strip().replace("pci@", "")
            
            _cmd = """ %s -b %s %s """%( _VET_DPDK_CMD, _VET_DPDK_DRV, str(_nic_pci) )
            _ret, _out, _e = _command.execute_command(_cmd)
            sleep(3)
            if str(_out).strip() != "" and str(_out).find("already bound") < 0 :
                _error("Fail to Add OVS-BR Port, NIC Bind Error, cmd=%s, ret=%s, output=%s, err=%s"%( str(_cmd), str(_ret), str(_out), str(_e) ))
                return False
            else:
                _info(" - Add OVS-BR Port, Bind NIC, nic=%s, driver=%s, pci=%s"%( _brIF, _VET_DPDK_DRV, _nic_pci ))
        
        _cmd = """ timeout -s 9 60 ovs-vsctl add-port %s %s """%( str(_brName), str(_brIF) )
        if _ovs_dpdk :
            _cmd +=  """ -- set Interface %s type=dpdk options:dpdk-devargs=%s """%( str(_brIF), _nic_pci )
        
        _ret, _out, _e = _command.execute_command(_cmd)
        if _ret != 0 and str(_e).find("already exists") < 0  :
            _error("Fail to Add OVS-BR Port, cmd=%s, ret=%s, output=%s, err=%s"%( _cmd, str(_ret), str(_out), str(_e) ))
            
            # for dpdk bug
            _cmd = """ killall ovs-vsctl """
            _ret, _out, _e = _command.execute_command(_cmd)
            return False
        else:
            if _ovs_dpdk :
                _info("SUCC: Add OVS-BR Port, cmd=%s"%str(_cmd))
            return True
    except Exception, e:
        _error("Fail to Add OVS-BR Port, Occur Error, exc=%s"%str(e))
        _except(e)
        return False


def config_vi_network(_net_name, _net_if_list, _ovs_dpdk=False):
    try:
        # remove existing ports from ovs
        if _net_name == None:
            _error("Fail to Config OVS-NET, No Net-Name")
            return False, "No VI-Network Name"
        
        _port_list = get_br_ifs(_net_name)
        if _port_list == None : 
            _error("Fail to Config OVS-NET, OVS-BR-Port Get Error, br=%s"%( _net_name ))
            return False, "OVS-BR-Port Get Error"
        _info(" OVS-NET[%s] Port: %s"%( _net_name, _port_list ))
        
        # delete existing ports in ovs
        for _port in _port_list :
            _ret = del_br_port(_port)
            if _ret :
                _info(" OVS-NET[%s] Port Delete, port=%s"%( _net_name, _port ))
            else:
                _error("Fail to Config OVS-NET, Port Delete Error, net=%s, port=%s"%( _net_name, _port ))
                return False, "OVS-NET Port Delete Error"
        
        # add port to ovs
        for _ifname in _net_if_list:
            if _ifname == None or str(_ifname).strip() == "" :
                _warn(" Invalid OVS-Port, Net=%s, Port=%s"%( _net_name, str(_ifname) ))
                continue
            _ret = add_br_port(_net_name, str(_ifname), _ovs_dpdk)
            if not _ret :
                _error("Fail to Config OVS-NET, Port Add Error, net=%s, port=%s"%( _net_name, str(_ifname) ))
                return False, "OVS-NET Port Add Error"
            else:
                _info(" OVS-NET[%s] Port Add, port=%s"%( _net_name, _ifname ))
        
        return True, None
    except Exception, e:
        _error("Fail to Config OVS-NET, exc=%s"%str(e))
        _except(e)
        return False, "Unknown Error, exc=%s"%str(e)
        
def create_lan_vnetwork(_gw, _mask, _net_name, _tenant, _tUser, _tPass, _net_type="flat", _host=None):
    try:
        try:
            _ipnet = IPv4Network("%s/%s"%( _gw, _mask ))
        except Exception :
            return False, "Invalid Address, gw=%s, mask=%s"%( str(_gw), str(_mask) )
        
        if _net_name == None or str(_net_name).strip() == "" :
            return False, "No vNet Name"
        
        _util = _HeatUtil(_tenant, _tUser, _tPass, _host)
        _vnet_name = "net_" + str(_net_name).strip()
        _physnet = "physnet_lan_" + str(_net_name).strip()
        _cidr="%s/%s"%(_ipnet.network, _ipnet.prefixlen)
        
        # delete prev Net
        _net_id = _util.get_network_id(_vnet_name)
        if _net_id != None and _net_id != "" :
            if not _util.delete_network(_net_id) :
                _warn("Fail to Delete vNetwork, net=%s, id=%s"%( _vnet_name, _net_id ))
        
        _ret = _util.create_neutron_network(_vnet_name, _physnet, _net_type, _cidr)
        if _ret :
            _info("SUCC: Create LAN vNet, net=%s"%_vnet_name)
            return True, None
        else:
            _error("Fail to Create vNet, net=%s"%_vnet_name)
            return False, "Fail to Create vNet, net=%s"%_vnet_name
    except Exception, e:
        _error("Fail to Create vNetwork, net=%s, exc=%s"%( _net_name, str(e) ))
        _except(e)
        return False, "Unknown Error, exc=%s"%str(e)

def remove_lan_vnetwork(_net_name, _tenant, _tUser, _tPass, _host=None):
    if _net_name == None or str(_net_name).strip() == "" :
        return False, "No vNet Name"
    
    _vnet_name = "net_" + str(_net_name).strip()
    
    try:
        _util = _HeatUtil(_tenant, _tUser, _tPass, _host)
        _net_id = _util.get_network_id(_vnet_name)
        if _net_id == None or _net_id == '' :
            _error("Fail to Remove VNet-LAN, No VNet ID, name=%s"%str(_vnet_name))
            return False, "No VNet ID"
        
        if not _util.delete_network(_net_id) :
            _error("Fail to Remove VNet-LAN, Remove Operation Error, name=%s"%str(_vnet_name))
            return False, "Remove Operation Error"
        
        _net_id = _util.get_network_id(_vnet_name)
        if _net_id != None and _net_id != '' :
            _error("Fail to Remove VNet-LAN, Remove Error, name=%s, id=%s"%( str(_vnet_name), str(_net_id) ))
            return False, "Remove Error"
        
        return True, None
    except Exception, e:
        _error("Fail to Remove VNet-LAN, net=%s, exc=%s"%( _vnet_name, str(e) ))
        _except(e)
        return False, "Unknown Error, exc=%s"%str(e)

def reset_vim_bridge(ovs_list):
    if type(ovs_list) != list :
        return False, "No OVS-Bridge, br=%s"%str(ovs_list)
    
    _ovs_brs = get_br()
    try:
        for ovs in ovs_list:
            if not ovs in _ovs_brs :
                _debug(" - NO OVS-BR Info, BR=%s" % ovs)
                continue
            
            port_list = get_br_ifs(ovs)
            if port_list == None : 
                _error("Fail to Reset OVS-BR, Port Get Error, br=%s"%( ovs ))
                return False, "OVS-BR Port Get Error, br=%s"%ovs
            
            # delete existing ports in ovs
            for port in port_list:
                if not port.startswith("phy"):
                    _ret = del_br_port(port)
                    if not _ret : 
                        _error("Fail to Reset OVS-BR, OVS-BR Port Delete Error, br=%s, port=%s"%( ovs, port ))
                        return False, "OVS-BR Port Delete Error, br=%s, port=%s"%( ovs, port )
                    _info("   Delete OVS-BR Port, br=%s, port=%s"%( ovs, port ))
        _info("SUCC: Reset OVS-BR")
        return True, None
    except Exception, e:
        _error("Fail to Clear OVS-BR, exc=%s"%str(e))
        _except(e)
        return False, "OVS-BR Clear Exception"
        
def get_public_ip():
    try:
        _CMD = """ openstack --insecure endpoint show nova -f json -c publicurl """
        # [{"Field": "publicurl", "Value": "https://175.213.170.152:8774/v2/%(tenant_id)s"}]
        _status, _ret, _e = _command.execute_command(_CMD)
        if _status != 0 or str(_ret).strip() == "" :
            _error("Fail to Get OpenStack Public IP, status=%s, ret=%s"%( str(_status), str(_e)))
            return None
        try:
            import json
            _json_ret = json.loads(str(_ret))
            _nova_url_info = str(_json_ret[0]['Value'])
            _nova_url_comp = _nova_url_info.split("//").pop().rsplit(":")
            _prevOspIP = _nova_url_comp[0]
            IPv4Network(_prevOspIP)
        except Exception, e:
            _error("Fail to Get OpenStack Public IP, invalid ip=%s"%str(_ret))
            return None
        return _prevOspIP
    except Exception, e:
        _error("Fail to Get Public IP, Occur Error, exc=%s"%str(e))
        _except(e)
        return None

def is_in_used(_pci_no, _fail_return=True):
    _CMD = """ ovs-vsctl show | grep -c "%s" """%str(_pci_no)
    try:
        _s, _r, _e = _command.execute_command(_CMD)
        _debug(" - Get OVS-PCI-Status, cmd=%s, out=%s, err=%s"%( _CMD, str(_r), str(_e) ))
        try:
            if int(_r) > 0:
                return True
            else:
                return False
        except Exception, e:
            _error("Fail to Get OVS-PCI-Status, cmd=%s, out=%s, err=%s, exc=%s"%( 
                                                str(_pci_no), str(_r), str(_e), str(e) ))
            _except(e)
            return _fail_return
    except Exception, e:
        _error("Fail to Get OVS-PCI-Status, Occur Error, pci=%s, exc=%s"%(str(_pci_no), str(e)))
        _except(e)
        return _fail_return

def is_master(_br, _nics):
    _CMD_LINK_MASTER = """ ip link show %s | grep -c "ovs-system" """
    try:
        _res = False
        for _nic in _nics :
            if _nic == None or str(_nic) == "" :
                continue
            
            _nic = str(_nic)
            _cmd = _CMD_LINK_MASTER%_nic
            _status, _ret, _e = _command.execute_command(_cmd)
            if str(_e).strip().find("not exist") > -1 :
                _cmd_ovs = """ ovs-vsctl get Interface %s admin_state | grep -c -i "up"  """%str(_nic)
                _status, _ret, _e = _command.execute_command(_cmd_ovs)
                try:
                    _ret = int(_ret)
                    if _ret > 0 :
                        _res = True
                    else:
                        return False
                except (ValueError, TypeError) as e:
                    _error("Fail to Check Nic's Owner, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd_ovs, str(_status), str(_ret), str(_e) ))
                    return False
            else:
                try:
                    _ret = int(_ret)
                    if _ret > 0 :
                        _res = True
                    else:
                        return False
                except (ValueError, TypeError) as e:
                    _error("Fail to Check Nic's Owner, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_status), str(_ret), str(_e) ))
                    return False
        
        if not _res :
            _error("Fail to Check Nic's Owner, No Nic")
        return _res
    except Exception, e:
        _error("Fail to Check Nic's Owner, exc=%s"%str(e))
        _except(e)
        return False

def has_utm(_mac_list):
    try:
        _cmd = """ virsh list | grep "^ *[0-9]" | awk '{print $1}' """
        _status, _output, _e = _command.execute_command(_cmd)
        if _status != 0 or _output == None :
            _error("Fail to Get VM List, cmd=%s, ret=%s, output=%s"%( _cmd, str(_status), str(_e) ))
            return False
        
        _macList = []
        for _mac in _mac_list :
            if _mac == None :
                continue
            
            _mn_mac = str(_mac).strip()
            if _mn_mac == "":
                continue
            
            if not _mn_mac in _macList :
                _macList.append(_mn_mac)
        
        if len(_macList) < 1 :
            _error("Fail to Get Mac Address..")
            return False
        
        _txtMac = "\|".join(_macList)
        _vidList = list(set(str(_output).split()))
        if len(_vidList) < 1:
            _info("Fail to Chk UTM, No VM")
            return False
        
        for _vID in _vidList :
            _cmd = """ virsh dumpxml %s | grep -c "%s" """%(str(_vID), _txtMac )
            _status, _output, _e = _command.execute_command(_cmd)
            try:
                if int(_output) > 0 :
                    return True
            except Exception, e:
                _warn("Fail to Check Utm, Invalid Output, output=%s"%_e)
        return False
    except Exception, e:
        _error("Fail to Get UTM Status, Occur Error, exc=%s"%str(e))
        _except(e)
        return False

def get_public_ip_changer(_public_ip, vimUser, vimPass, restart=True):
    return _UpdatePublicIP(_public_ip, "/etc/nova/nova.conf", "127.0.0.1", "keystone", vimUser, vimPass, restart)

def get_delete_vm_runner(_tenant, _tUser, _tPass, _host=None):
    return _HeatUtil(_tenant, _tUser, _tPass, _HeatUtil.TYPE_DELETE_ALL_STACK, _host)

def get_delete_vnet_runner(_tenant, _tUser, _tPass, _host=None):
    return _HeatUtil(_tenant, _tUser, _tPass, _HeatUtil.TYPE_RESET_NETWORK, _host)

class _OpenStackConfig():
    
    def __init__(self, cfgfile):
        self.cfgfile = cfgfile
    
    def read(self):
        try:
            conf = self._parse_file()
    
            # DEFAULT 섹션이 없으면 이를 추가 
            if not conf.items(iniparse.DEFAULTSECT):
                conf = self._parse_file(add_default=True)
        except ConfigParser.MissingSectionHeaderError:
            conf = self._parse_file(add_default=True)
        except ConfigParser.ParsingError, e:
            _error("Fail to Read OpenStack Config, Occur Error, exc=%s"%str(e))
            _except(e)
            return None
            
        self.conf = conf
        return self.conf
    
    def write(self, conf):
        # XXX: Ideally we should just do conf.write(f) here,
        # but to avoid iniparse issues, we massage the data a little here
        try:
            with open(self.cfgfile, 'w') as f:
                str_data = str(conf.data)
                if len(str_data) and str_data[-1] != '\n':
                    str_data += '\n'
        
                #str_data = str_data.replace('[%s]\n' % iniparse.DEFAULTSECT, '', 1)
                f.write(str_data)
            return True
        except Exception, e:
            _error("Fail to Write OpenStack Config, Occur Error, exc=%s"%str(e))
            _except(e)
            return False
    
    def update(self, section, name, value):
        try:
            if not self.conf:
                _error("Fail to Update OpenStack Config, No config")
                return False
            else:
                self.conf.set(section, name, value)
                return True
        except Exception as e:
            _error("Fail to Update OpenStack Config, Occur Error, exc=%s"%str(e))
            _except(e)
            return False
    
    def _parse_file(self, add_default=False):
        # Note we use RawConfigParser rather than SafeConfigParser
        # to avoid unwanted variable interpolation.
        
        # Note iniparse doesn't currently support allow_no_value=True.
        try:
            fp = open(self.cfgfile)
            conf = iniparse.RawConfigParser()
            conf.readfp(fp)
            return conf
        except IOError as e:
            _error("Fail to Parse OpenStack Config, Occur Error, exc=%s"%str(e))
            _except(e)
            return None


class _UpdatePublicIP(threading.Thread):
    
    def __init__(self, _public_ip, _nova_cfg, _dbHost, _dbName, _dbUser, _dbPass, _restart=True):
        threading.Thread.__init__(self)
        
        self._nova_cfg = _nova_cfg
        self._public_ip = _public_ip
        self._dbHost = _dbHost
        self._dbName = _dbName
        self._dbUser = _dbUser
        self._dbPass = _dbPass
        self._restart = _restart
        
        self._endpoint_type = "public"
        
        self.__prog = 0
        self.__fin = False
        self.__result = False
        self.__err_msg = None
    
    def is_fin(self):
        return self.__fin
    
    def prog(self):
        return self.__prog
    
    def result(self):
        return self.__result, self.__err_msg
    
    def _fin_err(self, _msg):
        self.__fin = True
        self.__result = False
        self.__err_msg = _msg
    
    def _fin_ok(self):
        self.__fin = True
        self.__result = True
    
    def _inc(self, _inc_num):
        self.__prog += _inc_num
    
    def _update_vnc_url(self):
        ## Nova VNC Update
        try:
            os_cfg = _OpenStackConfig(self._nova_cfg)
            cfg = os_cfg.read()
            
            # need to check url (http or https?)
            _prev_vnc_url = str(cfg.get("DEFAULT", "novncproxy_base_url"))
            vnc_url = "https://%s:6080/vnc_auto.html" %  self._public_ip
            if _prev_vnc_url == vnc_url :
                _info("Succ: Already Modified Nova VNC URL")
                self._inc(40)
                return True
            os_cfg.update("DEFAULT", "novncproxy_base_url", vnc_url)
            os_cfg.write(cfg)
        except Exception, e:
            _error("Fail to Update Config, exc=%s"%str(e))
            _except(e)
            self._fin_err("Fail to Update Config, exc=%s"%str(e))
            return False
        _info("Succ: Nova VNC URL Modification")
        self._inc(10)
        
        _ovs_dpdk, _err = is_ok_ovs_dpdk()
        if self._restart and not _ovs_dpdk :
            ## Osp Service Restart
            services = _VIM_RESTART_PROC
            try:
                for service in services:
                    _info("Restart OpenStack %s" % service)
                    _cmd_svc = "service %s restart" % service
                    _command.execute_command(_cmd_svc)
                    sleep(1)
                    
                    _cmd_status = "service %s status" % service
                    (_code, ret_out, ret_err) = _command.execute_command(_cmd_status)
                    self._inc(10)
                    if ret_out.find ("is running") != -1:
                        continue
                    elif ret_out.find ("start/running") != -1:
                        continue
                    elif ret_out.find ("start/post-stop") != -1:
                        continue
                    elif ret_out.find ("Running") == 0:
                        continue
                    
                    if service in ( _OVS_NORM_PROC, _OVS_DPDK_PROC ) :
                        _warn(" - Fail to Restart OpenStack Service, svc=%s, ret=%s, out=%s, err=%s"%( service, str(_code), str(ret_out), str(ret_err) ))
            except Exception, e:
                _error("Fail to Restart OpenStack Service, exc=%s"%str(e))
                _except(e)
                self._fin_err("Fail to Restart OpenStack Service, exc=%s"%str(e))
                return False
        _info("Succ: Restart OpenStack Service")
        return True
    
    def _update_db(self):
        db = None
        cur = None
        try:
            db = MySQLdb.connect(host=self._dbHost, user=self._dbUser, passwd=self._dbPass, db=self._dbName)
            cur = db.cursor()
            
            str_query = "select id, url from endpoint where interface='%s'" % self._endpoint_type
            cur.execute(str_query)
            for row in cur.fetchall():
                endpoint_id = str(row[0])
                url = str(row[1])
                try:
                    u = urlparse.urlparse(url)
                    prevIP = str(u.hostname).strip()
                    if prevIP != self._public_ip :
                        urlstring = "%s://%s:%s%s" % (u.scheme, self._public_ip, u.port, u.path)
                        _info("Update OpenStack Endpoint, url=%s" % urlstring)
                        cur.execute("""UPDATE endpoint SET url=%s WHERE id=%s """, (urlstring, endpoint_id))
                    
                    self._inc(5)
                except Exception, e:
                    _error("Fail to Update OpenStack Endpoint, exc=%s, url=%s"%( str(e), str(url) ))
                    _except(e)
                    self._fin_err("Fail to Update OpenStack Endpoint, exc=%s"%str(e))
                    return False
            
            db.commit()
        except Exception, e:
            _error("Fail to Update OpenStack Endoint, exc=%s"%str(e))
            _except(e)
            self._fin_err("Fail to Update_openStack Endpoint, exc=%s"%str(e))
            return False
        finally:
            if cur != None : cur.close()
            if db != None : db.close()
        
        _info("Succ: Update OpenStack Endpoint")
        return True
    
    def run(self):
        ## Nova VNC Update
        if not self._update_vnc_url() :
            return
        
        ## Endpoint Update
        if not self._update_db() :
            return
        self._fin_ok()



class _HeatUtil(threading.Thread):
    
    TYPE_DELETE_ALL_STACK = 0
    TYPE_RESET_NETWORK = 1
    
    RESET_NET = ['net_office', 'net_server', 'net_internet', 'net_internet1', 'net_internet2', 'net_internet3', 'net_extrawan1', 'net_extrawan2']
    
    def __init__(self, _tenant, _tUser, _tPass, _type, _host="vOneBox"):
        threading.Thread.__init__(self)
        
        self.__type = _type
        
        self.__tenant = (lambda x: "admin" if x == None else x)(_tenant)
        self.__user = (lambda x: "admin" if x == None else x)(_tUser)
        self.__pass = (lambda x: "kt@ne130X" if x == None else x)(_tPass)
        self.__host = (lambda x: "vOneBox" if x == None else x)(_host)
        
        self.__prog = 0
        self.__fin = False
        self.__result = False
        self.__err_msg = None
    
    def _inc(self, _inc_num):
        _tot = self.__prog + _inc_num
        if _tot >= 100 :
            self.__prog = 99
        else:
            self.__prog = _tot
    
    def _fin_err(self, _err):
        self.__fin = True
        self.__result = False
        self.__err_msg = _err
    
    def _fin_ok(self):
        self.__fin = True
        self.__result = True
        self.__err_msg = None
        self.__prog = 100
    
    def is_fin(self):
        return self.__fin
    
    def prog(self):
        return self.__prog
    
    def result(self):
        return self.__result, self.__err_msg
    
    def run(self):
        if self.__type == self.TYPE_DELETE_ALL_STACK :
            self.delete_stack_if_any()
        elif self.__type == self.TYPE_RESET_NETWORK :
            self.reset_network()
    
    def _set_keystone_credential(self, auth_url, tenant, user, passwd, timeout_value=30):
        self.k_creds={}
        self.k_creds['auth_url'] = auth_url
        self.k_creds['tenant_name'] = tenant
        self.k_creds['username'] = user
        self.k_creds['password'] = passwd
        self.k_creds['insecure'] = True
        self.k_creds['timeout'] = timeout_value
        
        self.n_creds={}
        self.n_creds['auth_url'] = auth_url
        self.n_creds['project_id']  = tenant
        self.n_creds['username'] = user
        # self.n_creds['api_key']  = passwd
        self.n_creds['insecure'] = True
        self.n_creds['timeout'] = timeout_value
        
    def _load_connection(self, timeout_value=30):
        '''called before any operation, it check if credentials has changed'''
        # control the timing and possible token timeout, but it seams that python client does this task for us :-)
        try:
            
            # import keystoneclient.v2_0.client as ksClient
            # self._set_keystone_credential("https://%s:35357/v2.0"%self.__host, self.__tenant, self.__user, self.__pass)
            # self.keystone = ksClient.Client(**self.k_creds)
            # self._inc(1)
            import keystoneclient.v3.client as ksClient
            self._set_keystone_credential("https://%s:35357/v3" % self.__host, self.__tenant, self.__user, self.__pass)
            self.keystone = ksClient.Client(**self.k_creds)
            self._inc(1)

            from novaclient import client as nClient
            self.nova = nClient.Client(2, **self.n_creds)
            _debug("NOVA: %s" %str(self.nova))
            self._inc(1)
            
            import glanceclient.v2.client as glClient
            self.glance_endpoint = self.keystone.service_catalog.url_for(service_type='image', endpoint_type='publicURL')
            _debug("GLANCE: endpoint = %s" %self.glance_endpoint)
            self.glance = glClient.Client(self.glance_endpoint, token=self.keystone.auth_token, **self.k_creds)
            #check k_creds vs n_creds
            self._inc(1)
            
            from neutronclient.neutron import client as neClient
            self.ne_endpoint=self.keystone.service_catalog.url_for(service_type='network', endpoint_type='internalURL')
            _debug("NEUTRON: endpoint = %s" % self.ne_endpoint)
            self.neutron = neClient.Client('2.0', endpoint_url=self.ne_endpoint, token=self.keystone.auth_token, **self.k_creds)
            self._inc(1)
            
            self.heat_endpoint = self.keystone.service_catalog.url_for(service_type='orchestration', endpoint_type='publicURL')
            _debug("HEAT: endpoint = %s" %self.heat_endpoint)
            self._inc(1)
            
            from heatclient.client import Client as heatClient
            self.heat = heatClient('1', endpoint=self.heat_endpoint, token=self.keystone.auth_token, **self.k_creds)
            self._inc(1)
        except heatException.NotFound, e:
            error_text=str(type(e))[6:-1] + ": " + (str(e) if len(e.args)==0 else str(e.args[0]))
            _error("Fail to Load Openstack Connection, err=%s"%error_text)
            _except(e)
        except Exception, e:
            error_text="Unknown Error " + str(e)
            _error("Fail to Load Openstack Connection, err=%s"%error_text)
            _except(e)
            
    def _get_stack_list(self):
        kwargs = {}
        stacks = []
        try:
            self._load_connection()
            stack_list = self.heat.stacks.list(**kwargs)
            self._inc(5)
            
            for stack in stack_list:
                stack_id = getattr(stack, "id")
                stack_name = getattr(stack, "stack_name")
                
                _debug("stack_id= %s stack_name= %s" % (stack_id, stack_name))
                stacks.append(stack_id)
            
            self._inc(5)
        except heatException.NotFound, e:
            error_text=str(type(e))[6:-1] + ": " + (str(e) if len(e.args)==0 else str(e.args[0]))
            _error("Fail to Get OpenStack Stack List, err=%s"%error_text)
            _except(e)
        except Exception, e:
            error_text="Unknown Error " + str(e)
            _error("Fail to Get OpenStack Stack List, err=%s"%error_text)
            _except(e)
        
        return stacks
    
    def delete_stack_if_any(self):
        try:
            stacks = self._get_stack_list()
            if len(stacks) == 0:
                _debug("No stacks to delete")
                self._fin_ok()
                return True
            
            for stack_id in stacks:
                _debug("delete stack, stack_id= %s" % stack_id)
                self._delete_stack(stack_id)
                result = self._check_stack_deleted(stack_id)
                if not result:
                    _error("failed to delete stack, stack_id= %s" % stack_id)
                    self._fin_err("Stack Delete Error")
                    return False
            
            self._fin_ok()
            return True
        except heatException.NotFound, e:
            error_text=str(type(e))[6:-1] + ": " + (str(e) if len(e.args)==0 else str(e.args[0]))
            _error("Fail to Delele All OpenStack Stack, err=%s"%error_text)
            _except(e)
            self._fin_err("All Stack Delete Error")
            return False
        except Exception, e:
            error_text="Unknown Error " + str(e)
            _error("Fail to Delele All OpenStack Stack, err=%s"%error_text)
            _except(e)
            self._fin_err("All Stack Delete Error")
            return False
            
            
    def _delete_stack(self, stack_uuid, stack_name = None):
        try:
            _debug("stack_uuid = %s, stack_name =%s" %(stack_uuid, stack_name))
            self._load_connection()
            
            if stack_name:
                _debug("delete_heat_stack_v4() stack_name =%s" %(stack_name))
                self.heat.stacks.delete(stack_name)
            else:
                _debug("delete_heat_stack_v4() stack_uuid =%s" %(stack_uuid))
                self.heat.stacks.delete(stack_uuid)
            
            self._inc(5)
        except heatException.NotFound, e:
            error_text=str(type(e))[6:-1] + ": " + (str(e) if len(e.args)==0 else str(e.args[0]))
            _error("Fail to Delete Openstack Stack, err=%s"%error_text)
            _except(e)
        except Exception, e:
            error_text="Unknown Error " + str(e)
            _error("Fail to Delete Openstack Stack, err=%s"%error_text)
            _except(e)
            
    def _check_stack_deleted(self, stack_id, stack_name = None):
        try:
            stack = self.heat.stacks.get(stack_id=stack_id).to_dict()
            self._inc(2)
            check_count = 0
            while True: 
                if type(stack) is str:
                    _debug("check_stack_deleted() heat stack get result type is not dict: %s" %str(stack))
                    break
                elif ('stack_status' in stack) == False:
                    _debug("check_stack_deleted() heat stack get result does not include stack_status: %s" %str(stack))
                    break
                elif stack['stack_status'] != 'DELETE_IN_PROGRESS':
                    _debug("check_stack_deleted() heat stack_status: %s" %str(stack['stack_status']))
                    break
                
                _debug("check_stack_deleted()  HEAT: Stack Status in Heat= %s" %str(stack['stack_status']))
                sleep(3)
                _debug("check_stack_deleted()  HEAT: check %d th" %check_count)
                if check_count >= 120:
                    _debug("check_stack_deleted  HEAT: stop deleting Heat Stack %d" %check_count)
                    break
                    
                try:
                    stack = self.heat.stacks.get(stack_id=stack_id).to_dict()
                except Exception, e:
                    _warn("Fail to Get Openstack Stack, err=%s"%str(e))
                    _except(e)
                
                check_count += 1
                self._inc(2)
                
            _debug("check_stack_deleted()  HEAT: Stack deleted.")
            return True
        except heatException.NotFound, e:
            error_text=str(type(e))[6:-1] + ": " + (str(e) if len(e.args)==0 else str(e.args[0]))
            _error("Fail to Check Deleted Stack, err=%s"%error_text)
            _except(e)
            return False
        except Exception, e:
            error_text="Unknown Error " + str(e)
            _error("Fail to Check Deleted Stack, err=%s"%error_text)
            _except(e)
            return False
    
    def reset_network(self):
        for _net_name in self.RESET_NET :
            _net_id = self.get_network_id(_net_name)
            if _net_id == None or _net_id == '' :
                _warn("No OpenStack Network ID, name=%s"%str(_net_name))
                continue
            
            if not self.delete_network(_net_id) :
                self._fin_err("Virtual Network Delete Error, name=%s"%str(_net_name))
                return False
        
        self._fin_ok()
        return True
            
    def get_network_id(self, network_name):
        try:
            self._load_connection()
            kwargs={"name": network_name}
            net_result = self.neutron.list_networks(**kwargs)
            self._inc(5)
            
            net_list = net_result['networks']
            for net in net_list:
                net_id = net["id"]
                net_name = net["name"]
                
                _debug("id= %s name= %s" % (net_id, net_name))
                return net_id
            
            _warn("Fail to Get Openstack Network ID, No Network")
            return None
        except Exception, e:
            _error("Fail to Get Openstack Network ID, exc=%s"%str(e))
            _except(e)
            return None
            
    def delete_network(self, net_id):
        try:
            self._load_connection()
            ports = self.neutron.list_ports(network_id=net_id)
            self._inc(5)
            for p in ports['ports']:
                try:
                    port_id = p["id"]
                    _debug("delete port: %s" % port_id)
                    self.neutron.delete_port(port_id)
                except Exception, e:
                    _error("Fail to Delete Network, Error deleting port: %s: %s" %(str(type(e))[6:-1], str(e)))
                    _except(e)
                
                self._inc(2)
            
            _debug("delete network: %s" % net_id)
            self.neutron.delete_network(net_id)
            self._inc(2)
            return True
        except Exception, e:
            _error("Fail to Delete Network, exc=%s"%str(e))
            _except(e)
            return False
    
    def create_neutron_network(self, _name, _physnet, _type, _cidr):
        try:
            network_dict = {'name': _name, 'admin_state_up': True}
            network_dict["provider:physical_network"] = _physnet
            network_dict["provider:network_type"]     = _type
            network_dict["shared"]=True
            
            self._load_connection()
            network = self.neutron.create_network({'network':network_dict})
            
            subnet_dict= { "name": _name + "-subnet",
                    "network_id": network["network"]["id"],
                    "ip_version": 4,
                    "enable_dhcp": False,
                    "cidr": _cidr
                    }
            self.neutron.create_subnet({"subnet": subnet_dict} )
            return True
        except Exception, e:
            _error("Fail to Create OSP-Network, name=%s"%str(_name))
            _except(e)
            return False









