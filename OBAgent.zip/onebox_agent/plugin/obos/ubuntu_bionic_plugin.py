#-*- coding: utf-8 -*-
'''
Created on 2017. 7. 25.

@author: ohhara
'''

import threading, pexpect, os, traceback, sys, tempfile
from time import sleep
from subprocess import Popen, PIPE, CalledProcessError
from debinterface.interfaces import Interfaces
from pyparsing import Suppress, Optional, restOfLine, Combine, Word, nums, oneOf,\
    Regex, alphanums, Dict, ZeroOrMore, Group
import datetime
import time
from ipaddr import IPv4Network




DEF_DNS = "168.126.63.1"
DHCLIENT_CONFIG = "/etc/dhcp/dhclient.conf"
DHCLINET_LEASE = "/var/lib/dhcp/dhclient%s.leases"
T_GAP_DHCLIENT_VALID = 60

INTERFACE_CONF = "/etc/udev/rules.d/70-persistent-net.rules"
DMESG_FILE = "/var/log/dmesg"

INTERFACES_PATH="/etc/network/interfaces"
BACKUP_PATH="/tmp/interfaces"

NIC_MODELS = ["Virtio", "82583V", "I350", "Network Connection", "Intel Corporation"]
NETWORK_BASE_CLASS = "02"

# DPDK_DRVS = ["igb_uio", "vfio-pci", "uio_pci_generic"]
DPDK_DRVS = ["igb_uio", "vfio-pci", "igb_uio"]


def _getLineNo():
    org_f = None
    try:
        raise Exception
    except:
        org_f = sys.exc_info()[2].tb_frame.f_back
    #On some versions of IronPython, currentframe() returns None if
    #IronPython isn't run with -X:Frames.
    if org_f is not None:
        f = org_f.f_back
    else:
        return None
    
    if f == None :
        return None
    
    l_no = f.f_lineno
    return l_no

logger = None
_LOG_T = "[PLG-LX.%-4s]"
def _debug(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.debug(msg)
    else: print msg

def _info(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.info(msg)
    else: print msg

def _warn(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.warning(msg)
    else: print msg

def _error(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.error(msg)
    else: print msg

def _except(exc):
    _SERR = tempfile.TemporaryFile()
    traceback.print_exc(exc, _SERR)
    _SERR.seek(0)
    msg = _SERR.read()
    msg = _LOG_T%str(_getLineNo()) + "\n" + str(msg)
    if logger != None : logger.fatal(msg)
    else: print msg


class Sysfs(object):

    def __init__(self):
        self._path_cls_net = "/sys/class/net"

    def get_nets(self):
        try:
            _nets = []
            dirs = os.listdir(self._path_cls_net)
            for _offset in range(0, len(dirs)):
                if os.path.isdir("%s/%s" % (self._path_cls_net, dirs[_offset])) is False:
                    continue
                if dirs[_offset].startswith("eth") is False:
                    continue
                _nets.append(dirs[_offset])
            _nets.sort()
            return _nets
        except Exception, e:
            _error("Fail to Get Nets, _exc=%s" % str(e))
            return None

    def get_hwaddress(self, _ifname):
        try:
            _hwaddr = None
            if _ifname is None or len(_ifname) <= 0 or _ifname.startswith("eth") is False:
                return None
            if os.path.exists("%s/%s/address" % (self._path_cls_net, _ifname)) is False:
                return None
            f = open("%s/%s/address" % (self._path_cls_net, _ifname), "r")
            if f is not None:
                _hwaddr = str(f.readline()).strip()
                f.close()
            return _hwaddr
        except Exception, e:
            _error("Fail to Get Mac Addr, _ifname=%s, exc=%s" % (str(_ifname), str(e)))
            return None

    def get_device(self, _ifname):
        try:
            _vendor = None
            _device = None
            if _ifname is None or len(_ifname) <= 0 or _ifname.startswith("eth") is False:
                return None
            if os.path.exists("%s/%s/device/device" % (self._path_cls_net, _ifname)) is False:
                return None
            f = open("%s/%s/device/vendor" % (self._path_cls_net, _ifname), "r")
            if f is not None:
                _vendor = str("%02x" % int(f.readline().strip(), 16))
                f.close()
            f = open("%s/%s/device/device" % (self._path_cls_net, _ifname), "r")
            if f is not None:
                _device = str("%02x" % int(f.readline().strip(), 16))
                f.close()
            return _vendor, _device
        except Exception, e:
            _error("Fail to Get Mac Addr, _ifname=%s, exc=%s" % (str(_ifname), str(e)))
            return None


class Vendor:

    def __init__(self, vendor):
        self.ID = vendor.split()[0]
        self.name = vendor.replace("%s " % self.ID, "")
        self.devices = {}

    def add_device(self, device):
        s = device.strip()
        dev_id = s.split()[0]
        if dev_id in self.devices:
            pass
        else:
            self.devices[dev_id] = Device(device)


class Device:

    def __init__(self, device):
        s = device.strip()
        self.ID = s.split()[0]
        self.name = s.replace("%s  " % self.ID, "")


class PCIIds:

    def __init__(self):
        self._path_pci_ids = "/usr/share/misc/pci.ids"
        self.vendors = {}
        self.contents = None
        self.read_local()

    def parse(self):
        if len(self.contents) < 1:
            _error("%s not found" % self._path_pci_ids)
            return False
        else:
            vendor_id = str()
            for l in self.contents:
                if l[0] == "#":
                    continue
                elif len(l.strip()) == 0:
                    continue
                else:
                    if l.find("\t") == 0:
                        self.vendors[vendor_id].add_device(l.strip())
                    else:
                        vendor_id = l.split()[0]
                        self.vendors[vendor_id] = Vendor(l.strip())
            return True

    def get_name(self, vendor_id, device_id):
        try:
            return self.vendors[vendor_id].devices[device_id].name.lstrip().rstrip()
        except KeyError, e1:
            return self.vendors[vendor_id].name.lstrip().rstrip()
        except Exception, e2:
            _error("Fail to Get net model, %s" % str(e2))
            return None

    def read_local(self):
        self.contents = open(self._path_pci_ids).readlines()


def get_cpu_model():
    try:
        _cmd = "cat /proc/cpuinfo | grep 'model name' | head -n 1 | awk -F ':' '{print $2}'"
        status, output, err = Command().execute_command(_cmd)
        if status == 0 and str(output).strip() != "" :
            _md = str(output).strip()
            _cmd = "cat /proc/cpuinfo | grep 'cache size' | head -n 1 | awk -F ':' '{print $2}'"
            status, output, err = Command().execute_command(_cmd)
            if status == 0 and str(output).strip() != "" :
                _md += ( " with " + str(output).strip() + " cache")
            else:
                _warn("Fail to Get CPU Cache, out=%s, err=%s"%( str(output), str(err) ))
            return _md
        else:
            _error("Fail to Get CPU Model, out=%s, err=%s"%( str(output), str(err) ))
            return "Unknown CPU Model"
    except Exception, e:
        _error("Fail to Get CPU Model, exc=%s"%str(e))
        _except(e)
        return "Unknown CPU Model"

def get_cpu_core():
    '''
    return : _cpu_sock, _cpu_core_per_sock, _cpu_logical_core(total)
    '''
    _total = -1
    _sock = -1
    _core = -1
    try:
        
        _cmd = "lscpu | grep '^CPU(s)' | awk -F ':' '{print $2}'"
        _ret = Command().execute_command(_cmd)
        try:
            _total = int(str(_ret[1]).strip())
        except Exception, e:
            _error("Fail to Get CPU Total Core, out=%s, err=%s, exc=%s"%( str(_ret[1]), str(_ret[2]), str(e) ))
            return _sock, _core, _total
        
        _cmd = "lscpu | grep '^Core(s) per socket' | awk -F ':' '{print $2}'"
        _ret = Command().execute_command(_cmd)
        try:
            _core = int(str(_ret[1]).strip())
        except Exception, e:
            _error("Fail to Get CPU Core Per Socket, out=%s, err=%s, exc=%s"%( str(_ret[1]), str(_ret[2]), str(e) ))
            return _sock, _core, _total
        
        _cmd = "lscpu | grep '^Socket(s)' | awk -F ':' '{print $2}'"
        _ret = Command().execute_command(_cmd)
        try:
            _sock = int(str(_ret[1]).strip())
        except Exception, e:
            _error("Fail to Get CPU Socket, out=%s, err=%s, exc=%s"%( str(_ret[1]), str(_ret[2]), str(e) ))
            return _sock, _core, _total
        
        return _sock, _core, _total
    except Exception, e:
        _error("Fail to Get CPU Core, exc=%s"%str(e))
        _except(e)
        return _sock, _core, _total

def get_mem_size():
    _mem = -1
    try:
        _cmd = "cat /proc/meminfo | grep '^MemTotal' | awk -F ':' '{print $2}' | awk '{print $1}'"
        _ret = Command().execute_command(_cmd)
        try:
            _mem = int(str(_ret[1]).strip()) / (1000)
        except Exception, e:
            _error("Fail to Get Memory Info, out=%s, err=%s, exc=%s"%( str(_ret[1]), str(_ret[2]), str(e) ))
    except Exception, e:
        _error("Fail to Get Memory Info, exc=%s"%str(e))
        _except(e)
    return _mem

def get_os_name():
    try:
        _cmd = """cat /etc/os-release | grep '^PRETTY_NAME' | awk -F '=' '{print $2}' | tr '"' ' '"""
        status, output, err = Command().execute_command(_cmd)
        if status == 0 and str(output).strip() != "" :
            return str(output).strip()
        else:
            _error("Fail to Get OS Info, out=%s, err=%s"%( str(output), str(err) ))
            return "Unknown OS Info"
    except Exception, e:
        _error("Fail to Get OS Info, exc=%s"%str(e))
        _except(e)
        return "Unknown OS Info"

def update_dhclient_config(dFile=None):
    dhc_cfg_txt = """option rfc3442-classless-static-routes code 121 = array of unsigned integer 8;

timeout 30;
send host-name = gethostname();
send dhcp-client-identifier = hardware;
send dhcp-lease-time 3600;
request subnet-mask, broadcast-address, time-offset, routers,
    domain-name, domain-name-servers, domain-search, host-name,
    dhcp6.name-servers, dhcp6.domain-search,
    netbios-name-servers, netbios-scope, interface-mtu,
    rfc3442-classless-static-routes, ntp-servers,
    dhcp6.fqdn, dhcp6.sntp-servers;
"""
    try:
        if dFile == None : dFile = DHCLIENT_CONFIG
        with open(dFile, "w") as f:
            f.write(dhc_cfg_txt)
        
        return True
    except Exception, e:
        _error("Fail to Update DHCPClient Config, Occur Error, exc=%s"%str(e))
        _except(e)
        return False

def delete_dhclient_config(dFile=None):
    if dFile == None : dFile = DHCLIENT_CONFIG
    delFile(dFile)

def dhclient_down():
    try:
        _cmd = """ killall dhclient | wc -l """
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 :
            _warn("Fail to Kill Dhclients, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_ret), str(_out), str(_e) ))
        return True
    except Exception, e:
        _warn("Fail to Kill Dhclients, Occure Error, exc=%s"%str(e))
        _except(e)
        return True

def runDHClient(_nic, _wait=10):
    try:
        if _nic == None or type(_nic) != str or str(_nic).strip() == '' :
            _error("Fail to Run DHClient, Invalid Nic=%s"%str(_nic))
            return False
        
        _cmd = """ timeout -s 9 %s dhclient %s """% ( str(_wait), str(_nic) )
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 :
            _error("Fail to Run DHClient, cmd=%s, status=%s, out=%s, err=%s"%( _cmd, str(_ret), str(_out), str(_e) ))
            return False
        
        _info("SUCC: Run DHClient, nic=%s"%str(_nic))
        return True
    except Exception, e:
        _error("Fail to Run DHClient, nic=%s, exc=%s"%( str(_nic), str(e) ))
        _except(e)
        return False

def stopDHClient(_nic):
    try:
        if _nic == None or type(_nic) != str or str(_nic).strip() == '' :
            _error("Fail to Stop DHClient, Invalid Nic=%s"%str(_nic))
            return False
        
        _cmd = """ dhclient -r %s """%str(_nic)
        _ret, _out, _e = Command().execute_command(_cmd)
        
        _ps_cmd = """ kill -9 $(ps -ef | grep -v grep | grep dhclient | grep "%s$" | awk '{print $2}') """%str(_nic)
        Command().execute_command(_ps_cmd)
        
        if _ret != 0 :
            _error("Fail to Stop DHClient, cmd=%s, status=%s, out=%s, err=%s"%( _cmd, str(_ret), str(_out), str(_e) ))
            return False
        
        _info("SUCC: Stop DHClient, nic=%s"%str(_nic))
        return True
    except Exception, e:
        _error("Fail to Stop DHClient, nic=%s, exc=%s"%( str(_nic), str(e) ))
        _except(e)
        return False

def parseDhclientLease(isDefaultLeaseFile, _nic, forced=True):
    '''
    return (ip, mask, gw) or (None, None, None) 
    '''
    _file = None
    try:
        if isDefaultLeaseFile :
            _file = DHCLINET_LEASE%str("")
        else:
            _file = DHCLINET_LEASE%("."+str(_nic))
        if not os.path.isfile(_file) :
            _error("Fail to Parse DHClient-Info, No DHClient Lease File, file=%s"%str(_file))
            return None, None, None
        
        leaseList = None
        with open(_file, "r") as f:
            leaseList = f.read()
        
        LBRACE,RBRACE,SEMI = map(Suppress, '{};')
        
        comment = '#' + Optional(restOfLine)
        yyyymmdd = Combine((Word(nums,exact=4)|Word(nums,exact=2))+('/'+Word(nums,exact=2))*2)
        hhmmss = Combine(Word(nums,exact=2)+(':'+Word(nums,exact=2))*2)
        dateRef = oneOf(list("0123456"))("weekday") + yyyymmdd("date") + hhmmss("time")
        def utcToLocalTime(tokens):
            utctime = datetime.datetime.strptime("%(date)s %(time)s" % tokens,
                                                            "%Y/%m/%d %H:%M:%S")
            localtime = utctime-datetime.timedelta(0,time.timezone,0)
            tokens["utcdate"],tokens["utctime"] = tokens["date"],tokens["time"]
            tokens["localdate"],tokens["localtime"] = str(localtime).split()
            del tokens["date"]
            del tokens["time"]
        dateRef.setParseAction(utcToLocalTime)
        
        ETC = Regex(".*;")
        NIC = "interface" + Regex("\".*\"") + SEMI
        MSK = "option subnet-mask" + Combine(Word(nums) + ('.' + Word(nums))*3 ) + SEMI
        IPA = "fixed-address" + Combine(Word(nums) + ('.' + Word(nums))*3 ) + SEMI
        GWA = "option routers" + Combine(Word(nums) + ('.' + Word(nums))*3 ) + SEMI
        NEW = "renew" + dateRef + SEMI
        EXP = "expire" + dateRef + SEMI
        
        MLINE = NIC | MSK | IPA | GWA | NEW | EXP | ETC
        OBJ = Word(alphanums) + LBRACE + Dict(ZeroOrMore(Group(MLINE)))  + RBRACE
        TOT = ZeroOrMore(Group(OBJ))
        TOT.ignore(comment)
        _parseData = TOT.parseString(leaseList)
        lastLease = None
        for lastLease in _parseData :
            if isDefaultLeaseFile :
                if lastLease == None or not 'interface' in lastLease or str(lastLease['interface']).strip().replace('"', "") != _nic :
                    continue
            
            if lastLease != None and "fixed-address" in lastLease and "option routers" in lastLease and 'option subnet-mask' in lastLease:
                _ip = lastLease['fixed-address']
                _router = lastLease['option routers']
                _mask = lastLease['option subnet-mask']
                try:
                    IPv4Network("%s/%s"%(str(_ip), str(_mask)))
                    IPv4Network("%s/0"%(str(_router)))
                except Exception, e:
                    _error("Fail to Parse DHClient-Info, Invalid DHCP Address, IF=%s, ip=%s, mask=%s, router=%s"%(str(_nic), str(_ip), str(_mask), str(_router)))
                    _except(e)
                    return None, None, None
                
                _debug(" - DHCP Address: IF=%s, ip=%s, mask=%s, router=%s"%( str(_nic), str(_ip), str(_mask), str(_router) ))
                if "expire" in lastLease and "localdate" in lastLease["expire"] and "localtime" in lastLease["expire"] :
                    _exp = datetime.datetime.strptime(str(lastLease["expire"]["localdate"])+" "+str(lastLease["expire"]["localtime"]), "%Y-%m-%d %H:%M:%S")
                    _max = _exp + datetime.timedelta(minutes=T_GAP_DHCLIENT_VALID)
                    _now = datetime.datetime.now()
                    if _max > _now :
                        _info("SUCC: Parse DHClient-Info")
                        return _ip, _mask, _router
                    else:
                        _warn(" - Fail to Parse DHClient-Info, Expired DHCP Address: IF=%s, dhcp_expr=%s, max=%s, now=%s"%(str(_nic), str(_exp), str(_max), str(_now)))
                        if forced :
                            return _ip, _mask, _router
                        else:
                            return None, None, None
        
        _warn("Fail to Parse DHClient-Info, No Invalid DHClient Data, IF=%s, file=%s, data=%s"%(str(_nic), str(_file), str(lastLease)))
        return None, None, None
    except Exception, e:
        _error("Fail to Parse DHClient-Info, IF=%s, file=%s, exc=%s"%(str(_nic), str(_file), str(e)))
        _except(e)
        return None, None, None

def get_mac_address(nic):
    try:
        ## ifconfig 
        # cmd = "ifconfig %s | grep HWaddr" % str(nic)
        cmd = "ifconfig %s | grep ether" % str(nic)
        _s, _o, _e = Command().execute_command(cmd)
        if _s == 0:
            ifcfg = _o.split()
            # return ifcfg[4]
            return ifcfg[1]
        else:
            _warn(" - Fail to Get Mac, cmd=%s, out=%s, err=%s"%( cmd, str(_o), str(_e) ))
        
        ## init file
        _cmd = """ cat %s | grep %s """%( INTERFACE_CONF, str(nic) )
        _s, _o, _e = Command().execute_command(_cmd)
        if str(_o).find("address") > -1 :
            for _dev_comp in str(_o).strip().split(",") :
                if str(_dev_comp).find("==") > -1 :
                    _name, _val = str(_dev_comp).replace('"', "").strip().split('==')
                    if _name == "ATTR{address}" and str(_val).strip() != "" :
                        return str(_val).strip()
        else:
            _warn(" - Fail to Get Mac By Init-File, cmd=%s, ret=%s, err=%s"%(
                                            _cmd, str(_o), str(_e) ))
        
        ## dmesg
        _cmd = """ _tmp=$(cat %s | grep ".*....:..:..\..: .* device on" | grep %s);"""%( DMESG_FILE, str(nic) )
        _cmd += """ _tmp=${_tmp%:*}; echo ${_tmp##*]} | awk '{print $2}' """
        _s, _o, _e = Command().execute_command(_cmd)
        if str(_o).strip() != "" :
            return str(_o).strip()
        else:
            _warn(" - Fail to Get Mac By dmesg-file, cmd=%s, ret=%s, err=%s"%(
                                            _cmd, str(_o), str(_e) ))
        
        ## oba
        oba_file = "/etc/onebox/onebox-agent.conf"
        import ruamel.yaml
        try:
            with open(oba_file, "r") as f:
                _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
            if _oba_cfg.has_key("svc_nic") and str(_oba_cfg['svc_nic']) == str(nic) \
                and _oba_cfg.has_key("svc_nic_mac") and str(_oba_cfg['svc_nic_mac']).strip() != "" :
                return str(_oba_cfg['svc_nic_mac']).strip()
            
            if _oba_cfg.has_key("extra_mgmt") and type(_oba_cfg['extra_mgmt']) == list \
                and len(_oba_cfg['extra_mgmt']) > 0 :
                for _mgmt in _oba_cfg['extra_mgmt'] :
                    if str(_mgmt['mgmt_nic']).strip() == str(nic) :
                        return str(_mgmt['mgmt_mac']).strip()
            
            if _oba_cfg.has_key("extra_wan") and type(_oba_cfg['extra_wan']) == list \
                and len(_oba_cfg['extra_wan']) > 0 :
                for _wan in _oba_cfg['extra_wan'] :
                    if str(_wan['wan_nic']).strip() == str(nic) :
                        return str(_wan['wan_mac']).strip()
        except Exception, e:
            _warn(" - Fail to Get Mac By oba-cfg, nic=%s, exc=%s"%( oba_file, str(nic), str(e) ))
        
        return None
    except Exception, e:
        _error("Fail to Get Mac, Occur Error, exc=%s"%str(e))
        _except(e)
        return None

def get_main_ip():
    '''
    return : (DEV, IP, MASK, GW) or (None, None, None, None)
    '''
    try:
        _CMD = """ ip r | grep default | awk '{print $3","$5}' | head -n 1 """
        _status, _ret, _e = Command().execute_command(_CMD)
        if _status != 0 or str(_ret).strip() == "" :
            _error("Fail to Get Main IP, cmd=%s, status=%s, ret=%s"%(_CMD, str(_status), str(_e)))
            return None, None, None, None
        _gw, _dev = str(_ret).strip().split(',')
        _gw = str(_gw).strip()
        _dev = str(_dev).strip()
        
        # _CMD = """ ifconfig %s | grep 'inet addr' | awk '{print $2":"$4}' | awk -F ":" '{print $2","$4}' """%_dev
        _CMD = """ ifconfig %s | grep 'inet ' | awk '{print $2","$4}' """ % _dev
        _status, _ret, _e = Command().execute_command(_CMD)
        if _status != 0 or str(_ret).strip() == "" :
            _error("Fail to Get Main IP, cmd=%s, status=%s, ret=%s"%(_CMD, str(_status), str(_e)))
            return None, None, None, None
        _ip, _mask = str(_ret).strip().split(',')
        _ip = str(_ip).strip()
        _mask = str(_mask).strip()
        
        return _dev, _ip, _mask, _gw
    except Exception, e:
        _error("Fail to Get Main IP, Occur Error, exc=%s"%str(e))
        _except(e)
        return None, None, None, None

def get_ip(_dev):
    '''
    return : None, None or (ip, mask)
    '''
    if str(_dev).strip() == "" :
        _error("Fail to Get IP, No Device")
        return None, None
    
    # _CMD = """ ifconfig %s | grep 'inet addr' | awk '{print $2":"$4}' | awk -F ":" '{print $2","$4}' """%str(_dev)
    _CMD = """ ifconfig %s | grep 'inet ' | awk '{print $2","$4}' """ % str(_dev)
    try:
        _status, _ret, _e = Command().execute_command(_CMD)
        if _status != 0 :
            _error("Fail to Get IP, cmd=%s, status=%s, ret=%s"%(_CMD, str(_status), str(_e)))
            return None, None
        
        if str(_ret).strip() == "" :
            _warn("Fail to Get IP, cmd=%s, status=%s, ret=%s"%(_CMD, str(_status), str(_e)))
            return None, None
        
        _ip, _mask = str(_ret).strip().split(',')
        _ip = str(_ip).strip()
        _mask = str(_mask).strip()
        
        return _ip, _mask
    except Exception, e:
        _error("Fail to Get IP, Occur Error, dev=%s, exc=%s"%(_dev, str(e)))
        _except(e)
        return None, None

def get_phy_if_list(_search_models=None):
    try:
        nic_list = []
        __search_models = NIC_MODELS
        if type(_search_models) == list :
            __search_models += _search_models
        _searchTxt = '\|'.join(__search_models)
        _ret = Command().execute_command("lshw -c network -short | grep '%s'"%_searchTxt)
        
        for line in _ret[1].splitlines():
            elems = line.split()
            nic = elems[1].strip()
            if nic == "" or nic.find("network") > -1 :
                continue
            nic_list.append(nic)
        
        nic_list.sort()
        return nic_list
    except Exception, e:
        _error("Fail to ifdown, Occur Error, exc=%s"%str(e))
        _except(e)
        return None

def get_ethernets(_search_models=None):
    try:
        nic_list = []
        __search_models = NIC_MODELS
        if type(_search_models) == list :
            __search_models += _search_models

        sys_fs = Sysfs()
        pci_ids = PCIIds()

        if pci_ids.parse() is not True:
            return get_phy_if_list(_search_models=_search_models)

        _nics = sys_fs.get_nets()
        for offset in range(0, len(_nics)):
            __ifname = _nics[offset]
            __vendor, __device = sys_fs.get_device(__ifname)
            __model = pci_ids.get_name(__vendor, __device)

            __match = False
            for offset2 in range(0, len(__search_models)):
                if str(__model).find(__search_models[offset2]) > -1:
                    __match = True
                    break

            if __match is True:
                nic_list.append(_nics[offset])

        nic_list.sort()

        return nic_list
    except Exception, e:
        _error("Fail to ifdown, Occur Error, exc=%s"%str(e))
        _except(e)
        return None

def get_dmidecode_keyword(_keyword=None):
    try:
        _cmd = "dmidecode -s '%s' | grep -v '#'" % _keyword
        _ret = Command().execute_command(_cmd)
        if len(_ret[1].strip().splitlines()) == 1:
            return str(_ret[1]).strip()
        else:
            return None
    except Exception, e:
        _error("Fail to %s, exc=%s" % (_cmd, str(e)))
        _except(e)
        return None

def chk_link_conn(_nic):
    _cmd = """ ethtool %s | grep 'Link detected' | grep -i 'yes' """%str(_nic)
    try:
        _status, _out, _err = Command().execute_command(_cmd)
        if _status != 0 and _status != 1 :
            _error("Host Nic check Error, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_status), str(_out), str(_err) ))
            return False
        
        if _out == None :
            _error("Host Nic Chk return is invalid, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_status), str(_out), str(_err) ))
            return False
        
        if str(_out).strip() == "" :
            _info("Host Nic %s is down, ret=%s"%( _nic, str(_out).strip() ))
            return False
        else:
            _info("Host Nic %s is alive, ret=%s"%( _nic, str(_out).strip() ))
            return True
    except Exception, e:
        _error("Fail to Chk Nic Connection, exc=%s"%str(e))
        _except(e)
        return False

def ping(_ip, _try=1, _wait=1, _dev=None):
    _cmd = """ ping """
    if _dev != None :
        _cmd = """ ping -I %s """%str(_dev)
    _cmd = _cmd + """-c %d -w %d %s | grep 'received' | awk '{print $4}' """%( _try, _wait, str(_ip) )
    try:
        _status, _out, _err = Command().execute_command(_cmd)
        try:
            _ret = int(_out)
            if _ret > 0 :
                return True
            else:
                return False
        except (ValueError, TypeError) as e:
            _error("Fail to Ping, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, _status, _out, _err ))
            return False
    except Exception, e:
        _error("Fail to Run Ping-CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return False

def arping(_ip, _dev, _try=1, _wait=3):
    _cmd = """ arping -c %d -w %d -I %s %s | grep 'Received' | awk '{print $2}' """%( _try, _wait, str(_dev), str(_ip) )
    try:
        _status, _out, _err = Command().execute_command(_cmd)
        try:
            _ret = int(_out)
            if _ret > 0 :
                return True
            else:
                return False
        except (ValueError, TypeError) as e:
            _error("Fail to Ping, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, _status, _out, _err ))
            return False
    except Exception, e:
        _error("Fail to Run Ping-CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return False

def chk_conn_nc(_url, _port, _wait=3):
    _cmd = """ nc -w %d -v -z %s %d > /dev/null 2> /dev/null;echo $? """%( _wait, str(_url), _port )
    try:
        _status, _out, _err = Command().execute_command(_cmd)
        try:
            _ret = int(_out)
            if _ret == 0 :
                return True
            else:
                return False
        except (ValueError, TypeError) as e:
            _error("Fail to Check NC-Conn, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, _status, _out, _err ))
            return False
    except Exception, e:
        _error("Fail to Run NC-Conn-CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return False

def chk_conn_curl(_url, _wait=3):
    _cmd = """ curl -k --connect-timeout %d %s > /dev/null 2>/dev/null; echo $? """%( _wait, str(_url) )
    try:
        _status, _out, _err = Command().execute_command(_cmd)
        try:
            _ret = int(_out)
            if _ret == 0 :
                return True
            else:
                return False
        except (ValueError, TypeError) as e:
            _error("Fail to Check Curl-Conn, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, _status, _out, _err ))
            return False
    except Exception, e:
        _error("Fail to Run Curl-Conn-CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return False

def chk_conn_nslookup(_url, _wait=3):
    _cmd = """ timeout -s 9 %d nslookup %s | grep -c "%s" """%( _wait, str(_url), str(_url) )
    try:
        _status, _out, _err = Command().execute_command(_cmd)
        try:
            _ret = int(_out)
            if _ret > 0 :
                return True
            else:
                return False
        except (ValueError, TypeError) as e:
            _error("Fail to Check NsLookUp-Conn, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, _status, _out, _err ))
            return False
    except Exception, e:
        _error("Fail to Run NsLookUp-Conn-CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return False

def is_master(_br, _nics):
    _cmd = """ ip link show %s | grep -c "%s " """%( "%s", str(_br) )
    try:
        _res = False
        for _nic in _nics :
            if _nic == None or str(_nic).strip() == "" :
                continue
            
            _nic = str(_nic)
            __cmd = _cmd%_nic
            _status, _out, _err = Command().execute_command(__cmd)
            try:
                _ret = int(_out)
                if _ret > 0 :
                    _res = True
                else:
                    return False
            except (ValueError, TypeError) as e:
                _error("Fail to Check Nic's Owner, cmd=%s, ret=%s, out=%s, err=%s"%( __cmd, str(_status), str(_out), str(_err) ))
                return False
        if not _res :
            _error("Fail to Check Nic's Owner, No Nic")
        return _res
    except Exception, e:
        _error("Fail to Check Nic's Owner, cmd=%s, nics=%s, exc=%s"%( _cmd, str(_nics), str(e) ))
        _except(e)
        return False

def is_nic_alive(nic, doIfUp=False):
    ## Host Interface check: ethtool
    try:
        if doIfUp :
            _cmd = """ ifconfig %s up """%str(nic)
            try:
                _status, _out, _err = Command().execute_command(_cmd)
                if _status != 0 :
                    _warn(" - Fail to Check Nic Status, Ifconfig up Error, cmd=%s, status=%s, out=%s, err=%s"%( _cmd, str(_status), str(_out), str(_err) ))
            except Exception, e:
                _warn(" - Fail to Check Nic Status, cmd=%s, excp=%s"%( _cmd, str(e) ))
        else:
            _cmd = """ ifconfig %s | grep -c "UP" """%str(nic)
            try:
                _status, _out, _err = Command().execute_command(_cmd)
                _ret = int(_out)
                if _ret < 1 :
                    _warn(" - Fail to Check Nic Status, NIC Down --> UP, nic=%s"%( str(nic) ))
                    _cmd_up = """ ifconfig %s up """%str(nic)
                    _status_up, _out_up, _err_up = Command().execute_command(_cmd_up)
                    if _status_up != 0 :
                        _warn(" - Fail to Check Nic Status, NIC UP Error, cmd=%s, status=%s, out=%s, err=%s"%( _cmd_up, str(_status_up), str(_out_up), str(_err_up) ))
            except (ValueError, TypeError) as e:
                _warn(" - Fail to Check Nic Status, NIC UP-Info Get Error, cmd=%s, status=%s, out=%s, err=%s"%( _cmd_up, str(_status_up), str(_out_up), str(_err_up) ))
            except Exception, e:
                _warn(" - Fail to Check Nic Status, cmd=%s, excp=%s"%( _cmd, str(e) ))
        
        _cmd = """ ethtool %s | grep 'Link detected' """%str(nic)
        _status, _out, _err = Command().execute_command(_cmd)
        if _status != 0 :
            _error("Fail to Check Nic Status, Host Nic check Error, cmd=%s, status=%s, out=%s, err=%s"%(_cmd, str(_status), str(_out), str(_err)))
            return False
        
        if str(_out).upper().find("YES") < 0 :
            return False
        
        return True
    except Exception, e:
        _error("Fail to Check Nic Status, exc=%s"%str(e))
        _except(e)
        return False

def is_if_up(_ifname, _fail_return=False):
    _cmd = """ifconfig %s | grep -c "UP" """%str(_ifname)
    try:
        _status, _output, _e = Command().execute_command(_cmd)
        try:
            if int(_output) > 0 :
                return True
            else:
                return False
        except Exception, e:
            _error("Fail to Get IFCONFIG Status, cmd=%s, ret=%s, out=%s, err=%s, exc=%s"%( _cmd, str(_status), str(_output), str(_e), str(e) ))
            return _fail_return
    except Exception, e:
        _error("Fail to Get IFCONFIG Status, Occur Error, exc=%s"%str(e))
        _except(e)
        return _fail_return


def down_and_up_interface(nic, _forced=None, _metric=None):
    try:
        cmd = Command()
        
        interface_lock = "/run/network/ifstate.%s" % nic
        if os.path.exists(interface_lock):
            os.remove(interface_lock)
        
        cmd_down = "ifdown %s" % nic
        if _forced != None :
            cmd_down = "timeout -s 9 %s "%str(_forced) + cmd_down
            
        (result, output, err) = cmd.execute_command(cmd_down)
        if result and str(err).find("not configured") < 0 :
            if _forced == None :
                _error("Fail to ifdown, cmd=%s, out=%s, err=%s"%( cmd_down, str(output), str(err) ))
                return False
            else:
                _warn("Fail to ifdown, cmd=%s, out=%s, err=%s"%( cmd_down, str(output), str(err) ))
        
        sleep(1)
        if _metric == None :
            cmd_up = "ifup %s" % nic
        else:
            cmd_up = "ifup -o metric=%s %s"%( str(_metric), nic )
        
        if _forced != None :
            cmd_up = "timeout -s 9 %s "%str(_forced) + cmd_up
        
        (result, output, err) = cmd.execute_command(cmd_up)
        if result and str(err).find("already configured") < 0 :
            if _forced == None :
                _error("Fail to ifup, cmd=%s, out=%s, err=%s"%( cmd_up, str(output), str(err) ))
                return False
            else:
                _warn("Fail to ifup, cmd=%s, out=%s, err=%s"%( cmd_up, str(output), str(err) ))
        
        _info("SUCC: Refresh Interface, if=%s"%str(nic))
        return True
    except Exception, e:
        _error("Fail to Refresh Interface, Occur Error, exc=%s"%str(e))
        _except(e)
        return False

def if_down(_ifName, _forced=None):
    try:
        if _forced != None :
            _cmd = """ timeout -s 9 %s ifdown %s """%( str(_forced), str(_ifName) )
        else:
            _cmd = """ifdown %s """%str(_ifName)
        
        _status, _output, _e = Command().execute_command(_cmd)
        if _status != 0 and str(_e).find("not configured") < 0  :
            _error("Fail to ifdown, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_status), str(_output), str(_e) ))
            return False
        else:
            return True
    except Exception, e:
        _error("Fail to ifdown, Occur Error, exc=%s"%str(e))
        _except(e)
        return False

def ifconfig_down(_ifName, _waitForUp=False):
    try:
        if not is_if_up(_ifName, True) :
            return
        
        _max = 300
        _wait = 0
        while _waitForUp :
            sleep(1)
            
            _cmd = """ ps -ef | grep -v 'grep' | grep 'ifup' | grep '%s' """%str(_ifName)
            _status, _output, _e = Command().execute_command(_cmd)
            if _output == None or str(_output).strip() == "" :
                break
            
            if _wait > _max :
                break
            
            _wait += 1
        
        _cmd = """ ifconfig %s down """%str(_ifName)
        _status, _output, _e = Command().execute_command(_cmd)
        if _status != 0 :
            _warn("Fail to ifconfig down, nic=%s, status=%s, out=%s, err=%s"%( _ifName, str(_status), str(_output), str(_e) ))
    except Exception, e:
        _warn("Fail to ifconfig down, Occur Error, exc=%s"%str(e))
        _except(e)

def ifconfig_up(_ifName):
    try:
        _cmd = """ ifconfig %s up """%str(_ifName)
        _status, _output, _e = Command().execute_command(_cmd)
        _info("SUCC: ifconfig up, %s"%str(_ifName))
    except Exception, e:
        _warn("Fail to ifconfig up, Occur Error, exc=%s"%str(e))
        _except(e)

def set_ip_address(nic, ip_addr=None, netmask="0"):
    try:
        if ip_addr == None:
            _cmd = "ifconfig %s 0" % (nic)
        else:
            _cmd = "ifconfig %s %s netmask %s" % (nic, ip_addr, netmask)
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 :
            _error("Fail to Set IP Address, cmd=%s, out=%s, err=%s"%( _cmd, str(_out), str(_e) ))
            return False
        return True
    except Exception, e:
        _error("Fail to Set IP Address, nic=%s, ip=%s, mask=%s, exc=%s"%( str(nic), str(ip_addr), str(netmask), str(e) ))
        _except(e)
        return False
        

def add_def_route(_ip):
    try:
        _cmd = """ ip route add default via %s """ % _ip
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 and str(_e).find("File exists") < 0  :
            _warn("Fail to Add def-route, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_ret), str(_out), str(_e) ))
            return False
        else:
            return True
    except Exception, e:
        _error("Fail to Add def-route, Occur Error, exc=%s"%str(e))
        _except(e)
        return False

def del_def_route():
    try:
        _cmd = """ ip route del default """
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 and str(_e).find("No such process") < 0  :
            _warn("Fail to Remove def-route, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_ret), str(_out), str(_e) ))
            return False
        else:
            return True
    except Exception, e:
        _error("Fail to Remove def-route, Occur Error, exc=%s"%str(e))
        _except(e)
        return False

def delete_route(_nic, _ip):
    try:
        _cmd = """ ip route list | grep -v "%s" | grep "%s" """%( str(_ip), str(_nic) )
        _ret, _out, _e = Command().execute_command(_cmd)
        if _e != None and str(_e).strip() != "" : 
            _error("Fail to Delete Route, cmd=%s, out=%s, err=%s"%( _cmd, str(_out), str(_e) ))
            return False
        
        gwList = str(_out).split("\n")
        for gwInfo in gwList :
            cmd = """ ip route del %s """%str(gwInfo)
            _ret, _out, _e = Command().execute_command(_cmd)
            if _ret != 0 :
                _warn("Fail to Delete Local Gateway, cmd=%s, out=%s, _err=%s"%(cmd, str(_out), str(_e)))
        
        return True
    except Exception, e:
        _error("Fail to Delete Route, nic=%s, ip=%s, exc=%s"%( str(_nic), str(_ip), str(e) ))
        _except(e)
    
    return False

def refresh_route(_name):
    try:
        _cmd = """ ifconfig %s down """%str(_name)
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 and _ret != 256 : 
            _error("Fail to Set Local Gateway, cmd=%s, out=%s, err=%s"%(_cmd, str(_out), str(_e)))
            return False
        
        _cmd = """ ifconfig %s up """%str(_name)
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 and _ret != 256 : 
            _error("Fail to Set Local Gateway, cmd=%s, out=%s, err=%s"%(_cmd, str(_out), str(_e)))
            return False
        
        _cmd = """ ifup %s """%str(_name)
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 and _ret != 256 : 
            _error("Fail to Set Local Gateway, cmd=%s, out=%s, err=%s"%(_cmd, str(_out), str(_e)))
            return False
        
        return True
    except Exception, e:
        _error("Fail to Set Local Gateway, name=%s, exc=%s"%( str(_name), str(e) ))
        _except(e)
    
    return False

def get_route_list():
    '''
    return : [Dev Name] or None
    '''
    try:
        _cmd = """ ip route list | grep -v "^default" | awk '{print $3}' """
        
        _status, _output, _e = Command().execute_command(_cmd)
        if _status != 0 or str(_e).strip() != "" :
            _error("Fail to Get Route List, ret=%s, output=%s, err=%s"%( str(_status), str(_output), str(_e) ))
            return None
        
        _r_list = []
        for _r_dev in str(_output).split() :
            if _r_dev != None and str(_r_dev).strip() != "" :
                _r_list.append(str(_r_dev).strip())
        
        return _r_list
    except Exception, e:
        _error("Fail to Get Route List, Occur Error, exc=%s"%str(e))
        _except(e)
        return None

def get_gw_info(_tname="main", _dev=None):
    '''
    return : [(Dev Name, IP, metric)] or None
    '''
    try:
        if _dev == None :
            _cmd = """ ip route list table "%s" | grep "^default" | awk '{print $3","$5","$7}' """%str(_tname)
        else:
            _cmd = """ ip route list table "%s" | grep "^default" | grep "%s" | awk '{print $3","$5","$7}' """%(str(_tname), str(_dev))
        
        _status, _output, _e = Command().execute_command(_cmd)
        if _status != 0 or str(_e).strip() != "" :
            _error("Fail to Get GW Info, ret=%s, output=%s, err=%s"%( str(_status), str(_output), str(_e) ))
            return None
        
        _gw_list = []
        for _gwinfo in str(_output).split() :
            _ret = _gwinfo.split(",")
            _dev = _ret[1]
            _ip = _ret[0]
            _metric = 0
            if len(_ret) > 2 and str(_ret[2]).strip() != "" :
                _metric = int(str(_ret[2]).strip())
            _gw_list.append(( str(_dev).strip(), str(_ip).strip(), _metric ))
        
        return _gw_list
    except Exception, e:
        _error("Fail to Get GW Info, Occur Error, exc=%s"%str(e))
        _except(e)
        return None

def get_def_gw_info():
    '''
    return : (Dev Name, IP, metric) or None, None, None
    '''
    _gw_list = get_gw_info()
    if _gw_list == None or len(_gw_list) < 1 :
        _error("Fail to Get Def-GW Info, No Gateway Info, info=%s"%str(_gw_list))
        return None, None, None
    
    return _gw_list[0]

def get_br():
    try:
        _cmd = """ brctl show | grep br-internet | awk '{print $1}' """
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret == 0 :
            return list(set(str(_out).split()))
        else:
            _error("Fail to Get Bridge, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_ret), str(_out), str(_e) ))
            return None
    except Exception, e:
        _error("Fail to Get Bridge, Occur Error, exc=%s"%str(e))
        _except(e)
        return None

def get_br_ifs(_brName):
    '''
    return : br's interface list, or None
    '''
    try:
#         _cmd = """ cat /sys/class/net/%s/lower_*/uevent | grep "INTERFACE" | awk -F "=" '{print $2}' """%str(_brName)
        _cmd = """ brctl show %s | grep -v "bridge name" | awk '{print $1","$4}' """%str(_brName)
        _status, _output, _e = Command().execute_command(_cmd)
        if str(_e).find("No such device") > -1 :
            _warn("Skip to Check LX-BR-IF, No Bridge, err=%s"%str(_e))
            return []
        if _status != 0 or str(_e).strip() != "" :
            _error("Fail to Check LX-BR-IF, ret=%s, output=%s, err=%s"%( str(_status), str(_output), str(_e) ))
            return None
        
        _br_ifs = []
        for _line in str(_output).split() :
            _comp = str(_line).split(',')
            if len(_comp) != 2 :
                _warn(" - Fail to Get LX-BR-IF, Invalid Return Line, line=%s"%str(_line))
                continue
            
            _nic = str(_comp[0]).strip()
            _last = str(_comp[1]).strip()
            if _nic == _brName or _last != "" :
                _nic = _last
            
            if _nic == "" :
                _warn(" - Fail to Get LX-BR-IF, Invalid Return Line, line=%s"%str(_line))
                continue
            
            if not _nic in _br_ifs :
                _br_ifs.append(_nic)
        
        return _br_ifs
    except Exception, e:
        _error("Fail to Get LX-Br-IF, Occur Error, exc=%s"%str(e))
        _except(e)
        return None

def add_br(_brname):
    try:
        _cmd = """ brctl addbr %s """%str(_brname)
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 and str(_e).find("same name") < 0  :
            _warn("Fail to Add lx-br, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_ret), str(_out), str(_e) ))
            return False
        else:
            return True
    except Exception, e:
        _error("Fail to Add lx-br, Occur Error, exc=%s"%str(e))
        _except(e)
        return False

def del_br_if(_brName, _brIF):
    try:
        _cmd = """ brctl delif %s %s """%( str(_brName), str(_brIF) )
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 and str(_e).find("not a slave") < 0 and str(_e).find("not exist") < 0 :
            _warn("Fail to Remove lx-br if, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_ret), str(_out), str(_e) ))
            return False
        else:
            return True
    except Exception, e:
        _error("Fail to Remove lx-br if, Occur Error, exc=%s"%str(e))
        _except(e)
        return False

def reset_os_bridge():
        br_list = ["br-internet", "br-internet1", "br-internet2", "br-internet3"]
        try:
            _netc = NetworkConfig()
            
            _cmd = "killall dhclient"
            Command().execute_command(_cmd)
            for br in br_list:
                _cmd = "ifconfig %s down" % br
                _ret, _out, _e = Command().execute_command(_cmd)
                _info(" - IFCONFIG DOWN, br=%s, out=%s, err=%s" % (br, str(_out), str(_e)))
                _cmd = "brctl delbr %s" % br
                _ret, _out, _e = Command().execute_command(_cmd)
                _info(" - LX-BR Delete, br=%s, out=%s, err=%s" % (br, str(_out), str(_e)))
                _netc.ifaces.removeAdapterByName(br)
                
            _netc.ifaces.writeInterfaces()
        except Exception, e:
            _error("Fail to Reset LX-BR, exc=%s"%str(e))
            _except(e)
            return False, "Reset LX-BR Exception"
            
        _info("SUCC: Reset LX-BR")
        return True, None

def unlock_interface(_ifName):
    try:
        interface_lock = "/run/network/ifstate.%s" % str(_ifName)
        delFile(interface_lock)
    except Exception, e:
        _error("Fail to Unlock if, Occur Error, exc=%s"%str(e))
        _except(e)


def get_nic_details(_pci_id):
    try:
        _ndetail = {}
        
        # driver
        _cmd = """ lspci -vmmks %s """%str(_pci_id)
        _ret, _out, _e = Command().execute_command(_cmd)
        if str(_e).strip() != "" :
            _warn(" - Fail to Get NIC-Detail, PCI-Driver Get Error, cmd=%s, err=%s"%( _cmd, str(_e).strip() ))
        
        for line in str(_out).splitlines():
            if len(line) == 0:
                continue
            name, value = str(line).split("\t", 1)
            name = str(name.strip(":")) + "_str"
            _ndetail[name] = str(value)
        
        # check for a unix interface name
        _ndetail["Interface"] = None
        for base, dirs, _ in os.walk("/sys/bus/pci/devices/%s/" % _pci_id):
            if "net" in dirs:
                _ndetail["Interface"] = ",".join(os.listdir(os.path.join(base, "net")))
                break
        
        # org driver
        _cmd = """ lspci -vnms %s | grep "^Vendor\|^Device" """%str(_pci_id)
        _ret, _out, _e = Command().execute_command(_cmd)
        if str(_e).strip() != "" :
            _warn(" - Fail to Get NIC-Detail, PCI-Driver Get Error, cmd=%s, err=%s"%( _cmd, str(_e).strip() ))
        
        _vname = None
        _dname = None
        for line in str(_out).splitlines():
            if str(line).find("Vendor") > -1 :
                name, value = str(line).split("\t", 1)
                _vname = str(value).strip()
            if str(line).find("Device") > -1 :
                name, value = str(line).split("\t", 1)
                _dname = str(value).strip()
        
        _ndetail['Driver_org'] = None
        if _vname != None and _dname != None:
            _cmd = """ cat /lib/modules/$(uname -r)/modules.alias | grep -i "%s.*%s" | tail -n 1 | awk '{print $3}' """%(_vname, _dname)
            _ret, _out, _e = Command().execute_command(_cmd)
            if str(_out).strip() == "" :
                _warn(" - Fail to Get NIC-Detail, PCI Init-Driver Get Error, pci=%s, vendor=%s, device=%s"%( _pci_id, str(_vname), str(_dname) ))
            else:
                _ndetail['Driver_org'] = str(_out).strip()
                _debug("pci=%s, vnd=%s, dev=%s, drv=%s"%(str(_pci_id), str(_vname), str(_dname), str(_out)))
        else:
            _warn(" - Fail to Get NIC-Detail, PCI-Product Get Error, pci=%s, vendor=%s, device=%s"%( _pci_id, str(_vname), str(_dname) ))
        
        return _ndetail
    except Exception, e:
        _error("Fail to Get NIC-Detail, exc=%s"%str(e))
        _except(e)
        return None

def get_nic_info():
    try:
        _nics = {}
        # '0000:06:00.0': {'Slot': '0000:06:00.0', 'SVendor': '8086', 'Vendor': 32902, 
        #                    'SDevice': '0000', 'Rev': '11', 'ProgIf': '30', 'Device': 5604, 
        #                    'Class': '0200'}
        _nic = {}
        
        _cmd_lspci = """ lspci -Dvmmn """
        _ret, _out, _e = Command().execute_command(_cmd_lspci)
        if str(_e).strip() != "" :
            _error("Fail to Get NIC-Info, PCI-Info Get Error, cmd=%s, err=%s"%( _cmd_lspci, str(_e).strip() ))
            return None
        
        for dev_line in str(_out).splitlines():
            if (len(dev_line) == 0):
                if _nic["Class"][0:2] == NETWORK_BASE_CLASS:
                    # convert device and vendor ids to numbers, then add to global
                    _nic["Vendor"] = int(_nic["Vendor"], 16)
                    _nic["Device"] = int(_nic["Device"], 16)
                    # use dict to make copy of dev
                    _nics[_nic["Slot"]] = dict(_nic)
            else:
                name, value = dev_line.split("\t", 1)
                _nic[str(name.rstrip(":"))] = str(value).strip()
        
        for _pci_id in _nics.keys():
            if str(_pci_id).strip() == "" :
                continue
            
            _pDetail = get_nic_details(_pci_id)
            if _pDetail == None :
                _warn(" - Fail to Get NIC-Info, Detail Get Error, pci=%s"%str(_pci_id))
                continue
            
            _nics[_pci_id] = _nics[_pci_id].copy()
            _nics[_pci_id].update(_pDetail.items())
        
        _debug(" - GET NIC Info: %s"%str(_nics))
        return _nics
    except Exception, e:
        _error("Fail to Get NIC-Info, exc=%s"%str(e))
        _except(e)
        return None

def ubind_dev(_dev_info):
    try:
        _dev_id = str(_dev_info['Slot']).strip()
        if _dev_id == "" :
            _error("Fail to UBind Device, No Device ID, dev=%s"%str(_dev_info))
            return False, "No Device ID"
        
        if not "Driver_str" in _dev_info :
            _info("SKIP to UBind Device, No Driver, dev=%s"%str(_dev_info))
            return True, None
        
        filename = "/sys/bus/pci/drivers/%s/unbind" % _dev_info["Driver_str"]
        try:
            f = open(filename, "a")
            f.write(_dev_id)
        except Exception, e:
            _error("Fail to UBind Device, dev=%s, file=%s, exc=%s"%( str(_dev_info), filename, str(e) ))
            _except(e)
            return False, str(e)
        
        f.close()
        return True, None
    except Exception, e:
        _error("Fail to UBind Device, dev=%s, exc=%s"%( str(_dev_info), str(e) ))
        _except(e)
        return False, str(e)

def bind_dev(_dev_info, _drv_name, _recursv=False):
    try:
        _dev_id = str(_dev_info['Slot']).strip()
        if _dev_id == "" :
            _error("Fail to Bind Device, No Device ID, dev=%s"%str(_dev_info))
            return False, "No Device ID"
        
        saved_driver = None
        if "Driver_str" in _dev_info :
            saved_driver = _dev_info["Driver_str"]
            if saved_driver == _drv_name :
                _info("SKIP to Bind Device, Already Bind, dev=%s"%str(_dev_info))
                return True, None
            else:
                ubind_dev(_dev_info)
    
        # if we are binding to one of DPDK drivers, add PCI id's to that driver
        if _drv_name in DPDK_DRVS:
            filename = "/sys/bus/pci/drivers/%s/new_id" % _drv_name
            try:
                f = open(filename, "w")
                f.write("%04x %04x" % (_dev_info["Vendor"], _dev_info["Device"]))
                f.close()
            except Exception, e:
                _error("Fail to Bind Device, DPDK-Bind Error, dev=%s, file=%s, exc=%s"%( str(_dev_info), filename, str(e) ))
                _except(e)
                return False, str(e)
        
        # do the bind by writing to /sys
        filename = "/sys/bus/pci/drivers/%s/bind" % _drv_name
        try:
            f = open(filename, "a")
        except Exception, e:
            _error("Fail to Bind Device, Kern-Bind Error(open), dev=%s, file=%s, exc=%s"%( str(_dev_info), filename, str(e) ))
            _except(e)
            if not _recursv and saved_driver is not None:  # restore any previous driver
                bind_dev(_dev_info, saved_driver, True)
            return False, str(e)
        
        try:
            f.write(_dev_id)
            f.close()
        except Exception, e:
            # for some reason, closing dev_id after adding a new PCI ID to new_id
            # results in IOError. however, if the device was successfully bound,
            # we don't care for any errors and can safely ignore IOError
            tmp = get_nic_details(_dev_id)
            if "Driver_str" in tmp and tmp["Driver_str"] == _drv_name:
                _dev_info["Driver_str"] = _drv_name
                return True, None
            
            _error("Fail to Bind Device, Kern-Bind Error(write), dev=%s, file=%s, exc=%s"%( str(_dev_info), filename, str(e) ))
            _except(e)
            if not _recursv and saved_driver is not None:  # restore any previous driver
                bind_dev(_dev_info, saved_driver, True)
            return False, str(e)
        
        _dev_info["Driver_str"] = _drv_name
        return True, None
    except Exception, e:
        _error("Fail to Bind Device, dev=%s, drv=%s, exc=%s"%( str(_dev_info), str(_drv_name), str(e) ))
        _except(e)
        return False, str(e)


def delFile(absPath):
    try:
        if os.path.isfile( absPath ) and os.path.isabs( absPath ):
            os.remove( absPath )
            _debug("Delete File, f=%s"%str(absPath))
    except Exception, e:
        _error("Fail to Delete File, Occur Error, exc=%s"%str(e))
        _except(e)


def set_file_permission(_file, permission):
    try:
        _cmd = """ chmod %s %s """%( str(permission), str(_file) )
        _ret, _out, _e = Command().execute_command(_cmd)
        if _ret != 0 :
            _error("Fail to Set File Permission, cmd=%s, ret=%s, out=%s, err=%s"%( _cmd, str(_ret), str(_out), str(_e) ))
            return False
        else:
            return True
    except Exception, e:
        _error("Fail to Set File Permission, Occur Error, exc=%s"%str(e))
        _except(e)
        return False

def set_remote_file_permission(ssh, permission, target):
    try:
        ssh_cmd="chmod %s %s/*" % (permission, target)
#         stdin, stdout, stderr = ssh.exec_command(ssh_cmd, timeout=30)
        _ret = ssh.exec_command(ssh_cmd, timeout=30)
        if _ret[2] != None and str(_ret[2]).strip() != "" :
            _error("Fail to Set Remote File Permission, cmd=%s, err=%s"%( ssh_cmd, str(_ret[2]) ))
            return False
        
        _info("SUCC: Set Remote File Permission, cmd=%s"%ssh_cmd)
        return True
    except Exception, e :
        _error("Fail to Set Remote File Permission, target=%s, perm=%s, exc=%s"%( str(target), str(permission), str(e) ))
        _except(e)
        return False

def find_file(_dir, _fname=None, _mday=None, _aday=None, _except_txt=None):
    # find /var/onebox/.stat -atime +1 -ctime +1 -mtime +1 | grep -v "onebox_etc_status\|onebox_net_status\|onebox_status\|onebox_wan_status"
    _cmd = """ find %s -type f """%str(_dir)
    if _fname != None :
        _cmd = _cmd + """-name %s """%str(_fname)
    if _mday != None :
        _cmd = _cmd + """-mtime %s -ctime %s """%( str(_mday), str(_mday) )
    if _aday != None :
        _cmd = _cmd + """-atime %s """%str(_aday)
    if _except_txt != None :
        if type(_except_txt) == tuple or type(_except_txt) == list :
            _cmd = _cmd + """| grep -v "%s" """%("\|".join(_except_txt))
        else:
            _cmd = _cmd + """| grep -v "%s" """%str(_except_txt)
    
    try:
        _status, _out, _err = Command().execute_command(_cmd)
        if _status != 0 :
            _error("Fail to Find File, cmd=%s, status=%s, out=%s, err=%s"%( _cmd, str(_status), str(_out), str(_err) ))
            return None
        else:
            _ret = str(_out).split()
            _files = []
            for _ff in _ret :
                _files.append(str(_ff).strip())
            return _files
    except Exception, e:
        _error("Fail to Find File, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return None

def exec_pexpect(_cmd, expectList, timeout_=60):
    """
    eList = [
                {"exp":"password:", "react":"RUN", "res":"asdfasdf"},
                {"exp":"EOF", "react":"END"}
            
            ]
    react : "END", "RUN"
    expect end : "EOF", "done", ...
    "EOF" --> pexcept.EOF
    """
    _debug("PEXPECT Start: cmd=%s, expect=%s" %(_cmd, str(expectList)))
    child = None
    try:
        child = pexpect.spawn(str(_cmd).strip(), timeout=timeout_)
        #child.logfile = sys.stdout
        
        _expList = []
        for _exp in expectList :
            if _exp['exp'] == "EOF":
                _expList.append(pexpect.EOF)
            else:
                _expList.append(_exp['exp'])
        
        while True :
            resp = child.expect(_expList)
            _buf = str(child.buffer)
            if resp < len(expectList) :
                _react = expectList[resp]['react']
                if _react == "END" :
                    _debug("PExpect END: exp=%s, buf=%s"%( expectList[resp]['exp'], _buf))
                    return True, _buf
                elif _react == "RUN" :
                    _snd = expectList[resp]['res']
                    _debug("PExpect RUN: %s --> %s, buf=%s"%( expectList[resp]['exp'], _snd, _buf))
                    child.sendline(_snd)
                else:
                    _error("PExpect Error: Invalid REACT Param, react=%s, buf=%s"%(str(_react), _buf))
                    child.kill(0)
                    child.close()
                    return False, "PExpect Invalid REACT PARAM"
            else:
                _error("PExpect Error: Invalid Expect Return, ret=%s, buf=%s"%(str(resp), _buf))
                child.kill(0)
                child.close()
                return False, "PExpect Invalid Return"
    except pexpect.TIMEOUT:
        _buf = None
        if child != None :
            _buf = str(child.buffer)
        _error("PExpect Exception: cmd=%s, expect=%s, buf=%s"%(_cmd, str(expectList), str(_buf)))
        return False, "PExcept TimeOut"
    except Exception, e:
        _error("PExpect Exception")
        _except(e)
        return False, str(e)
    finally:
        if child != None : child.close()






class NetworkConfig():
    
    def __init__(self, cfg_file=INTERFACES_PATH, back_file=BACKUP_PATH):
        self._cfg_file = cfg_file
        self.ifaces = Interfaces(interfaces_path=cfg_file, backup_path=back_file)
    
    def config_bridge_internet(self, br_name, nics, is_dhcp, ip_addr=None, net_mask=None, net_gw=None, dns_ip=None):
        # configuration의 결과가 성공적임을 확인하기 위한 플래그
        try:
            if dns_ip == None :
                dns_addr = DEF_DNS
            else:
                dns_addr = dns_ip
            nic_txt = ','.join(nics)
            if is_dhcp:
                ip_source = "dhcp"
                
                options= {
                      "name": br_name, 
                      "addrFam": "inet",
                      "auto": True,
                      "source": ip_source,
                      "dns-nameservers": (dns_addr),
                      "bridge_ports":  nic_txt
                }
            else:
                ip_source = "static"
                    
                options= {
                      "name": br_name, 
                      "addrFam": "inet",
                      "auto": True,
                      "source": ip_source,
                      "address": ip_addr,
                      "netmask": net_mask,
                      "gateway": net_gw,
                      "dns-nameservers": (dns_addr),
                      "bridge_ports":  nic_txt
                }
            self.ifaces.removeAdapterByName(br_name)
            self.ifaces.addAdapter(options)
            _info("SUCC: Config LX-BR, info=%s"%str(options))
            return True
        except Exception, e:
            _error("Fail to Config Internet Bridge, name=%s, exc=%s"%( str(br_name), str(e) ))
            _except(e)
            return False
    
    def config_manual_updown(self, if_name):
        # configuration의 결과가 성공적임을 확인하기 위한 플래그
        try:
            options= {
                  "name": if_name, 
                  "addrFam": "inet",
                  "source": "manual",
                  "post-up": "ifconfig $IFACE up",
                  "pre-down": "ifconfig $IFACE down",
                  "auto": True
            }
            
            self.ifaces.removeAdapterByName(if_name)
            self.ifaces.addAdapter(options)
            _info("SUCC: Config manual-updown iface, info=%s"%str(options))
            return True
        except Exception, e:
            _error("Fail to Config Manual UpDown, name=%s, exc=%s"%( str(if_name), str(e) ))
            _except(e)
            return False
    
    def config_default_local_network(self, br_name, _ip, _mask):
        return self._config_ovs_br(br_name, _ip, _mask)
    
    def config_local_network(self, br_name, _ip, _mask, _init_route_list):
        '''
        _del_route_list : [ "192.168.0.0/24", ... ]
        '''
        _pd = []
        _pu = []
        for _init_r in _init_route_list :
            _pd.append( "ip route del %s dev $IFACE"%str(_init_r) )
            _pu.append( "ip route add %s dev $IFACE"%str(_init_r) )
        if len(_pd) < 1 :
            _prevdown = None
        else:
            _prevdown = "; ".join(_pd)
        if len(_pu) < 1 :
            _prevup = None
        else:
            _prevup = "; ".join(_pu)
        return self._config_ovs_br(br_name, _ip, _mask, _prevdown, _prevup)
    
    def _config_ovs_br(self, br_name, _ip, _mask, _prevdown=None, _prevup=None):
        options= {
              "name": br_name, 
              "addrFam": "inet",
              "auto": True,
              "source": "static",
              "address": _ip,
              "netmask": _mask,
              "ovs_type": "OVSBridge"
        }
        if _prevdown != None :
            options['pre-down'] = _prevdown
        if _prevup != None :
            options['pre-up'] = _prevup
        
        try:
            self.ifaces.removeAdapterByName(br_name)
            self.ifaces.addAdapter(options)
            _info("SUCC: Config Init Local Network, info=%s"%str(options))
            return True
        except Exception, e:
            _error("Fail to Config OVS-BR, name=%s, ip=%s/%s, exc=%s"%( str(br_name), str(_ip), str(_mask), str(e) ))
            _except(e)
        return False
    
    def write(self):
        '''
        Write는 항상 외부에서 호출해준다.
        NetworkConfig에서는 설정을 추가/삭제/변경하고, 이들에 대한 write는 외부에 한 번 호출해야 오류 가능성을 줄일 수 있다. 
        '''
        try:
            self.ifaces.writeInterfaces()
            _info("SUCC: Write Network Config")
            return True
        except Exception, e:
            _except(e)
            return False


class Command:
    
    def __init__(self):
        pass
    
    def run_process(self, commands):
        code = 0
        output = ""
        try:
            p = Popen([commands], stdout = PIPE, stderr=PIPE, shell=False, close_fds = True)
            while True:
                code = p.poll()
                if p.stderr:
                    line = p.stderr.read().decode("utf-8")
                else:
                    line = p.stdout.read().decode("utf-8")
                output = output + line
                
                if code is not None:
                    break
            p.stderr.close()
            p.stdout.close()
        
        except Exception, e:
            code = 1
            output = str(e)
            _except(e)
            
        return (code, output)  
    
    def execute_command(self, commands):
        code = 0
        ret_out = ""
        ret_err = ""
        try:
            p = Popen(commands, shell=True, stdout=PIPE, stderr=PIPE, close_fds=True)
            # communicate는 프로세스가 종료될 때까지 대기한 후 최종 결과를 반환한다.
            # 즉, wait가 필요없음
            (ret_out, ret_err) = p.communicate()
            p.stdout.close()
            p.stderr.close()
            code = p.wait()
        except CalledProcessError as e:
            _except(e)
            code = e.returncode
            ret_out = e.output
        except Exception, e:
            code = 1000
            ret_err = str(e)
            _except(e)
            
        return (code, ret_out, ret_err)  


class Service(Command):
    
    def __init__(self, service):
        self.service = service
        
    def get_name(self):
        return self.service
    
    def start(self):
        commands = "service %s start" % self.service
        return  self.execute_command(commands)
            
    def stop(self):
        commands = "service %s stop" % self.service
        return  self.execute_command(commands)
            
    def restart(self):
        commands = "service %s restart" % self.service
        return  self.execute_command(commands)
    
    def stop_and_start(self):
        self.stop()
        sleep(0.5)
        self.start()
            
    def status(self):
        commands = "service %s status" % self.service
        (_code, ret_out, ret_err) = self.execute_command(commands)
        # if ret_out.find ("is running") != -1:
        #     return True
        if ret_out.find("running") != -1:
            return True
        elif ret_out.find ("start/running") != -1:
            return True
        elif ret_out.find ("start/post-stop") != -1:
            return True
        elif ret_out.find ("Running") == 0:
            return True
        
        _debug(" - svc status, name=%s, ret=%s, out=%s, err=%s"%( self.service, str(_code), str(ret_out), str(ret_err) ))
        return False


class SshTunnel(threading.Thread):
    """
    1. 단일 모드에서만 run 수행
    2. 중복 create 시 중복 체크 필요
    """
    _CHK_SLEEP = 10
    _RESULT = None
    _RETURN = None
    
    def __init__(self, _sshAuth, _svrPort, _dstIP, _dstPort, _svrIP="localhost", _sshPort=22, _to=3600 ):
        """
        _sshAuth : 암호인증 또는 인증서 인증
            - 암호 인증 : _sshAuth = {"id":"onebox", "pass":"asdfasdf"}
            - 인증서 인증 : _sshAuth = {"key": "/var/onebox/key/id_rsa"}
        _to : Thread Mode 일 경우 사용
        """
        threading.Thread.__init__(self)
        
        if _sshAuth == None or type(_sshAuth) != dict :
            raise Exception("SSHTunnel Exception: Invalid AuthInfo, auth=%s"%str(_sshAuth))
        
        if _sshAuth.has_key("id") and _sshAuth.has_key('pass') and not _sshAuth.has_key('key'):
            pass
        elif not _sshAuth.has_key("id") and not _sshAuth.has_key('pass') and _sshAuth.has_key('key'):
            pass
        else: 
            raise Exception("SSHTunnel Exception: Invalid AuthInfo, auth=%s"%str(_sshAuth))
        
        self.sshAuth = _sshAuth
        if self.sshAuth.has_key("pass") :
            self.sshAuthType = "pass"
        elif self.sshAuth.has_key("key") : 
            self.sshAuthType = "key"
        else:
            raise Exception("SSHTunnel Exception: Invalid AuthType, auth=%s"%str(self.sshAuth))
        
        self.svrIP = str(_svrIP)
        self.svrPort = str(_svrPort)
        self.dstIP = str(_dstIP)
        self.dstPort = str(_dstPort)
        self.sshPort = str(_sshPort)
        self.timeout = _to
    
    def run_status(self):
        """
        Thread 모드 일 경우 사용
        """
        return self._RESULT, self._RETURN
    
    def create(self, _svrIP=None):
        if _svrIP != None : self.svrIP = _svrIP
        _info( "Start SSH-Tunnel: auth=%s, svrIP=%s, svrPort=%s, dstIP=%s, dstPort=%s"%(
                    str(self.sshAuth), self.svrIP, self.svrPort, self.dstIP, self.dstPort ) )
        
        try:
            ## Create SSHTunnel
            if self.sshAuthType == "key" :
                from subprocess import call
                _SOUT = tempfile.TemporaryFile()
                _SERR = tempfile.TemporaryFile()
                
                _cmd = [
                        'ssh', self.svrIP, 
                        "-o", "StrictHostKeyChecking=no",
                        '-L', "%s:%s:%s"%(self.svrPort, self.dstIP, self.dstPort),
                        '-Nfgi', str(self.sshAuth['key']),
                        '-p', self.sshPort,
                        ]
                _ret = call(_cmd, stdout=_SOUT, stderr=_SERR)
                _SOUT.seek(0)
                _SERR.seek(0)
                _output = str(_SOUT.read()).strip()
                _e = str(_SERR.read()).strip()
                
                if _e != "" and _e.find("Address already in use") < 0 and _e.find("Warning: Permanently added") < 0 :
                    _err = "Fail to Open SSHTunnel, _cmd=%s, err=%s"%( " ".join(_cmd), _e )
                    _except(_err)
                    return False, _err
                
            elif self.sshAuthType == "pass" :
                _cmd = """ ssh -f -N -g -L %s:%s:%s -l %s %s -p %s """%(
                            self.svrPort, self.dstIP, self.dstPort, str(self.sshAuth['id']), self.svrIP, self.sshPort )
                exps = [{'exp':"no\)\? ", 'react':'RUN', 'res':'yes'}, 
                        {'exp':'password:', 'react':"RUN", "res":self.sshAuth['pass']},
                        {'exp':'EOF', 'react':"END"}]
                _status, _output = exec_pexpect(_cmd, exps, 3)
                if not _status :
                    _err = "Fail to Open SSHTunnel, cmd=%s, ret=%s"%(_cmd, str(_output))
                    _except(_err)
                    return False, _err
            else:
                _err ="Fail to Open SSHTunnel, Invalid AuthType, auth=%s"%str(self.sshAuth)
                _except(_err)
                return False, _err
            
            _info("Succ: Create SSHTunnel")
            return True, None
        except Exception, e:
            _err = "Fail to Open SSHTunnel, exc=%s"%str(e)
            _error(_err)
            _except(e)
            return False, _err
    
    def destroy(self):
        _info("Close SSHTunnel..")
        _kill_cmd = """ ps -ef | grep -v "grep" | grep "ssh" | grep "%s:%s:%s" | awk '{print $2}' | xargs  -n 1 kill -9 $1 """%(self.svrPort, self.dstIP, self.dstPort)
        try:
            _status, _output, _e = Command().execute_command(_kill_cmd)
            _info(" - cmd=%s, ret=%s, err=%s"%( _kill_cmd, str(_output), str(_e) ))
            if _status != 0 or str(_e).strip() != "" :
                _error("Fail to Destroy SSHTunnel, status=%s, ret=%s, err=%s"%( str(_status), str(_output), str(_e) ))
                return False
            
            _info("Succ: SSHTunnel Closed")
            return True
        except Exception, e:
            _error("Fail to Destory SSHTunnel, exc=%s"%str(e))
            _except(e)
            return False
    
    def status(self):
        _chk_cmd = """ ps -ef | grep -v "grep" | grep "ssh" | grep -c "%s:%s:%s" """%(self.svrPort, self.dstIP, self.dstPort)
        _info("Check SSHTunnel Status, cmd=%s"%_chk_cmd)
        try:
            _status, _output, _e = Command().execute_command(_chk_cmd)
            try:
                if int(_output) < 1 :
                    _info("SUCC: SSHTunnel Check: OFF")
                    return True, False
                else:
                    _info("SUCC: SSHTunnel Check: ON")
                    return True, True
            except Exception:
                _error("Fail to Check SSHTunnel, ret=%s, out=%s, err=%s"%(str(_status), str(_output), str(_e)))
                return False, False
        except Exception, e:
            _error("Fail to Check SSHTunnel, exc=%s"%str(e))
            _except(e)
            return False, False
    
    
    def run(self):
        self._RESULT, self._RETURN = self.create()
        
        
        _chk_cmd = """ ps -ef | grep -v "grep" | grep "ssh" | grep -c "%s:%s:%s" """%(self.svrPort, self.dstIP, self.dstPort)
        
        _info("Start SSHTunnel Chk, cmd=%s"%_chk_cmd)
        while True :
            try:
                if self.timeout < 0 :
                    _info("Stop SSHTunnel Check: Expired AliveTime, Destroy All SSHTunnel")
                    self.destroy()
                    return
                
                _status, _output, _e = Command().execute_command(_chk_cmd)
                if _status == 0 and int(_output) < 1 :
                    _info("Stop SSHTunnel Check: No SSHTunnel")
                    return
                
                _debug("RUN SSHTunnel Check: ret=%s, remainTime=%s"%( str(_output), str(self.timeout) ))
            except Exception, e:
                _error("Fail to Check SSHTunnel, exc=%s"%str(e))
                _except(e)
            
            self.timeout -= self._CHK_SLEEP
            sleep(self._CHK_SLEEP)
            
        












