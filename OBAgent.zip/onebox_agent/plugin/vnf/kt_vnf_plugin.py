#-*- coding: utf-8 -*-
'''
Created on 2017. 8. 2.

@author: ohhara
'''
import traceback, json, paramiko, threading, copy, os, ruamel.yaml, sys, tempfile
from time import sleep
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from ipaddr import IPv4Network


V_TYPE = "KT-VNF"

HEADER = {"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"}
HEADER_VNFM = {"content-Type": "application/json", "accept":"*/*"}

DEF_ID = 'root'
DEF_PASS = 'smflaqh#1'

C_Crt = "/var/onebox/key/client.crt"
C_Key = "/var/onebox/key/client.key"

_P_NICS = ['eth1', 'eth5', 'eth6', 'eth7']
_MAIN_TABLE = "main"
_EXCEPT_TABLE = [ 'local', 'default' ]


_URL_IDX = """https://%s/index.dao"""
_URL_LOGIN = """https://%s/login.dao"""
_URL_LOGOUT = """https://%s/logout.dao"""

_URL_BR = """https://%s/base/bridge.dao?User=%s"""
_URL_OPENVPN = """https://%s/vpn/openvpn.dao?User=%s"""
_URL_QOS_IF = """https://%s/filter/qos_interface_search.dao?User=%s"""
_URL_ETH = """https://%s/base/ethernet.dao?User=%s"""
_URL_DHCP = """https://%s/base/xdsl.dao?User=%s"""
_URL_ROUTE_MAP = """https://%s/base/route/map.dao?User=%s"""
_URL_ROUTE = """https://%s/base/route/table.dao?_name=%s&User=%s"""
_URL_ROUTE_RULE = """https://%s/base/route/rule.dao?User=%s"""
_URL_OBJ_NET = """https://%s/object/network_search.dao"""

_URL_DEL_ROUTE = """https://%s/base/route/table_delete.dao"""
_URL_DEL_ARP = """https://%s/base/arp_delete.dao"""
_URL_DEL_ROUTE_RULE = """https://%s/base/route/rule_delete.dao"""
_URL_DEL_ETH = """https://%s/base/ethernet_delete.dao"""
_URL_DEL_DHCP = """https://%s/base/xdsl_delete.dao"""

_URL_ADD_EHT = """https://%s/base/ethernet_create.dao"""
_URL_ADD_DHCP = """https://%s/base/xdsl_create.dao"""
_URL_ADD_ROUTE = """https://%s/base/route/table_create.dao"""

_URL_MOD_OBJ_NET = """https://%s/object/network_modify.dao"""
_URL_MOD_IP = """https://%s/base/interface_modify.dao"""
_URL_MOD_ROUTE = "https://%s/base/route/table_modify.dao"

_URL_VNFM_BACKUP = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/backup"""%V_TYPE
_URL_VNFM_RESTORE = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/restore"""%V_TYPE
_URL_VNFM_STATUS = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/status"""%V_TYPE

def load_cfg(_type):
    global V_TYPE, _URL_VNFM_BACKUP, _URL_VNFM_RESTORE, _URL_VNFM_STATUS
    
    V_TYPE = _type
    _URL_VNFM_BACKUP = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/backup"""%V_TYPE
    _URL_VNFM_RESTORE = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/restore"""%V_TYPE
    _URL_VNFM_STATUS = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/status"""%V_TYPE


def _getLineNo():
    org_f = None
    try:
        raise Exception
    except:
        org_f = sys.exc_info()[2].tb_frame.f_back
    #On some versions of IronPython, currentframe() returns None if
    #IronPython isn't run with -X:Frames.
    if org_f is not None:
        f = org_f.f_back
    else:
        return None
    
    if f == None :
        return None
    
    l_no = f.f_lineno
    return l_no

logger = None
_LOG_T = "[PLG-KTVNF.%-4s]"
def _debug(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.debug(msg)
    else: print msg

def _info(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.info(msg)
    else: print msg

def _warn(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.warning(msg)
    else: print msg

def _error(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.error(msg)
    else: print msg

def _except(exc):
    _SERR = tempfile.TemporaryFile()
    traceback.print_exc(exc, _SERR)
    _SERR.seek(0)
    msg = _SERR.read()
    msg = _LOG_T%str(_getLineNo()) + "\n" + str(msg)
    if logger != None : logger.fatal(msg)
    else: print msg




class SshClientTimer():
    
    def __init__(self, sshClient, _cmd, _wait):
        self.sshClient = sshClient
        self._cmd = _cmd
        self.timer = threading.Timer(_wait+10, self.do )
    
    def do(self):
        try:
            if self.sshClient is not None:
                self.sshClient.close()
                _warn("+++++++++ TimeOut SSHClient, cmd=%s"%str(self._cmd))
                return
            
            _debug("+-------- not killed ssh timer, cmd=%s"%str(self._cmd))
        except Exception, e:
            _error("+++++++++ Exception to Close SSHClient Thread, cmd=%s"%str(self._cmd))
            _except(e)
    
    def start(self):
        self.timer.start()
    
    def stop(self):
        self.timer.cancel()

def ssh_cmd(svr_ip, cmd, _to=10):
    client = None
    csc = None
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.load_system_host_keys()
        
        csc = SshClientTimer(client, cmd, _to)
        csc.start()
        
        try:
            client.connect(svr_ip, timeout=_to)
        except Exception:
            import Crypto.Cipher.AES
            orig_new = Crypto.Cipher.AES.new
            def fixed_AES_new(key, *ls):
                if Crypto.Cipher.AES.MODE_CTR == ls[0] :
                    ls = list(ls)
                    ls[1] = ''
                return orig_new(key, *ls)
            Crypto.Cipher.AES.new = fixed_AES_new
            client.connect(svr_ip, timeout=_to)
        _std = client.exec_command(cmd)
        out = str(_std[1].read()).strip()
        err = str(_std[2].read()).strip()
        
        client.close()
        client = None
        csc.stop()
        
        if err != "" :
            return False, err
        else:
            return True, out
    except Exception,e:
        _error("Exception to Run SSH Commend, ip=%s, cmd=%s"%(str(svr_ip), str(cmd)))
        _except(e)
    finally:
        if client is not None:
            client.close()
            client = None
        if csc is not None :
            csc.stop()
    
    return False, None

def callAPI( _url, _method, header=HEADER, reqBody=None, returnHeader=False, _to=5, cCrt=None, cKey=None, sTime=2 ):
    try:
        sleep(sTime)
        
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(header)
        if reqBody == None:
            strBody = None
        elif type(reqBody) == str:
            strBody = reqBody
        else:
            strBody = json.dumps( reqBody )
        
        if cCrt == None or cKey == None :
            req = HTTPRequest( validate_cert=False, url=_url, headers=h, method=_method.upper(), 
                           body=strBody, request_timeout=_to )
        else:
            req = HTTPRequest( validate_cert=False, url=_url, headers=h, method=_method.upper(), 
                            client_cert=cCrt,
                            client_key=cKey,
                            body=strBody, request_timeout=_to )
                
        response = http_client.fetch( request=req )
        http_client.close()
        
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except :
            pass
        
        if returnHeader :
            return { "header": response.headers, "body": retBody }
        else:
            return retBody
    except Exception, e:
        _error("Fail to Call API, url=%s, method=%s, body=%s"%(_url, _method, reqBody))
        _except(e)
        return None



def login(vnfIP, vnfID=None, vnfPass=None, _rNum = 10):
    if vnfID == None : vnfID = DEF_ID
    if vnfPass == None : vnfPass = DEF_PASS
    
    _title = "KT-VNF Login"
    for _idx in range(_rNum):
        sleep(3)
        try:
            ### Login
            _url = _URL_IDX%vnfIP
            _ret = callAPI(_url, "GET")
            
            _url = _URL_LOGIN%vnfIP
            _body = 'username=%s&passwd=%s&force=%s'%(vnfID, vnfPass, str(1))
            _ret = callAPI(_url, "POST", reqBody=_body, sTime=1)
            if _ret == None or not _ret.has_key('success') or str(_ret['success']) != "true" :
                _warn("Fail to %s, retry=%s/%s, ret=%s"%(_title, str(_idx+1), str(_rNum), str(_ret)))
                continue
            
            _debug("Succ: %s"%_title)
            return True
        except Exception, e:
            _warn("Fail to %s, retry=%s/%s, exception=%s"%(_title, str(_idx+1), str(_rNum), str(e)))
            _except(e)
            continue
        
    return False

def logout(vnfIP, vnfID=None):
    if vnfID == None : vnfID = DEF_ID
    
    _title = "KT-VNF LogOut"
    try:
        ### Login
        _url = _URL_LOGOUT%vnfIP
        _body = 'User=%s'%(vnfID)
        _ret = callAPI(_url, "POST", reqBody=_body, sTime=1)
        sleep(1)
        if _ret == None or not _ret.has_key('success') or _ret['success'] != True :
            _warn("Fail to %s, ret=%s"%(_title, str(_ret)))
            return False
        
        _debug("Succ: %s"%_title)
        return True
    except Exception, e:
        _warn("Fail to %s, exception=%s"%(_title, str(e)))
        _except(e)
        return False

def is_same_state_for_restore():
    return False

def get_web_port():
    return 443

def get_model():
    return V_TYPE

def get_wan_nic_list():
    return _P_NICS

def get_metric(_name):
    '''
    return : None or metric
    '''
    __n = str(_name).strip()
    if __n == "br-wan" : return 0
    elif __n == "br-wan1" : return 100
    elif __n == "br-wan2" : return 200
    elif __n == "br-wan3" : return 300
    else : return None

def get_nic(_name):
    '''
    return : None or if_name
    '''
    __n = str(_name).strip()
    if __n == "br-wan" : return "eth1"
    elif __n == "br-wan1" : return "eth5"
    elif __n == "br-wan2" : return "eth6"
    elif __n == "br-wan3" : return "eth7"
    elif __n == "br-lan-office" : return "eth2"
    elif __n == "br-lan-server" : return "eth3"
    else : return None

def _get_dhcp_name(_name):
    '''
    return : None or dhcp_name
    '''
    __n = str(_name).strip()
    if __n == "br-wan" or __n == "eth1" : return "red_dhcp"
    elif __n == "br-wan1" or __n == "eth5" : return "red_dhcp_r1"
    elif __n == "br-wan2" or __n == "eth6" : return "red_dhcp_r2"
    elif __n == "br-wan3" or __n == "eth7" : return "red_dhcp_r3"
    else : return None

def get_br(_name):
    '''
    return : None or br_name
    '''
    __n = str(_name).strip()
    if __n == "eth1" : return "br-wan"
    if __n == "eth2" : return "br-lan-office"
    if __n == "eth3" : return "br-lan-server"
    elif __n == "eth5" : return "br-wan1"
    elif __n == "eth6" : return "br-wan2"
    elif __n == "eth7" : return "br-wan3"
    else : return None

def _get_br_list(_vnf_ip):
    '''
    return : None or br-name list
    '''
    _cmd = """ brctl show | grep '^[a-z,A-Z,0-9]' | grep -v '^bridge name' | awk '{print $1}' """
    try:
        _res, _ret = ssh_cmd(_vnf_ip, _cmd)
        try:
            if not _res :
                _error("Fail to Get BR-List, cmd=%s, ret=%s, out=%s"%( _cmd, _res, _ret ))
                return None
            _br_list = []
            for _line in str(_ret).split() :
                if _line != None and str(_line).strip() != "" :
                    _br_list.append(str(_line).strip())
            return _br_list
        except Exception, e:
            _error("Fail to Get BR-List, cmd=%s, ret=%s, out=%s, exc=%s"%( _cmd, _res, _ret, str(e) ))
            _except(e)
            return None
    except Exception, e:
        _error("Fail to Run CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return None
    
def get_br_info(_vnf_ip, _brname=None):
    '''
    return : None or dict{'br1': ['eth1'], 'br2':[]}
    '''
    if _brname == None :
        _brlist = _get_br_list(_vnf_ip)
    else:
        _brlist = [_brname]
    if type(_brlist) != list or len(_brlist) < 1 :
        return None
    
    _br_info = {}
    __cmd = """ brctl show %s | grep -v "bridge name" | awk '{print $1","$4}' """
    for _brname in _brlist :
        _br_ifs = []
        _cmd = __cmd%_brname
        try:
            _res, _ret = ssh_cmd(_vnf_ip, _cmd)
            if str(_ret).find("No such device") > -1 :
                _warn(" - Skip to Get VNF-BR-IF, No Bridge, cmd=%s, ret=%s"%(_cmd, str(_ret)))
                continue
            if not _res :
                _warn(" - Fail to Get VNF-BR-IF, cmd=%s, ret=%s"%(_cmd, str(_ret)))
                continue
            
            for _line in str(_ret).split() :
                _comp = str(_line).split(',')
                if len(_comp) != 2 :
                    _warn(" - Fail to Get VNF-BR-IF, Invalid Return Line, line=%s"%str(_line))
                    continue
                
                _nic = str(_comp[0]).strip()
                _last = str(_comp[1]).strip()
                if _nic == _brname or _last != "" :
                    _nic = _last
                
                if _nic == "" :
                    _warn(" - Fail to Get VNF-BR-IF, Invalid Return Line, line=%s"%str(_line))
                    continue
                
                if not _nic in _br_ifs :
                    _br_ifs.append(_nic)
            
            _br_info[_brname] = _br_ifs
        except Exception, e:
            _warn(" - Fail to Get VNF-BR-IF, cmd=%s, ret=%s, exc=%s"%( _cmd, str(_ret), str(e) ))
            _except(e)
            continue
    return _br_info

def get_route_table(_vnf_ip):
    '''
    return : None or List
    '''
    _cmd = """ ip rule list | awk -F "lookup " '{print $2}' """
    try:
        _res, _ret = ssh_cmd(_vnf_ip, _cmd)
        try:
            if not _res :
                _error("Fail to Get Route-Table, cmd=%s, ret=%s, out=%s"%( _cmd, _res, _ret ))
                return None
            _rt_list = []
            for _tbName in str(_ret).split() :
                tbName = str(_tbName).strip()
                if tbName == _MAIN_TABLE :
                    _rt_list.insert(0, tbName)
                elif tbName != "" and not tbName in _EXCEPT_TABLE :
                    _rt_list.append(tbName)
            return _rt_list
        except Exception, e:
            _error("Fail to Get Route-Table, cmd=%s, ret=%s, out=%s, exc=%s"%( _cmd, _res, _ret, str(e) ))
            _except(e)
            return None
    except Exception, e:
        _error("Fail to Run CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return None

def get_gw_info(_vnf_ip, _tname="main", _dev=None):
    '''
    return : None or [(dev, ip, metric)]
    '''
    if _dev == None :
        _cmd = """ ip route list table "%s" | grep "^default" | awk '{print $3","$5","$7}' """%(str(_tname))
    else:
        _cmd = """ ip route list table "%s" | grep "^default" | grep '%s' | awk '{print $3","$5","$7}' """%(str(_tname), str(_dev))
    
    try:
        _res, _ret = ssh_cmd(_vnf_ip, _cmd)
        try:
            if not _res :
                _error("Fail to Get GW-Info, cmd=%s, ret=%s, out=%s"%( _cmd, _res, _ret ))
                return None
            
            _tmp_gw_list = []
            for _gw_txt in str(_ret).split() :
                try:
                    _gw_info = str(_gw_txt).split(",")
                    _dev = _gw_info[1]
                    _ip = _gw_info[0]
                    _metric = 0
                    if len(_gw_info) > 2 and str(_gw_info[2]).strip() != "" :
                        _metric = int(str(_gw_info[2]).strip())
                    _tmp_gw_list.append(( str(_dev).strip(), str(_ip).strip(), _metric ))
                except Exception, e:
                    _warn("Fail to Get GW-Info, Invalid Return, ret=%s"%( str(_gw_txt) ))
                    continue
                
            def getKey(_item):
                return _item[2]
            _tmp_gw_list.sort(key=getKey)
            return _tmp_gw_list
        except Exception, e:
            _error("Fail to Get GW-Info, cmd=%s, ret=%s, out=%s, exc=%s"%( _cmd, str(_res), str(_ret), str(e) ))
            _except(e)
            return None
    except Exception, e:
        _error("Fail to Run CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return None

def get_def_gw_info(_vnf_ip):
    '''
    return : None, None, None or (dev, ip, metric)
    '''
    _gw_list = get_gw_info(_vnf_ip)
    if _gw_list == None or len(_gw_list) < 1 :
        return None, None, None
    else:
        return _gw_list[0]

def _get_public_ip_list(_vnf_ip):
    '''
    return : [(NIC, IP, MASK)] or List
    '''
    _ip_list = []
    for _nic in _P_NICS :
        _ip, _mask = get_ip(_vnf_ip, _nic)
        if _ip == None :
            continue
        
        _ip_list.append(( _nic, _ip, _mask ))
    
    return _ip_list

def get_ip(_vnf_ip, _nic):
    '''
    return : (IP, MASK) or None, None
    '''
    if str(_nic).strip() == "" :
        _error("Fail to Get IP, No Nic")
        return None, None
    
    _cmd = """ ifconfig %s | grep 'inet addr' | awk '{print $2":"$4}' | awk -F ":" '{print $2","$4}' """%str(_nic)
    try:
        _res, _ret = ssh_cmd(_vnf_ip, _cmd)
        if str(_ret).find("Device not found") > 0 :
            return None, None
        
        if not _res or str(_ret) == "" :
            _warn("Fail to Get IP, cmd=%s, ret=%s, out=%s"%( _cmd, _res, _ret ))
            return None, None
        
        _ip, _mask = str(_ret).split(",")
        try:
            IPv4Network("%s/%s"%( _ip, _mask ))
        except Exception, e:
            _warn("Fail to Get IP, Invalid Value, ip=%s, exc=%s"%(_ret, str(e)))
            return None, None
        return str(_ip).strip(), str(_mask).strip()
    except Exception, e:
        _warn("Fail to Run CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        return None, None
    
def get_main_public_ip(_vnf_ip):
    '''
    return : (None, None, None, None) or (nic, ip, mask, gw)
    '''
    _ip_list = _get_public_ip_list(_vnf_ip)
    if len(_ip_list) < 1 :
        return None, None, None, None
    
    _def_gw_dev, _def_gw_ip, _def_gw_metric = get_def_gw_info(_vnf_ip)
    if _def_gw_ip == None or _def_gw_dev == None :
        return _ip_list[0][0], _ip_list[0][1], _ip_list[0][2], None
    
    for _ip_info in _ip_list :
        if _ip_info[0] == _def_gw_dev :
            return _ip_info[0], _ip_info[1], _ip_info[2], _def_gw_ip
    
    return _ip_list[0][0], _ip_list[0][1], _ip_list[0][2], None

def _ping(_vnf_ip, _ip, _try=1, _wait=1):
    _cmd = """ ping -c %d -w %d %s | grep 'received' | awk '{print $4}' """%( _try, _wait, str(_ip) )
    try:
        _res, _ret = ssh_cmd(_vnf_ip, _cmd)
        try:
            _ret = int(_ret)
            if _ret > 0 :
                return True
            else:
                return False
        except (ValueError, TypeError) as e:
            _error("Fail to Ping, cmd=%s, ret=%s, out=%s"%( _cmd, _res, _ret ))
            return False
    except Exception, e:
        _error("Fail to Run Ping-CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return False

def _arping(_vnf_ip, _ip, _dev, _try=1, _wait=3):
    _cmd = """ arping -c %d -w %d -I %s %s | grep 'Received' | awk '{print $2}' """%( 
                                        _try, _wait, _dev, _ip )
    try:
        _res, _ret = ssh_cmd(_vnf_ip, _cmd)
        try:
            _ret = int(_ret)
            if _ret > 0 :
                return True
            else:
                return False
        except (ValueError, TypeError) as e:
            _error("Fail to ARPing, cmd=%s, ret=%s, out=%s"%( str(_cmd), str(_res), str(_ret) ))
            return False
    except Exception, e:
        _error("Fail to Run ARPing-CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return False

def _chk_conn_nc(_vnf_ip, _url, _port, _wait=3):
    _cmd = """ nc -w %d -v -z %s %d > /dev/null 2>/dev/null;echo $? """%( _wait, str(_url), _port )
    try:
        _res, _ret = ssh_cmd(_vnf_ip, _cmd)
        try:
            _ret = int(_ret)
            if _ret == 0 :
                return True
            else:
                return False
        except (ValueError, TypeError) as e:
            _error("Fail to Check NC-Conn, cmd=%s, ret=%s, out=%s"%( _cmd, _res, _ret ))
            return False
    except Exception, e:
        _error("Fail to Run NC-Conn-CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return False

def _chk_conn_curl(_vnf_ip, _url, _wait=3):
    _cmd = """ curl -k --connect-timeout %d %s > /dev/null 2>/dev/null; echo $? """%( _wait, str(_url) )
    try:
        _res, _ret = ssh_cmd(_vnf_ip, _cmd)
        try:
            _ret = int(_ret)
            if _ret == 0 :
                return True
            else:
                return False
        except (ValueError, TypeError) as e:
            _error("Fail to Check Curl-Conn, cmd=%s, ret=%s, out=%s"%( _cmd, _res, _ret ))
            return False
    except Exception, e:
        _error("Fail to Run Curl-Conn-CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return False

def _chk_conn_nslookup(_vnf_ip, _url, _wait=3):
    _cmd = """ busybox timeout -t %d nslookup %s | grep -c "%s" """%( _wait, str(_url), str(_url) )
    try:
        _res, _ret = ssh_cmd(_vnf_ip, _cmd)
        try:
            _ret = int(_ret)
            if _ret > 0 :
                return True
            else:
                return False
        except (ValueError, TypeError) as e:
            _error("Fail to Check NsLookUp-Conn, cmd=%s, ret=%s, out=%s"%( _cmd, _res, _ret ))
            return False
    except Exception, e:
        _error("Fail to Run NsLookUp-Conn-CMD, cmd=%s, exc=%s"%( _cmd, str(e) ))
        _except(e)
        return False

def check_conn(_uip, _dns1, _dns2, _url, _port, _murl, _ERR_RET_LIST):
    _chk_fail_list = []
    try:
        # DNS
        if _ping(_uip, _dns1) or _ping(_uip, _dns2) :
            _info("SUCC: Chk-Conn, VNF-DNS-Ping")
            return True, None, _chk_fail_list
        else:
            _warn(" - Fail to Chk-Conn, VNF-DNS-Ping")
            _chk_fail_list.append(_ERR_RET_LIST["DNS_PING"]) # ECD_CHK_CONN_VNF_DNS_PING
        
        # GW: ping, arping
        _def_gw_dev, _def_gw_ip, _def_gw_metric = get_def_gw_info(_uip)
        if _def_gw_dev == None or _def_gw_ip == None :
            _err = "Default VNF-GW-Info Error, info=%s/%s/%s"%( str(_def_gw_dev), str(_def_gw_ip), str(_def_gw_metric) )
            _error("Fail to Chk-Conn, %s"%_err)
            _chk_fail_list.append(_ERR_RET_LIST["NO_GW"]) # ECD_CHK_CONN_VNF_NO_GW
            return False, _err, _chk_fail_list
        
        _def_dev = _def_gw_dev
        _gw_ip = _def_gw_ip
        if _ping(_uip, _gw_ip, 3) :
            _info("SUCC: Chk-Conn, VNF-GW-Ping, vnf_ip=%s, gw=%s"%( str(_uip), str(_gw_ip) ))
            return True, None, _chk_fail_list
        else:
            _warn(" - Fail to Chk-Conn, VNF-GW-Ping, vnf_ip=%s, gw=%s"%( str(_uip), str(_gw_ip) ))
            _chk_fail_list.append(_ERR_RET_LIST["GW_PING"]) # ECD_CHK_CONN_VNF_GW_PING
        
        if _arping(_uip, _gw_ip, _def_dev, 3) :
            _info("SUCC: Chk-Conn, VNF-GW-Arp, vnf_ip=%s, gw=%s"%( str(_uip), str(_gw_ip) ))
            return True, None, _chk_fail_list
        else:
            _warn(" - Fail to Chk-Conn, VNF-GW-Arp, vnf_ip=%s, gw=%s"%( str(_uip), str(_gw_ip) ))
            _chk_fail_list.append(_ERR_RET_LIST["GW_ARPING"]) # ECD_CHK_CONN_VNF_GW_ARPING
        
        # NC 
        if _chk_conn_nc(_uip, _url, _port) :
            _info("SUCC: Chk-Conn, VNF-NC, site=%s"%str(_url))
            return True, None, _chk_fail_list
        else:
            _warn(" - Fail to Chk-Conn, VNF-NC, site=%s"%str(_url))
            _chk_fail_list.append(_ERR_RET_LIST["NC_SITE"]) # ECD_CHK_CONN_VNF_NC_SITE
        
        # Curl ORCH-M
        if _chk_conn_curl(_uip, _murl):
            _info("SUCC: Chk-Conn, VNF-Curl, site=Orch-M")
            return True, None, _chk_fail_list
        else:
            _warn(" - Fail to Chk-Conn, VNF-Curl, site=Orch-M")
            _chk_fail_list.append(_ERR_RET_LIST["CURL_MON"]) # ECD_CHK_CONN_VNF_CURL_MON
        
        # NsLookup 
        if _chk_conn_nslookup(_uip, _url) :
            _info("SUCC: Chk-Conn, VNF-NsLookup, site=%s"%str(_url))
            return True, None, _chk_fail_list
        else:
            _warn(" - Fail to Chk-Conn, VNF-NsLookup, site=%s"%str(_url))
            _chk_fail_list.append(_ERR_RET_LIST["NS_SITE"]) # ECD_CHK_CONN_VNF_NS_SITE
        
        return False, None, _chk_fail_list
    except Exception, e:
        _error("Fail to Chk-Conn, exc=%s, chk_fail_list=%s"%( str(e), _chk_fail_list ))
        _except(e)
        return False, "Exception", _chk_fail_list
        

def to_delinfo_txt(_delInfo):
    if _delInfo == None :
        return True, None
    
    _tab = "     "
    _delInfoTxt = ""
    try:
        ## {"IP": None, "Route": None, "RouteRule": None, "ARP": None}
        
        
        _ip = (_delInfo['IP'] if _delInfo.has_key('IP') else None)
        if _ip != None and len(_ip) > 0 :
            _delInfoTxt += ("## IP :\n")
            for _nic in _ip.keys() :
                _ipInfo = _ip[_nic]
                if _ipInfo.has_key('id') :
                    _delInfoTxt += ( "%s%-5s: DHCP(%s)\n"%(_tab, _nic, _ipInfo['id']) )
                else:
                    _fir = True
                    for _ipAddr in _ipInfo['ip_list'] :
                        if _fir :
                            _delInfoTxt += ( "%s%-5s: %s/%s\n"%(_tab, _nic, _ipAddr['_addr'], _ipAddr['_prefixlen']) )
                            _fir = False
                        else:
                            _delInfoTxt += ( "%s%-5s  %s/%s\n"%(_tab, "", _ipAddr['_addr'], _ipAddr['_prefixlen']) )
        
        _route = (_delInfo['Route'] if _delInfo.has_key('Route') else None)
        if _route != None and len(_route) > 0 :
            _delInfoTxt += ("## Route :\n")
            for _r in _route : 
                _gwInfo = ",".join(_r['_gwList'])
                _delInfoTxt += ( "%stable: %5s, %s/%s >> %s\n"%(_tab, _r['_name'], _r['_destAddr'], _r['_dnetPrefix'], _gwInfo) )
        
        _rule = (_delInfo['RouteRule'] if _delInfo.has_key('RouteRule') else None)
        if _rule != None and len(_rule) > 0 :
            _delInfoTxt += ("## RouteRule :\n")
            for _rr in _rule :
                _delInfoTxt += ( "%stable: %5s, src:%s/%s, dst:%s/%s\n"%(
                                _tab, _rr['_name'], _rr['_addr'], _rr['_fromPrefix'], _rr['_toAddr'], _rr['_toPrefix']) )
        
        _arp = (_delInfo['ARP'] if _delInfo.has_key('ARP') else None)
        if _arp != None and len(_arp) > 0 :
            _delInfoTxt += ("## ARP :\n")
            for _a in _arp :
                _delInfoTxt += ( "%s%s, %s, %s\n"%(_tab, _a['addr'], _a['lladdr'], _a['ifname']) )
        
        if _delInfoTxt.strip() == "" :
            return True, None
        
        return True, _delInfoTxt
    except Exception, e:
        _error("Fail to Convert DelInfo to Text, exc=%s, progTxt=%s"%( str(e), _delInfoTxt ))
        _except(e)
        return False, None


def backup(_backupFile, _ip, _crt=C_Crt, _key=C_Key):
    _url = _URL_VNFM_BACKUP
    _body = {"vnf_name":V_TYPE, "local_mgmt_ip":_ip, "type":"local_all"}
    _cCrt = "/var/onebox/key/client.crt"
    _cKey = "/var/onebox/key/client.key"
    try:
        _ret = callAPI(_url, "POST", header=HEADER_VNFM, reqBody=_body, _to=60, cCrt=_crt, cKey=_key, sTime=1)
        
        if _ret == None or not _ret.has_key('local_location') :
            _error("Fail to Backup KT-VNF, ret=%s"%str(_ret))
            return False, "Invalid Return"
        with open(_backupFile, 'w') as f:
            f.write(str(_ret['local_location']))
        return True, None
    except Exception, e:
        _error("Fail to Backup KT-VNF, exc=%s"%str(e))
        _except(e)
        return False, "Exception Occur"


def _chk_ip_chg_api(_vnf_ip, _vnf_id=None, _vnf_pass=None, _login=True):
    login(_vnf_ip, _vnf_id, _vnf_pass)
    
    _url = _URL_MOD_IP%(_vnf_ip)
    _ret = callAPI(_url, "GET")
    if type(_ret) == dict and _ret.has_key('success') :
        return True
    else:
        _error("Fail to Check IP-CHG-API, res=%s"%str(_ret))
        return False

def chk_vnf_bridge(_vnf_ip, _wnic_list, _lan_nic=None, _vnf_id=None):
    '''
    return : True/False, if list, error-msg
    '''
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    try:
        _url = _URL_BR%( _vnf_ip, _vnf_id )
        _ret = callAPI(_url, "GET")
        if _ret == None or not _ret.has_key('data') :
            _error("Fail to Chk VNF-Bridge, Invalid Return, ret=%s"%( str(_ret)))
            return False, None, "Invalid Return"
        _debug("SUCC: Get VNF-Bridge, data=%s"%( str(_ret['data']) ))
        
        _ifs = []
        for _brInfo in _ret['data'] :
            ## bridge info
            if _brInfo.has_key('_ports') :
                _has_lan = False
                _has_wan = False
                _wan_ifs = []
                for _portInfo in _brInfo['_ports'] :
                    ## bridge port info
                    if _portInfo.has_key('_ifname') :
                        __chk_nic = str(_portInfo['_ifname']).strip()
                        if _lan_nic != None and __chk_nic == _lan_nic :
                            _has_lan = True
                        if __chk_nic in _wnic_list :
                            _has_wan = True
                            _info(" - Bridge ON, port=%s"%( str(_portInfo) ))
                            if _lan_nic == None : _ifs.append(__chk_nic)
                            else: _wan_ifs.append(__chk_nic)
                    else:
                        _warn(" - No Bridge's Port IFName, port=%s"%str(_portInfo) )
                if _has_lan and _has_wan :
                    _ifs += _wan_ifs
            else:
                _warn(" - No Bridge's Ports Info, br=%s"%str(_brInfo))
        return True, _ifs, None
    except Exception, e:
        _error("Fail to Check VNF-Bridge, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

def chk_vnf_openvpn(_vnf_ip, _vnf_id, _wnic_list):
    '''
    return : True/False, if list/error-msg
    '''
    try:
        ### VPN 조회
        _url = _URL_OPENVPN%( _vnf_ip, _vnf_id )
        _ret = callAPI(_url, "GET")
        if _ret == None or not _ret.has_key('data') :
            _error("Fail to Chk VNF-OpenVPN, Invalid Return, ret=%s"%( str(_ret) ))
            return False, None, "Invalid Return"
        _debug(" - Get VNF-OpenVPN, data=%s"%( str(_ret['data']) ))
        
        _ifs = []
        for _vpnInfo in _ret['data'] : 
            if _vpnInfo.has_key('localinterface') :
                for _wanNic in _wnic_list :
                    _cmp = str(_wanNic) + "_"
                    if str(_vpnInfo['localinterface']).strip().find(_cmp) > -1 :
                        _info(" - OpenVPN ON, port=%s"%( str(_vpnInfo)) )
                        _ifs.append(_wanNic)
            else:
                _warn(" - No OpenVPN's IF, vpn=%s"%str(_vpnInfo))
        return True, _ifs, None
    except Exception, e:
        _error("Fail to Check VNF-OpenVPN, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

def chk_vnf_qos(_vnf_ip, _vnf_id, _wnic_list):
    '''
    return : True/False, if list/error-msg
    '''
    try:
        _url = _URL_QOS_IF%( _vnf_ip, _vnf_id )
        _ret = callAPI(_url, "GET")
        if _ret == None or (not _ret.has_key('links') and not _ret.has_key('lnks')) :
            _error("Fail to Chk VNF-QoS, Invalid Return, ret=%s"%( str(_ret) ))
            return False, None, "Invalid Return"
        _link = (_ret['links'] if _ret.has_key('links') else _ret['lnks'])
        _debug(" - Get VNF-QoS, data=%s"%( str(_link) ))
        
        _ifs = []
        for _qosInfo in _link :
            if _qosInfo.has_key('text') :
                __chk_nic = str(_qosInfo['text']).strip()
                if __chk_nic in _wnic_list :
                    _info(" - QoS ON, port=%s"%( str(_qosInfo)) )
                    _ifs.append(__chk_nic)
            else:
                _warn(" - No QoS's IF, qos=%s"%str(_qosInfo))
        return True, _ifs, None
    except Exception, e:
        _error("Fail to Check VNF-QoS, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

def _get_vnf_if_id(_vnf_ip, _wnic_list, _vnf_id=None):
    '''
    return : True/False, if-id list, error-msg
    '''
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    try:
        _url = _URL_ETH%( _vnf_ip, _vnf_id )
        _ret = callAPI(_url, "GET")
        if _ret == None or not _ret.has_key('_interface') :
            _error("Fail to Get VNF-IF-ID, Invalid Return, ret=%s"%(str(_ret)))
            return False, None, "Invalid Return"
        
        _info = {}
        for _retInfo in _ret['_interface'] :
            if _retInfo.has_key('name') :
                _get_nic = str(_retInfo['name']).strip()
                if _get_nic in _wnic_list :
                    _info[_get_nic] = str(_retInfo['index'])
        
        if len(_info.keys()) < 1:
            _warn(" - Fail to Get VNF-IF-ID, ret=%s"%str(_ret))
        return True, _info, None
    except Exception, e:
        _error("Fail to Get VNF-IF-ID, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

def _get_vnf_dhcp_id(_vnf_ip, _vnf_id, _wnic_list):
    '''
    return : True/False, dhcp-id list/error-msg
    '''
    try:
        _url = _URL_DHCP%( _vnf_ip, _vnf_id )
        _ret = callAPI(_url, "GET")
        if _ret == None or not _ret.has_key('data') :
            _error("Fail to Get DHCP-ID, Invalid Return, ret=%s"%(str(_ret)))
            return False, None, "Invalid Return"
        
        _info = {}
        for _retInfo in _ret['data'] :
            _get_nic = str(_retInfo['_interface'])
            if _get_nic in _wnic_list :
                _info[_get_nic] = str(_retInfo['_id'])
        
        return True, _info, None
    except Exception, e:
        _error("Fail to Get VNF-DHCP-ID, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

def _get_vnf_if_ipinfo(_vnf_ip, _vnf_id, _wnic_list):
    '''
    return : True/False, if-ip-info list/error-msg
    '''
    try:
        _url = _URL_ETH%( _vnf_ip, _vnf_id )
        _ret = callAPI(_url, "GET")
        if not _ret.has_key('data') :
            _error("Fail to Get VNF-IP-INFO, Invalid Return, ret=%s"%(str(_ret)))
            return False, None, "Invalid Return"
        
        _info = {}
        for _retInfo in _ret['data'] :
            if _retInfo.has_key('_ifname') and str(_retInfo['_ifname']) :
                _get_nic = str(_retInfo['_ifname'])
                if _get_nic in _wnic_list :
                    if _info.has_key(_get_nic) and type(_info[_get_nic]) == list :
                        _info[_get_nic].append({ "_addr":str(_retInfo['_addr']), "_prefixlen": str(_retInfo['_prefixlen']) })
                    else:
                        _info[_get_nic] = [{ "_addr":str(_retInfo['_addr']), "_prefixlen": str(_retInfo['_prefixlen']) }]
        
        return True, _info, None
    except Exception, e:
        _error("Fail to Get VNF-IP-INFO, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

def _get_vnf_route_map(_vnf_ip, _vnf_id=None):
    '''
    return : True/False, route-map-id list, error-msg
    '''
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    try:
        _url = _URL_ROUTE_MAP%( _vnf_ip, _vnf_id )
        _ret = callAPI(_url, "GET")
        if _ret == None or not _ret.has_key('map') :
            _error("Fail to Get VNF-ROUTE-MAP, Invalid Return, ret=%s"%(str(_ret)))
            return False, None, "Invalid Return"
        
        _info = {}
        for _retInfo in _ret['map'] :
            if _retInfo.has_key('_name') or str(_retInfo['_name']).strip() != "" :
                _rmName = str(_retInfo['_name'])
                _rmNum = str(_retInfo['_value'])
                _info[_rmName] = _rmNum
        
        return True, _info, None
    except Exception, e:
        _error("Fail to Get VNF-ROUTE-MAP, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

def _get_vnf_route_info(_vnf_ip, _mapName, _vnf_id=None):
    '''
    return : True/False, route-info list/error-msg
    '''
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    try:
        _url = _URL_ROUTE%( _vnf_ip, _mapName, _vnf_id )
        _ret = callAPI(_url, "GET")
        if _ret == None or not _ret.has_key('data') :
            _error("Fail to Get VNF-ROUTE-INFO, Invalid Return, ret=%s"%(str(_ret)))
            return False, None, "Invalid Return"
        
        return True, _ret['data'], None
    except Exception, e:
        _error("Fail to Get VNF-ROUTE-INFO, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

def get_vnf_all_route_info(_vnf_ip, _wan_nic_list, _static_gw_list=None, _chkExist=None, _vnf_id=None):
    '''
    return : True/False, all-route-info list/error-msg
    '''
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    try:
        _ret, _rmap, _err = _get_vnf_route_map(_vnf_ip, _vnf_id)
        if not _ret :
            _error("Fail to Get VNF-ALL-ROUTE, RouteMap Get Error, ret=%s"%(str(_err)))
            return False, None, "RouteMap Get Error, err=%s"%str(_err)
        
        _defRouteTable = []
        _usrRouteTable = []
        for _rmName in _rmap.keys():
            _ret, _rList, _err = _get_vnf_route_info(_vnf_ip, _rmName, _vnf_id)
            if not _ret :
                _error("Fail to Get VNF-ALL-ROUTE, Route Get Error, err=%s"%(str(_err)))
                return False, None, "Route Get Error, err=%s"%str(_err)
            
            for _rInfo in _rList :
                _name = str(_rInfo['_name'])
                _destAddr = str(_rInfo['_destAddr'])
                _dnetmask = str(_rInfo['_destPrefix'])
                _dnetPrefix = str(_rInfo['_dstPrefix'])
                _metric = str(_rInfo['_metric'])
                _gwList = str(_rInfo['_gwlist']).split(',')
                _tbNum = str(_rmap[_rmName])
                
                _gwLen = len(_gwList)
                for _gwInfo in _gwList :
                    _gIP, _gIF = str(_gwInfo).split('/')
                    if _gIF in _wan_nic_list :
                        _route = { "_name":_name, "_destAddr": _destAddr, '_gwList':_gwList, "_dnetmask": _dnetmask, 
                                  "_metric": _metric, "_dnetPrefix":_dnetPrefix, "_tbNum": _tbNum }
                        # default GW
                        if _gwLen == 1 and _destAddr == "0.0.0.0" :
                            _staticGW = (lambda x: x[_gIF]['gw'] if _static_gw_list != None and x.has_key(_gIF) else None)(_static_gw_list)
                            # dhcp def GW
                            if _staticGW == None :
                                _defRouteTable.append(_route)
                                if type(_chkExist) == list and _gIF in _chkExist : _chkExist.remove(_gIF)
                                break
                            # static def gw
                            elif str(_gIP) == str(_staticGW) :
                                _defRouteTable.append(_route)
                                if type(_chkExist) == list and _gIF in _chkExist : _chkExist.remove(_gIF)
                                break
                            _warn("     User-Default Route, gIP=%s, prevGIP=%s"%(_gIP, _staticGW) )
                        # user GW
                        _warn("     User Route, _gw=%s, dstAddr=%s"%( str(_gwList), str(_destAddr)) )
                        _usrRouteTable.append(_route)
                        break
        
        return True, {'def':_defRouteTable, 'usr':_usrRouteTable}, None
    except Exception, e:
        _error("Fail to Get VNF-ROUTE-INFO, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)


def _get_vnf_route_rule(_vnf_ip, _vnf_id, _wnic_list):
    '''
    return : True/False, route-rule list/error-msg
    '''
    try:
        _url = _URL_ROUTE_RULE%( _vnf_ip, _vnf_id )
        _ret = callAPI(_url, "GET")
        if _ret == None or not _ret.has_key('data') :
            _error("Fail to Get VNF-ROUTE-RULE, Invalid Return, ret=%s"%(str(_ret)))
            return False, None, "Invalid Return"
        
        _info = []
        for _rule in _ret['data'] :
            if str(_rule['_inputIf']) in _wnic_list :
                _info.append(_rule)
        
        return True, _info, None
    except Exception, e:
        _error("Fail to Get VNF-ROUTE-RULE, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

def _get_vnf_arp(_vnf_ip, _wnic_list):
    '''
    return : True/False, arp list/error-msg
    '''
    try:
        ## 'eth5"\|eth1"'
        _ifList = '"\|'.join(_wnic_list) + '"'
        _cmd = """cat /turtle/etc/conf/netconfig.xml | grep neighbor | grep '%s' | awk '{print $2","$3","$4}'"""%(_ifList)
        
        _res, _ret = ssh_cmd( _vnf_ip, _cmd)
        if not _res :
            _error("Fail to Get VNF-ARP, Invalid Return, ret=%s"%(str(_ret)))
            return False, None, "Invalid Return"
        
        # ifname="eth5",addr="211.224.203.123",hwaddr="00:12:20:12:32:11"/>
        # ifname="eth1",addr="175.213.170.3",hwaddr="01:22:33:44:55:12"/>
        _info = {}
        for _arpInfoTxt in str(_ret).split() :
            _arpInfo = str(_arpInfoTxt).replace("/>", "").split(",")
            if len(_arpInfo) != 3 :
                _error("Fail to Get VNF-ARP, Invalid Return, ret=%s"%(str(_ret)))
                return False, None, "Invalid Return"
            
            _ifName = str(_arpInfo[0]).replace('"', "").split('=')
            if len(_ifName) != 2 or str(_ifName[1]).strip() == "" :
                _error("Fail to Get VNF-ARP, Invalid IFName, ret=%s"%(str(_ret)))
                return False, None, "Invalid IFName"
            _ifName = str(_ifName[1]).strip()
            
            _ifAddr = str(_arpInfo[1]).replace('"', "").split('=')
            if len(_ifAddr) != 2 or str(_ifAddr[1]).strip() == "" :
                _error("Fail to Get VNF-ARP, Invalid IFAddr, ret=%s"%(str(_ret)))
                return False, None, "Invalid IFAddr"
            _ifAddr = str(_ifAddr[1]).strip()
            
            _mac = str(_arpInfo[2]).replace('"', "").split('=')
            if len(_mac) != 2 or str(_mac[1]).strip() == "" :
                _error("Fail to Get VNF-ARP, Invalid MacAddr, ret=%s"%(str(_ret)))
                return False, None, "Invalid MacAddr"
            _mac = str(_mac[1]).strip()
            
            if _info.has_key(_ifName) and type(_info[_ifName]) == list :
                _info[_ifName].append({"addr": _ifAddr, "lladdr": _mac})
            else:
                _info[_ifName] = [{"addr": _ifAddr, "lladdr": _mac}]
        return True, _info, None
    except Exception, e:
        _error("Fail to Get VNF-ARP, exc=%s"%str(e))
        _except(e)
        return False, None, str(e)

def add_vnf_ip(_vnf_ip, _is_dhcp, _host_br, _ip=None, _mask=None, _mac=None, _vnf_id=None):
    '''
    return : True/False, error-msg
    '''
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    try:
        _utm_nic = get_nic(_host_br)
        if _utm_nic == None :
            _error("Fail to Add VNF-IP, NIC Convert Error, br=%s"%str(_host_br))
            return False, "NIC Convert Error, br=%s"%str(_host_br)
        
        if _is_dhcp :
            _url = _URL_ADD_DHCP%( _vnf_ip )
            _dhcp_name = _get_dhcp_name(_host_br)
            if _dhcp_name == None :
                _error("Fail to Add VNF-IP, DHCP-NAME Convert Error, br=%s"%str(_host_br))
                return False, "DHCP-NAME Convert Error, br=%s"%str(_host_br)
            if _mac == None :
                _body = "_name=%s&_interface=%s&_mode=1&_identi=2&User=%s"%(_dhcp_name, _utm_nic, _vnf_id )
            else:
                _body = "_name=%s&_interface=%s&_mode=1&_identi=1&_inIdenti=%s&User=%s"%(_dhcp_name, _utm_nic, str(_mac), _vnf_id )
        else:
            _ret, _if_ids, _err = _get_vnf_if_id(_vnf_ip, [_utm_nic], _vnf_id)
            if not _ret or type(_if_ids) != dict or not _if_ids.has_key(_utm_nic) or _if_ids[_utm_nic] == None or str(_if_ids[_utm_nic]).strip() == "" :
                _error("Fail to Add VNF-IP, VNF-IF-ID Get Error, br=%s, vnf-nic=%s, err=%s, ret=%s"%( str(_host_br), str(_utm_nic), str(_err), str(_if_ids) ))
                return False, "VNF-IF-ID Get Error, br=%s, vnf-nic=%s"%( str(_host_br), str(_utm_nic) )
            _if_id = _if_ids[_utm_nic]
            try:
                _mask = IPv4Network("%s/%s"%( _ip, _mask ))._prefixlen
            except Exception, e:
                _error("Fail to Add VNF-IP, Invalid IP Info, ip=%s, mask=%s"%( str(_ip), str(_mask) ))
                return False, "Invalid IP Info, ip=%s, mask=%s"%( str(_ip), str(_mask) )
            
            _url = _URL_ADD_EHT%( _vnf_ip )
            _body = "interface=%s&_ipAddr=%s&_netmask=%s&User=%s"%( 
                    str(_if_id), str(_ip), str(_mask), _vnf_id )
        
        _ret = callAPI(_url, "POST", reqBody=_body)
        if _ret == None or not _ret.has_key('success') or not _ret['success'] :
            _error("Fail to Add VNF-IP, Invalid API Return, ret=%s, body=%s"%( str(_ret), str(_body) ))
            return False, "Invalid API Return"
        
        return True, None
    except Exception, e:
        _error("Fail to Add VNF-IP, exc=%s"%str(e))
        _except(e)
        return False, str(e)

def add_vnf_route(_vnf_ip, _is_dhcp, _host_br, _gw=None, _table=None, _metric=None, _vnf_id=None):
    '''
    return : True/False, error-msg
    '''
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    try:
        _table = ( "main" if _table == None else _table )
        _gw = ( "0.0.0.0" if _is_dhcp else _gw)
        _nic = get_nic(_host_br)
        _metric = ( "0" if _metric == None else _metric )
        
        _tbNum = 254
        if _table == None or str(_table).strip() == "" :
            _error("Fail to Add VNF-ROUTE, No Table Name")
            return False, "No Table Name"
        
        _ret, _map, _err = _get_vnf_route_map(_vnf_ip, _vnf_id)
        if not _ret or type(_map) != dict or not _map.has_key(_table) or _map[_table] == None or str(_map[_table]).strip() == "" :
            _error("Fail to Add VNF-ROUTE, Table-ID Get Error, table=%s, err=%s"%( str(_table), _err ))
            return False, "Table-ID Get Error, table=%s"%str(_table)
        _tbNum = _map[_table]
        
        try:
            IPv4Network(_gw)
        except Exception, e:
            _error("Fail to Add VNF-ROUTE, Invalid GW, gw=%s"%( str(_gw) ))
            return False, "Invalid GW, gw=%s"%( str(_gw) )
        
        if _nic == None :
            _error("Fail to Add VNF-ROUTE, NIC Convert Error, br=%s"%str(_host_br))
            return False, "NIC Convert Error, br=%s"%str(_host_br)
        
        _url = _URL_ADD_ROUTE%( _vnf_ip )
        _body = "_tablename=%s&_nthop=1&_multitext=%s/%s/1;_dnetmask=0&_value=%s&_monitoring=0&_metric=%s&_destAddr=0.0.0.0&_range=1&User=%s"%(
                _table, _gw, _nic, str(_tbNum), str(_metric), _vnf_id )
        
        try:
            int(_metric)
        except Exception, e:
            _error("Fail to Add VNF-ROUTE, Invalid Metric, metric=%s"%( str(_metric) ))
            return False, "Invalid Metric, metric=%s"%( str(_metric) )
        
        _ret = callAPI(_url, "POST", reqBody=_body)
        if _ret == None or not _ret.has_key('success') or not _ret['success'] :
            _error("Fail to Add VNF-ROUTE, Invalid API Return, ret=%s, body=%s"%( str(_ret), str(_body) ))
            return False, "Invalid API Return"
        
        return True, None
    except Exception, e:
        _error("Fail to Add VNF-ROUTE, exc=%s"%str(e))
        _except(e)
        return False, str(e)

def del_vnf_route(_vnf_ip, _route, _vnf_id=None):
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    try:
        _url = _URL_DEL_ROUTE%str(_vnf_ip)
        __ifParam = []
        for __tmp in _route['_gwList'] :
            __ifParam.append(str(__tmp).split('/')[1])
        _ifParam = "<div></div>".join(__ifParam)
        _body = "_name=%s&_value=%s&_destAddr=%s&_dnetmask=%s&_metric=%s&_interface=%s&User=%s"%( 
                str(_route['_name']), str(_route['_tbNum']), str(_route['_destAddr']), 
                str(_route['_dnetmask']), str(_route['_metric']), str(_ifParam), _vnf_id )
        
        _ret = callAPI(_url, "POST", reqBody=_body)
        if _ret == None or not _ret.has_key('success') or not _ret['success'] :
            _error(" - Fail to Delete VNF-ROUTE, ret=%s, url=%s body=%s"%(str(_ret), _url, _body))
            return False, "Invalid Route-Del Result"
        _debug(" - Route-Del Body=%s"%( _body ))
        return True, None
    except Exception, e:
        _error("Fail to Delete VNF-ROUTE, exc=%s"%str(e))
        _except(e)
        return False, str(e)

def del_vnf_all_route(_vnf_ip, _route_list, _vnf_id=None):
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    try:
        for _route in _route_list :
            _ret, _err = del_vnf_route(_vnf_ip, _route, _vnf_id)
            if _ret == None or not _ret.has_key('success') or not _ret['success'] :
                return False, _err
        
        _info("SUCC: Deleted VNF-ALL-Route=%s"%( str(_route_list) ))
        return True, None
    except Exception, e:
        _error("Fail to Delete VNF-ALL-ROUTE, exc=%s"%str(e))
        _except(e)
        return False, str(e)

def mod_vnf_route(_vnf_ip, _tname, _tnum, _gw_ip, _nic, _metric=None, _vnf_id=None):
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    _metric = ("0" if _metric == None else _metric)
    try:
        _url = _URL_MOD_ROUTE%( _vnf_ip )
        _body = "_tablename=%s&_nthop=1&_multitext=%s/%s/1;_dnetmask=0&_value=%s&_monitoring=0&_destAddr=0.0.0.0&_range=1&_metric=%s&User=%s"%(
                    str(_tname), str(_gw_ip), str(_nic), str(_tnum), str(_metric), str(_vnf_id) )
        
        try:
            IPv4Network(_gw_ip)
        except Exception, e:
            _error("Fail to Modify VNF-ROUTE, Invalid GW-IP, gw=%s"%( str(_gw_ip) ))
            return False, "Invalid GW-IP, gw=%s"%( str(_gw_ip) )
        try:
            int(_metric)
        except Exception, e:
            _error("Fail to Modify VNF-ROUTE, Invalid Metric, metric=%s"%( str(_metric) ))
            return False, "Invalid Metric, metric=%s"%( str(_metric) )
        
        _ret = callAPI(_url, "POST", reqBody=_body)
        if _ret == None or not _ret.has_key('success') or not _ret['success'] :
            _error("Fail to Modify VNF-ROUTE, Invalid API Return, ret=%s, body=%s"%( str(_ret), str(_body) ))
            return False, "Invalid API Return"
        
        return True, None
    except Exception, e:
        _error("Fail to Modify VNF-ROUTE, exc=%s"%str(e))
        _except(e)
        return False, str(e)

def del_unuse_if(_vnf_ip, _dhcp_if_list, _vnf_id=None):
    return del_dhcp_if(_vnf_ip, _dhcp_if_list, _vnf_id)

def del_dhcp_if(_vnf_ip, _dhcp_if_list, _vnf_id=None):
    _vnf_id = (DEF_ID if _vnf_id == None else _vnf_id)
    _recover = False
    try:
        _ret, _dhcp_id, _err = _get_vnf_dhcp_id(_vnf_ip, _vnf_id, _dhcp_if_list)
        if not _ret or type(_dhcp_id) != dict :
            _error("Fail to Del VNF-DHCP-IFs, IF-ID Get Error, if-list=%s, ret=%s, err=%s"%( str(_dhcp_if_list), str(_dhcp_id), str(_err) ))
            return False, _recover, "IF-ID Get Error, err=%s"%str(_err)
        
        _url = _URL_DEL_DHCP%str(_vnf_ip)
        for _dhcp_if in _dhcp_if_list :
            if not _dhcp_id.has_key(_dhcp_if) :
                _warn(" - Fail to Del VNF-DHCP-IFs, No IF-ID, if=%s, if-id=%s"%( str(_dhcp_if), str(_dhcp_id) ))
                continue
            
            _nid = _dhcp_id[_dhcp_if]
            _body = "DeleteID=%s&User=%s"%(_nid, _vnf_id)
            _recover = True
            _ret = callAPI(_url, "POST", reqBody=_body)
            if type(_ret) != dict or not _ret.has_key('success') :
                _error("Fail to Del VNF-DHCP-IFs, Invalid DHCP-Del Return, ret=%s, body=%s"%( str(_ret), _body))
                return False, _recover, "Invalid DHCP-Del Result, if=%s"%str(_dhcp_if)
            if not _ret['success'] :
                _warn(" - Fail to Del VNF-DHCP-IFs, IF Del Error, if=%s, ret=%s"%( str(_dhcp_if), str(_ret) ))
            else:
                _debug(" - Del DHCP IP, if=%s, Body=%s"%( str(_dhcp_if), _body ))
        
        _info("SUCC: Del VNF-DHCP-IFs, if-list=%s"%( str(_dhcp_if_list) ))
        return True, _recover, None
    except Exception, e:
        _error("Fail to Del VNF-DHCP-IFs, if-list=%s, exc=%s"%( str(_dhcp_if_list), str(e) ))
        _except(e)
        return False, _recover, str(e)


def mod_ip_to_dhcp(_vnf_ip, _nic, _dhcp_name, _mac=None):
    _url = _URL_MOD_IP%_vnf_ip
    _body = "interfaceName=%s&dslName=%s&identflag=%s"%( str(_nic), str(_dhcp_name), "%s" )
    if _mac == None :
        _body = _body%"2"
    else:
        _body = _body%("1&identText=%s"%str(_mac))
    
    _ret = callAPI(_url, "POST", reqBody=_body)
    if type(_ret) != dict or not _ret.has_key('success') :
        _error("Fail to Modify IP(dhcp), Invalid Return, ret=%s"%(str(_ret)))
        return False, "Invalid Return"
    
    if _ret['success'] :
        return True, None
    else:
        return False, "KT-VNF Error"
    

def mod_ip_to_static(_vnf_ip, _nic, _ip, _pfx):
    _url = _URL_MOD_IP%_vnf_ip
    _body = "interfaceName=%s&ipAddr=%s&prefixlen=%s"%( str(_nic), str(_ip), str(_pfx) )
    _ret = callAPI(_url, "POST", reqBody=_body)
    if type(_ret) != dict or not _ret.has_key('success') :
        _error("Fail to Modify IP(static), Invalid Return, ret=%s"%(str(_ret)))
        return False, "Invalid Return"
    
    if _ret['success'] :
        return True, None
    else:
        return False, "KT-VNF Error"


def chk_list_for_new_wan_ip(_vnf_ip, _vnf_id=None, _vnf_pass=None):
    _vnf_id = ( DEF_ID if _vnf_id == None else _vnf_id )
    _vnf_pass = ( DEF_PASS if _vnf_pass == None else _vnf_pass )
    if _chk_ip_chg_api(_vnf_ip, _vnf_id, _vnf_pass, True) :
        return _ChkWanIPChg.ITEM_LIST_WITH_API
    else:
        return _ChkWanIPChg.ITEM_LIST_WITHOUT_API

def create_chk_new_wan_ip(_ip, _wanNicList, _prevStaticWanInfo, _id=None, _pass=None):
    _id = ( DEF_ID if _id == None else _id )
    _pass = ( DEF_PASS if _pass == None else _pass )
    return _ChkWanIPChg(_ip, _wanNicList, _prevStaticWanInfo, _id, _pass)

def run_list_for_new_wan_ip(_vnf_ip, _vnf_id=None, _vnf_pass=None):
    _vnf_id = ( DEF_ID if _vnf_id == None else _vnf_id )
    _vnf_pass = ( DEF_PASS if _vnf_pass == None else _vnf_pass )
    if _chk_ip_chg_api(_vnf_ip, _vnf_id, _vnf_pass, True) :
        return _RunWanIpChg.ITEM_LIST_WITH_API
    else:
        return _RunWanIpChg.ITEM_LIST_WITHOUT_API

def create_run_new_wan_ip(utm_ip, 
                 _bak_file, _tmp_if_file, _tmp_dr_file, _tmp_ur_file, _tmp_rr_file, _tmp_arp_file,
                 newWanInfo, prevStaticWanInfo, utmID=None, utmPass=None):
    if utmID == None :
        utmID = DEF_ID
    if utmPass == None :
        utmPass = DEF_PASS
    return _RunWanIpChg(utm_ip, 
                 _bak_file, _tmp_if_file, _tmp_dr_file, _tmp_ur_file, _tmp_rr_file, _tmp_arp_file,
                 newWanInfo, prevStaticWanInfo, utmID, utmPass)

def chk_list_for_new_lan_ip():
    return _ChkLanIPChg.ITEM_LIST

def create_chk_new_lan_ip(_ip, _lan_nic, _wanNicList=None, _id=None, _pass=None):
    _id = ( DEF_ID if _id == None else _id )
    _pass = ( DEF_PASS if _pass == None else _pass )
    return _ChkLanIPChg(_ip, _lan_nic, _wanNicList, _id, _pass)

def run_list_for_new_lan_ip():
    return _RunLanIpChg.ITEM_LIST

def create_run_new_lan_ip(utm_ip, _bak_file, _new_lan_info, utmID=None, utmPass=None):
    if utmID == None :
        utmID = DEF_ID
    if utmPass == None :
        utmPass = DEF_PASS
    return _RunLanIpChg(utm_ip, _bak_file, _new_lan_info, utmID, utmPass)

def create_vnf_restore(_vnf_ip, _bak_file):
    return _RunRestore(_vnf_ip, _bak_file)


class _IncProg(threading.Thread):
    
    def __init__(self, _progMng, _period, _inc, _max=None):
        threading.Thread.__init__(self)
        
        self._prog = _progMng
        self._run = True
        self._period = _period
        self._inc = _inc
        self._max = _max
    
    def stop(self):
        if not self._run :
            return
        self._run = False
        sleep(self._period+0.2)
    
    def start(self):
        sleep(0.5)
        if not self.isAlive() :
            try:
                threading.Thread.start(self)
            except RuntimeError :
                pass
    
    def run(self):
        while self._run :
            sleep(self._period)
            if not self._run or self._prog.rate() >= 100 :
                break
            try:
                self._prog.inc(self._inc, self._max)
            except Exception:
                pass
    

class _ProgMng(threading.Thread):
    
    ITEM_LIST = []
    PROG_LIST = []
    
    STAT_COMP = 0
    STAT_RUN = 1
    STAT_UNSUPP = 2
    STAT_ROLLBACK = 2
    STAT_ERR = -1
    
    def __init__(self):
        threading.Thread.__init__(self)
        
        self._index = 0
        self._status = self.STAT_RUN
        self._err = None
        self._return = None
        
        self._incprog = None
        self._rollback = False
        self._subtitle = None
    
    def _complete(self):
        if self._incprog != None : self._incprog.stop()
        
        if len(self.PROG_LIST) > self._index :
            self.PROG_LIST[self._index] = 100
        else:
            _warn("  - Invalid Prog Index, prog=%s, idx=%s"%( str(self.PROG_LIST), str(self._index) ))
        
        if len(self.ITEM_LIST) > self._index :
            if len(self.ITEM_LIST) > self._index + 1 :
                self._index += 1
            self._subtitle = self.ITEM_LIST[self._index]
            self._itemprog = self.PROG_LIST[self._index]
        else:
            self._subtitle = "No Item"
            self._itemprog = 0
    
    def _fin_err(self, _err):
        if self._incprog != None : self._incprog.stop()
        if self._rollback :
            self._status = self.STAT_ROLLBACK
        else:
            self._status = self.STAT_ERR
        self._err = str(_err)
        self._return = None
    
    def _fin_ok(self, _return=None):
        if self._incprog != None : self._incprog.stop()
        self._status = self.STAT_COMP
        self._err = None
        self._return = _return
    
    def inc(self, _inc, _max=None):
        if len(self.PROG_LIST) > self._index :
            _now_rate = self.PROG_LIST[self._index]
            if _max == None :
                self.PROG_LIST[self._index] = max(0, min(99, _inc + _now_rate))
            else:
                self.PROG_LIST[self._index] = max(0, min(min(_max, (_now_rate+_inc)), 99))
        else:
            _warn("  - Invalid Prog Index, prog=%s, idx=%s"%( str(self.PROG_LIST), str(self._index) ))
    
    def set_rate(self, _rate):
        if len(self.PROG_LIST) > self._index :
            self.PROG_LIST[self._index] = max(0, min(100, _rate))
        else:
            _warn("  - Invalid Prog Index, prog=%s, idx=%s"%( str(self.PROG_LIST), str(self._index) ))
        
    def rate(self):
        if len(self.PROG_LIST) > self._index :
            return self.PROG_LIST[self._index]
        else:
            _warn("  - Invalid Prog Index, prog=%s, idx=%s"%( str(self.PROG_LIST), str(self._index) ))
            return -1
    
    def get_idx(self):
        return self._index
    
    def item(self):
        if len(self.ITEM_LIST) > self._index :
            return self.ITEM_LIST[self._index]
        else:
            _warn("  - Invalid Prog Index, prog=%s, idx=%s"%( str(self.PROG_LIST), str(self._index) ))
            return "No Item"
    
    def item_list(self):
        return self.ITEM_LIST
    
    def get_info(self):
        return self._status, self.ITEM_LIST, self.PROG_LIST
    
    def result(self):
        return self._status, self._return, self._err
    
    def start_inc(self, _period, _inc, _max=None):
        self._incprog = _IncProg(self, _period, _inc, _max)
        self._incprog.start()
    
    def stop_inc(self):
        if self._incprog != None :
            self._incprog.stop()
            self._incprog = None


class _ChkWanIPChg(_ProgMng):
    
    ITEM_LIST_WITHOUT_API = ["Bridge", "OpenVPN", "QoS", "IP", "RoutingTable Map", "Route", "Route-Rule", "ARP"]
    ITEM_LIST_WITH_API = ['IP-Change API']
    
    PROG_LIST_WITHOUT_API = [0]*len(ITEM_LIST_WITHOUT_API)
    PROG_LIST_WITH_API = [0]*len(ITEM_LIST_WITH_API)
    
    def __init__(self, _ip, _wanNicList, _prevStaticWanInfo, _id=None, _pass=None):
        _ProgMng.__init__(self)
        
        self._ip = _ip
        self._id = (DEF_ID if _id == None else _id)
        self._pass = (DEF_PASS if _pass == None else _pass)
        self._wanNicList = _wanNicList
        self.prevStaticWanInfo = _prevStaticWanInfo
        
        if _chk_ip_chg_api(self._ip, self._id, self._pass):
            self.ITEM_LIST = self.ITEM_LIST_WITH_API
            self.PROG_LIST = self.PROG_LIST_WITH_API
        else:
            self.ITEM_LIST = self.ITEM_LIST_WITHOUT_API
            self.PROG_LIST = self.PROG_LIST_WITHOUT_API
        
        self._subtitle = self.ITEM_LIST[0]
        self._itemprog = self.PROG_LIST[0]
    
    def _fin_unsuppor(self, _unsuppItem):
        if self._incprog != None : self._incprog.stop()
        self._status = self.STAT_UNSUPP
        self._err = _unsuppItem
        self._return = None
    
    
    def run(self):
        _title = "Check For UTM WAN-IP Change"
        
        _delInfo = {"IP": None, "Route": None, "RouteRule": None, "ARP": None}
        
        _unsuppItem = {"bridge":False, "OpenVPN":False, "QoS":False}
        _findUnSupp = False
        try:
            self.set_rate(2)
            if _chk_ip_chg_api(self._ip, self._id, self._pass, True) :
                _debug(" - Check %s"%( self._subtitle ))
                self._complete()
                self._fin_ok(_delInfo)
                return 
            
            _ret = login(self._ip, self._id, self._pass)
            self.set_rate(5)
            if not _ret :
                self._fin_err("KT-VNF Login Error")
                return
            
            ### Bridge 조회
            self.set_rate(10)
            self.start_inc(3, 1)
            _ret, _br_ifs, _err = chk_vnf_bridge(self._ip, self._wanNicList, _vnf_id=self._id)
            if not _ret :
                self._fin_err(_err)
                return
            else:
                if len(_br_ifs) > 0 :
                    _unsuppItem['bridge'] = True
                    _findUnSupp = True
            _debug(" - Check %s, br-if=%s"%( self._subtitle, str(_br_ifs) ))
            self._complete()
            
            
            ### VPN 조회
            self.set_rate(10)
            self.start_inc(3, 1)
            _ret, _vpn_ifs, _err = chk_vnf_openvpn(self._ip, self._id, self._wanNicList)
            if not _ret :
                self._fin_err(_err)
                return
            else:
                if len(_vpn_ifs) > 0 :
                    _unsuppItem['OpenVPN'] = True
                    _findUnSupp = True
            _debug(" - Check %s, vpn-if=%s"%( self._subtitle, str(_vpn_ifs) ))
            self._complete()
            
            
            ### 서비스 품질
            self.set_rate(10)
            self.start_inc(3, 1)
            _ret, _qos_ifs, _err = chk_vnf_qos(self._ip, self._id, self._wanNicList)
            if not _ret :
                self._fin_err(_err)
                return
            else:
                if len(_qos_ifs) > 0 :
                    _unsuppItem['QoS'] = True
                    _findUnSupp = True
            _debug(" - Check %s, qos-if=%s"%( self._subtitle, str(_qos_ifs) ))
            self._complete()
            
            
            _debug(" - SUCC: Check UnSupported Item, item=%s, chk=%s"%( str(_unsuppItem), str(_findUnSupp) ))
            if _findUnSupp :
                self._fin_unsuppor(_unsuppItem)
                return
            
            #### 삭제할 data 조회
            _nicID = {}
            
            ### 기존 Ethernet 조회
            self.set_rate(5)
            
            ## NIC IDX 조회:DHCP->STATIC 시 사용
            self.start_inc(3, 1, 30)
            _ret, _if_idx, _err = _get_vnf_if_id(self._ip, self._wanNicList, self._id)
            if not _ret :
                self._fin_err(_ret)
                return
            
            for _ifName in _if_idx.keys() :
                if _ifName in self._wanNicList :
                    _nicID[_ifName] = {"idx":str(_if_idx[_ifName]), "ip_list":[]}
            _debug(" - Get %s, idxInfo=%s"%(self._subtitle, str(_nicID)))
            self.stop_inc()
            self.set_rate(30)
            
            # xDSL
            self.start_inc(3, 1, 60)
            _ret, _dhcp_id, _err = _get_vnf_dhcp_id(self._ip, self._id, self._wanNicList)
            if not _ret :
                self._fin_err(_ret)
                return
            
            for _ifName in _dhcp_id.keys() :
                if _ifName in self._wanNicList :
                    _nicID[_ifName].update( {"id":_dhcp_id[_ifName]} )
            self.stop_inc()
            self.set_rate(60)
            
            # Ethernet
            self.start_inc(3, 1, 90)
            _ret, _ip_list, _err = _get_vnf_if_ipinfo(self._ip, self._id, self._wanNicList)
            if not _ret :
                self._fin_err(_ret)
                return
            
            for _ifName in _ip_list.keys() :
                if _ifName in self._wanNicList :
                    _nicID[_ifName]['ip_list'] = _ip_list[_ifName]
            self.stop_inc()
            self.set_rate(90)
            
            
            ## 기존 정보 제거: 삭제될 항목만 남김
            self.start_inc(3, 1)
            _delNics = copy.deepcopy(_nicID)
            _nNicList = _delNics.keys()
            _sNicList = self.prevStaticWanInfo.keys()
            for _nNic in _nNicList:
                # static
                if not _delNics[_nNic].has_key('id') and _nNic in _sNicList : 
                    _tmpIPIList = copy.deepcopy(_delNics[_nNic]['ip_list'])
                    for _nNicIPInfo in _tmpIPIList :
                        if self.prevStaticWanInfo[_nNic]['ip'] == _nNicIPInfo['_addr'] :
                            _delNics[_nNic]['ip_list'].remove(_nNicIPInfo)
                    if len(_delNics[_nNic]['ip_list']) < 1 :
                        _delNics.pop(_nNic)
                # dhcp
                elif _delNics[_nNic].has_key('id') and not _nNic in _sNicList :
                    _delNics.pop(_nNic)
            
            _delInfo["IP"] = _delNics
            _debug(" - Get %s, ifID=%s"%( self._subtitle, str(_delNics) ))
            self._complete()
            
            
            ### Routing Table Map 조회
            self.set_rate(10)
            self.start_inc(3, 1)
            
            _ret, _map_list, _err = _get_vnf_route_map(self._ip, self._id)
            if not _ret :
                self._fin_err(_ret)
                return
            
            _debug(" - Get %s, map=%s"%( self._subtitle, str(_map_list) ))
            self._complete()
            
            
            ### Routing Table 조회
            self.set_rate(5)
            self.start_inc(3, 1)
            
            _usrRouteTable = []
            for _mapName in _map_list.keys() :
                _ret, _route_info, _err = _get_vnf_route_info(self._ip, _mapName, self._id)
                if not _ret :
                    self._fin_err(_ret)
                    return
                
                for _prevR in _route_info :
                    _name = str(_prevR['_name'])
                    _destAddr = str(_prevR['_destAddr'])
                    _dnetmask = str(_prevR['_destPrefix'])
                    _dnetPrefix = str(_prevR['_dstPrefix'])
                    _metric = str(_prevR['_metric'])
                    _gwList = str(_prevR['_gwlist']).split(',')
                    _tbNum = str(_map_list[_mapName])
                    
                    _gwLen = len(_gwList)
                    for _gwInfo in _gwList :
                        _gIP, _gIF = str(_gwInfo).split('/')
                        if _gIF in self._wanNicList :
                            _route = { "_name":_name, "_destAddr": _destAddr, '_gwList':_gwList, "_dnetmask": _dnetmask, 
                                      "_metric": _metric, "_dnetPrefix":_dnetPrefix, "_tbNum": _tbNum }
                            # default GW
                            if _gwLen == 1 and _destAddr == "0.0.0.0" :
                                _staticGW = (lambda x: x[_gIF]['gw'] if x.has_key(_gIF) else None)(self.prevStaticWanInfo)
                                # dhcp def GW
                                if _staticGW == None :
                                    break
                                # static def gw
                                elif str(_gIP) == str(_staticGW) :
                                    break
                                _warn(" - User-Default Route, gIP=%s, prevGIP=%s"%(_gIP, _staticGW) )
                            # user GW
                            _warn(" - User Route, _gw=%s, dstAddr=%s"%( str(_gwList), str(_destAddr)) )
                            _usrRouteTable.append(_route)
                            break
            
            _delInfo['Route'] = _usrRouteTable
            _debug(" - Get %s, usr=%s"%( self._subtitle, str(_usrRouteTable) ))
            self._complete()
            
            
            ### Route 규칙 조회
            self.set_rate(10)
            self.start_inc(3, 1)
            
            _ret, _rrule, _err = _get_vnf_route_rule(self._ip, self._id, self._wanNicList)
            if not _ret :
                self._fin_err(_ret)
                return
            
            _delInfo['RouteRule'] = _rrule
            _debug(" - Get %s, rule=%s"%( self._subtitle, str(_rrule) ))
            self._complete()
            
            
            ### ARP 조회
            self.set_rate(5)
            self.start_inc(3, 1)
            
            _ret, _arp, _err = _get_vnf_arp(self._ip, self._wanNicList)
            if not _ret :
                self._fin_err(_ret)
                return
            
            _prevARP = []
            for _ifName in _arp.keys() :
                for _arpInfo in _arp[_ifName] :
                    _ifAddr = _arpInfo['addr']
                    _mac = _arpInfo['lladdr']
                    _prevARP.append({ "ifindex": str(_nicID[_ifName]['idx']), "ifname": _ifName, "addr": _ifAddr, "lladdr": _mac })
            
            _delInfo['ARP'] = _prevARP
            _debug(" - Get %s, arp=%s"%( self._subtitle, str(_prevARP) ))
            self._complete()
            
            
            self._fin_ok(_delInfo)
            return
        except Exception, e:
            _error("Fail to Check for WAN-IP Change, item=%s, exc=%s"%( self._subtitle, str(e) ))
            _except(e)
            self._fin_err(e)
            return






class _RunWanIpChg(_ProgMng):
    
    ITEM_LIST_WITHOUT_API = ["Backup", 
                 "Ethernet Check", "RoutingTable Check", "Route-Rule Check", "ARP Check",
                 "ARP Delete", "Route Delete", "Route-Rule Delete", "IP Delete", 
                 "Daemon Restart",
                 "IP Create", "Default GateWay Create", "Network Object Create"]
    ITEM_LIST_WITH_API = ["Backup", "WAN-IP Change", "WAN-Route Change"]
    
    PROG_LIST_WITHOUT_API = [0]*len(ITEM_LIST_WITHOUT_API)
    PROG_LIST_WITH_API = [0]*len(ITEM_LIST_WITH_API)
    
    def __init__(self, utm_ip, 
                 _bak_file, _tmp_if_file, _tmp_dr_file, _tmp_ur_file, _tmp_rr_file, _tmp_arp_file,
                 newWanInfo, prevStaticWanInfo, utmID=None, utmPass=None):
        _ProgMng.__init__(self)
        
        self._ip = utm_ip
        self._id = (DEF_ID if utmID == None else utmID)
        self._pass = (DEF_PASS if utmPass == None else utmPass)
        self._new_wan_info = []
        self._prev_static_wan = prevStaticWanInfo
        self._bak_file = _bak_file
        self._tmp_if_file = _tmp_if_file
        self._tmp_dr_file = _tmp_dr_file
        self._tmp_ur_file = _tmp_ur_file
        self._tmp_rr_file = _tmp_rr_file
        self._tmp_arp_file = _tmp_arp_file
        
        for _newwan in newWanInfo :
            if _newwan['is_dhcp'] :
                self._new_wan_info.append({"nic":_newwan['nic'], 
                                           "is_dhcp":True, 
                                           "name":_get_dhcp_name(_newwan['nic']),
                                           "mac":_newwan['mac']})
            else:
                self._new_wan_info.append(copy.deepcopy(_newwan))
        
        if _chk_ip_chg_api(self._ip, self._id, self._pass, True) :
            self._has_api = True
            self.ITEM_LIST = self.ITEM_LIST_WITH_API
            self.PROG_LIST = self.PROG_LIST_WITH_API
        else:
            self._has_api = False
            self.ITEM_LIST = self.ITEM_LIST_WITHOUT_API
            self.PROG_LIST = self.PROG_LIST_WITHOUT_API
        
        self._subtitle = self.ITEM_LIST[0]
        self._itemprog = self.PROG_LIST[0]
    
    
    def _chg_ip_without_api(self):
        ## prevStaticWanInfo = {'eth1':{'gw':'175.213.170.1', 'ip':'175.213.170.152'}}
        ## newWanInfo = [ {"nic":"eth1", "is_dhcp":False, "ip":"175.213.170.152", "gw":"175.213.170.1", "subnet":"255.255.255.0"}, 
        ##                 {"nic":"eth5", "is_dhcp":True, "name":"red_dhcp_r1" } ]
        _title = "UTM WAN-IP Chagne"
        _info("Start %s"%_title)
        try:
            ### 1. vnfm에 backup 요청
            self.set_rate(5)
            self.start_inc(3, 1)
            if not os.path.isfile( self._bak_file ) :
                _ret, _err = backup(self._bak_file, self._ip)
                self.set_rate(90)
                if not _ret :
                    self._fin_err(_err)
                    return
                _debug("     Save Backup File, f=%s"%(self._bak_file))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 2. 기존 Ethernet 조회
            ## Login
            self.set_rate(5)
            
            _ret = login(self._ip, self._id, self._pass)
            self.set_rate(10)
            if not _ret :
                self._fin_err("KT-VNF Login Error")
                return
            
            _debug("     Login KT-VNF")
            self.set_rate(15)
            
            wanNic = []
            for _newWanInfo in self._new_wan_info :
                wanNic.append(_newWanInfo['nic'])
            wanNic.sort()
            self.set_rate(20)
            
            _nicID = {}
            ## NIC IDX 조회:DHCP->STATIC 시 사용
            _url = _URL_ETH%(self._ip, self._id)
            _ret = callAPI(_url, "GET")
            self.set_rate(30)
            if _ret == None or not _ret.has_key('_interface') :
                _error(" - Fail to %s, Invalid Ethernet Return, ret=%s"%(self._subtitle, str(_ret)))
                self._fin_err("Invalid Ethernet Data")
                return
            
            for _ifInfo in _ret['_interface'] :
                for _wanNic in wanNic :
                    if _ifInfo.has_key('name') and str(_ifInfo['name']) == _wanNic :
                        _nicID[_wanNic] = {"idx":str(_ifInfo['index']), "ip_list":[]}
                        break
            _debug("     Ethernet Info=%s"%(str(_nicID)))
            self.set_rate(40)
            
            _notFind = copy.deepcopy(wanNic)
            
            # xDSL
            _url = _URL_DHCP%(self._ip, self._id)
            _ret = callAPI(_url, "GET")
            self.set_rate(60)
            if _ret == None or not _ret.has_key('data') :
                _error(" - Fail to %s, Invalid xDSL Return, ret=%s"%(self._subtitle, str(_ret)))
                self._fin_err("Invalid DHCP Data")
                return
            
            for _ifInfo in _ret['data'] :
                for _wanNic in wanNic :
                    if str(_ifInfo['_interface']) == _wanNic :
                        _nicID[_wanNic].update( {"id":str(_ifInfo['_id'])} )
                        if _wanNic in _notFind : _notFind.remove(_wanNic)
                        break
            
            if len(_notFind) > 0 :
                _warn("     Fail to %s(DHCP), No I/F=%s, ret=%s"%(self._subtitle, _notFind, str(_ret)))
            
            # Ethernet
            _url = _URL_ETH%(self._ip, self._id)
            _ret = callAPI(_url, "GET")
            self.set_rate(80)
            if not _ret.has_key('data') :
                _error(" - Fail to %s, Invalid Ethernet Return, ret=%s"%(self._subtitle, str(_ret)))
                self._fin_err("Invalid Ethernet Data")
                return
            
            for _ifInfo in _ret['data'] :
                for _wanNic in wanNic :
                    if _ifInfo.has_key('_ifname') and str(_ifInfo['_ifname']) == _wanNic :
                        _nicID[_wanNic]['ip_list'].append({ "_addr":str(_ifInfo['_addr']), "_prefixlen": str(_ifInfo['_prefixlen']) })
                        if _wanNic in _notFind : _notFind.remove(_wanNic)
            
            if len(_notFind) > 0 :
                _warn("Fail to %s(STATIC), No I/F=%s, ret=%s"%(self._subtitle, _notFind, str(_ret)))
            _debug("     Ethernet ID=%s"%( str(_nicID) ))
            
            ## 삭제할 WAN Ethernet 저장
            ## /var/onebox/tmp/kt_vnf_prev_if.tmp
            self.set_rate(90)
            if len(_nicID) > 0 and not os.path.isfile( self._tmp_if_file ) :
                with open(self._tmp_if_file, 'w') as f:
                    f.write(ruamel.yaml.dump(_nicID, Dumper=ruamel.yaml.RoundTripDumper))
                _info("     Save Tmp If File=%s"%( self._tmp_if_file))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 3. Routing Table 조회
            self.set_rate(5)
            
            ## Routing Table Map 조회
            _url = _URL_ROUTE_MAP%(self._ip, self._id)
            _ret = callAPI(_url, "GET")
            self.set_rate(15)
            if _ret == None or not _ret.has_key('map') :
                _error(" - Fail to %s, Invalid RoutingTable-Map Return, ret=%s"%(self._subtitle, str(_ret)))
                self._fin_err("Invalid RoutingTableMap Data")
                return
            _debug("     RoutingTableMap=%s"%( str(_ret['map']) ))
            
            rMap = _ret
            
            _usrRouteTable = []
            _defRouteTable = []
            _chkDR = copy.deepcopy(wanNic)
            for _routeT in rMap['map'] :
                if not _routeT.has_key('_name') or str(_routeT['_name']).strip() == "" :
                    _error(" - Fail to %s, No RoutingTable Name, ret=%s"%(self._subtitle, str(_routeT)))
                    self._fin_err("No RoutingTable Name")
                    return
                
                _url = _URL_ROUTE%(self._ip, _routeT['_name'], self._id)
                __ret = callAPI(_url, "GET")
                self.inc(5)
                if __ret == None or not __ret.has_key('data') :
                    _error(" - Fail to %s, Invalid RouteTable Return, ret=%s"%(self._subtitle, str(__ret)))
                    self._fin_err("Invalid RouteTable Data")
                    return
                
                for _prevR in __ret['data'] :
                    _name = str(_prevR['_name'])
                    _destAddr = str(_prevR['_destAddr'])
                    _dnetmask = str(_prevR['_destPrefix'])
                    _dnetPrefix = str(_prevR['_dstPrefix'])
                    _metric = str(_prevR['_metric'])
                    _gwList = str(_prevR['_gwlist']).split(',')
                    _tbNum = str(_routeT['_value'])
                    
                    _gwLen = len(_gwList)
                    for _gwInfo in _gwList :
                        _gIP, _gIF = str(_gwInfo).split('/')
                        if _gIF in wanNic :
                            _route = { "_name":_name, "_destAddr": _destAddr, '_gwList':_gwList, "_dnetmask": _dnetmask, 
                                      "_metric": _metric, "_dnetPrefix":_dnetPrefix, "_tbNum": _tbNum }
                            # default GW
                            if _gwLen == 1 and _destAddr == "0.0.0.0" :
                                _staticGW = (lambda x: x[_gIF]['gw'] if x.has_key(_gIF) else None)(self._prev_static_wan)
                                # dhcp def GW
                                if _staticGW == None :
                                    _defRouteTable.append(_route)
                                    if _gIF in _chkDR : _chkDR.remove(_gIF)
                                    break
                                # static def gw
                                elif str(_gIP) == str(_staticGW) :
                                    _defRouteTable.append(_route)
                                    if _gIF in _chkDR : _chkDR.remove(_gIF)
                                    break
                                _warn("     User-Default Route, gIP=%s, prevGIP=%s"%(_gIP, _staticGW) )
                            # user GW
                            _warn("     User Route, _gw=%s, dstAddr=%s"%( str(_gwList), str(_destAddr)) )
                            _usrRouteTable.append(_route)
                            break
            
            _debug("     Def Route=%s, Usr Route=%s"%( str(_defRouteTable), str(_usrRouteTable) ))
            self.inc(5)
            
            ## 기존 GW 정보 저장 : BTA error 용
            ## /var/onebox/tmp/kt_vnf_def_gw.tmp 파일 하나로 관리 : BTA Error 용
            ## 기존에 지워진 GW 정보가 있을 경우 merge 필요 : GW 삭제 후 오동작 가능성 있으므로.
            if not os.path.isfile( self._tmp_dr_file ) :
                if len(_chkDR) > 0 :
                    _error(" - Fail to %s, No Default Route, nic=%s, prevStaticRoute=%s"%(self._subtitle, str(_chkDR), str(self._prev_static_wan)))
                    self._fin_err("No Default Gagteway, %s"%str(_chkDR))
                    return
                
                with open(self._tmp_dr_file, 'w') as f:
                    f.write(ruamel.yaml.dump(_defRouteTable, Dumper=ruamel.yaml.RoundTripDumper))
                _debug("     Save Tmp-Def-Route-File, f=%s"%(self._tmp_dr_file))
            else:
                _sDRList = []
                with open(self._tmp_dr_file, "r") as f:
                    _sDRList = ruamel.yaml.safe_load(f)
                
                for _sDR in _sDRList :
                    for _gwInfo in _sDR['_gwList'] :
                        _gIP, _gIF = str(_gwInfo).split('/')
                        if _gIF in _chkDR : _chkDR.remove(_gIF)
                
                if len(_chkDR) > 0 :
                    _error(" - Fail to %s, No Default Route, nic=%s"%(self._subtitle, str(_chkDR) ))
                    self._fin_err("No Default Gagteway, %s"%str(_chkDR))
                    return
            self.inc(5)
            
            ## 기존 GW 정보 저장 : Orch-F Noti 용
            ## /var/onebox/tmp/kt_vnf_prev_gw.tmp 파일 하나로 관리 : Orch-F 용
            ## 기존에 지워진 GW 정보가 있을 경우 merge 필요 : GW 삭제 후 오동작 가능성 있으므로.
            if not os.path.isfile( self._tmp_ur_file ) and len(_usrRouteTable) > 0 :
                with open(self._tmp_ur_file, 'w') as f:
                    f.write(ruamel.yaml.dump(_usrRouteTable, Dumper=ruamel.yaml.RoundTripDumper))
                _debug("     Save Tmp-Usr-Route-File, f=%s"%(self._tmp_ur_file))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 4. Route 규칙 조회
            self.set_rate(5)
                        
            _prevRule = []
            
            _url = _URL_ROUTE_RULE%(self._ip, self._id)
            _ret = callAPI(_url, "GET")
            self.set_rate(40)
            if _ret == None or not _ret.has_key('data') :
                _error(" - Fail to %s, Invalid Route-Rule Return, ret=%s"%(self._subtitle, str(_ret)))
                self._fin_err("Invalid Route-Rule Data")
                return
            
            for _rule in _ret['data'] :
                if str(_rule['_inputIf']) in wanNic :
                    _prevRule.append(_rule)
            _debug("     Route-Rule=%s"%( str(_prevRule) ))
            self.set_rate(50)
            
            ## Route 규칙 저장
            if len(_prevRule) > 0 and not os.path.isfile( self._tmp_rr_file ) :
                with open(self._tmp_rr_file, 'w') as f:
                    f.write(ruamel.yaml.dump(_prevRule, Dumper=ruamel.yaml.RoundTripDumper))
                
                _debug("     Save Tmp-RouteRule-File, f=%s"%(self._tmp_rr_file))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 5. ARP 조회
            self.set_rate(5)
            
            _prevARP = []
            
            ## 'eth5"\|eth1"'
            _ifList = '"\|'.join(wanNic) + '"'
            _cmd = """cat /turtle/etc/conf/netconfig.xml | grep neighbor | grep '%s' | awk '{print $2","$3","$4}'"""%(_ifList)
            
            _res, _ret = ssh_cmd(self._ip, _cmd)
            self.set_rate(20)
            if not _res :
                _error(" - Fail to %s, Invalid ARP Return, ret=%s"%(self._subtitle, str(_ret)))
                self._fin_err("Invalid ARP Data")
                return
            
            # ifname="eth5",addr="211.224.203.123",hwaddr="00:12:20:12:32:11"/>
            # ifname="eth1",addr="175.213.170.3",hwaddr="01:22:33:44:55:12"/>
            for _arpInfoTxt in str(_ret).split() :
                _arpInfo = str(_arpInfoTxt).replace("/>", "").split(",")
                if len(_arpInfo) != 3 :
                    _error(" - Fail to %s, Invalid ARP Return, ret=%s"%(self._subtitle, str(_arpInfoTxt)))
                    self._fin_err("Invalid ARP Data")
                    return
                
                _ifName = str(_arpInfo[0]).replace('"', "").split('=')
                if len(_ifName) != 2 or str(_ifName[1]).strip() == "" :
                    _error(" - Fail to %s, Invalid IF Name, ret=%s"%(self._subtitle, str(_arpInfo)))
                    self._fin_err("Invalid IF Name")
                    return
                _ifName = str(_ifName[1]).strip()
                
                _ifAddr = str(_arpInfo[1]).replace('"', "").split('=')
                if len(_ifAddr) != 2 or str(_ifAddr[1]).strip() == "" :
                    _error(" - Fail to %s, Invalid IF Addr, ret=%s"%(self._subtitle, str(_arpInfo)))
                    self._fin_err("Invalid IF Addr")
                    return
                _ifAddr = str(_ifAddr[1]).strip()
                
                _mac = str(_arpInfo[2]).replace('"', "").split('=')
                if len(_mac) != 2 or str(_mac[1]).strip() == "" :
                    _error(" - Fail to %s, Invalid Mac Addr, ret=%s"%(self._subtitle, str(_arpInfo)))
                    self._fin_err("Invalid Mac Addr")
                    return
                _mac = str(_mac[1]).strip()
                
                _prevARP.append({ "ifindex": str(_nicID[_ifName]['idx']), "ifname": _ifName, "addr": _ifAddr, "lladdr": _mac })
                self.inc(5)
            _debug("     PrevArp=%s"%( str(_prevARP) ))
            if len(_prevARP) < 1:
                _debug("     No ARP : %s"%str(_ret))
            
            ## ARP 저장
            self.inc(5)
            if len(_prevARP) > 0 and not os.path.isfile( self._tmp_arp_file ) :
                with open(self._tmp_arp_file, 'w') as f:
                    f.write(ruamel.yaml.dump(_prevARP, Dumper=ruamel.yaml.RoundTripDumper))
                
                _debug("     Save Tmp-ARP-File f=%s"%( self._tmp_arp_file))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ###### Delete
            self._rollback = True
            ### 6. ARP 삭제
            self.set_rate(5)
            
            _url = _URL_DEL_ARP%self._ip
            for _arp in _prevARP :
                _body = "DeleteID=%s&IPAddr=%s&MACAddr=%s&User=%s"%( str(_arp['ifindex']), str(_arp['addr']), str(_arp['lladdr']), self._id )
                _ret = callAPI(_url, "POST", reqBody=_body)
                self.inc(5)
                if _ret == None or not _ret.has_key('success') or not _ret['success'] :
                    _error(" - Fail to %s, Invalid ARP-Del Return, ret=%s, body=%s"%(self._subtitle, str(_ret), _body))
                    self._fin_err("Invalid ARP-Del Result")
                    return
                _debug("     ARP-DEL body=%s"%( _body ))
            _debug("     Deleted ARP=%s"%( str(_prevARP) ))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 7. 전체 GW 삭제(WAN NIC만)
            ## _name=main&_destAddr=0.0.0.0&_dnetmask=0.0.0.0&_metric=100
            ## Static 일 경우, 프로비저닝 시 설정한 GW 주소와 같을 경우만 제거
            ## 나머지는 저장 후 orch-f에 전송
            self.set_rate(5)
            
            _url = _URL_DEL_ROUTE%self._ip
            for _route in _defRouteTable + _usrRouteTable :
                
                __ifParam = []
                for __tmp in _route['_gwList'] :
                    __ifParam.append(str(__tmp).split('/')[1])
                _ifParam = "<div></div>".join(__ifParam)
                _body = "_name=%s&_value=%s&_destAddr=%s&_dnetmask=%s&_metric=%s&_interface=%s&User=%s"%( 
                        str(_route['_name']), str(_route['_tbNum']), str(_route['_destAddr']), 
                        str(_route['_dnetmask']), str(_route['_metric']), str(_ifParam), self._id )
                _ret = callAPI(_url, "POST", reqBody=_body)
                self.inc(5)
                if _ret == None or not _ret.has_key('success') or not _ret['success'] :
                    _error(" - Fail to %s, Invalid Route-Del Return, ret=%s, body=%s"%(self._subtitle, str(_ret), _body))
                    self._fin_err("Invalid Route-Del Result")
                    return
                _debug("     Route-Del Body=%s"%( _body ))
            
            _debug("     Deleted Route=%s"%( str(_usrRouteTable+_defRouteTable) ))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 8. Route 규칙 삭제
            self.set_rate(5)
            
            _url = _URL_DEL_ROUTE_RULE%self._ip
            for _prevR in _prevRule :
                _body = "TableName=%s&PrioID=%s&User=%s"%( str(_prevR['_name']), str(_prevR['_priority']), self._id )
                _ret = callAPI(_url, "POST", reqBody=_body)
                self.inc(10)
                if _ret == None or not _ret.has_key('success') or not _ret['success'] :
                    _error(" - Fail to %s, Invalid Route-Rule-Del Return, ret=%s"%(self._subtitle, str(_ret)))
                    self._fin_err("Invalid Route-Rule-Del Result")
                    return
                _debug("     Route-Rule-Del Body=%s"%( _body))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 9. 기존 WAN Ethernet 삭제
            self.set_rate(5)
            
            for _delNic in _nicID.keys() :
                # Ethernet Delete
                if not _nicID[_delNic].has_key('id') :
                    _url = _URL_DEL_ETH%self._ip
                    for _ipaddr in _nicID[_delNic]['ip_list'] :
                        _body = "DeleteID=%s&IPAddr=%s&User=%s"%( str(_nicID[_delNic]['idx']), str(_ipaddr['_addr']), self._id )
                        _ret = callAPI(_url, "POST", reqBody=_body)
                        self.inc(5)
                        if _ret == None or not _ret.has_key('success') or not _ret['success'] :
                            _error(" - Fail to %s(static), Invalid Static-IP-Del Return, ret=%s, body=%s"%(self._subtitle, str(_ret), _body))
                            self._fin_err("Invalid Static-IP-Del Result")
                            return
                        _debug("     Static-IP-Del Body=%s"%( _body ))
                # xDSL Delete
                else:
                    _url = _URL_DEL_DHCP%self._ip
                    _body = "DeleteID=%s&User=%s"%(str(_nicID[_delNic]['id']), self._id)
                    _ret = callAPI(_url, "POST", reqBody=_body)
                    self.inc(5)
                    if _ret == None or not _ret.has_key('success') or not _ret['success'] :
                        _error(" - Fail to %s(dhcp), Invalid DHCP-Del Return, ret=%s, body=%s"%(self._subtitle, str(_ret), _body))
                        self._fin_err("Invalid DHCP-Del Result")
                        return
                    
                    _debug("     DHCP-Del Body=%s"%( _body ))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 10. UTM PM 데몬 재기동 : UTM API 버그 처리 용
            self.set_rate(5)
            
            _cmd = """killall -9 pm"""
            _res, _out = ssh_cmd(self._ip, _cmd)
            self.set_rate(30)
            if not _res or str(_out) != "" :
                _warn("     Fail to %s, cmd=%s, out=%s"%( self._subtitle, _cmd, str(_out) ) )
            else:
                _debug("     Stop PM Daemon")
            
            self.start_inc(1, 1)
            sleep(3)
            self.stop_inc()
            
            _cmd = """/turtle/bin/pm"""
            _res, _out = ssh_cmd(self._ip, _cmd)
            self.set_rate(70)
            if not _res or str(_out) != "" : 
                _warn("     Fail to %s, cmd=%s, out=%s"%( self._subtitle, _cmd, str(_out) ))
            else:
                _debug("     Start PM Daemon")
            
            self.start_inc(1, 1)
            sleep(10)
            self.stop_inc()
            
            ## 재로그인
            if not login(self._ip, self._id, self._pass, _rNum=15) :
                _error(" - Fail to %s, Login Error"%self._subtitle)
                self._fin_err("Login Error")
                return
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 11. 신규 WAN Ethernet 생성
            ## 없으면 에러 리턴
            ## dhcp 일 경우, 순서대로 red_dhcp_r#
            self.set_rate(5)
            
            if os.path.isfile( self._tmp_if_file ) :
                _tIfList = {}
                with open(self._tmp_if_file, "r") as f:
                    _tIfList = ruamel.yaml.safe_load(f)
                
                for _eth in _tIfList.keys() :
                    if not _nicID.has_key(_eth) :
                        _nicID[_eth] = _tIfList[_eth]
            
            self.set_rate(10)
            for _newWanInfo in self._new_wan_info :
                _wanNic = _newWanInfo['nic']
                # Ethernet
                if not _newWanInfo['is_dhcp'] :
                    _wanNetMask = IPv4Network("0.0.0.0/%s"%_newWanInfo['subnet'])._prefixlen
                    _url = _URL_ADD_EHT%self._ip
                    _body = "interface=%s&_ipAddr=%s&_netmask=%s&User=%s"%( 
                            str(_nicID[_wanNic]['idx']), str(_newWanInfo['ip']), 
                            str(_wanNetMask), self._id )
                # xDSL
                else:
                    _url = _URL_ADD_DHCP%self._ip
                    if _newWanInfo['mac'] != None :
                        _body = "_name=%s&_interface=%s&_mode=1&_identi=2&User=%s"%(
                                            str(_newWanInfo['name']), str(_wanNic), self._id )
                    else:
                        _body = "_name=%s&_interface=%s&_mode=1&_identi=1&_inIdenti=%s&User=%s"%(
                                            str(_newWanInfo['name']), str(_wanNic), str(_newWanInfo['mac']), self._id )
                
                self.inc(5)
                _ret = callAPI(_url, "POST", reqBody=_body)
                if _ret == None or not _ret.has_key('success') or not _ret['success'] :
                    _error(" - Fail to %s, Invalid IP-Create Return, ret=%s, body=%s"%(self._subtitle, str(_ret), _body))
                    self._fin_err("Invalid IP-Create Result")
                    return
                
                _debug("     IP-Create Body=%s"%(_body))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 12. Default GW 설정
            ## _tablename=main&_multitext=0.0.0.0/eth5/1;_dnetmask=0&_value=254&_monitoring=1
            ## &_metric=111&_destAddr=0.0.0.0&_range=1
            self.set_rate(5)
            
            _allDRList = copy.deepcopy(_defRouteTable)
            if os.path.isfile( self._tmp_dr_file ) :
                _tmpDRList = []
                with open(self._tmp_dr_file, "r") as f:
                    _tmpDRList = ruamel.yaml.safe_load(f)
                
                _addDR = []
                for _tDR in _tmpDRList :
                    _sameR = False
                    for _pDR in _defRouteTable :
                        if _pDR == _tDR :
                            _sameR = True
                            break
                    
                    if not _sameR :
                        _allDRList.append(_tDR)
            
            self.set_rate(10)
            _url = _URL_ADD_ROUTE%self._ip
            notSetDR = []
            for _tDR in _allDRList :
                notSet = True
                for _newWanInfo in self._new_wan_info :
                    _tDRIP, _tDRIF = str(_tDR['_gwList'][0]).split('/')
                    
                    if _tDRIF == _newWanInfo['nic'] :
                        _gIP = (lambda x : '0.0.0.0' if x['is_dhcp'] else x['gw'])(_newWanInfo)
                        
                        _body = "_tablename=%s&_nthop=1&_multitext=%s/%s/1;_dnetmask=0&_value=%s&_monitoring=0&_metric=%s&_destAddr=0.0.0.0&_range=1&User=%s"%(
                                str(_tDR['_name']), str(_gIP), str(_tDRIF), str(_tDR['_tbNum']), str(_tDR['_metric']), self._id )
                        _ret = callAPI(_url, "POST", reqBody=_body)
                        self.inc(5)
                        if _ret == None or not _ret.has_key('success') or not _ret['success'] :
                            _error(" - Fail to %s, Invalid Def-GW-Create Return, ret=%s, body=%s"%(self._subtitle, str(_ret), _body))
                            self._fin_err("Invalid Def-GW-Create Result")
                            return
                        
                        _debug("     Def-GW-Create Body=%s"%(_body))
                        notSet = False
                        break
                
                if notSet:
                    notSetDR.append(_newWanInfo['nic'])
                    _warn("     Fail to %s, nic=%s"%( self._subtitle, str(_newWanInfo['nic']) ))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 13. WAN 네트워크 객체 설정
            self.set_rate(5)
            
            _GRurl = _URL_OBJ_NET%self._ip
            _SRurl = _URL_MOD_OBJ_NET%self._ip
            for _newWan in self._new_wan_info :
                ## 변경 전후가 모두 static만 처리
                if not _newWan['is_dhcp'] and self._prev_static_wan.has_key(_newWan['nic']):
                    _prevNIP = self._prev_static_wan[_newWan['nic']]['ip']
                    _newNIP = _newWan['ip']
                    ## 조회
                    _body = "_type=1&_addrType=2&_ipv4Addr=%s&User=%s"%( str(_prevNIP), self._id )
                    _ret = callAPI(_GRurl, "POST", reqBody=_body)
                    if _ret == None or not _ret.has_key('children') :
                        _warn("     Fail to %s, Invalid Network-Object-Get Return, ret=%s, body=%s"%(self._subtitle, str(_ret), _body))
                        continue
                    _debug("     Network-Object-Get Ret=%s"%(str(_ret)))
                    
                    ## 변경
                    for _netInfo in _ret['children'] :
                        _sid = str(_netInfo['id'])
                        _uid = _sid
                        try:
                            _uid = str(_netInfo['children'][0]['nid'])
                        except Exception, e:
                            _warn("     Fail to %s, Invalid Network-Object-Get Return, ret=%s, e=%s"%(self._subtitle, str(_netInfo), str(e)))
                            continue
                        _nname = str(_netInfo['name'])
                        _body = "unitId=%s&setId=%s&name=%s&type=1&addrType=2&ipv4Addr=%s&macType=2&macOnly=0&User=%s"%(
                                    str(_uid), str(_sid), str(_nname), str(_newNIP), self._id)
                        _ret = callAPI(_SRurl, "POST", reqBody=_body)
                        if _ret == None or not _ret.has_key('success') or not _ret['success'] :
                            _warn("     Fail to %s, Invalid Network-Object-Mod Return, ret=%s, body=%s"%(self._subtitle, str(_ret), _body))
                            continue
                        _debug("     Network-Object-Mod Body=%s"%(_body))
            
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 임시 Default Route 저장 파일 삭제
            self._subtitle = "Remove Tmp-Def-Route File"
            try:
                if os.path.isfile( self._tmp_dr_file ) and os.path.isabs( self._tmp_dr_file ):
                    os.remove( self._tmp_dr_file )
                    _info(" - Succ: %s, f=%s"%(self._subtitle, self._tmp_dr_file))
            except Exception, e:
                _warn(" - Fail to %s, file=%s"%(self._subtitle, self._tmp_dr_file))
                _except(e)
            
            self._fin_ok()
        except Exception, e:
            _error(" - Fail to %s, exc=%s"%( self._subtitle, str(e) ))
            _except(e)
            self._fin_err("Error Occur")
    
    
    def _chg_ip_with_api(self):
        ## prevStaticWanInfo = {'eth1':{'gw':'175.213.170.1', 'ip':'175.213.170.152'}}
        ## newWanInfo = [ {"nic":"eth1", "is_dhcp":False, "ip":"175.213.170.152", "gw":"175.213.170.1", "subnet":"255.255.255.0"}, 
        ##                 {"nic":"eth5", "is_dhcp":True, "name":"red_dhcp_r1", "mac":"00:00:00:11:11:11" } ]
        _title = "UTM WAN-IP Chagne"
        _info("Start %s"%_title)
        try:
            ### 1. vnfm에 backup 요청
            self.set_rate(5)
            
            self.start_inc(3, 1)
            if not os.path.isfile( self._bak_file ) :
                _ret, _err = backup(self._bak_file, self._ip)
                if not _ret :
                    _error(" - Fail to %s, err=%s"%( self._subtitle, str(_err) ))
                    self._fin_err("KT-VNF Backup Error, err=%s"%str(_err))
                    return
                _debug("     Save Backup File, f=%s"%(self._bak_file))
            
            self.stop_inc()
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 2. IP Change
            ## Login
            self.set_rate(5)
            
            self.start_inc(3, 1)
            _ret = login(self._ip, self._id, self._pass)
            if not _ret :
                _error(" - Fail to %s, Login Error"%( self._subtitle ))
                self._fin_err("KT-VNF Login Error")
                return
            _debug("     Login KT-VNF")
            
            _gw_info = {}
            for _newWanInfo in self._new_wan_info :
                _wnic = _newWanInfo['nic']
                _wnic_dhcp = _newWanInfo['is_dhcp']
                _prev_nic_static = self._prev_static_wan.has_key(_wnic)
                if _wnic_dhcp :
                    # static -> dhcp
                    if _prev_nic_static :
                        self._rollback = True
                        _gw_info[_wnic] = "0.0.0.0"
                        _ret, _err = mod_ip_to_dhcp(self._ip, _wnic, _newWanInfo['name'], _newWanInfo['mac'])
                        if not _ret :
                            _error(" - Fail to %s, err=%s"%( self._subtitle, str(_err) ))
                            self._fin_err("KT-VNF IP Change Error, err=%s"%str(_err))
                            return
                        else:
                            _debug("     Change IP STATIC -> DHCP, VNF-NIC=%s"%str(_wnic))
                    # dhcp -> dhcp
                    else:
                        _debug("     SKIP to IP Change, VNF-NIC=%s, DHCP->DHCP"%str(_wnic))
                        continue
                else:
                    _wnic_ip = _newWanInfo['ip']
                    # static -> static
                    if _prev_nic_static :
                        # same ip
                        # if _wnic_ip == self._prev_static_wan[_wnic]['ip'] :
                        #     _debug("     SKIP to IP Change, VNF-NIC=%s, ip=%s, STATIC->STATIC"%( str(_wnic), _wnic_ip))
                        #     continue
                        if _wnic_ip == self._prev_static_wan[_wnic]['ip'] and \
                                _newWanInfo['gw'] == self._prev_static_wan[_wnic]['gw']:
                            _debug(
                                "     SKIP to IP Change, VNF-NIC=%s, newip=%s, previp=%s, newgw=%s, prevgw=%s "
                                "STATIC->STATIC" % (
                                    str(_wnic), _wnic_ip, self._prev_static_wan[_wnic]['ip'],
                                    _newWanInfo['gw'], self._prev_static_wan[_wnic]['gw']))
                            continue
                    # diff ip
                    # dhcp -> static
                    try:
                        _ip_pfx = IPv4Network("0.0.0.0/%s"%_newWanInfo['subnet']).prefixlen
                        self._rollback = True
                        _gw_info[_wnic] = _newWanInfo['gw']
                        _ret, _err = mod_ip_to_static(self._ip, _wnic, _wnic_ip, _ip_pfx)
                        if not _ret :
                            _error(" - Fail to %s, err=%s"%( self._subtitle, str(_err) ))
                            self._fin_err("KT-VNF IP Change Error, err=%s"%str(_err))
                            return
                        else:
                            _debug("     Change IP to Static, VNF-NIC=%s, ip=%s/%s"%( str(_wnic), str(_wnic_ip), str(_ip_pfx) ))
                    except Exception, e:
                        _error(" - Fail to %s, exc=%s"%( self._subtitle, str(e) ))
                        _except(e)
                        self._fin_err("KT-VNF IP Change Error, IP Check Error, net=%s, err=%s"%( str(_newWanInfo), str(e) ))
                        return
            
            self.stop_inc()
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 3. Route Change
            self.set_rate(5)
            self.start_inc(3, 1)
            
            _ret, _prev_gw_info, _err = get_vnf_all_route_info(self._ip, _gw_info.keys(), self._prev_static_wan)
            if not _ret :
                _error(" - Fail to %s, Rouet Get Error, err=%s"%( self._subtitle, str(_err) ))
                self._fin_err("KT-VNF Route Get Error, err=%s"%( str(_err) ))
                return
            if type(_prev_gw_info) != dict or not _prev_gw_info.has_key('def') :
                _error(" - Fail to %s, Invalid Route Info, ret=%s"%( self._subtitle, str(_prev_gw_info) ))
                self._fin_err("KT-VNF Route Change Error, Invalid Route Info, ret=%s"%( str(_prev_gw_info) ))
                return
            _debug("      Get Default GW: gw=%s"%str(_prev_gw_info['def']))
            
            _def_prev_gw_info = _prev_gw_info['def']
            for _def_prev_gw in _def_prev_gw_info :
                # "_name", "_destAddr", '_gwList', "_dnetmask", 
                # "_metric", "_dnetPrefix", "_tbNum"
                _tname = _def_prev_gw['_name']
                _tnum = _def_prev_gw['_tbNum']
                _metric = _def_prev_gw['_metric']
                _gw_list = _def_prev_gw['_gwList']
                for _gw in _gw_list :
                    _gIP, _gIF = str(_gw).split('/')
                    if _gIF != None and _gw_info.has_key(_gIF) :
                        _new_gw = _gw_info[_gIF]
                        _ret, _err = mod_vnf_route(self._ip, _tname, _tnum, _new_gw, _gIF, _metric)
                        if not _ret :
                            _error(" - Fail to %s, API Return Error, prev_gw_info=%s, err=%s"%( self._subtitle, str(_def_prev_gw), str(_err) ))
                            self._fin_err("KT-VNF Route Change Error, API Return Error, err=%s"%( str(_err) ))
                            return
                        _debug("     Change Route, %s: %s -> %s"%( str(_gIF), str(_gIP), str(_new_gw) ))
                    else:
                        _warn(" - Fail to %s, No GW Info, gw=%s"%( self._subtitle, str(_gw) ))
            
            self.stop_inc()
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            self._fin_ok()
        except Exception, e:
            _error(" - Fail to %s, exc=%s"%( self._subtitle, str(e) ))
            _except(e)
            self._fin_err("Error Occur")
    
    
    def run(self):
        if _chk_ip_chg_api(self._ip, self._id, self._pass, True) :
            self._chg_ip_with_api()
        else:
            self._chg_ip_without_api()


class _ChkLanIPChg(_ProgMng):
    
    ITEM_LIST = ['IP-Change API', "Bridge"]
    
    PROG_LIST = [0]*len(ITEM_LIST)
    
    def __init__(self, _ip, _lan_nic, _wanNicList=None, _id=None, _pass=None):
        _ProgMng.__init__(self)
        
        self._ip = _ip
        self._id = (DEF_ID if _id == None else _id)
        self._pass = (DEF_PASS if _pass == None else _pass)
        self._lan_nic = _lan_nic
        self._wanNicList = (_P_NICS if _wanNicList == None else _wanNicList)
        
        self._subtitle = self.ITEM_LIST[0]
        self._itemprog = self.PROG_LIST[0]
    
    def _fin_unsuppor(self, _unsuppItem):
        if self._incprog != None : self._incprog.stop()
        self._status = self.STAT_UNSUPP
        self._err = _unsuppItem
        self._return = None
    
    
    def run(self):
        _title = "Check For UTM LAN-IP Change"
        
        _unsuppItem = {"bridge":False}
        _findUnSupp = False
        try:
            self.set_rate(2)
            self.start_inc(1, 1)
            if not _chk_ip_chg_api(self._ip, self._id, self._pass, True) :
                _error(" - Fail to Check %s, No API"%( self._subtitle ))
                self._fin_err("No IP-Change API")
                return
            _debug(" - Check %s"%( self._subtitle ))
            self._complete()
            
            _ret = login(self._ip, self._id, self._pass)
            self.set_rate(5)
            if not _ret :
                self._fin_err("KT-VNF Login Error")
                return
            
            
            ### Bridge 조회
            self.set_rate(10)
            self.start_inc(1, 1)
            _ret, _br_ifs, _err = chk_vnf_bridge(self._ip, self._wanNicList, self._lan_nic, _vnf_id=self._id)
            if not _ret :
                self._fin_err(_err)
                return
            else:
                if len(_br_ifs) > 0 :
                    _unsuppItem['bridge'] = True
                    _findUnSupp = True
            _debug(" - Check %s, br-if=%s"%( self._subtitle, str(_br_ifs) ))
            self._complete()
            
            _debug(" - SUCC: Check UnSupported Item, item=%s, chk=%s"%( str(_unsuppItem), str(_findUnSupp) ))
            if _findUnSupp :
                self._fin_unsuppor(_unsuppItem)
                return
            
            self._fin_ok()
        except Exception, e:
            _error("Fail to Check for LAN-IP Change, item=%s, exc=%s"%( self._subtitle, str(e) ))
            _except(e)
            self._fin_err(e)
            return


class _RunLanIpChg(_ProgMng):
    
    ITEM_LIST = ["Backup", "LAN-IP Change"]
    
    PROG_LIST = [0]*len(ITEM_LIST)
    
    def __init__(self, utm_ip, _bak_file, _new_lan_info, utmID=None, utmPass=None):
        _ProgMng.__init__(self)
        
        self._ip = utm_ip
        self._id = (DEF_ID if utmID == None else utmID)
        self._pass = (DEF_PASS if utmPass == None else utmPass)
        self._bak_file = _bak_file
        self._newLanInfo = _new_lan_info
        
        self._subtitle = self.ITEM_LIST[0]
        self._itemprog = self.PROG_LIST[0]
    
    def run(self):
        _title = "UTM LAN-IP Chagne"
        _info("Start %s"%_title)
        try:
            ### 1. vnfm에 backup 요청
            self.set_rate(5)
            
            self.start_inc(3, 1)
            if not os.path.isfile( self._bak_file ) :
                _ret, _err = backup(self._bak_file, self._ip)
                if not _ret :
                    self._fin_err(_err)
                    return
                _debug("     Save Backup File, f=%s"%(self._bak_file))
            
            self.stop_inc()
            _info(" - Succ: %s"%( self._subtitle ))
            self._complete()
            
            
            ### 2. IP Change
            ## Login
            self.set_rate(5)
            
            self.start_inc(3, 1)
            _ret = login(self._ip, self._id, self._pass)
            self.set_rate(10)
            if not _ret :
                self._fin_err("KT-VNF Login Error")
                return
            _debug("     Login KT-VNF")
            
            _lnic = self._newLanInfo['nic']
            _lnic_ip = self._newLanInfo['ip']
            try:
                _ip_pfx = IPv4Network("0.0.0.0/%s"%self._newLanInfo['mask']).prefixlen
                self._rollback = True
                _ret, _err = mod_ip_to_static(self._ip, _lnic, _lnic_ip, _ip_pfx)
                if not _ret :
                    self._fin_err("KT-VNF IP Change Error, err=%s"%str(_err))
                    return
                else:
                    _debug("     Change IP to Static, VNF-NIC=%s, ip=%s/%s"%( str(_lnic), str(_lnic_ip), str(_ip_pfx) ))
            except Exception, e:
                self._fin_err("KT-VNF IP Change Error, IP Check Error, net=%s, err=%s"%( str(self._newLanInfo), str(e) ))
                return
            
            self._complete()
            self._fin_ok()
        except Exception, e:
            _error(" - Fail to %s, exc=%s"%( self._subtitle, str(e) ))
            _except(e)
            self._fin_err("Error Occur")
            
    

class _RunRestore(_ProgMng):
    
    ITEM_LIST = ['Resotre']
    PROG_LIST = [0]*len(ITEM_LIST)
    
    def __init__(self, _vnf_ip, _bak_file, _wait_cnt=50):
        _ProgMng.__init__(self)
        
        self._ip = _vnf_ip
        self._bak_file = _bak_file
        self._wait_cnt = _wait_cnt
        
        self._subtitle = self.ITEM_LIST[0]
        self._itemprog = self.PROG_LIST[0]
    
    
    def run(self):
        try:
            _info("Start KT-VNF Restore")
            self.set_rate(10)
            _url = _URL_VNFM_RESTORE
            _body = {"vnf_name": V_TYPE, "local_mgmt_ip": self._ip, 
                     "local_location": str(self._bak_file), "needWanSwitch": False, "type": "local_all"}
            _cCrt = "/var/onebox/key/client.crt"
            _cKey = "/var/onebox/key/client.key"
            _ret = callAPI(_url, "POST", header=HEADER_VNFM, reqBody=_body, _to=180, cCrt=_cCrt, cKey=_cKey, sTime=1)
            if _ret == None :
                _error("Fail to Request KT-VNF Restore, API Call Error")
                self._fin_err("API Call Error")
                return
            _info("SUCC: Request KT-VNF Restore")
            
            _intv = 2
            _url = _URL_VNFM_STATUS
            _body = {"vnf_name": V_TYPE, "local_mgmt_ip": self._ip}
            self.set_rate(100 - self._wait_cnt)
            self.start_inc(2, 1)
            for _idx in range(self._wait_cnt) :
                sleep(_intv)
                try:
                    _ret = callAPI(_url, "POST", header=HEADER_VNFM, reqBody=_body, _to=5, cCrt=_cCrt, cKey=_cKey, sTime=1)
                    if _ret != None and _ret.has_key('status') and str(_ret['status']).strip().upper() == "RUNNING" :
                        _info("Succ: Restore KT-VNF")
                        self.stop_inc()
                        self._complete()
                        self._fin_ok()
                        return
                    _info(" - Check KT-VNF Restore Status, try=%s/%s status=%s"%(str(_idx+1), str(self._wait_cnt), str(_ret)) )
                except Exception, e:
                    _warn(" - Fail to Check KT-VNF Restore Status, exc=%s"%str(e))
                    _except(e)
            
            self.stop_inc()
            _error("Fail to Request KT-VNF Restore, TimeOut")
            self._fin_err("TimeOut")
        except Exception, e:
            _error("Fail to Request KT-VNF Restore, exc=%s"%str(e))
            _except(e)
            self._fin_err("Exception Occur")
            
    








