#-*- coding: utf-8 -*-
'''
Created on 2017. 8. 2.

@author: ohhara
'''
import traceback, sys, tempfile

DEF_ID = "no-utm"
DEF_PASS = "no-utm"

V_TYPE = "NO-UTM"

def load_cfg(_type):
    global V_TYPE
    V_TYPE = _type

def _getLineNo():
    org_f = None
    try:
        raise Exception
    except:
        org_f = sys.exc_info()[2].tb_frame.f_back
    #On some versions of IronPython, currentframe() returns None if
    #IronPython isn't run with -X:Frames.
    if org_f is not None:
        f = org_f.f_back
    else:
        return None
    
    if f == None :
        return None
    
    l_no = f.f_lineno
    return l_no

logger = None
_LOG_T = "[NO-UTM-Plugin.%-4s]"
def _debug(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.debug(msg)
    else: print msg

def _info(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.info(msg)
    else: print msg

def _warn(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.warning(msg)
    else: print msg

def _error(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.error(msg)
    else: print msg

def _except(exc):
    _SERR = tempfile.TemporaryFile()
    traceback.print_exc(exc, _SERR)
    _SERR.seek(0)
    msg = _SERR.read()
    msg = _LOG_T%str(_getLineNo()) + "\n" + str(msg)
    if logger != None : logger.fatal(msg)
    else: print msg


def login(vnfIP, vnfID=None, vnfPass=None, _rNum = 10):
    _warn("Fail to LogIn, NO UTM-Plugin")
    return False

def logout(vnfIP, vnfID=None):
    _warn("Fail to LogOut, NO UTM-Plugin")
    return False

def get_web_port():
    return None

def get_model():
    return "NO-UTM"

def get_wan_nic_list():
    _warn("Fail to Get WAN-NIC List, NO UTM-Plugin")
    return None
#     return _P_NICS

def get_metric(_name):
    _warn("Fail to Get Metric, NO UTM-Plugin")
    return None
#     '''
#     return : None or metric
#     '''
#     __n = str(_name).strip()
#     if __n == "br-wan" : return 0
#     elif __n == "br-wan1" : return 100
#     elif __n == "br-wan2" : return 200
#     elif __n == "br-wan3" : return 300
#     else : return None

def get_nic(_name):
    _warn("Fail to Get Nic, NO UTM-Plugin")
    return None
#     '''
#     return : None or if_name
#     '''
#     __n = str(_name).strip()
#     if __n == "br-wan" : return "eth1"
#     elif __n == "br-wan1" : return "eth5"
#     elif __n == "br-wan2" : return "eth6"
#     elif __n == "br-wan3" : return "eth7"
#     elif __n == "br-lan-office" : return "eth2"
#     elif __n == "br-lan-server" : return "eth3"
#     else : return None

def _get_dhcp_name(_name):
    _warn("Fail to Get DHCP_NAME, NO UTM-Plugin")
    return None
#     '''
#     return : None or dhcp_name
#     '''
#     __n = str(_name).strip()
#     if __n == "br-wan" or __n == "eth1" : return "red_dhcp"
#     elif __n == "br-wan1" or __n == "eth5" : return "red_dhcp_r1"
#     elif __n == "br-wan2" or __n == "eth6" : return "red_dhcp_r2"
#     elif __n == "br-wan3" or __n == "eth7" : return "red_dhcp_r3"
#     else : return None

def get_br(_name):
    _warn("Fail to Get Bridge, NO UTM-Plugin")
    return None
#     '''
#     return : None or br_name
#     '''
#     __n = str(_name).strip()
#     if __n == "eth1" : return "br-wan"
#     if __n == "eth2" : return "br-lan-office"
#     if __n == "eth3" : return "br-lan-server"
#     elif __n == "eth5" : return "br-wan1"
#     elif __n == "eth6" : return "br-wan2"
#     elif __n == "eth7" : return "br-wan3"
#     else : return None

def _get_br_list(_vnf_ip):
    _warn("Fail to Get Bridge List, NO UTM-Plugin")
    return None
    
def get_br_info(_vnf_ip, _brname=None):
    _warn("Fail to Get Bridge Info, NO UTM-Plugin")
    return None

def get_route_table(_vnf_ip):
    _warn("Fail to Get RouteTable, NO UTM-Plugin")
    return None

def get_gw_info(_vnf_ip, _tname="main", _dev=None):
    _warn("Fail to Get GW-Info, NO UTM-Plugin")
    return None

def get_def_gw_info(_vnf_ip):
    _warn("Fail to Get Default-GW-Info, NO UTM-Plugin")
    return None, None, None

def _get_public_ip_list(_vnf_ip):
    _warn("Fail to Get Public IP List, NO UTM-Plugin")
    return []

def get_ip(_vnf_ip, _nic):
    _warn("Fail to Get IP, NO UTM-Plugin")
    return None, None
    
def get_main_public_ip(_vnf_ip):
    _warn("Fail to Get Main Public IP, NO UTM-Plugin")
    return None, None, None, None

def check_conn(_uip, _dns1, _dns2, _url, _port, _murl, _ERR_RET_LIST):
    _warn("Fail to Check Conn, NO UTM-Plugin")
    return False, "No UTM-Plugin", []

def to_delinfo_txt(_delInfo):
    _warn("Fail to Change DeleteInfo-Text, NO UTM-Plugin")
    return False, None

def backup(_backupFile, _ip, _crt=None, _key=None):
    _warn("Fail to Backup, NO UTM-Plugin")
    return False, "No UTM-Plugin"

def chk_vnf_bridge(_vnf_ip, _wnic_list, _lan_nic=None, _vnf_id=None):
    _warn("Fail to Check VNF-Bridge, NO UTM-Plugin")
    return False, None, "No UTM-Plugin"


def get_vnf_all_route_info(_vnf_ip, _wan_nic_list, _static_gw_list=None, _chkExist=None, _vnf_id=None):
    _warn("Fail to Get All Route-Info, NO UTM-Plugin")
    return False, None, "No UTM-Plugin"

def add_vnf_ip(_vnf_ip, _is_dhcp, _host_br, _ip=None, _mask=None, _mac=None, _vnf_id=None):
    _warn("Fail to Add IP, NO UTM-Plugin")
    return False, "No UTM-Plugin"

def add_vnf_route(_vnf_ip, _is_dhcp, _host_br, _gw=None, _table=None, _metric=None, _vnf_id=None):
    _warn("Fail to Add Route, NO UTM-Plugin")
    return False, "No UTM-Plugin"

def del_vnf_route(_vnf_ip, _route, _vnf_id=None):
    _warn("Fail to Delete Route, NO UTM-Plugin")
    return False, "No UTM-Plugin"

def del_vnf_all_route(_vnf_ip, _route_list, _vnf_id=None):
    _warn("Fail to Delete All Route, NO UTM-Plugin")
    return False, "No UTM-Plugin"

def mod_vnf_route(_vnf_ip, _tname, _tnum, _gw_ip, _nic, _metric=None, _vnf_id=None):
    _warn("Fail to Modify Route, NO UTM-Plugin")
    return False, "No UTM-Plugin"

def del_unuse_if(_vnf_ip, _dhcp_if_list, _vnf_id=None):
    _warn("Fail to Delete UnUse-IF, NO UTM-Plugin")
    return False, False, "No UTM-Plugin"

def del_dhcp_if(_vnf_ip, _dhcp_if_list, _vnf_id=None):
    _warn("Fail to Delete DHCP-IF, NO UTM-Plugin")
    return False, False, "No UTM-Plugin"


def mod_ip_to_dhcp(_vnf_ip, _nic, _dhcp_name, _mac=None):
    _warn("Fail to Modify IP to DHCP, NO UTM-Plugin")
    return False, "No UTM-Plugin"

def mod_ip_to_static(_vnf_ip, _nic, _ip, _pfx):
    _warn("Fail to Modify IP to Static, NO UTM-Plugin")
    return False, "No UTM-Plugin"

def chk_list_for_new_wan_ip(_vnf_ip, _vnf_id=None, _vnf_pass=None):
    _warn("Fail to Get New-Wan-IP Chk-List, NO UTM-Plugin")
    return []

def create_chk_new_wan_ip(_ip, _wanNicList, _prevStaticWanInfo, _id=None, _pass=None):
    _warn("Fail to Create Check-New-Wan-IP-Inst, NO UTM-Plugin")
    return None

def run_list_for_new_wan_ip(_vnf_ip, _vnf_id=None, _vnf_pass=None):
    _warn("Fail to Get New-Wan-IP Run-List, NO UTM-Plugin")
    return []

def create_run_new_wan_ip(utm_ip, 
                 _bak_file, _tmp_if_file, _tmp_dr_file, _tmp_ur_file, _tmp_rr_file, _tmp_arp_file,
                 newWanInfo, prevStaticWanInfo, utmID=None, utmPass=None):
    _warn("Fail to Create New-Wan-IP-Inst, NO UTM-Plugin")
    return None

def chk_list_for_new_lan_ip():
    _warn("Fail to Get New-Lan-IP Chk-List, NO UTM-Plugin")
    return []

def create_chk_new_lan_ip(_ip, _lan_nic, _wanNicList=None, _id=None, _pass=None):
    _warn("Fail to Create Check-New-Lan-IP-Inst, NO UTM-Plugin")
    return None

def run_list_for_new_lan_ip():
    _warn("Fail to Get New-Lan-IP Run-List, NO UTM-Plugin")
    return []

def create_run_new_lan_ip(utm_ip, _bak_file, _new_lan_info, utmID=None, utmPass=None):
    _warn("Fail to Create New-Lan-IP-Inst, NO UTM-Plugin")
    return None

def create_vnf_restore(_vnf_ip, _bak_file):
    _warn("Fail to Create VNF-Restore-Inst, NO UTM-Plugin")
    return None



