# -*- coding: utf-8 -*-
#
# @Copyright (c) 2018 IN-SOFT Co., Ltd. all rights reserved.
#
# @Author: Sung-Sik, Park (sspark@in-soft.co.kr)
#
# @Legal Notice
#  Redistribution and use in source and binary forms, with or with out
#  modification, are not permitted in any cases.
#


# This software is based on the PEP 8 -- Style Guide for Python Code.
#  https://www.python.org/dev/peps/pep-0008/#comments


# Imports should be grouped in the following order:
#
#  1. standard library imports
#  2. related third party imports
#  3. local application/library specific imports
#
# The import order should be in alphabetical order.


import copy
import json
import os
import sys
import tempfile
import traceback
import threading
from time import sleep

# noinspection PyPackageRequirements
from ipaddr import IPv4Network
import ruamel.yaml
from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest

SESSION_ID = None

V_TYPE = "AXGATE-UTM"
HEADER = {"content-Type": "application/x-www-form-urlencoded", "accept": "*/*"}
HEADER_VNFM = {"content-Type": "application/json", "accept": "*/*"}

DEF_ID = "axroot"
DEF_PASS = "smflaqhNo1@"
DEF_PORT = int(443)

PHYSICAL_NICs = [
    "eth1",
    "eth5",
    "eth6",
    "eth7"
]

CLIENT_CERTI = "/var/onebox/key/client.crt"
CLIENT_KEY = "/var/onebox/key/client.key"

URL_VNFM_BACKUP = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/backup""" % V_TYPE
URL_VNFM_RESTORE = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/restore""" % V_TYPE
URL_VNFM_STATUS = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/status""" % V_TYPE

_LOG_T = "[PLG-AXG-UTM.%-4s]"

logger = None


# New implemented
#  Func: load_cfg(_type)


def load_cfg(_type):
    global V_TYPE, URL_VNFM_BACKUP, URL_VNFM_RESTORE, URL_VNFM_STATUS

    V_TYPE = _type
    URL_VNFM_BACKUP = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/backup""" % V_TYPE
    URL_VNFM_RESTORE = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/restore""" % V_TYPE
    URL_VNFM_STATUS = """https://127.0.0.1:9014/ktvnfm/v1/vnfs/%s/status""" % V_TYPE


# noinspection PyPep8Naming
def _getLineNo():
    # noinspection PyUnusedLocal
    org_f = None
    # noinspection PyBroadException
    try:
        raise Exception
    except:
        org_f = sys.exc_info()[2].tb_frame.f_back
    # On some versions of IronPython, currentframe() returns None if
    # IronPython isn't run with -X:Frames.
    if org_f is not None:
        f = org_f.f_back
    else:
        return None

    if f is None:
        return None

    l_no = f.f_lineno

    return l_no


def _debug(msg):
    msg = _LOG_T % str(_getLineNo()) + " " + str(msg)
    if logger is not None:
        logger.debug(msg)
    else:
        print msg


def _info(msg):
    msg = _LOG_T % str(_getLineNo()) + " " + str(msg)
    if logger is not None:
        logger.info(msg)
    else:
        print msg


def _warn(msg):
    msg = _LOG_T % str(_getLineNo()) + " " + str(msg)
    if logger is not None:
        logger.warning(msg)
    else:
        print msg


def _error(msg):
    msg = _LOG_T % str(_getLineNo()) + " " + str(msg)
    if logger is not None:
        logger.error(msg)
    else:
        print msg


def _except(exc):
    _serr = tempfile.TemporaryFile()
    traceback.print_exc(exc, _serr)
    _serr.seek(0)
    msg = _serr.read()
    msg = _LOG_T % str(_getLineNo()) + "\n" + str(msg)
    if logger is not None:
        logger.fatal(msg)
    else:
        print msg


class AxGateHTTPClient(object):
    def __init__(self):
        self._headers = HTTPHeaders()

    def add_header(self, name, value):
        self._headers.add(name, value)

    def http_request(self,
                     http_validate_cert=False,
                     client_ssl_cert=None,
                     client_ssl_key=None,
                     http_url="https://127.0.0.1:443/",
                     http_method="GET",
                     http_body=None,
                     http_request_timeout=5,
                     delay_timeout=2):
        """
        :param http_validate_cert:
        :param client_ssl_cert:
        :param client_ssl_key:
        :param http_url:
        :param http_method:
        :param http_body:
        :param http_request_timeout:
        :param delay_timeout:
        :return: Error, Header, Body
        """
        # Question: Why is this code necessary?
        sleep(delay_timeout)

        http_client = None
        http_response = None

        try:
            http_client = httpclient.HTTPClient()

            http_request = HTTPRequest(
                validate_cert=http_validate_cert,
                client_cert=client_ssl_cert,
                client_key=client_ssl_key,
                url=http_url,
                headers=self._headers,
                method=http_method,
                body=http_body,
                request_timeout=http_request_timeout
            )

            _debug("HTTPRequest: url={}, body={}, http_request_timeout={}"
                   .format(http_url, http_body, http_request_timeout))

            http_response = http_client.fetch(request=http_request)

            _debug("Fetch: code={}, body={}".format(http_response.code, http_response.body))
        except Exception as _exc:
            _debug("HTTPRequest:")
            _debug("  url={}".format(http_url))
            _debug("  headers={}".format(self._headers))
            _debug("  body={}".format(http_body))
            _debug("  http_request_timeout={}".format(http_request_timeout))

            if http_response is None:
                _debug("Fetch: <http_response> is None")
            else:
                _debug("Fetch:")
                _debug("  code={}".format(http_response.code))
                _debug("  headers={}".format(http_response.headers))
                _debug("  body={}".format(http_response.body))

            _except(_exc)

            if http_response is not None:
                return True, http_response.code, http_response.headers, http_response.body
            return True, None, None, None
        finally:
            http_client.close()

        return False, http_response.code, http_response.headers, http_response.body


# New implemented
#  Func: show_vnf_version(_vnf_ip, _session_id)


def show_vnf_version(_vnf_ip, _session_id):
    vnf_version = None

    if _session_id is None or not _session_id:
        _warn("No valid SESSION ID")
        return None

    # noinspection PyBroadException,PyUnusedLocal
    try:
        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show version" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % _session_id))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % _vnf_ip),
            http_method="POST",
            http_body=str("cmd=show version"),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            return None

        result = int()
        rows = str(body).splitlines()
        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
                continue

            if columns[0] == "version":
                vnf_version = columns[1]

        if result is not 1:
            return None

        return vnf_version
    except Exception as _exc:
        return None


# Refactoring code
#  Func: login(vnfIP,
#              vnfID=None,
#              vnfPass=None,
#              _rNum = 10)


def login(address, username=DEF_ID, password=DEF_PASS, retries=10, retry_delay=3):
    sid = None

    # noinspection PyStatementEffect,PyBroadException
    try:
        global SESSION_ID
        if SESSION_ID is not None:
            _vnf_version = show_vnf_version(_vnf_ip=address, _session_id=SESSION_ID)

            if _vnf_version is not None:
                _debug("Valid SESSION ID: '%s'" % str(SESSION_ID))
                return SESSION_ID
    except Exception:
        pass

    if username is None or not username:
        username = DEF_ID

    if password is None or not password:
        password = DEF_PASS

    for retry in range(1, retries + 1):
        sleep(retry_delay)

        try:
            http_client = AxGateHTTPClient()

            http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
            http_client.add_header(name="Accept", value="*/*")

            err, code, headers, body = http_client.http_request(
                http_url=str("https://%s:443/login.cgi" % address),
                http_method="POST",
                http_body=str("username=%s&password=%s&desc=VNF" % (username, password)),
                delay_timeout=1
            )

            if err is False and code == 200 and headers is not None and body is not None:
                results = str(body).split(":")
                if len(results) is not 2 or results[0] != "result":
                    _warn("Fail to %s, retries=%d/%d" % (str("AxGate VNF login"), retry, retries))
                    continue

                if results[1] is 0:
                    _warn("Fail to %s, retries=%d/%d" % (str("AxGate VNF login"), retry, retries))
                    continue

                cookies = headers.get_list("Set-Cookie")
                for offset in range(0, len(cookies)):
                    if int(str(cookies[offset]).find("SessionID=")) > -1:
                        sid = cookies[offset][len(str("SessionID=")):]
                        break

                if sid is None or len(sid) <= 0:
                    _warn("Fail to %s, retries=%d/%d" % (str("AxGate VNF login"), retry, retries))
                    continue

            if sid is not None and len(sid) > 0:
                global SESSION_ID
                SESSION_ID = sid
                _debug("Succeed: AxGate VNF login: SessionID[%s]" % sid)
                break
        except Exception as _exc:
            _warn("Fail to %s, retries=%d/%d" % (str("AxGate VNF login"), retry, retries))
            _except(_exc)
            continue

    return sid


# Refactoring code
#  Func: logout(vnfIP,
#               vnfID=None)


def logout(address, session_id, timeout=0):
    # try:
    #     http_client = AxGateHTTPClient()
    #
    #     http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
    #     http_client.add_header(name="Accept", value="*/*")
    #     http_client.add_header(name="Cookie", value=str("SessionID=%s" % session_id))
    #
    #     err, code, headers, body = http_client.http_request(
    #         http_url=str("https://%s:443/restrict/logout.cgi" % address),
    #         http_method="POST",
    #         http_body=str("timeout=%d" % timeout),
    #         delay_timeout=1
    #     )
    #
    #     if err is False and code == 200 and headers is not None and body is not None:
    #         results = str(body).split(":")
    #         if len(results) is not 2 or results[0] != "result":
    #             _warn("Fail to %s" % (str("AxGate VNF logout")))
    #             return False
    #
    #         if results[1] is 0:
    #             _warn("Fail to %s" % (str("AxGate VNF logout")))
    #             return False
    # except Exception as _exc:
    #     _warn("Fail to AxGate VNF logout")
    #     _except(_exc)
    #     return False

    return True


def _logout(address, session_id, timeout=0):
    try:
        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % session_id))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/logout.cgi" % address),
            http_method="POST",
            http_body=str("timeout=%d" % timeout),
            delay_timeout=1
        )

        if err is False and code == 200 and headers is not None and body is not None:
            results = str(body).split(":")
            if len(results) is not 2 or results[0] != "result":
                _warn("Fail to %s" % (str("AxGate VNF logout")))
                return

            if results[1] is 0:
                _warn("Fail to %s" % (str("AxGate VNF logout")))
                return
    except Exception as _exc:
        _warn("Fail to AxGate VNF logout")
        _except(_exc)
        return


# Refactoring code
#  Func: get_wan_nic_list(vnfIP,
#               vnfID=None)


def get_wan_nic_list():
    return PHYSICAL_NICs


# Not refactoring code
#  Func: get_metric(name)


def get_metric(_name):
    """
    :param _name:
    :return:
    """

    n = str(_name).strip()

    if n == "br-wan":
        return 0
    elif n == "br-wan1":
        return 200
    elif n == "br-wan2":
        return 210
    elif n == "br-wan3":
        return 220
    else:
        return None


# New implemented
#  Func: _get_distance(_name)


def _get_distance(_name):
    """
    :param _name:
    :return:
    """

    n = str(_name).strip()

    if n == "eth1":
        return 1
    elif n == "eth5":
        return 210
    elif n == "eth6":
        return 220
    elif n == "eth7":
        return 230
    else:
        return None


# Not refactoring code
#  Func: get_nic(_name)


def get_nic(_name):
    """
    :param _name:
    :return:
    """

    n = str(_name).strip()

    if n == "br-wan":
        return "eth1"
    elif n == "br-wan1":
        return "eth5"
    elif n == "br-wan2":
        return "eth6"
    elif n == "br-wan3":
        return "eth7"
    elif n == "br-lan-office":
        return "eth2"
    elif n == "br-lan-server":
        return "eth3"
    else:
        return None


# Not refactoring code
#  Func: get_nic(name)


def _get_dhcp_name(name):
    """
    :param name:
    :return: None or dhcp-name
    """

    n = str(name).strip()

    if n == "br-wan" or n == "eth1":
        return "red_dhcp"
    elif n == "br-wan1" or n == "eth5":
        return "red_dhcp_r1"
    elif n == "br-wan2" or n == "eth6":
        return "red_dhcp_r2"
    elif n == "br-wan3" or n == "eth7":
        return "red_dhcp_r3"
    else:
        return None


# Not refactoring code
#  Func: get_br(_name)


def get_br(_name):
    """
    :param _name:
    :return:
    """

    n = str(_name).strip()

    if n == "eth1":
        return "br-wan"
    if n == "eth2":
        return "br-lan-office"
    if n == "eth3":
        return "br-lan-server"
    elif n == "eth5":
        return "br-wan1"
    elif n == "eth6":
        return "br-wan2"
    elif n == "eth7":
        return "br-wan3"
    else:
        return None


# Refactoring code
#  Func: _get_br_list(vnfIP)


def _get_br_list(address, username="axroot", password="smflaqhNo1@"):
    """
    :param address: address of VNF
    :return: Noe or br-name list
    """

    bridges = None
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            _error("Fail to Get Bridges: /login.cgi, sid(%s)" % sid)
            return None

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show interface bridge" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=str("cmd=show interface bridge"),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            _error("Fail to Get Bridges: /exec.cgi")
            return None

        result = int()
        rows = str(body).splitlines()
        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
                continue

            if columns[0] == "message":
                break

            if columns[0] == "ifname":
                if bridges is None:
                    bridges = list()

                bridges.append(columns[1])

        if result is not 1:
            _error("Fail to Get Bridges: /exec.cgi")
            return None
    except Exception as _exc:
        _warn("Fail to Get Bridges")
        _except(_exc)
        return None
    # finally:
    #     if sid is not None:
    #         logout(address=address, session_id=sid)

    return bridges


# Refactoring code
#  Func: get_br_info(_vnf_ip, _brname=None)


def get_br_info(_vnf_ip, _brname=None):
    """
    :param _vnf_ip:
    :param _brname:
    :return: None or dict{'br1': ['eth1'], 'br2':[]}
    """

    if _brname is None:
        _brlist = _get_br_list(address=_vnf_ip)
    else:
        _brlist = [_brname]

    if type(_brlist) != list or len(_brlist) < 1:
        return None

    _br_info = dict()

    try:
        sid = login(address=_vnf_ip, username="axroot", password="smflaqhNo1@")
        if sid is None or len(sid) is 0:
            _error("Fail to Get Bridges: /login.cgi, sid(%s)" % sid)
            return None

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show interface bridge" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % _vnf_ip),
            http_method="POST",
            http_body=str("cmd=show interface bridge"),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            _error("Fail to Get Bridges: /exec.cgi")
            return None

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
                break

        if result is not 1:
            _error("Fail to Get Bridges: /exec.cgi")
            return None

        for _brname in _brlist:
            _br_ifs = list()

            _found = False
            _port = list()
            for offset in range(0, len(rows)):
                columns = rows[offset].split(":")

                if len(columns) is not 2:
                    continue

                if columns[0] == "message":
                    _debug("message: %s" % str(columns[1]))
                elif columns[0] == "ifname":
                    if _brname == columns[1]:
                        _found = True
                elif columns[0] == "port":
                    _br_ifs = str(columns[1]).split(",")
                    break

            if _found is True:
                _br_info[_brname] = _br_ifs

    except Exception as _exc:
        _warn("Fail to Get Bridges")
        _except(_exc)
        return None
    # finally:
    #     if sid is not None:
    #         logout(address=_vnf_ip, session_id=sid)

    return _br_info


# Not implemented
#  Func: _getLineNo()


# Refactoring code
#  Func: get_gw_info(_vnf_ip, _tname="main", _dev=None)


# noinspection PyUnusedLocal
def get_gw_info(_vnf_ip, _name="main", _dev=None):
    """
    :param _vnf_ip:
    :param _name:
    :param _dev:
    :return: None or [(dev, ip, metric)]
    """

    gateway = None
    sid = None

    try:
        sid = login(address=_vnf_ip, username="axroot", password="smflaqhNo1@")
        if sid is None or len(sid) is 0:
            _error("Fail to Get Main route: /login.cgi, sid(%s)" % sid)
            return None

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show ip route 0.0.0.0" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % _vnf_ip),
            http_method="POST",
            http_body=str("cmd=show ip route 0.0.0.0"),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            _error("Fail to Get Main route(show ip route 0.0.0.0): /exec.cgi")
            return None

        result = int()
        rows = str(body).splitlines()

        dev = None
        ip = None
        metric = None

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "message":
                _debug("Get Main route(show ip route 0.0.0.0): /exec.cgi: message(%s)" % columns[0])
            elif columns[0] == "ifname":
                dev = columns[1]
            elif columns[0] == "route-ip":
                ip = columns[1]
            elif columns[0] == "distance":
                metric = columns[1]

            if dev is not None and \
                            ip is not None and \
                            metric is not None:
                if gateway is None:
                    gateway = list()
                    gateway.append((dev, ip, metric))

        if result is not 1:
            _error("Fail to Get Main route(show ip route 0.0.0.0): /exec.cgi")
            return None
    except Exception as _exc:
        _warn("Fail to Get Main route")
        _except(_exc)
        return None
    # finally:
    #     if sid is not None:
    #         logout(address=_vnf_ip, session_id=sid)

    return gateway


# Refactoring code
#  Func: _get_def_gw_info(_vnf_ip)


def get_def_gw_info(_vnf_ip):
    """
    :param _vnf_ip:
    :return:
    :return: None, None, None or (dev, ip, metric)
    """

    gateways = get_gw_info(_vnf_ip)

    if gateways is None or len(gateways) < 1:
        return None, None, None
    else:
        return gateways[0]


# Refactoring code
#  Func: _get_public_ip_list(_vnf_ip)


def _get_public_ip_list(address):
    """
    :param address: address of VNF
    :return: [(NIC, IP, MASK)] or List
    """

    ips = list()

    for nic in PHYSICAL_NICs:
        ip, mask = get_ip(address, nic)

        if ip is None:
            continue

        ips.append((nic, ip, mask))

    return ips


# Refactoring code
#  Func: get_ip(_vnf_ip, _nic)


def get_ip(_vnf_ip, _nic):
    """
    :param _vnf_ip: address of VNF
    :param _nic: Network Interface of VNF
    :param nic: Network Interface of VNF
    :return: (IP, Mask) or (None, None)
    """

    sid = None
    ip = None
    mask = None

    if not str(_nic).strip():
        _error("Fail to Get Ip: 'Nic' paramter is empty.")
        return None, None

    try:
        sid = login(address=_vnf_ip, username="axroot", password="smflaqhNo1@")
        if sid is None or len(sid) is 0:
            _error("Fail to Get Ip: /login.cgi, sid(%s)" % sid)
            return None, None

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show interface eth[0-9]" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % _vnf_ip),
            http_method="POST",
            http_body=str("cmd=show interface %s" % _nic),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            _error("Fail to Get Ip(show interface %s): /exec.cgi" % _nic)
            return None, None

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if columns is None:
                continue

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "message":
                _debug("Get Ip(show interface %s): /exec.cgi: message(%s)" % (_nic, columns[0]))
            elif columns[0] == "primary" and str(columns[1]).lower() != "none":
                ipmask = columns[1].split("/")

                if len(ipmask) is not 2:
                    result = 1
                    _error("Fail to Get Ip(show interface %s): /exec.cgi: 'primary' parsing error" % _nic)
                else:
                    ip = ipmask[0]
                    mask = ipmask[1]

        if result is not 1:
            _error("Fail to Get Ip(show ip interface %s): /exec.cgi" % _nic)
            return None, None
    except Exception as _exc:
        _warn("Fail to Get Ip")
        _except(_exc)
        return None, None
    # finally:
    #     if sid is not None:
    #         logout(address=_vnf_ip, session_id=sid)

    return ip, mask


# Refactoring code
#  Func: get_main_public(_vnf_ip)


def get_main_public_ip(_vnf_ip):
    """
    :param _vnf_ip:
    :return: (None, None, None, None) or (nic, ip, mask, gw)
    """

    ips = _get_public_ip_list(_vnf_ip)

    if len(ips) < 1:
        return None, None, None, None

    dev, ip, metric = get_def_gw_info(_vnf_ip)
    if dev is None or ip is None:
        return ips[0][0], ips[0][1], ips[0][2], None

    for iptuple in ips:
        if iptuple[0] == dev:
            return iptuple[0], iptuple[1], iptuple[2], ip

    return ips[0][0], ips[0][1], ips[0][2], None


# Refactoring code
#  Func: _ping(_vnf_ip, ip, _try=1, wait=1)


def _do_ping(address, destination, timeo=1):
    """
    :param address: address of VNF
    :param destination:
    :param timeo:
    :return:
    """

    sid = None

    try:
        sid = login(address=address, username="axroot", password="smflaqhNo1@")
        if sid is None or len(sid) is 0:
            _error("Fail to Do ping(test target-status ping %s timeout %d): /login.cgi, sid(%s)" % (
                destination, timeo, sid))
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=test target-status ping {destination} timeout {timeo}" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=str("cmd=test target-status ping %s timeout %d" % (destination, timeo)),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            _error(
                "Fail to Do ping(test target-status ping %s timeout %d): /exec.cgi" % (
                    destination, timeo))
            return False

        result = int()
        doping = False
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "ping":
                if int(columns[1]) is 1:
                    doping = True

        if result is not 1 or doping is False:
            _error("Fail to Do ping(test target-status ping %s timeout %d): /exec.cgi" % (
                destination, timeo))
            return False
    except Exception as _exc:
        _warn("Fail to Do ping")
        _except(_exc)
        return False
    # finally:
    #     if sid is not None:
    #         logout(address=address, session_id=sid)

    return True


# Refactoring code
#  Func: _do_arping(_vnf_ip, ip, dev, _try=1, wait=3)


# noinspection PyUnusedLocal
def _do_arping(address, destination, dev, retry=1, timeo=3):
    """
    :param address: address of VNF
    :param destination:
    :param dev:
    :param retry:
    :param timeo:
    :return:
    """

    sid = None

    try:
        sid = login(address=address, username="axroot", password="smflaqhNo1@")
        if sid is None or len(sid) is 0:
            _error(
                "Fail to Do ping(test target-status arping %s timeout %d source %s): /login.cgi, sid(%s)" %
                (destination, timeo, dev, sid))
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=test target-status arping {destination} timeout {timeo}" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=str("cmd=test target-status arping %s timeout %d" % (destination, timeo)),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            _error(
                "Fail to Do arping(test target-status arping %s timeout %d): /exec.cgi" % (
                    destination, timeo))
            return False

        result = int()
        doarping = False
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "arping":
                if int(columns[1]) is 1:
                    doarping = True

        if result is not 1 or doarping is False:
            _error("Fail to Do arping(test target-status ping %s timeout %d): /exec.cgi" % (
                destination, timeo))
            return False
    except Exception as _exc:
        _warn("Fail to Do arping")
        _except(_exc)
        return False
    # finally:
    #     if sid is not None:
    #         logout(address=address, session_id=sid)

    return True


# Not implemented
#  Func: _chk_conn_nc(_vnf_ip, _url, _port, _wait=3)


# Not implemented
#  Func: _chk_conn_curl(_vnf_ip, _url, _wait=3)


# Not implemented
#  Func: _chk_conn_nslookup(_vnf_ip, url, wait=3)


# noinspection PyUnusedLocal
def _do_nslookup(address, url, timeo=3):
    """
    :param address: address of VNF
    :param url:
    :param timeo:
    :return:
    """

    sid = None

    try:
        sid = login(address=address, username="axroot", password="smflaqhNo1@")
        if sid is None or len(sid) is 0:
            _error("Fail to Do nslookup(test target-status nslookup %s): /login.cgi, sid(%s)" % (
                url, sid))
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=test target-status nslookup {url} timeout {timeo}" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=str("cmd=test target-status nslookup %s" % url),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            _error(
                "Fail to Do arping(test target-status nslookup %s): /exec.cgi" % url)
            return False

        result = int()
        doarping = False
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "nslookup":
                if int(columns[1]) is 1:
                    doarping = True

        if result is not 1 or doarping is False:
            _error("Fail to Do nslookup(test target-status nslookup %s): /exec.cgi" % url)
            return False
    except Exception as _exc:
        _warn("Fail to Do nslookup")
        _except(_exc)
        return False
    # finally:
    #     if sid is not None:
    #         logout(address=address, session_id=sid)

    return True


# Refactoring code
#  Func: check_conn


# noinspection PyUnusedLocal
def check_conn(_uip, _dns1, _dns2, _url, _port, _murl, _ERR_RET_LIST):
    """
    :param _uip:
    :param _dns1:
    :param _dns2:
    :param _url:
    :param _port:
    :param _murl:
    :param _ERR_RET_LIST:
    :return:
    """

    fails = list()

    sid = None

    try:
        # DNS
        if _do_ping(_uip, _dns1) or _do_ping(_uip, _dns2):
            _info("SUCC: Chk-Conn, VNF-DNS-Ping")
            return True, None, fails
        else:
            _warn(" - Fail to Chk-Conn, VNF-DNS-Ping")

            # ECD_CHK_CONN_VNF_DNS_PING
            fails.append(_ERR_RET_LIST["DNS_PING"])

        # Gateway: ping, arping
        def_gateway_dev, def_gateway_ip, def_gateway_metric = get_def_gw_info(_uip)
        if def_gateway_dev is None or def_gateway_ip is None:
            err = str("Default VNF-GW-Info Error, info=%s/%s/%s" % (
                str(def_gateway_dev), str(def_gateway_ip), str(def_gateway_metric)
            ))
            _error("Fail to Chk-Conn, %s" % err)

            # ECD_CHK_CONN_VNF_NO_GW
            fails.append(_ERR_RET_LIST["NO_GW"])
            return False, err, fails

        def_dev = def_gateway_dev
        gateway_ip = def_gateway_ip
        if _do_ping(_uip, gateway_ip, 3):
            _info("SUCC: Chk-Conn, VNF-GW-Ping, vnf_ip=%s, gw=%s" % (str(_uip), str(gateway_ip)))
            return True, None, fails
        else:
            _warn(" - Fail to Chk-Conn, VNF-GW-Ping, vnf_ip=%s, gw=%s" % (str(_uip), str(gateway_ip)))
            # ECD_CHK_CONN_VNF_GW_PING
            fails.append(_ERR_RET_LIST["GW_PING"])

        if _do_arping(_uip, gateway_ip, def_dev, 3):
            _info("SUCC: Chk-Conn, VNF-GW-Arp, vnf_ip=%s, gw=%s" % (str(_uip), str(gateway_ip)))
            return True, None, fails
        else:
            _warn(" - Fail to Chk-Conn, VNF-GW-Arp, vnf_ip=%s, gw=%s" % (str(_uip), str(gateway_ip)))
            # ECD_CHK_CONN_VNF_GW_ARPING
            fails.append(_ERR_RET_LIST["GW_ARPING"])

        # NC
        # ToDo: Ignore?

        # Curl ORCH-M
        # ToDo: Ignore?

        # NSLookup
        if _do_nslookup(_uip, _url):
            _info("SUCC: Chk-Conn, VNF-NsLookup, site=%s" % str(_url))
            return True, None, fails
        else:
            _warn(" - Fail to Chk-Conn, VNF-NsLookup, site=%s" % str(_url))
            # ECD_CHK_CONN_VNF_NS_SITE
            fails.append(_ERR_RET_LIST["NS_SITE"])
    except Exception as _exc:
        _warn("Fail to Chk-Conn")
        _except(_exc)
        return False, "Exception", fails
    # finally:
    #     if sid is not None:
    #         logout(address=_uip, session_id=sid)

    return False, None, fails


# Refactoring code
#  Func: to_delinfo_txt(_delInfo)


def to_delinfo_txt(_delInfo):
    """
    :param _delInfo:
    :return:
    """

    if _delInfo is None:
        return True, None

    _debug("_delInfo:%s" % str(_delInfo))

    tab = "     "
    delinfotxt = str()

    try:
        # ## {"IP": None, "Route": None, "RouteRule": None, "ARP": None}
        ip = (_delInfo['IP'] if "IP" in _delInfo else None)
        if ip is not None and len(ip) > 0:
            delinfotxt += "## IP :\n"
            for _nic in ip.keys():
                ipinfo = ip[_nic]
                if "id" in ipinfo:
                    delinfotxt += ("%s%-5s: DHCP(%s)\n" % (tab, _nic, ipinfo['id']))
                else:
                    _fir = True
                    for _ipAddr in ipinfo['ip_list']:
                        if _fir:
                            delinfotxt += ("%s%-5s: %s/%s\n" %
                                           (tab, _nic, _ipAddr['_addr'], _ipAddr['_prefixlen']))
                            _fir = False
                        else:
                            delinfotxt += (
                                "%s%-5s  %s/%s\n" % (tab, "", _ipAddr['_addr'], _ipAddr['_prefixlen']))

        _route = (_delInfo['Route'] if "Route" in _delInfo else None)
        if _route is not None and len(_route) > 0:
            delinfotxt += "## Route :\n"
            # noinspection PyTypeChecker
            for _r in _route:
                _gwInfo = ",".join(_r['_gwList'])
                delinfotxt += ("%stable: %5s, %s/%s >> %s\n" % (
                    tab, _r['_name'], _r['_destAddr'], _r['_dnetPrefix'], _gwInfo))

        _rule = (_delInfo['RouteRule'] if "RouteRule" in _delInfo else None)
        if _rule is not None and len(_rule) > 0:
            delinfotxt += "## RouteRule :\n"
            # noinspection PyTypeChecker
            for _rr in _rule:
                delinfotxt += ("%stable: %5s, src:%s/%s, dst:%s/%s\n" % (
                    tab,
                    _rr['_name'],
                    _rr['_addr'],
                    _rr['_fromPrefix'],
                    _rr['_toAddr'],
                    _rr['_toPrefix']))

        _arp = (_delInfo['ARP'] if "ARP" in _delInfo else None)
        if _arp is not None and len(_arp) > 0:
            delinfotxt += "## ARP :\n"
            # noinspection PyTypeChecker
            for _a in _arp:
                delinfotxt += ("%s%s, %s, %s\n" % (tab, _a['addr'], _a['lladdr'], _a['ifname']))

        if not delinfotxt:
            return True, None

        return True, delinfotxt
    except Exception, e:
        _error("Fail to Convert DelInfo to Text, exc=%s, progTxt=%s" % (str(e), delinfotxt))
        _except(e)
        return False, None


# New implemented
#  Func: def request_vnfapi(url,
#                           method,
#                           header=HEADER,
#                           request_body=None,
#                           response_header=False,
#                           to=5,
#                           cert=None,
#                           key=None,
#                           stime=2)


def _request_vnfapi(url,
                    method,
                    header=HEADER,
                    request_body=None,
                    response_header=False,
                    to=10,
                    cert=None,
                    key=None,
                    stime=2):
    try:
        sleep(stime)

        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(header)

        if request_body is None:
            body_string = None
        elif type(request_body) == str:
            body_string = request_body
        else:
            body_string = json.dumps(request_body)

        if cert is None or key is None:
            req = HTTPRequest(validate_cert=False,
                              url=url,
                              headers=h,
                              method=method.upper(),
                              body=body_string,
                              request_timeout=to)
        else:
            req = HTTPRequest(validate_cert=False,
                              url=url,
                              headers=h,
                              method=method.upper(),
                              client_cert=cert,
                              client_key=key,
                              body=body_string,
                              request_timeout=to)

        _debug("HTTPRequest:")
        _debug("    url: {}".format(url))
        _debug("    method: {}".format(method))
        _debug("    header: {}".format(header))
        _debug("    request_body: {}".format(request_body))
        _debug("    response_header: {}".format(response_header))
        _debug("    to: {}".format(to))
        _debug("    cert: {}".format(cert))
        _debug("    key: {}".format(key))
        _debug("    stime: {}".format(stime))

        response = http_client.fetch(request=req)
        _debug("    response: {}".format(response))
        http_client.close()

        response_body = response.body
        # noinspection PyBroadException
        try:
            response_body = json.loads(response.body)
        except:
            pass

        if response_header:
            return {"header": response.headers, "body": response_body}
        else:
            return response_body
    except Exception, e:
        _error("Fail to Call API, url=%s, method=%s, body=%s" % (url, method, request_body))
        _except(e)
        return None


# Refactoring code
#  Func: backup(_backupFile, _ip, _crt=C_Crt, _key=C_Key)


def backup(backup_file, address, cert=CLIENT_CERTI, key=CLIENT_KEY):
    try:
        result = _request_vnfapi(
            URL_VNFM_BACKUP,
            "POST",
            header=HEADER_VNFM,
            request_body={"vnf_name": V_TYPE, "local_mgmt_ip": address, "type": "local_all"},
            to=60,
            cert=cert,
            key=key,
            stime=1)

        if result is None and type(result) != dict:
            _error("Fail to Backup AXGATE-UTM, Result is Not Dict ret={}".format(result))
            return False, "Invalid Return"

        if result is None or "local_location" not in result:
            _error("Fail to Backup AXGATE-UTM, ret=%s" % str(result))
            return False, "Invalid Return"

        with open(backup_file, 'w') as f:
            f.write(str(result['local_location']))
        return True, None
    except Exception, e:
        _error("Fail to Backup AXGATE-UTM, exc=%s" % str(e))
        _except(e)
        return False, "Exception Occur"


# Not implemented
#  Func: _chk_ip_chg_api(_vnf_ip, _vnf_id=None, _vnf_pass=None, _login=True)


# Refactoring code
#  Func: chk_vnf_bridge(_vnf_ip, _wnic_list, _lan_nic=None, _vnf_id=None)


# noinspection PyUnusedLocal
def chk_vnf_bridge(_vnf_ip, _wnic_list, _lan_nic=None, _vnf_id=None):
    """
    :param _vnf_ip:
    :param _wnic_list:
    :param _lan_nic:
    :param _vnf_id:
    :return: True/False, if list, error-msg
    """

    interfaces = list()
    sid = None

    try:
        sid = login(address=_vnf_ip, username="axroot", password="smflaqhNo1@")
        if sid is None or len(sid) is 0:
            err = "Fail to Get bridge(show interface bridge): /login.cgi, sid(%s)" % sid
            _error("%s" % err)
            return False, interfaces, err

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show interface bridge" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % _vnf_ip),
            http_method="POST",
            http_body=str("cmd=show interface bridge"),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to Get bridge(show interface bridge): /exec.cgi"
            _error(err)
            return False, interfaces, err

        result = int()
        doarping = False
        rows = str(body).splitlines()

        found = False

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "port":
                found = True

                has_lan = False
                has_wan = False
                wan_interfaces = list()

                ports = columns[1].split(",")
                for ports_offset in range(0, len(ports)):
                    if ports[ports_offset] == _lan_nic:
                        has_lan = True
                    if ports[ports_offset] in _wnic_list:
                        has_wan = True
                        _info(" - Bridge ON, port=%s" % (str(ports[ports_offset])))
                        if _lan_nic is None:
                            interfaces.append(ports[ports_offset])
                        else:
                            wan_interfaces.append(ports[ports_offset])
                    else:
                        _warn(" - No Bridge's Port IFName, port=%s" % str(ports[ports_offset]))
                if has_lan and has_wan:
                    interfaces += wan_interfaces

        if result is not 1:
            err = "Fail to Get bridge(show interface bridge): /exec.cgi"
            _error("%s" % err)
            return False, interfaces, err

        return True, interfaces, None
    except Exception as _exc:
        _warn("Fail to Get bridge")
        _except(_exc)
        return False, interfaces, str(_exc)
        # finally:
        #     if sid is not None:
        #         logout(address=_vnf_ip, session_id=sid)


# Not implemented
#  Func: chk_vnf_openvpn(address, _vnf_id, _wnic_list)


# Not implemented
#  Func: chk_vnf_qos(_vnf_ip, _vnf_id, _wnic_list)


# Not implemented
#  Func: _get_vnf_if_id(_vnf_ip, _wnic_list, _vnf_id=None)


# New implemented
#  Func: _get_vnf_ifnames(address, wan_nics, username=None, password=None)


def _get_vnf_ifnames(wan_nics, address, username=None, password=None):
    ifnames = list()
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to Get VNF interface names(show interface): /login.cgi, sid(%s)" % sid
            _error("%s" % err)
            return False, ifnames, err

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show interface" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=str("cmd=show interface"),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to Get VNF interface names(show interface): /exec.cgi"
            _error(err)
            return False, ifnames, err

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "ifname":
                ifname = str(columns[1]).strip()
                if ifname in wan_nics:
                    ifnames.append(ifname)

        if result is not 1:
            err = "Fail to Get VNF interface names(show interface): /exec.cgi"
            _error("%s" % err)
            return False, ifnames, err
    except Exception as _exc:
        _warn("Fail to Get VNF interface names")
        _except(_exc)
        return False, ifnames, str(_exc)
    # finally:
    #     if sid is not None:
    #         logout(address=address, session_id=sid)

    return True, ifnames, None


# New implemented
#  Func: _get_vnf_ethernets(address, username=None, password=None)


def _get_vnf_ethernets(address, username=None, password=None):
    ethernets = list()
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to Get VNF ethernets(show interface): /login.cgi, sid(%s)" % sid
            _error("%s" % err)
            return None

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show interface" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=str("cmd=show interface"),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to Get VNF ethernets(show interface): /exec.cgi"
            _error(err)
            return None

        rows = str(body).splitlines()
        ethernet = None

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                if int(columns[1]) is not 1:
                    err = "Fail to Get VNF ethernets(show interface): /exec.cgi"
                    _error("%s" % err)
                    return None

            if columns[0] == "ifname" or \
                            columns[0] == "type" or \
                            columns[0] == "primary" or \
                            columns[0] == "secondary" or \
                            columns[0] == "port" or \
                            columns[0] == "multi-port" or \
                            columns[0] == "link-check" or \
                            columns[0] == "status" or \
                            columns[0] == "protocol":
                if ethernet is None:
                    ethernet = dict()

                ethernet[columns[0]] = columns[1]

                if ethernet is not None and len(ethernet) is 9:
                    ethernets.append(ethernet)
                    ethernet = None
        return ethernets
    except Exception as _exc:
        _warn("Fail to Get VNF ethernets")
        _except(_exc)
        return None
        # finally:
        #     if sid is not None:
        #         logout(address=address, session_id=sid)


# Not implemented
#  Func: _get_vnf_dhcp_id(_vnf_ip, _vnf_id, _wnic_list)


# Not implemented
#  Func:_get_vnf_if_ipinfo(_vnf_ip, _vnf_id, _wnic_list)


# New implemented
#  Func: _get_vnf_ipaddress(address, wan_nics, username=None, password=None)


def _get_vnf_ipaddress(address, wan_nics, username=None, password=None):
    ipaddrs = dict()
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to Get VNF Ip address(show interface): /login.cgi, sid(%s)" % sid
            _error("%s" % err)
            return False, ipaddrs, err

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show interface" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=str("cmd=show interface"),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to Get VNF Ip address(show interface): /exec.cgi"
            _error(err)
            return False, ipaddrs, err

        result = int()
        rows = str(body).splitlines()

        ifname = None

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "ifname":
                ifname = str(columns[1].strip())
            elif columns[0] == "primary" or columns[0] == "secondary":
                address_cidr = str(columns[1]).split("/")

                if len(address_cidr) is not 2:
                    continue

                if ifname in wan_nics:
                    if ifname in ipaddrs and type(ipaddrs[ifname]) == list:
                        ipaddrs[ifname].append(
                            {
                                "_addr": str(address_cidr[0]),
                                "_prefixlen": str(address_cidr[1])
                            }
                        )
                    else:
                        ipaddrs[ifname] = [
                            {
                                "_addr": address_cidr[0],
                                "_prefixlen": address_cidr[1]
                            }
                        ]

        if result is not 1:
            err = "Fail to Get VNF Ip address(show interface): /exec.cgi"
            _error("%s" % err)
            return False, ipaddrs, err
    except Exception as _exc:
        _warn("Fail to Get VNF Ip address")
        _except(_exc)
        return False, ipaddrs, str(_exc)
    # finally:
    #     if sid is not None:
    #         logout(address=address, session_id=sid)

    return True, ipaddrs, None


# Not implemented
#  Func:_get_vnf_route_map(_vnf_ip, _vnf_id=None)


# Not implemented
#  Func:_get_vnf_route_info(_vnf_ip, _mapName, _vnf_id=None)


# New implemented
#  Func: _get_vnf_route(address, username=None, password=None)


def _get_vnf_route(address, username=None, password=None):
    routes = list()
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to Get VNF Get route info(show ip route): /login.cgi, sid(%s)" % sid
            _error("%s" % err)
            return False, None, err

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show ip route" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=str("cmd=show ip route"),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to Get VNF Get route info(show ip route): /exec.cgi"
            _error(err)
            return False, None, err

        result = int()
        route = dict()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
                if result is not 1:
                    err = "Fail to Get VNF Ip address(show ip route): /exec.cgi"
                    _error("%s" % err)
                    return False, None, err

            if columns[0] == "type" or \
                            columns[0] == "dest-ip" or \
                            columns[0] == "route-ip" or \
                            columns[0] == "ifname" or \
                            columns[0] == "distance" or \
                            columns[0] == "route-status":
                route[columns[0]] = columns[1]

            if len(route) is 6:
                routes.append(route)
                route = dict()

        if result is not 1:
            err = "Fail to Get VNF Ip address(show ip route): /exec.cgi"
            _error("%s" % err)
            return False, None, err

        return True, routes, None
    except Exception as _exc:
        _warn("Fail to Get VNF Ip address")
        _except(_exc)
        return False, None, str(_exc)
        # finally:
        #     if sid is not None:
        #         logout(address=address, session_id=sid)


# Refactoring code
#  Func: get_vnf_all_route_info(_vnf_ip,
#                               _wan_nic_list,
#                               _static_gw_list=None,
#                               _chkExist=None,
#                               _vnf_id=None)


def get_vnf_all_route_info(_vnf_ip, _wan_nic_list, _static_gw_list=None, _chkExist=None, _vnf_id=None):
    # {
    #     "def": [
    #         {
    #             "_name": _name,
    #             "_destAddr": _destAddr,
    #             '_gwList': _gwList,
    #             "_dnetmask": _dnetmask,
    #             "_metric": _metric,
    #             "_dnetPrefix": _dnetPrefix,
    #             "_tbNum": _tbNum
    #         }
    #     ],
    #     "usr": [
    #         {
    #             "_name": _name,
    #             "_destAddr": _destAddr,
    #             '_gwList': _gwList,
    #             "_dnetmask": _dnetmask,
    #             "_metric": _metric,
    #             "_dnetPrefix": _dnetPrefix,
    #             "_tbNum": _tbNum
    #         }
    #     ]
    # }

    _debug("Input parameter")
    _debug("    _vnf_ip: %s" % _vnf_ip)
    _debug("    _wan_nic_list: {}".format(_wan_nic_list))
    _debug("    _static_gw_list: {}".format(_static_gw_list))
    _debug("    _chkExist: {}".format(_chkExist))
    _debug("    _vnf_id: {}".format(_vnf_id))

    _defRouteTable = list()
    _usrRouteTable = list()

    try:
        _vnf_id = (DEF_ID if _vnf_id is None else _vnf_id)

        _ret, _routes, _err = _get_vnf_route(address=_vnf_ip, username=_vnf_id, password=DEF_PASS)
        _debug("_get_vnf_route, Return:")
        _debug("    _ret: {}".format(_ret))
        _debug("    _routes: {}".format(_routes))
        _debug("    _err: {}".format(_err))

        if _ret is not True:
            _error("Fail to Get VNF-ALL-ROUTE, Route Get Error, err=%s" % (str(_err)))
            return False, None, "Route Get Error, err=%s" % str(_err)

        for _rInfo in _routes:
            _name = str("main")
            _destAddr, _dnetmask = str(_rInfo["dest-ip"]).split("/")
            _dnetmask = _dnetPrefix = cidr_to_netmask(_dnetmask)
            _metric = str(_rInfo["distance"])
            _gwList = list()
            # _gwList.append(str(_rInfo["route-ip"]))
            _gwList.append("%s/%s" % (str(_rInfo["route-ip"]), str(_rInfo["ifname"])))

            _gwLen = len(_gwList)
            for _gwInfo in _gwList:
                _gIP = str(_gwInfo)
                _gIF = str(_rInfo["ifname"])

                if _gIF in _wan_nic_list:
                    _route = {
                        "_name": _name,
                        "_destAddr": _destAddr,
                        "_gwList": _gwList,
                        "_dnetmask": _dnetmask,
                        "_metric": _metric,
                        "_dnetPrefix": _dnetPrefix,
                        "_tbNum": 0
                    }

                    # default GW
                    if _gwLen is 1 and _destAddr == "0.0.0.0":
                        _staticGW = (
                            lambda x: x[_gIF]['gw']
                            if (_static_gw_list is not None) and _gIF in x else None)(_static_gw_list)
                        # dhcp def GW
                        if _staticGW is None:
                            _defRouteTable.append(_route)
                            if type(_chkExist) == list and _gIF in _chkExist:
                                _chkExist.remove(_gIF)
                            break
                        # static def gw
                        elif str(_gIP) == str(_staticGW):
                            _defRouteTable.append(_route)
                            if type(_chkExist) == list and _gIF in _chkExist:
                                _chkExist.remove(_gIF)
                            break
                        _warn("     User-Default Route, gIP=%s, prevGIP=%s" % (_gIP, _staticGW))
                    # user GW
                    _warn("     User Route, _gw=%s, dstAddr=%s" % (str(_gwList), str(_destAddr)))
                    _usrRouteTable.append(_route)
                    break
        return True, {'def': _defRouteTable, 'usr': _usrRouteTable}, None
    except Exception as _exc:
        _error("Fail to Get VNF-ROUTE-INFO, exc=%s" % str(_exc))
        _except(_exc)
        return False, None, str(_exc)


# New implemented
#  Func: _get_vnf_def_route(address, username, password)


def _get_vnf_def_route(address, username, password):
    _default_route = dict()
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF Get default route(show ip route 0.0.0.0: /login.cgi, sid(%s)" % sid
            _error("%s" % err)
            return False, _default_route

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=show ip route 0.0.0.0" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        _http_body = str("cmd=show ip route 0.0.0.0")

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF Get default route(show ip route 0.0.0.0): /exec.cgi"
            _error(err)
            return False, _default_route

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
                if result is not 1:
                    err = "Fail to VNF Get default route(show ip route 0.0.0.0): /exec.cgi"
                    _error("%s" % err)
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))
            elif columns[0] == "type" or \
                    columns[0] == "dest-ip" or \
                    columns[0] == "route-ip" or \
                    columns[0] == "ifname" or \
                    columns[0] == "distance" or \
                    columns[0] == "route-status":
                _default_route[columns[0]] = columns[1]

        if result is not 1:
            err = "Fail to VNF Get default route(show ip route 0.0.0.0): /exec.cgi"
            _error("%s" % err)
            return False, _default_route

        return True, _default_route
    except Exception as _exc:
        _warn("Fail to VNF Get default route")
        _except(_exc)
        return False, _default_route
        # finally:
        #     if sid is not None:
        #         logout(address=address, session_id=sid)


# New implemented
#  Func: _change_vnf_def_route(address, username, password, ifname, distance)


def _change_vnf_def_route(address, username, password, no_ip_route=None, new_ip_route=None):
    # if no_ip_route is None or not no_ip_route:
    #     _error("no_ip_route string is None: %s" % no_ip_route)
    #     return False
    if new_ip_route is None or not new_ip_route:
        _error("new_ip_route string is None: %s" % new_ip_route)
        return False

    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF Change route(configure terminal" \
                  "%s" \
                  "%s" \
                  "end" \
                  "write): /login.cgi, sid(%s)" % (
                      no_ip_route, new_ip_route,
                      sid)
            _error("%s" % err)
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=configure terminal
        #             no ip route {address/cidr} {ifname} {distance}
        #             ip route {address/cidr} {ifname} {distance}
        #             end" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        if no_ip_route is None or len(no_ip_route) == 0:
            _http_body = str("cmd=configure terminal\\n"
                             "%s\\n"
                             "end\\n"
                             "write" % new_ip_route)
        else:
            _http_body = str("cmd=configure terminal\\n"
                             "%s\\n"
                             "%s\\n"
                             "end\\n"
                             "write" % (no_ip_route, new_ip_route))
        _http_body = _http_body.replace('\\n', "%0A")

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            _error(_http_body)
            return False

        result = int()
        _message = str()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
                if result is not 1:
                    err = _http_body
                    _error("%s" % err)
                    _error("  Code: '%s'" % code)
                    _error("  Headers: '%s'" % headers)
                    _error("  Body: '%s'" % body)
            elif columns[0] == "message":
                _message = str(columns[1])

        if _message.strip() == "No matching route to delete" or \
                        _message.strip() == "none":
            return True

        if result is 1 and _message.strip() != "No matching route to delete":
            _error("Fail to VNF Change route(%s): %s" % (_http_body, _message))
            return False

        return True
    except Exception as _exc:
        _warn("Fail to VNF Change route")
        _except(_exc)
        return False
        # finally:
        #     if sid is not None:
        #         logout(address=address, session_id=sid)


# New implemented
#  Func: _change_vnf_route(address, username, password, route_address, new_route_address, ifname, distance)


def _change_vnf_route(address, username, password, route_address, new_route_address, ifname, distance):
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF Change route(configure terminal" \
                  "no ip route %s %s %d" \
                  "ip route %s %s %d" \
                  "end" \
                  "write): /login.cgi, sid(%s)" % (
                      route_address, ifname, int(distance),
                      new_route_address, ifname, int(distance),
                      sid)
            _error("%s" % err)
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=configure terminal
        #             no ip route {address/cidr} {ifname} {distance}
        #             ip route {address/cidr} {ifname} {distance}
        #             end" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        _http_body = str("cmd=configure terminal\\n"
                         "no ip route %s %s %d\\n"
                         "ip route %s %s %d\\n"
                         "end\\n"
                         "write" % (
                             route_address, ifname, int(distance),
                             new_route_address, ifname, int(distance)))
        _http_body = _http_body.replace('\\n', "%0A")

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF Change route(configure terminal" \
                  "no ip route %s %s %d" \
                  "ip route %s %s %d" \
                  "end" \
                  "write): /exec.cgi" % (
                      route_address, ifname, int(distance),
                      new_route_address, ifname, int(distance))
            _error(err)
            return False

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
                if result is not 1:
                    err = "Fail to VNF Chagne route(configure terminal" \
                          "no ip route %s %s %d" \
                          "ip route %s %s %d" \
                          "end" \
                          "write): /exec.cgi" % (
                              route_address, ifname, int(distance),
                              new_route_address, ifname, int(distance)
                          )
                    _error("%s" % err)
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))

        if result is not 1:
            err = "Fail to VNF Change route(configure terminal" \
                  "no ip route %s %s %d" \
                  "ip route %s %s %d" \
                  "end" \
                  "write): /exec.cgi" % (
                      route_address, ifname, int(distance),
                      new_route_address, ifname, int(distance))
            _error("%s" % err)
            return False

        return True
    except Exception as _exc:
        _warn("Fail to VNF Change route")
        _except(_exc)
        return False
        # finally:
        #     if sid is not None:
        #         logout(address=address, session_id=sid)


# New implemented
#  Func: _delete_vnf_route(address, username=None, password=None)


def _delete_vnf_route(address, username, password, route_address, ifname, distance):
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF No route(configure terminal" \
                  "no ip route %s %s %d" \
                  "end" \
                  "write): /login.cgi, sid(%s)" % (
                      route_address, ifname, int(distance), sid)
            _error("%s" % err)
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=configure terminal
        #             no ip route {address/cidr} {ifname} {distance}
        #             end" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        _http_body = str("cmd=configure terminal\\n"
                         "no ip route %s %s %d\\n"
                         "end\\n"
                         "write" % (route_address, ifname, int(distance)))
        _http_body = _http_body.replace('\\n', "%0A")

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF No route(configure terminal" \
                  "no ip route %s %s %d" \
                  "end" \
                  "write): /exec.cgi" % (route_address, ifname, int(distance))
            _error(err)
            return False

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
                if result is not 1:
                    err = "Fail to VNF No route(configure terminal" \
                          "no ip route %s %s %d" \
                          "end" \
                          "write): /exec.cgi" % (route_address, ifname, int(distance))
                    _error("%s" % err)
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))

        if result is not 1:
            err = "Fail to VNF No route(configure terminal" \
                  "no ip route %s %s %d" \
                  "end" \
                  "write): /exec.cgi" % (route_address, ifname, int(distance))
            _error("%s" % err)
            return False

        return True
    except Exception as _exc:
        _warn("Fail to VNF No route")
        _except(_exc)
        return False
        # finally:
        #     if sid is not None:
        #         logout(address=address, session_id=sid)


# New implemented
#  Func: _delete_vnf_route(address, username=None, password=None)


def _del_vnf_route(address, username, password, route_address, ifname, distance):
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF Del route(configure terminal" \
                  "no ip route 0.0.0.0/0 %s" \
                  "end" \
                  "write): /login.cgi, sid(%s)" % (ifname, sid)
            _error("%s" % err)
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=configure terminal
        #             no ip route {address/cidr} {ifname} {distance}
        #             end" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        _http_body = str("cmd=configure terminal\\n"
                         "no ip route 0.0.0.0/0 %s\\n"
                         "end\\n"
                         "write" % ifname)
        _http_body = _http_body.replace('\\n', "%0A")

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF Del route(configure terminal\n" \
                  "no ip route 0.0.0.0/0 %s\n" \
                  "end\n" \
                  "write): /exec.cgi" % ifname
            _error(err)
            return False

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
                if result is not 1:
                    err = "Fail to VNF Del route(configure terminal" \
                          "no ip route 0.0.0.0/0 %s" \
                          "end" \
                          "write): /exec.cgi" % ifname
                    _error("%s" % err)
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))

        if result is not 1:
            err = "Fail to VNF Del route(configure terminal" \
                  "no ip route 0.0.0.0/0 %s" \
                  "end" \
                  "write): /exec.cgi" % ifname
            _error("%s" % err)
            return False

        return True
    except Exception as _exc:
        _warn("Fail to VNF Del route")
        _except(_exc)
        return False
        # finally:
        #     if sid is not None:
        #         logout(address=address, session_id=sid)


# New implemented
#  Func: _get_brname_by_ethernet(address,
#                                username,
#                                password,
#                                ifname)


def _get_brname_by_ethernet(address, username, password, ifname):
    try:
        _http_body = str("cmd=show interface %s bridge-name" % ifname)
        # _http_body = str("show interface %s bridge-name" % ifname)
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF Get Bridge-name by Ethernet-name(%s): /login.cgi, sid(%s)" % (_http_body, sid)
            _error("%s" % err)
            return False, err, None

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF Get Bridge-name by Ethernet-name(%s): /exec.cgi" % _http_body
            _error(err)
            return False, err, None

        _debug("Succeed to VNF Get Bridge-name by Ethernet-name(%s): /exec.cgi" % _http_body)
        _debug("Body:%s" % str(body))

        result = int()
        rows = str(body).splitlines()

        _ifname = None
        _message = None

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                _debug("columns: %s" % str(columns))
                _message = str(columns)
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))
            elif columns[0] == "ifname":
                _ifname = columns[1]

        if result is not 1:
            err = "Fail to VNF Get Bridge-name by Ethernet-name(%s): /exec.cgi: %s" % (_http_body, _message)
            _error(err)
            _error("  Code: '%s'" % code)
            _error("  Headers: '%s'" % headers)
            _error("  Body: '%s'" % body)
            return False, err, None

        _debug("Succeed to VNF Get Bridge-name by Ethernet-name:{}".format(_ifname))

        return True, None, _ifname
    except Exception as _exc:
        _warn("Fail to VNF Get Bridge-name by Ethernet-name")
        _except(_exc)
        return False, "Fail to VNF Get Bridge-name by Ethernet-name", None


# New implemented
#  Func: _setup_vnf_ip(address,
#                      username,
#                      password,
#                      ifname,
#                      ipaddress,
#                      gw,
#                      lk_interval,
#                      lk_failcount,
#                      lk_proto,
#                      lk_target):


def _setup_vnf_ip(address, username, password, ifname, ipaddress, gw, lk_interval, lk_failcount, lk_proto, lk_target):
    sid = None

    _debug("ifname: %s" % ifname)
    _debug("ipaddress: %s" % ipaddress)

    _cmd_link_check = None

    if ipaddress == "dhcp":
        _cmd_link_check = str("link-check %s %s %s" % (lk_interval, lk_failcount, lk_proto))
    else:
        if lk_target is not None:
            _cmd_link_check = str("link-check %s %s %s %s" % (lk_interval, lk_failcount, lk_proto, lk_target))

    # if ipaddress != "dhcp":
    #     if gw is None or not gw:
    #         _error("Static ip configuration, need to setup the gateway")
    #         return False

    if gw is None:
        if _cmd_link_check is None:
            _http_body = str("cmd=configure terminal\\n"
                             "interface %s\\n"
                             "no ip gateway\\n"
                             "ip address %s\\n"
                             "no shutdown\\n"
                             "security-zone uplink_main\\n"
                             "end\\n"
                             "write" % (ifname, ipaddress))
        else:
            _http_body = str("cmd=configure terminal\\n"
                             "interface %s\\n"
                             "no ip gateway\\n"
                             "ip address %s\\n"
                             "%s\\n"
                             "no shutdown\\n"
                             "security-zone uplink_main\\n"
                             "end\\n"
                             "write" % (ifname, ipaddress, _cmd_link_check))
    else:
        if _cmd_link_check is None:
            _http_body = str("cmd=configure terminal\\n"
                             "interface %s\\n"
                             "no ip gateway\\n"
                             "ip address %s\\n"
                             "ip gateway %s\\n"
                             "no shutdown\\n"
                             "security-zone uplink_main\\n"
                             "end\\n"
                             "write" % (ifname, ipaddress, gw))
        else:
            _http_body = str("cmd=configure terminal\\n"
                             "interface %s\\n"
                             "no ip gateway\\n"
                             "ip address %s\\n"
                             "ip gateway %s\\n"
                             "%s\\n"
                             "no shutdown\\n"
                             "security-zone uplink_main\\n"
                             "end\\n"
                             "write" % (ifname, ipaddress, gw, _cmd_link_check))

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF Setup ipaddress(%s): /login.cgi, sid(%s)" % (_http_body, sid)
            _error("%s" % err)
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=configure terminal
        #             interface {ifname}
        #             ip address {ipaddress}
        #             link-check {check interval} {fail count} {arp|icmp} {address}
        #             no shutdown
        #             end" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        # if ipaddress == "dhcp":
        #     _http_body = str("cmd=configure terminal\\n"
        #                      "interface %s\\n"
        #                      "no ip gateway\\n"
        #                      "ip address %s\\n"
        #                      "%s\\n"
        #                      "no shutdown\\n"
        #                      "end\\n"
        #                      "write" % (ifname, ipaddress, _cmd_link_check))
        # else:
        #     _http_body = str("cmd=configure terminal\\n"
        #                      "interface %s\\n"
        #                      "no ip gateway\\n"
        #                      "ip address %s\\n"
        #                      "ip gateway %s\\n"
        #                      "%s\\n"
        #                      "no shutdown\\n"
        #                      "end\\n"
        #                      "write" % (ifname, ipaddress, gw, _cmd_link_check))
        _http_body = _http_body.replace('\\n', "%0A")

        _debug("_http_body: %s" % _http_body)

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF Setup ipadress(%s): /exec.cgi" % _http_body
            _error(err)
            return False

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))

        if result is not 1:
            err = "Fail to VNF Setup ipadress(%s): /exec.cgi" % _http_body
            _error(_http_body)
            return False

        return True
    except Exception as _exc:
        _warn("Fail to VNF Setup ipaddress")
        _except(_exc)
        return False
        # finally:
        #     if sid is not None:
        #         logout(address=address, session_id=sid)


# New implemented
#  Func: _setup_vnf_route(address, username, password)


def _setup_vnf_route(address, username, password, route_ip, ifname, distance):
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF Setup route(configure terminal" \
                  "ip route %s %s %d" \
                  "end): /login.cgi, sid(%s)" % (route_ip, ifname, int(distance), sid)
            _error("%s" % err)
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=configure terminal
        #             ip route {route ip} {ifname} {distance}
        #             end" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        _http_body = str("cmd=configure terminal\\n"
                         "ip route %s %s %d\\n"
                         "end\\n"
                         "write" % (route_ip, ifname, int(distance)))
        _http_body = _http_body.replace('\\n', "%0A")

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF Setup route(configure terminal" \
                  "ip route %s %s %d" \
                  "end" \
                  "write): /exec.cgi" % (route_ip, ifname, distance)
            _error(err)
            return False

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))

        if result is not 1:
            err = "Fail to VNF Setup route(configure terminal" \
                  "ip route %s %s %d" \
                  "end" \
                  "write): /exec.cgi" % (route_ip, ifname, distance)
            _error(err)
            return False

        return True
    except Exception as _exc:
        _warn("Fail to VNF Setup route")
        _except(_exc)
        return False
        # finally:
        #     if sid is not None:
        #         logout(address=address, session_id=sid)


# New implemented
#  Func: _add_vnf_route(address, username, password)


def _add_vnf_route(address, username, password, route_ip, ifname, distance):
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF ADD route(configure terminal" \
                  "ip route %s %s %d" \
                  "end" \
                  "write): /login.cgi, sid(%s)" % (route_ip, ifname, int(distance), sid)
            _error("%s" % err)
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=configure terminal
        #             ip route {route ip} {ifname} {distance}
        #             end" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        _http_body = str("cmd=configure terminal\\n"
                         "ip route 0.0.0.0/0 %s %d\\n"
                         "end\\n"
                         "write" % (ifname, int(distance)))
        _http_body = _http_body.replace('\\n', "%0A")

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF ADD route(configure terminal" \
                  "ip route 0.0.0.0/0 %s %d" \
                  "end" \
                  "write): /exec.cgi" % (ifname, distance)
            _error(err)
            return False

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))

        if result is not 1:
            err = "Fail to VNF ADD route(configure terminal" \
                  "ip route 0.0.0.0/0 %s %d" \
                  "end" \
                  "write): /exec.cgi" % (ifname, distance)
            _error(err)
            return False

        return True
    except Exception as _exc:
        _warn("Fail to VNF ADD route")
        _except(_exc)
        return False
        # finally:
        #     if sid is not None:
        #         logout(address=address, session_id=sid)


# New implemented
#  Func: _setup_vnf_ifgw(address, username, password, ifname, gw)


def _setup_vnf_ifgw(address, username, password, ifname, gw):
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF IF Gateway(configure terminal" \
                  "interface %s" \
                  "ip gateway %s" \
                  "end" \
                  "write): /login.cgi, sid(%s)" % (ifname, gw, sid)
            _error("%s" % err)
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=configure terminal
        #             interface {ifname}
        #             ip gateway {address}
        #             end" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        _http_body = str("cmd=configure terminal\\n"
                         "interface %s\\n"
                         "ip gateway %s\\n"
                         "end\\n"
                         "write" % (ifname, gw))
        _http_body = _http_body.replace('\\n', "%0A")

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF IF Gateway(configure terminal" \
                  "interface %s" \
                  "ip gateway %s" \
                  "end" \
                  "write): /exec.cgi" % (ifname, gw)
            _error(err)
            return False

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))

        if result is not 1:
            err = "Fail to VNF IF Gateway(configure terminal" \
                  "interface %s" \
                  "ip gateway %s" \
                  "end" \
                  "write): /exec.cgi" % (ifname, gw)
            _error(err)
            return False

        return True
    except Exception as _exc:
        _warn("Fail to VNF IF Gateway")
        _except(_exc)
        return False


# New implemented
#  Func: _setup_vnf_iflink_check(address, username, password, ifname, gw)


def _setup_vnf_iflink_check(address, username, password, ifname, gw):
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF IF Link-check(configure terminal" \
                  "interface %s" \
                  "link-check 3 3 icmp %s" \
                  "end" \
                  "write): /login.cgi, sid(%s)" % (ifname, gw, sid)
            _error("%s" % err)
            return False

        # Example using curl command:
        #
        # curl --request POST \
        # --url "https://{address}:{port}/restrict/exec.cgi" \
        # --header "accept-charset: utf-8" \
        # --header "content-type: application/x-www-form-urlencoded" \
        # --header "Cookie: SessionID={SessionID}" \
        # --data "cmd=configure terminal
        #             interface {ifname}
        #             link-check 3 3 icmp {gateway}
        #             end" -k -vvv

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        if gw == "0.0.0.0":
            _http_body = str("cmd=configure terminal\\n"
                             "interface %s\\n"
                             "link-check 3 3 icmp\\n"
                             "end\\n"
                             "write" % ifname)
        else:
            _http_body = str("cmd=configure terminal\\n"
                             "interface %s\\n"
                             "link-check 3 3 icmp %s\\n"
                             "end\\n"
                             "write" % (ifname, gw))

        _http_body = _http_body.replace('\\n', "%0A")

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF IF Link-check(%s): /exec.cgi" % _http_body
            _error(err)
            return False

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))

        if result is not 1:
            err = "Fail to VNF IF Link-check(%s): /exec.cgi" % _http_body
            _error(err)
            return False

        return True
    except Exception as _exc:
        _warn("Fail to VNF IF Link-check")
        _except(_exc)
        return False


# New implemented
#  Func: _no_ip_address(address, username, password, ifname, ip)


def _no_ip_address(address, username, password, ifname, ip):
    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF No ip address(configure terminal" \
                  "interface %s" \
                  "no ip address %s" \
                  "no ip gateway" \
                  "no link-check" \
                  "shutdown" \
                  "no security-zone" \
                  "end" \
                  "write): /login.cgi, sid(%s)" % (ifname, ip, sid)
            _error("%s" % err)
            return False

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        _http_body = str("cmd=configure terminal\\n"
                         "interface %s\\n"
                         "no ip address %s\\n"
                         "no ip gateway\\n"
                         "no link-check\\n"
                         "shutdown\\n"
                         "no security-zone\\n"
                         "end\\n"
                         "write" % (ifname, ip))
        _http_body = _http_body.replace('\\n', "%0A")

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=_http_body,
            delay_timeout=1
        )

        _debug("response.body: %s" % str(body))

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF No ip address(%s): /exec.cgi" % _http_body
            _error(err)
            return False

        result = int()
        rows = str(body).splitlines()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))

        if result is not 1:
            err = "Fail to VNF No ip address(%s): /exec.cgi" % _http_body
            _error(err)
            return False

        _debug("Succeed: _http_body: %s" % _http_body)

        return True
    except Exception as _exc:
        _warn("Fail to VNF No ip address")
        _except(_exc)
        return False
        # finally:
        #     if sid is not None:
        #         _logout(address=address, session_id=sid)


# New implemented
#  Func: _get_vnf_all_interface(address, username, password)


def _get_vnf_all_interface(address, username, password):
    _interfaces = list()

    sid = None

    try:
        sid = login(address=address, username=username, password=password)
        if sid is None or len(sid) is 0:
            err = "Fail to VNF Get all interface(show interface eth all): /login.cgi, sid(%s)" % sid
            _error("%s" % err)
            return False, _interfaces

        http_client = AxGateHTTPClient()

        http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
        http_client.add_header(name="Accept", value="*/*")
        http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

        err, code, headers, body = http_client.http_request(
            http_url=str("https://%s:443/restrict/exec.cgi" % address),
            http_method="POST",
            http_body=str("cmd=show interface eth all"),
            delay_timeout=1
        )

        if err is True or code is not 200 or headers is None or body is None:
            err = "Fail to VNF Get all interface(show interface eth all): /exec.cgi"
            _error(err)
            return False, _interfaces

        _debug("Succeed to VNF Get all interface(show interface eth all): /exec.cgi")
        _debug("Body:%s" % str(body))

        result = int()
        rows = str(body).splitlines()

        _interface = dict()

        for offset in range(0, len(rows)):
            columns = rows[offset].split(":")

            if len(columns) is not 2:
                continue

            if columns[0] == "result":
                result = int(columns[1])
            elif columns[0] == "message":
                _debug("message: %s" % str(columns[1]))
            elif columns[0] == "ifname" or \
                            columns[0] == "type" or \
                            columns[0] == "primary" or \
                            columns[0] == "secondary" or \
                            columns[0] == "port" or \
                            columns[0] == "multi-port" or \
                            columns[0] == "link-check" or \
                            columns[0] == "status" or \
                            columns[0] == "protocol":
                _interface[columns[0]] = columns[1]

                if len(_interface) == 9:
                    _interfaces.append(_interface)
                    _interface = dict()

        if result is not 1:
            err = "Fail to VNF Get all interface(show interface eth all: /exec.cgi"
            _error(err)
            _error("  Code: '%s'" % code)
            _error("  Headers: '%s'" % headers)
            _error("  Body: '%s'" % body)
            return False, _interfaces

        _debug("Succeed to VNF Get all interface:{}".format(_interfaces))

        return True, _interfaces
    except Exception as _exc:
        _warn("Fail to VNF Get all interface")
        _except(_exc)
        return False, _interfaces
        # finally:
        #     if sid is not None:
        #         _logout(address=address, session_id=sid)


# New implemented
#  Func: cidr_to_netmask(cidr)


def cidr_to_netmask(cidr):
    cidr = int(cidr)
    mask = (0xffffffff >> (32 - cidr)) << (32 - cidr)
    return (str((0xff000000 & mask) >> 24) + '.' +
            str((0x00ff0000 & mask) >> 16) + '.' +
            str((0x0000ff00 & mask) >> 8) + '.' +
            str((0x000000ff & mask)))


# New implemented
#  Func: netmask_to_cidr(netmask)


def netmask_to_cidr(netmask):
    return sum([bin(int(x)).count('1') for x in netmask.split('.')])


# Refactoring code
#  Func: del_dhcp_if(_vnf_ip, _dhcp_if_list, _vnf_id=None)


def del_dhcp_if(_vnf_ip, _dhcp_if_list, _vnf_id=None):
    """
    :param _vnf_ip:
    :param _dhcp_if_list:
    :param _vnf_id:
    :return: Result(True|False), Recover(True|False), Error
    """
    _debug("_vnf_ip: {}".format(_vnf_ip))
    _debug("_dhcp_if_list: {}".format(_dhcp_if_list))
    _debug("_vnf_id: {}".format(_vnf_id))
    _info("This plug-in(AxGate) ignores the steps for the IP-Change API Check")


# Refactoring code
#  Func: del_unuse_if(_vnf_ip, _dhcp_if_list, _vnf_id=None)


def del_unuse_if(_vnf_ip, _dhcp_if_list, _vnf_id=None):
    """
    :param _vnf_ip:
    :param _dhcp_if_list:
    :param _vnf_id:
    :return: Result(True|False), Recover(True|False), Error
    """
    _debug("_vnf_ip: {}".format(_vnf_ip))
    _debug("_dhcp_if_list: {}".format(_dhcp_if_list))
    _debug("_vnf_id: {}".format(_vnf_id))

    try:
        _ret, _get_all_interfaces = _get_vnf_all_interface(
            address=_vnf_ip,
            username=_vnf_id,
            password=DEF_PASS
        )
        _debug("_ret: %s" % str(_ret))
        _debug("_get_all_interfaces:{}".format(_get_all_interfaces))

        if _ret is not True:
            return False, False, "Fail to Get all interfaces"

        _recover = False

        for _interface in _dhcp_if_list:
            _found = False
            _err = True
            _err_message = str()

            for _get_interface in _get_all_interfaces:
                _debug("_get_interface:{}".format(_get_interface))
                if "ifname" in _get_interface:
                    if _get_interface["ifname"] == _interface:
                        _debug("_found is True: %s , %s" % (_get_interface["ifname"], _interface))
                        _recover = True
                        _found = True

                        if _get_interface["type"] == "dhcp":
                            _err = _no_ip_address(
                                address=_vnf_ip,
                                username=_vnf_id,
                                ifname=_interface,
                                ip=str("dhcp")
                            )
                        else:
                            _err = _no_ip_address(
                                address=_vnf_ip,
                                username=_vnf_id,
                                ifname=_interface,
                                ip=_get_interface["primary"]
                            )

                        _debug("_no_ip_adress, _err: %s" % str(_err))

                        if _err is not True:
                            _err_message = "Fail to Del Unuse IF, %s" % str(_get_interface)
                            _error(_err_message)
                            return False, True, _err_message
                        break

            # if _err is not True:
            #     _error(_err_message)
            #     return False, True, _err_message

            if _found is not True:
                _warn("Del Unuse IF, Not found, %s" % _interface)
                continue

        return True, _recover, None

    except Exception as _exc:
        _error("Fail to Del Unuse IF, _exc=%s" % str(_exc))
        _except(_exc)
        return False, None, str(_exc)


# Refactoring code
#  Func: del_dhcp_if(_vnf_ip, _dhcp_if_list, _vnf_id=None)


def chk_list_for_new_wan_ip(_vnf_ip, _vnf_id=None, _vnf_pass=None):
    _vnf_id = (DEF_ID if _vnf_id is None else _vnf_id)
    _vnf_pass = (DEF_PASS if _vnf_pass is None else _vnf_pass)

    _info("This plug-in(AxGate) ignores the steps for the API Check")
    _info("_vnf_ip: %s, _vnf_id: %s, _vnf_pass: %s" % (_vnf_ip, _vnf_id, _vnf_pass))

    return _ChkWanIPChg.ITEM_LIST_WITH_API


# Refactoring code
#  Func: create_chk_new_wan_ip(_ip, _wanNicList, _prevStaticWanInfo, _id=None, _pass=None)


def create_chk_new_wan_ip(_ip, _wan_nic_list, _prev_static_wan_info, _id=None, _pass=None):
    _id = (DEF_ID if _id is None else _id)
    _pass = (DEF_PASS if _pass is None else _pass)
    return _ChkWanIPChg(_ip, _wan_nic_list, _prev_static_wan_info, _id, _pass)


# Refactoring code
#  Func: run_list_for_new_wan_ip(_vnf_ip, _vnf_id=None, _vnf_pass=None)


def run_list_for_new_wan_ip(_vnf_ip, _vnf_id=None, _vnf_pass=None):
    _vnf_id = (DEF_ID if _vnf_id is None else _vnf_id)
    _vnf_pass = (DEF_PASS if _vnf_pass is None else _vnf_pass)

    _info("This plug-in(AxGate) ignores the steps for the API Check")
    _info("_vnf_ip: %s, _vnf_id: %s, _vnf_pass: %s" % (_vnf_ip, _vnf_id, _vnf_pass))

    return _RunWanIpChg.ITEM_LIST_WITH_API


# Refactoring code
#  Func: create_run_new_wan_ip(utm_ip,
#                              _bak_file,
#                              _tmp_if_file,
#                              _tmp_dr_file,
#                              _tmp_ur_file,
#                              _tmp_rr_file,
#                              _tmp_arp_file,
#                              new_wan_info,
#                              prev_static_wan_info,
#                              utm_id=None,
#                              utm_pass=None)


def create_run_new_wan_ip(utm_ip,
                          _bak_file,
                          _tmp_if_file,
                          _tmp_dr_file,
                          _tmp_ur_file,
                          _tmp_rr_file,
                          _tmp_arp_file,
                          new_wan_info,
                          prev_static_wan_info,
                          utm_id=None,
                          utm_pass=None):
    if utm_id is None:
        utm_id = DEF_ID

    if utm_pass is None:
        utm_pass = DEF_PASS

    return _RunWanIpChg(utm_ip,
                        _bak_file,
                        _tmp_if_file,
                        _tmp_dr_file,
                        _tmp_ur_file,
                        _tmp_rr_file,
                        _tmp_arp_file,
                        new_wan_info,
                        prev_static_wan_info,
                        utm_id,
                        utm_pass)


# Refactoring code
#  Func: chk_list_for_new_lan_ip()


def chk_list_for_new_lan_ip():
    return _ChkLanIPChg.ITEM_LIST


# Refactoring code
#  Func: create_chk_new_lan_ip(_ip, _lan_nic, _wan_nic_list=None, _id=None, _pass=None)


def create_chk_new_lan_ip(_ip, _lan_nic, _wan_nic_list=None, _id=None, _pass=None):
    _id = (DEF_ID if _id is None else _id)
    _pass = (DEF_PASS if _pass is None else _pass)

    return _ChkLanIPChg(_ip, _lan_nic, _wan_nic_list, _id, _pass)


# Refactoring code
#  Func: run_list_for_new_lan_ip()


def run_list_for_new_lan_ip():
    return _RunLanIpChg.ITEM_LIST


# Refactoring code
#  Func: create_run_new_lan_ip(utm_ip, _bak_file, _new_lan_info, utm_id=None, utm_pass=None)


def create_run_new_lan_ip(utm_ip, _bak_file, _new_lan_info, utm_id=None, utm_pass=None):
    if utm_id is None:
        utm_id = DEF_ID

    if utm_pass is None:
        utm_pass = DEF_PASS

    return _RunLanIpChg(utm_ip, _bak_file, _new_lan_info, utm_id, utm_pass)


# Refactoring code
#  Func: create_vnf_restore(_vnf_ip, _bak_file)


def create_vnf_restore(_vnf_ip, _bak_file):
    return _RunRestore(_vnf_ip, _bak_file)


# Refactoring code
#  Func: add_vnf_ip(_vnf_ip, _is_dhcp, _host_br, _ip=None, _mask=None, _mac=None, _vnf_id=None)


def add_vnf_ip(_vnf_ip, _is_dhcp, _host_br, _ip=None, _mask=None, _mac=None, _vnf_id=None):
    _debug("_vnf_ip: %s" % _vnf_ip)
    _debug("_is_dhcp: %s" % _is_dhcp)
    _debug("_host_br: %s" % _host_br)
    _debug("_ip: %s" % _ip)
    _debug("_mask: %s" % _mask)
    # _debug("_gw: %s" % _gw)
    _debug("_mac: %s" % _mac)
    _debug("_vnf_id: %s" % _vnf_ip)

    _vnf_id = (DEF_ID if _vnf_id is None else _vnf_id)

    try:
        _utm_nic = get_nic(_host_br)

        if _utm_nic is None:
            _error("Fail to Add VNF-IP, NIC Convert Error, br=%s" % str(_host_br))
            return False, "NIC Convert Error, br=%s" % str(_host_br)

        if _is_dhcp:
            _ret = _setup_vnf_ip(
                address=_vnf_ip,
                username=_vnf_id,
                password=DEF_PASS,
                ifname=_utm_nic,
                ipaddress="dhcp",
                gw=None,
                lk_interval=str("3"),
                lk_failcount=str("3"),
                lk_proto=str("icmp"),
                lk_target=None
            )
        else:
            _mask = IPv4Network("%s/%s" % (_ip, _mask)).prefixlen
            _ret = _setup_vnf_ip(
                address=_vnf_ip,
                username=_vnf_id,
                password=DEF_PASS,
                ifname=_utm_nic,
                ipaddress=str("%s/%s" % (_ip, _mask)),
                # gw=str("%s" % _gw),
                gw=None,
                lk_interval=str("3"),
                lk_failcount=str("3"),
                lk_proto=str("icmp"),
                lk_target=None
                # lk_target=str("%s" % _gw)
            )

        if _ret is not True:
            _error("Fail to Add VNF-IP, Invalid API Return, ret=%s" % str(_ret))
            return False, "Invalid API Return"

        return True, None
    except Exception as _exc:
        _error("Fail to Add VNF-IP, exc=%s" % str(_exc))
        _except(_exc)
        return False, str(_exc)


# Refactoring code
#  Func: add_vnf_route(_vnf_ip, _is_dhcp, _host_br, _gw=None, _table=None, _metric=None, _vnf_id=None)


def add_vnf_route(_vnf_ip, _is_dhcp, _host_br, _gw=None, _table=None, _metric=None, _vnf_id=None):
    """
    :param _vnf_ip:
    :param _is_dhcp:
    :param _host_br:
    :param _gw:
    :param _table:
    :param _metric:
    :param _vnf_id:
    :return: True/False, error-msg
    """

    _vnf_id = (DEF_ID if _vnf_id is None else _vnf_id)

    try:
        _table = ("main" if _table is None else _table)
        _gw = ("0.0.0.0" if _is_dhcp else _gw)
        _nic = get_nic(_host_br)
        _metric = ("0" if _metric is None else _metric)

        if _table is None or not str(_table).strip():
            _error("Fail to Add VNF-ROUTE, No Table Name")
            return False, "No Table Name"

        try:
            IPv4Network(_gw)
        except Exception as _exc1:
            _error("Fail to Add VNF-ROUTE, Invalid GW, gw=%s" % (str(_gw)))
            _except(_exc1)
            return False, "Invalid GW, gw=%s" % (str(_gw))

        if _nic is None:
            _error("Fail to Add VNF-ROUTE, NIC Convert Error, br=%s" % str(_host_br))
            return False, "NIC Convert Error, br=%s" % str(_host_br)

        try:
            int(_metric)
        except Exception as _exc1:
            _error("Fail to Add VNF-ROUTE, Invalid Metric, metric=%s" % str(_metric))
            _except(_exc1)
            return False, "Invalid Metric, metric=%s" % str(_metric)

        _ret = _add_vnf_route(
            address=_vnf_ip,
            username=_vnf_id,
            password=DEF_PASS,
            route_ip=_gw,
            ifname=_nic,
            distance=int(_metric)
        )

        if _ret is not True:
            _error("Fail to Add VNF-ROUTE, Invalid API Return, ret=%s" % str(_ret))
            return False, "Invalid API Return: Add VNF-ROUTE"

        if _is_dhcp is not True:
            _ret = _setup_vnf_ifgw(
                address=_vnf_ip,
                username=_vnf_id,
                password=DEF_PASS,
                ifname=_nic,
                gw=_gw
            )

            if _ret is not True:
                _error("Fail to Setup Interface-%s, Gateway(%s), Invalid API Return, ret=%s" % (
                    str(_nic), str(_gw), str(_ret)))
                return False, "Invalid API Return: Add IF Gateway"

        _ret = _setup_vnf_iflink_check(
            address=_vnf_ip,
            username=_vnf_id,
            password=DEF_PASS,
            ifname=_nic,
            gw=_gw
        )

        if _ret is not True:
            _error("Fail to Setup Interface-%s, Link-check(%s), Invalid API Return, ret=%s" %
                   (str(_nic), str(_gw), str(_ret)))
            return False, "Invalid API Return: Add IF Link-check"

        return True, None
    except Exception as _exc:
        _error("Fail to Add VNF-ROUTE, exc=%s" % str(_exc))
        _except(_exc)
        return False, str(_exc)


# Refactoring code
#  Func: del_vnf_route(_vnf_ip, _route, _vnf_id=None)


def del_vnf_route(_vnf_ip, _route, _vnf_id=None):
    _vnf_id = (DEF_ID if _vnf_id is None else _vnf_id)

    try:
        __ifParam = []
        for __tmp in _route['_gwList']:
            __ifParam.append(str(__tmp).split('/')[1])
        _ifParam = "<div></div>".join(__ifParam)

        _ret, _get_route = _get_vnf_def_route(
            address=_vnf_ip,
            username=_vnf_id,
            password=DEF_PASS
        )

        if _ret is not True:
            _error(" - Fail to Delete VNF-ROUTE, Get prev default route ret=%s" % str(_ret))
            return False, "Invalid Route-Del Result"

        if _get_route is not None and len(_get_route) > 0 and \
                        "ifname" in _get_route:
            if _get_route["ifname"] == str(_ifParam):
                _netmask_bits = netmask_to_cidr(str(_route["_dnetmask"]))
                _ret = _del_vnf_route(
                    address=_vnf_ip,
                    username=_vnf_id,
                    password=DEF_PASS,
                    route_address=str("%s" % str(_get_route["route-ip"])),
                    ifname=str(_ifParam),
                    distance=str(_route["_metric"])
                )

            if _ret is not True:
                _error(" - Fail to Delete VNF-ROUTE, ret=%s" % str(_ret))
                return False, "Invalid Route-Del Result"
        _debug(" - Route-Del")
        return True, None
    except Exception as _exc:
        _error("Fail to Delete VNF-ROUTE, exc=%s" % str(_exc))
        _except(_exc)
        return False, str(_exc)


# Refactoring code
#  Func: del_vnf_all_route(_vnf_ip, _route_list, _vnf_id=None)


def del_vnf_all_route(_vnf_ip, _route_list, _vnf_id=None):
    _vnf_id = (DEF_ID if _vnf_id is None else _vnf_id)

    try:
        for _route in _route_list:
            _ret, _err = del_vnf_route(_vnf_ip, _route, _vnf_id)
            if _ret is not True:
                return False, _err

        _info("SUCC: Deleted VNF-ALL-Route={}".format(_route_list))
        return True, None
    except Exception as _exc:
        _error("Fail to Delete VNF-ALL-ROUTE, exc=%s" % str(_exc))
        _except(_exc)
        return False, str(_exc)


# Refactoring code
#  Class: _IncProg(threading.Thread)


class _IncProg(threading.Thread):
    def __init__(self, _progmng, _period, _inc, _max=None):
        threading.Thread.__init__(self)

        self._prog = _progmng
        self._run = True
        self._period = _period
        self._inc = _inc
        self._max = _max

    def stop(self):
        if not self._run:
            return
        self._run = False
        sleep(self._period + 0.2)

    def start(self):
        sleep(0.5)
        if not self.isAlive():
            try:
                threading.Thread.start(self)
            except RuntimeError:
                pass

    def run(self):
        while self._run:
            sleep(self._period)
            if not self._run or self._prog.rate() >= 100:
                break
            # noinspection PyBroadException
            try:
                self._prog.inc(self._inc, self._max)
            except Exception:
                pass


# Refactoring code
#  Class: _ProgMng(threading.Thread)


class _ProgMng(threading.Thread):
    ITEM_LIST = []
    PROG_LIST = []

    STAT_COMP = 0
    STAT_RUN = 1
    STAT_UNSUPP = 2
    STAT_ROLLBACK = 2
    STAT_ERR = -1

    def __init__(self):
        threading.Thread.__init__(self)

        self._index = 0
        self._status = self.STAT_RUN
        self._err = None
        self._return = None

        self._incprog = None
        self._rollback = False
        self._subtitle = None

    def _complete(self):
        if self._incprog is not None:
            self._incprog.stop()

        if len(self.PROG_LIST) > self._index:
            self.PROG_LIST[self._index] = 100
        else:
            _warn(
                "  - Invalid Prog Index, prog=%s, idx=%s" % (
                    str(self.PROG_LIST), str(self._index)))

        if len(self.ITEM_LIST) > self._index:
            if len(self.ITEM_LIST) > self._index + 1:
                self._index += 1
            self._subtitle = self.ITEM_LIST[self._index]
            self._itemprog = self.PROG_LIST[self._index]
        else:
            self._subtitle = "No Item"
            self._itemprog = 0

    def _fin_err(self, _err):
        if self._incprog is not None:
            self._incprog.stop()
        if self._rollback:
            self._status = self.STAT_ROLLBACK
        else:
            self._status = self.STAT_ERR
        self._err = str(_err)
        self._return = None

    def _fin_ok(self, _return=None):
        if self._incprog is not None:
            self._incprog.stop()
        self._status = self.STAT_COMP
        self._err = None
        self._return = _return

    def inc(self, _inc, _max=None):
        if len(self.PROG_LIST) > self._index:
            _now_rate = self.PROG_LIST[self._index]
            if _max is None:
                self.PROG_LIST[self._index] = max(0, min(99, _inc + _now_rate))
            else:
                self.PROG_LIST[self._index] = max(0, min(min(_max, (_now_rate + _inc)), 99))
        else:
            _warn(
                "  - Invalid Prog Index, prog=%s, idx=%s" % (
                    str(self.PROG_LIST), str(self._index)))

    def set_rate(self, _rate):
        if len(self.PROG_LIST) > self._index:
            self.PROG_LIST[self._index] = max(0, min(100, _rate))
        else:
            _warn(
                "  - Invalid Prog Index, prog=%s, idx=%s" % (
                    str(self.PROG_LIST), str(self._index)))

    def rate(self):
        if len(self.PROG_LIST) > self._index:
            return self.PROG_LIST[self._index]
        else:
            _warn(
                "  - Invalid Prog Index, prog=%s, idx=%s" % (
                    str(self.PROG_LIST), str(self._index)))
            return -1

    def get_idx(self):
        return self._index

    def item(self):
        if len(self.ITEM_LIST) > self._index:
            return self.ITEM_LIST[self._index]
        else:
            _warn(
                "  - Invalid Prog Index, prog=%s, idx=%s" % (
                    str(self.PROG_LIST), str(self._index)))
            return "No Item"

    def item_list(self):
        return self.ITEM_LIST

    def get_info(self):
        return self._status, self.ITEM_LIST, self.PROG_LIST

    def result(self):
        return self._status, self._return, self._err

    def start_inc(self, _period, _inc, _max=None):
        self._incprog = _IncProg(self, _period, _inc, _max)
        self._incprog.start()

    def stop_inc(self):
        if self._incprog is not None:
            self._incprog.stop()
            self._incprog = None


# Refactoring code
#  Class: _ChkWanIPChg(_ProgMng)


class _ChkWanIPChg(_ProgMng):
    ITEM_LIST_WITHOUT_API = [
        "Bridge",
        "OpenVPN",
        "QoS",
        "IP",
        "RoutingTable Map",
        "Route",
        "Route-Rule",
        "ARP"
    ]
    ITEM_LIST_WITH_API = ['IP-Change API']

    PROG_LIST_WITHOUT_API = [0] * len(ITEM_LIST_WITHOUT_API)
    PROG_LIST_WITH_API = [0] * len(ITEM_LIST_WITH_API)

    def __init__(self, _ip, _wan_nic_list, prev_static_wan_info, _id=None, _pass=None):
        _ProgMng.__init__(self)

        self._ip = _ip
        self._id = (DEF_ID if _id is None else _id)
        self._pass = (DEF_PASS if _pass is None else _pass)
        self._wan_nic_list = _wan_nic_list
        self.prevStaticWanInfo = prev_static_wan_info

        self.ITEM_LIST = self.ITEM_LIST_WITH_API
        self.PROG_LIST = self.PROG_LIST_WITH_API

        self._subtitle = self.ITEM_LIST[0]
        self._itemprog = self.PROG_LIST[0]

    def _fin_unsuppor(self, _unsuppitem):
        if self._incprog is None:
            self._incprog.stop()
        self._status = self.STAT_UNSUPP
        self._err = _unsuppitem
        self._return = None

    def run(self):
        _delInfo = {"IP": None, "Route": None, "RouteRule": None, "ARP": None}

        _unsuppItem = {"bridge": False, "OpenVPN": False, "QoS": False, "Not-supported API for Bridge-name": False}
        _findUnSupp = False

        try:
            self.set_rate(2)
            _debug("This plug-in(AxGate) ignores the steps for the IP-Change API Check")

            # ## Bridge 조회
            self.set_rate(10)
            self.start_inc(3, 1)
            _ret, _br_ifs, _err = chk_vnf_bridge(self._ip, self._wan_nic_list, _vnf_id=self._id)
            if not _ret:
                self._fin_err(_err)
                return
            # else:
            #     if len(_br_ifs) > 0:
            #         _unsuppItem['bridge'] = True
            #         _findUnSupp = True
            _debug(" - Check %s, br-if=%s" % (self._subtitle, str(_br_ifs)))
            if len(_br_ifs) > 0:
                for _wan_nic in self._wan_nic_list:
                    _ret, _err, _brname = _get_brname_by_ethernet(
                        address=self._ip, username=self._id, password=self._pass, ifname=str(_wan_nic))
                    _debug("_err=%s" % _err)

                    if _ret is False:
                        _unsuppItem['Not supported API for Bridge-name'] = True
                        _findUnSupp = True
                        break

                    _not_supported = 0
                    for _err_str in str(_err).split():
                        if _err_str.lower().find("invalid") == 0:
                            _not_supported += 1
                        elif _err_str.lower().find("'^'") == 0:
                            _not_supported += 1
                        elif _err_str.lower().find("marker") == 0:
                            _not_supported += 1

                    if _not_supported >= 3:
                        _unsuppItem['Not supported API for Bridge-name'] = True
                        _findUnSupp = True
                        break
            self._complete()

            # ## VPN 조회
            self.set_rate(10)
            self.start_inc(3, 1)
            _debug("This plug-in(AxGate) ignores the steps for the OpenVPN Check")
            self._complete()

            # ## 서비스 품질
            self.set_rate(10)
            self.start_inc(3, 1)
            _debug("This plug-in(AxGate) ignores the steps for the QoS Check")
            self._complete()

            _debug(" - SUCC: Check UnSupported Item, item=%s, chk=%s" % (str(_unsuppItem), str(_findUnSupp)))
            if _findUnSupp:
                self._fin_unsuppor(_unsuppItem)
                return

            # ### 삭제할 data 조회
            _nicID = {}

            # ## 기존 Ethernet 조회
            self.set_rate(5)

            # # NIC IDX 조회:DHCP->STATIC 시 사용
            self.start_inc(3, 1, 30)

            _ret, _ifnames, _err = _get_vnf_ifnames(
                self._wan_nic_list,
                self._ip,
                username=self._id,
                password=self._pass
            )
            if not _ret:
                self._fin_err(_ret)
                return

            for _ifName in _ifnames:
                if _ifName in self._wan_nic_list:
                    _nicID[_ifName] = {"name": _ifName, "ip_list": []}
            _debug(" - Get %s, ifname info=%s" % (self._subtitle, str(_nicID)))
            self.stop_inc()
            self.set_rate(30)

            # xDSL
            self.start_inc(3, 1, 60)
            _debug("This plug-in(AxGate) ignores the steps for the xDSL Check")
            self.stop_inc()
            self.set_rate(60)

            # Ethernet
            self.start_inc(3, 1, 90)
            _ret, _ip_list, _err = _get_vnf_ipaddress(
                self._ip,
                self._wan_nic_list,
                username=self._id,
                password=self._pass)
            if not _ret:
                self._fin_err(_ret)
                return

            for _ifName in _ip_list.keys():
                if _ifName in self._wan_nic_list:
                    _nicID[_ifName]['ip_list'] = _ip_list[_ifName]
            self.stop_inc()
            self.set_rate(90)

            # # 기존 정보 제거: 삭제될 항목만 남김
            self.start_inc(3, 1)
            _delNics = copy.deepcopy(_nicID)
            _nNicList = _delNics.keys()
            _sNicList = self.prevStaticWanInfo.keys()
            for _nNic in _nNicList:
                # static
                if "id" not in _delNics[_nNic] and _nNic in _sNicList:
                    _tmpIPIList = copy.deepcopy(_delNics[_nNic]['ip_list'])
                    for _nNicIPInfo in _tmpIPIList:
                        if self.prevStaticWanInfo[_nNic]['ip'] == _nNicIPInfo['_addr']:
                            _delNics[_nNic]['ip_list'].remove(_nNicIPInfo)
                    if len(_delNics[_nNic]['ip_list']) < 1:
                        _delNics.pop(_nNic)
                # DHCP
                elif "id" in _delNics[_nNic] and _nNic not in _sNicList:
                    _delNics.pop(_nNic)

            _delInfo["IP"] = _delNics
            _debug(" - Get %s, ifID=%s" % (self._subtitle, str(_delNics)))
            self._complete()

            _usrRouteTable = []
            _ret, _routes, _err = _get_vnf_route(
                self._ip,
                username=self._id,
                password=self._pass
            )
            if not _ret:
                self._fin_err(_ret)
                return

            for _route in _routes:
                _name = str("main")
                _destAddr, _dnetmask = str(_route["dest-ip"]).split("/")
                _dnetmask = _dnetPrefix = cidr_to_netmask(_dnetmask)
                _metric = str(_route["distance"])
                _gwList = list()
                _gwList.append(str(_route["route-ip"]))

                _gwLen = len(_gwList)
                for _gwInfo in _gwList:
                    _gIP = str(_gwInfo)
                    _gIF = str(_route["ifname"])
                    if _gIF in self._wan_nic_list:
                        _route = {
                            "_name": _name,
                            "_destAddr": _destAddr,
                            "_gwList": _gwList,
                            "_dnetmask": _dnetmask,
                            "_metric": _metric,
                            "_dnetPrefix": _dnetPrefix
                        }

                        # default gw
                        if _gwLen is 1 and _destAddr == "0.0.0.0":
                            _staticGW = (lambda x: x[_gIF]['gw'] if _gIF in x else None)(self.prevStaticWanInfo)
                            # dhcp def GW
                            if _staticGW is None:
                                break
                            # static def gw
                            elif str(_gIP) == str(_staticGW):
                                break
                            _warn(" - User-Default Route, gIP=%s, prevGIP=%s" % (_gIP, _staticGW))

                            # user GW
                            _warn(" - User Route, _gw=%s, dstAddr=%s" % (str(_gwList), str(_destAddr)))
                            _usrRouteTable.append(_route)
                            break

            _delInfo['Route'] = _usrRouteTable
            _debug(" - Get %s, usr=%s" % (self._subtitle, str(_usrRouteTable)))
            self._complete()

            # ## Route 규칙 조회
            self.set_rate(10)
            self.start_inc(3, 1)
            _debug("This plug-in(AxGate) ignores the steps for the Route rule Check")
            _rrule = list()
            _delInfo['RouteRule'] = _rrule
            _debug((" - Get %s, rule=%s" % (self._subtitle, str(_rrule))))
            self._complete()

            # ## ARP 조회
            self.set_rate(5)
            self.start_inc(3, 1)

            _arp = dict()
            _debug("This plug-in(AxGate) ignores the steps for the ARP Check")

            _prevARP = []
            for _ifName in _arp.keys():
                for _arpInfo in _arp[_ifName]:
                    _ifAddr = _arpInfo['addr']
                    _mac = _arpInfo['lladdr']
                    _prevARP.append(
                        {
                            "ifindex": str(_nicID[_ifName]['idx']),
                            "ifname": _ifName,
                            "addr": _ifAddr,
                            "lladdr": _mac
                        }
                    )

            _delInfo['ARP'] = _prevARP
            _debug((" - Get %s, arp=%s" % (self._subtitle, str(_prevARP))))
            self._complete()

            self._fin_ok(_delInfo)
            return
        except Exception as _exc:
            _error("Fail to Check for WAN-IP Change, item=%s, exc=%s" % (self._subtitle, str(_exc)))
            _except(_exc)
            self._fin_err(_exc)
            return


# Refactoring code
#  Class: _RunWanIpChg(_ProgMng)


class _RunWanIpChg(_ProgMng):
    ITEM_LIST_WITHOUT_API = [
        "Backup",
        "Ethernet Check",
        "RoutingTable Check",
        "Route-Rule Check",
        "ARP Check",
        "ARP Delete",
        "Route Delete",
        "Route-Rule Delete",
        "IP Delete",
        "Daemon Restart",
        "IP Create",
        "Default GateWay Create",
        "Network Object Create"
    ]
    ITEM_LIST_WITH_API = ["Backup", "WAN-IP Change", "WAN-Route Change"]

    PROG_LIST_WITHOUT_API = [0] * len(ITEM_LIST_WITHOUT_API)
    PROG_LIST_WITH_API = [0] * len(ITEM_LIST_WITH_API)

    def __init__(self,
                 utm_ip,
                 _bak_file,
                 _tmp_if_file,
                 _tmp_dr_file,
                 _tmp_ur_file,
                 _tmp_rr_file,
                 _tmp_arp_file,
                 newwaninfo,
                 prev_static_wan_info,
                 utm_id=None,
                 utm_pass=None):
        _ProgMng.__init__(self)

        self._ip = utm_ip
        self._id = (DEF_ID if utm_id is None else utm_id)
        self._pass = (DEF_PASS if utm_pass is None else utm_pass)
        self._new_wan_info = []
        self._prev_static_wan = prev_static_wan_info
        self._bak_file = _bak_file
        self._tmp_if_file = _tmp_if_file
        self._tmp_dr_file = _tmp_dr_file
        self._tmp_ur_file = _tmp_ur_file
        self._tmp_rr_file = _tmp_rr_file
        self._tmp_arp_file = _tmp_arp_file

        def _new_wan_info_nic(_item):
            return _item["nic"]

        for _newwan in newwaninfo:
            if _newwan['is_dhcp']:
                self._new_wan_info.append(
                    {
                        "nic": _newwan['nic'],
                        "is_dhcp": True,
                        "name": _get_dhcp_name(_newwan['nic']),
                        "mac": _newwan['mac']
                    }
                )
            else:
                self._new_wan_info.append(copy.deepcopy(_newwan))

        self._new_wan_info.sort(key=_new_wan_info_nic, reverse=True)

        self._has_api = True
        self.ITEM_LIST = self.ITEM_LIST_WITH_API
        self.PROG_LIST = self.PROG_LIST_WITH_API

        self._subtitle = self.ITEM_LIST[0]
        self._itemprog = self.PROG_LIST[0]

    def _chg_ip_with_api(self):
        # prevStaticWanInfo = {
        #     'eth1': {
        #         'gw': '175.213.170.1',
        #         'ip': '175.213.170.152'
        #     }
        # }
        # newWanInfo = [
        #     {
        #         "nic": "eth1",
        #         "is_dhcp": False,
        #         "ip":"175.213.170.152",
        #         "gw":"175.213.170.1",
        #         "subnet":"255.255.255.0"
        #     },
        #     {
        #         "nic": "eth5",
        #         "is_dhcp": True,
        #         "name": "red_dhcp_r1",
        #         "mac":"00:00:00:11:11:11"
        #     }
        # ]

        _title = "UTM WAN-IP Chagne"
        _info("Start %s" % _title)

        try:
            # 1. vnfm에 backup 요청
            self.set_rate(5)

            self.start_inc(3, 1)
            if not os.path.isfile(self._bak_file):
                _ret, _err = backup(self._bak_file, self._ip)
                if not _ret:
                    _error(" - Fail to %s, err=%s" % (self._subtitle, str(_err)))
                    self._fin_err("AXGATE-UTM Backup Error, err=%s" % str(_err))
                    return
                _debug("     Save Backup File, f=%s" % self._bak_file)

            self.stop_inc()
            _info(" - Succ: %s" % self._subtitle)
            self._complete()

            # 2. IP Change
            # Login
            self.set_rate(5)

            self.start_inc(3, 1)

            _debug("self._new_wan_info: %s" % str(self._new_wan_info))

            _bridges = _get_br_list(address=self._ip, username=self._id, password=self._pass)
            _info("_bridges: %s" % str(_bridges))

            _gw_info = {}
            for _newWanInfo in self._new_wan_info:
                _wnic = _newWanInfo['nic']
                _wnic_dhcp = _newWanInfo['is_dhcp']
                _prev_nic_static = _wnic in self._prev_static_wan

                # _ret, _err, _brname = _get_brname_by_ethernet(
                #     address=self._ip, username=self._id, password=self._pass, ifname=_wnic)

                _brname = "none"
                if _bridges is not None and len(_bridges) > 0:
                    _ret, _err, _brname = _get_brname_by_ethernet(
                        address=self._ip, username=self._id, password=self._pass, ifname=_wnic)

                    if _ret is not True:
                        _error(" - Fail to Change Default Route, err=%s" % str(_err))
                        self._fin_err("AXGATE-UTM Route Change Error, err=%s" % (str(_err)))
                        return

                # if _ret is not True:
                #     _error(" - Fail to %s, err=%s" % (self._subtitle, str(_err)))
                #     self._fin_err("AXGATE-UTM IP Change Error, err=%s" % str(_err))
                #     return

                if _wnic_dhcp:
                    # static -> dhcp
                    if _prev_nic_static:
                        self._rollback = True
                        _gw_info[_wnic] = "0.0.0.0"

                        _ret = _setup_vnf_ip(
                            address=self._ip,
                            username=self._id,
                            password=self._pass,
                            # ifname=_wnic,
                            ifname=(_brname if not _brname == "none" else _wnic),
                            ipaddress=str("dhcp"),
                            gw=None,
                            lk_interval=str("3"),
                            lk_failcount=str("3"),
                            lk_proto=str("icmp"),
                            lk_target=None
                        )
                        if _ret is not True:
                            _error(" - Fail to %s, err=%s" % (self._subtitle, str(_err)))
                            self._fin_err("AXGATE-UTM IP Change Error, err=%s" % str(_err))
                            return
                        else:
                            _debug("     Change IP STATIC -> DHCP, VNF-NIC=%s" % str(_wnic))
                    # dhcp -> dhcp
                    else:
                        _debug("     SKIP to IP Change, VNF-NIC=%s, DHCP->DHCP" % str(_wnic))
                        continue
                else:
                    _wnic_ip = _newWanInfo['ip']
                    # static -> static
                    if _prev_nic_static:
                        # Skip if IP and Gateway settings are already set
                        if _wnic_ip == self._prev_static_wan[_wnic]['ip'] and \
                                        _newWanInfo['gw'] == self._prev_static_wan[_wnic]['gw']:
                            _debug(
                                "     SKIP to IP Change, VNF-NIC=%s, newip=%s, previp=%s, newgw=%s, prevgw=%s "
                                "STATIC->STATIC" % (
                                    str(_wnic), _wnic_ip, self._prev_static_wan[_wnic]['ip'],
                                    _newWanInfo['gw'], self._prev_static_wan[_wnic]['gw']))
                            continue
                    # diff ip
                    # dhcp -> static
                    try:
                        _ip_pfx = IPv4Network("0.0.0.0/%s" % _newWanInfo['subnet']).prefixlen
                        self._rollback = True
                        _gw_info[_wnic] = _newWanInfo['gw']
                        _ret = _setup_vnf_ip(
                            address=self._ip,
                            username=self._id,
                            password=self._pass,
                            # ifname=_wnic,
                            ifname=(_brname if not _brname == "none" else _wnic),
                            ipaddress=str("%s/%s" % (_wnic_ip, _ip_pfx)),
                            gw=str(_newWanInfo["gw"]),
                            lk_interval=str("3"),
                            lk_failcount=str("3"),
                            lk_proto=str("icmp"),
                            lk_target=str(_newWanInfo["gw"])
                        )
                        if _ret is not True:
                            _error(" - Fail to %s, err=%s" % (self._subtitle, str(_err)))
                            self._fin_err("AXGATE-UTM IP Change Error, err=%s" % str(_err))
                            return
                        else:
                            _debug("     Change IP to Static, VNF-NIC=%s, ip=%s/%s" % (
                                str(_wnic), str(_wnic_ip), str(_ip_pfx)))
                    except Exception as _exc1:
                        _error(" - Fail to %s, exc=%s" % (self._subtitle, str(_exc1)))
                        _except(_exc1)
                        self._fin_err(
                            "AXGATE-UTM IP Change Error, IP Check Error, net=%s, err=%s" % (
                                str(_newWanInfo), str(_exc1)))
                        return

            self.stop_inc()
            _info(" - Succ: %s" % self._subtitle)
            self._complete()

            # 3. Route Change
            self.set_rate(5)
            self.start_inc(3, 1)

            # def _get_vnf_def_route(address, username, password):

            # ## New logic begin
            _err, _default_route = _get_vnf_def_route(address=self._ip, username=self._id, password=self._pass)
            _debug("_default_route: %s" % str(_default_route))
            if _err is not True:
                _error(" - Fail to %s, Default Route Get Error, err=%s" % (self._subtitle, str(_err)))
                self._fin_err("AXGATE-UTM Default Route Get Error, err=%s" % (str(_err)))
                return

            # if static: no ip route {ipaddress}
            # if dhcp: no ip route {interface}

            _no_ip_route = str()

            # if not _ret:
            #         self._fin_err(_err)
            #         return
            # else:
            #     if len(_br_ifs) > 0:
            #         _unsuppItem['bridge'] = True
            #         _findUnSupp = True
            # _debug(" - Check %s, br-if=%s" % (self._subtitle, str(_br_ifs)))
            # if len(_br_ifs) > 0:
            #     pass

            for _newWanInfo in self._new_wan_info:

                _brname = "none"

                if _bridges is not None and len(_bridges) > 0:
                    _ret, _err, _brname = _get_brname_by_ethernet(
                        address=self._ip, username=self._id, password=self._pass, ifname=_newWanInfo["nic"])

                    if _ret is not True:
                        _error(" - Fail to Change Default Route, err=%s" % str(_err))
                        self._fin_err("AXGATE-UTM Route Change Error, err=%s" % (str(_err)))
                        return

                if len(_default_route) > 0:
                    _no_ip_route = str(
                        "no ip route 0.0.0.0/0 %s" % _newWanInfo["nic"]
                    )
                    if str(_default_route["type"]).lower() == "static":
                        _debug("(static) _no_ip_route: %s" % _no_ip_route)
                    else:
                        _debug("(dhcp) _no_ip_route: %s" % _no_ip_route)

                if _brname == "none":
                    _new_ip_route = str(
                        "ip route 0.0.0.0/0 %s %d" % (_newWanInfo["nic"], _get_distance(_newWanInfo["nic"]))
                    )
                else:
                    _new_ip_route = str(
                        "ip route 0.0.0.0/0 %s %d" % (_brname, _get_distance(_newWanInfo["nic"]))
                    )

                _debug("_new_ip_route: %s" % _new_ip_route)

                _err = _change_vnf_def_route(
                    address=self._ip,
                    username=self._id,
                    password=self._pass,
                    no_ip_route=_no_ip_route,
                    new_ip_route=_new_ip_route
                )

                if _err is not True:
                    _error(" - Fail to Change Default Route(%s >>> %s)" % (_no_ip_route, _newWanInfo))
                    self._fin_err("AXGATE-UTM Route Change Error, API Return Error, err=%s" % (str(_err)))
                    return
                _debug("     Change Route:")
                _debug("        OLD: %s" % _no_ip_route)
                _debug("        NEW: %s" % _new_ip_route)

            ### New logic end

            # _ret, _prev_gw_info, _err = get_vnf_all_route_info(
            #     self._ip,
            #     _gw_info.keys(),
            #     self._prev_static_wan
            # )
            # if _ret is not True:
            #     _error(" - Fail to %s, Route Get Error, err=%s" % (self._subtitle, str(_err)))
            #     self._fin_err("AXGATE-UTM Route Get Error, err=%s" % (str(_err)))
            #     return
            # if type(_prev_gw_info) != dict or "def" not in _prev_gw_info:
            #     _error(" - Fail to %s, Invalid Route Info, ret=%s" % (self._subtitle, str(_prev_gw_info)))
            #     self._fin_err("AXGATE-UTM Route Change Error, Invalid Route Info, ret=%s" % (str(_prev_gw_info)))
            #     return
            # _debug("      Get Default GW: gw=%s" % str(_prev_gw_info['def']))
            #
            # _def_prev_gw_info = _prev_gw_info['def']
            # for _def_prev_gw in _def_prev_gw_info:
            #     # "_name", "_destAddr", '_gwList', "_dnetmask",
            #     # "_metric", "_dnetPrefix", "_tbNum"
            #     _tname = _def_prev_gw['_name']
            #     _tnum = _def_prev_gw['_tbNum']
            #     _metric = _def_prev_gw['_metric']
            #     _gw_list = _def_prev_gw['_gwList']
            #     for _gw in _gw_list:
            #         _gIP, _gIF = str(_gw).split('/')
            #         if _gIF is not None and _gw_info.has_key(_gIF):
            #             _new_gw = _gw_info[_gIF]
            #             _ret = _change_vnf_route(
            #                 address=self._ip,
            #                 username=self._id,
            #                 password=self._pass,
            #                 route_address=_gIP,
            #                 new_route_address=_new_gw,
            #                 ifname=_gIF,
            #                 distance=_metric
            #             )
            #             if _ret is not True:
            #                 _error(" - Fail to %s, API Return Error, prev_gw_info=%s" % (
            #                     self._subtitle, str(_def_prev_gw)))
            #                 self._fin_err("AXGATE-UTM Route Change Error, API Return Error, err=%s" % (str(_err)))
            #                 return
            #             _debug("     Change Route, %s: %s -> %s" % (str(_gIF), str(_gIP), str(_new_gw)))
            #         else:
            #             _warn(" - Fail to %s, No GW Info, gw=%s" % (self._subtitle, str(_gw)))

            self.stop_inc()
            _info(" - Succ: %s" % self._subtitle)
            self._complete()

            self._fin_ok()
        except Exception as _exc:
            _error(" - Fail to %s, exc=%s" % (self._subtitle, str(_exc)))
            _except(_exc)
            self._fin_err("Error Occur")

    def run(self):
        self._chg_ip_with_api()


# Refactoring code
#  Class: _ChkLanIPChg(_ProgMng)


class _ChkLanIPChg(_ProgMng):
    ITEM_LIST = ['IP-Change API', "Bridge"]

    PROG_LIST = [0] * len(ITEM_LIST)

    def __init__(self, _ip, _lan_nic, _wanniclist=None, _id=None, _pass=None):
        _ProgMng.__init__(self)

        self._ip = _ip
        self._id = (DEF_ID if _id is None else _id)
        self._pass = (DEF_PASS if _pass is None else _pass)
        self._lan_nic = _lan_nic
        self._wanniclist = (PHYSICAL_NICs if _wanniclist is None else _wanniclist)

        self._subtitle = self.ITEM_LIST[0]
        self._itemprog = self.PROG_LIST[0]

    def _fin_unsuppor(self, _unsuppitem):
        if self._incprog is None:
            self._incprog.stop()
        self._status = self.STAT_UNSUPP
        self._err = _unsuppitem
        self._return = None

    def run(self):
        _unsuppItem = {"bridge": False}
        _findUnSupp = False

        try:
            self.set_rate(2)
            self.start_inc(1, 1)
            _debug("This plug-in(AxGate) ignores the steps for the IP-Change API Check")
            self._complete()

            _ret = login(self._ip, self._id, self._pass)
            self.set_rate(5)
            if not _ret:
                self._fin_err("AXGATE-UTM Login Error")
                return

            # ## Bridge 조회
            self.set_rate(10)
            self.start_inc(1, 1)
            _ret, _br_ifs, _err = chk_vnf_bridge(
                self._ip, self._wanniclist, self._lan_nic, _vnf_id=self._id
            )

            if not _ret:
                self._fin_err(_err)
                return
            else:
                if len(_br_ifs) > 0:
                    _unsuppItem['bridge'] = True
                    _findUnSupp = True

            _debug(" - Check %s, br-if=%s" % (self._subtitle, str(_br_ifs)))
            self._complete()

            _debug(
                " - SUCC: Check UnSupported Item, item=%s, chk=%s" % (
                    str(_unsuppItem), str(_findUnSupp)))
            if _findUnSupp:
                self._fin_unsuppor(_unsuppItem)
                return

            self._fin_ok()
        except Exception as _exc:
            _error("Fail to Check for LAN-IP Change, item=%s, exc=%s" % (
                self._subtitle, str(_exc)))
            _except(_exc)
            self._fin_err(_exc)
            return


# Refactoring code
#  Class: _RunLanIpChg(_ProgMng)


class _RunLanIpChg(_ProgMng):
    ITEM_LIST = ["Backup", "LAN-IP Change"]

    PROG_LIST = [0] * len(ITEM_LIST)

    def __init__(self, utm_ip, _bak_file, _new_lan_info, utmid=None, utmpass=None):
        _ProgMng.__init__(self)

        self._ip = utm_ip
        self._id = (DEF_ID if utmid is None else utmid)
        self._pass = (DEF_PASS if utmpass is None else utmpass)
        self._bak_file = _bak_file
        self._newLanInfo = _new_lan_info

        self._subtitle = self.ITEM_LIST[0]
        self._itemprog = self.PROG_LIST[0]

    def run(self):
        _title = "UTM LAN-IP Chagne"
        _info("Start %s" % _title)

        sid = None

        try:
            # 1. Request backup to VNFM
            self.set_rate(5)

            self.start_inc(3, 1)
            if not os.path.isfile(self._bak_file):
                _ret, _err = backup(self._bak_file, self._ip)
                if not _ret:
                    self._fin_err(_err)
                    return
                _debug("     Save Backup File, f=%s" % self._bak_file)

            self.stop_inc()
            _info(" - Succ: %s" % self._subtitle)
            self._complete()

            # 2. IP Change
            self.set_rate(5)

            #  Login
            self.start_inc(3, 1)
            sid = login(address=self._ip, username=self._id, password=self._pass)
            self.set_rate(10)

            interface = self._newLanInfo["nic"]
            _cidr = netmask_to_cidr(self._newLanInfo["mask"])
            _debug("mask(%s) -> cidr(%s)" % (str(self._newLanInfo["mask"]), str(_cidr)))
            ipaddress_cidr = str("%s/%s" % (self._newLanInfo["ip"], _cidr))

            if sid is None or len(sid) is 0:
                err = "Fail to IP change(\n" \
                      "configure terminal\n" \
                      "interface %s\n" \
                      "ip address %s\n" \
                      "no shutdown\n" \
                      "end" \
                      "write): /login.cgi, sid(%s)" % (interface,
                                                       ipaddress_cidr,
                                                       sid)
                _error("%s" % err)
                self._fin_err("AXGATE-UTM Login Error")
                return

            _debug("     Login AXGATE-UTM")

            http_client = AxGateHTTPClient()

            http_client.add_header(name="Content-Type", value="application/x-www-form-urlencoded; charset=utf-8")
            http_client.add_header(name="Accept", value="*/*")
            http_client.add_header(name="Cookie", value=str("SessionID=%s" % sid))

            _http_body = str("cmd=configure terminal\\n"
                             "interface %s\\n"
                             "ip address %s\\n"
                             "no shutdown\\n"
                             "end\\n"
                             "write"
                             % (interface, ipaddress_cidr))
            _http_body = _http_body.replace('\\n', "%0A")

            _debug("_http_body: %s" % _http_body)

            err, code, headers, body = http_client.http_request(
                http_url=str("https://%s:443/restrict/exec.cgi" % self._ip),
                http_method="POST",
                http_body=_http_body,
                delay_timeout=1
            )

            if err is True or code is not 200 or headers is None or body is None:
                err = "Fail to IP change(\n" \
                      "configure terminal\n" \
                      "interface %s\n" \
                      "ip address %s\n" \
                      "no shutdown\n" \
                      "end\\n" \
                      "write): /exec.cgi, sid(%s)" % (interface, ipaddress_cidr, sid)
                _error(err)
                _error("  Code: '%s'" % code)
                _error("  Headers: '%s'" % headers)
                _error("  Body: '%s'" % body)
                self._fin_err("AXGATE-UTM IP Change Error, err={}".format(body))
                return

            result = int()
            message = str()
            rows = str(body).splitlines()

            for offset in range(0, len(rows)):
                columns = rows[offset].split(":")

                if len(columns) is not 2:
                    continue

                if columns[0] == "result":
                    result = int(columns[1])
                elif columns[0] == "message":
                    message = columns[1]
                    _debug("message: %s" % message)

            if result is not 1:
                err = "Fail to IP change(\n" \
                      "configure terminal\n" \
                      "interface %s\n" \
                      "ip address %s\n" \
                      "no shutdown\n" \
                      "end\\n" \
                      "write): /exec.cgi, sid(%s)" % (interface, ipaddress_cidr, sid)
                _error("%s" % err)
                _error("  Code: '%s'" % code)
                _error("  Headers: '%s'" % headers)
                _error("  Body: '%s'" % body)
                if message is not None and len(message) > 0:
                    self._fin_err("AXGATE-UTM IP Change Error, err=%s" % message)
                else:
                    self._fin_err("AXGATE-UTM IP Change Error, err={}".format(body))
                return

            _debug(
                "     Change IP to Static, VNF-NIC=%s, ip=%s" % (interface, ipaddress_cidr))

            self._complete()
            self._fin_ok()
        except Exception as _exc:
            _error(" - Fail to %s, exc=%s" % (self._subtitle, str(_exc)))
            _except(_exc)
            # logout(address=self._ip, session_id=sid)
            self._fin_err("Error Occur")


# Refactoring code
#  Class: _RunRestore(_ProgMng)


class _RunRestore(_ProgMng):
    ITEM_LIST = ["Resotre"]
    PROG_LIST = [0] * len(ITEM_LIST)

    def __init__(self, _vnf_ip, _bak_file, _wait_cnt=50):
        _ProgMng.__init__(self)

        self._ip = _vnf_ip
        self._bak_file = _bak_file
        self._wait_cnt = _wait_cnt

        self._subtitle = self.ITEM_LIST[0]
        self._itemprog = self.PROG_LIST[0]

    def run(self):
        try:
            _info("Start AXGATE-UTM Restore")

            self.set_rate(10)
            url = URL_VNFM_RESTORE
            body = {
                "vnf_name": V_TYPE,
                "local_mgmt_ip": self._ip,
                "local_location": str(self._bak_file),
                "needWanSwitch": False,
                "type": "local_all"
            }
            client_cert = "/var/onebox/key/client.crt"
            client_key = "/var/onebox/key/client.key"

            result = _request_vnfapi(
                url=url,
                method="POST",
                header=HEADER_VNFM,
                request_body=body,
                cert=client_cert,
                key=client_key,
                to=60,
                stime=5
            )

            if result is None:
                _error("Fail to Request AXGATE-UTM Restore, API Call Error")
                self._fin_err("API Call Error")
                return

            _info("SUCC: Request AXGATE-UTM Restore")

            intv = 2
            url = URL_VNFM_STATUS
            body = {
                "vnf_name": V_TYPE,
                "local_mgmt_ip": self._ip
            }
            self.set_rate(100 - self._wait_cnt)
            self.start_inc(2, 1)
            for _idx in range(self._wait_cnt):
                sleep(intv)
                try:
                    result = _request_vnfapi(
                        url=url,
                        method="POST",
                        header=HEADER_VNFM,
                        request_body=body,
                        to=5,
                        cert=client_cert,
                        key=client_key,
                        stime=10
                    )

                    if result is not None and \
                                    "status" in result and \
                                    str(result['status']).strip().upper() == "RUNNING":
                        _info("Succ: Restore AXGATE-UTM")
                        self.stop_inc()
                        self._complete()
                        self._fin_ok()
                        return
                    _info(
                        " - Check AXAGATE-VNF Restore Status, try=%s/%s status=%s" % (
                            str(_idx + 1), str(self._wait_cnt), str(result)))
                except Exception as _exc1:
                    _warn(" - Fail to Check AXGATE-UTM Restore Status, exc=%s" % str(_exc1))
                    _except(_exc1)

            self.stop_inc()
            _error("Fail to Request AXGATE-UTM Restore, TimeOut")
            self._fin_err("TimeOut")
        except Exception as _exc:
            _error("Fail to Request AXGATE-UTM Restore, exc=%s" % str(_exc))
            _except(_exc)
            self._fin_err("Exception Occur")


# New implemented
#  Func: def get_web_port()


def get_web_port():
    return 443


# New implemented
#  Func: get_model()


def get_model():
    return V_TYPE


# New implemented
#  Func: is_same_state_for_restore()


def is_same_state_for_restore():
    return True
