#-*- coding: utf-8 -*-
'''
Created on 2018. 2. 22.

@author: ohhara
'''


import sys, tempfile, traceback, json
from time import sleep

from tornado import httpclient
from tornado.httputil import HTTPHeaders
from tornado.httpclient import HTTPRequest
from ipaddr import IPv4Network


HEADER = {"content-Type": "application/x-www-form-urlencoded", "accept":"*/*"}

DEF_ID = "acroot"
DEF_PASS = "ipcs0406!"

_URL_LOGIN = """https://%s/onebox/login.dao"""
_URL_IP = """https://%s/onebox/base/ethernet.dao"""
_URL_GW = """https://%s/onebox/base/route/table.dao"""


def _getLineNo():
    org_f = None
    try:
        raise Exception
    except:
        org_f = sys.exc_info()[2].tb_frame.f_back
    #On some versions of IronPython, currentframe() returns None if
    #IronPython isn't run with -X:Frames.
    if org_f is not None:
        f = org_f.f_back
    else:
        return None
    
    if f == None :
        return None
    
    l_no = f.f_lineno
    return l_no

logger = None
_LOG_T = "[PLG-ACR-PBX.%-4s]"
def _debug(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.debug(msg)
    else: print msg

def _info(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.info(msg)
    else: print msg

def _warn(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.warning(msg)
    else: print msg

def _error(msg):
    msg = _LOG_T%str(_getLineNo()) + " " + str(msg)
    if logger != None : logger.error(msg)
    else: print msg

def _except(exc):
    _SERR = tempfile.TemporaryFile()
    traceback.print_exc(exc, _SERR)
    _SERR.seek(0)
    msg = _SERR.read()
    msg = _LOG_T%str(_getLineNo()) + "\n" + str(msg)
    if logger != None : logger.fatal(msg)
    else: print msg


def callAPI( _url, _method, header=HEADER, reqBody=None, returnHeader=False, _to=5, cCrt=None, cKey=None, sTime=2 ):
    try:
        sleep(sTime)
        
        http_client = httpclient.HTTPClient()
        h = HTTPHeaders(header)
        if reqBody == None:
            strBody = None
        elif type(reqBody) == str:
            strBody = reqBody
        else:
            strBody = json.dumps( reqBody )
        
        if cCrt == None or cKey == None :
            req = HTTPRequest( validate_cert=False, url=_url, headers=h, method=_method.upper(), 
                           body=strBody, request_timeout=_to )
        else:
            req = HTTPRequest( validate_cert=False, url=_url, headers=h, method=_method.upper(), 
                            client_cert=cCrt,
                            client_key=cKey,
                            body=strBody, request_timeout=_to )
                
        response = http_client.fetch( request=req )
        http_client.close()
        
        retBody = response.body
        try:
            retBody = json.loads(response.body)
        except :
            pass
        
        if returnHeader :
            return { "header": response.headers, "body": retBody }
        else:
            return retBody
    except Exception, e:
        _error("Fail to Call API, url=%s, method=%s, body=%s"%(_url, _method, reqBody))
        _except(e)
        return None



def login(vnfIP, vnfID=None, vnfPass=None, _rNum = 10):
    if vnfID == None : vnfID = DEF_ID
    if vnfPass == None : vnfPass = DEF_PASS
    
    _title = "Acromate-PBX Login"
    for _idx in range(_rNum):
        sleep(3)
        try:
            ### Login
            _url = _URL_LOGIN%str(vnfIP)
            _body = 'username=%s&passwd=%s&force=%s'%(str(vnfID), str(vnfPass), str(1))
            _ret = callAPI(_url, "POST", reqBody=_body, sTime=1)
            if _ret == None or not _ret.has_key('success') or str(_ret['success']).lower() != "true" :
                _warn("Fail to %s, retry=%s/%s, url=%s, body=%s, ret=%s"%(_title, str(_idx+1), str(_rNum), _url, _body, str(_ret)))
                continue
            
            return True
        except Exception, e:
            _warn("Fail to %s, retry=%s/%s, exception=%s"%(_title, str(_idx+1), str(_rNum), str(e)))
            _except(e)
            continue
        
    return False

def logout(vnfIP, vnfID=None):
    return True

def get_web_port():
    return 80

def to_inner_nic(_ovs_br):
    if str(_ovs_br).find("extrawan") > -1 :
        return "eth1"
    if str(_ovs_br).find("office") > -1 :
        return "eth2"
    if str(_ovs_br).find("server") > -1 :
        return "eth3"
    if str(_ovs_br).find("local") > -1 :
        return "eth4"
    
    return None

def get_ip(_vnf_ip, _nic):
    '''
    return : (IP, MASK) or None, None
    '''
    try:
        ### Login
        _url = _URL_IP%_vnf_ip
        _ret = callAPI(_url, "GET", sTime=1)
        if type(_ret) != list and len(_ret) < 1 :
            _warn("Fail to Get IP, nic=%s, ret=%s"%( str(_nic), str(_ret) ))
            return None, None
        
        for _ip_info in _ret :
            if type(_ip_info) == dict and _ip_info.has_key('name') :
                _ifname = str(_ip_info['name'])
                if _ifname == str(_nic) :
                    try:
                        _ip = str(_ip_info['ip'])
                        _mask = str(_ip_info['netmask'])
                        IPv4Network("%s/%s"%( _ip, _mask ))
                        return _ip, _mask
                    except Exception, e:
                        _warn("Fail to Get IP, nic=%s, exc=%s, ip_info=%s"%( str(_nic), str(e), str(_ip_info) ))
                        _except(e)
                        return None, None
        
        _warn("Fail to Get IP, No IP Info, nic=%s, ret=%s"%( str(_nic), str(_ret) ))
        return None, None
    except Exception, e:
        _warn("Fail to Get IP, nic=%s, exception=%s"%( str(_nic), str(e)))
        _except(e)
        None, None


def get_def_gw_info(_vnf_ip):
    '''
    return : None, None, None or (dev, ip, metric)
    '''
    try:
        ### Login
        _url = _URL_GW%_vnf_ip
        _ret = callAPI(_url, "GET", sTime=1)
        if type(_ret) != list and len(_ret) < 1 :
            _warn("Fail to Get GW, ret=%s"%( str(_ret) ))
            return None, None, None
        
        for _gw_info in _ret :
            if type(_gw_info) == dict and _gw_info.has_key('_gateway') and _gw_info.has_key('_outputIf') and _gw_info.has_key('_metric') and _gw_info.has_key('_destAddr') and _gw_info.has_key('_active') :
                _gw_dst = str(_gw_info['_destAddr'])
                _gw_act = _gw_info['_active']
                _gw_if = str(_gw_info['_outputIf']).replace(";", "")
                _gw_metric = int(_gw_info['_metric'])
                _gw_ip = str(_gw_info['_gateway']).replace(";", "")
                if _gw_act == 1 and _gw_dst == "0.0.0.0" :
                    try:
                        IPv4Network("%s/255.255.255.255"%( _gw_ip ))
                        return _gw_if, _gw_ip, _gw_metric
                    except Exception, e:
                        _warn("Fail to Get GW, exc=%s, gw_info=%s"%( str(e), str(_gw_info) ))
                        _except(e)
                        return None, None, None
        
        _warn("Fail to Get GW, No GW Info, ret=%s"%( str(_ret) ))
        return None, None, None
    except Exception, e:
        _warn("Fail to Get GW, exception=%s"%( str(e)))
        _except(e)
        None, None, None

