#!/usr/bin/python
#-*- coding: utf-8 -*-
'''
Created on 2017. 7. 25.

@author: ohhara
'''

import sys, ruamel.yaml, os
from optparse import OptionParser

import warnings
warnings.simplefilter(action="ignore", category=FutureWarning)

from boot import boot_ctrl
from boot import boot_view as bv
from boot import boot_constant as bc
from util import ob_constant as oc
from data.ob_info import OB_INFO
from util import ob_lib
from boot import boot_lib
from plugin.obos import linux_plugin

from util.ko_logger import ko_logger
logger = ko_logger(tag=bc._L_TITLE, logdir="/var/log/onebox", loglevel="debug", logConsole=False).get_instance()
logger.propagate = False


def main():
    if not os.path.exists( oc.DIR_TMP ) :
        os.makedirs( oc.DIR_TMP )
    
    cfgName = oc.FILE_OBA_CONF
    if len(sys.argv) >= 2:
        cfgName = sys.argv[1]
    
    with open(cfgName, "r") as f:
        _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)

    oba_cfg = OB_INFO().loadByCfg(_oba_cfg, True)

    # check this os info and load valid plugins
    _os = linux_plugin.get_os_name()
    logger.info("os name = %s" % _os)
    oba_cfg.m_os = _os

    _ob_lib = ob_lib.create_lib(oba_cfg, logger)
    if _ob_lib is None:
        bv.alert("Failed to load valid os plugins")
        return

    # check this hw info (valid model, cpu, ..)
    oba_cfg.m_hw = _ob_lib.get_hw_info(oba_cfg)
    if oba_cfg.m_hw.hw_model() is None:
        bv.alert("Failed to get hardware model. Check /var/onebox/hardware/model")
        return

    _bta_lib = boot_lib.create_lib(_ob_lib)

    bta_data = {
        oc.OTAG_VER: oc.VAL_OB_VER,
        oc.OTAG_CFG_FILE: cfgName,
        oc.OTAG_OBA_INFO: oba_cfg,
        oc.OTAG_LIB_OB: _ob_lib,
        oc.OTAG_LIB_BTA: _bta_lib
    }

    parser = OptionParser(usage="usage: %prog [options]",
                          version="One-Box Boot Agent version %s"%oc.VAL_OB_VER)
    # AUX NIC to ignore when detecting network interfaces
    parser.add_option("-a", dest="aux", type="string", help="Aux network interface")
    parser.add_option("-o", "--orch",
                       dest="orch", 
                       type="string",
                       help="orchestrator ip")
    (options, args) = parser.parse_args()
    
    logger.info("----------------------[[[[ BTA Start ]]]----------------------")
    logger.info(" - ver: %s, option: %s, args: %s" % ( oc.VAL_OB_VER, str(options), str(args) ))
    
    _choices = [("1", "First Install"), ("2", "Recovery"), ("3", "Factory Reset"),
                ("4", "Network Config"), ("5", "ETC")]

    while True :
        _ret = None
        try:
            _menu = boot_ctrl.get_main_menu(_choices)
            if _menu == "1" :
                _ret = boot_ctrl.first_install(bta_data)
            elif _menu == "2" :
                _ret = boot_ctrl.recovery(bta_data, options)
            elif _menu == "3" :
                _ret = boot_ctrl.factory_reset(bta_data)
            elif _menu == "4" :
                _ret = boot_ctrl.network_config(bta_data)
            elif _menu == "5" :
                _ret = boot_ctrl.etc(bta_data)
            # exit
            elif _menu == bc.BTA_M_EXIT:
                _ret = bc.BTA_M_EXIT
            # error
            else:
                logger.error("Invalid Menu, ret=%s"%str(_menu))
                _ret = bc.BTA_M_EXIT
        except Exception, e:
            logger.exception(e)
            _ret = bc.BTA_M_EXIT
        
        if _ret == bc.BTA_M_EXIT :
            break
        elif _ret == bc.BTA_M_BACK :
            continue

    logger.info("----------------------[[[[ BTA Exit ]]]----------------------")
    

if __name__ == '__main__':
    main()

