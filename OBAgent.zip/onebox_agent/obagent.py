#!/usr/bin/python
#-*- coding: utf-8 -*-
'''
Created on 2017. 7. 25.

@author: ohhara
'''

import sys, ruamel.yaml, os, shutil, ssl

from optparse import OptionParser
from time import sleep
from tornado.web import Application
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from onebox_agent.oba import oba_constant as oac
from onebox_agent.util import ob_constant as oc
from onebox_agent.data.ob_info import OB_INFO
from plugin.obos import linux_plugin
from onebox_agent.oba.handler import file_handler, zba_handler, backup_handler, status_handler, wansw_handler, scheduler_handler,\
    vnf_info_handler
from onebox_agent.oba.scheduler.obinfo_scheduler import OBNetNotiSchd, OBStatusSchd
from onebox_agent.oba.scheduler.wanmon_scheduler import WanMonSchd
from onebox_agent.oba.scheduler.ovsmod_scheduler import OvsModSchd

from util.ko_logger import ko_logger
logger = ko_logger(tag=oac._L_TITLE, logdir="/var/log/onebox", loglevel="debug", logConsole=False).get_instance()
logger.propagate = False

import warnings
warnings.simplefilter(action="error", category=FutureWarning)


class httpSvrThread:
    
    def __init__(self, applictions, port):
        self.svr = HTTPServer(applictions, ssl_options={
                "certfile": "/var/onebox/key/svr_crt.pem",
                "keyfile": "/var/onebox/key/svr_key.pem",
                "ca_certs": "/var/onebox/key/svr_ca.pem",
                "cert_reqs": ssl.CERT_REQUIRED
        })
        self.svr.bind(port)
        try:
            self.svr.start()
        except KeyboardInterrupt:
            logger.info('Keyboard Interrupt')
            self.shutdown()
    
    def shutdown(self):
        logger.info('shutdown - ioloop.stop')        
        IOLoop().current().stop()
        logger.info('shutdown - svr.stop')
        self.svr.stop()
        
    def run(self):
        logger.info('Run Http Server')
        IOLoop().current().start()


def setKey():
    try:
        logger.info('Set Key File')
        
        if not os.path.isdir('/var/onebox/key') :
            os.makedirs('/var/onebox/key')
            logger.info(' - Make Key Dir')
        
        rootKeyFile = '/var/onebox/key/id_rsa'
        zbKeyFile = '/var/onebox/key/zb_rsa'
        hasRooKey = hasZbKey = setZbKeyOwn = False
        if os.path.isfile( rootKeyFile ) :
            hasRooKey = True
        if os.path.isfile( zbKeyFile ) :
            hasZbKey = True
        
        import commands as cmd
        status, ret = cmd.getstatusoutput( "ls -g %s"%str(zbKeyFile) )
        if status == 0 and ret.find('zabbix') >= 0 :
            setZbKeyOwn = True
        
        if hasRooKey and hasZbKey and setZbKeyOwn :
            logger.info('SUCC: Set Key, Already Exist')
            return True
        
        rootDir = os.getenv('HOME', '/root')
        keyFile = rootDir + '/.ssh/id_rsa'
        if not os.path.isfile( keyFile ) :
            status, ret = cmd.getstatusoutput( "echo -e  'y\\n' | ssh-keygen -q -t rsa -f %s -N ''"%str(keyFile) )
            
            if not os.path.isfile( keyFile ) :
                logger.info( 'Fail to Set Key, No Key File, file=%s'%str(keyFile) )
                return False
            else:
                logger.info(' - Created New Key File, file=%s'%str(keyFile))
        
        if not hasRooKey :
            shutil.copyfile( keyFile, rootKeyFile )
            os.chmod(rootKeyFile, 0600)
            logger.info( ' - Set Root Key' )
        
        if not hasZbKey :
            shutil.copyfile( keyFile, zbKeyFile )
            os.chmod(zbKeyFile, 0600)
            logger.info( ' - Set Zabbix Key' )
        
        if not setZbKeyOwn :
            from pwd import getpwnam
            try:
                uid = getpwnam('zabbix')[2]
                gid = getpwnam('zabbix')[3]
                os.chown(zbKeyFile, uid, gid)
                logger.info( ' -  Set Zabbix Key Owner' )
            except Exception, e:
                logger.wanning( ' - Fail to Set Zabbix Key' )
                logger.exception(e)
        
        logger.info('SUCC: Set Key')
        return True
    except Exception, e:
        logger.error("Fail to Set Key, Unknown Error, exc=%s"%str(e))
        logger.exception(e)
        return False

def initStatus(_ob_info, _ol):
    from onebox_agent.util.onebox_manager import OBAStatusManager, OneBoxState, StateManager, WANStateManager, VNFStateManager, EtcStateManager, NetStateManager
    # Init ob status
    _oba_stat = OBAStatusManager()
    
    if not _oba_stat.is_keep_backup_stat() :
        StateManager().set_state(OneBoxState.RUNNING)
    if not _oba_stat.is_keep_wan_stat() :
        WANStateManager().set_state(OneBoxState.RUNNING)
    if not _oba_stat.is_keep_vnf_set() :
        VNFStateManager().set_state(OneBoxState.RUNNING)
    if not _oba_stat.is_keep_ntf_on() :
        EtcStateManager().init(EtcStateManager.TP_NTF)
    if not _oba_stat.is_keep_wsw_on() :
        EtcStateManager().init(EtcStateManager.TP_WSW)
    if not _oba_stat.is_keep_net_stat() :
        NetStateManager().init(_ob_info, _ol)
    
    _oba_stat.init()
    _ol.correct_nic_drv()


def makeApp( _oba_data ):
    app = Application(
                      file_handler.url( _oba_data )
                      + zba_handler.url( _oba_data )
                      + backup_handler.url( _oba_data)
                      + status_handler.url(_oba_data)
                      + wansw_handler.url(_oba_data)
                      + scheduler_handler.url(_oba_data)
                      + vnf_info_handler.url(_oba_data)
                     )
    
    return app

def startScheduler( oba_data ):
    logger.info('Start Scheduler....' )

    obstat = OBStatusSchd(oba_data[oc.OTAG_LIB_OB])
    obstat.start()
    
    obnetnoti = OBNetNotiSchd(oba_data[oc.OTAG_LIB_OB], oba_data[oc.OTAG_OBA_INFO])
    obnetnoti.start()

    wanMon = WanMonSchd(oba_data[oc.OTAG_LIB_OB], oba_data[oc.OTAG_OBA_INFO])
    wanMon.start()

    # add check ovs br-int flow rules in big ob
    if str(oba_data[oc.OTAG_OBA_INFO].m_os).lower().find("ubuntu 18.") > -1:
        ovschk = OvsModSchd()
        ovschk.start()

def startAPI(app, _port):
    logger.info('Start API : port=%s'%(str(_port)))
    svr = httpSvrThread(app, _port)
    svr.run()

def main():
    
    parser = OptionParser(usage="usage: %prog [options]", version="One-Box Agent version %s"%oc.VAL_OB_VER)
    parser.add_option("-c", "--config-file",
                       dest="config", 
                       type="string",
                       help="configuration file")
    # flag for orch connector. False if used (no orch connector)
    parser.add_option("-n", action="store_false", dest="orch_connect", default=True, help="no orchestrator connection")
    (options, args) = parser.parse_args()
    
    #cfgName = './cfg/oba.cfg'
    if options.config == None:
        parser.print_help()
        sys.exit(0)
    else:
        cfgName = options.config

    logger.info("---------------[[[ OneBox-Agent Start ]]]---------------")
    
    with open(cfgName, "r") as f:
        _oba_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
    _ob_info = OB_INFO().loadByCfg(_oba_cfg, True)

    _os = linux_plugin.get_os_name()
    logger.info("os name = %s" % _os)
    _ob_info.m_os = _os

    from onebox_agent.util import ob_lib
    obLib = ob_lib.create_lib(_ob_info, logger)
    if obLib is None:
        raise Exception("Failed to load valid os plugins")

    # check hw model info
    _ob_info.m_hw = obLib.get_hw_info(_ob_info)
    if _ob_info.m_hw.hw_model() is None:
        raise Exception("Failed to get hardware model. Check /var/onebox/hardware/model")

    oba_data = {oc.OTAG_VER: oc.VAL_OB_VER,
                oc.OTAG_CFG_FILE: cfgName,
                oc.OTAG_OBA_INFO: _ob_info,
                oc.OTAG_LIB_OB: obLib}
    
    try:
        setKey()
        initStatus(_ob_info, obLib)
        
        if options.orch_connect:
            startScheduler(oba_data)
        
        sleep(5)
        app = makeApp(oba_data)
        startAPI(app, _ob_info.oba_port())
        
        logger.info("---------------[[[ OneBox-Agent Stop ]]]----------------")
    except Exception, e:
        logger.exception(e)
        raise e


if __name__ == '__main__':
    main()
