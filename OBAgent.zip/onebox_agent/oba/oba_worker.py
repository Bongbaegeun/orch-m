#-*- coding: utf-8 -*-
'''
Created on 2017. 9. 6.

@author: ohhara
'''


import threading
from time import sleep



from onebox_agent.oba import oba_constant as oac
from onebox_agent.util import ob_constant as oc
from onebox_agent.util.onebox_manager import WANStateManager, OneBoxState, WanWorkManager, WORK_FAIL, WORK_DOING, WORK_DONE

import logging
logger = logging.getLogger(oac._L_TITLE)


class _Worker(threading.Thread):
    
    STATE_STORE = None
    
    def __init__(self, _stat_err, _workmgr=None):
        threading.Thread.__init__(self)
        
        self._caller = None
        self._stat_err = ( _stat_err if type(_stat_err) == OneBoxState else OneBoxState.UNDEFINED )
        self._workmgr = _workmgr
        self.status = None
        self.desc = None
    
    def get_status(self):
        return self.status, self.desc
    
    def _update_status(self, status, desc):
        if self._workmgr != None :
            self._workmgr.set_state(status, desc)
        self.status = status
        self.desc = desc
    
    def _fail(self, _err):
        logger.error("## [%s] Fail to %s, %s, job_id=%s"%( str(self._caller), self._title, _err, self.job_id ))
        self._update_status(WORK_FAIL, _err)
        WANStateManager().set_state(self._stat_err)
    
    def forced_fail(self, _err):
        logger.error("## [%s] Fail to %s, %s, job_id=%s"%( str(self._caller), self._title, _err, self.job_id ))
        self._update_status(WORK_FAIL, _err)
        WANStateManager().set_state(self._stat_err)
    
    def _ok(self, _msg):
        logger.info("## [%s] SUCC: %s, job_id=%s, msg=%s"%( str(self._caller), self._title, self.job_id, _msg ))
        self._update_status(WORK_DONE, _msg)
        WANStateManager().set_state(OneBoxState.RUNNING)


class WanTestWorker(_Worker):
    
    def __init__(self, _caller, direction, ob_info, _ol, job_id=None):
        if job_id == None :
            _Worker.__init__(self, OneBoxState.WAN_TEST_ERROR)
        else:
            _Worker.__init__(self, OneBoxState.WAN_TEST_ERROR, WanWorkManager(job_id))
        self._title = "WanTestWork"
        
        WANStateManager().set_state(OneBoxState.WAN_TEST_REQUESTED)
        self._caller = _caller
        self.job_id = ( _caller if job_id == None else job_id)
        self.direction = direction
        self.ob_info = ob_info
        self._ol = _ol
        
        self._check()
    
    def _check(self):
        # DOING, DONE, FAIL
        if self.ob_info.is_in_band() :
            if self.direction not in [oac.VAL_SW_HOST2VM, oac.VAL_SW_VM2HOST] :
                _err = "Invalid SW-Direction, direction=%s"%str(self.direction)
                self._fail(_err)
            else:
                _res = "Create Worker for WanTestRequest, direction=%s"%(self.direction)
                self._update_status(WORK_DOING, _res)
        else:
            self._fail("Invalid Mgmt-Mode, mode=Out-Of-Band")
    
    def run(self):
        if self.status == WORK_FAIL :
            logger.warning("[%s] Stop %s, status=%s"%( str(self._caller), self.status ))
            return
        
        logger.info("## [%s] Start %s, job_id=%s, direct=%s"%( str(self._caller), self._title, self.job_id, self.direction ))
        WANStateManager().set_state(OneBoxState.WAN_TEST_IN_PROGRESS)
        try:
            ## GW, DNS
            _wan_mode = (oc.VAL_WAN_MD_HOST if self.direction == oac.VAL_SW_VM2HOST else oc.VAL_WAN_MD_VNF)
            _ret = False
            _err = None
            _retry = 5
            for _i in range(_retry) :
                _ret, _err, _ecode = self._ol.chk_conn(self.ob_info, _wan_mode)
                if _ret :
                    break
                else:
                    logger.warning("## [%s] -- Fail to Check Conn, retry=%s/%s, err=%s, ecode=%s"%(
                                        str(self._caller), str(_i+1), str(_retry), str(_err), str(_ecode) ))
                sleep(3)
            
            if _ret :
                self._ok("Pass WAN Network Test")
            else:
                self._fail(_err)
            return
        except Exception, e:
            self._fail(str(e))
            logger.exception(e)
            return




class WanSwitchWorker(_Worker):
    
    def __init__(self, _caller, direction, ob_info, _ol, job_id=None):
        if job_id == None :
            _Worker.__init__(self, OneBoxState.WAN_SW_ERROR)
        else:
            _Worker.__init__(self, OneBoxState.WAN_SW_ERROR, WanWorkManager(job_id))
        self._title = "WanSwWork"
        
        self._caller = _caller
        WANStateManager().set_state(OneBoxState.WAN_SW_REQUESTED)
        self.job_id = ( _caller if job_id == None else job_id )
        self.direction = direction
        self.ob_info = ob_info
        self._ol = _ol
        
        self._check()
    
    
    def _check(self):
        # DOING, DONE, FAIL
        if self.ob_info.is_in_band() :
            if self.direction not in [oac.VAL_SW_HOST2VM, oac.VAL_SW_VM2HOST] :
                _err = "Invalid SW-Direction, direction=%s"%str(self.direction)
                self._fail(_err)
            else:
                _res = "Create Worker for WanSwitchRequest, direction=%s"%(self.direction)
                self._update_status(WORK_DOING, _res)
        else:
            self._fail("Invalid Mgmt-Mode, mode=Out-Of-Band")
    
    
    def _switch_vnf(self):
        try:
            ## VIM INIT & Bind Dev Kern
            self._ol.correct_nic_drv()
            
            ### Host Bridge Setting
            ## Get Host Bridge IF
            _hostBr = self._ol.get_host_bridge()
            if _hostBr == None :
                logger.warning("    ## [%s] No Host Bridge"%str(self._caller))
                _hostBr = []
            logger.info("    ## [%s] - Host-Bridge=%s"%( str(self._caller), str(_hostBr) ))
            
            _wan_nic_list = []
            _wan_list = self.ob_info.wan_list()
            for _wan in _wan_list :
                _wan_nic = _wan.nic()
                if _wan_nic != None and str(_wan_nic).strip() != "" :
                    _wan_nic_list.append(str(_wan_nic).strip())
            
            ## Del Host Bridge IF
            for brName in _hostBr :
                _lxbrIfList = self._ol.get_os().get_br_ifs(brName)
                if _lxbrIfList == None :
                    logger.warning("    ## [%s] No Host Bridge Interface, br=%s"%( str(self._caller), str(brName) ))
                    continue
                
                logger.info("    ## [%s] - Host-Bridge=%s, nic=%s"%( str(self._caller), str(brName), str(_lxbrIfList) ))
                for _lxbrIf in _lxbrIfList :
                    if _lxbrIf in _wan_nic_list :
                        if self._ol.get_os().del_br_if(brName, _lxbrIf) :
                            logger.info("    ## [%s] Delete Host Bridge Interface, br=%s, if=%s"%( str(self._caller), brName, _lxbrIf ))
                        else:
                            logger.warning("    ## [%s] Fail to Delete Host Bridge Interface, br=%s, if=%s"%( str(self._caller), brName, _lxbrIf ))
            
            ## Ifconfig Down Bridge
            for brName in _hostBr :
                self._ol.get_os().ifconfig_down(brName)
            
            ## dhclient Kill
            self._ol.get_os().dhclient_down()
            
            ### Host Gateway Setting
            ## Del Host Default GW
            self._ol.get_os().del_def_route()
            
            ## Add Host Default Gateway
            defGW = self.ob_info.utm_local_ip()
            if defGW == None or str(defGW).strip() == "" :
                defGW = oc.VAL_DEF_HOST_LOCAL_GW
            if not self._ol.get_os().add_def_route(defGW) :
                return False, "Host Default Gateway Error, gw=%s"%str(defGW)
            sleep(10)
            
            ### VIM-BR Setting
            ## Del VIM-Port
            for _port in _wan_nic_list :
                self._ol.get_vim().del_br_port_all(_port)
            
            ## Add VIM-BR Port
            for _wan in _wan_list :
                _prev_ifs = self._ol.get_vim().get_br_ifs(str(_wan.bridge()))
                if type(_prev_ifs) == list and str(_wan.nic()) in _prev_ifs :
                    logger.debug("    ## [%s] SKIP to Add OVS-BR-Port, Already Exist, br=%s, port=%s"%( str(_wan.bridge()), str(_wan.nic()) ))
                    continue
                
                if self._ol.get_vim().add_br_port( str(_wan.bridge()), str(_wan.nic()), self.ob_info.ovs_dpdk() ) :
                    logger.info("    ## [%s] Add OVS-BR-Port, br=%s, port=%s"%( str(self._caller), str(_wan.bridge()), str(_wan.nic()) ))
                else:
                    logger.error("    ## [%s] Fail to Add OVS-BR-Port, br=%s, port=%s"%( str(self._caller), str(_wan.bridge()), str(_wan.nic()) ))
            
            logger.info("  ## [%s] WAN-Switch to VNF"%str(self._caller))
            return True, None
        except Exception, e:
            logger.error("  ## [%s] Fail to WAN-Switch to VNF, exc=%s"%( str(self._caller), str(e) ))
            logger.exception(e)
            return False, str(e)
    
    def _switch_host(self):
        try:
            ## Host BR Down
            _mgmt_list = self.ob_info.mgmt_list()
            _mgmt_nic_list = []
            for _mgmt in _mgmt_list :
                _mgmt_nic_list.append(_mgmt.nic())
#                 self._ol.get_os().if_down(_mgmt.bridge())
            
            ## Del VIM-BR Port
            for _nic in _mgmt_nic_list :
                self._ol.get_vim().del_br_port_all(_nic)
            
            ## VIM INIT & Bind Dev Kern
            self._ol.correct_nic_drv()
            
            ## UP Host-Br
            if not self._ol.get_os().update_dhclient_config() :
                logger.warning("    ## [%s] Fail to Set DHClient Config"%str(self._caller))
            
            ## DhClient Kill
            self._ol.get_os().dhclient_down()
            
            ## Del Host Default GW
            self._ol.get_os().del_def_route()
            
            _set_gw = False
            for network in _mgmt_list :
                br_ext = network.bridge()
                nic = network.nic()
                
                self._ol.get_os().unlock_interface(br_ext)
                
                self._ol.get_os().down_and_up_interface(nic, 10)
                self._ol.get_os().down_and_up_interface(br_ext, 30)
                
                _gdev, _gip, _gm = self._ol.get_os().get_def_gw_info()
                if _gdev == None or _gdev != br_ext :
                    _down_if = threading.Thread(target=self._ol.get_os().ifconfig_down, 
                                                args=(br_ext, True))
                    _down_if.start()
                    logger.info("    ## [%s] Start Interface Down: %s"%( str(self._caller), str(br_ext) ))
                else:
                    _set_gw = True
            
            if not _set_gw :
                _mn = _mgmt_list[0]
                br_ext = _mn.bridge()
                nic = _mn.nic()
                
                self._ol.get_os().unlock_interface(br_ext)
                
                self._ol.get_os().down_and_up_interface(nic, 10)
                self._ol.get_os().down_and_up_interface(br_ext, 10)
                _gwInfo = self._ol.get_os().get_def_gw_info()
                
                if _gwInfo[0] == None or _gwInfo[0] != br_ext :
                    logger.warning("    ## [%s] Fail to Wan-Switch to Host, Invalid Def-GW, prv=%s, new=%s"%( str(self._caller), str(_gwInfo), str(_mn) ))
                    if _mn.gw() != None and str(_mn.gw()).strip() != "" :
                        self._ol.get_os().del_def_route()
                        self._ol.get_os().add_def_route(_mn.gw())
                    else:
                        logger.warning("    ## [%s] Fail to Set Default GW, No GW Info, mgmt=%s"%( str(self._caller), str(_mn) ))
            
            logger.info("  ## [%s] WAN-Switch to Host"%str(self._caller))
            return True, None
        except Exception, e:
            logger.error("  ## [%s] Fail to WAN-Switch to Host, exc=%s"%( str(self._caller), str(e) ))
            logger.exception(e)
            return False, str(e)
    
    
    def run(self):
        if self.status == WORK_FAIL :
            logger.warning("[%s] Stop %s, status=%s"%( str(self._caller), self.status ))
            return
        
        logger.info("## [%s] Start %s, job_id=%s, direct=%s"%( str(self._caller), self._title, self.job_id, self.direction ))
        WANStateManager().set_state(OneBoxState.WAN_SW_IN_PROGRESS)
        try:
            _has_utm = self._ol.hasUtm(self.ob_info.wan_mac_list())
            _wan_mode = self._ol.getWanMode(self.ob_info)
            
            logger.info("  ## [%s] OneBox Wan Info, has_utm=%s, wan_mode=%s"%( str(self._caller), str(_has_utm), str(_wan_mode) ))
            # sw host -> vm
            if self.direction == oac.VAL_SW_HOST2VM :
                # mode : vm
                if _wan_mode == oc.VAL_WAN_MD_VNF :
                    self._ok("WAN-Mode is Already VM")
                    return
                
                # mode : Invalid
                if not _has_utm :
                    _err = "No VM(UTM)"
                    self._fail(_err)
                    return
                # mode : host or Unknown
                else:
                    _uip = self.ob_info.utm_local_ip()
                    _has_utm = self._ol.hasUtm(self.ob_info.wan_mac_list())
                    _wan_mode = self._ol.getWanMode(self.ob_info)
                    _prv_mgmt_ip = self._ol.get_mgmt_ip(_has_utm, _wan_mode, _uip)
                    
                    _ret, _err = self._switch_vnf()
                    if _ret :
                        self._ok("WAN-Switch to VM")
                    else:
                        self._fail(_err)
                    # update vim-ip
                    self._ol.update_vim_ip( self.ob_info, _prv_mgmt_ip, 10, True)
                    return
            
            # sw vm -> host
            elif self.direction == oac.VAL_SW_VM2HOST :
                # mode : host
                if _wan_mode == oc.VAL_WAN_MD_HOST :
                    self._ok("WAN-Mode is Already Host")
                    return
                
                _uip = self.ob_info.utm_local_ip()
                _has_utm = self._ol.hasUtm(self.ob_info.wan_mac_list())
                _wan_mode = self._ol.getWanMode(self.ob_info)
                _prv_mgmt_ip = self._ol.get_mgmt_ip(_has_utm, _wan_mode, _uip)
                
                # mode : others
                _ret, _err = self._switch_host()
                if _ret :
                    self._ok("WAN-Switch to Host")
                else:
                    self._fail(_err)
                
                # update vim-ip
                self._ol.update_vim_ip( self.ob_info, _prv_mgmt_ip, 10, True)
                return
            
            # Invalid Direction
            else:
                self._fail("Invalid Direction, direction=%s"%( self.direction ))
                return
        except Exception, e:
            self._fail(str(e))
            logger.exception(e)
            return
        
        






