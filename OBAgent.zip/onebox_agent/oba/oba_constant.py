#-*- coding: utf-8 -*-
'''
Created on 2017. 9. 4.

@author: ohhara
'''

_L_TITLE = "onebox-agent"


DIR_BACKUP_TMP = "/tmp/%s"
DIR_BACKUP_LOCAL = "/var/onebox/backup/OneBox/%s"
DIR_BACKUP_SRC = ["/etc/network/interfaces.d", "/var/onebox/vnf_configs", "/etc/zabbix/zabbix_agentd.conf.d/", "/usr/plugin"]
DIR_RESTORE_VNFM = ["/var/onebox/vnf_configs"]
DIR_RESTORE_MONA = ["/etc/zabbix/zabbix_agentd.conf.d", "/usr/plugin"]


FILE_BACKUP_LOCAL = "backup-%s.tar.gz"
FILE_BACKUP_REMOTE = "/var/onebox/backup/%s/OneBox/%s"
FILE_BACKUP_SRC_ETC = ["/etc/hosts", "/etc/network/interfaces", "/etc/network/if-pre-up.d/iptablesload", "/etc/iptables.up.rules" ]
FILE_BACKUP_SRC_NOVA = ["/etc/nova/nova.conf", "/etc/nova/nova-compute.conf"]
FILE_BACKUP_SRC_NEUTRON = ["/etc/neutron/neutron.conf", "/etc/neutron/plugins/ml2/ml2_conf.ini", "/etc/openvswitch/conf.db"]
FILE_RESTORE_SRC_NEUTRON = ["/etc/neutron/neutron.conf", "/etc/neutron/plugins/ml2/ml2_conf.ini"]
FILE_BACKUP_SRC_OBA = ["/etc/onebox/onebox-agent.conf"]
FILE_BACKUP_SRC_VNFM = ["/etc/onebox/onebox-vnfm.conf"]
FILE_BACKUP_SRC_MONA = ["/etc/zabbix/zabbix_agentd.conf"]
FILE_BACKUP_SRC_NMSA = ["/var/onebox/softwares/onebox-znmsc/znmsc.ini", 
                        "/var/onebox/softwares/onebox-znmsc/znmsc.pkey",
                        "/var/onebox/softwares/onebox-znmsc/bin/znmsc"]

FILE_BACKUP_SRC_SMSA = ["/var/onebox/softwares/onebox-zsmsc/zsmsc.eini", 
                        "/var/onebox/softwares/onebox-zsmsc/zsmsc.pkey",
                        "/var/onebox/softwares/onebox-zsmsc/bin/zsmsc"]

SVC_RESTORE_VNFM = ["onebox-vnfm"]
SVC_RESTORE_MONA = ["zabbix-agent"]
SVC_RESTORE_NMSA = ["znmsc"]
SVC_RESTORE_SMSA = ["zsmsc"]
SVC_RESTORE_OBA = ["onebox-agent"]


VAL_SW_VM2HOST = "vm2host"
VAL_SW_HOST2VM = "host2vm"

CALLER_API = "API"
CALLER_SCHD = "SCHD"

RET_OK = "OK"

T_WAN_PASS_WAIT_FOR_BR = 20
T_WAN_PASS_WAIT_FOR_SW = 30
T_WAN_PASS_WAIT_FOR_VNF = 10




