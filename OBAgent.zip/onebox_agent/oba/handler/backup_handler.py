#!/usr/bin/python
#-*- coding: utf-8 -*-

import httplib, json, datetime, os, threading
from tornado.web import MissingArgumentError


from onebox_agent.util import ob_constant as oc
from onebox_agent.oba import oba_constant as oac
from onebox_agent.oba.handler.orchf_req_handler import OrchfRequestHandler
from onebox_agent.util.onebox_manager import OBAStatusManager, OneBoxState, StateManager, BRStateManager, STATUS_TYPE_BACKUP, STATUS_TYPE_RESTORE
from onebox_agent.util import onebox_manager, ob_worker

import logging
from time import sleep
logger = logging.getLogger(oac._L_TITLE)

url_base="/v1"

OP_BACKUP = "BACKUP"
OP_RESTORE = "RESTORE"
OP_RESTORE_PROG = "RESTORE-PROG"


class _RestoreWork(threading.Thread):
    
    def __init__(self, _ol, trans_id, local_location, backup_data, backup_server_ip, backup_server_port, remote_location, restart_obagent, _ovs_dpdk=False):
        threading.Thread.__init__(self)
        
        self._ol = _ol
        self.tid = trans_id
        self.backup_ip = backup_server_ip
        self.backup_port = backup_server_port
        self.local_loc = local_location
        self.remote_loc = remote_location
        self.backup_data = backup_data
        self.oba_restart = restart_obagent
        self.statemgr = StateManager()
        self.restorestatemgr = BRStateManager(STATUS_TYPE_RESTORE, trans_id)
        self.ovs_dpdk = _ovs_dpdk
    
    def update_state(self, state, cur_step, tot_step):
        logger.info(" - Update Restore-State: tid=%s, state=%s, prog=%d/%d" % (self.tid, state.name, cur_step, tot_step))
        self.statemgr.set_state(state)
        self.restorestatemgr.set_state(state, cur_step, tot_step)
    
    def run(self):
        _rwrk = ob_worker.ObWork_Recovery(self._ol, logger, self.local_loc, "/tmp/restore", 
                                          self.backup_ip, self.backup_port, self.remote_loc, False, self.ovs_dpdk)
        
        tot_step = len(_rwrk.item_list())
        cur_step = _rwrk.get_idx() + 1
        try:
            logger.info("Start RestoreReq, tid=%s, local_loc=%s, backup_svr_ip=%s, remote_loc=%s"%(
                            self.tid, self.local_loc, self.backup_ip, self.remote_loc))        
            self.update_state(OneBoxState.RESTORE_IN_PROGRESS, cur_step, tot_step)
            
            _rwrk.start()
            while True:
                sleep(2)
                
                _rret = _rwrk.result()
                if _rret[0] != _rwrk.STAT_RUN :
                    break
                else:
                    cur_step = _rwrk.get_idx() + 1
                    self.update_state(OneBoxState.RESTORE_IN_PROGRESS, cur_step, tot_step)
            
            _res, _ret, _err = _rwrk.result()
            cur_step = _rwrk.get_idx() + 1
            if _res != _rwrk.STAT_COMP :
                self.update_state(OneBoxState.RESTORE_ERROR, cur_step, tot_step)
            else:
                logger.info("SUCC: Restore, tid=%s"%self.tid)
                self.update_state(OneBoxState.RESTORE_DONE, cur_step, tot_step)
            
            # RUNNING state
            # restore 동작이 완료된 후 OneBox의 상태를 RUNNING으로 설정
            self.statemgr.set_state(OneBoxState.RUNNING)
            
            OBAStatusManager().keep_ntf_on(True)
            OBAStatusManager().keep_wsw_on(True)
            
            if self.oba_restart :
                logger.info("--------[RESTORE] OBA Restart--------")
                self._ol.restart_service([oc.VAL_OBA_NAME])
            
        except Exception, e:
            logger.error("Fail to Restore, Unknown Error, tid=%s, exc=%s"%( self.tid, str(e) ))
            logger.exception(e)
            # TODO: NGKIM - ERROR 시 처리 (message 값 추가하여 str(e) 전달?)
            self.update_state(OneBoxState.RESTORE_ERROR, cur_step, tot_step)


class BackupHandler(OrchfRequestHandler):
    
    def initialize(self, opCode, _data):
        self.opCode = opCode
        self._data = _data
        self._ol = _data[oc.OTAG_LIB_OB]
    
    def post(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req [[Backup]]: %s, body=%s"%( str(self.opCode), str(reqdata) ))
        
        try:
            reqdata = json.loads(self.request.body)
            if self.opCode == OP_BACKUP :
                res = self.backup(reqdata)
            elif self.opCode == OP_RESTORE :
                res = self.restore(reqdata)
            else:
                res = self.retErr(httplib.BAD_REQUEST, "Unknown Post URL or Operation, opcode=%s"%str(self.opCode))
        except Exception, e:
            logger.error("Fail to Handle BackupAPI, op=%s, body=%s, exc=%s"%( self.opCode, str(reqdata), str(e) ))
            logger.exception(e)
            res = self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
        
        logger.info("<<<< Send-Res [[Backup]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()
    
    def get(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req [[Backup]]: %s, body=%s"%( str(self.opCode), str(reqdata) ))
        
        try:
            if self.opCode == OP_RESTORE_PROG :
                res = self.restore_prog()
            else:
                res = self.retErr(httplib.BAD_REQUEST, "Unknown Get URL or Operation, opcode=%s"%str(self.opCode))
        except Exception, e:
            logger.error("Fail to Handle BackupAPI, op=%s, body=%s, exc=%s"%( self.opCode, str(reqdata), str(e) ))
            logger.exception(e)
            res = self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
        
        logger.info("<<<< Send-Res [[Backup]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()
    
    
    def _create_archive(self, _date):
        etc_files = oac.FILE_BACKUP_SRC_ETC
        
        nova_files = oac.FILE_BACKUP_SRC_NOVA
        neutron_files = oac.FILE_BACKUP_SRC_NEUTRON
        
        oba_files = oac.FILE_BACKUP_SRC_OBA
        vnfm_files = oac.FILE_BACKUP_SRC_VNFM
        zabbix_files = oac.FILE_BACKUP_SRC_MONA
        nmsa_files = oac.FILE_BACKUP_SRC_NMSA
        smsa_files = oac.FILE_BACKUP_SRC_SMSA

        dirs = oac.DIR_BACKUP_SRC
        dirs_to_archive = ["etc", "usr", "var"]
        
        try:
            backup_root = oac.DIR_BACKUP_TMP%str(_date)
            local_location = os.path.join(oac.DIR_BACKUP_LOCAL%str(_date), oac.FILE_BACKUP_LOCAL%str(_date))
            
            for src in etc_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)
            
            for src in nova_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)
            
            for src in neutron_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)
            
            for src in oba_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)
            
            for src in vnfm_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)
            
            for src in zabbix_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)
            
            for src in nmsa_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)

            for src in smsa_files:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyFile(src, dst)
            
            for src in dirs:
                dst = "%s%s" % (backup_root, src)
                self._ol.copyDir(src, dst)
            
            self._ol.tar(local_location, backup_root, dirs_to_archive)
            return local_location
        except Exception, e:
            logger.error("Fail to Create Backup Archive, Unknown Error, exc=%s"%str(e))
            logger.exception(e)
            return None
    
    def backup(self, reqData):
        try:
            backup_server_ip = reqData['backup_server_ip']
            if 'backup_server_port' in reqData:
                backup_server_port = reqData['backup_server_port']
            else:
                backup_server_port = 9922
            
            # TODO: Perform One-Box Backup 
            _chk = onebox_manager.chk_all_inprogress()
            if _chk != None :
                _err = "Other Request IN-Progress, status=%s"%str(_chk)
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr( httplib.BAD_REQUEST, _err)
            
            statemgr = StateManager()
            statemgr.set_state(OneBoxState.BACKUP_REQUESTED)
            trans_id = onebox_manager.new_tid()
            tot_step = 3
            
            backstatemgr = BRStateManager(STATUS_TYPE_BACKUP, trans_id)
            backstatemgr.set_state(OneBoxState.BACKUP_REQUESTED, 1, tot_step)
            
            # archive files and copy them to backup location (local + remote)
            today = datetime.datetime.now() 
            _date = today.strftime('%y%m%d-%H%M')
            local_location = self._create_archive(_date)
            if local_location == None :
                logger.error("Fail to %s, Backup-TAR-File Create Error"%self.opCode)
                statemgr.set_state(OneBoxState.BACKUP_ERROR)
                return self.retErr(httplib.INTERNAL_SERVER_ERROR, "fail to create backup archive file")
            
            statemgr.set_state(OneBoxState.BACKUP_IN_PROGRESS)
            backstatemgr.set_state(OneBoxState.BACKUP_IN_PROGRESS, 2, tot_step)
            
            # COPY to remote backup location
            _ob_info = self._data[oc.OTAG_OBA_INFO]
            _ob_id = _ob_info.ob_id()
            remote_location = oac.FILE_BACKUP_REMOTE%(_ob_id, _date)
            _ret = self._ol.scp_put(backup_server_ip, backup_server_port, local_location, remote_location)
            
            if not _ret: 
                _err = "BackupFile Remote Copy Error, dst=%s:%s"%( backup_server_ip, backup_server_port )
                logger.error("Fail to %s, %s"%( self.opCode, _err ) )
                
                # error but check it's done
                statemgr.set_state(OneBoxState.BACKUP_DONE)
                backstatemgr.set_state(OneBoxState.BACKUP_DONE, 3, tot_step)
                statemgr.set_state(OneBoxState.RUNNING)
                
                return self.retErr(httplib.INTERNAL_SERVER_ERROR, _err)
            
            obb = _ob_info.to_ob_net_info(logger)
            if obb == None :
                _err = "OneBox NetworkInfo Get Error"
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                statemgr.set_state(OneBoxState.BACKUP_ERROR)
                return self.retErr(httplib.INTERNAL_SERVER_ERROR, _err)
            remote_file = os.path.join( remote_location, os.path.basename(local_location) )
            _res = {'result': oac.RET_OK, 'backup_data': obb, 
                    'backup_server_ip': backup_server_ip, 'backup_server_port': backup_server_port,
                    'local_location': local_location, 'remote_location': remote_file}
            
            statemgr.set_state(OneBoxState.BACKUP_DONE)
            backstatemgr.set_state(OneBoxState.BACKUP_DONE, 3, tot_step)
            
            # RUNNING state
            # backup이 완료된 후 OneBox의 상태를 RUNNING으로 설정
            statemgr.set_state(OneBoxState.RUNNING)
            
            logger.info("SUCC: %s, tid=%s"%( self.opCode, trans_id ))
            _res = json.dumps(_res)
            return self.retOK(_res)
        except KeyError, e:
            logger.error("Fail to %s, No Key, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            statemgr.set_state(OneBoxState.BACKUP_ERROR)
            return self.retErr( httplib.BAD_REQUEST, "KeyError: %s"%str(e) )
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            statemgr.set_state(OneBoxState.BACKUP_ERROR)
            return self.retErr( httplib.INTERNAL_SERVER_ERROR, e )
    
    def restore(self, reqData):
        try:
            backup_server_ip = reqData['backup_server_ip']
            if 'backup_server_port' in reqData:
                backup_server_port = reqData['backup_server_port']
            else:
                backup_server_port = 9922
                
            local_location = reqData['local_location']
            remote_location = reqData['remote_location']
            backup_data = reqData['backup_data']
            
            # TODO: Perform One-Box Restore
            _chk = onebox_manager.chk_all_inprogress()
            if _chk != None :
                _err = "Other Request IN-Progress, status=%s"%str(_chk)
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr( httplib.BAD_REQUEST, _err)
            
            statemgr = StateManager()
            statemgr.set_state(OneBoxState.RESTORE_REQUESTED)
            trans_id = onebox_manager.new_tid()
            _ob_info = self._data[oc.OTAG_OBA_INFO]
            restore_thread = _RestoreWork(self._ol, trans_id, local_location, backup_data, backup_server_ip, 
                                          backup_server_port, remote_location, True, _ob_info.ovs_dpdk())
            restore_thread.start()
            
            _res = {'transaction_id': trans_id, 'status': oc.STATUS_DOING, 'message': "Restore requested",
                    'current_step': 1, 'total_step': 8}
            
            logger.info("SUCC: %s, tid=%s"%( self.opCode, trans_id ))
            return self.retOK(_res)
        except KeyError, e:
            logger.error("Fail to %s, No Key, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr( httplib.BAD_REQUEST, "KeyError: %s"%str(e) )
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr( httplib.INTERNAL_SERVER_ERROR, e )
    
    def restore_prog(self):
        
        try:
            transaction_id = self.get_argument("transaction_id")
            if transaction_id != "":
                statemgr = BRStateManager(STATUS_TYPE_RESTORE, transaction_id)
                status = statemgr.get_state()
                if status == None :
                    _err = "No Transaction_id, tid=%s"%transaction_id
                    logger.error("Fail to %s, %s"%( self.opCode, _err ))
                    return self.retErr(httplib.BAD_REQUEST, _err)
                
                cur_step = status["current_step"]
                total_step = status["total_step"]
                _ret = {'transaction_id': transaction_id, 'message': status["progress"],
                        'current_step': cur_step, 'total_step': total_step}
                if status["status"] in [OneBoxState.RESTORE_REQUESTED.name, 
                                        OneBoxState.RESTORE_IN_PROGRESS.name] :
                    _ret['status'] = oc.STATUS_DOING
                elif status["status"] == OneBoxState.RESTORE_DONE.name :
                    _ret['status'] = oc.STATUS_DONE
                elif status["status"] == OneBoxState.RESTORE_ERROR.name :
                    _ret['status'] = oc.STATUS_ERROR
                else:
                    _err = "Unknown Restore State, state=%s"%str(status['status'])
                    logger.error("Fail to %s, %s"%( self.opCode, _err ))
                    return self.retErr(httplib.INTERNAL_SERVER_ERROR, _err)
                return _ret
            else:
                _err = "Need Transaction_id as an argument"
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr( httplib.BAD_REQUEST, _err)
        except MissingArgumentError, e:
            logger.error("Fail to %s, Argument Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr( httplib.BAD_REQUEST, e )
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr( httplib.INTERNAL_SERVER_ERROR, e )



def url( _data ):
    url = [ 
            ('%s/backup'%url_base, BackupHandler, dict(opCode=OP_BACKUP, _data=_data)),
            ('%s/restore'%url_base, BackupHandler, dict(opCode=OP_RESTORE, _data=_data)),
            ('%s/restore/progress'%url_base, BackupHandler, dict(opCode=OP_RESTORE_PROG, _data=_data)),
            ]
    return url
