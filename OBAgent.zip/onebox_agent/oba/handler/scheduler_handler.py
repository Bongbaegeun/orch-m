#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, httplib


from onebox_agent.util import ob_constant as oc
from onebox_agent.oba import oba_constant as oac
from onebox_agent.oba.handler.orchf_req_handler import OrchfRequestHandler
from onebox_agent.util.onebox_manager import EtcStateManager, NetStateManager
from onebox_agent.data.ob_info import OB_NET

import logging
logger = logging.getLogger(oac._L_TITLE)

url_base="/v1"

OP_NOTI_OBINFO_PAUSE = "PAUSE-NOTIFY_OBINFO"
OP_NOTI_OBINFO_RESUME = "RESUME-NOTIFY_OBINFO"

OP_NOTI_OBINFO = "NOTIFY-OBINFO"

OP_WAN_MON_PAUSE = "PAUSE-WAN_MONITOR"
OP_WAN_MON_RESUME = "RESUME-WAN_MONITOR"
OP_WAN_MODE = "GET-WAN_MODE"

OP_SCHD_PAUSE = "PAUSE-SCHD"
OP_SCHD_RESUME = "RESUME-SCHD"


class SchdHandler(OrchfRequestHandler):
    
    def initialize(self, opCode, _data):
        self.opCode = opCode
        self._data = _data
        self._ol = _data[oc.OTAG_LIB_OB]
        self._ob_info = _data[oc.OTAG_OBA_INFO]
    
    def post(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req [[Scheduler]]: %s, body=%s"%( str(self.opCode), str(reqdata) ))
        
        try:
            reqdata = json.loads(self.request.body)
            if self.opCode == OP_WAN_MON_PAUSE :
                if type(reqdata) == dict and reqdata.has_key("timeout") :
                    res = self._wan_mon_pause(reqdata['timeout'])
                else:
                    res = self._wan_mon_pause()
            elif self.opCode == OP_SCHD_PAUSE :
                if type(reqdata) == dict and reqdata.has_key("timeout") :
                    res = self._schd_pause(reqdata['timeout'])
                else:
                    res = self._schd_pause()
            else:
                res = self.retErr(httplib.BAD_REQUEST, "Unknown Post URL or Operation, opcode=%s"%str(self.opCode))
        except Exception, e:
            logger.error("Fail to Handle Scheduler API, op=%s, body=%s, exc=%s"%( self.opCode, str(reqdata), str(e) ))
            logger.exception(e)
            res = self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
        
        logger.info("<<<< Send-Res [[Scheduler]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()
    
    def get(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req [[Scheduler]]: %s, body=%s"%( str(self.opCode), str(reqdata) ))
        
        try:
            if self.opCode == OP_NOTI_OBINFO :
                res = self._noti_obinfo()
            elif self.opCode == OP_NOTI_OBINFO_PAUSE :
                res = self._noti_obinfo_pause()
            elif self.opCode == OP_NOTI_OBINFO_RESUME :
                res = self._noti_obinfo_resume()
            
            elif self.opCode == OP_WAN_MODE :
                res = self._get_wan_mode()
            elif self.opCode == OP_WAN_MON_PAUSE :
                res = self._wan_mon_pause()
            elif self.opCode == OP_WAN_MON_RESUME :
                res = self._wan_mon_resume()
            
            elif self.opCode == OP_SCHD_PAUSE :
                res = self._schd_pause()
            elif self.opCode == OP_SCHD_RESUME :
                res = self._schd_resume()
            else:
                res = self.retErr(httplib.BAD_REQUEST, "Unknown Get URL or Operation, opcode=%s"%str(self.opCode))
        except Exception, e:
            logger.error("Fail to Handle Scheduler API, op=%s, body=%s, exc=%s"%( self.opCode, str(reqdata), str(e) ))
            logger.exception(e)
            res = self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
        
        logger.info("<<<< Send-Res [[Scheduler]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()
    
    def _schd_pause(self, _t=None):
        '''
        return : 
            OK= retOK( result=OK )
            error= error:description
        '''
        try:
            if _t != None and type(_t) != int :
                logger.warning(" - Fail to %s, Invalid Param, wait=%s"%str(_t))
                _t = None
            
            EtcStateManager().run_wan_sw_schd(False, _t)
            
            EtcStateManager().run_noti_ob_schd(False)
            return self.retOK({'result':oac.RET_OK})
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _schd_resume(self):
        '''
        return : 
            OK= retOK( result=OK )
            error= error:description
        '''
        try:
            EtcStateManager().run_noti_ob_schd(True)
            EtcStateManager().run_wan_sw_schd(True)
            return self.retOK({'result':oac.RET_OK})
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _noti_obinfo(self):
        '''
        return : 
            OK= retOK
            error= error:description
        '''
        try:
            _net_state_json = NetStateManager().get_state()
            _net_state_info = OB_NET().load(_net_state_json)
            _ob_noti = self._ol.to_obinfo_for_orchf(_net_state_info, self._ob_info)
            _res = json.dumps(_ob_noti)
            return self.retOK(_res)
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _noti_obinfo_pause(self):
        '''
        return : 
            OK= retOK( result=OK )
            error= error:description
        '''
        try:
            EtcStateManager().run_noti_ob_schd(False)
            return self.retOK({'result':oac.RET_OK})
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _noti_obinfo_resume(self):
        '''
        return : 
            OK= retOK( result=OK )
            error= error:description
        '''
        try:
            EtcStateManager().run_noti_ob_schd(True)
            return self.retOK({'result':oac.RET_OK})
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _get_wan_mode(self):
        '''
        return : 
            OK= retOK( mode=vm/host/error )
            error= error:description
        '''
        try:
            _wm = self._ol.getWanMode(self._ob_info)
            if _wm == None :
                return self.retErr(httplib.INTERNAL_SERVER_ERROR, "WAN_MODE GET Error")
            elif _wm == oc.VAL_WAN_MD_HOST :
                return self.retOK({'mode': 'host'})
            elif _wm == oc.VAL_WAN_MD_VNF :
                return self.retOK({'mode': 'vm'})
            elif _wm == oc.VAL_WAN_MD_OUTBAND :
                return self.retOK({'mode': oc.VAL_WAN_MD_OUTBAND})
            else :
                return self.retErr(httplib.INTERNAL_SERVER_ERROR, "Invalid WAN_MODE, mode=%s"%str(_wm))
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _wan_mon_pause(self, _t=None):
        '''
        return : 
            OK= retOK( result=OK )
            error= error:description
        '''
        try:
            if _t != None and type(_t) != int :
                logger.warning(" - Fail to %s, Invalid Param, wait=%s"%str(_t))
                _t = None
            
            EtcStateManager().run_wan_sw_schd(False, _t)
            return self.retOK({'result':oac.RET_OK})
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _wan_mon_resume(self):
        '''
        return : 
            OK= retOK( result=OK )
            error= error:description
        '''
        try:
            EtcStateManager().run_wan_sw_schd(True)
            return self.retOK({'result':oac.RET_OK})
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))





def url( _data ):
    url = [ 
            ('%s/notify/pause' % url_base, SchdHandler, dict(opCode=OP_NOTI_OBINFO_PAUSE, _data=_data)),
            ('%s/notify/resume' % url_base, SchdHandler, dict(opCode=OP_NOTI_OBINFO_RESUME, _data=_data)),
            ('%s/onebox_info' % url_base, SchdHandler, dict(opCode=OP_NOTI_OBINFO, _data=_data)),
            
            ('%s/wanmonitor' % url_base, SchdHandler, dict(opCode=OP_WAN_MODE, _data=_data)),
            ## wan switch 방지 용
            ('%s/wanmonitor/pause' % url_base, SchdHandler, dict(opCode=OP_WAN_MON_PAUSE, _data=_data)),
            ('%s/wanmonitor/resume' % url_base, SchdHandler, dict(opCode=OP_WAN_MON_RESUME, _data=_data)),
            
            ('%s/schd/pause' % url_base, SchdHandler, dict(opCode=OP_SCHD_PAUSE, _data=_data)),
            ('%s/schd/resume' % url_base, SchdHandler, dict(opCode=OP_SCHD_RESUME, _data=_data)),
            ]
    return url


