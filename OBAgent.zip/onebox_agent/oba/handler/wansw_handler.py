#!/usr/bin/python
#-*- coding: utf-8 -*-

import json, httplib, threading
from time import sleep


from onebox_agent.util import ob_constant as oc
from onebox_agent.oba import oba_constant as oac
from onebox_agent.util import onebox_manager
from onebox_agent.oba.handler.orchf_req_handler import OrchfRequestHandler
from onebox_agent.util.onebox_manager import OneBoxState, WANStateManager, WanWorkManager, WORK_DONE, WORK_FAIL
from onebox_agent.oba.oba_worker import WanSwitchWorker, WanTestWorker

import logging
logger = logging.getLogger(oac._L_TITLE)

url_base="/v1"

OP_WAN_SW = "WAN-SWITCH"
OP_WAN_SW_TEST = "WAN-SWITCH-TEST"
OP_WAN_SW_PROG = "WAN-SWITCH-PROG"

class _WanSwTimer(threading.Thread):
    
    
    def __init__(self, _worker):
        threading.Thread.__init__(self)
        self._worker = _worker
        
    def run(self):
        _status = None
        _desc = None
        _to = 300
        __to = _to
        _period = 3
        while _to > 0 :
            sleep(_period)
            try:
                _status, _desc = self._worker.get_status()
                if _status == WORK_DONE :
                    logger.info(" - [WAN-SW API Timer] Done: SUCC")
                    return
                elif _status == WORK_FAIL :
                    logger.info(" - [WAN-SW API Timer] Done: FAIL")
                    return
            except Exception, e:
                logger.warning(" - [WAN-SW API Timer] Fail to Check WAN-SW Worker, exc=%s"%str(e))
                logger.exception(e)
            _to -= _period
        
        self._worker.forced_fail("TimeOut, to=%s"%str(__to))


class WanSwitchHandler(OrchfRequestHandler):
    
    def initialize(self, opCode, _data):
        self.opCode = opCode
        self._data = _data
        self._ol = _data[oc.OTAG_LIB_OB]
        self._ob_info = _data[oc.OTAG_OBA_INFO]
    
    def post(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req [[WAN-Switch]]: %s, body=%s"%( str(self.opCode), str(reqdata) ))
        
        try:
            reqdata = json.loads(self.request.body)
            if self.opCode == OP_WAN_SW :
                res = self._sw(reqdata)
            elif self.opCode == OP_WAN_SW_TEST :
                res = self._test(reqdata)
            else:
                res = self.retErr(httplib.BAD_REQUEST, "Unknown Post URL or Operation, opcode=%s"%str(self.opCode))
        except Exception, e:
            logger.error("Fail to Handle WAN-Switch API, op=%s, body=%s, exc=%s"%( self.opCode, str(reqdata), str(e) ))
            logger.exception(e)
            res = self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
        
        logger.info("<<<< Send-Res [[WAN-Switch]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()
    
    def get(self, job_id):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req [[WAN-Switch]]: %s, body=%s"%( str(self.opCode), str(reqdata) ))
        
        try:
            if self.opCode == OP_WAN_SW_PROG :
                res = self._prog(job_id)
            else:
                res = self.retErr(httplib.BAD_REQUEST, "Unknown Get URL or Operation, opcode=%s"%str(self.opCode))
        except Exception, e:
            logger.error("Fail to Handle WAN-Switch API, op=%s, body=%s, exc=%s"%( self.opCode, str(reqdata), str(e) ))
            logger.exception(e)
            res = self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
        
        logger.info("<<<< Send-Res [[WAN-Switch]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()
    
    def _sw(self, reqData):
        '''
        return : 
            error= error:description
            ok : {status}
        '''
        _run_worker = False
        try:
            job_id = reqData['job_id']
            direction = reqData['direction']
            
            if not self._ob_info.is_in_band() :
                _err = "Invalid Mgmt-Mode, mode=Out-Of-Band"
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                _ret = {'status': WORK_FAIL, 'error':{'code':httplib.BAD_REQUEST, 'type': "", 'description': _err}}
                return self.retErr(httplib.BAD_REQUEST, _ret)
            
            _chk = onebox_manager.chk_all_inprogress()
            if _chk != None :
                _err = "Other Request IN-Progress, status=%s"%str(_chk)
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr( httplib.BAD_REQUEST, _err)
            
            _worker = WanSwitchWorker(oac.CALLER_API, direction, self._ob_info, self._ol, job_id)
            _worker.start()
            _run_worker = True
            
            status, desc = _worker.get_status()
            if status == WORK_FAIL :
                logger.error("Fail to %s, %s"%( self.opCode, desc ))
                return self.retErr(httplib.INTERNAL_SERVER_ERROR, desc)
            
            _WanSwTimer(_worker).start()
            
            logger.info("SUCC: %s, status=%s, desc=%s"%( self.opCode, str(status), str(desc) ))
            return self.retOK({'status': status})
        except KeyError, e:
            logger.error("Fail to %s, No Key, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            if not _run_worker : WANStateManager().set_state(OneBoxState.WAN_SW_ERROR)
            return self.retErr(httplib.BAD_REQUEST, "KeyError: %s"%str(e))
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            if not _run_worker : WANStateManager().set_state(OneBoxState.WAN_SW_ERROR)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _test(self, reqData):
        try:
            job_id = reqData['job_id']
            direction = reqData['direction']
            
            _chk = onebox_manager.chk_all_inprogress()
            if _chk != None :
                _err = "Other Request IN-Progress, status=%s"%str(_chk)
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr( httplib.BAD_REQUEST, _err)
            
            _worker = WanTestWorker(oac.CALLER_API, direction, self._ob_info, self._ol, job_id)
            _worker.start()
            _run_worker = True
            
            status, desc = _worker.get_status()
            if status == WORK_FAIL :
                logger.error("Fail to %s, %s"%( self.opCode, desc ))
                return self.retErr(httplib.INTERNAL_SERVER_ERROR, desc)
            
            logger.info("SUCC: %s, status=%s, desc=%s"%( self.opCode, str(status), str(desc) ))
            return self.retOK({'status': status, 'desc': desc})
        except KeyError, e:
            logger.error("Fail to %s, No Key, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            if not _run_worker : WANStateManager().set_state(OneBoxState.WAN_TEST_ERROR)
            return self.retErr(httplib.BAD_REQUEST, "KeyError: %s"%str(e))
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            if not _run_worker : WANStateManager().set_state(OneBoxState.WAN_TEST_ERROR)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _prog(self, job_id):
        try:
            if job_id == None or str(job_id).strip() == "" :
                _err = "No JobID"
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr(httplib.BAD_REQUEST, _err)
            job_id = str(job_id).strip()
            
            wanMgr = WanWorkManager(job_id)
            _stat = wanMgr.get_state()
            if _stat == None :
                _err = "No Job-Status Info, job_id=%s"%(job_id)
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr(httplib.INTERNAL_SERVER_ERROR, _err)
            
            if _stat['status'] == WORK_FAIL :
                return self.retErr(httplib.INTERNAL_SERVER_ERROR, _stat['desc'])
            
            return self.retOK({'status': _stat['status']})
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))


def url( _data ):
    url = [ 
            ('%s/wanswitch'%url_base, WanSwitchHandler, dict(opCode=OP_WAN_SW, _data=_data)),
            ('%s/wanswitch/test'%url_base, WanSwitchHandler, dict(opCode=OP_WAN_SW_TEST, _data=_data)),
            ('%s/wanswitch/jobprogress/([^/]*)'%url_base, WanSwitchHandler, dict(opCode=OP_WAN_SW_PROG, _data=_data))
            ]
    return url


