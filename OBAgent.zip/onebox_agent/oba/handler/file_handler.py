#!/usr/bin/python
#-*- coding: utf-8 -*-



import json, os, shutil, dircache
from tornado.web import RequestHandler
from datetime import datetime

from onebox_agent.oba import oba_constant as oac
from onebox_agent.oba.handler import orchm_req_handler as orchm_req

import logging
logger = logging.getLogger(oac._L_TITLE)

import sys
reload(sys)
sys.setdefaultencoding('utf8')

FILE_PUT = 'FILE-PUT'
FILE_DEL = 'FILE-DEL'
FILE_DEL_EXCLUDE = 'FILE-DEL-EXCLUDE'



def backupFile( absName, orgDir, _backupDir ):
    if _backupDir != None and _backupDir != '' :
        if not os.path.isabs( _backupDir ) :
            backupDir = os.path.normpath( os.path.join(orgDir, _backupDir) )
        else:
            backupDir = _backupDir
        
        if not os.path.exists( backupDir ) :
            os.makedirs( backupDir )
        
        dttm = str( datetime.now().strftime("%Y%m%d_%H:%M:%S") )
        
        if os.path.isdir( absName ):
            shutil.copytree( absName, backupDir+'_'+dttm )
        elif os.path.isfile( absName ) :
            shutil.copyfile( absName, os.path.join( backupDir, os.path.basename(absName)+'.'+dttm ) )
    return

def putFile( name, data, _backupDir=None, _chmod=0755 ):
    try:
        _dir = os.path.dirname( name )
        if not os.path.exists( _dir ) :
            _backupDir = None
            os.makedirs( _dir )
        
        if not os.path.exists( name ):
            _backupDir = None
        
        backupFile( name, _dir, _backupDir )
        
        f = open( str(name), 'w+' )
        f.write( data )
        f.close()
        
        os.chmod( name, _chmod )
        logger.info( 'SUCC: Put File, file=%s'%(name) )
        return orchm_req.getOK( name )
    except Exception, e:
        logger.exception(e)
        return orchm_req.getErr( orchm_req.EXCP, e )

def delFile( _type, targets, _backupDir ):
    try:
        delList = []
        if str(_type).upper() == 'FILE':
            for target in targets:
                if os.path.isfile( target ) and os.path.isabs( target ):
                    backupFile( target, os.path.dirname(target), _backupDir )
                    os.remove( target )
                    delList.append( target )
                else:
                    logger.warning( ' - Del File is not File or Abstract Path, file=%s'%target)
                    continue
        elif str(_type).upper() == 'DIR':
            for target in targets:
                if os.path.isdir( target ) and os.path.isabs( target ):
                    backupFile( target, target, _backupDir )
                    shutil.rmtree( target )
                    delList.append( target )
                else:
                    logger.warning( ' - Del File is not Directory or Abstract Path, file=%s'%target)
                    continue
        else :
            return orchm_req.getErr( orchm_req.INVALID_DATA, 'Unknown Delete TargetType=%s'%(_type) )
        
        logger.info( 'SUCC: Del Target, file=%s'%(delList) )
        return orchm_req.getOK( targets )
    except Exception, e:
        logger.exception( e )
        return orchm_req.getErr( orchm_req.EXCP, e )

def delFileAtDir_Exclude( targetDir, excludeFile, _backupDir ):
    try:
        if not os.path.isabs(targetDir):
            logger.error( 'Fail to Delete File, TargetDir is not Abstract Dir, dir=%s'%(targetDir) )
            return orchm_req.getErr( orchm_req.INVALID_DATA, 'TargetDir is not Abstract Dir, dir=%s'%(targetDir) )
        
        fList = dircache.listdir( targetDir )
        
        for exclude in excludeFile:
            try:
                fList.remove( os.path.basename(exclude) )
            except ValueError, ve:
                logger.warning(ve)
        
        delFileList = []
        for delFile in fList:
            if delFile == None or delFile == '': continue
            
            backupFileName = os.path.join( targetDir, delFile)
            if os.path.isfile(backupFileName):
                backupFile( backupFileName, targetDir, _backupDir )
                os.remove( backupFileName )
                delFileList.append( backupFileName )
        
            logger.info( 'SUCC: Del Files, file=%s'%(delFileList) )
        return orchm_req.getOK( delFileList )
    except Exception, e:
        logger.exception( e )
        return orchm_req.getErr( orchm_req.EXCP, e )


class FileHandler(RequestHandler):
    
    def initialize(self, opCode, _data):
        self._data = _data
        self.opCode = opCode
    
    def post(self):
        reqdata = self.request.body
        logger.info( '>>>> Recv-Req [[File]]: %s'%(str(self.opCode)) )
        
        try:
            reqdata = json.loads(self.request.body)
            backupDir = None
            if reqdata.has_key('backup_dir') and reqdata['backup_dir'] != None and reqdata['backup_dir'] != '' :
                backupDir = reqdata['backup_dir']
            
            chmod = 0755
            if reqdata.has_key('chmod') and str.isdigit(reqdata['chmod']) :
                chmod = int(reqdata['chmod'])
            
            if self.opCode == FILE_PUT :
                res = putFile( reqdata['name'], reqdata['data'], backupDir, chmod )
            elif self.opCode == FILE_DEL:
                res = delFile( reqdata['type'], reqdata['targets'], backupDir )
            elif self.opCode == FILE_DEL_EXCLUDE :
                res = delFileAtDir_Exclude( reqdata['target_dir'], reqdata['exclude_file'], backupDir )
            else:
                res = orchm_req.getErr( orchm_req.UNKNOWN_REQ, 'Undefined OpCode, %s'%str(self.opCode) )
        except Exception, e:
            logger.exception(e)
            res = orchm_req.getErr( orchm_req.EXCP, e )
        
        logger.info("<<<< Send-Res [[File]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()

def url( _oba_data ):
    url = [ 
            ('/file/put', FileHandler, dict(opCode=FILE_PUT, _data=_oba_data)),
            ('/file/del', FileHandler, dict(opCode=FILE_DEL, _data=_oba_data)),
            ('/file/del/exclude', FileHandler, dict(opCode=FILE_DEL_EXCLUDE, _data=_oba_data))
            ]
    return url






