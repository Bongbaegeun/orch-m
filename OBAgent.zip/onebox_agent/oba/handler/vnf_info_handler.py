#!/usr/bin/python
#-*- coding: utf-8 -*-
'''
Created on 2018. 3. 7.

@author: ohhara
'''

import json, httplib, threading
from time import sleep

from onebox_agent.util import ob_constant as oc
from onebox_agent.oba import oba_constant as oac
from onebox_agent.util import onebox_manager
from onebox_agent.oba.handler.orchf_req_handler import OrchfRequestHandler
from onebox_agent.util.onebox_manager import OneBoxState, VNFStateManager, VnfWorkManager, WORK_DONE, WORK_FAIL, WORK_DOING

import logging
logger = logging.getLogger(oac._L_TITLE)

url_base="/v1"

OP_VNF_INFO = "VNF-INFO"
OP_VNF_SET = "VNF-SET"
OP_VNF_UNSET = "VNF-UNSET"
OP_VNF_PROG = "VNF-PROG"


def _DEL_PLUGIN(_ob_info, _pfile, _cfg, _ptype=None):
    __p_type = None
    if _ptype != None :
        __p_type = _ptype
    else:
        __p_type = _ob_info.get_plugin_type(_pfile)
    
    
    if __p_type in [ oc.VNFM_PLUGIN_TYPE_UTM, oc.CFG_PLUGIN_UTM ] :
        _ob_info.set_plugin_noutm()
        return True
    else:
        _plug = _ob_info.del_plugin_evnf(_pfile)
        logger.info(" - [VNF-UNSET_API] Succ to Unset Plugin, del-plugin=%s"%str(_plug))
        return True


class _OBARestarter(threading.Thread):
    
    def __init__(self, _ol):
        threading.Thread.__init__(self)
        self._ol = _ol
        
    def run(self):
        sleep(3)
        self._ol.restart_service([oc.VAL_OBA_NAME])



class VNFInfoHandler(OrchfRequestHandler):
    
    def initialize(self, opCode, _data):
        self.opCode = opCode
        self._data = _data
        self._ol = _data[oc.OTAG_LIB_OB]
        self._ob_info = _data[oc.OTAG_OBA_INFO]
        
        self._oba_restart = False
    
    def post(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req [[VNF-INFO]]: %s, body=%s"%( str(self.opCode), str(reqdata) ))
        
        try:
            reqdata = json.loads(self.request.body)
            if self.opCode == OP_VNF_INFO :
                res = self._vnf_info()
            elif self.opCode == OP_VNF_SET :
                res = self._vnf_set(reqdata)
            elif self.opCode == OP_VNF_UNSET :
                res = self._vnf_unset(reqdata)
            else:
                res = self.retErr(httplib.BAD_REQUEST, "Unknown Post URL or Operation, opcode=%s"%str(self.opCode))
        except Exception, e:
            logger.error("Fail to Handle VNF-INFO API, op=%s, body=%s, exc=%s"%( self.opCode, str(reqdata), str(e) ))
            logger.exception(e)
            res = self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
        
        logger.info("<<<< Send-Res [[VNF-INFO]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()
        
        if self._oba_restart :
            self._oba_restart = False
            logger.info("!!!! %s API: OneBox-Agent Restart.. "%str(self.opCode))
            _OBARestarter(self._ol).start()
    
    def get(self, job_id):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req [[VNF-INFO]]: %s, body=%s"%( str(self.opCode), str(reqdata) ))
        
        try:
            if self.opCode == OP_VNF_INFO :
                res = self._vnf_info()
            elif self.opCode == OP_VNF_PROG :
                res = self._vnf_prog(job_id)
            else:
                res = self.retErr(httplib.BAD_REQUEST, "Unknown Get URL or Operation, opcode=%s"%str(self.opCode))
        except Exception, e:
            logger.error("Fail to Handle VNF-INFO API, op=%s, body=%s, exc=%s"%( self.opCode, str(reqdata), str(e) ))
            logger.exception(e)
            res = self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
        
        logger.info("<<<< Send-Res [[VNF-INFO]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()
    
    def _ret_err(self, _stMgr, _wkMgr, _wkDesc, _httpErr):
        logger.error("Fail to %s, %s"%( self.opCode, _wkDesc ))
        _stMgr.set_state( OneBoxState.RUNNING)
        _wkMgr.set_state(WORK_FAIL, _wkDesc)
        return self.retErr( _httpErr, _wkDesc)
    
    def _vnf_info(self):
        try:
            _vnf_plugin_list = []
            if type(self._ob_info.plugin_list()) == list :
                for _evp in self._ob_info.plugin_list() :
                    _vnf_plugin_list.append({'vnf_type': _evp.ptype(), 'vnf_plugin': _evp.file(), 'vnf_cfg': _evp.cfg()})
            
            return self.retOK({'vnf_list': _vnf_plugin_list})
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _vnf_set(self, reqData):
        '''
        return : 
            error= error:description
            ok : {status}
        '''
        _vnfStMgr = None
        _vnfWkMgr = None
        try:
            job_id = reqData['job_id']
            vnf_type = reqData['vnf_type']
            vnf_model = reqData['vnf_model']
            vnf_wan_list = reqData['vnf_wan_list']
            vnf_vendor = (reqData['vnf_vendor'] if reqData.has_key('vnf_vendor') else None)
            vnf_version = (reqData['vnf_version'] if reqData.has_key('vnf_version') else None)
            
            vnf_ip = ( reqData['vnf_local_ip'] if reqData.has_key('vnf_local_ip') else None )
            vnf_id = (reqData['vnf_id'] if reqData.has_key('vnf_id') else None)
            vnf_pw = (reqData['vnf_pwd'] if reqData.has_key('vnf_pwd') else None)
            
            _chk = onebox_manager.chk_all_inprogress()
            if _chk != None :
                _err = "Other Request IN-Progress, status=%s"%str(_chk)
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr( httplib.BAD_REQUEST, _err)
            
            # setting
            _vnfStMgr = VNFStateManager()
            _vnfWkMgr = VnfWorkManager(job_id)
            _vnfStMgr.set_state(OneBoxState.VNF_SET_IN_PROGRESS)
            _vnfWkMgr.set_state(WORK_DOING, str(reqData))
            
            _pfile = oc.GET_PFILE(vnf_model)
            if _pfile == None :
                _err = "Unknown VNF Info, model=%s"%str(vnf_model)
                return self._ret_err(_vnfStMgr, _vnfWkMgr, _err, httplib.BAD_REQUEST)
            
            if vnf_type != oc.VNFM_PLUGIN_TYPE_UTM and self._ob_info.has_plugin(_pfile) :
                _err = "Already Existed VNF Info, model=%s"%str(vnf_model)
                return self._ret_err(_vnfStMgr, _vnfWkMgr, _err, httplib.CONFLICT)
            
            _pcfg = {oc.CFG_PLUGIN_CFG_WAN: [], oc.CFG_PLUGIN_CFG_MD: vnf_model}
            if vnf_vendor != None : _pcfg[oc.CFG_PLUGIN_CFG_VD] = vnf_vendor
            if vnf_version != None : _pcfg[oc.CFG_PLUGIN_CFG_VER] = vnf_version
            if vnf_ip != None : _pcfg[oc.CFG_PLUGIN_CFG_IP] = vnf_ip
            if vnf_id != None : _pcfg[oc.CFG_PLUGIN_CFG_ID] = vnf_id
            if vnf_pw != None : _pcfg[oc.CFG_PLUGIN_CFG_PW] = vnf_pw
            
            if type(vnf_wan_list) == list and len(vnf_wan_list) > 0 :
                for _vwi in vnf_wan_list :
                    _ovsbr = oc.GET_OVSBR(_vwi)
                    if _ovsbr == None :
                        logger.warning(" - [VNF-SET-API] Invalid WAN Info, wan=%s, br=%s"%( str(_vwi), str(_ovsbr) ))
                    else:
                        _pcfg[oc.CFG_PLUGIN_CFG_WAN].append(_ovsbr)
            else:
                _err = "Invalid WAN-Info, info=%s"%str(vnf_wan_list)
                return self._ret_err(_vnfStMgr, _vnfWkMgr, _err, httplib.BAD_REQUEST)
            
            if str(vnf_type).lower() in [ oc.VNFM_PLUGIN_TYPE_UTM, oc.CFG_PLUGIN_UTM ] :
                self._ob_info.set_plugin_utm(_pfile, _pcfg)
                self._ob_info.set_utm_info(vnf_ip, None, vnf_id, vnf_pw)
            else:
                self._ob_info.add_plugin_evnf(vnf_type, _pfile, _pcfg)
            try:
                self._ob_info.saveToCfg()
            except Exception, e:
                logger.exception(e)
                _err = "OBA-CFG Save Error, err=%s"%str(e)
                return self._ret_err(_vnfStMgr, _vnfWkMgr, _err, httplib.INTERNAL_SERVER_ERROR)
            
            self._oba_restart = True
            logger.info("SUCC: %s, type=%s, file=%s, cfg=%s, desc=%s"%( self.opCode, str(vnf_type), str(_pfile), str(_pcfg), "Wait for OBA-Restart" ))
            return self.retOK({'status': WORK_DOING})
        except KeyError, e:
            logger.error("Fail to %s, No Key, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            if _vnfStMgr != None : _vnfStMgr.set_state(OneBoxState.RUNNING)
            if _vnfWkMgr != None : _vnfWkMgr.set_state(WORK_FAIL, "KeyError: %s"%str(e))
            return self.retErr(httplib.BAD_REQUEST, "KeyError: %s"%str(e))
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            if _vnfStMgr != None : _vnfStMgr.set_state(OneBoxState.RUNNING)
            if _vnfWkMgr != None : _vnfWkMgr.set_state(WORK_FAIL, str(e))
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _vnf_unset(self, reqData):
        _vnfStMgr = None
        _vnfWkMgr = None
        try:
            job_id = reqData['job_id']
            vnf_model = reqData['vnf_model']
            vnf_type = (reqData['vnf_type'] if reqData.has_key('vnf_type') else None)
            vnf_vendor = (reqData['vnf_vendor'] if reqData.has_key('vnf_vendor') else None)
            vnf_version = (reqData['vnf_version'] if reqData.has_key('vnf_version') else None)
            
            _chk = onebox_manager.chk_all_inprogress()
            if _chk != None :
                _err = "Other Request IN-Progress, status=%s"%str(_chk)
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr( httplib.BAD_REQUEST, _err)
            
            # setting
            _vnfStMgr = VNFStateManager()
            _vnfWkMgr = VnfWorkManager(job_id)
            _vnfStMgr.set_state(OneBoxState.VNF_UNSET_IN_PROGRESS)
            _vnfWkMgr.set_state(WORK_DOING, str(reqData))
            
            _pfile = oc.GET_PFILE(vnf_model)
            if _pfile == None :
                _err = "Unknown VNF Info, model=%s"%str(vnf_model)
                return self._ret_err(_vnfStMgr, _vnfWkMgr, _err, httplib.BAD_REQUEST)
            
            _pcfg = {oc.CFG_PLUGIN_CFG_WAN: []}
            if vnf_vendor != None : _pcfg[oc.CFG_PLUGIN_CFG_VD] = vnf_vendor
            if vnf_version != None : _pcfg[oc.CFG_PLUGIN_CFG_VER] = vnf_version
            
            _DEL_PLUGIN(self._ob_info, _pfile, _pcfg, vnf_type)
            try:
                self._ob_info.saveToCfg()
            except Exception, e:
                logger.exception(e)
                _err = "OBA-CFG Save Error, err=%s"%str(e)
                return self._ret_err(_vnfStMgr, _vnfWkMgr, _err, httplib.INTERNAL_SERVER_ERROR)
            
            self._oba_restart = True
            logger.info("SUCC: %s, type=%s, file=%s, cfg=%s, desc=%s"%( self.opCode, str(vnf_type), str(_pfile), str(_pcfg), "Wait for OBA-Restart" ))
            return self.retOK({'status': WORK_DOING})
        except KeyError, e:
            logger.error("Fail to %s, No Key, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            if _vnfStMgr != None : _vnfStMgr.set_state(OneBoxState.RUNNING)
            if _vnfWkMgr != None : _vnfWkMgr.set_state(WORK_FAIL, "KeyError: %s"%str(e))
            return self.retErr(httplib.BAD_REQUEST, "KeyError: %s"%str(e))
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            if _vnfStMgr != None : _vnfStMgr.set_state(OneBoxState.RUNNING)
            if _vnfWkMgr != None : _vnfWkMgr.set_state(WORK_FAIL, str(e))
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))
    
    def _vnf_prog(self, job_id):
        try:
            if job_id == None or str(job_id).strip() == "" :
                _err = "No JobID"
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr(httplib.BAD_REQUEST, _err)
            job_id = str(job_id).strip()
            
            _vnfStMgr = VNFStateManager()
            _vnfWkMgr = VnfWorkManager(job_id)
            
            _stat = _vnfStMgr.get_state()
            if type(_stat) != dict or not _stat.has_key('status') :
                return self.retErr(httplib.INTERNAL_SERVER_ERROR, "No Job Status Info")
            
            if _stat['status'] == OneBoxState.RUNNING.name :
                _wkst = _vnfWkMgr.get_state()
                _desc = "Done"
                if type(_wkst) == dict and _wkst.has_key('desc') : _desc = _wkst['desc']
                if type(_wkst) == dict and _wkst.has_key('status') :
                    if _wkst['status'] in [WORK_DOING, WORK_DONE] :
                        _vnfWkMgr.set_state(WORK_DONE, _desc)
                        return self.retOK({'status': WORK_DONE})
                    elif _wkst['status'] == WORK_FAIL :
                        return self.retOK({'status': WORK_FAIL})
                _err = "VNF-Status Error, status=%s"%str(_wkst)
                logger.warning(" - [VNF-PROG-API] %s"%_err)
                return self.retOK({'status': WORK_FAIL})
            elif _stat['status'] in [OneBoxState.VNF_SET_IN_PROGRESS.name, OneBoxState.VNF_SET_REQUESTED.name, 
                                     OneBoxState.VNF_UNSET_IN_PROGRESS.name, OneBoxState.VNF_UNSET_REQUESTED.name] :
                return self.retOK({'status': WORK_DOING})
            else:
                _err = "VNF-Set Error Status, status=%s"%str(_stat)
                logger.warning(" - [VNF-PROG-API] %s"%_err)
                _vnfWkMgr.set_state(WORK_FAIL, _err)
                return self.retOK({'status': WORK_FAIL})
        except Exception, e:
            logger.error("Fail to %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, str(e))


def url( _data ):
    url = [ 
            ('%s/vnf'%url_base, VNFInfoHandler, dict(opCode=OP_VNF_INFO, _data=_data)),
            ('%s/vnf/set'%url_base, VNFInfoHandler, dict(opCode=OP_VNF_SET, _data=_data)),
            ('%s/vnf/unset'%url_base, VNFInfoHandler, dict(opCode=OP_VNF_UNSET, _data=_data)),
            ('%s/vnf/jobprogress/([^/]*)'%url_base, VNFInfoHandler, dict(opCode=OP_VNF_PROG, _data=_data))
            ]
    return url


