#!/usr/bin/python
#-*- coding: utf-8 -*-

import json
from tornado.web import RequestHandler
import commands as cmd
from time import sleep


from onebox_agent.oba import oba_constant as oac
from onebox_agent.oba.handler import orchm_req_handler as orchm_req
from onebox_agent.util import ob_constant as oc

import logging
logger = logging.getLogger(oac._L_TITLE)


ZBA_RESTART = 'ZBA-RESTART'
ZBA_MON_FILE_STATUS = 'ZBA-MON-FILE-STATUS'



def restartZBA( name, chkProcs ):
    try:
        status, ret = cmd.getstatusoutput( "service %s restart"%name )
        if status != 0 :
            logger.error( 'Fail to Execute Shell, errCode=%s, errMsg=%s'%(str(status), ret) )
            return orchm_req.getErr( orchm_req.SHELL_FAIL, 'Fail to Execute Shell, errCode=%s, errMsg=%s'%(str(status), ret) )
        else:
            sleep(3)
            for proc in chkProcs:
                status, output = cmd.getstatusoutput( 'ps -ef | grep -v "grep" | grep -c "%s"'%proc )
                if (output == None) or (not str.isdigit(output)) or (int(output) < 1) :
                    logger.error( 'No Process, proc=%s'%proc )
                    return orchm_req.getErr( orchm_req.SHELL_FAIL, 'No Process, proc=%s'%proc )
                    
            return orchm_req.getOK( ret )
    except Exception, e:
        logger.error("Fail to Restart ZBA, exc=%s"%str(e))
        logger.exception( e )
        return orchm_req.getErr( orchm_req.EXCP, e )

def status_mon_file(reqdata):
    '''
    return : { zba_key_list: [1,2,3], template_list:[1,2,3] }
    '''
    try:
        _plug_root_dir = oc.DIR_MONA_PLUG
        _zbac_root_dir = oc.DIR_MONA_KEY
        if type(reqdata) == dict and reqdata.has_key('plug_root_dir') :
            if reqdata['plug_root_dir'] == None or str(reqdata['plug_root_dir']).strip() == "" :
                logger.error( "Fail to MON-FILE Status API, No PlugIn-Root Param, dir=%s"%str(reqdata['plug_root_dir']) )
                return orchm_req.getErr( orchm_req.INVALID_DATA, "No PlugIn-Root Param, dir=%s"%str(reqdata['plug_root_dir']) )
            else:
                _plug_root_dir = str(reqdata['plug_root_dir']).strip()
        if type(reqdata) == dict and reqdata.has_key('zba_key_root_dir') :
            if reqdata['zba_key_root_dir'] == None or str(reqdata['zba_key_root_dir']).strip() == "" :
                logger.error( "Fail to MON-FILE Status API, No ZBA-KEY-Root Param, dir=%s"%str(reqdata['zba_key_root_dir']) )
                return orchm_req.getErr( orchm_req.INVALID_DATA, "No ZBA-KEY-Root Param, dir=%s"%str(reqdata['zba_key_root_dir']) )
            else:
                _zbac_root_dir = str(reqdata['zba_key_root_dir']).strip()
        
        import os
        _p_dir_list = []
        _z_file_list = []
        if os.path.isdir(_plug_root_dir) :
            _p_dir_list = os.listdir(_plug_root_dir)
        else:
            logger.error( "Fail to MON-FILE Status API, No Plugin-Directory, dir=%s"%str(_plug_root_dir) )
            return orchm_req.getErr( orchm_req.NO_DATA, "No Plugin-Directory, dir=%s"%str(_plug_root_dir) )
        if os.path.isdir(_zbac_root_dir) :
            for (path, _dir, files) in os.walk(_zbac_root_dir):
                if path == _zbac_root_dir :
                    _z_file_list += files
        else:
            logger.error( "Fail to MON-FILE Status API, No ZB-Key-Directory, dir=%s"%str(_zbac_root_dir) )
            return orchm_req.getErr( orchm_req.NO_DATA, "No ZB-Key-Directory, dir=%s"%str(_zbac_root_dir) )
        
        _p_temp_list = []
        _z_temp_list = []
        for _p_dir in _p_dir_list :
            _path_plugin = os.path.join(_plug_root_dir, _p_dir)
            for (_path, _dir, files) in os.walk(_path_plugin):
                if _path == _path_plugin :
                    for filename in files:
                        # if str(filename).find(".pyc") < 1 or ( str(filename).find(".py") > -1 or str(filename).find(".yaml") > -1 or str(filename).find(".sh") > -1 ) :
                        if str(filename).find(".pyc") < 1 or (str(filename).find(".py") > -1 or str(filename).find(".sh") > -1):
                            _p_comp = str(_p_dir).split('-')
                            try:
                                if not int(_p_comp[0]) in _p_temp_list :
                                    _p_temp_list.append(int(_p_comp[0]))
                            except Exception, e:
                                logger.warning(" - SKIP to Get Plugin-Template Number, Plugin-Dir=%s"%str(_p_comp))
                            break
        for _z_file in _z_file_list :
            _z_comp = str(_z_file).split('-')
            try:
                _z_temp_list.append(int(_z_comp[0]))
            except Exception, e:
                logger.warning(" - SKIP to Get ZBA-Key-Template Number, ZBKEY-File=%s"%str(_z_file))
        
        _ret = { 'zba_key_list': _z_temp_list, 'template_list':_p_temp_list }
        return _ret
    except Exception, e:
        logger.error("Fail to Get MonA-File Status, exc=%s"%str(e))
        logger.exception( e )
        return orchm_req.getErr( orchm_req.EXCP, e )


class ZBAHandler(RequestHandler):
    
    def initialize(self, opCode, _data):
        self._data = _data
        self.opCode = opCode
    
    def post(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req [[ZB Agent]]: %s, body=%s"%( str(self.opCode), str(reqdata) ))
        
        try:
            reqdata = json.loads(self.request.body)
            if self.opCode == ZBA_RESTART :
                zbName = self._data[oc.OTAG_OBA_INFO].c_zba_info.daemon()
                zbChkProc = self._data[oc.OTAG_OBA_INFO].c_zba_info.chk_proc()
                res = restartZBA( zbName, zbChkProc )
            elif self.opCode == ZBA_MON_FILE_STATUS :
                res = status_mon_file(reqdata)
            else:
                res = orchm_req.getErr( orchm_req.UNKNOWN_REQ, 'Undefined OpCode, %s'%str(self.opCode) )
        except Exception, e:
            logger.error("Fail to Handle ZBA-API, exc=%s"%str(e))
            logger.exception(e)
            res = orchm_req.getErr( orchm_req.EXCP, e )
        
        logger.info("<<<< Send-Res [[ZB Agent]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()

def url( _data ):
    url = [ 
            ('/zba/restart', ZBAHandler, dict(opCode=ZBA_RESTART, _data=_data)),
            ('/zba/status/mon_file', ZBAHandler, dict(opCode=ZBA_MON_FILE_STATUS, _data=_data)),
          ]
    return url





