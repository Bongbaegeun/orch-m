#!/usr/bin/python
#-*- coding: utf-8 -*-


import httplib
from tornado.web import MissingArgumentError


from onebox_agent.oba import oba_constant as oac
from onebox_agent.util import ob_constant as oc
from onebox_agent.oba.handler.orchf_req_handler import OrchfRequestHandler
from onebox_agent.util.onebox_manager import StateManager, BRStateManager, STATUS_TYPE_BACKUP, STATUS_TYPE_RESTORE

import logging
logger = logging.getLogger(oac._L_TITLE)

url_base="/v1"

OP_STATUS = "STATUS"
OP_STATUS_BACKUP = "STATUS-BACKUP"
OP_STATUS_RESTORE = "STATUS-RESTORE"
OP_STATUS_VERSION = "STATUS-VERSION"





class StatusHandler(OrchfRequestHandler):
    
    def initialize(self, opCode, _data):
        self.opCode = opCode
        self._data = _data
    
    
    def get(self):
        reqdata = self.request.body
        logger.info(">>>> Recv-Req [[Status]]: %s, body=%s"%( str(self.opCode), str(reqdata) ))
        
        try:
            if self.opCode == OP_STATUS :
                res = self._status()
            elif self.opCode == OP_STATUS_BACKUP :
                res = self._status_backup()
            elif self.opCode == OP_STATUS_RESTORE :
                res = self._status_restore()
            elif self.opCode == OP_STATUS_VERSION :
                res = self._status_version()
            else:
                res = self.retErr(httplib.BAD_REQUEST, "Unknown Get URL or Operation, opcode=%s"%str(self.opCode))
        except Exception, e:
            logger.error("Fail to Handle StatusAPI, op=%s, body=%s, exc=%s"%( self.opCode, str(reqdata), str(e) ))
            logger.exception(e)
            res = self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
        
        logger.info("<<<< Send-Res [[Status]]: %s, res=%s"%( str(self.opCode), str(res) ))
        self.write(res)
        self.flush()
    
    
    def _status(self):
        '''
        return : {status: "RUNNING"}
        '''
        try:
            statemgr = StateManager()
            _ret = statemgr.get_state()
            
            logger.info("SUCC: Get %s, status=%s"%( self.opCode, str(_ret) ))
            return _ret
        except Exception, e:
            logger.error("Fail to Get %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
    
    def _status_backup(self):
        '''
        return : {
                status[str]: "BACKUP_DONE", 
                current_step[int]: 3, 
                total_step[int]: 3, 
                progress[str]: "BACKUP_DONE__3__3"
                }
        '''
        try:
            transaction_id = self.get_argument("transaction_id")
            if str(transaction_id).strip() == "" :
                logger.error("Fail to Get %s, Invalid TransactionID, tid=%s"%( self.opCode, str(transaction_id) ))
                return self.retErr(httplib.BAD_REQUEST, "Invalid TransactionID")
            
            statemgr = BRStateManager(STATUS_TYPE_BACKUP, transaction_id)
            _ret = statemgr.get_state()
            if _ret == None :
                _err = "No Transaction_id, tid=%s"%transaction_id
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr(httplib.BAD_REQUEST, _err)
            
            logger.info("SUCC: Get %s, status=%s"%( self.opCode, str(_ret) ))
            return _ret
        except MissingArgumentError, e:
            logger.error("Fail to Get %s, Argument Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.BAD_REQUEST, e)
        except Exception, e:
            logger.error("Fail to Get %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
    
    def _status_restore(self):
        '''
        return : {
                status[str]: RESOTRE_DONE, 
                current_step[int]: 3, 
                total_step[int]: 3, 
                progress[str]: "RESOTRE_DONE__3__3"
                }
        '''
        try:
            transaction_id = self.get_argument("transaction_id")
            if str(transaction_id).strip() == "" :
                logger.error("Fail to Get %s, Invalid TransactionID, tid=%s"%( self.opCode, str(transaction_id) ))
                return self.retErr(httplib.BAD_REQUEST, "Invalid TransactionID")
            
            statemgr = BRStateManager(STATUS_TYPE_RESTORE, transaction_id)
            _ret = statemgr.get_state()
            if _ret == None :
                _err = "No Transaction_id, tid=%s"%transaction_id
                logger.error("Fail to %s, %s"%( self.opCode, _err ))
                return self.retErr(httplib.BAD_REQUEST, _err)
            
            logger.info("SUCC: Get %s, status=%s"%( self.opCode, str(_ret) ))
            return _ret
        except MissingArgumentError, e:
            logger.error("Fail to Get %s, Argument Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.BAD_REQUEST, e)
        except Exception, e:
            logger.error("Fail to Get %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
    
    def _status_version(self):
        '''
        return : { version[str] }
        '''
        try:
            _ret = {"version": oc.VAL_OB_VER}
            logger.info("SUCC: Get %s, version=%s"%( self.opCode, str(_ret) ))
            return _ret
        except Exception, e:
            logger.error("Fail to Get %s, Unknown Error, exc=%s"%( self.opCode, str(e) ))
            logger.exception(e)
            return self.retErr(httplib.INTERNAL_SERVER_ERROR, e)
    

def url( _data ):
    url = [ 
            ('%s/status'%url_base, StatusHandler, dict(opCode=OP_STATUS, _data=_data)),
            ('%s/backupstatus'%url_base, StatusHandler, dict(opCode=OP_STATUS_BACKUP, _data=_data)),
            ('%s/restorestatus'%url_base, StatusHandler, dict(opCode=OP_STATUS_RESTORE, _data=_data)),
            ('%s/version'%url_base, StatusHandler, dict(opCode=OP_STATUS_VERSION, _data=_data)),
            ]
    return url


