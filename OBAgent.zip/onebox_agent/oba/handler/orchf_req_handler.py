#-*- coding: utf-8 -*-
'''
Created on 2017. 9. 4.

@author: ohhara
'''

from tornado.web import RequestHandler
import datetime


def new_tid():
    today = datetime.datetime.now()
    return today.strftime('%y%m%d%H%M')

class OrchfRequestHandler(RequestHandler):
    
    def retOK(self, msg):
        return msg
    
    def retError(self, httpCode, msg ):
        self.set_status(httpCode)     
        return msg
    
    def retErr(self, httpCode, msg ):
    
        self.set_status(httpCode)     
        return { 'error':{'description': str(msg)} }
    
#     def retErr(self, httpCode, msg, req=None ):
#     
#         self.set_status(httpCode)     
#         if req == None:
#             return { 'error':{'description': str(msg)} }
#         else:
#             return { 'error':{'description': str(msg), 'req':req} }
    
#     def retErrWithType(self, code, msg, _type = ""):
#         self.set_status(code)
#         if _type == "": 
#             _type = code
#         return { 'error':{'code': code, 'type': type, 'description': str(msg) }}
