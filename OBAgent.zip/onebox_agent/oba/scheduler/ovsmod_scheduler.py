#!/usr/bin/python
#-*- coding: utf-8 -*-

import threading
from time import sleep

from onebox_agent.oba import oba_constant as oac
from onebox_agent.plugin.obos import linux_plugin as lp

import logging
logger = logging.getLogger(oac._L_TITLE)


_TITLE_OBOVS = "Schd-OBOvsMod"

class OvsModSchd(threading.Thread):
    
    _PERIOD = 10
    _STOP = False
    _STOP_WAIT = 30
    _RETRY_WAIT = 15
    # OVS_MOD_FLOWS_CMD = "ovs-ofctl mod-flows br-int table=24,priority=0,actions=normal"
    OVS_CHK_FLOWS_BR_INT_TB25 = "ovs-ofctl dump-flows br-int | grep table=25"
    OVS_ADD_FLOWS_BR_INT_TB25 = "ovs-ofctl add-flow br-int \'cookie=%s,table=25,priority=0,actions=resubmit(,60)\'"

    OVS_MOD_FLOWS_CMD = "ovs-ofctl mod-flows br-int cookie=%s,table=24,priority=0,actions=normal"
    OVS_CHK_FLOWS_CMD = "ovs-ofctl dump-flows br-int"

    def __init__(self, _ol=None, _ob_info=None):
        threading.Thread.__init__(self)
        
        # self._ol = _ol
        # self._ob_info = _ob_info

    '''
    return
        0 : error, unknown, none
        1 : table=24, priority=0, actions=drop
        2 : table=24, priority=0, actions=normal
    '''
    def chk_flow_br_int_tb24(self):
        logger.info("Start check ovs br-int dump-flows: %s" % self.OVS_CHK_FLOWS_CMD)
        _command = lp.Command()
        (_ret_code, _ret_out, _ret_err) = _command.execute_command(self.OVS_CHK_FLOWS_CMD)

        if _ret_code != 0:
            logger.error("Fail to Get ovs br-int dump-flows, ret=%s, output=%s, err=%s"
                         % (str(_ret_code), str(_ret_out), str(_ret_err)))
            return 0
        elif _ret_code == 0 and _ret_out == "":
            logger.debug("Get ovs br-int dump-flows: %s" % self.OVS_CHK_FLOWS_CMD)
            logger.debug(str(_ret_out))
            return 0
        elif _ret_code == 0 and _ret_out != "":
            ovs_flows= str(_ret_out)
            logger.debug("Get ovs br-int dump-flows: %s" % self.OVS_CHK_FLOWS_CMD)
            logger.debug(ovs_flows)

            rows = str(ovs_flows).lower().splitlines()
            for n in range(0, len(rows)):
                if rows[n].find('table=24') > 0 and rows[n].find('priority=0') > 0 and rows[n].find('actions=normal') > 0:
                    # logger.info("  OK ovs br-int mod-flows actions normal")
                    return 2
                elif rows[n].find('table=24') > 0 and rows[n].find('priority=0') > 0 and rows[n].find('actions=drop') > 0:
                    # logger.info("  OK ovs br-int mod-flows actions drop")
                    return 1
        else:
            logger.info("ovs br-int mod-flows actions unknown")
            return 0

    # cookie value parse from output and paste to cmd
    def mod_flow_br_int_tb24(self):
        _command = lp.Command()
        (_ret_code, _ret_out, _ret_err) = _command.execute_command(self.OVS_CHK_FLOWS_CMD)
        if _ret_code == 0 and _ret_out != "":
            ovs_flows = str(_ret_out)
            rows = str(ovs_flows).lower().splitlines()
            for n in range(0, len(rows)):
                if rows[n].find('table=24') > 0 and rows[n].find('priority=0') > 0 and rows[n].find('actions=drop') > 0:
                    cookie = rows[n].split(',')[0].split('=')[1]
                    mod_cmd = self.OVS_MOD_FLOWS_CMD % cookie
                    logger.debug("Execute ovs mod cmd: %s" % mod_cmd)
                    (_ret_code, _ret_out, _ret_err) = _command.execute_command(mod_cmd)

                    if _ret_code != 0:
                        logger.error("Fail to Set ovs br-int mod-flows, ret=%s, output=%s, err=%s"
                                     % (str(_ret_code), str(_ret_out), str(_ret_err)))
                    else:
                        logger.info("Succ to Set ovs br-int mod-flows")
                        return True
        return False

        # cookie value parse from output and paste to cmd

    def add_flow_br_int_tb25(self):
        _command = lp.Command()
        _loop_count = 0

        while True:
            if _loop_count > 600:   # 10 Minutes
                logger.error("add-flow has timed-out : %")
                return False

            if _loop_count is not 0:    sleep(self._PERIOD)
            _loop_count += 1

            (_ret_code, _ret_out, _ret_err) = _command.execute_command(self.OVS_CHK_FLOWS_BR_INT_TB25)
            if _ret_code == 0 and _ret_out != "":
                ovs_flows = str(_ret_out)
                rows = str(ovs_flows).lower().splitlines()

                cookie = rows[0].split(',')[0].split('=')[1]
                add_cmd = self.OVS_ADD_FLOWS_BR_INT_TB25 % cookie
                logger.debug("ovs add-flow cmd = %s" % add_cmd)
            else:
                logger.error("Failed to get ovs br-int tb 25 cookie : " % _ret_err)
                continue

            (_ret_code, _ret_out, _ret_err) = _command.execute_command(add_cmd)

            if _ret_code != 0:
                logger.error("Failed to add-flow for br-int tb 25, ret=%s, output=%s, err=%s"
                             % (str(_ret_code), str(_ret_out), str(_ret_err)))
                continue
            else:
                logger.info("Succ to add-flow ovs br-int tb 25")
                return True

    def run(self):
        logger.info("-------[[ %s Run ]]--------" % _TITLE_OBOVS)
        
        # _obid = self._ob_info.ob_id()

        _sleep = self._PERIOD
        _is_first = True
        _loop_count = 0

        while True:
            if not _is_first :
                sleep(_sleep)
            _is_first = False

            if _loop_count > 600:   # 10 Minutes
                # logger.info("Finish check ovs dump-flows")
                return
            _loop_count += 1
            try:
                _ret = self.chk_flow_br_int_tb24()
                if _ret == 0:
                    continue
                if _ret == 1:
                    logger.info("Try change ovs br-int tb 24 flows!")
                    # sleep(30)  # wait till load all ovs rules
                    self.mod_flow_br_int_tb24()
                elif _ret == 2:
                    logger.info("OK ovs br-int mod-flows tb 24 actions normal")

                    # after complete mod-flow table 24, do add-flow br-int table 25
                    self.add_flow_br_int_tb25()
                    return
            except Exception, e:
                logger.error("[%s] exc= %s" % (_TITLE_OBOVS, str(e)))
                logger.exception(e)
