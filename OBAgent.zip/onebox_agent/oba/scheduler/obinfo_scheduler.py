#!/usr/bin/python
#-*- coding: utf-8 -*-

import threading
from time import sleep

from onebox_agent.oba import oba_constant as oac
from onebox_agent.util import onebox_manager
from onebox_agent.util.onebox_manager import EtcStateManager, NetStateManager, StateManager, WANStateManager, VNFStateManager, STATUS_TYPE_BACKUP, STATUS_TYPE_RESTORE, STATUS_TYPE_WAN
from onebox_agent.data.ob_info import OB_NET
from onebox_agent.util import ob_constant as oc

import logging
logger = logging.getLogger(oac._L_TITLE)


_TITLE_OBNET = "Schd-OBNetNoti"

class OBNetNotiSchd(threading.Thread):
    
    _PERIOD = 60
    _STOP = False
    _STOP_WAIT = 30
    _RETRY_WAIT = 15
    
    def __init__(self, _ol, _ob_info):
        threading.Thread.__init__(self)
        
        self._ol = _ol
        self._ob_info = _ob_info
        self._PERIOD = (self._PERIOD if _ob_info.noti_intv() == None else _ob_info.noti_intv())
    
    
    def run(self):
        logger.info("-------[[ %s Run ]]--------"%_TITLE_OBNET)
        
        _obid = self._ob_info.ob_id()
        _orchfip, _orchfport = self._ob_info.orchf_site()
        _url = "%s/server/%s"%( oc.URL_ORCHF_BASE(str(_orchfip), str(_orchfport)), str(_obid) )
        _header = oc.HEADER
        _method = "POST"
        
        _sleep = self._PERIOD
        _is_first = True
        while True :
            if not _is_first :
                sleep(_sleep)
            _is_first = False
            
            self._STOP = EtcStateManager().is_noti_ob_off(self._STOP)
            if self._STOP :
                _sleep = self._STOP_WAIT
                logger.info("[%s] - Stop Notify, wait=%s"%( _TITLE_OBNET, str(_sleep) ))
                continue
            else:
                _sleep = self._PERIOD
            
            try:
                _brState = StateManager().get_state()
                _wanState = WANStateManager().get_state()
                _vnfState = VNFStateManager().get_state()
                
                if type(_brState) == dict and _brState.has_key('status') :
                    if _brState['status'] in onebox_manager.STAT_BR_PREVENT_DUPL :
                        logger.info("[%s] - OBNet-Noti Wait for Backup/Restore, status=%s"%(_TITLE_OBNET, str(_brState['status']) ))
                        _sleep = oac.T_WAN_PASS_WAIT_FOR_BR
                        continue
                else:
                    logger.warning("[%s] - Fail to Get Backup/Restore-Status, status=%s"%(_TITLE_OBNET, str(_brState)))
                if type(_wanState) == dict and _wanState.has_key('status') :
                    if _wanState['status'] in onebox_manager.STAT_WAN_PREVENT_DUPL :
                        logger.info("[%s] - OBNet-Noti Wait for WAN-SW/TEST, status=%s"%(_TITLE_OBNET, str(_wanState['status'])))
                        _sleep = oac.T_WAN_PASS_WAIT_FOR_SW
                        continue
                else:
                    logger.warning("[%s] - Fail to Get WAN-Status, status=%s"%(_TITLE_OBNET, str(_wanState)))
                if type(_vnfState) == dict and _vnfState.has_key('status') :
                    if _vnfState['status'] in onebox_manager.STAT_VNF_PREVENT_DUPL :
                        logger.info("[%s] - OBNet-Noti Wait for VNF-SET/UNSET, status=%s"%(_TITLE_OBNET, str(_vnfState['status'])))
                        _sleep = oac.T_WAN_PASS_WAIT_FOR_VNF
                        continue
                else:
                    logger.warning("[%s] - Fail to Get VNF-Status, status=%s"%(_TITLE_OBNET, str(_vnfState)))
                
                _sleep = self._PERIOD
                _net_state_json = NetStateManager().get_state()
                _net_state_info = OB_NET().load(_net_state_json)
                _ret = self._ol.noti_ob_info(_net_state_info, self._ob_info)
                if not _ret :
                    if not self._ol.chk_mon_file() :
                        if _net_state_info.is_notified :
                            _net_state_info.set_notify(False)
                            NetStateManager().set_state(_net_state_info.to_dict())
                    logger.error("[%s] - Fail to Notify OBNet-Info"%_TITLE_OBNET)
                else:
                    if not _net_state_info.is_notified :
                        _net_state_info.set_notify(True)
                        NetStateManager().set_state(_net_state_info.to_dict())
                    logger.info("[%s] - SUCC: Notify OBNet-Info"%_TITLE_OBNET)
            except Exception, e:
                logger.error("[%s] - Fail to Notify OBNet-Info, exc=%s"%(_TITLE_OBNET, str(e)))
                logger.exception(e)
        
        logger.error("!!!!!!!! Broken %s !!!!!!!!"%_TITLE_OBNET)
    


_TITLE_OBSTAT = "Schd-OBStatus"

class OBStatusSchd(threading.Thread):
    
    _PERIOD = 3600
    _ERR_RETRY_T = 300
    _EXPIRED_DAY = 7
    
    def __init__(self, _ol):
        threading.Thread.__init__(self)
        
        self._ol = _ol
    
    def run(self):
        logger.info("-------[[ %s Run ]]--------"%_TITLE_OBSTAT)
        
        while True:
            _sleep = self._PERIOD
            try:
                _dday = "+%s"%str(self._EXPIRED_DAY)
                for _ff in ( "%s.*"%STATUS_TYPE_BACKUP, "%s.*"%STATUS_TYPE_RESTORE, "%s.*"%STATUS_TYPE_WAN ) :
                    _unused_files = self._ol.get_os().find_file(oc.DIR_STAT_DIR, _fname=_ff, _mday=_dday, _aday=_dday)
                    if type(_unused_files) == list or type(_unused_files) == tuple and len(_unused_files) > 0 :
                        self._ol.delete_files(_unused_files)
                        logger.info("[%s] SUCC: Manage OBStatus Files, files=%s"%(_TITLE_OBSTAT, str(_unused_files)))
                    elif _unused_files == None :
                        logger.error("[%s] Fail to Manage OBStatus Files, File[%s] Find Error"%( _TITLE_OBSTAT, str(_ff) ))
                        _sleep = self._ERR_RETRY_T
            except Exception, e:
                logger.error("[%s] Fail to Manage OBStatus Files, exc=%s"%(_TITLE_OBSTAT, str(e)))
                logger.exception(e)
                _sleep = self._ERR_RETRY_T
            
            sleep(_sleep)
        
        
        logger.error("!!!!!!!! Broken %s !!!!!!!!"%_TITLE_OBSTAT)





