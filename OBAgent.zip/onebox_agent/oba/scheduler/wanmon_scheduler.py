#!/usr/bin/python
# -*- coding: utf-8 -*-

import threading, os
from time import sleep
from time import time
from datetime import datetime


from onebox_agent.oba import oba_constant as oac
from onebox_agent.util import onebox_manager
from onebox_agent.data import ob_info
from onebox_agent.util import ob_constant as oc
from onebox_agent.util.onebox_manager import EtcStateManager, StateManager, WANStateManager, VNFStateManager, NetStateManager, WORK_FAIL, WORK_DONE
from onebox_agent.oba.oba_worker import WanSwitchWorker

import logging
logger = logging.getLogger(oac._L_TITLE)


_TITLE_WANMON = "Schd-WanMon"

FLAG_CHG_ALL        = 0b11111
FLAG_CHG_WAN_MODE   = 0b0001 # 1
FLAG_CHG_MGMT_IP    = 0b0010 # 2
FLAG_CHG_EXTRA_IP   = 0b0100 # 4
FLAG_CHG_NOTI       = 0b1000 # 8

_UPDATE_OSP     = 0b0001
_UPDATE_OS_BR   = 0b0010
_UPDATE_NOTI    = 0b0100



def chk_api_req():
    try:
        _brState = StateManager().get_state()
        _wanState = WANStateManager().get_state()
        _vnfState = VNFStateManager().get_state()
        
        if type(_brState) == dict and _brState.has_key('status') :
            if _brState['status'] in onebox_manager.STAT_BR_PREVENT_DUPL :
                logger.info("[%s] WAN-Refresh Wait for Backup/Restore, status=%s"%( _TITLE_WANMON, str(_brState['status']) ))
                return False, oac.T_WAN_PASS_WAIT_FOR_BR
        else:
            logger.warning("[%s] Fail to Get Backup/Restore-Status, status=%s"%( _TITLE_WANMON, str(_brState) ))
        if type(_wanState) == dict and _wanState.has_key('status') :
            if _wanState['status'] in onebox_manager.STAT_WAN_PREVENT_DUPL :
                logger.info("[%s] WAN-Refresh Wait for WAN-SW/TEST, status=%s"%( _TITLE_WANMON, str(_wanState['status']) ))
                return False, oac.T_WAN_PASS_WAIT_FOR_SW
        else:
            logger.warning("[%s] Fail to Get WAN-Status, status=%s"%(_TITLE_WANMON, str(_wanState) ))
        if type(_vnfState) == dict and _vnfState.has_key('status') :
            if _vnfState['status'] in onebox_manager.STAT_VNF_PREVENT_DUPL :
                logger.info("[%s] WAN-Refresh Wait for VNF-SET/UNSET, status=%s"%( _TITLE_WANMON, str(_vnfState['status']) ))
                return False, oac.T_WAN_PASS_WAIT_FOR_VNF
        else:
            logger.warning("[%s] Fail to Get VNF-Status, status=%s"%(_TITLE_WANMON, str(_vnfState) ))
        return True, None
    except Exception, e:
        logger.error("[%s] Fail to Get Status-Info, exc=%s"%( _TITLE_WANMON, str(e) ))
        logger.exception(e)
        return False, None

def _update_openstack(_ol, _mip, _vimUser, _vimPass, _ovs_dpdk=False):
    _updateHandler = _ol.get_update_vim_public_ip_handler(_mip, _vimUser, _vimPass, _ovs_dpdk)
    _updateHandler.start()
    while True :
        sleep(0.2)
        if _updateHandler.is_fin() :
            break
    
    _ret, _err = _updateHandler.result()
    if not _ret :
        logger.error("[%s] - Fail to Update OpenStack Mgmt IP, err=%s"%( _TITLE_WANMON, str(_err) ))
        return False
    else:
        return True

def update_wan(_ol, _prev_net_info, _ob_info, _net_info, _is_first=False, _forced_update=False):
    _update_ret = 0
    try:
        _chg_flag = 0
        ## mgmt ip 변경 처리 : OSP, API
        ## All IP Info : noti
        if _prev_net_info == None :
            _chg_flag = FLAG_CHG_ALL
        else:
            if _net_info.diff_mgmt_ip(_prev_net_info) : _chg_flag |= FLAG_CHG_MGMT_IP
            if _net_info.diff_extra_ip(_prev_net_info) : _chg_flag |= FLAG_CHG_EXTRA_IP
            if _net_info.diff_wan_mode(_prev_net_info) : _chg_flag |= FLAG_CHG_WAN_MODE
            if not _net_info.is_notified : _chg_flag |= FLAG_CHG_NOTI
            
            _notiURFName = oc.FILE_NOTI_UTM_UR
            _notiRRFName = oc.FILE_NOTI_UTM_RR
            _notiIFName = oc.FILE_NOTI_UTM_IF
            _notiArpName = oc.FILE_NOTI_UTM_ARP
            if os.path.isfile(_notiURFName) or os.path.isfile(_notiRRFName) or os.path.isfile(_notiIFName) or os.path.isfile(_notiArpName) :
                _chg_flag |= FLAG_CHG_NOTI
        
        _mgmt_info = _net_info.get_mgmt_ip()
        if _mgmt_info[1] == None :
            logger.error("[%s] - Fail to Update Wan-Info, No Mgmt IP, ip=%s"%( _TITLE_WANMON, str(_mgmt_info) ))
        else:
            logger.debug("[%s] - Update-Wan Info, flag=%s, forced=%s"%( _TITLE_WANMON, str(_chg_flag), str(_forced_update) ))
            # update openstack
            if _forced_update or _chg_flag & FLAG_CHG_MGMT_IP :
                _ovs_dpdk = _ob_info.ovs_dpdk()
                if _update_openstack(_ol, _mgmt_info[1], _ob_info.vim_auth_user(), _ob_info.vim_auth_pass(), _ovs_dpdk) :
                    logger.info("[%s] - SUCC: Update OpenStack MGMT-IP"%( _TITLE_WANMON ))
                    _update_ret |= _UPDATE_OSP
            # update host bridge ip
            if _forced_update or _chg_flag & FLAG_CHG_MGMT_IP :
                for _m_addr in _net_info.mgmt_list :
                    if not _ol.set_host_ip(_m_addr.dev, _m_addr.ip, _m_addr.mask) :
                        logger.warning("[%s] - Fail to Update Host Br-IP, br=%s, ip=%s, mask=%s"%(
                                        _TITLE_WANMON, str(_m_addr.dev), str(_m_addr.ip), str(_m_addr.mask) ))
                logger.info("[%s] - SUCC: Update Host Br-IP"%_TITLE_WANMON)
                _update_ret |= _UPDATE_OS_BR
            # notify ob-info
            if _forced_update or _chg_flag & ( FLAG_CHG_MGMT_IP | FLAG_CHG_WAN_MODE | FLAG_CHG_EXTRA_IP | FLAG_CHG_NOTI ) :
                _noti_off = EtcStateManager().is_noti_ob_off(True)
                if not _noti_off :
                    _ret = _ol.noti_ob_info(_net_info, _ob_info, _is_first)
                    if _ret :
                        logger.info("[%s] - SUCC: Notify OB-Info"%( _TITLE_WANMON ))
                        _update_ret |= _UPDATE_NOTI
                        if not _net_info.is_notified :
                            _net_info.set_notify(True)
                            logger.info("[%s] - Save Net-Info for Notify-Flag(True)"%_TITLE_WANMON)
                            NetStateManager().set_state(_net_info.to_dict())
                    else:
                        logger.error("[%s] - Fail to Notify OB-Info"%( _TITLE_WANMON ))
                        if _net_info.is_notified :
                            _net_info.set_notify(False)
                            logger.info("[%s] - Save Net-Info for Notify-Flag(False)"%_TITLE_WANMON)
                            NetStateManager().set_state(_net_info.to_dict())
                else:
                    logger.info("[%s] - SKIP: Notify OB-Info, Noti_off=%s"%( _TITLE_WANMON, _noti_off ))
        
        return _net_info, _update_ret
    except Exception, e:
        logger.error("[%s] - Fail to Update Wan-Info, exc=%s"%( _TITLE_WANMON, str(e) ))
        logger.exception(e)
        return _net_info, _update_ret

def _refresh_and_update_wan(_ol, _ob_info, _sw_on=True, _is_first=False, _forced_update=False):
    '''
    func: refresh internet, store data and update IP of OSP, OS, etc...
    return: OB_NET, _update_flag
    '''
    _net_info = None
    _prev_net_info = None
    try:
        _net_info_json = NetStateManager().get_state()
        _prev_net_info = ob_info.OB_NET().load(_net_info_json)
        _net_info = ob_info.OB_NET().load(_net_info_json)
    except Exception, e:
        logger.error("[%s] - Fail to Refresh Wan, OBNetInfo Get Error, exc=%s"%(_TITLE_WANMON, str(e) ))
        logger.exception(e)
    
    if _net_info == None :
        try:
            _has_utm = _ol.hasUtm(_ob_info.wan_mac_list())
            _net_info = ob_info.OB_NET()
            _net_info.init(_ob_info.is_in_band(), _ob_info.utm_local_ip(),
                           _has_utm, _ol.getWanMode(_ob_info), 
                           _ob_info.mgmt_list(), _ob_info.wan_list(), _ob_info.extra_wan_list())
        except Exception, e:
            logger.error("[%s] - Fail to Refresh Wan, OBNetInfo Init Error, exc=%s"%(_TITLE_WANMON, str(e) ))
            logger.exception(e)
            return None, 0
    
    ## refresh wan
    _ret, _net_info = _ol.refresh_wan(_net_info, _ob_info, _TITLE_WANMON, _sw_on)
    if not _ret :
        return _net_info, 0
    else:
        NetStateManager().set_state(_net_info.to_dict())
        logger.info("[%s] - Finish Wan-Refresh and Save Net-Info"%_TITLE_WANMON)
    
    
    ## repair wan
    # os-br check
    try:
        _br_list = _ol.get_host_bridge()
        for _m_addr in _net_info.mgmt_list :
            if not _m_addr.dev in _br_list :
                if _ol.add_host_bridge(_m_addr.dev) :
                    logger.info("[%s] - - SUCC: Add OS-BR, br=%s"%( _TITLE_WANMON, str(_m_addr.dev) ))
                else:
                    logger.warning("[%s] - - Fail to Refresh Wan, OS-BR Add Error, br=%s"%( _TITLE_WANMON, str(_m_addr.dev) ))
            if _net_info.wan_mode == oc.VAL_WAN_MD_VNF :
                _ol.set_host_if_status(_m_addr.dev, False)
        sleep(3)
        
        ## unnecessary br down
        _def_gw_dev = _ol.get_os().get_def_gw_info()[0]
        if str(_def_gw_dev).find(oc.VAL_DEF_HOST_MGMT_BR) > -1 :
            _host_route_list = _ol.get_os().get_route_list()
            if type(_host_route_list) == list :
                for _r_dev in _host_route_list :
                    if _r_dev in _br_list and _def_gw_dev != _r_dev :
                        _ol.set_host_if_status(_r_dev, False)
                        logger.warning("[%s] - - SUCC: Ifconfig-Down Unnecessary BR, br=%s"%(_TITLE_WANMON, str(_r_dev)))
            else:
                logger.warning("[%s] - - Fail to Get Host Route Info, ret=%s"%( _TITLE_WANMON, str(_host_route_list) ))
        
        ## set host mgmt ip
        _maddr = _net_info.main_mgmt()
        _hip, _hmask = _ol.get_os().get_ip(_maddr.dev)
        if _hip == None or str(_hip).strip() == "" : 
            if _ol.set_host_ip(_maddr.dev, _maddr.ip, _maddr.mask) :
                logger.info("[%s] - - SUCC: Set Host-Mgmt-ip, info=%s"%( _TITLE_WANMON, str(_maddr) ))
            else:
                logger.warning("[%s] - - Fail to Set Host-Mgmt-IP, info=%s"%( _TITLE_WANMON, str(_maddr) ))
            
    except Exception, e:
        logger.error("[%s] - Fail to Fix Host Bridge Wan, exc=%s"%(_TITLE_WANMON, str(e) ))
        logger.exception(e)
    
    ## udpate wan
    return update_wan(_ol, _prev_net_info, _ob_info, _net_info, _is_first, _forced_update)


def _obInfoTxt(_ob_id, _net_info, _func_name=None):
    _TAB = "\t\t"
    
    if _func_name == None :
        _obInfo = "\n" + _TAB + "############################################################################\n"
    else:
        _obInfo = "\n" + _TAB + "############################# After %s ##############################\n"%_func_name
    _obInfo = _obInfo + _TAB + "## OB ID : " + str(_ob_id) + "\n"
    _obInfo = _obInfo + _TAB + "## MGMT Mode : "
    if not _net_info.in_band :
        _obInfo = _obInfo + "Out-Band\n"
    else:
        _obInfo = _obInfo + "In-Band\n"
    _obInfo = _obInfo + _TAB + "## WAN Mode : %s\n"%str(_net_info.wan_mode)
    
    _obInfo = _obInfo + _TAB + "## UTM Status : %s\n"%( "Ready" if _net_info.is_utm_ok else "Not Ready" )
    _utm_main = _net_info.main_wan()
    if _utm_main.dev != None:
        _obInfo = _obInfo + _TAB + "## UTM GW Dev/IP : %s/%s\n"%( str(_utm_main.dev), str(_utm_main.gw) )
    
    return _obInfo


def to_show(_ol, _ob_info, _net_info, _func_name=None, _conn=True):
    if _net_info == None:
        return "---------[%s] Fail to Show Net-Info, No Net-Info%s --------------------------"%(
                        _TITLE_WANMON, ("" if _func_name == None else "[%s]"%_func_name) )
    
    _txt = ""
    _TAB = "\t\t"
    
    _markMgmt = " "
    _markWan = " "
    _mgmtInfo = _TAB + "##   %s MGMT      Dev/Br/IP : "
    _wanInfo  = _TAB + "##   %s WAN(UTM)  Dev/Br/IP : "
    try:
        if _net_info.wan_mode == oc.VAL_WAN_MD_HOST :
            if _conn : 
                _mgmtInfo = _mgmtInfo%( "*" )
                _markMgmt = "M"
            else : 
                _mgmtInfo = _mgmtInfo%( "x" )
                _markMgmt = "x"
            _wanInfo = _wanInfo%( " " )
        elif _net_info.wan_mode == oc.VAL_WAN_MD_VNF :
            _mgmtInfo = _mgmtInfo%( " " )
            if _conn : 
                _wanInfo = _wanInfo%( "*" )
                _markWan = "M"
            else : 
                _wanInfo = _wanInfo%( "x" )
                _markWan = "x"
        elif _net_info.wan_mode == oc.VAL_WAN_MD_OUTBAND:
            if _conn : 
                _mgmtInfo = _mgmtInfo%( "*" )
                _markMgmt = "M"
            else : 
                _mgmtInfo = _mgmtInfo%( "x" )
                _markMgmt = "x"
            if _net_info.is_utm_ok : 
                _wanInfo = _wanInfo%( "*" )
                _markWan = "M"
            else : _wanInfo = _wanInfo%( " " )
        else:
            _mgmtInfo = _mgmtInfo%( "X" )
            _wanInfo = _wanInfo%( "X" )
        
        _m_m_net = _net_info.main_mgmt()
        _mMgmNic = str(_m_m_net.nic)
        _mMgmDev = str(_m_m_net.dev)
        _mMgmIP = str(_m_m_net.ip)
        
        _m_w_net = _net_info.main_wan()
        _mWanNic = str(_m_w_net.nic)
        _mWanDev = str(_m_w_net.dev)
        _mWanIP = str(_m_w_net.ip)
        
        __isFirst = True
        _has_br = False
        for _extra in _net_info.wan_list :
            _extraNic = _extra.nic
            _extraDev = _extra.dev
            _extraIP = _extra.ip
            _extraGW = _extra.gw
            _vnfNicBr = str(_ol.to_utm_nic(_extraDev)) + ("" if _extra.br == None else "[%s]"%str(_extra.br))
            _has_br = _extra.br != None
            
            used = " "
            if _extraNic != None and _extraNic == _mWanNic :
                used = _markWan
            
            if __isFirst :
                __isFirst = False
                if _has_br :
                    _wanInfo = _wanInfo + "%s %-4s/%-7s/%-9s/%-15s/%-15s"%(used, str(_extraNic), str(_extraDev), str(_vnfNicBr), str(_extraIP), str(_extraGW)) + "\n"
                else:
                    _wanInfo = _wanInfo + "%s %-4s/%-7s/%-4s/%-15s/%-15s"%(used, str(_extraNic), str(_extraDev), str(_vnfNicBr), str(_extraIP), str(_extraGW)) + "\n"
            else:
                if _has_br :
                    _wanInfo = _wanInfo + _TAB + "##                           %s %-4s/%-7s/%-9s/%-15s/%-15s"%(used, str(_extraNic), str(_extraDev), str(_vnfNicBr), str(_extraIP), str(_extraGW)) + "\n"
                else:
                    _wanInfo = _wanInfo + _TAB + "##                           %s %-4s/%-7s/%-4s/%-15s/%-15s"%(used, str(_extraNic), str(_extraDev), str(_vnfNicBr), str(_extraIP), str(_extraGW)) + "\n"
        
        
        __isFirst = True
        for _extra in _net_info.mgmt_list :
            _extraNic = _extra.nic
            _extraDev = _extra.dev
            _extraIP = _extra.ip
            _extraGW = _extra.gw
            used = " "
            if _extraNic != None and _extraNic == _mMgmNic :
                used = _markMgmt
            
            if __isFirst :
                __isFirst = False
                if _has_br :
                    _mgmtInfo = _mgmtInfo + "%s %-4s/%-17s/%-15s/%-15s"%( used, str(_extraNic), str(_extraDev), str(_extraIP), str(_extraGW) ) + "\n"
                else:
                    _mgmtInfo = _mgmtInfo + "%s %-4s/%-12s/%-15s/%-15s"%( used, str(_extraNic), str(_extraDev), str(_extraIP), str(_extraGW) ) + "\n"
            else:
                if _has_br :
                    _mgmtInfo = _mgmtInfo + _TAB + "##                           %s %-4s/%-17s/%-15s/%-15s"%(used, str(_extraNic), str(_extraDev), str(_extraIP), str(_extraGW)) + "\n"
                else:
                    _mgmtInfo = _mgmtInfo + _TAB + "##                           %s %-4s/%-12s/%-15s/%-15s"%(used, str(_extraNic), str(_extraDev), str(_extraIP), str(_extraGW)) + "\n"
        

        _txt = _obInfoTxt(_ob_info.ob_id(), _net_info, _func_name)
        _txt = _txt + _TAB + "## Connection :\n"
        _txt = _txt + _mgmtInfo + _wanInfo 
        
        ## Extra Wan
        if type(_net_info.extra_vnf_wan_list) == list and len(_net_info.extra_vnf_wan_list) > 0 :
            _txt = _txt + _TAB + "##   ------------------------------------------------------------------------\n"
            for _evw in _net_info.extra_vnf_wan_list :
                _evw_vtype = None
                _evw_nic = _evw.nic
                _evw_dev = _evw.dev
                _evw_ip = _evw.ip
                _evw_gw = _evw.gw
                
                _evw_in_nic = "eth1"
                
                if type(_ol.get_extra_vnf_list()) == list :
                    for _evl in _ol.get_extra_vnf_list() :
                        if type(_evl.p_wan_list) == list and _evw_dev in _evl.p_wan_list :
                            _evw_vtype = _evl.p_type
                            _evw_in_nic = _evl.p_lib.to_inner_nic(_evw_dev)
                            break
                _evw_br = str(_evw_in_nic) + ( "" if _evw.br == None else "[%s]"%str(_evw.br))
                
                _txt = _txt + _TAB + "##     WAN(%-4s) Dev/Br/IP :   %-4s/%-7s/%-4s/%-15s/%-15s"%( str(_evw_vtype), str(_evw_nic), str(_evw_dev), str(_evw_br), str(_evw_ip), str(_evw_gw)) + "\n"
        
        _txt = _txt + _TAB + "#############################################################################"
    except Exception, e:
        logger.error("[%s] Fail to Show OBNet-Text, exc=%s"%( _TITLE_WANMON, str(e) ))
        logger.exception(e)
    
    return _txt


class WanMonSchd(threading.Thread):
    
    _PERIOD = 30
    
    # by API, Pause WAN-HA
    _SW_STOP = False
    _SW_STOP_WAIT = 15
    _SW_PAUSE_LIMIT = 600
    
    _SLOW = 45
    _NORM = 30
    _FAST = 15
    _VERY_FAST = 5
    
    # WAN-SW
    _TOTAL_WAIT_FOR_INIT_VNF_CONN = 300
    _1RETRY_FOR_VNF_CONN = 3
    _HOST_RETRY_MAX = 3
    _VNF_RETRY_MAX = 3
    _WAN_SW_VNF_TO = 60
    _WAN_SW_HOST_TO = 300
    _WAN_SW_CHK_PERIOD = 3
    
    _AUTO_FIX_BR = True

    _HOST_CONNECTIVITY = 3

    def __init__(self, _ol, _ob_info):
        threading.Thread.__init__(self)
        
        self._ol = _ol
        self._ob_info = _ob_info
        
        self._PERIOD = (self._PERIOD if _ob_info.c_wan_info.wan_mon_intv() == None else _ob_info.c_wan_info.wan_mon_intv())
        self._in_band = _ob_info.is_in_band()
        # by cfg, Stop WAN-SW
        self._wan_sw = _ob_info.c_wan_info.wan_sw()
        ## after sw-vnf, total timeout for chk Init-vnf-conn
        self._TOTAL_WAIT_FOR_INIT_VNF_CONN = (self._TOTAL_WAIT_FOR_INIT_VNF_CONN if _ob_info.c_wan_info.wait_time_for_init_vnf() == None else _ob_info.c_wan_info.wait_time_for_init_vnf())
        ## after sw-vnf, retry-cnt per 1 cycle  for chk vnf-conn
        self._1RETRY_FOR_VNF_CONN = (self._1RETRY_FOR_VNF_CONN if _ob_info.c_wan_info.retry_for_vnf() == None else _ob_info.c_wan_info.retry_for_vnf())
        # by cfg, RETRY SW
        self._HOST_RETRY_MAX = (self._HOST_RETRY_MAX if _ob_info.c_wan_info.wan_sw_retry() == None else _ob_info.c_wan_info.wan_sw_retry())
        self._VNF_RETRY_MAX = (self._VNF_RETRY_MAX if _ob_info.c_wan_info.wan_sw_retry() == None else _ob_info.c_wan_info.wan_sw_retry())
        
        self._AUTO_FIX_BR = _ob_info.c_wan_info.wan_auto_fix()
        
        self._need_refresh = False
        self._SW_PAUSE_LIMIT = oc.T_DEF_WAIT_WAN_SW_PAUSE
        
        self._is_first_noti = True
        self._is_first_update = True
        
        self._host_wait_cnt = 0
    
    
    def fix_wan(self, _net_info):
        # out-band consider -> N/A
        if not self._AUTO_FIX_BR or not _net_info.in_band or not self._wan_sw :
            logger.info("[%s] - SKIP to Fix-Wan, auto_fix=%s, in_band=%s, sw_on=%s"%( 
                            _TITLE_WANMON, str(self._AUTO_FIX_BR), str(_net_info.in_band), str(self._wan_sw) ))
            return True
        
        try:
            # to vnf
            self._need_refresh = True
            if _net_info.is_utm_ok :
                self.sw2vnf()
            # to host
            else :
                self.sw2host()
                _is_wan_conn, _err, _ecode = self._ol.chk_conn(self._ob_info, _net_info.wan_mode)
                if not _is_wan_conn :
                    logger.warning("[%s] - Fail to Fix-Wan, No Host Conn, err=%s"%( _TITLE_WANMON, str(_err) ))
                    self.host_mgmt_ha(_net_info)
                
            logger.info("[%s] - SUCC: Fix-Wan"%( _TITLE_WANMON ))
            return True
        except Exception, e:
            logger.error("[%s] - Fail to Auto-Fix Net-Info, exc=%s"%( _TITLE_WANMON, str(e) ))
            logger.exception(e)
            return False
    
    def fix_ev_wan(self, _net_info):
        _ret = False
        # extra-vnf-wan
        _evw_list = _net_info.extra_vnf_wan_list
        _set_evw_br_list = []
        if type(_evw_list) == list : 
            for _evw in _evw_list :
                _set_evw_br_list.append(_evw.dev)
                if not self._ol.get_vim().is_master(_evw.dev, [_evw.nic]) :
                    ## VIM INIT & Bind Dev Kern
                    self._ol.correct_nic_drv()
                    
                    ### VIM-BR Setting
                    ## Del VIM-Port
                    self._ol.get_vim().del_br_port_all(_evw.nic)
                    
                    ## Add VIM-BR Port
                    if self._ol.get_vim().add_br_port( str(_evw.dev), str(_evw.nic), self._ob_info.ovs_dpdk() ) :
                        logger.info("[%s] - Succ to Fix-EVWan, set ovs-br, br=%s, port=%s"%( _TITLE_WANMON, str(_evw.dev), str(_evw.nic) ))
                    else:
                        logger.error("[%s] - Fail to Fix-EVWan, set ovs-br, br=%s, port=%s"%( _TITLE_WANMON, str(_evw.dev), str(_evw.nic) ))
                    self._need_refresh = True
                    _ret = True
        
        _reset_brs = []
        _reset_ports = []
        for _evbr in oc.VAL_DEF_VI_EWAN_BR_LIST :
            if not _evbr in _set_evw_br_list :
                _brifs = self._ol.get_vim().get_br_ifs(_evbr)
                if type(_brifs) == list and len(_brifs) > 0 :
                    _reset_brs.append(_evbr)
                    _reset_ports += _brifs
        
        if len(_reset_brs) > 0 :
            _rret, _err = self._ol.get_vim().reset_vim_bridge(_reset_brs)
            if _rret == True: 
                logger.info("[%s] - Succ to Fix-EVWan, unset unused nic, br=%s, nic=%s"%( _TITLE_WANMON, str(_reset_brs), str(_reset_ports) ))
            else:
                logger.info("[%s] - Fail to Fix-EVWan, unset unused nic, br=%s, nic=%s"%( _TITLE_WANMON, str(_reset_brs), str(_reset_ports) ))
            self._need_refresh = True
            _ret = True
        
        return _ret
        
    
    def host_mgmt_ha(self, _net_info):
        # out-band consider
        try:
            m_mgmt = _net_info.main_mgmt()
            m_br = m_mgmt.dev
            
            _alive_nics = []
            for _mgmt in _net_info.mgmt_list :
                _br = _mgmt.dev
                if m_br == _br :
                    continue
                
                ## Nic Alive
                _ret = self._ol.get_os().is_nic_alive(_mgmt.nic)
                if not _ret :
                    logger.warning("[%s] - Fail to Host-MGMT-HA, Nic Down, br=%s, nic=%s"%( _TITLE_WANMON, str(_br), str(_mgmt.nic) ))
                    continue
                _alive_nics.append(_mgmt.nic)
                
                ## bridge up by metric 100
                self._ol.get_os().down_and_up_interface(_br, 10, 100)
                sleep(1)
                
                ## ping chk, dns1,2, + gw
                _is_conn = False
                _ping_dst = [ oc.VAL_DEF_DNS_1, oc.VAL_DEF_DNS_2 ]
                if _mgmt.gw != None and str(_mgmt.gw) != "" :
                    _ping_dst.append(_mgmt.gw)
                for _dst in _ping_dst :
                    if self._ol.get_os().ping(_dst, 3, 3, _br) :
                        _is_conn = True
                        break
                self._ol.set_host_if_status(_br, False)
                
                if _is_conn :
                    ## change bridge
                    self._ol.set_host_if_status(m_br, False)
                    self._ol.get_os().down_and_up_interface(_br, 120)
                    _net_info.set_main_mgmt(_br)
                    NetStateManager().set_state(_net_info.to_dict())
                    self._need_refresh = True
                    logger.info("[%s] - SUCC: Host-MGMT-HA, br=%s[%s]->%s[%s]"%( _TITLE_WANMON, str(m_br), str(m_mgmt.nic), str(_br), str(_mgmt.nic) ))
                    return True
                else:
                    logger.warning("[%s] - Fail to Host-MGMT-HA, Ping Fail, br=%s, dst=%s"%( _TITLE_WANMON, str(_br), str(_ping_dst) ))
                    continue
            
            _f_mgmt = _net_info.mgmt_list[0]
            _gwInfo = self._ol.get_os().get_def_gw_info()
            if _f_mgmt.dev != m_br or _gwInfo[0] == None :
                self._ol.set_host_if_status(m_br, False)
                self._ol.get_os().down_and_up_interface(_f_mgmt.dev, 10)
                if _f_mgmt.gw != None and str(_f_mgmt.gw).strip() != "" :
                    if _gwInfo[0] == None or _gwInfo[0] != _f_mgmt.dev :
                        logger.warning("[%s] - Fail to Host-MGMT-HA, Invalid Def-GW-Dev, prev-gw=%s, new-gw=%s"%( _TITLE_WANMON, str(_gwInfo), str(_f_mgmt) ))
                        self._ol.get_os().del_def_route()
                        self._ol.get_os().add_def_route(_f_mgmt.gw)
                else:
                    logger.warning("[%s] - Fail to Host-MGMT-HA, Default Main Setting Error, No GW Info, mgmt=%s"%( _TITLE_WANMON, str(_f_mgmt) ))
                    
                _net_info.set_main_mgmt(0)
                NetStateManager().set_state(_net_info.to_dict())
                self._need_refresh = True
                logger.info("[%s] - Change Main Mgmt Bridge, br=%s[%s]->%s[%s]"%( _TITLE_WANMON, str(m_br), str(m_mgmt.nic), str(_f_mgmt.dev), str(_f_mgmt.nic) ))
            
            logger.error("[%s] - Fail to Host-MGMT-HA, No Available Bridge, Alive-Nic=%s"%( _TITLE_WANMON, str(_alive_nics) ))
            return False
        except Exception, e:
            logger.error("[%s] - Fail to Host-MGMT-HA, exc=%s"%( _TITLE_WANMON, str(e) ))
            logger.exception(e)
            return False
    
    def go_back_main(self, _net_info):
        try:
            m_mgmt = _net_info.main_mgmt()
            m_br = m_mgmt.dev
            if m_br == oc.VAL_DEF_HOST_MGMT_BR and _net_info.wan_mode != oc.VAL_WAN_MD_VNF :
                return True
            
            for _mgmt in _net_info.mgmt_list :
                _br = _mgmt.dev
                if oc.VAL_DEF_HOST_MGMT_BR == _br :
                    ## Nic Alive
                    if not self._ol.get_os().is_nic_alive(_mgmt.nic) :
                        logger.warning("[%s] - Fail to Go-Back Main Host-Br, Nic Link Down, br=%s, nic=%s"%( _TITLE_WANMON, str(_br), str(_mgmt.nic) ))
                        return False
                    
                    ## bridge up by metric 100
                    self._ol.get_os().down_and_up_interface(_br, 10, 100)
                    sleep(1)
                    
                    ## ping chk, dns1,2, + gw
                    _is_conn = False
                    _ping_dst = [ oc.VAL_DEF_DNS_1, oc.VAL_DEF_DNS_2 ]
                    if _mgmt.gw != None and str(_mgmt.gw) != "" :
                        _ping_dst.append(_mgmt.gw)
                    for _dst in _ping_dst :
                        if self._ol.get_os().ping(_dst, 3, 3, _br) :
                            _is_conn = True
                            break
                    self._ol.set_host_if_status(_br, False)
                    
                    if _is_conn :
                        ## change bridge
                        self._ol.set_host_if_status(m_br, False)
                        self._ol.get_os().down_and_up_interface(_br, 120)
                        _net_info.set_main_mgmt(_br)
                        NetStateManager().set_state(_net_info.to_dict())
                        self._need_refresh = True
                        logger.info("[%s] - SUCC: Go-Back Main Host-Br, br=%s[%s]->%s[%s]"%( _TITLE_WANMON, str(m_br), str(m_mgmt.nic), str(_br), str(_mgmt.nic) ))
                        return True
                    else:
                        logger.warning("[%s] - Fail to Go-Back Main Host-Br, Ping Fail, br=%s, dst=%s"%( _TITLE_WANMON, str(_br), str(_ping_dst) ))
                        return False
            
            logger.error("[%s] - Fail to Go-Back Main Host-Br, No Main Bridge Info, br=%s"%( _TITLE_WANMON, str(oc.VAL_DEF_HOST_MGMT_BR) ))
            return False
        except Exception, e:
            logger.error("[%s] - Fail to Go-Back Main Host-Br, exc=%s"%( _TITLE_WANMON, str(e) ))
            logger.exception(e)
            return False
    
    def sw2vnf(self, _to=None, _period=None):
        try:
            _ret, __sleep = chk_api_req()
            if not _ret :
                return False
            
            _work = WanSwitchWorker(oac.CALLER_SCHD, oac.VAL_SW_HOST2VM, self._ob_info, self._ol)
            _work.start()
            self._need_refresh = True
            
            _status = None
            _desc = None
            _to = ( self._WAN_SW_VNF_TO if _to == None else _to )
            __to = _to
            _period = ( self._WAN_SW_CHK_PERIOD if _period == None else _period )
            while _to > 0 :
                sleep(_period)
                _status, _desc = _work.get_status()
                if _status == WORK_DONE :
                    logger.info("[%s]  - SUCC to WAN-SW to VNF, desc=%s"%( _TITLE_WANMON, str(_desc) ))
                    return True
                elif _status == WORK_FAIL :
                    logger.error("[%s] - Fail to WAN-SW to VNF, err=%s"%( _TITLE_WANMON, str(_desc) ))
                    return False
                _to -= _period
            
            _work.forced_fail("TimeOut, to=%s"%str(__to))
            logger.error("[%s] - Fail to WAN-SW to VNF, TimeOut, to=%s, desc=%s"%( _TITLE_WANMON, str(__to), str(_desc) ))
            return False
        except Exception, e:
            logger.error("[%s] - Fail to WAN-SW to VNF, exc=%s"%( _TITLE_WANMON, str(e) ))
            logger.exception(e)
            return False
    
    def sw2host(self, _to=None, _period=None):
        try:
            _ret, __sleep = chk_api_req()
            if not _ret :
                return False
            
            _work = WanSwitchWorker(oac.CALLER_SCHD, oac.VAL_SW_VM2HOST, self._ob_info, self._ol)
            _work.start()
            self._need_refresh = True
            
            _status = None
            _desc = None
            _to = ( self._WAN_SW_HOST_TO if _to == None else _to )
            __to = _to
            _period = ( self._WAN_SW_CHK_PERIOD if _period == None else _period )
            while _to > 0 :
                sleep(_period)
                _status, _desc = _work.get_status()
                if _status == WORK_DONE :
                    logger.info("[%s]  - SUCC to WAN-SW to HOST, desc=%s"%( _TITLE_WANMON, str(_desc) ))
                    return True
                elif _status == WORK_FAIL :
                    logger.error("[%s] - Fail to WAN-SW to HOST, err=%s"%( _TITLE_WANMON, str(_desc) ))
                    return False
                _to -= _period
            
            _work.forced_fail("TimeOut, to=%s"%str(__to))
            logger.error("[%s] - Fail to WAN-SW to HOST, TimeOut, to=%s, period=%s, desc=%s"%( _TITLE_WANMON, str(__to), str(_period), str(_desc) ))
            return False
        except Exception, e:
            logger.error("[%s] - Fail to WAN-SW to HOST, exc=%s"%( _TITLE_WANMON, str(e) ))
            logger.exception(e)
            return False
    
    def _refresh_update(self):
        _net_info, _up_flag = _refresh_and_update_wan(self._ol, self._ob_info, not self._SW_STOP, self._is_first_noti, self._is_first_update)
        logger.debug("[%s] - - Update Result, flag=%s"%( _TITLE_WANMON, str(_up_flag) ))
        if _up_flag & _UPDATE_NOTI : self._is_first_noti = False
        if bool(_up_flag & _UPDATE_OS_BR) and bool(_up_flag & _UPDATE_OSP) : self._is_first_update = False
        return _net_info
    
    def run(self):
        logger.info("-------[[ %s Run ]]--------" % _TITLE_WANMON)
        
        sleep(10)
        _net_info = self._refresh_update()
        logger.info( to_show(self._ol, self._ob_info, _net_info, "Init WanMon") )
        
        _sleep = self._PERIOD
        _host_sw_retry = 0
        _vnf_sw_retry = 0
        _sw_pause_time = 0
        _is_sw_on = self._wan_sw and self._in_band
        
        # Wait for first utm start
        _retry_chk_for_first_utm_start = 0
        _prev_utm_status = False
        _wait_long_for_first_utm_start = None
        
        # Wait for UTM Fault
        _retry_for_utm_fault = 0
        _retry_max_for_utm_fault = 3
        
        # Wait for Handling Fault
        _prev_wan_mode = _net_info.wan_mode
        _wait_for_handle_fault = 0
        _wait_max_for_handle_fault = 3
        
        _is_wan_conn = True

        _host_connectivity = 0
        _host_connectivity_time = 0

        try:
            while True:
                try:
                    _now = datetime.now()
                    logger.info("[%s] [[ 1. WAIT ]] >>>>>>>> sleep=%s" % (_TITLE_WANMON, str(_sleep)))
                    sleep(_sleep)

                    # Pass, if WAN_SW/TEST, BACKUP/RESTORE IN PROGRESS(TODO, File/ZBA API)
                    _ret, __sleep = chk_api_req()
                    _sleep = (_sleep if __sleep is None else __sleep)
                    logger.info(
                        "[%s] [[ 2. CHK SW-API ]] >>>>>>>> ret=%s, sleep=%s" % (_TITLE_WANMON, str(_ret), str(_sleep)))
                    if not _ret:
                        continue

                    # Get WAN-INFO
                    _sleep = self._PERIOD
                    _net_info = self._refresh_update()
                    logger.info("[%s] [[ 3. Refresh&Update ]] >>>>>>>> " % _TITLE_WANMON)
                    if _net_info is None:
                        logger.error("[%s] Fail to Get Net-Info, No Net-Info")
                        continue
                    self._need_refresh = False
                    logger.info(to_show(self._ol, self._ob_info, _net_info, _conn=_is_wan_conn))

                    # for PAUSE
                    _gap = int((datetime.now() - _now).total_seconds())
                    # STOP handle
                    _setOn = (_sw_pause_time + _gap) > self._SW_PAUSE_LIMIT
                    logger.info("[%s] [[ 4. CHK Pause Limit ]] >>>>>>>> exceed=%s" % (_TITLE_WANMON, str(_setOn)))
                    try:
                        if _setOn:
                            EtcStateManager().run_wan_sw_schd(_setOn)
                            self._SW_STOP = False
                            self._SW_PAUSE_LIMIT = oc.T_DEF_WAIT_WAN_SW_PAUSE
                        else:
                            self._SW_STOP = EtcStateManager().is_wan_sw_off(self._SW_STOP)
                            if self._SW_STOP:
                                self._SW_PAUSE_LIMIT = EtcStateManager().wan_sw_pause_timeout()
                            else:
                                self._SW_PAUSE_LIMIT = oc.T_DEF_WAIT_WAN_SW_PAUSE
                    except Exception, e:
                        if _setOn:
                            logger.error("[%s] Fail to Set WAN-SW Status, set_run=True" % _TITLE_WANMON)
                        else:
                            logger.error(
                                "[%s] Fail to Get WAN-SW Status, is_stop=%s" % (_TITLE_WANMON, str(self._SW_STOP)))
                        logger.exception(e)

                    # TIME handle
                    logger.info("[%s] [[ 5. CHK Pause ]] >>>>>>>> pause=%s" % (_TITLE_WANMON, str(self._SW_STOP)))
                    if self._SW_STOP:
                        _sleep = self._SW_STOP_WAIT
                        _sw_pause_time += _gap
                        logger.info("[%s] PAUSE WAN-SW, wait_time=%s/%s, period=%s" % (_TITLE_WANMON,
                                                                                       str(_sw_pause_time),
                                                                                       str(self._SW_PAUSE_LIMIT),
                                                                                       str(self._SW_STOP_WAIT)))
                        continue
                    else:
                        _sleep = self._PERIOD
                        _sw_pause_time = 0

                    # fix/host ha/wan-sw sequentially if not succ
                    try:
                        # wan_mode chk and Fix Wan
                        logger.info(
                            "[%s] [[ 6. FIX WAN ]] >>>>>>>> wan_mode=%s" % (_TITLE_WANMON, str(_net_info.wan_mode)))
                        if _net_info.wan_mode is None:
                            _ret = self.fix_wan(_net_info)
                            logger.info("[%s] [[ 6-1. FIX WAN ]] >>>>>>>> ret=%s, wan_mode=%s, refresh=%s" % (
                                _TITLE_WANMON, str(_ret), str(_net_info.wan_mode), str(self._need_refresh)))

                            if not _ret or _net_info.wan_mode is None:
                                logger.error("[%s] Fail to Fix Wan, ret=%s, wan_mode=%s" % (
                                    _TITLE_WANMON, str(_ret), str(_net_info.wan_mode)))
                                _sleep = self._FAST
                                continue

                        if self.fix_ev_wan(_net_info):
                            logger.info("[%s] [[ 6-2. FIX EV-WAN ]] >>>>>>>> ret=%s, refresh=%s" % (
                                _TITLE_WANMON, str(_ret), str(self._need_refresh)))

                        if self._need_refresh:
                            _net_info = self._refresh_update()
                            self._need_refresh = False
                            _sleep = self._FAST
                            logger.info(to_show(self._ol, self._ob_info, _net_info, "Wan-Auto-Fix", _conn=_is_wan_conn))
                            continue

                        # UTM/WAN-Conn chk
                        _is_ok_utm = _net_info.is_utm_ok
                        _is_wan_conn, _err, _ecode = self._ol.chk_conn(self._ob_info, _net_info.wan_mode)

                        logger.debug("[%s] _net_info.wan_mode=%s, _is_wan_conn=%s" %
                                     (_TITLE_WANMON, str(_net_info.wan_mode), str(_is_wan_conn)))
                        logger.debug("[%s] _vnf_sw_retry=%s, _host_sw_retry=%s" %
                                     (_TITLE_WANMON, str(_vnf_sw_retry), str(_host_sw_retry)))

                        if _net_info.wan_mode == oc.VAL_WAN_MD_HOST and \
                                _vnf_sw_retry >= self._VNF_RETRY_MAX:
                            if _is_wan_conn is True:
                                _host_connectivity = _host_connectivity + 1
                                if _host_connectivity_time == 0:
                                    _host_connectivity_time = time()
                                else:
                                    connectivity_duration = time() - _host_connectivity_time
                                    if connectivity_duration >= self._ob_info.wan_host_connectivity_duration_time():
                                        _vnf_sw_retry = 0
                                        _host_connectivity = 0
                                        _host_connectivity_time = 0
                                        logger.info("[%s] connectivity_duration=%s, set _vnf_sw_retry=%s" %
                                                    (_TITLE_WANMON, str(connectivity_duration), str(_vnf_sw_retry)))
                            else:
                                _host_connectivity = 0
                                _host_connectivity_time = 0
                        else:
                            _host_connectivity = 0
                            _host_connectivity_time = 0

                        if _wait_long_for_first_utm_start is None:
                            _wait_long_for_first_utm_start = datetime.now()
                        if oc.ECD_CHK_CONN_VNF_NO_GW in _ecode:
                            _retry_max_for_utm_fault = 2

                            #                     logger.debug("-------prv_utm_stat=%s, _is_ok_utm=%s, wan=%s,
                            # wan_conn=%s"%(
                            #                                         str(_prev_utm_status), str(_is_ok_utm),
                            # str(_net_info.wan_mode), str(_is_wan_conn) ))

                        logger.info("[%s] [[ 7. CHK UTM Status ]] >>>>>>>> utm=%s, wan_mode=%s, conn=%s" % (
                            _TITLE_WANMON, str(_is_ok_utm), str(_net_info.wan_mode), str(_is_wan_conn)))

                        if _is_ok_utm and _net_info.wan_mode == oc.VAL_WAN_MD_VNF and not _is_wan_conn:
                            # retry for setting utm-gw when utm start, wait 5mins, no sw
                            logger.info("[%s] [[ 7-1. CHK First-UTM ]] >>>>>>>> prev_utm=%s, retry=%s/%s" % (
                                _TITLE_WANMON, str(_prev_utm_status), str(_retry_chk_for_first_utm_start),
                                str(self._TOTAL_WAIT_FOR_INIT_VNF_CONN)))
                            if not _prev_utm_status:
                                if _retry_chk_for_first_utm_start < self._TOTAL_WAIT_FOR_INIT_VNF_CONN:
                                    _retry_chk_for_first_utm_start = int(
                                        (datetime.now() - _wait_long_for_first_utm_start).total_seconds())
                                    _retry_for_utm_fault += 1
                                    _sleep = self._NORM
                                    logger.info("[%s] Wait for First UTM Start, wait=%s/%s, period=%s" % (
                                        _TITLE_WANMON, str(_retry_chk_for_first_utm_start),
                                        str(self._TOTAL_WAIT_FOR_INIT_VNF_CONN), str(_sleep)))
                                    continue
                                else:
                                    logger.warning("[%s] Fail to Wait for First UTM Start, TimeOut, to=%s/%s" % (
                                        _TITLE_WANMON, str(_retry_chk_for_first_utm_start),
                                        str(self._TOTAL_WAIT_FOR_INIT_VNF_CONN)))
                            _prev_utm_status = True
                            _wait_long_for_first_utm_start = None
                            _retry_chk_for_first_utm_start = 0
                            # for running utm fault, no sw and wait 1~2m
                            # No UTM GW=retry 2, Conn Fail=retry 3
                            logger.info("[%s] [[ 7-2. CHK UTM-Fault ]] >>>>>>>> retry=%s/%s" % (
                                _TITLE_WANMON, str(_retry_for_utm_fault), str(_retry_max_for_utm_fault)))
                            if _retry_for_utm_fault < _retry_max_for_utm_fault:
                                _retry_for_utm_fault += 1
                                _sleep = self._NORM
                                logger.info("[%s] Wait for UTM Fault, retry_chk=%s/%s, period=%s" % (
                                    _TITLE_WANMON, str(_retry_for_utm_fault), str(_retry_max_for_utm_fault),
                                    str(_sleep)))
                                continue
                            else:
                                logger.warning("[%s] Fail to Wait for UTM Fault, TimeOut, to=%s/%s" % (
                                    _TITLE_WANMON, str(_retry_for_utm_fault + 1), str(_retry_max_for_utm_fault)))

                        if _net_info.wan_mode == oc.VAL_WAN_MD_VNF or (
                                _net_info.wan_mode != oc.VAL_WAN_MD_VNF and not _is_ok_utm):
                            _prev_utm_status = _is_ok_utm
                        _wait_long_for_first_utm_start = None
                        _retry_chk_for_first_utm_start = 0
                        _retry_for_utm_fault = 0

                        # SW-VNF Delay for UTM Fix or Analyze Fault, 3m
                        logger.info(
                            "[%s] [[ 8. CHK STAY-HOST ]] >>>>>>>> prev_wan_mode=%s, now_wan_mode=%s, utm=%s, conn=%s" %
                            (_TITLE_WANMON, str(_prev_wan_mode), str(_net_info.wan_mode), str(_is_ok_utm),
                             str(_is_wan_conn)))
                        if _prev_wan_mode == oc.VAL_WAN_MD_VNF and _is_ok_utm and _net_info.wan_mode != oc.VAL_WAN_MD_VNF and _is_wan_conn:
                            logger.info("[%s] [[ 8-1. CHK STAY-HOST Retry ]] >>>>>>>> retry=%s/%s" % (
                                _TITLE_WANMON, str(_wait_for_handle_fault), str(_wait_max_for_handle_fault)))
                            if _wait_for_handle_fault < _wait_max_for_handle_fault:
                                _wait_for_handle_fault += 1
                                _sleep = self._SLOW
                                logger.info("[%s] Wait for Fault-Handling Time, retry_chk=%s/%s, period=%s" % (
                                    _TITLE_WANMON, str(_wait_for_handle_fault), str(_wait_max_for_handle_fault),
                                    str(_sleep)))

                                if not _is_wan_conn:
                                    logger.info("[%s] Try to Host-MGMT-SW" % (_TITLE_WANMON))
                                    if not self.host_mgmt_ha(_net_info):
                                        logger.error("[%s] Fail to Host-MGMT-SW" % _TITLE_WANMON)
                                continue
                            else:
                                logger.warning("[%s] Fail to Wait for Fault-Handling Time, TimeOut, to=%s/%s" % (
                                    _TITLE_WANMON, str(_wait_for_handle_fault + 1), str(_wait_max_for_handle_fault)))
                        _wait_for_handle_fault = 0
                        _prev_wan_mode = _net_info.wan_mode

                        # wan_mode == vnf
                        _is_dpdk = self._ob_info.ovs_dpdk()
                        logger.info("[%s] [[ 9. CHK WAN-SW ]] >>>>>>>> wan_mode=%s, conn=%s" % (
                            _TITLE_WANMON, str(_net_info.wan_mode), str(_is_wan_conn)))
                        if _net_info.wan_mode == oc.VAL_WAN_MD_VNF:
                            logger.info(
                                "[%s] [[ 9-1. CHK WAN-SW-HOST ]] >>>>>>>> sw_on=%s, utm_ok=%s, ovs_dpdk=%s, "
                                "vnf_retry=%s/%s, host_retry=%s/%s" % (
                                    _TITLE_WANMON, str(_is_sw_on), str(_is_ok_utm), str(_is_dpdk),
                                    str(_vnf_sw_retry), str(self._VNF_RETRY_MAX),
                                    str(_host_sw_retry), str(self._HOST_RETRY_MAX)))
                            _sleep = self._PERIOD
                            if _is_wan_conn:
                                _vnf_sw_retry = 0
                            elif _is_sw_on:
                                _to_host = (_is_dpdk or not _is_ok_utm) or (
                                not _is_dpdk and _host_sw_retry < self._HOST_RETRY_MAX)
                                # SW to Host
                                if _to_host:
                                    _vnf_sw_retry += 1
                                    logger.info("[%s] [[ 9-2. WAN-SW HOST ]] >>>>>>>> " % (_TITLE_WANMON))
                                    if not self.sw2host():
                                        logger.error("[%s] Fail to Switch to Host" % _TITLE_WANMON)
                                    _sleep = self._VERY_FAST
                                else:
                                    logger.info("[%s] [[ 9-2. STOP WAN-SW HOST ]] >>>>>>>> " % (_TITLE_WANMON))

                        # wan_mode == host, separate
                        else:
                            if _is_wan_conn: _host_sw_retry = 0
                            _sleep = self._PERIOD
                            logger.info(
                                "[%s] [[ 9-1. CHK WAN-SW-VNF ]] >>>>>>>> sw_on=%s, utm_ok=%s, ovs_dpdk=%s, "
                                "vnf_retry=%s/%s, host_retry=%s/%s" % (
                                    _TITLE_WANMON, str(_is_sw_on), str(_is_ok_utm), str(_is_dpdk),
                                    str(_vnf_sw_retry), str(self._VNF_RETRY_MAX),
                                    str(_host_sw_retry), str(self._HOST_RETRY_MAX)))
                            # SW to VNF
                            _to_vnf = (_vnf_sw_retry < self._VNF_RETRY_MAX) or (
                                not _is_dpdk and _host_sw_retry >= self._HOST_RETRY_MAX)
                            if _is_sw_on and _is_ok_utm and _to_vnf:
                                _host_sw_retry += 1
                                logger.info("[%s] [[ 9-2. WAN-SW VNF ]] >>>>>>>> " % (_TITLE_WANMON))
                                if not self.sw2vnf():
                                    logger.error("[%s] Fail to Switch to VNF" % _TITLE_WANMON)
                                _sleep = self._VERY_FAST
                            else:
                                logger.info(
                                    "[%s] [[ 9-2. CHK HOST-HA ]] >>>>>>>> conn=%s" % (_TITLE_WANMON, str(_is_wan_conn)))
                                if _is_wan_conn:
                                    logger.info("[%s] [[ 9-3. GO HOST-MAIN-BR ]] >>>>>>>> " % (_TITLE_WANMON))
                                    self.go_back_main(_net_info)
                                else:
                                    logger.info("[%s] [[ 9-3. DO HOST-HA ]] >>>>>>>> " % (_TITLE_WANMON))
                                    if not self.host_mgmt_ha(_net_info):
                                        logger.error("[%s] Fail to Host-MGMT-SW" % _TITLE_WANMON)
                                    _sleep = self._VERY_FAST

                        logger.info("[%s] [[ 10. CHK LAST Refresh&Update ]] >>>>>>>> refresh=%s" % (
                            _TITLE_WANMON, str(self._need_refresh)))
                        if self._need_refresh:
                            _net_info = self._refresh_update()
                            logger.info(to_show(self._ol, self._ob_info, _net_info, "WAN-HA", _conn=_is_wan_conn))
                            self._need_refresh = False
                    except Exception, e:
                        logger.error("[%s] Fail to Wan-HA, exc=%s" % (_TITLE_WANMON, str(e)))
                        logger.exception(e)
                except Exception, e:
                    logger.error("[%s] Fail to Monitor Wan, exc=%s" % (_TITLE_WANMON, str(e)))
                    logger.exception(e)
        except Exception, e:
            logger.error("!!!!!!!! Broken %s, exc=%s !!!!!!!!" % (_TITLE_WANMON, str(e)))
