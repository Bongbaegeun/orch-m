####################
1.2.0 ReFactoring
####################



#####################
1.1.0 버전 이전
#####################
1. python 패키지 설치
apt-get install -y libpq-dev python-dev python-pip lm-sensors language-pack-ko
pip install pyrestful
pip install tornado
pip install paramiko
pip install psycopg2


2. visudo 로 sudoers 편집
'zabbix  ALL=NOPASSWD: /bin/ip' 추가


3. 접속 정보
/var/onebox 디렉토리 생성
admin-openrc.sh 복사
UTM 접속 key 복사




