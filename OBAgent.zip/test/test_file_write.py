import unittest
import time

from onebox_agent.util.config_manager import ConfigManager
from onebox_agent.util.linux_service import Command

from onebox_agent.util.network_config import NetworkConfig

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

class TestFileWrite(unittest.TestCase):
    
    def write_dhclient_config(self, nic):
        result = False
        dhclient_conf = "/etc/dhcp/dhclient.conf"
        try:
            nc = NetworkConfig()
            
            mac_addr = nc.get_mac_address(nic)
            txt_dhcp_config = """option rfc3442-classless-static-routes code 121 = array of unsigned integer 8;

send host-name = gethostname();
send dhcp-client-identifier 1:{0};
send dhcp-lease-time 3600;
request subnet-mask, broadcast-address, time-offset, routers,
        domain-name, domain-name-servers, domain-search, host-name,
        dhcp6.name-servers, dhcp6.domain-search,
        netbios-name-servers, netbios-scope, interface-mtu,
        rfc3442-classless-static-routes, ntp-servers,
        dhcp6.fqdn, dhcp6.sntp-servers;
""".format(mac_addr)
        
            with open(dhclient_conf, "w") as f:
                f.write(txt_dhcp_config)
                
            result = True
        except Exception, e:
            logger.exception(e)
            result = False
            
        return result
    
    def test_write(self):
        nic = "eth0"
        result = self.write_dhclient_config(nic)
        
        self.assertEqual(result, True)