from httplib import HTTPException
from requests.exceptions import ConnectionError

import pprint
from time import sleep

from onebox_agent.apitest.wan_switch_apitest import WanStatusAPI, WanSwitchAPI, WanSwitchProgressAPI

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

def call_wan_status_api(orch):
    mode = "NONE"
    try:
        api = WanStatusAPI()
        result, content = api.call(orch)
        
        print "result = %d" % result
        print "content= %s" % pprint.pprint(content)
        
        mode = content['mode']
    except (HTTPException, ConnectionError), e:
        str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
        logger.error(str_err)
    except Exception, e:
        logger.exception(e)
    
    logger.debug("call_wan_status_api mode= %s" % mode)
    return mode
    
def call_wan_switch_api(orch, job_id, direction):
    status = "NONE"
    try:
        params = {
             "tid": "1234",
             "tpath": "onebox/wanswitch",
             "job_id": job_id,
             "direction": direction,
             "vnf_name": "UTM",
             "local_ip": "192.168.254.1"
        }
        
        api = WanSwitchAPI()
        result, content = api.call(orch, params)
        
        print "result = %d" % result
        print "content= %s" % pprint.pprint(content)
        
        status = content['status']
    except (HTTPException, ConnectionError), e:
        str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
        logger.error(str_err)
    except Exception, e:
        logger.exception(e)
    
    logger.debug("call_wan_switch_api status= %s" % status)
    return status
    
def check_progress(orch, job_id):
    status = "NONE"
    try:
        api = WanSwitchProgressAPI()
        while status != "DONE":
            result, content = api.call(orch, job_id)
            
            print "result = %d" % result
            print "content= %s" % pprint.pprint(content)
            
            status = content['status']
            if status == "FAIL":
                break
            sleep(5)
                
    except (HTTPException, ConnectionError), e:
        str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
        logger.error(str_err)
        return "" 
    except Exception, e:
        logger.exception(e)

def main():
    api_server = "127.0.0.1:5556"
    try:
        job_id = "1001"
        direction = "vm2host"
        
        call_wan_status_api(api_server)
        sleep(1)
        status = call_wan_switch_api(api_server, job_id, direction)
        sleep(1)
        check_progress(api_server, job_id)
            
    except (HTTPException, ConnectionError), e:
        str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
        logger.error(str_err)
        return "" 
    except Exception, e:
        logger.exception(e)
                

if __name__ == '__main__':
    main()
