import unittest
import yaml, yamlordereddictloader
import ruamel.yaml

from onebox_agent.util.config_manager import ConfigManager

class TestOneBoxConfig(unittest.TestCase):
    
    def test_ruamel(self):
        OB_ID="T330-R.OB38"
        
        config_orig = "/etc/onebox/onebox-agent-2.conf"
        config_dest = "/tmp/onebox-config"
        
        # read configuration
        with open(config_orig, "r") as f:
            ob_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
        
        # update configuration
        ob_cfg['onebox_id'] = "NGKIM.OB37"
            
        print ruamel.yaml.dump(ob_cfg, Dumper=ruamel.yaml.RoundTripDumper)
        
        # write configuration
        with open(config_dest, 'w') as f:
            f.write(ruamel.yaml.dump(ob_cfg, Dumper=ruamel.yaml.RoundTripDumper))
        
        cfg_ob_id = ob_cfg['onebox_id']
            
        self.assertNotEqual(OB_ID, cfg_ob_id)
        
    def test_vnfm_config(self):
        OB_ID="NGKIM.OB55"
        
        config_orig = "/etc/onebox/onebox-vnfm.conf"
        config_dest = "/tmp/onebox-vnfm-config"
        
        # read configuration
        with open(config_orig, "r") as f:
            ob_cfg = ruamel.yaml.load(f, Loader=ruamel.yaml.RoundTripLoader)
        
        # update configuration
        ob_cfg['onebox_id'] = "NGKIM.OB55"
            
        print ruamel.yaml.dump(ob_cfg, Dumper=ruamel.yaml.RoundTripDumper)
        
        # write configuration
        with open(config_dest, 'w') as f:
            f.write(ruamel.yaml.dump(ob_cfg, Dumper=ruamel.yaml.RoundTripDumper))
        
        cfg_ob_id = ob_cfg['onebox_id']
            
        self.assertEqual(OB_ID, cfg_ob_id)
        
    def test_zabbix_config(self):
        OB_ID="NGKIM.OB55"
        
        config_orig = "/tmp/zabbix_agentd.conf"
        
        from configobj import ConfigObj
        config = ConfigObj(config_orig)
        cfg_ob_id_orig = config.get("Hostname")
        
        config['Hostname'] = OB_ID
        config.write()
        
        # read again
        config = ConfigObj(config_orig)
        cfg_ob_id_updated = config.get("Hostname")
        
        self.assertEqual(cfg_ob_id_updated, OB_ID)
        
        
    
    