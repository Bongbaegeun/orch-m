import unittest
import time

from subprocess import Popen, PIPE, CalledProcessError

from onebox_agent.util.config_manager import ConfigManager 

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

class Command:
    
    def execute_command(self, commands):
        code = 0
        ret_out = ""
        ret_err = ""
        try:
            p = Popen(commands, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        
            while True:
                out = p.stdout.readline()
                err = p.stderr.readline()
                code = p.poll()
                
                if out == "" and code is not None: 
                    break
                else:
                    ret_out = "%s %s" % (ret_out, out.strip())
                    ret_err = "%s %s" % (ret_err, err.strip())
                
            logger.debug("commands= %s \ncode = %d \nout= %s \nerr= %s" % (commands, code, ret_out, ret_err))
        except CalledProcessError as e:
            logger.exception(e)
            code = e.returncode
            ret_out = e.output
        except Exception, e:
            logger.exception(e)
            
        return (code, ret_out, ret_err)  

class LinuxService(Command):
    
    def __init__(self, service):
        self.service = service
        
    def get_name(self):
        return self.service
    
    def start(self):
        commands = ["service", self.service, "start"]
        return  self.execute_command(commands)
            
    def stop(self):
        commands = ["service", self.service, "stop"]
        return  self.execute_command(commands)
            
    def restart(self):
        commands = ["service", self.service, "restart"]
        return  self.execute_command(commands)
            
    def status(self):
        running=False
        try:
            commands = ["service", self.service, "status"]
            (code, ret_out, ret_err) = self.execute_command(commands)
            logger.debug("%s" % ret_out)
            if ret_out.find ("is running") != -1:
                running=True
            
        except Exception, e:
            logger.exception(e)
            
        return  running
    
class TestServiceRestart(unittest.TestCase):
    
    def check_running(self, svc):
        if not svc.status():
            print "service %s is not running" % svc.get_name()
        else:
            print "service %s is running" % svc.get_name()
    
    def test_service_status(self):
        service = "onebox-agent"
        svc = LinuxService(service)
        ret_status = False
        
        svc.stop()
        time.sleep(1)
        self.check_running(svc)
        
        svc.start()
        time.sleep(1)
        self.check_running(svc)
        
        svc.stop()
        time.sleep(1)
        self.check_running(svc)
        
        self.assertFalse(ret_status)
    
    def test_service_restart(self):
        exp_ret =  ""
        service = "onebox-agent"
        
        svc = LinuxService(service)
        
        print "call stop"
        svc.stop()
        
        (code, output, err)  = svc.status()
        print "  code= %s output= %s err= %s" % (code, output, err)
        
        time.sleep(3)
        (code, output, err)  = svc.status()
        print "  code= %s output= %s err= %s" % (code, output, err)
        
        print "call start"
        svc.start()
        
        (code, output, err)  = svc.status()
        print "  code= %s output= %s err= %s" % (code, output, err)
        
        self.assertEqual(exp_ret, "")
    