import unittest
import pprint
from onebox_agent.apitest.onebox_backup_info_api import OneBoxBackupInfoAPI
from onebox_agent.descriptor.onebox_networking_descriptor import OneBoxBackupData, OneBoxNetworking, NetworkInfo, IPAddress

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

class TestOneBoxConfig(unittest.TestCase):
    
    def test_get_onebox_info(self):
        onebox_id = "Bdemo.OB1"
        
        api = OneBoxBackupInfoAPI()
        result, content = api.call(onebox_id, "211.224.204.203")
        
        print "result= %s content= %s" % (result, content)
        print "onebox_id= %s" % content['backup_data']['onebox_id']
        onebox_id_backup = content['backup_data']['onebox_id']
        
        pp = pprint.PrettyPrinter(indent=4)
        pp.pprint(content['backup_data'])
        
        obn = OneBoxNetworking.fromdict(content['backup_data'])
        self.assertEqual(onebox_id, obn.get_onebox_id())
        
        print obn.to_JSON()
        
        '''
        obbd = OneBoxBackupData()
        
        wanip = IPAddress(1)
        waninfo = NetworkInfo("eth0", wanip)
        
        out_of_band_mgmt = 1 
        mgmtip = IPAddress(0, "192.168.253.3", "255.255.255.0", "192.168.253.1")
        mgmtinfo = NetworkInfo("eth1", mgmtip)
        
        obb = OneBoxNetworking(onebox_id, waninfo, out_of_band_mgmt, mgmtinfo)
        
        obbd = OneBoxBackupData(obb, 
                                "211.224.204.132", 
                                "/var/onebox/backup/onebox/onebox_backup_20160907.tar.gz",
                                "/var/onebox/backup/%s/onebox/onebox_backup_20160907.tar.gz" % onebox_id )
        
        self.assertEqual(onebox_id, obb_obid)
        '''
        