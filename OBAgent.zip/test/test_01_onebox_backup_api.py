import unittest

from httplib import HTTPException
from requests.exceptions import ConnectionError

import pprint
from time import sleep

from onebox_agent.apitest.onebox_status_apitest import OneBoxStatusAPITest
from onebox_agent.apitest.backup_apitest import BackupAPITest, BackupStatusAPITest

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

class TestOneBoxBackup(unittest.TestCase):
    
    def test_backup_api(self):

        orch = "127.0.0.1:5556"
        try:
            params = {
                 "backup_server_ip": "211.224.204.203",
                 "backup_server_port": "22"
            }
            
            bk_api_test = BackupAPITest()
            result, content = bk_api_test.call(orch, params)
            print "result = %d" % result
            print "content= %s" % pprint.pprint(content)
                
        except (HTTPException, ConnectionError), e:
            str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
            logger.error(str_err)
            return "" 
        except Exception, e:
            logger.exception(e)