import unittest
import time

from socket import AF_INET
from onebox_agent.util.config_manager import ConfigManager
from onebox_agent.util.linux_service import Command

import onebox_agent.util.log_manager as log_manager
import code
logger = log_manager.LogManager.get_instance()

    
class TestCommand(unittest.TestCase):
    
    def test_ifconfig(self):
        nic = "eth5"
        ret_status = False
        
        cmd = Command()
        (code, ret_out, ret_err) = cmd.execute_command("ifconfig %s" % nic)
        
        print "code= %d" % code
        print "output = %s" % ret_out
        print "error = %s" % ret_err
        
        self.assertEqual(code, 1)
        
        
    def test_interface_down_and_up_with_run_process(self):
        nic = "eth1"
        ret_status = False
        
        cmd = Command()
        '''
        (code, output) = cmd.run_process("ifdown %s" % nic)
        
        print "code= %d" % code
        print "output = %s" % output
        
        time.sleep(1)
        
        (code, output) = cmd.run_process("ifup %s" % nic)
        
        print "code= %d" % code
        print "output = %s" % output
        
        time.sleep(1)
        '''
        (code, output, error) = cmd.execute_command("ifconfig eth1")
        
        print "code= %d" % code
        print "output = %s" % output
        print "error = %s" % error
        
        self.assertEqual(code, 0)
        
    def test_interface_down_and_up_with_run(self):
        nic = "eth1"
        ret_status = False
        
        cmd = Command()
        (code, output) = cmd.run_cmd("ifdown %s" % nic)
        
        print "code= %d" % code
        print "output = %s" % output
        
        time.sleep(1)
        
        (code, output) = cmd.run_cmd("ifup %s" % nic)
        
        print "code= %d" % code
        print "output = %s" % output
        
        self.assertEqual(code, 0)
        
    def test_interface_up(self):
        nic = "eth2"
        ret_status = False
        
        cmd = Command()
        (code, ret_out, ret_err) = cmd.execute_command("ifup %s" % nic)
        
        print "code= %d" % code
        print "output = %s" % ret_out
        print "error = %s" % ret_err
        
        self.assertEqual(code, 0)
        
    def test_interface_down(self):
        nic = "eth2"
        ret_status = False
        
        cmd = Command()
        (code, ret_out, ret_err) = cmd.execute_command("ifdown %s" % nic)
        
        print "code= %d" % code
        print "output = %s" % ret_out
        print "error = %s" % ret_err
        
        self.assertEqual(code, 0)
    
