from httplib import HTTPException
from requests.exceptions import ConnectionError
from optparse import OptionParser

import pprint
from time import sleep

from onebox_agent.apitest.onebox_backup_info_api import OneBoxBackupInfoAPI
from onebox_agent.apitest.onebox_status_apitest import OneBoxStatusAPITest
from onebox_agent.apitest.restore_apitest import RestoreAPITest, RestoreStatusAPITest, RestoreProgressAPITest
from onebox_agent.descriptor.onebox_networking_descriptor import OneBoxNetworking, IPAddress, NetworkInfo

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

def get_obn_from_orch(onebox_id, orch_ip):
    obbi_api = OneBoxBackupInfoAPI()
    result, content = obbi_api.call(onebox_id, orch_ip)
    
    print "result = %d" % result
    print "content= %s" % pprint.pprint(content)
    
    obn = OneBoxNetworking.fromdict(content['backup_data'])
    
    return obn
    
def main():
    
    parser = OptionParser(usage="usage: %prog [options]",
                          version="Get Backup info from Orchestrator")
    # AUX NIC to ignore when detecting network interfaces
    parser.add_option("--id", dest="id", type="string", help="One-Box ID")
    parser.add_option("-o", "--orch",
                       dest="orch", 
                       type="string",
                       help="orchestrator ip")
    (options, args) = parser.parse_args()
    
    try:
        if not options.orch: orch_ip = "211.224.204.203"
        else:                orch_ip = options.orch
        logger.debug("orch= %s" % orch_ip)
        
        if not options.id: onebox_id = "RESTORE.OB1"
        else:              onebox_id = options.id
    
        obagent = "127.0.0.1:5556"
        obn = get_obn_from_orch(onebox_id, orch_ip)
    except (HTTPException, ConnectionError), e:
        str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
        logger.error(str_err)
        return "" 
    except Exception, e:
        print str(e)
        logger.exception(e)

if __name__ == '__main__':
    main()
