import unittest
import time

from dialog import Dialog

from onebox_agent.util.config_manager import ConfigManager 

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()
    
class TestProgressDialog(unittest.TestCase):
    
    def gauge_demo(self, d):
        d.gauge_start("Progress: 0%", title="Still testing your patience...")

        for i in (1, 30, 50, 100):
            if i < 50:
                d.gauge_update(i, "Progress: {0}%".format(i), update_text=True)
            elif i == 50:
                d.gauge_update(i, "Over {0}%. Good.".format(i),
                               update_text=True)
            elif i == 80:
                d.gauge_update(i, "Yeah, this boring crap will be over Really "
                               "Soon Now.", update_text=True)
            else:
                d.gauge_update(i)

            time.sleep(1)

        d.gauge_stop()
    
    def test_progress_dialog(self):
        exp_ret = ""
        
        d = Dialog(dialog="dialog")
        # Dialog.set_background_title() requires pythondialog 2.13 or later
        d.set_background_title("My little program")
        self.gauge_demo(d)
        
        self.assertEqual(exp_ret, "")
        
    def test_viewbox(self):
        exp_ret = ""
        
        d = Dialog(dialog="dialog")
        # Dialog.set_background_title() requires pythondialog 2.13 or later
        d.set_background_title("My little program")
        d.infobox("Plug in Management Cable...", width=60, height=5)
        
        self.assertEqual(exp_ret, "")
    