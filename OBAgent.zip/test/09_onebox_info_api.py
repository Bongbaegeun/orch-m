import unittest

from httplib import HTTPException
from requests.exceptions import ConnectionError

import pprint
from time import sleep

from onebox_agent.apitest.onebox_info_api import OneBoxInfoAPI

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

class TestOneBoxInfoAPI(unittest.TestCase):
    
    def test_onebox_info_api(self):

        orch = "127.0.0.1:5556"
        try:
            api_test = OneBoxInfoAPI()
            result, content = api_test.call(orch)
            print "result = %d" % result
            print "content= %s" % pprint.pprint(content)
                
        except (HTTPException, ConnectionError), e:
            str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
            logger.error(str_err)
            return "" 
        except Exception, e:
            logger.exception(e)