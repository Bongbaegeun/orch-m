import unittest

from httplib import HTTPException
from requests.exceptions import ConnectionError

import pprint
from time import sleep

from onebox_agent.apitest.onebox_status_apitest import OneBoxStatusAPITest
from onebox_agent.apitest.backup_apitest import BackupAPITest, BackupStatusAPITest

from onebox_agent.apitest.onebox_backup_info_api import OneBoxBackupInfoAPI
from onebox_agent.descriptor.onebox_networking_descriptor import OneBoxNetworking, IPAddress, NetworkInfo

from onebox_agent.manager.onebox_manager import OneBoxManager, RestoreManager
from onebox_agent.util.linux_service import LinuxService

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

class TestGetOneBoxBackup(unittest.TestCase):
    
    def get_obn_from_orch(self, onebox_id, orch_ip):
        result = False
        output = ""
        
        obbi_api = OneBoxBackupInfoAPI()
        res, content = obbi_api.call(onebox_id, orch_ip)
        
        if res < 0:
            result = False
            output = content
        else:
            logger.debug("result = %d" % result)
            logger.debug("content= %s" % pprint.pprint(content))
        
            result = True
            output = content
            
        return result, output
    
    def get_backup_from_remote(self, restore, ip, port, remote_location, local_location):
        try:
            result, output = restore.copy_remote_backup_to_local(ip, port, remote_location, local_location)
        except Exception, e:
            logger.exception(e)
        return result, output
    
    def test_get_backup(self):
        result = False
        
        try:
            onebox_id = "REPLACE.OB1"
            orch_ip = "211.224.204.203"
            result, obn = self.get_obn_from_orch(onebox_id, orch_ip)
            
            if not result:
                logger.debug("Fail!!! %s" % obn) 
                result = False
            else:
                local_location = obn['local_location']
                remote_location = obn['remote_location']
                backup_server_ip = obn['backup_server_ip']
                backup_server_port = obn['backup_server_port']
                backup_data = obn['backup_data']
                
                local_location = "/tmp/ngkim.tar.gz"
                backup_root="/tmp/test-restore"
                
                restore = RestoreManager()
                result, output  = self.get_backup_from_remote(restore, backup_server_ip, backup_server_port, remote_location, local_location)
                if result:
                    restore.untar_backup(backup_root, local_location)
                    restore.restore_onebox_agent(backup_root)
                
                result = True
        except (HTTPException, ConnectionError), e:
            str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
            logger.error(str_err)
            result = False
        except Exception, e:
            logger.exception(e)
            result = False
        
        self.assertTrue(result)
