import unittest
import os

from onebox_agent.util.file_util import FileUtil

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

class TestDeleteFiles(unittest.TestCase):
    
    def test_search_files(self):
        
        futil = FileUtil()
        #search_result = self.files_with_an_extension("/var/log", ".0")
        search_result = futil.files_in_a_dir("/var/log/onebox")
        for f in search_result:
            print f
        
        futil.delete_files(search_result)
        search_result = futil.files_in_a_dir("/var/log/onebox")
                    
        self.assertEqual(len(search_result), 0)
        
        