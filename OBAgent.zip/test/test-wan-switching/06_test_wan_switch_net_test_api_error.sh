#!/bin/bash

if [ -z $1 ]; then
  job_id="1001"
else
  job_id=$1
fi 

echo "job_id= $job_id"
echo "call api"
curl -X POST http://127.0.0.1:5556/v1/wanswitch/test \
	-H "Content-Type: application/json" \
	-d "{ \"tid\": \"1234\", \"tpath\": \"onebox/wanswitch\", \"job_id\": \"${job_id}\", \"direction\": \"vm2inhost\", \"vnf_name\": \"UTM\", \"local_ip\": \"192.168.254.1\" }"

echo ""
echo "check progress"
./04_test_wan_switch_test_api.sh $job_id
echo ""
