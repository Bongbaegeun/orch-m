#!/bin/bash

curl -X GET http://127.0.0.1:5556/v1/wanmonitor/pause

echo ""