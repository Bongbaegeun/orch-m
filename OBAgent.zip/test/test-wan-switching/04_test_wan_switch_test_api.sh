#!/bin/bash

if [ -z $1 ]; then
  job_id="1004"
else
  job_id=$1
fi 

curl -X GET http://127.0.0.1:5556/v1/wanswitch/jobprogress/${job_id}

echo ""
