import unittest

from onebox_agent.util.network_config import NetworkConfig
from onebox_agent.util.linux_service import Command
from onebox_agent.descriptor.onebox_networking_descriptor import IPAddress, NetworkInfo

import netinfo

class TestNetworkConfig(unittest.TestCase):
    
    '''
    def test_network_connectivity(self):
        nc = NetworkConnection()
        print nc.is_connected()
    '''
    '''
    def print_netinfo(self, dev):
        print "*********************************"
        print dev
        print "mac: "+netinfo.get_hwaddr(dev)
        print "ip: "+netinfo.get_ip(dev)
        print "netmask: "+netinfo.get_netmask(dev)
        print "broadcast: "+netinfo.get_broadcast(dev)
        print "######################################"
        
    def get_default_gw_using_netinfo(self):
        gateway = ""
        found = False
        for route in netinfo.get_routes():
            if route['dest'] == "0.0.0.0" and route['netmask'] == "0.0.0.0":
                gateway = route['gateway']
                found = True
                
        return gateway    
    '''
    
    def test_network_config(self):
        
        result = True
        nc = NetworkConfig()
        
        nic_list = nc.get_network_interface_list()
        for nic in nic_list: 
            result = nc.config_manual_updown(nic)
                
        nc.list_adapters()
        
        ip_default = IPAddress(True)
        net_default = NetworkInfo("eth0", ip_default, "br-internet")
        result = nc.config_mgmt(net_default)
        
        nc.list_adapters()
        
        #nc.write()
            
        #nc.config_manual_updown("eth3")
        
        #self.print_netinfo("br-internet")
        #gateway = nc.get_host_default_gw()
        #print "default gateway = %s" % gateway
        #subnet = nc.get_host_subnet("br-internet")
        #print "subnet= %s" % subnet
         
        self.assertTrue(result)
    
        
    