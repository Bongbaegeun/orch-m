import unittest

from httplib import HTTPException
from requests.exceptions import ConnectionError

import pprint
from time import sleep

from onebox_agent.apitest.onebox_backup_api import OneBoxBackupAPI, OneBoxBackupProgressAPI

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

class TestOrchOneBoxBackup(unittest.TestCase):
    
    def call_backup_api(self, orch, onebox_id):
        status = "NONE"
        try:
            params = {
                 "backup_server": "175.213.170.123",
                 "backup_location": ""
            }
            
            obb_api = OneBoxBackupAPI()
            result, content = obb_api.call(orch, onebox_id, params)
            print "result = %d" % result
            print "content= %s" % pprint.pprint(content)
            
            status = content['status']
        except (HTTPException, ConnectionError), e:
            str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
            logger.error(str_err)
            return "" 
        except Exception, e:
            logger.exception(e)
        
        return status
    
    def check_progress(self, orch, onebox_id, status):
        try:
            obbp_api = OneBoxBackupProgressAPI()
            while status != "DONE":
                result, content = obbp_api.call(orch, onebox_id)
                
                print "result = %d" % result
                print "content= %s" % pprint.pprint(content)
                
                status = content['status']
                sleep(1)
                    
        except (HTTPException, ConnectionError), e:
            str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
            logger.error(str_err)
            return "" 
        except Exception, e:
            logger.exception(e)
    
    def test_orch_backup_api(self):
        result = True
        
        orch = "211.224.204.203:9090"
        onebox_id = "REPLACE.OB1"
        try:
            status = self.call_backup_api(orch, onebox_id)
            
            self.check_progress(orch, onebox_id, status)
                
        except (HTTPException, ConnectionError), e:
            str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
            logger.error(str_err)
            return "" 
        except Exception, e:
            logger.exception(e)
            
        self.assertTrue(result)
