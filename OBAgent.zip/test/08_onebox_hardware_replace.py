import unittest

from httplib import HTTPException
from requests.exceptions import ConnectionError

import pprint
from time import sleep

from onebox_agent.apitest.onebox_status_apitest import OneBoxStatusAPITest
from onebox_agent.apitest.backup_apitest import BackupAPITest, BackupStatusAPITest

from onebox_agent.apitest.onebox_backup_info_api import OneBoxBackupInfoAPI
from onebox_agent.descriptor.onebox_networking_descriptor import OneBoxNetworking, IPAddress, NetworkInfo

from onebox_agent.manager.onebox_manager import OneBoxManager
from onebox_agent.util.linux_service import LinuxService

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

class TestOneBoxHWReplace(unittest.TestCase):
    
    def get_obn_from_orch(self, onebox_id, orch_ip):
        obbi_api = OneBoxBackupInfoAPI()
        result, content = obbi_api.call(onebox_id, orch_ip)
        
        print "result = %d" % result
        print "content= %s" % pprint.pprint(content)
        
        #obn = OneBoxNetworking.fromdict(content['backup_data'])
        
        return content
    
    def stop_onebox_agent(self):
        ob_service = "onebox-agent"
        logger.debug("stop service %s" % ob_service)
        ob_svc = LinuxService(ob_service)
        ob_svc.stop()
        
        if ob_svc.status():
            logger.debug("Failed to stop One-Box Agent service.") 
            return False
        else:
            logger.debug("One-Box Agent service stop: OK!!!")
            return True
        
    def start_onebox_agent(self):
        ob_service = "onebox-agent"
        logger.debug("restart service %s" % ob_service)
        ob_svc = LinuxService(ob_service)
        ob_svc.restart()
        time.sleep(0.5)
        
        if not ob_svc.status():
            logger.debug("Failed to start One-Box Agent service.") 
            return False
        else:
            logger.debug("One-Box Agent service start: OK!!!")
            return True
        
    def test_hw_replace(self):
        result = False
        
        orch = "127.0.0.1:5556"
        try:
            onebox_id = "REPLACE.OB1"
            orch_ip = "211.224.204.203"
            obn = self.get_obn_from_orch(onebox_id, orch_ip)
            ''' 
            self.stop_onebox_agent()
             
            local_location = obn['local_location']
            remote_location = obn['remote_location']
            backup_server_ip = obn['backup_server_ip']
            backup_server_port = obn['backup_server_port']
            backup_data = obn['backup_data']
            
            manager = OneBoxManager.get_instance("/etc/onebox/onebox-agent.conf.sample")
            result, output = manager.run_restore(local_location, backup_data, backup_server_ip, backup_server_port, remote_location, restart_obagent = True)            
            if result:           
                logger.debug("RestoreHandler: Run restore OK!!!")
                result = True
            else:
                logger.error("RestoreHandler: Run restore ERROR!!! %s" % output)
                result = False
            ''' 
            result = True
        except (HTTPException, ConnectionError), e:
            str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
            logger.error(str_err)
            return "" 
        except Exception, e:
            logger.exception(e)
        
        self.assertTrue(result)
