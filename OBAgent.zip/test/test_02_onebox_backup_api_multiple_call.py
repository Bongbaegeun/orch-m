from httplib import HTTPException
from requests.exceptions import ConnectionError

from time import sleep

from onebox_agent.apitest.backup_apitest import BackupAPITest

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

def main():
    
    orch = "127.0.0.1:5556"
    try:
        NUM_TEST=2
        count = 1
        while True:
            params = {
             "backup_server_ip": "211.224.204.211"
            }
        
            bk_api_test = BackupAPITest()
            result, content = bk_api_test.call(orch, params)
            
            print "========================================================================="
            print " backup api call (count = %d) " % count
            print "-------------------------------------------------------------------------"
            print "result = %d" % result
            
            if result > 0:
                transaction_id = content ['transaction_id']
                print "transaction_id = %s" % transaction_id
            else:
                print "message= %s" % content
            print "========================================================================="
            print ""
            
            count += 1
            if count > NUM_TEST:
                break
            else:
                sleep(3)
        
    except (HTTPException, ConnectionError), e:
        str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
        logger.error(str_err)
        return "" 
    except Exception, e:
        logger.exception(e)
                

if __name__ == '__main__':
    main()
