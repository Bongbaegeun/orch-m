import unittest

def parser(conf):
    
    vnc_opts = [
        cfg.StrOpt('novncproxy_base_url',
                   default='http://127.0.0.1:6080/vnc_auto.html',
                   help='Location of VNC console proxy, in the form '
                        '"http://127.0.0.1:6080/vnc_auto.html"'),
        cfg.StrOpt('xvpvncproxy_base_url',
                   default='http://127.0.0.1:6081/console',
                   help='Location of nova xvp VNC console proxy, in the form '
                        '"http://127.0.0.1:6081/console"'),
        cfg.StrOpt('vncserver_listen',
                   default='127.0.0.1',
                   help='IP address on which instance vncservers should listen'),
        cfg.StrOpt('vncserver_proxyclient_address',
                   default='127.0.0.1',
                   help='The address to which proxy clients '
                        '(like nova-xvpvncproxy) should connect'),
        cfg.BoolOpt('vnc_enabled',
                    default=True,
                    help='Enable VNC related features'),
        cfg.StrOpt('vnc_keymap',
                   default='en-us',
                   help='Keymap for VNC'),
        ]
    
    CONF = cfg.CONF
    CONF.register_opts(vnc_opts)
    CONF(default_config_files=conf)
    
    return CONF


class TestOpenStackConfig(unittest.TestCase):
           
    def test_read_openstack_config(self):
        onebox_id = "Bdemo.OB1"
         
        CONF=parser(['/etc/nova/nova.conf'])
        print(CONF.novncproxy_base_url)
        
        self.assertEqual(onebox_id, onebox_id)
    
    def test_write_openstack_config(self):
        onebox_id = "Bdemo.OB1"
         
        CONF=parser(['/etc/nova/nova.conf'])
        print(CONF.novncproxy_base_url)
        
        CONF.novncproxy_base_url = "http://211.224.204.216:6080/vnc_auto.html"
        print(CONF.novncproxy_base_url)
        
        self.assertEqual(onebox_id, onebox_id)
    