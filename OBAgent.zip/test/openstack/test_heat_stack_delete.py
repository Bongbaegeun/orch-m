import unittest
from onebox_agent.util.heat_util import HeatUtil
from netaddr import *
from socket import inet_aton

class TestOpenStackHeat(unittest.TestCase):
    
    def test_delete_stack(self):
        hUtil = HeatUtil()
        result = hUtil.delete_stack_if_any()
        
        self.assertTrue(result)
        
    def validate_addr(self, ipaddr, netmask):
        result = False
        try:
            inet_aton(ipaddr)
            inet_aton(netmask)
            
            result = True
        except:
            sys.stderr.write('IP address or netmask invalid\n')
            sys.stderr.write(USAGE)
            result = False
        return result
    
    def get_net_size(self, netmask):
        binary_str = ''
        for octet in netmask:
            binary_str += bin(int(octet))[2:].zfill(8)
        return str(len(binary_str.rstrip('0')))
    
    def create_virtual_network(self, ipaddr, netmask, net_name, physnet, net_type):
        result = False
        
        hUtil = HeatUtil()
        net_id = hUtil.get_network_id(net_name)
        if net_id != "":
            result = hUtil.delete_network(net_id)
        else:
            result = True
            
        if result:
            result = False
            subnet = netmask.split('.')
            net_size = self.get_net_size(subnet)
            addr = IPNetwork(ipaddr + "/" + net_size)
            ip_cidr="%s/%s" % (addr.network, net_size) 
            result = hUtil.create_neutron_network(net_name, physnet, net_type, ip_cidr)
            
        return result

    def test_create_network(self):
        result = False
        
        result = self.create_virtual_network("192.168.0.1", "255.255.255.0", "net_office", "physnet_lan_office", "flat")
        result = self.create_virtual_network("192.168.1.1", "255.255.255.0", "net_server", "physnet_lan_server", "flat")
        
        self.assertTrue(result)