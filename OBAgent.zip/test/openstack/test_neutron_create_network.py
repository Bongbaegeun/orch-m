import unittest
from onebox_agent.util.heat_util import HeatUtil

class TestOpenStackHeat(unittest.TestCase):
    
    def test_delete_stack(self):
        hUtil = HeatUtil()
        result = hUtil.delete_stack_if_any()
        
        self.assertTrue(result)
        