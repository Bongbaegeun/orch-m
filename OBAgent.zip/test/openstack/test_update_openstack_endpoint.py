import unittest
import MySQLdb, urlparse

from onebox_agent.util.heat_util import HeatUtil

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

class TestOpenStackEndpoint(unittest.TestCase):

    def update_openstack_endpoint(self, dbhost, username, password, endpoint_type, new_endpoint_ip):
        try:
            if str(new_endpoint_ip).count(':') > 0:
                logger.error('Invalid EndPoint IP, ip=%s'%str(new_endpoint_ip))
                return
            db = MySQLdb.connect(host=dbhost, user=username, passwd=password,db="keystone")
            cur = db.cursor()
            str_query = "select id, url from endpoint where interface='%s'" % endpoint_type
            cur.execute(str_query)
            for row in cur.fetchall():
                endpoint_id = str(row[0])
                url = str(row[1])
                try:
                    u = urlparse.urlparse(url)
                    logger.debug("Changing %s to %s in URL %s" % (u.hostname, new_endpoint_ip, url))
                    urlstring = "%s://%s:%s%s" % (u.scheme, new_endpoint_ip, u.port, u.path)
                    logger.debug("new keystone endpoint= %s" % urlstring)
                    cur.execute("""UPDATE endpoint SET url=%s WHERE id=%s """, (urlstring, endpoint_id))
                except Exception as e:
                    logger.error("Could not parse URL, giving up: %s (%s)" % (url, e))
                    logger.exception(e)
                    cur.close()
                    db.close()
                
            db.commit()
            cur.close()
            db.close()
        except Exception, e:
            logger.error(str(e))
            logger.exception(e)

    def test_update_endpoint(self):
        hUtil = HeatUtil()
        
        keystone_user = "keystone"
        keystone_pass = "keystone1234"
        mgmt_ip = "127.0.0.1"
        
        logger.debug("update_openstack_endpoint_urls: call update_openstack_endpoint")
        hUtil.update_openstack_endpoint("127.0.0.1", keystone_user, keystone_pass, 'public', mgmt_ip)
        hUtil.get_stack_list()
        logger.debug("update_openstack_endpoint_urls DONE!!! **************")