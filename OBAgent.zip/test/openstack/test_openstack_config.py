import unittest
from onebox_agent.util.openstack_config import OpenStackConfig
from onebox_agent.util.linux_service import LinuxService

class TestOpenStackConfig(unittest.TestCase):

    def test_read_openstack_config(self):
        onebox_id = "Bdemo.OB1"
        
        section = "DEFAULT"
        name = "novncproxy_base_url"
        
        os_cfg = OpenStackConfig("/etc/nova/nova.conf")
        cfg = os_cfg.read()
        val = cfg.get(section, name )
        
        print "name= %s value= %s" % (name, val)
        
        self.assertEqual(onebox_id, onebox_id)
    
    def test_write_openstack_config(self):
        onebox_id = "Bdemo.OB1"
        
        section = "DEFAULT"
        name = "novncproxy_base_url"
        
        os_cfg = OpenStackConfig("/etc/nova/nova.conf")
        cfg = os_cfg.read()
        val = cfg.get(section, name )
        
        print "[before update] name= %s value= %s" % (name, val)
        
        vnc_url = "http://175.213.170.124:6080/vnc_auto.html"
        os_cfg.update(section, name, vnc_url)
        val = cfg.get(section, name )
        
        print "[after update] name= %s value= %s" % (name, val)
        os_cfg.write(cfg)
        
        services = ["nova-novncproxy", "nova-compute"]
        for service in services:
            svc = LinuxService(service)
            svc.restart()
        
        self.assertEqual(onebox_id, onebox_id)
    
    