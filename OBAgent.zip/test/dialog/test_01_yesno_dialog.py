import unittest

from dialog import Dialog, PythonDialogOSError
from onebox_agent.boot.boot_dialog import BootAgentDialog

class TestOneBoxHWReplace(unittest.TestCase):
    
    def test_confirm_hw_replace(self):
        result = False
        
        dialog = BootAgentDialog()
        code = dialog.confirm_request_recover_to_orchestrator()
        if code == dialog.OK:
            result = True
        else:
            result = False
        print "code= %s" % code
        
        self.assertTrue(result)
        