#!/bin/bash

curl -X GET http://211.224.204.137:5556/v1/status
echo ""
