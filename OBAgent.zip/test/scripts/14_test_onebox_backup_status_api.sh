#!/bin/bash

curl -X POST http://127.0.0.1:5556/v1/backup \
	-H "Content-Type: application/json" \
	-d "{ \"backup_server_ip\": \"211.224.204.211\" }"

echo ""
curl -X GET http://127.0.0.1:5556/v1/backupstatus?transaction_id=1603010000
echo ""
