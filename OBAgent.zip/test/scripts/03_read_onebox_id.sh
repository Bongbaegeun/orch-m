#!/bin/bash


ORCH_IP="211.224.204.248"
ORCH_PORT=9090
CUSTOMER="MBC"
OBIP="211.224.204.222"

curl http://${ORCH_IP}:${ORCH_PORT}/orch/server/${OBIP}



