#!/bin/bash

curl -v -X POST http://127.0.0.1:5556/v1/backup \
	-H "Content-Type: application/json" \
	-d "{ \"backup_server_ip1\": \"211.224.204.211\" }"
echo ""
