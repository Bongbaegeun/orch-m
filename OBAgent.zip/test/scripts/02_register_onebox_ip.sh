#!/bin/bash


ORCH_IP="211.224.204.248"
ORCH_PORT=9090
CUSTOMER="MBC"
OBIP="211.224.204.222"

curl -X POST http://${ORCH_IP}:${ORCH_PORT}/orch/server \
	-H "Content-Type: application/json" \
	-d "{ \"customer_name\": \"${CUSTOMER}\", \"public_ip\": \"${OBIP}\" }"

