#!/bin/bash

curl -X POST http://211.224.204.248:9090/orch/server \
	-H "Content-Type: application/json" \
	-d "{ \"customer_name\": \"MBC\" }"

