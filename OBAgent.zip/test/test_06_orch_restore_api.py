from httplib import HTTPException
from requests.exceptions import ConnectionError

import pprint
from time import sleep

from onebox_agent.apitest.onebox_restore_api import OneBoxRestoreAPI, OneBoxRestoreProgressAPI

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

def call_restore_api(orch, onebox_id):
    status = "NONE"
    try:
        params = {
            "requester":"BOOTAGT",
            "mgmt_ip": "211.224.204.166",
            "wan_mac": "00:10:f3:28:c2:74",
            "backup_id": "",
            "force_restore": False
        }
        
        obr_api = OneBoxRestoreAPI()
        result, content = obr_api.call(orch, onebox_id, params)
        print "result = %d" % result
        print "content= %s" % pprint.pprint(content)
        
        status = content['status']
    except (HTTPException, ConnectionError), e:
        str_err="Failed to get response from orchestrator due to HTTP Error %s" %str(e)
        logger.error(str_err)
        return "" 
    except Exception, e:
        logger.exception(e)
    
    return status

def check_progress(orch, onebox_id):
    status = "NONE"
    try:
        obrp_api = OneBoxRestoreProgressAPI()
        while status != "DONE":
            result, content = obrp_api.call(orch, onebox_id)
            
            print "result = %d" % result
            print "content= %s" % pprint.pprint(content)
            
            status = content['status']
            if status == "ERROR":
                break
            sleep(5)
                
    except (HTTPException, ConnectionError), e:
        str_err="Failed to get response from orchestrator due to HTTP Error %s" %str(e)
        logger.error(str_err)
        return "" 
    except Exception, e:
        logger.exception(e)

def main():
    orch = "211.224.204.203:9090"
    onebox_id = "RESTORE.OB1"
    try:
        status = call_restore_api(orch, onebox_id)
        
        check_progress(orch, onebox_id)
            
    except (HTTPException, ConnectionError), e:
        str_err="Failed to get response from orchestrator due to HTTP Error %s" %str(e)
        logger.error(str_err)
        return "" 
    except Exception, e:
        logger.exception(e)
                

if __name__ == '__main__':
    main()
