from httplib import HTTPException
from requests.exceptions import ConnectionError

from time import sleep

from onebox_agent.apitest.onebox_status_apitest import OneBoxStatusAPITest
from onebox_agent.apitest.reset_apitest import ResetAPITest, ResetStatusAPITest

import onebox_agent.util.log_manager as log_manager
logger = log_manager.LogManager.get_instance()

def main():

    orch = "127.0.0.1:5556"
    try:
        params = {
             "backup_server_ip": "211.224.204.211"
        }
        
        rs_api_test = ResetAPITest()
        result, content = rs_api_test.call(orch, params)
        transaction_id = content['transaction_id']
        print "result = %d" % result
        print "transaction_id = %s" % transaction_id
        
        while True :
            print "========================================================================="
            print " %s " % "restore_information"
            print "-------------------------------------------------------------------------"
            print "transaction_id = %s" % transaction_id
            print "========================================================================="
            print ""
            
            ob_api_test = OneBoxStatusAPITest()
            result, content = ob_api_test.call(orch)
            ob_step_name = content['status']
            print "========================================================================="
            print " %s " % "onebox_status"
            print "-------------------------------------------------------------------------"
            print "result = %d" % result
            print "status = %s" % (ob_step_name)
            print "========================================================================="
            print ""
            
            rs_status_api_test = ResetStatusAPITest()
            result, content = rs_status_api_test.call(orch, transaction_id)
            step_name = content['status']
            cur_step = content['current_step']
            tot_step = content['total_step']
            str_progress = content['progress']
            print "========================================================================="
            print " %s " % "restore_progress"
            print "-------------------------------------------------------------------------"
            print "result = %d" % result
            print "status = %s progress= %s / %s" % (step_name, cur_step, tot_step)
            print "progress = %s" % str_progress
            print "========================================================================="
            print ""
            
            if int(cur_step) == int(tot_step):
                break
            else: 
                sleep(1)
                rs_api_test.clear_screen()
            
    except (HTTPException, ConnectionError), e:
        str_err="Failed to get onebox-id from orchestrator due to HTTP Error %s" %str(e)
        logger.error(str_err)
        return "" 
    except Exception, e:
        logger.exception(e)
                

if __name__ == '__main__':
    main()