#!/bin/bash


BACKUP_DATE=`+%Y%m%d-%H%M`
BACKUP_DIR="/tmp/${BACKUP_DATE}"
BACKUP_ETC=$BACKUP_DIR/etc

mkdir -p $BACKUP_DIR
mkdir -p $BACKUP_ETC

ETC_FILE_LIST="/etc/hosts /etc/network/interfaces /etc/network/if-pre-up.d/iptablesload /etc/iptables.up.rules"
ETC_DIR_LIST="/etc/network/interfaces.d"

cp /etc/hosts $BACKUP_ETC
cp /etc/network/interfaces $BACKUP_ETC


/etc/iptables.up.rules
/etc/nova/nova.conf
/etc/nova/nova-compute.conf
/etc/neutron/neutron.conf
/etc/neutron/plugins/ml2/ml2_conf.ini
/etc/openvswitch/conf.db
/etc/onebox/onebox-agent.conf
/etc/onebox/onebox-vnfm.conf
/etc/zabbix/zabbix-agentd.conf
/etc/zabbix/zabbix_agentd.conf.d/
/usr/plugin
/var/onebox/vnf_configs